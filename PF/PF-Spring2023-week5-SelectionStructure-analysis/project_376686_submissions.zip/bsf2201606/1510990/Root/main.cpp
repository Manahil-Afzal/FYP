/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    //no terminator is used at the end of the if statement
    if (y > large)
    //write the correct the sentence of if. equal is not used in this case 
    if	(x > large)
    if (z > large)
	large =z;
    cout<<"Largest of x, y, and z is:"<<large<<endl;
    return 0;
}
