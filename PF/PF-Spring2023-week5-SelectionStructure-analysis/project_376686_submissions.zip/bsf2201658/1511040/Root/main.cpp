/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (x > y && x>z)
    cout<<"x is largest num="<<x;
    if (y > x && y>z)
    cout<<"y is largest num="<<y;
    if(z>x && z>y)
        cout<<"z is largest num="<<z;
    return 0;
}
