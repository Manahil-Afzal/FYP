/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main()
{	
    int x,y,z;
    cout<<"Input x,y,z;";
    cin>>x>>y>>z;
    if (x>y)
    if(x>z)
    cout<<"x islarger";
    else
    cout<<"y is larger";
    else
    cout<<"z is larger";
}


