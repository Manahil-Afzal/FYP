/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;

int main() {
    int x, y, z, large;
    
    // Add a space after the prompt
    cout << "Input x, y, and z: ";
    cin >> x >> y >> z;
    
    // Set the initial value of large to x
    large = x;
    
    // Remove the semicolon after the if statement
    if (y > large) {
        large = y;
    }
    // Add braces to enclose the body of the if statement
    if (z > large) {
        large = z;
    }
    
    // Add a space before the output message
    cout << "Largest of x, y, and z is: " << large << endl;
    return 0;
}
