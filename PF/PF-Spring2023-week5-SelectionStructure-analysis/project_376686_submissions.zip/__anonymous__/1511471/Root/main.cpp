#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (x>y && x>z)
    {
    	large = x;
	}
	else if (y>x && y>z)
	{
		large = y;
	}
	else
	{
		large = z;
	}
	cout<<"Largest number is :"<<large;
}