/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z"<<endl;
    cin>>x>>y>>z;
    if (x>y && x>z)
    {
    x = large;
    }
    else if (y>x && y>z)
    {
	y=large;
    }
    else{
        z=large;
    }
    cout<<"Largest of x, y, and z is:"<<large<<endl;
    return 0;
}
