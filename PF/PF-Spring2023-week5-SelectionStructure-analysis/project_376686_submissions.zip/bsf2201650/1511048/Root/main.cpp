/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
#include<string>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x'y'z";
    cin>>x>>y>>z;
    if (y>large);
    	x = large;
    (z>large);
	large =z;
    cout<<"Largest of x, y, and z is:"<<large<<endl;
    return 0;
}
