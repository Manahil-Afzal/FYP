/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/
#include <iostream>
using namespace std;
int main(){
	int x,y,z;//large removed
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (y >x && y>z)//no statement terminator
    {
    cout<<"largest number"<<y;
    }
    else if(x>y && x>z){
        cout<<"largest number"<<x;
        
    }
    else
    cout<<"largest number"<<z;
    return 0;
}
