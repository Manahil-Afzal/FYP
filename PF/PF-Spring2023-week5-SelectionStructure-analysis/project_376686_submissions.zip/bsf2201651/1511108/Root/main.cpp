/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;//removed large
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (y > x&&y>z)
    {
        cout<<"largest number is:"<<y;
    }
    else if (x > y&& x>z)
    {
        cout<<"largest number is:"<<x;
    }
	else
    cout<<"Largest number is:"<<z;
    return 0;
}
