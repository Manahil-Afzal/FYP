/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (y > x)
    {
        if (y>z)
        cout<<"large no is="<<y;
        else
        cout<<"large no is="<<z;
    }
    else{
        if(x>z)
        cout<<"large no is="<<x;
        else 
        cout<<"large no is="<<z;
    }
    
    
    
}
