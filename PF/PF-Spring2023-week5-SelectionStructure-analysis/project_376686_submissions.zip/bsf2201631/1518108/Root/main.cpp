/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if(x>y>z){
    	cout<<"the lrgest no is"<<x;
	}
	else if(x<y>z){
		cout<<"the largest no is"<<y;
	}
	else{
		cout<<"the latrgest no is"<<z;
	}
	return 0;
}

