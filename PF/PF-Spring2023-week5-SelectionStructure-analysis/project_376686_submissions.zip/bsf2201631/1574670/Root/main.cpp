/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    
    if(x>y>z){
        cout<<"the largest no is "<<x <<endl;
      
    }else if(x<y>z){
  cout<<"the largest no is "<<y <<endl;
    }else if(x<y<z){
          cout<<"the largest no is "<<z <<endl;
    }
   
    return 0;
}
