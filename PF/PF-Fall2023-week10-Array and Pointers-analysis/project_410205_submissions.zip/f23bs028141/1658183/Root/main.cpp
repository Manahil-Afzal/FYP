/*this programe demonstrates the use of arrays using pointers.identify and correct errors*/
#include<iostream>
using namespace std;

int main(){
    int arr[5] = {65, 66, 67, 68, 69};
    int *iptr[5];
    int i;

    // initialize array pointers by making them point to 5 different ints
    for (i = 0; i < 5; i++) {
        iptr[i] = &arr[i];
    }

    // now prints the values being pointed to by the pointers
    for (i = 0; i < 5; i++) {
        cout << "Pointer " << i << " points to " << *iptr[i] << "\n";
    }
    cout << '\n';

    // now print the addresses stored in the array
    for (i = 0; i < 5; i++) {
        cout << "The address stored in iptr[" << i << "] is " << iptr[i] << "\n";
    }
    return 0;
}
