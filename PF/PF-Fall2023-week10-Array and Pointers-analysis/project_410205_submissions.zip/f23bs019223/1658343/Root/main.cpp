/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include<iostream>
using namespace std;

int main()
{
	int *iptr[5];
	int fa=65, fb=66, fc=67, fd=68, fe=69;
	int i;

	// initialize array pointers by making them point to 5 different ints
	iptr[0] = &fa;
	iptr[1] = &fb;
	iptr[2] = &fc;
	iptr[3] = &fd;
	iptr[4] = &fe; // & opreater should be used

	// now prints the values being pointed to by the pointers
	for(int i=0; i<6; i++) // int was not used 
	{
		cout<<"Pointer"<<i<<" points to "<<*iptr[i]<<"\n"; // the ptr should be decleared like this *iptr
	}
	cout<<"\n"; // wrong cout syntax was used "" should be used 

	// now print the addresses stored in the array
	for(int i=0; i<5; i++) // int was not used

	{
		cout<<"The address stored in iptr["<<i<<"] is "<<&iptr[i]<<"\n";
	}

}
