/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */
#include <iostream>
using namespace std;

int main() {
    int *iptr[5];
    int fa = 65, fb = 66, fc = 67, fd = 68, fe = 69;
    int i;

    // Initialize array pointers by making them point to 5 different ints
    iptr[0] = &fa;
    iptr[1] = &fb;
    iptr[2] = &fc;
    iptr[3] = &fd;
    iptr[4] = &fe;

    // Now print the values being pointed to by the pointers
    for (i = 0; i < 5; i++) { // Change the loop condition to avoid going out of bounds
        cout << "Pointer " << i << " points to " << *iptr[i] << "\n";
    }
    cout << '\n'; // You should use '\n' instead of ’\n’

    // Now print the addresses stored in the array
    for (i = 0; i < 5; i++) {
        cout << "The address stored in iptr[" << i << "] is " << &iptr[i] << "\n"; // Use cout and correct the output format
    }

    return 0; // Add a return statement to indicate a successful execution
}

