/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include<iostream>
using namespace std;

int main(){
 int f[5]={65,66,67,68,69};
 int *ptr=f;//there is no way to dcelare this type of pointerv array
 int i;

	// initialize array pointers by making them point to 5 different ints
	/*illegal declaration or conversion first we have to initialize an array and then its value an be assigned to pointer*/


	// now prints the values being pointed to by the pointers
	for(i=0;i<6;i++)
	{
		cout<<"Pointer"<<i<<" points to "<<*ptr++<<"\n";
	}
	cout<<"\n";

	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in "<<i<<"is "<<&ptr[i]<<"\n";
	}
return 0;
}
