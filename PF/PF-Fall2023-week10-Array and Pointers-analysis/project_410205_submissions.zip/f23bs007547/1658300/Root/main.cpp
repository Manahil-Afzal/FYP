/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include<iostream>
using namespace std;

int main()
{
	int f[5]={65,66,67,68,69};
	int *ptr=f;//declaration was not correct
	int i;

	// initialize array pointers by making them point to 5 different ints
	/*illegal declaration or conversion first we have to initialize an array and then its value can be assigned to the pointer*/
	// now prints the values being pointed to by the pointers
	for(i=0;i<5;i++)//condition was not correct
	{
	    cout<<"Pointer"<<i<<"points to"<<*ptr++<<"\n";//ptr was not declared
	}
	cout<<"\n";


	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in pointer no"<<i<< "is "<<&ptr[i]<<"\n";
	}
	return 0;

}
