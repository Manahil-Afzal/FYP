/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include<iostream>
using namespace std;

int main(){
	int *iptr[5];
	int fa=65, fb=66, fc=67, fd=68, fe=69;
	int i;

	// initialize array pointers by making them point to 5 different ints
	iptr[0]=&fa;
	iptr[1]=&fb;
	iptr[2]=&fc;
	iptr[3]=&fd;
	iptr[4]=&fe;

	// now prints the values being pointed to by the pointers
	for(i=0; i<5; i++)
	{
		cout<<"Pointer"<<i<<" points to "<<*iptr[i]<<"\n";
	}
	cout<<"\n";

	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in "<< i  <<"is "<<&iptr[i]<<endl;
	}

}
