/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */
#include<iostream>
using namespace std;

int main(){
	int f[5]={65,66,67,68,69};
	int *iptr=f; //there is no way to declare this type of pointer array
	int i;

	// initialize array pointers by making them point to 5 different ints
	/*illegal declaration or conversion first we have to initialize an array and then its value can be assigned to pointer*/

	for(i=0; i<5; i++)// we have only five elements so we have to change condition to i<5
	{
		cout<<"Pointer"<<i<<" points to "<<*iptr++<<"\n";/* ptr was not declared in this scope and we can simply access every element by using increment opertor*/ 
	}
	cout<<'\n';

	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in pointer no "<<i<< "is "<<&iptr[i]<<"\n"; //i changed cout with Cout,and >> with <<, which was leading towards error
	}

}
