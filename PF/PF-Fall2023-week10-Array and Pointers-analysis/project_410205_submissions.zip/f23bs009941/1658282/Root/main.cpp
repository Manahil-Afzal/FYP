/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include<iostream>
using namespace std;

int main(){
	int f[5]={65,66,67,68,69};
	int *ptr=f;//there is no way to declare this type  of array
	int i;

	// initialize array pointers by making them point to 5 different ints
//first initilaize then value assign
	// now prints the values being pointed to by the pointers
	for(i=0; i<5; i++)//we have only 5 elemnts
	{
		cout<<"Pointer"<<i<<" points to "<<*ptr++<<"\n";//ptr was not declare
	}
	cout<<"\n";

	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in "<<i<<"is"<<&ptr[i]<<"\n"; 

	}

}
