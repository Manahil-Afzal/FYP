#include <iostream>
using namespace std;

int main() {
    int *iptr[5];
    int fa = 65, fb = 66, fc = 67, fd = 68, fe = 69;
    int i;

    // Initialize array pointers by making them point to 5 different ints
    iptr[0] = &fa; // Use the address-of operator (&) to assign the address of variables to pointers
    iptr[1] = &fb;
    iptr[2] = &fc;
    iptr[3] = &fd;
    iptr[4] = &fe;

    // Now print the values being pointed to by the pointers
    for (i = 0; i < 5; i++) { // Corrected the loop condition from 6 to 5
        cout << "Pointer " << i << " points to " << *iptr[i] << "\n"; // Corrected ptr to iptr
    }
    cout << '\n'; // Corrected the single quotes to double quotes

    // Now print the addresses stored in the array
    for (i = 0; i < 5; i++) {
        cout << "The address stored in iptr[" << i << "] is " << &iptr[i] << "\n"; // Corrected Cout to cout and added the correct formatting
    }

    return 0; // Added a return statement to indicate successful program execution
}
