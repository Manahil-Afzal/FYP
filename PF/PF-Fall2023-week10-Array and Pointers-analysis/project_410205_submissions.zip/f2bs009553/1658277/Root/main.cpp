/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include<iostream>
using namespace std;

int main(){
    int *ptr;
	int arr[5];
	int fa=65, fb=66, fc=67, fd=68, fe=69;
	int i;

	// initialize array pointers by making them point to 5 different ints
	ptr[0] = fa;
	ptr[1] = fb;
	ptr[2] = fc;
	ptr[3] = fd;
	ptr[4] = fe;

	// now prints the values being pointed to by the pointers
	for(i=0; i<5; i++)
	{
		cout<<"Pointer"<<i<<" points to "<<ptr[i]<<"\n";
	}
	cout<<"\n";

	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in "<< "is"<<&ptr[i]<<"\n";
	}

}
