// /* This program demonstrates the use of arrays using pointers. Identify and correct errors. */
//there is corrected code.
#include <iostream>
using namespace std;

int main() {
    int *iptr[5];
    int fa = 65, fb = 66, fc = 67, fd = 68, fe = 69;
    int i;

    // Initialize array pointers by making them point to 5 different ints
    iptr[0] = &fa; // Use the address-of operator '&' to store the addresses of the variables
    iptr[1] = &fb;
    iptr[2] = &fc;
    iptr[3] = &fd;
    iptr[4] = &fe;

    // Now print the values being pointed to by the pointers
    for (i = 0; i < 5; i++) { // Corrected loop bounds to avoid an out-of-bounds access
        cout << "Pointer " << i << " points to " << *iptr[i] << "\n"; // Use correct variable name iptr
    }
    cout << '\n'; // Use single quotes for the newline character

    // Now print the addresses stored in the array
    for (i = 0; i < 5; i++) {
        cout << "The address stored in iptr[" << i << "] is " << iptr[i] << "\n"; // Use correct variable name iptr
    }

    return 0; // Added a return statement to indicate successful program execution
}

