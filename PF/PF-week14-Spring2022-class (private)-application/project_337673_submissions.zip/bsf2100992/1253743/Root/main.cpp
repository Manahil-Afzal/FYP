/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include <iostream>
#include <string>
using namespace std;

class ElectricityBill{
	
	string custName;
	int billNum, consumedUnits, perUnitPrice, billAmount;
    public:
		void getDetails()
    {
	
	cout<<"Enter the name of customer: "<<endl;
	cin>>custName;
	cout<<"Enter bill number: "<<endl;
	cin>>billNum;
	cout<<"Enter the consumed units: "<<endl;
	cin>>consumedUnits;
		cout<<endl<<"Electricity Bill detalis are: "<<endl
	    <<"Customer Name: "<<custName<<endl
	    <<"Bill Number: "<<billNum<<endl
	    <<"Consumed Units: "<<consumedUnits<<endl;
    }
		void calcDetails()
		
    {

	   if(consumedUnits<300){
	   cout<<"Per unit price is Rs. 4 "<<endl;
	   cin>>perUnitPrice;
       }
	   if(consumedUnits>=300 && consumedUnits<1000){
	   cout<<"Per unit price is Rs. 5 "<<endl;
	   cin>>perUnitPrice;
       }
	   if(consumedUnits>999){
	   cout<<"Per unit price is Rs. 7"<<endl;   
	   cin>>perUnitPrice;
       }
	      billAmount = consumedUnits * perUnitPrice;
	      	cout<<"The Bill Amount is: "<<billAmount<<endl;
    }		
    		
};

int main()
{
	ElectricityBill obj;
	
	obj.getDetails();
	obj.calcDetails();
	
}
