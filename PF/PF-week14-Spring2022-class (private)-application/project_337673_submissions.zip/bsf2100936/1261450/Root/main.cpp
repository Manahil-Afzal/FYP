/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include<iostream>
using namespace std;
class Bill
{
	string customerName;
	string billno;
	int unitsConsumed;
	int billamount;
	public:
	void getDetails();
	void putDetails();
};
void Bill::getDetails()
{
	cout<<"Enter customer name : ";
	cin>>customerName;
	cout<<"Enter bill number : ";
	cin>>billno;
	cout<<"Enter consumed units : ";
	cin>>unitsConsumed;
	if(unitsConsumed<500)
	billamount=unitsConsumed*10;
	else if(unitsConsumed>=500 && unitsConsumed<1000)
	billamount=unitsConsumed*15;
	else if(unitsConsumed>899)
	billamount=unitsConsumed*12;
}
void Bill::putDetails()
{
	cout<<"\nCustomer name : "<<customerName<<endl;
	cout<<"Bill no. : "<<billno<<endl;
	cout<<"Consumed units : "<<unitsConsumed<<endl;
	cout<<"Bill amount : "<<billamount<<endl;	
}
int main()
{
	Bill std;
	std.getDetails();
	std.putDetails();
	return 0;
}