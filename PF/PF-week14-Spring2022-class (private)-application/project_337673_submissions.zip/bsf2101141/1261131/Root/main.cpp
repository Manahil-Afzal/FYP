/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include<iostream>
using namespace std;
class electbill{
    private:
    char name[20];
    int bilNo;
    float unit;
    float bilamnt(float n){
   float ret;
   if(n<300){
   ret=4*n;}
   else if(n>999){ 
   ret=5*n;}
   else{
   ret=7*n;}
     return ret;       
    }
    public:
    void getdetails();
    void putdetails();
    };
void electbill:: getdetails(){
   cout<<"enter your name: "<<endl;
   cin>>name;
   cout<<"enter bill number : "<<endl;
   cin>>bilNo;
   cout<<"enter units: "<<endl;
   cin>>unit;
   bilamnt(unit);
}
void electbill:: putdetails(){
   cout<<"your name: "<<name<<endl;
   cout<<"bill number: "<<bilNo<<endl;
   cout<<"units: "<<unit<<endl;
   cout<<"Your bill amount is "<<bilamnt(unit)<<" Rs/-";
}
main(){
   electbill c1;
   c1.getdetails();
   c1.putdetails();
}
