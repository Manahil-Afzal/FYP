/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include<iostream>
using namespace std;


class Electricitybill {
    string coustomerName;
    long billNo;
    int units;
    int unitPrice;
    double billAmount;
    public:
    void getDetails();
    void putDetails();
};

int main() {
    Electricitybill  billCal;
    billCal.getDetails();
    billCal.putDetails();
    return 0;
}

void Electricitybill::getDetails() {
    cout<<"Enter Coustomer Name:"<<endl;
    cin>>coustomerName;
    cout<<"Enter Bill Number:"<<endl;
    cin>>billNo;
    cout<<"Enter Number of units consumed:"<<endl;
    cin>>units;
    if(units < 300)
    unitPrice = 4;
    else if(units >= 300 && units <= 999)
    unitPrice = 5;
    else if(units > 999)
    unitPrice = 7;
    billAmount = (double)units * unitPrice;
}
void Electricitybill::putDetails() {
cout<<"Bill Details: \n";
cout<<"Coustomer Name:"<<coustomerName<<endl;
cout<<"Bill Number:"<<billNo<<endl;
cout<<"Units Consumed :"<<units<<endl;
cout<<"Your Bill Amount:"<<billAmount<<endl;
}
