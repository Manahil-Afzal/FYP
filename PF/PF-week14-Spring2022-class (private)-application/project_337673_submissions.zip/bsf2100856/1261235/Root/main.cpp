/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include<iostream>
using namespace std;
class Bill
{
	string customerName;
	string billNo;
	int unitsConsumed;
	int billAmount;
	public:
	void getDetails();
	void putDetails();
};
void Bill::getDetails()
{
	cout<<"Enter customer name : ";
	cin>>customerName;
	cout<<"Enter bill number : ";
	cin>>billNo;
	cout<<"Enter consumed units : ";
	cin>>unitsConsumed;
	if(unitsConsumed<300)
	billAmount=unitsConsumed*4;
	else if(unitsConsumed>=300 && unitsConsumed<1000)
	billAmount=unitsConsumed*5;
	else if(unitsConsumed>999)
	billAmount=unitsConsumed*7;
}
void Bill::putDetails()
{
	cout<<"\nCustomer name : "<<customerName<<endl;
	cout<<"Bill no. : "<<billNo<<endl;
	cout<<"Consumed units : "<<unitsConsumed<<endl;
	cout<<"Bill amount : "<<billAmount<<endl;	
}
int main()
{
	Bill std;
	std.getDetails();
	std.putDetails();
	return 0;
}