/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include<iostream> 

 using namespace std;
 class ebill 
 { 
      private: 
      int billNo; 
      char cname[20]; 
      int units; 
      double bill; 
      public: 
                 void get() 
         { 
                 
                  cout<<"Enter bill number : "; 
                  cin>>billNo; 
                  cout<<"\nEnter Customer Name : "; 
                  cin>>cname; 
                  cout<<"\nEnter No. of Units used : "; 
                  cin>>units; 
          } 
                 void put() 
          { 
                 cout<<"\nbill number is : "<<billNo; 
                 cout<<"\nCustomer Name is : "<<cname; 
                 cout<<"\nNumber of Units Consumed : "<<units; 
                 cout<<"\nBill of Customer : "<<bill; 
          } 
                 void calc() 
         { 
                 if(units<=100) 
                        bill=units*1.20; 
                else if(units<=300) 
                        bill=100*1.20+(units-100)*2; 
                else 
                        bill=100*1.20+200*2+(units-300)*3; 
          } 
 }; 
              int main() 
      { 
              
              ebill p1; 
              p1.get(); 
              p1.calc(); 
              p1.put(); 
              
       }
