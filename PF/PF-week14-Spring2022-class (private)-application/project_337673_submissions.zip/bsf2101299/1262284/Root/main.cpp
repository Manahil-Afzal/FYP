/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/


#include<iostream>
using namespace std;
class electricity
{
private:
    string name;
    int billno;
    int units;
public:
    void getdetails();
    void results();
};
int main()
{
    electricity value;
    value.getdetails();
    value.results();
    return 0;
}
void electricity:: getdetails()
{
    cout<<" Enter Your name ";
    cin>>name;
    cout<<" Enter your bill number ";
    cin>>billno;
    cout<<" Enter the units u have consumed ";
    cin>>units;
}
void electricity::results()
{
    int a;
    cout<<"Your name is : "<<name<<endl;
    cout<<"Your bill number is : "<<billno<<endl;
    cout<<"Units you have consumed :  "<<units<<endl;
    if(300>units)
    {
        a= units*4;
        cout<<"Your bill is  "<<a;
    }
    else if(999<units)
    {
        a=units*7;
        cout<<" Your bill is  "<<a;
    }

    else
    {
        a=units*5;
        cout<<" Your bill is "<<a;
    }
}