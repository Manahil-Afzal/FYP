/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include <iostream>
using namespace std;
class billData{
    public:
    string customerName;
    int billNumber;
    int unitsConsumed;
};
int main(){
    int billAmount;
    int perUnitPrice;
    
    billData myObj; // Create an object of billData
    cout << "Enter the customer name: "<< endl;
    cin >> myObj.customerName;
    cout << "Enter bill number : "<< endl;
    cin >> myObj.billNumber;
    cout << "Enter units Consumed" << endl;
    cin >> myObj.unitsConsumed;
    if(myObj.unitsConsumed < 300){
     cout <<  " perUnitPrice = 4";
    }
    if(myObj.unitsConsumed >= 300){
        perUnitPrice = 5;
    }
    if(myObj.unitsConsumed > 999){
        perUnitPrice = 7;
    }
    billAmount = myObj.unitsConsumed*perUnitPrice ;
    cout << "The name of customer is: " << myObj.customerName << endl;
    cout << "The bill number is: " << myObj.billNumber << endl;
    cout << "The uni consumed are: " << myObj.unitsConsumed << endl;
    cout << "The biil amount is " << billAmount;
    
    return 0;
  
    
}