/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include <iostream>
using namespace std;
class Bill
{
	private:
		string name;
		int billnmbr;
		int units;
		int price;
	public:
	    void getData();
	    void putData();			
};
   void Bill::getData()
   {
   	cout<<"Enter Customer Name:";
   	cin>>name;
   	cout<<"Enter Bill Number:";
   	cin>>billnmbr;
   	cout<<"Enter units consumed:";
   	cin>>units;
   	if (units<300)
   	price= units*4;
   	else if (units>=300 && units<1000)
   	price=units*5;
   	else if (units>999)
   	price=units*7;
   }
   void Bill::putData()
   {
   	cout<<"Cutomer name is:"<<name<<endl<<"Bill Number is:"<<billnmbr<<endl<<"Units consumed are:"<<units<<endl<<"Bill Amount is:"<<price;
   }
   int main()
   {
   	Bill myObj;
   	myObj.getData();
   	myObj.putData();
   	return 0;
   }