/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include <iostream>
using namespace std;

class Bill{
    private:
  string name;
  string bill_nmbr;
  int units;
  float bill_amount;
  float unit_price;
  public:
  void getin();
  void display();
    
};
void Bill::getin(){
    cout<<"Enter your name"<<endl;
    getline(cin,name);
    cout<<"Enter the bill number"<<endl;
    cin>>bill_nmbr;
    cout<<"Enter the units consumed"<<endl;
    cin>>units;
     if(units<300){
        unit_price=4;
    }
    else if(units>=300&&units<1000){
        unit_price=5;
    }
    else{
        unit_price=7;
    }
    bill_amount=unit_price*units;
}
void Bill::display(){
    cout<<"User Account Info: "<<endl;
    cout<<"Name: "<<name<<"   "<<"Bill number : "<<bill_nmbr<<"   "<<"Total units: "<<units<<endl;
    cout<<"Price per unit: "<<unit_price<<"   "<<"Total amount to pay: "<<bill_amount<<endl;
   
    
}
int main(){
    Bill amount;
    amount.getin();
    amount.display();
    
    
    return 0;
    
    
    
    
}