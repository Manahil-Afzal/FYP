#include <iostream>
using namespace std;

int main(){
int a,b;
cin>>a;
cin>>b;
cout<<"This is the entered value:"<<a;
cout<<"This is the entered value:"<<b;
    
    
    
    return 0;
}