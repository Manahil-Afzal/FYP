/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include <iostream>
using namespace std;

class Car {
  public:
    int speed(int maxSpeed);

};


int Car::speed(int maxSpeed) {
  return maxSpeed;
};

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
