/*Write a program that creates a class to display electricity bill. 
The class should take customer name, bill number, units consumed as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 4;
if greater than or equal to 300 but less than 1000 the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 7.*/
#include<iostream>
using namespace std;
class electricitybill
{
	public:
	string name;
	int billno;
	int unitconsumed;
	int unitprice;
	void detailin()
	{
		cout<<"enter detail pls:\n";
		cout<<"enter name:";
		cin>>name;
		cout<<"\nenter bill no:";
		cin>>billno;
		cout<<"\nenter consumed unit:";
		cin>>unitconsumed;
	}
	void detailout()
	{
		cout<<"your enter detail is:\n";
		cout<<"name of person:"<<name;
		cout<<"\nbill n o    :"<<billno;
		cout<<"\nunit consumed:"<<unitconsumed;
		if(unitconsumed<300)
		unitprice=4;
		if(unitconsumed>=300&&unitconsumed<1000)
		unitprice=5;
		if(unitconsumed>999)
		unitprice=7;
		cout<<"\nthe amount of bill is:"<<unitprice*unitconsumed;		
	}

};
int main ()
{
	electricitybill electdetail;
	electdetail.detailin();
	electdetail.detailout();
}