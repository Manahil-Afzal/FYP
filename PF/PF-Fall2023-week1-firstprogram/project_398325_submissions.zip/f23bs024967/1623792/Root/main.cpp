//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
    cout<<" My name is SALMAN AYYUB ";
    cout<<" and my student id is F23BS024967 . ";
}