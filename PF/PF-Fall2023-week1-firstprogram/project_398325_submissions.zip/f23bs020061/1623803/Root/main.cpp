#include<iostream>
using namespace std;

int main()
{
    cout<<"Ayyan ayub\n";
     cout<<"f23bs020061";
     return 0;
     //Write a C++ program which displays your name and student id on scre
}