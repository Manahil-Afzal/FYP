#include<iostream>
#include<string>
using namespace std;
main()
{
    string  name;
    string  studentid;
    cout<<"Enter your name:";
    cin>>name;
    cout<<"Enter your student id:";
    cin>>studentid;
}