//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main()
{
    cout<<"My naem is saleem Aasi :"<<endl;
    cout<<"My student id is F23BSo16737";
}