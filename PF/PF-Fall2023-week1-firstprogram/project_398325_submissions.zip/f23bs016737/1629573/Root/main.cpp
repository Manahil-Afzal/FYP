//Write a C++ program which displays your name and student id on screen.
#include <iostream>
using namespace std;
int main()
{
  cout<<"My student id is f23bs016737" <<endl;
  cout<<"My name is M saleem aasi ";
}
