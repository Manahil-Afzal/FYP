//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
    cout<<"My name is MUHAMMAD ZAIN ASHIQ";
    cout<<"\nf23bs032578";
}