//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main(){
    cout<<"Student name: Ahmad Hassan"<<endl;
    cout<<"Student Id: f23bs036807";
}