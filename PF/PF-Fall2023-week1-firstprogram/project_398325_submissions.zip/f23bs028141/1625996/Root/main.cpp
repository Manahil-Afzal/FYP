#include<iostream>
using namespace std;
main()
{
    cout<<"husnain khalid";
    cout<<"f23bs028141";
    }//Write a C++ program which displays your name and student id on screen.