//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main()
{
    cout<<"My name is Laiba Usman."<<endl;
    cout<<"My Student ID is F23BS007547.";
    return 0;
}