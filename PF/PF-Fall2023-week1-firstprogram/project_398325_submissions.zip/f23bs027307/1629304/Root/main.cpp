
#include<iostream>
using namespace std;
main(){
    
    cout<<"Muhammad Nadeem";
    cout<<endl;
    cout<<"f23bs027307";
    
}