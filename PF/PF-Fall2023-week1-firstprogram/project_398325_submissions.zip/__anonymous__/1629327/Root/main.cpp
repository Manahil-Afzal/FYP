//Write a C++ program which displays your name and student id on screen.
#include<iostream>
#include<string>
using namespace std;
int main( )
{
    string studentname;
    string studentid;
    cout<<"enter studentname";
    cin>>studentname;
    cout<<
    "enter studentid";
    cin>>studentid;
    
}