//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
    string name;
    string studentid;
    cout<<"Enter your name:";
    cin>>name;
    cout<<"Enter your studentid:";
    cin>>studentid;
    
}