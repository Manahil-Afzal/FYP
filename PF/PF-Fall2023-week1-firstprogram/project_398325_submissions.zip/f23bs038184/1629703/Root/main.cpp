//Write a C++ program which displays your name and student id on screen.
#include<iostream>
#include<string>
using namespace std;
main()
{
    string name,id;
     
    cout<<"enter your name";
    cin>>name;
    cout<<"enter your student id";
    cin>>id;
    cout<<"your name is"<<name;
    cout<<"your id is"<<id;
}