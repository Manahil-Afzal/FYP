//Write a C++ program which displays your name and student id on screen.
#include<iostream>
int main()
{
  std::cout<<"Name: Abubakar Khalil\n";
  std::cout<<"Student Id: f23bs035695";
    return 0;
}
