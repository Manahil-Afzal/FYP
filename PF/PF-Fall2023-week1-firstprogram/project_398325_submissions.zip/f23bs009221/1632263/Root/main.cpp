//Write a C++ program which displays your name and student id on screen.
#include <iostream>
using namespace std;

int main(){
    string name;
    string id;
    cout<<"Enter my name "<<endl;
    cin>>name;
    cout<<"Enter my id "<<endl;
    cin>>id;
    
    cout<<"My Name is: "<<name<<endl;
    cout<<"My id is: "<<id<<endl; 
    return 0;
}