//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main()
{
    string name;
    string stdid;
    cout<<"enter your name";
    cin>>name;
    cout<<"enter your student id";
    cin>>stdid;
}