//Write a C++ program which displays your name and student id on screen.
#include <iostream>
using namespace std;
main()
{ 
     cout<<"My name is : Ali Hassan"<<endl; 
     cout<<"Student Id : f23bs003413"<<endl; 
}