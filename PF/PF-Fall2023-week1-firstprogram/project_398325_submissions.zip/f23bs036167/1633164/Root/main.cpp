//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main()
{
    string studentName;
    string studentId;
    cout<<"enter the student name";
    cin>>studentName;
    cout<<"enter the student id";
    cin>>studentId;
    return 0;
}