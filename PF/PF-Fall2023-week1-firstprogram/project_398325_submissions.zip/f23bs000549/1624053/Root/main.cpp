//Write a C++ program which displays your name and student id on screen.
#define MAX_LENGTH 100
#include <iostream>
using namespace std;
int main()
{
    char name[MAX_LENGTH] = { 0 };
	string id;
    cout<<"***Enter Your Name***"<<endl;
    cin.getline(name, MAX_LENGTH);
    cout<<"***Enter Your Id***"<<endl;
    cin>>id;
    
    
    cout << "\nDisplaying My Information," << endl;
    cout << "Name: " <<name << endl;
    cout << "ID: " << id << endl;
    return 0;
}