//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
 main()
{ 
    string name = "Shoaib-Ul-Hussan";
    string studentId = "F23BS012721";
    cout << " My name is " << name << " and student id is " << studentId << " . " ;
}
    