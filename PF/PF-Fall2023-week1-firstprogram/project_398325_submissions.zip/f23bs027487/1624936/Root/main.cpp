#include<iostream>
using namespace std;
main ()
{
    cout<<"Muhammad Qaisar";
    
    cout<<" \n F23BS027487";
    }//Write a C++ program which displays your name and student id on screen.