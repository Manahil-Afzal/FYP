//Write a C++ program which displays your name and student id on screen.#include<iostream>
#include<iostream>
using namespace std;
 main()
{
    cout<<"Hamza amin";
    cout<<endl;
    cout<<"f23bs015199";
    
}