//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main ()
{
    cout<<"Junaid Ahmad\n";
    cout<<"f23bs021263";
    return 0;
}