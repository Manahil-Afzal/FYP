//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main ()
{
    cout<<"Asad Hussain\n";
    cout<<"f23bs021589";
    return 0;
}//Write a C++ program which displays your name and student id on screen.