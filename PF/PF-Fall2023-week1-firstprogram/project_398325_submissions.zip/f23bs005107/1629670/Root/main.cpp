#include<iostream>
using namespace std;
main()
{
	string name;
	string ID;
	cout<<"enter your name=";
	cin>>name;
	cout<<"enter your student ID=";
	cin>>ID;
	return 0;
}//Write a C++ program which displays your name and student id on screen.