//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
    string name = "Muhammad Kamran";
    string studentId = "F23BS001549";
    cout<<"My name is "<< name<< " and student id is "<<studentId <<".";
}