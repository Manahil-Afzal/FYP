//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
string name ="umar saif";
string id ="f23bs0199553";
cout<<"my name is "<< name<<"\n";
cout<<"my id is "<<id;
}