//Write a C++ program which displays your name and student id on screen.
#include<iostream>
#include<string>
using namespace std;
main()
{
	string name;
	string StdId;
	cout<<"Enter your name:";
	cin>>name;
	cout<<"Enter your student id:";
	cin>>StdId;	
}