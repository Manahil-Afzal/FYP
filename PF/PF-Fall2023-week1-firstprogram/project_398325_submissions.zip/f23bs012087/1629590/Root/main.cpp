#include<iostream>
using namespace std;
main()
{
cout<<"MY Name is Aaraaf Ahmad" <<endl;
cout<<"Student ID: F23BS012087" <<endl;
}