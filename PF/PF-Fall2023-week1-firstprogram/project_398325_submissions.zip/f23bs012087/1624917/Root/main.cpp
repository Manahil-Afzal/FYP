 
#include <iostream>
using namespace std;

int main() {
    string name = "Aaraaf Ahmad";
    string studentID = "fb23bs012087";

    cout << "Name: " << name << endl;
    cout << "Student ID: " << studentID << endl;

    return 0;
}