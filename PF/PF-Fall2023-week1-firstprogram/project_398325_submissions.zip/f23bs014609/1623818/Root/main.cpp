#include<iostream>
using namespace std;
int main(){
    cout<<"My Name= Shayan Afzal"<<endl;
    cout<<"My ID= F23BS014609"<<endl;
    return 0;
}