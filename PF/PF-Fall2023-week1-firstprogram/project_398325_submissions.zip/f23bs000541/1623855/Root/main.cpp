//Write a C++ program which displays your name and student id on screen.
#include <iostream>
#include <string>
using namespace std;

int main()
{
    // Assigning the name and id to the variables
    string name = "Syed Zohair Abbas";
    string id = "F23BS000541";

    // Printing the name and student id
    cout << "Name: " << name << "\n";
    cout << "Student id: " << id << "\n";
}
