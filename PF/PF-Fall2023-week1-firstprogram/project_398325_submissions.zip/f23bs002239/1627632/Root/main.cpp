#include <iostream> 
using namespace std;
main()
{
    string name;
    string studentid;
    cout<<"name";
    cin>>name;
    cout<<"studentid";
    cin>>studentid;
}