//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
cout<<"saif haider\n";
cout<<"f23bs010025\n";
}