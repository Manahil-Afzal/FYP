//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
    cout<<"M. Talha Abbas\n";
    cout<<"F23BS006959";
}