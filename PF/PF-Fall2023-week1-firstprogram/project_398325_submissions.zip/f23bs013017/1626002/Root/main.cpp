//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main(){
    cout<<"Muhammad Umair"<<endl;
    cout<<"f23bs013017"<<endl;
}