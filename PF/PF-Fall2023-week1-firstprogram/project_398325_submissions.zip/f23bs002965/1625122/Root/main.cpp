//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
    string name= "Abdul Hanan" ; 
    string student_ID = "F23BS002965";
    cout<< name<<endl;
    cout<< student_ID<<endl;
}
