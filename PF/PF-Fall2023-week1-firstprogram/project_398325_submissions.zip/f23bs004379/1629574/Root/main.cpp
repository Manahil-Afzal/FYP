//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;

main()
{
cout<<"Zuha Noor"<<endl;
cout<<"Std Id is= F23BS004379"<<endl;
    
}