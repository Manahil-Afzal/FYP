#include<iostream>
using namespace std;
main()
{
    cout<<"MY Name=Anas Saleem"<<endl;
    cout<<"My Id=F23BS022071";
    return 0;
}