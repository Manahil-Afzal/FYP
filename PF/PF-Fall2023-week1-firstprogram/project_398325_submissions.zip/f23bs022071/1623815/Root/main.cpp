//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
main()
{
cout<<"My Name=Muhammad Anas Saleem"<<endl;
cout<<"My Id=F23BS022071";
return 0;
}