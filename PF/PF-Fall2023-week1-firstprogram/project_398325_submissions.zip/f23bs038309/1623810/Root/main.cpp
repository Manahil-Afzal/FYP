//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main ()
{
    cout<<"Umair Ahmed\n";
    cout<<"f23bs038309";
    return 0;
}//Write a C++ program which displays your name and student id on screen.//Write a C++ program which displays your name and student id on screen.