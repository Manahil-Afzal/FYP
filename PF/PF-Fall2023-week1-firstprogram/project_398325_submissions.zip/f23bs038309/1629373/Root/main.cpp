//Write a C++ program which displays your name and student id on screen.
#include<iostream>
using namespace std;
int main()
{
    cout<<"My name is Umair Ahmed.\n My student I'D is F23BS038309";
    return 0;
    
}