#include<iostream>
using namespace std;

int main(){
    cout<<"Usman Hashim"<<endl;
    cout<<"F23BS016527";
    
}