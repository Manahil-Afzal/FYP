//Write a C++ program which displays your name and student id on screen.
# include<iostream>
using namespace std;
int main()
{
	cout<<"shahzaman\n";
	cout<<"f23bs005798";
}