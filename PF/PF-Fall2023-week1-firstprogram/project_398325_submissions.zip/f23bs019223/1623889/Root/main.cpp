#include<iostream>
#include<string>
using namespace std;
int main()
{
    //Assigning the name and id to the variable 
    string name="ABDUL MOHAMIN";
    string id="F23BS019223";
    //Print name and id
    cout<<"Name:"<<name<<"\n";
    cout<<"Student ID:"<<id<<"\n";
}