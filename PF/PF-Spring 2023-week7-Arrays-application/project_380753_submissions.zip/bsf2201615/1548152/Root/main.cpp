#include <iostream>

using namespace std;

int main() {
  const int SIZE = 10;
  int arr[SIZE];

  for(int i = 0; i < SIZE; i++) {
    arr[i] = i + 100;
  }

  for(int i = 0; i < SIZE; i += 2) {
    cout << "Value at index " << i << " is " << arr[i] << endl;
  }

  return 0;
}//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.