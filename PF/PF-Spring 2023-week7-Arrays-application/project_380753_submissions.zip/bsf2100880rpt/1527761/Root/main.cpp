//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int n , number[100];
    cout<<"enter no u want to display: "<<endl;
    cin>>n;
    
    for ( int i = 0 ; i < n ; i++)
    {
        number[i]= i+ 100;
    }
    for ( int i = 1 ; i < n ; i = i + 2 )
    {
        cout<<number[i]<<endl;
    }
    return 0;
    
}