//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
main(){
int num[100];
for(int i=0;i<100;i++)
{
num[i]=i+100;
}
for(int j=1;j<100;j+=2){
    cout<<num[j]<<"\n";
}
}
