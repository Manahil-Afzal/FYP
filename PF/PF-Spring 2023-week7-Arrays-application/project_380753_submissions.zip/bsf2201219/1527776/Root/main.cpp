//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.

#include<iostream>
using namespace std;
int main()
{
    int size[19], number=0;
    for ( int i=0; i<=19; i++ ){
        if( i%2==1 ){
    number= i+100;
    cout<<number<<endl;
        }
    }
}