//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>

using namespace std;

const int ARRAY_SIZE = 10;

int main()
{
    int myArray[ARRAY_SIZE];

    // Set array ith location value to i+100
    for(int i=0; i<ARRAY_SIZE; i++)
    {
        myArray[i] = i + 100;
    }

    // Display the values assigned to odd index values of array
    for(int i=1; i<ARRAY_SIZE; i+=2)
    {
        cout << "Value at index " << i << " is " << myArray[i] << endl;
    }

    return 0;
}