//Write a C++ program that sets array with location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
main()
{
int i,array[200];
cout<<"Enter 6 valus:"<<endl;
for(i=100;i<106;i++)
cin>>array[i];
cout<<"odd index values are:"<<endl;
for(i=100;i<106;i++)
{
    if(i%2!=0)
    cout<<array[i]<<endl;
}

}