//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;
main(){
    int arr_siz=10;
    int array[arr_siz];
    for(int i=0;i<arr_siz;i++)
      {
      array[i]=i+100;
       }
     for(int i=1;i<arr_siz;i+=2){
     	cout<<"value assign to index "<<i<<" :"<<array[i]<<endl;
     }
     
    }