//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.

#include <iostream>
using namespace std;
main(){
    int i,array[200];
    cout<<"Enter 5 values:"<<endl;
    for(i=101;i<106;i++)
    cin>>array[i];
    cout<<"Odd index values are:"<<endl;
    for(i=101;i<106;i++)
    {
        if(i%2==0)
    cout<<array[i]<<endl;
        
    }
}