//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int i, array[110];
    cout<<"enter 10 values:"<<endl;
    for(i=101;i<=110;i++)
    cin>>array[i];
    cout<<"odd index values are:"<<endl;
    for(i=101;i<=110;i++)
    {
        if(i%2!=0)
        cout<<array[i]<<endl;
    }
    return 0;
}