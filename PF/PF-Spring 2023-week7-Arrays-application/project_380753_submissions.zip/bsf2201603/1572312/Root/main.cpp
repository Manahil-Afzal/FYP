//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>

using namespace std;

int main() {
    const int SIZE = 10; // size of the array
    int arr[SIZE]; // declare array of size 10

    // loop through array and assign values to each element
    for (int i = 0; i < SIZE; i++) {
        arr[i] = i + 100;
    }

    // display values of odd indexed elements
    for (int i = 1; i < SIZE; i += 2) {
        cout << "Value at index " << i << " is " << arr[i] << endl;
    }

    return 0;
}
