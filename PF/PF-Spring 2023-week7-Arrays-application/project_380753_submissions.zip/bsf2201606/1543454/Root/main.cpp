
#include <iostream>

using namespace std;

int main() {
    const int ARRAY_SIZE = 10;
    int arr[ARRAY_SIZE];

    // Set array ith location value to i+100
    for (int i = 0; i < ARRAY_SIZE; i++) {
        arr[i] = i + 100;
    }

    // Display values assigned to odd index values of array
    cout << "Values assigned to odd index values of array:" << endl;
    for (int i = 1; i < ARRAY_SIZE; i += 2) {
        cout << "arr[" << i << "] = " << arr[i] << endl;
    }

    return 0;
}
