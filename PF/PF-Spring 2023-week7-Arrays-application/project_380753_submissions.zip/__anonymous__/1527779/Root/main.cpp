#include<iostream>

using namespace std;
int main()
{
   int arr[10], i;
   cout<<"Enter any 10 array elements: ";
   for(i=0; i<10; i++)
      cin>>arr[i];
   cout<<"\nThese elements are on odd indexes:\n";
   for(i=0; i<10; i++)
   {
      if(i%2==0)
         cout<<arr[i]<<" ";
   }
   cout<<endl;
   return 0;
}