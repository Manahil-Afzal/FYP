//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;
main()
{
    int size[30];
    for(int i=0;i<30;i++){
        size[i]=i+100;
    }
    for(int i=1;i<30;i+=2){
        cout<<"assigned values["<<i<<"]"<<size[i]<<endl;
    }
}