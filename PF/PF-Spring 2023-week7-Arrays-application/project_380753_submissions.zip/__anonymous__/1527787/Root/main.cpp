#include<iostream>

using namespace std;
main()
{
    int size[10];
    for (int i=0; i<10; i++){
    	size[i] = i+100;
    }
    for (int i=1; i<10 ; i+=2){
    	cout<<"Value assigned to size["<<i<< "]" <<size[i] <<"\n";
    }
}
    
    

