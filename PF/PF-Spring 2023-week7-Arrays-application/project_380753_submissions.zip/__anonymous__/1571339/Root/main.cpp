//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.

#include <iostream>
using namespace std;

int main()
{
    const int SIZE = 10;
    int arr[SIZE];

    // set the values of the array
    for (int i = 0; i < SIZE; i++) {
        arr[i] = i + 100;
    }

    // display the values assigned to odd index locations
    cout << "Values assigned to odd-indexed locations of array:\n";
    for (int i = 1; i < SIZE; i += 2) {
        cout << "arr[" << i << "] = " << arr[i] << endl;
    }

    return 0;
}
