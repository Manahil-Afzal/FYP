//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
 #include<iostream>
 using namespace std;
 int main(){
     int i;
     int count;
     cout << "Enter The Number Of Elements : ";
     cin >> count;
     int numbers[count];
     // passing the value to array
     for (i=0;i<count;i++){
         cout << "ENTER THE ELEMENTS";
         cin>> numbers[i];
     }
     
     for(i=0;i<count;i++){
         int odd_number;
         if(i%2 != 0){
             odd_number=numbers[i];
         cout << odd_number;
         }
     }
 }