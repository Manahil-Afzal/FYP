//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
	int arr[20]; //array of size 20
	
	for(int i=0;i<20;i++)
	{
		arr[i] = i+100;
	}
	
	cout<<"\n Number at odd index: ";
	for(int i=0;i<20;i++){
	
		if(i%2!=0){
			cout<<arr[i]<<" ";
		}
	}
		cout<<"\n";
}
