//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int size[20];
    for(int i=0;i<20;i++){
        size[i]=i+100;
    }
    for(int i=1;i < 20;i+=2){
        cout<<"asingned values["<<i<<"]"<<size[i]<<endl;
    }
}