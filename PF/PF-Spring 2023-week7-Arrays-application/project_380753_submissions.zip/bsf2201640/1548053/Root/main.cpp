//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>

int main() {
    const int ARRAY_SIZE = 10;  // Size of the array
    int myArray[ARRAY_SIZE];   // Declare an array of integers

    // Set values in the array
    for (int i = 0; i < ARRAY_SIZE; i++) {
        myArray[i] = i + 100;   // Set array[i] = i + 100
    }

    // Display values at odd index values
    std::cout << "Values at odd index values of the array: ";
    for (int i = 1; i < ARRAY_SIZE; i += 2) {
        std::cout << myArray[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}
