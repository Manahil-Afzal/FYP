//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.#include<iostream>
#include<iostream>
using namespace std;
int main()
{ 
    int num[10];
    for(int i=0;i<10;i++)
    {num[i]=i+100;}
    for(int i=10;i<10;i=i+2)
    {cout<<num[i]<<",";}
    
}