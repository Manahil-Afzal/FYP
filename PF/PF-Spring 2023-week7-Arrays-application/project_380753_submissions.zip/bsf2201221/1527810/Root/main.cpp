//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int size[13];
    for(int i=0;i<13;i++){
    size[i]=i+100;
    }
    for(int i=1;i<13;i+=2){
        cout<<"value assigned to size["<<i<<"] :"<<size[i]<<"\n";
    }
}