#include<iostream>

using namespace std;
main()
{
    int a[10];
    for (int i=0; i<10; i++){
    	a[i] = i+100;
    }
    for (int i=1; i<10 ; i+=2){
    	cout<<"Odd assigned values to a["<<i<< "] are " << a[i] <<"\n";
    }
}