//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
main()
{
    int      array[100];
    cout<<"Enter the 100 values"<<endl;
    for(int i=0;i<100;i++)
    {
        cin>>array[i];
    }
    for(int i=0;i<100;i++)
    {
        if(array[i]%2!=0)
        {
            cout<<"Display all odd indux value"<<endl;
            cout<<array[i]<<endl;
        }
    }
}