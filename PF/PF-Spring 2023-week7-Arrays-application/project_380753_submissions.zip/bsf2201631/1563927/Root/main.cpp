//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;

int main(int argc, char const *argv[])
{
  // 1
  int size;
  cout << "Enter total number of elements to add : " << endl;
  cin >> size;

  // 2
  int numArray[size];

  // 3
  for (int i = 0; i < size; i++)
  {
    cout << "Enter number " << i << " :" << endl;
    cin >> numArray[i];
  }

  // 4
  cout << "Odd indexed numbers : " << endl;
  for (int i = 0; i < size; i++)
  {
    // 5
    if (i % 2 == 0)
    {
      continue;
    }
    cout << "Index " << i << ",value : " << numArray[i] << endl;
  }

  // 6
  cout << "Even indexed numbers : " << endl;
  for (int i = 0; i < size; i++)
  {
    if (i % 2 != 0)
    {
      continue;
    }
    cout << "Index " << i << ",value : " << numArray[i] << endl;
  }

  return 0;
}