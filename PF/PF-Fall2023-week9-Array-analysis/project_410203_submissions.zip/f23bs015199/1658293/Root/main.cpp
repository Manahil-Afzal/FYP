// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main() {
    float arr[5];  // Change the array size to 5 to store five values
    int i;

    cout << "Enter five floating-point values:";

    for (i = 0; i < 5; i++) { // Use a for loop to input the values
        cin >> arr[i];
    }

    cout << "Values in reverse order" << endl;
    for (i = 4; i >= 0; i--) { // Use a for loop to print the values in reverse order
        cout << arr[i] << " ";
    }

    return 0;
}
