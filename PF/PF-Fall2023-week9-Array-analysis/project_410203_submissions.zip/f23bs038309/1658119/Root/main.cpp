// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;



int main()
{
float arr[5]; //4 is replaced by 5 beacuse 5 floating point values input this program
int i;
cout<<"enter five floating-point values:";

for(int i=0;i<5;i++) // = is removed because the array started from 0 index.
cin>>arr[i];    //corrected the syntax
cout<<"values in reverse order"<<endl;
 i=5;
for(int j=i-1;j>=0;j--)
cout<<arr[j]<<endl;
return 0;
}
