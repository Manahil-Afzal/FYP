#include <iostream>
using namespace std;

int main() {
    float arr[5];
    int i;
    cout << "Enter five floating-point values: "<<endl;

    for (i = 0; i < 5; i++){
    cout<<"enter the value no"<<i+1<<":";
        cin >> arr[i];
}
    cout << "Values in reverse order:" << endl;
    for (i = 4; i >= 0; i--)
        cout << arr[i] << " ";
    
    return 0;
}
