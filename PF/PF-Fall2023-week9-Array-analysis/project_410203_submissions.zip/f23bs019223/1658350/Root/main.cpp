// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;



int main()
{
float arr[5]; // the arr is declared with the size of 5 to hold five floating point values 
int i;
cout<<"enter five floating-point values:";

for(int i=0;i<5;i++){ // use curly braces and to input use arr[i]
cin>>arr[i];
}
cout<<"values in reverse order"<<endl;
for(int i=4;i>=0;i--){ // start from the last element and go in reverse
cout<<arr[i]<<"";
}
return 0;
}
