// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;



int main()
{
float arr[5];//array size is less than  5
int i;
cout<<"enter five floating-point values:"<<endl;

for(int i=0;i<=5;i++){
    cout<<"enter the value number"<<i+1<<" ";
    cin>>arr[i];}
cout<<"value in reverse order"<<endl;
cin>>arr[i];
for(int i=4;i>=0;i--)
{
    cout<<arr[i]<<endl;
}
return 0;
}
