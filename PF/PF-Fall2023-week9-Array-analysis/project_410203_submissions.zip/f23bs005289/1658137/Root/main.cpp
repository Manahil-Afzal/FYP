// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.
#include <iostream>
using namespace std;
int main()
{
float arr[4];
int i;
cout<<"enter five floating-point values:"<<endl;        //Write endl to go to next line
for(int i=0;i<=5;i++)
cin>>arr[i];                                            //[i] is missing
cout<<"values in reverse order"<<endl;
for(int i=0;i>=5;i--)                                   //Wrong condition was use
cin>>arr[i];                                            //Use cin instead of cout,wrong exertion operator is use
return 0;
}
