// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;



int main()
{
float arr[5]; //The array "arr" is declared with a size of 5 to hold five floating-point values.

int i;
cout<<"enter five floating-point values:";

for(i=0;i<5;i++){ // Use '<' instead of '<=' and 'cin>> arr[i]' to input values

cin>>arr[i];
}
cout<<"values in reverse order"<<endl;

for(i=4;i>=0;i--){// Start from the last element and go in reverse order.
cout<<arr[i]<<" ";
}
return 0;
}