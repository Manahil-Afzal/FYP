// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;
int main()
{
float arr[5];   /*array size is less than required size*/
int i;  /*variable decalration does not affect the program but it isn't good programming practice */
cout<<"enter five floating-point values:"<<endl;
for(int i=0;i<5;i++)/*terminating condition is wrong its one more than array size*/
{
	cout<<"enter the vaue no "<<i+1<<" ";/*program should display appropriate message for every input*/
  cin>>arr[i];}
cout<<"values in reverse order"<<endl;
for(int i=4;i>=0;i--)/*initiallized value of i was 0 which leads loop to terminate quickly,does not show thw required output and in terminating condition 0 will be included to access the first value of array*/

cout<<arr[i]<<endl;/*endl makes the output readable*/
return 0;
}
