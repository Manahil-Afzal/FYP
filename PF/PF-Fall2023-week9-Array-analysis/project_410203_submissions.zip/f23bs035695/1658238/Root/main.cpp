// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.
#include <iostream>
using namespace std;

int main()
{
    float arr[5];  // You need to declare an array of size 5 to store 5 floating-point values.
    
    cout << "Enter five floating-point values: ";

    for (int i = 0; i < 5; i++) {  // Use '<' instead of '<=' and 'cin >> arr[i]' to input values.
        cin >> arr[i];
    }

    cout << "Values in reverse order:" << endl;
    for (int i = 4; i >= 0; i--) {  // Start from the last element and go in reverse order.
        cout << arr[i] << " ";
    }

    return 0;
}
