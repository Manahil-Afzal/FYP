
// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.




#include <iostream>

int main() {
    const int size = 5; // Define the size of the array
    float values[size]; // Declare an array to store the floating-point values

    // Input phase: Prompt the user to enter five floating-point values
    for (int i = 0; i < size; i++) {
        std::cout << "Enter value " << (i + 1) << ": ";
        std::cin >> values[i];
    }

    // Display the values in reverse order
    std::cout << "Values in reverse order:\n";
    for (int i = size - 1; i >= 0; i--) {
        std::cout << values[i] << " ";
    }

    return 0;
}