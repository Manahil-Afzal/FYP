// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;



int main()
{
float arr[5];//set array size
cout<<"enter five floating-point values:";

for(int i=0;i<5;i++)//wrong condition is used
cin>>arr[i];//wrong way of taking input
cout<<"values in reverse order"<<endl;
for(int i=4;i>0;i--)
cout<<arr[i];
return 0;
}
