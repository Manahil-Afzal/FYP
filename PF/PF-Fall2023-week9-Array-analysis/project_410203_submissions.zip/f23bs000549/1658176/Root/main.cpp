// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main()
{
    float arr[5]; // Corrected the array size to 5 (from 4)
    int i;
    cout << "Enter five floating-point values: ";

    for (int i = 0; i < 5; i++) // Changed the loop condition to i < 5
    {
        cin >> arr[i]; // Use arr[i] to read values into the array
    }

    cout << "Values in reverse order:" << endl;
    for (int i = 4; i >= 0; i--) // Changed the loop condition to i >= 0 and the loop counter initialization to 4
    {
        cout << arr[i] << " "; // Print the values with a space in between
    }
    
    return 0;
}




