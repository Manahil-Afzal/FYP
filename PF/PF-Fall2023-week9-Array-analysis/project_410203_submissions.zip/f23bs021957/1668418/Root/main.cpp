// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;
int main() {
    const int size = 5;
    float values[size];


    cout << "Enter five floating-point values:\n";
    for (int i = 0; i < size; ++i) {
        cout << "Value " << i + 1 << ": ";
    cin >> values[i];
    }

    
     cout << "Values in reverse order:\n";
    for (int i = size - 1; i >= 0; --i) {
        cout << values[i] << " ";
    }

    return 0;
}