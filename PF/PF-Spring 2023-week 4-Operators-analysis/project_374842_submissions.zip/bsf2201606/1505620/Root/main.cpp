// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  //cin syntx is wrong right syntax is cin>>
  cin>>y;
  x = y;
  //error to use the syntax right cout<<"vlaue of x="<<x<<endl;
  cout<<"Value of x = "<<x<<endl;
 
  int a = 3,b = 5,c = 8;
  // operators is use like a=a+b;
  a =a+b;
  c =a-b;
  //use also endl
  cout<<"\na += b: "<<a<<endl;
  cout<<"\nc -= b: "<<c;
  // operator is used after the = signs like a=*b
  
  a = a*b;
  b =b/c;
  //enter the /n for new line or endl
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


