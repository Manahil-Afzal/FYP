// Identify and correct errors. Also comment your identified errors and corrections
#include <iostream>
using namespace std;

int main()
{
    int x, y;
    cout << "Enter input variable y: ";
    cin >> y;  // Corrected error: Use >> instead of <<
    
    x = y;
    cout << "Value of x = " << x << endl;  // Corrected error: Added missing quotes and semicolon
    
    int a = 3, b = 5, c = 8;
    a += b;  // Corrected error: Removed unnecessary equals sign
    c -= b;  // Corrected error: Removed unnecessary equals sign
    
    cout << "\na += b: " << a;
    cout << "\nc -= b: " << c;
    
    a *= b;
    b /= c;  // Corrected error: Removed unnecessary equals sign
    
    cout << "\na *= b: " << a;
    cout << "\nb /= c: " << b;
  
    return 0;
}






