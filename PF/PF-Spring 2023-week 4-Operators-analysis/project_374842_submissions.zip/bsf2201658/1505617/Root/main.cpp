// Identify and correct errors. Also comment your identified errors and corrections
#include<iostream>//extra space
using namespace std;
int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//incorrect angle bracket
  x=y;
  cout<<"Value of x="<<x<<endl;//closing " is not inserted
  int a=3,b=5,c=8;
  a+=b;//wrong position of operator
  c-=b;//wrong position of operator
  cout<<"\na+=b:"<<a;
  cout<<"\nc-=b:"<<c;
  a*= b;
  b/=c;//wrong position of operator
  cout<<"\na*=b:"<<a;
  cout<<"\nb/=c:"<<b;
  return 0;
  }


