// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//Extraction Operator mistake
  x = y;
  cout<<"Value of x " <<x<<endl;//Double Qoute mistake
  
  int a = 3,b = 5,c = 8;
  a += b;//Operator mistake
  c -= b;//Operator mistake
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;//Operator mistake
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


