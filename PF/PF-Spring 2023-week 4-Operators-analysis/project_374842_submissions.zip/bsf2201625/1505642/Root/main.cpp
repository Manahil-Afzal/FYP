// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; //correct insertion operator
  x = y;
  cout<<"Value of x = "<<x<<endl; //close the double quotes
  
  int a = 3,b = 5,c = 8;
  a += b;//correct addition assignment
  c -= b;//correct substraction assignment
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;//correct division assignment
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


