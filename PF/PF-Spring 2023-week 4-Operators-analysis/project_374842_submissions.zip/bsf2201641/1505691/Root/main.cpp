// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

 main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//insertion operator
  x = y;
  cout<<"Value of x =" <<x<<endl; //double quotations
  int a=3, b=5,c=8; //space
  a+=b; // + BEFORE ASSIGNMENT OPERATOR
  c-=b; // - BEFORE ASSIGNMENT OPERATOR
  cout<<"\n a+= b: " ;
  cin>>b;
  cout<<"\n c-= b: ";
  cin>>b;
  a *= b;
  b/=c; //BEFORE ASSIGNMENT OPERATOR
  cout<<"a *= b: ";
  cin>>a;
  cout<<"b /= c: " ;
  cin>>b;
  
  return 0;
  }


