// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x, y;
  cout << "Enter input variable y: "; 
  cin >> y;  // corrected from cin << y;
  x = y;
  cout << "Value of x = " << x << endl;  // corrected from cout<<"Value of x = <<x<<endl;

  int a = 3, b = 5, c = 8;
  a += b;  // corrected from a =+ b;
  c -= b;  // corrected from c =- b;
  cout << "\na += b: " << a;
  cout << "\nc -= b: " << c;
  
  a *= b;
  b /= c;  // corrected from b =/ c;
  cout << "\na *= b: " << a;  // added newline
  cout << "\nb /= c: " << b;  // corrected from cout<<"b /= c: "<<b;

  return 0;
}



