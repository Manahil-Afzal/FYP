// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//insert the correct operators
  x = y;
  cout<<"Value of x = "<<x<<endl;//insert double colons
  
  int a = 3,c = 8;
  float b = 5;
  a += b;//change the order of operator 
  c -= b;//change the order of operator 
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  //now a=8, c=3
  a *= b;
  b /= c;//change the order of operators
  
  cout<<"\na *= b: "<<a;//insert line space
  cout<<"\nb /= c: "<<(float)b;//insert line space
  
  return 0;
  }


