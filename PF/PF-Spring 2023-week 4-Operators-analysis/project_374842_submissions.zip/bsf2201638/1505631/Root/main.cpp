// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;                   //correct extraction opr
  x = y;
  cout<<"Value of x = " <<x<<endl;          // correct inverted comma
  
  int a = 3,b = 5,c = 8;
  a += b;                            // correct oprator (+= instaed of =+)
  c -= b;                            // correct oprator
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;                           
  b /= c;                           // corrrct Opr  (/= instead of =/)
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


