// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//repaqcing extraction operator with insertion operator
  x = y;
  cout<<"Value of x =" <<x<<endl;//double qoutes aere not mentioned
  int a = 3,b = 5,c = 8;
  a += b;//wrong compound assignment operator
  c -= b;//wrong compound assignment operator
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;//wrong compound assignment operator
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


