// Identify and correct errors. Also comment your identified errors and corrections

#include<iostream> //remove space between include and iostream
using namespace std;
main()//remove int before main
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; //use wrong insertion operator
  x = y;
  cout<<"Value of x =" <<x<<endl; //use double quotes at the endf of = operator
  int a = 3,b = 5,c = 8;
  a += b; //correct addition assignment operator
  c -= b; //correct subtraction assignment opertaor
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c; // correct division assignment operator
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }



