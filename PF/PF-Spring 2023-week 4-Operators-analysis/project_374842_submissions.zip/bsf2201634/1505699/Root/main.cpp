// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; //insertion operator
  x = y;
  cout<<"Enter value of x =" <<x<<endl; //double qoutations
  int a=3,b=5,c=8; //space
  a+=b; //+ BEFORE ASSIGNMENT OPERATOR
  c-=b; //- BEFORE ASSIGNMENT OPERATOR
  cout<<"\na += b: ";
  cin>>a; //taking inputs
  cout<<"\nc -= b: ";
  cin>>c; //taking inputs
  a*=b;
  b/=c; //BEFORE ASSIGNMENT OPERATOR
  cout<<"a *= b: ";
  cin>>a;
  cout<<"b /= c: ";
  cin>>b;
  return 0;
}


