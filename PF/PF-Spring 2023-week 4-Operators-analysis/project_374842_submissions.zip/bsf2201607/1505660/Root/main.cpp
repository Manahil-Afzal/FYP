// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;
int main()
{
  int x,y;
 cout<<"Enter input variable y: ";
  cin>>y;//correct insertion operater
  x=y;
  cout<<"Value of x="<<x<<endl;//corect double quotes
  int a=3,b=5,c=8;
  a+=b;//corect addittion 
  c-=b;//corect subtraction
  cout<<"\na+=b:"<<a;
  cout<<"\nc-=b:"<<c;
  a*=b;
  b/=c;//corect division
  cout<<"a*=b:"<<a;
  cout<<"b/=c:"<<b;
  
  return 0;
  }


