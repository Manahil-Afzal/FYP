// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//exchange the syntax error << to >>
  x = y;
  cout<<"Value of x="<<x<<endl;//inser double qoutation marks
  
  int a = 3,c = 8;
  float b=5;//change the data type
  a += b;
  c -= b;
  cout<<"\na += b: "<<a;//insert \n
  cout<<"\nc -= b: "<<c;//insert \n
  // now a=8, c=3
  
  a *= b;
  b /= c;//change the order of operator 
  cout<<"\na *= b: "<<a;//insert \n
  cout<<"\nb /= c: "<<b;//insert \n
  
  return 0;
  }


