// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;          //correcting the extraction operators
  x = y;
  cout<<"Value of x =" <<x<<endl;    //correcting the quotations
  
  int a = 3,b = 5,c = 8;
  a += b;               //correct operator(+= instead of =+)
  c -= b;               //correct operator(-= instead of =-)
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;               //correct operator(/= instead of =/)
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


