// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;  // corrected the input operator from "<<" to ">>"
  x = y;
  cout<<"Value of x = " <<x<<endl;  // added a space after "="
  
  int a = 3,b = 5,c = 8;
  a += b;  // corrected the shorthand operator from "=+" to "+="
  c -= b;  // corrected the shorthand operator from "=-" to "-="
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;
  cout<<"\na *= b: "<<a;  // added a newline character at the beginning of the line
  cout<<"\nb /= c: "<<b;  // added a newline character at the beginning of the line
  
  return 0;
}


