// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;
  x=y;
  cout<<"Value of x ="<<x<<endl;
  
  int a=3,b=5,c=8;
  a =a+b;
  c =c-b;
  cout<<"\na+=b:"<<a;
  cout<<"\nc-=b:"<<c;
  
  a*=b;
  b=b/c;
  cout<<"a*=a*b:"<<a;
  cout<<"b=b/c:"<<b;
  
  return 0;
  }


