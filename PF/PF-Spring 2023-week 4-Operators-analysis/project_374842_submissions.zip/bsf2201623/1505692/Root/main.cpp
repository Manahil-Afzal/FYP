// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//insertion operator
  x = y;
  cout<<"enter value of x = "<<x<<endl;//double quotations
  int a=3,b=5,c=8;//space
  a+=b;//+before assignment operator
  c-=b;//-before assignment operator
  cout<<"\n a+=b: ";
  cin>>b;//taking inputs
  cout<<"\n c-=b: ";
  cin>>b;//taking inputs
  a*=b;
  b/=c;// /before assignment operator 
  cout<<"a*=b: ";
  cin>>a;
  cout<<"b/=c: ";
  cin>>b;
  
  
  return 0;
  }


