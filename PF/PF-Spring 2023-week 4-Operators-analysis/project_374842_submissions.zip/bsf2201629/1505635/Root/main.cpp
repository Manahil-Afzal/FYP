// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;       //extraction opreator
  x = y;
  cout<<"Value of x = " <<x<<endl;      //inverted comma
  
  int a = 3,b = 5,c = 8;
  a += b;       //correct operator
  c -= b;       //correct operator
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;       //correct operator
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


