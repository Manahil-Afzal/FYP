// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; //extraction operator is used 
  x = y;
  cout<<"Value of x =" <<x<<endl;// double qoute is not used after assignment operator
  
  int a = 3,b = 5,c = 8;
  a += b;//wromg used of operator
  c -=b;//wrong used of opeartor
  
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /=c;//wrong used of operator
  
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


