/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData() {
        cout << "Title: ";
        cin.ignore();
        getline(cin, title);
        cout << "Price: ";
        cin >> price;
    }

    void putData() {
        cout << "Title: " << title << endl;
        cout << "Price: " << price << endl;
    }
};

int main() {
    Book book1, book2, book3;
    book1.getData();
    book2.getData();
    book3.getData();
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
