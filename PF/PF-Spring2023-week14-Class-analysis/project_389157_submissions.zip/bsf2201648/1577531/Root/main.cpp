/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
    string title;
    float price;
public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << endl;
    cout << "Price: " << price << endl;
}

int main() {
    Book book1, book2, book3;
    book1.getData();
    book2.getData();
    book3.getData();
    cout<<endl;
    cout<<"Entered Books data"<<endl;
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
/*Changes made:

Corrected the class name from book to Book (capitalized first letter is the convention for class names).
Removed the redundant void getdata() declaration inside the class.
Corrected the class name from books to Book in the function definitions.
Added a missing semicolon after the class definition.
Corrected the main function definition from int main() to int main().
Added missing opening and closing braces {} for the main function.*/