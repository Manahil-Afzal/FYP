/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;

class Book {
    string title;
    float price;

public:
    void getData() {
        cout << "Title: ";
        cin.ignore();
        getline(cin, title);
        cout << "Price: ";
        cin >> price;
    }

    void putData() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "Book Details:\n";
    cout << "---------------\n";
    cout << "Book 1:\n";
    book1.putData();

    cout << "Book 2:\n";
    book2.putData();

    cout << "Book 3:\n";
    book3.putData();

    return 0;
}
