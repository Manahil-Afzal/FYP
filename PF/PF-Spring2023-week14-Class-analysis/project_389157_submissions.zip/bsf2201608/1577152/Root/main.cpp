/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string>

using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getdata();
    void putdata();
};

void Book::getdata() {
    cout << "Title: ";
    cin.ignore(); // Ignore the newline character in the input buffer
    getline(cin, title);

    cout << "Price: ";
    cin >> price;
}

void Book::putdata() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getdata();

    cout << "Enter details for Book 2:\n";
    book2.getdata();

    cout << "Enter details for Book 3:\n";
    book3.getdata();

    cout << "Details of Book 1:\n";
    book1.putdata();

    cout << "Details of Book 2:\n";
    book2.putdata();

    cout << "Details of Book 3:\n";
    book3.putdata();

    return 0;
}
