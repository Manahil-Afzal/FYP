/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string> // include string header for using string data type

using namespace std;

class Book // capitalize the class name
{
  string title;
  float price;
public:
  void getdata(); // remove duplicate declaration and make the functions public
  void putdata();
};

void Book::getdata() // use the scope resolution operator to define the functions
{
  cout << "Title:";
  cin >> title;
  cout << "Price:";
  cin >> price;
}

void Book::putdata()
{
  cout << "Title:" << title << "\n";
  cout << "Price:" << price << "\n";
}

int main()
{
  Book book1, book2, book3;
  book1.getdata();
  book2.getdata();
  book3.getdata();
  book1.putdata();
  book2.putdata();
  book3.putdata();

  return 0;
}