/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
string title;
float price ;
public:
void getdata ();
void putdata ();
} ;
void book :: getdata ()// scope resolution operator error
{
cout<<"Title:";//inverted comma error
cin>>title;
cout<<"Price:";// inverted comma error
cin>>price;
 
}
void book :: putdata ()// scope resolution operator error
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";// inverted comma error
}
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;
return 0;
}
