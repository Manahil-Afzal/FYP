/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
    string title;
    float price;
public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore();
    getline(cin, title);
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << endl;
    cout << "Price: " << price << endl;
}

int main() {
    Book book1, book2, book3;

    cout << "Enter data for Book 1:" << endl;
    book1.getData();

    cout << "Enter data for Book 2:" << endl;
    book2.getData();

    cout << "Enter data for Book 3:" << endl;
    book3.getData();

    cout << "Data for Book 1:" << endl;
    book1.putData();

    cout << "Data for Book 2:" << endl;
    book2.putData();

    cout << "Data for Book 3:" << endl;
    book3.putData();

    return 0;
}
