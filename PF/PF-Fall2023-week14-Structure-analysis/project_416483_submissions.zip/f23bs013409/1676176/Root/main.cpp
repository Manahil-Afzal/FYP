// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
};
 Distance d1, d2, sumOfDistances;  //Correct Variable Decleration

int main() {
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: "; //Wrong Usage of round braces
    cin>>d1.feet;  //input for d1
    cout<<"Enter inch: ";
    cin>>d1.inch;  //input for d1 
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet;  //input for d2
    cout<<"Enter inch: ";
    cin>>d2.inch;   //input for d2

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = "; //wrong quotation mark
cout<<sumOfDistances.feet, sumOfDistances.inch;
    return 0;
}


