// Identify and correct errors.
#include <iostream>
using namespace std;

struct Distance {
    int feet;
    float inch;
};

int main() {
    Distance d1, d2, sumOfDistances; // Corrected the struct variables declaration

    cout << "Enter information for 1st distance\n";
    cout << "Enter feet: ";
    cin >> d1.feet; // Corrected the variable name
    cout << "Enter inch: ";
    cin >> d1.inch;

    cout << "\nEnter information for 2nd distance\n";
    cout << "Enter feet: ";
    cin >> d2.feet;
    cout << "Enter inch: ";
    cin >> d2.inch;

    sumOfDistances.feet = d1.feet + d2.feet;
    sumOfDistances.inch = d1.inch + d2.inch;

    if (sumOfDistances.inch >= 12.0) { // Changed '>' to '>=' for a more accurate condition
        sumOfDistances.inch = sumOfDistances.inch - 12.0;
        ++sumOfDistances.feet;
    }

    cout << "\nSum of distances = " << sumOfDistances.feet << " feet, " << sumOfDistances.inch << " inches"; // Corrected the output format
    return 0;
}

