// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {               //use wrong syntax of structure
    int feet;
    float inch;
} d1, d2, sumOfDistances;

int main() {
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: ";                               //inexpected )
    cin>>d1.feet;
    cout<<"Enter inch: ";
    cin>>d1.inch;
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet;                                           //un necessory use of pointer
    cout<<"Enter inch: ";
    cin>>d2.inch;

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances =";
cout<<sumOfDistances.feet<<endl<< sumOfDistances.inch;
    return 0;
}


