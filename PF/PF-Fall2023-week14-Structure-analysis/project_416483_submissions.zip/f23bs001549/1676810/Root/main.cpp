// Identify and correct errors.

#include <iostream>
using namespace std;
struct Distance {
    int feet;
    float inch;
};
int main() {
    Distance d1, d2, sumOfDistances; // Declare variables inside main
    cout << "Enter information for 1st distance\n";
    cout << "Enter feet: ";
    cin >> d1.feet; // Use d1.feet instead of feet
    cout << "Enter inch: ";
    cin >> d1.inch;
    cout << "\nEnter information for 2nd distance\n";
    cout << "Enter feet: ";
    cin >> d2.feet; // Use d2.feet instead of d2->feet
    cout << "Enter inch: ";
    cin >> d2.inch;
    sumOfDistances.feet = d1.feet + d2.feet;
    sumOfDistances.inch = d1.inch + d2.inch;
    if (sumOfDistances.inch > 12.0) {
        sumOfDistances.inch = sumOfDistances.inch - 12.0;
        ++sumOfDistances.feet;
    }
    cout << "\nSum of distances = " << sumOfDistances.feet << " feet, " << sumOfDistances.inch << " inches\n";
    return 0;
}