// Identify and correct errors.
#include <iostream>
using namespace std;
struct Distance
{ int feet;
 float inch; }d1, d2, sumOfDistances;
int main()
{ 
int inch,feet;
cout<<"Enter information for 1st distance\n";
 cout<<"Enter feet: ";
 cin>>feet;
 cout<<"Enter inch: ";
 cin>>inch;
 cout<<"\nEnter information for 2nd distance\n";
 cout<<"Enter feet: ";
 cin>>feet;
 cout<<"Enter inch: ";
 cin>>inch;
 sumOfDistances.feet=d1.feet+d2.feet;
 sumOfDistances.inch=d1.inch+d2.inch;
 if (sumOfDistances.inch>12.0) {
 sumOfDistances.inch = sumOfDistances.inch-12.0;
 ++sumOfDistances.feet; }
 cout<<"\nSum of distances = ";
cout<<sumOfDistances.feet, sumOfDistances.inch;
 return 0; }
