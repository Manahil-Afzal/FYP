// Identify and correct errors.

///*Write a program that defines a structure to store BookId, Price and Pages of a book. 
//It declares two structure variables and input values displays the record of the more costly book.*/
//#include<iostream>
//using namespace std;
//
//struct book {
//  	int bookid;
//  	int price;
//  	int book_pages;
//};
//int main(){
//
//
//book book1,book2;
//cout<<"Enter The book Id"<<endl;
//cin>>book1.bookid;
//cout<<"Enter The book price"<<endl;
//cin>>book1.price;
//cout<<"Enter The book pages"<<endl;
//cin>>book1.book_pages;
//cout<<"Enter The second Book Data"<<endl;
//cout<<"Enter The book Id"<<endl;
//cin>>book2.bookid;
//cout<<"Enter The book price"<<endl;
//cin>>book2.price;
//cout<<"Enter The book pages"<<endl;
//cin>>book2.book_pages;
//if(book2.price>book1.price){
//
//cout<<"The book id is "<<book2.bookid<<endl;
//cout<<"The book price is "<<book2.price<<endl;
//cout<<"The book pages  is "<<book2.book_pages<<endl;}
//else {
//
//cout<<"The book id is "<<book1.bookid<<endl;
//cout<<"The book price is "<<book1.price<<endl;
//cout<<"The book pages  is "<<book1.book_pages<<endl;}
//}
// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
}; 

int main() {
Distance 	d1, d2, sumOfDistances;
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: ";
    cin>>d1.feet;
    cout<<"Enter inch: ";
    cin>>d1.inch;
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet;
    cout<<"Enter inch: ";
    cin>>d2.inch;

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
    }
        cout<<"\nSum of distances = ";
cout<<sumOfDistances.feet<< sumOfDistances.inch;
    return 0;
}





