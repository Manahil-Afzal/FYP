// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
} d1, d2, sumOfDistances;//remove semicolon after curly brakets of structure

int main() {
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: ";
    cin>>d1.feet;// enter d1.feet instead of feet
    cout<<"Enter inch: ";
    cin>>d1.inch;// enter d1.inch instead of feet
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet;//remove paranthesis after d2.feet
    cout<<"Enter inch: ";
    cin>>d2.inch;

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = ";
cout<<sumOfDistances.feet, sumOfDistances.inch;
    return 0;
}


