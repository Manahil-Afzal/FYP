// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
} d1, d2, sumOfDistances;//remove seicolon after curly braces

int main() {
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: ";//remove parenthesis
    cin>>d1.feet;//use d1.feet instead of feet;
    cout<<"Enter inch: ";
    cin>>d1.inch;//use d1.inch instead of inch
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet;//use d2.feet instead of d2->feet and remove parenthesis.
    cout<<"Enter inch: ";
    cin>>d2.inch;//use d2.inch instead of d2->inch.

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = ";//use double coats ""
cout<<sumOfDistances.feet, sumOfDistances.inch;
    return 0;
}


