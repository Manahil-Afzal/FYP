// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;  
} d1, d2, sumOfDistances; //variables were declared outside the strucutre

int main() {

    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: ";  //) was used that was an error
    cin>>d1.feet; //accessing elements of structure was wrong
    cout<<"Enter inch: ";
    cin>>d1.inch; //accessing elements of structure was wrong
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet;  //-> was used which is used to access a pointer member of structure
    cout<<"Enter inch: ";
    cin>>d2.inch;  //-> was used which is used to access a pointer member of structure

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = "; //missing terminating " character
cout<<sumOfDistances.feet<<"."<<sumOfDistances.inch; // here i have displayed . to increase readability
    return 0;
}
