// Identify and correct errors.

#include <iostream>
using namespace std;

struct SumOfDistances
 {
    int feet;
    float inch;
}; 

int main() {
     SumOfDistances d1, d2,sum;
    cout<<"Enter information for 1st distance"<<endl;
    cout<<"Enter feet: ";
    cin>>d1.feet;
    cout<<"Enter inch: ";
    cin>>d1.inch;
    cout<<"Enter information for 2nd distance"<<endl;
    cout<<"Enter feet: ";
    cin>>d2.feet;
    cout<<"Enter inch: ";
    cin>>d2.inch;

    sum.feet=d1.feet + d2.feet;
    sum.inch=d1.inch + d2.inch;
   
    if (sum.inch>=12.0) {
        
        sum.inch -= 12.0;
        ++sum.feet;
    }else{
       
 cout<<"Sum of distances = "<<endl;
cout<<sum.feet<<sum.inch;
}

}


