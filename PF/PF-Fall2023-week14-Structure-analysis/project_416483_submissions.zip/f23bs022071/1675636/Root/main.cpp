// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
} d1, d2, sumOfDistances; //extra semicolon was used

int main() {
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: "; //bracket was removed
    cin>>d1.feet;
    cout<<"Enter inch: ";
    cin>>d1.inch;
    cout<<"Enter information for 2nd distance:\n"; //exta \n is removed
    cout<<"Enter feet: ";
    cin>>d2.feet; //exact pointers are used and extra bracket is removed
    cout<<"Enter inch: ";
    cin>>d2.inch; //exact pointers are used

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"Sum of distances = "; //Quotation is corrected and /n is removed
cout<<sumOfDistances.feet+ sumOfDistances.inch; //comma is replaced with +
    return 0;
}


