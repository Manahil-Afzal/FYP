/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;
int main()
{
int totalAmount=30000 ,option,withdraw,deposit;

cout<<"What you want to do withdraw or deposit :"<<endl;
cout<<"If you want to do withdraw then enter 1 and if you want to do deposit then 2 :"<<endl;
cout<<"if you want to cancel then enter 0 :"<<endl;
cin>>option;
if(option==1)
{
    cout<<"Welcome to your withdraw section :"<<endl;
    cout<<"how much amount you want to withdraw :"<<endl;
    cin>>withdraw;
    int current=totalAmount-withdraw;
   cout<<"Your current amount is :"<<current;
     
}
if(option==2)
{
    cout<<"Welcome to your deposit section :"<<endl;
    cout<<"how much amount you want to deposit :"<<endl;
    cin>>deposit;
    int current=totalAmount+deposit;
   cout<<"Your current amount is :"<<current;
     
}

}