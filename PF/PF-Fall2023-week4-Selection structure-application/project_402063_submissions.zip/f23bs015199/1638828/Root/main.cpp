/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;

int main() {
    double balance = 10000.0;  // Initial account balance
    double amount;           // Amount to deposit or withdraw
    char transactionType;    // 'D' for deposit, 'W' for withdrawal

    cout << "Welcome to the Bank!" << endl;
    cout << "Your current balance is: Pkr" << balance << endl;

    cout << "Enter 'D' for deposit or 'W' for withdrawal: ";
    cin >> transactionType;

    if (transactionType == 'D' || transactionType == 'd') {
        cout << "Enter the amount to deposit: Pkr";
        cin >> amount;
        if (amount > 0) {
            balance += amount;
            cout << "Deposit successful!" << endl;
        } else {
            cout << "Invalid deposit amount. Transaction canceled." << endl;
        }
    } else if (transactionType == 'W' || transactionType == 'w') {
        cout << "Enter the amount to withdraw: Pkr";
        cin >> amount;
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawal successful!" << endl;
        } else {
            cout << "Invalid withdrawal amount or insufficient balance. Transaction canceled." << endl;
        }
    } else {
        cout << "Invalid transaction type. Transaction canceled." << endl;
    }

    cout << "Your updated balance is: Pkr" << balance << endl;

    return 0;
}
