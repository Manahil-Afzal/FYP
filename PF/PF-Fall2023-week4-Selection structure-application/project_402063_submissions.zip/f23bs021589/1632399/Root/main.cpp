/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int Balance=15000;
    int Amount;
    int Remaining_Balance;
    int n;
    cout<<"do you want to deposit withdraw:";
    cin>>n;
    if(n==1)
    {
    cout<<"Enter The Amount:";
    cin>>Amount;
    Remaining_Balance=Balance -Amount;
    cout<<"Your Remaining Balance is="<<Remaining_Balance;}
    else if (n==2)
    {
        cout<<" Enter The Amount:";
        cin>>Amount;
        Remaining_Balance=Balance+Amount;
        cout<< "Your Remaining Balance is="<<Remaining_Balance;}
    }