
#include <iostream>

using namespace std;

class BankAccount {
private:
    double balance;

public:
    BankAccount(double initialBalance) {
        balance = initialBalance;
    }

    double getBalance() {
        return balance;
    }

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposit successful. Updated balance: $" << balance << endl;
        } else {
            cout << "Invalid deposit amount. Amount must be greater than 0." << endl;
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawal successful. Updated balance: $" << balance << endl;
        } else if (amount <= 0) {
            cout << "Invalid withdrawal amount. Amount must be greater than 0." << endl;
        } else {
            cout << "Insufficient balance. Withdrawal not allowed." << endl;
        }
    }
};

int main() {
    double initialBalance;
    cout << "Enter initial balance: $";
    cin >> initialBalance;

    BankAccount account(initialBalance);

    while (true) {
        cout << "Choose an option:" << endl;
        cout << "1. Deposit" << endl;
        cout << "2. Withdraw" << endl;
        cout << "3. Check Balance" << endl;
        cout << "4. Exit" << endl;

        int choice;
        cin >> choice;

        switch (choice) {
            case 1:
                double depositAmount;
                cout << "Enter the deposit amount: $";
                cin >> depositAmount;
                account.deposit(depositAmount);
                break;
            case 2:
                double withdrawAmount;
                cout << "Enter the withdrawal amount: $";
                cin >> withdrawAmount;
                account.withdraw(withdrawAmount);
                break;
            case 3:
                cout << "Current balance: $" << account.getBalance() << endl;
                break;
            case 4:
                cout << "Exiting program." << endl;
                return 0;
            default:
                cout << "Invalid choice. Please select a valid option." << endl;
        }
    }

    return 0;
}