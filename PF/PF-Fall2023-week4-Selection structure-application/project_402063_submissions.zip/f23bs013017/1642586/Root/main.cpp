
#include <iostream>

int main() {
    double balance = 0.0;
    char transactionType;
    double amount;

    // Get the initial balance from the user
    std::cout << "Enter the initial balance: $";
    std::cin >> balance;

    // Ask the user for the transaction type (W for Withdraw, D for Deposit)
    std::cout << "Enter transaction type (W for Withdraw, D for Deposit): ";
    std::cin >> transactionType;

    // Ask the user for the transaction amount
    std::cout << "Enter the transaction amount: $";
    std::cin >> amount;

    // Perform the transaction and update the balance
    if (transactionType == 'W' || transactionType == 'w') {
        // Withdraw
        if (amount <= balance) {
            balance -= amount;
            std::cout << "Withdrawal successful. Updated balance: $" << balance << std::endl;
        } else {
            std::cout << "Insufficient funds. Transaction failed." << std::endl;
        }
    } else if (transactionType == 'D' || transactionType == 'd') {
        // Deposit
        balance += amount;
        std::cout << "Deposit successful. Updated balance: $" << balance << std::endl;
    } else {
        std::cout << "Invalid transaction type. Please enter 'W' for Withdraw or 'D' for Deposit." << std::endl;
    }

    return 0;
}