/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account.
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays
the current balance after performing the transaction user wants to perform on the Bank’s account.*/

#include <iostream>
using namespace std;

const long CURRENT_BALANCE = 5000;

int main()
{
    long current_balance = CURRENT_BALANCE;
    int option;
    cout << "Do you want to Deposit or Withdraw money!\n";
    cout << "Press 1 for Deposit\n";
    cout << "Press 2 for Withdraw\n";
    cin >> option;
    long amount;

    switch (option)
    {
    // Case 1 is for deposit
    case 1:
        cout << "Enter the amount you want to Deposit: \n";
        cin >> amount;
        // Error Checking
        if (amount > 0)
        {
            current_balance = current_balance + amount;
            cout << "Your amount " << amount << " has been successfully Deposit\n";
        }
        else
        {
            cout << "Invalid input!\n";
        }
        break;
    // Case 2 is for withdraw
    case 2:
        cout << "Enter the value you want to withdraw: \n";
        cin >> amount;
        // Error checking
        if (amount < 1)
        {
            cout << "Invalid input!\n";
        }
        else
        {
            if (current_balance >= amount)
            {
                current_balance = current_balance - amount;
                cout << "You have successfully withdraw an amount of " << amount << endl;
            }
            else
            {
                cout << "Your account has insufficient balance!\n";
            }
        }
        break;
    default:
        cout << "Enter the valid input 1 or 2\n";
        break;
    }
    cout << "New Balance is " << current_balance << endl;

    return 0;
}