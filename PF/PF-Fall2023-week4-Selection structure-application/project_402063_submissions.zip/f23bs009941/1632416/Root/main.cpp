/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
long totalbalance,withdraw,deposit,x,currentbalance;
totalbalance=100000;
cout<<"your total balance is:100000"<<endl;
cout<<"enter 1 to withdraw and 2 to deposit"<<endl;
cin>>x;
if(x==1)
{
cout<<"enter the amount you want to withdraw:";
cin>>withdraw;
if(withdraw>100000)
cout<<"invalid value";
currentbalance=totalbalance-withdraw;
cout<<"your current balance is:"<<currentbalance<<endl;
}
else if(x==2)
{
cout<<"enter amount you want to deposit:";
cin>>deposit;
currentbalance=totalbalance+deposit;
cout<<"your current balance is:"<<currentbalance<<endl;

}
return 0;
}



