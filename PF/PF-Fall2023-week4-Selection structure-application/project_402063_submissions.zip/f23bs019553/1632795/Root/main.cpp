/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;

main()
{
    long current_balance = 10000;
    char transection_option; 
    cout<<"Do you want to withdraw or deposit? "<<endl;
    cout<<"Press w for withdraw and d for deposit";
    cin>> transection_option;
    if (transection_option == 'w' or transection_option == 'W')
    {
        long amount;
        cout<<"Enter the amount you want to withdraw: ";
        cin>>amount;
        if (current_balance < amount) {
            cout<<"Your current balance is less then th amount you want to witdraw. ";
        }
        else{
            long new_balance = current_balance - amount;
              cout<<"Amount "  
              << amount << "Successfully withdraw ";
              cout<<"Current Balance: "<<new_balance;
        }
      
    }
    else if ( transection_option == 'd' or transection_option == 'D')
    {
        long amount;
        cout<<"Enter the amount you want to deposit: ";
        cin>>amount;
        if (amount <= 0)
        {
            cout<<"Amount must be greater then 0";
        }
        else{
            cout<<"Successfully Depost amount"<<amount;
        cout<<"Current Balance is: "<<amount + current_balance;
        }
        
        
        
    }
    
    else {
         cout<<"Invalid input!";
    }
}