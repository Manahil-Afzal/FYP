/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main(){
 int existing_balance=50000;
 int amount_entered;
 int new_balance;
 char choice;
 cout<<"Enter amount you want to withdraw or deposit:";
 cin>>amount_entered;
 cout<<"Enter W to withdraw or D for deposit:";
 cin>>choice;
 if(choice=='W'){
 	new_balance=existing_balance - amount_entered;
 	cout<<"you withdrew "<<amount_entered<<" and your new balance is "<<new_balance;
 	}else if(choice=='D'){
 		new_balance=existing_balance + amount_entered;
 		cout<<"you deposited"<<amount_entered<<"and your  new balance is "<<new_balance;
	 }else{
	 	cout<<"Inappropriate choice";
	 } 
}
