/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;
int main()
{
    int totalAmount=30000,option,withdraw,deposit;
    
    
    
    cout<<"What you want to do withdraw or deposit :"<<endl;
    cout<<"Enter any of option 1 or 2 "<<endl;
    cout<<"Or if you want to cancel then enter 0 :"<<endl;
    
    cin>>option;
    if(option==1)
    {
        
        cout<<"Welcome to withdraw section :"<<endl;
        
        cout<<"How much amounts you want to withdraw : "<<endl;
        cin>>withdraw;
        int remainingBalance=totalAmount-withdraw;
        cout<<"Your current balace is :"<<remainingBalance;
        
        
    }
    else if(option==2)
    {
        
        cout<<"Welcome to deposit section :"<<endl;
        
        cout<<"How much amounts you want to deposit : "<<endl;
        cin>>deposit;
        int remainingBalance=totalAmount+deposit;
        cout<<"Your current balace is :"<<remainingBalance;
          
    }
    else if(option==0)
    {
        cout<<"Thanks for chosing us :";
    }
    else
    {
        cout<<"You enter invalid option :";
    }
    
}