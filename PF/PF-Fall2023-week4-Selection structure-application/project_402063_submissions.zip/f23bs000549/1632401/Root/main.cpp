/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
	int total_amount;
	int amount;
	int remaining_amount;
	cout<<"Enter your Total amount of your account"<<endl;
	cin>>total_amount;
	cout<<"Enter amount you want to withdraw/deposit"<<endl;
	cin>>amount;
	if (amount > total_amount) 
	{
        cout << "Error: Insufficient balance." << endl;
    } 
	else 
	{
        remaining_amount = total_amount - amount;
        cout << "Your Current balance in your account is: " << remaining_amount << endl;
    }		
	
}