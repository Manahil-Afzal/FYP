/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;

int main() {
    float balance, amount;
    int choice;

    cout << "Enter initial balance: ";
    cin >> balance;

    cout << "Enter 1 to deposit, 2 to withdraw: ";
    cin >> choice;

    cout << "Enter amount: ";
    cin >> amount;

    if (choice == 1) {
        balance += amount;
        cout << "Amount deposited. Current balance is " << balance << endl;
    } else if (choice == 2) {
        if (amount > balance) {
            cout << "Insufficient funds." << endl;
        } else {
            balance -= amount;
            cout << "Amount withdrawn. Current balance is " << balance << endl;
        }
    } else {
        cout << "Invalid choice." << endl;
    }

    return 0;
}
