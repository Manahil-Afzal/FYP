/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int Balance=15000;
    int Amount;
    int Remaining_Balance;
    int n;
    cout<<"your Balance ="<<Balance<<endl;
    cout<<"Do you want to deposit or Withdraw?"<<endl;
    cout<<"Enter 1 to withdraw and 2 to deposit:";
    cin>>n;
    
    if (n==1)
    {
    cout<<"Enter The Amount you want to Withdraw:";
    cin>>Amount;
   {
	 if (Amount<=15000)
    {
	Remaining_Balance= Balance-Amount;
    cout<<"Congratulation Withdrawal Successful....."<<endl;
    cout<<"Your remaining Balance is="<<Remaining_Balance<<endl;
    cout<<"confirmation message has been sent to your mobile phone......";}
	else  
	{
	cout<<"insuffuicent balance......."<<endl;
	cout<<"Enter Valid Amount.......";}
}
}
    else if(n==2)
    
    {
    cout<<"Enter The Amount you want to deposit:";
    cin>>Amount;
    Remaining_Balance= Balance+Amount;
    cout<<"Congratulation Deposition Successful....."<<endl;
    cout<<"Your remaining Balance is="<<Remaining_Balance<<endl;

    cout<<"confirmation message has been sent to your mobile phone......"<<endl;
    }
    
}