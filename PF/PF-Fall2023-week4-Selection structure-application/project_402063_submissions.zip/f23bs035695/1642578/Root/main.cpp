/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>

class BankAccount {
private:
    double balance;

public:
    BankAccount(double initialBalance) {
        balance = initialBalance;
    }

    void deposit(double amount) {
        balance += amount;
    }

    void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
        } else {
            std::cout << "Insufficient balance to withdraw $" << amount << std::endl;
        }
    }

    double getBalance() {
        return balance;
    }
};

int main() {
    double initialBalance;
    std::cout << "Enter the initial balance of your bank account: $";
    std::cin >> initialBalance;

    BankAccount account(initialBalance);

    int choice;
    double amount;

    do {
        std::cout << "\nChoose an option:\n";
        std::cout << "1. Deposit\n";
        std::cout << "2. Withdraw\n";
        std::cout << "3. Check Balance\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter the amount to deposit: $";
                std::cin >> amount;
                account.deposit(amount);
                break;
            case 2:
                std::cout << "Enter the amount to withdraw: $";
                std::cin >> amount;
                account.withdraw(amount);
                break;
            case 3:
                std::cout << "Current balance: $" << account.getBalance() << std::endl;
                break;
            case 4:
                std::cout << "Exiting the program. Thank you!\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }

    } while (choice != 4);

    return 0;
}
