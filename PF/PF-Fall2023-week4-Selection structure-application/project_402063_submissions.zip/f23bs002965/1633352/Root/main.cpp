/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main(){
    int current_balance= 10000;
    char transaction;
    
    cout<<"Do you want to withdraw money,then press w:"<<endl;
    cout<<"Do you want to deposit money,then press d:"<<endl;
    cout<<"Press:";
        cin>>transaction;
    if(transaction=='w' || transaction=='W'){
        int amount;
        cout<<"Enter the amount you want to withdraw:";
        cin>>amount;
        if(amount<=current_balance){
            cout<<"You withdraw money Successfuly👍"<<endl;
            current_balance-=amount;
            cout<<"New balance:"<<current_balance;
        }else{
            cout<<"Your balance is less than the amount you want to withdraw!";
        }
        
    }
    else if(transaction=='d' || transaction=='D'){
        int amount;
        cout<<"Enter the amount you want to deposit:";
        cin>>amount;   
     if(amount>0){
         current_balance+=amount;
          cout<<"You deposit money Successfuly👍"<<endl;
          cout<<"New balance:"<<current_balance;
          }else{
          cout<<"Invalid deposit amount. You cannot deposit negative amount                                                                                               ";
    }  }
}