/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
	# include<iostream>
	using namespace std;
	int main()
	{
	double amount=10000.0;
	int option,withdraw,deposit,balance;
	cout<<"what you want to do withdraw or deposit:"<<endl;
	cout<<"enter option 1 for withdraw or2 for deposit:"<<endl;
	cout<<"or if want to cancel then enter 0:"<<endl;
	cin>>option;
	if(option==1)
	{
		cout<<"welcome to withdraw selection:"<<endl;
		cout<<"how much amount you want to withdraw:"<<endl;
		cin>>withdraw;
		int  balance = amount-withdraw;
		cout<<"you remaining balance is:  "<< balance;
	}
	else if(option==2)
	{
		cout<<"welcome to deposit selection:"<<endl;
		cout<<"how much amount you want to deposit:"<<endl;
		cin>>deposit;
		int balance = amount+deposit;
		cout<<"you current balance is:  "<< balance;	
	}
	else
	{
		cout<<"thanks for choosing us:";
	}
	
}