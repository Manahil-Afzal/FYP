/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main(){
 int ExistingBalance=50000;
 int AmountEntered;
 int CurrentBalance;
 char choice;
 cout<<"Enter amount you want to withdraw or deposit:";
 cin>>AmountEntered;
 cout<<"Enter W to withdraw or D for deposit:";
 cin>>choice;
 if(choice=='W'){
 	CurrentBalance=ExistingBalance - AmountEntered;
 	cout<<"you withdrew "<<AmountEntered<<" and your new balance is "<<CurrentBalance;
 	}else if(choice=='D'){
 		CurrentBalance=ExistingBalance + AmountEntered;
 		cout<<"you deposited"<<AmountEntered<<"and your  new balance is "<<CurrentBalance;
	 }else{
	 	cout<<"Inappropriate choice";
	 } 
}
