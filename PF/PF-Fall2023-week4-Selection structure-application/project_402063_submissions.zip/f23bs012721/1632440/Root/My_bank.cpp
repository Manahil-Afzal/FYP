/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing  thetransaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;
main ()
{
    int totalAmount = 20000,option,withdraw,deposit;
     cout << "What you want to do withdraw or deposit:"<<endl;
     cout << "Enter any one of the given option 1 or 2 :" <<endl;
     cout << "Or if you want to cancel then enter 0: " << endl;
     cin>> option;
     
     if(option ==1)
     {
         cout << "Welcome to withdraw section :" <<endl;
         cout << "How much amount  you want to withdraw:" <<endl;
         cin  >> withdraw;
         int remaingBalance = totalAmount - withdraw ;
         cout << "Your remaing balance is:" << remaingBalance;
         
     }
     else if(option == 2)
     {
         cout <<"Welcome to deposit section :" <<endl;
         cout << "How much amount  you want to deposit :"<< endl;
         cin>>deposit;
         int newBalance = totalAmount + deposit ;
         cout << "Your new balance is :" <<newBalance ;
         
         }

     else if(option == 0)
     {
        
         cout << "Your amount has been canceled " ;
         
         
         
     }
     else 
     {
         cout << "You have entered invalid section :" ;
         cout << "Opps something went wrong" ;
     }
}