/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
	double balance=100000,withdrawl_amount,deposit_amount;
	int transaction_type;
	cout<<"available balance is:Rs."<<balance<<endl;
	cout<<"enter trnsansantion type(1 for withdrawl, 2 for deposit):";
	cin>>transaction_type;
	if(transaction_type==1)
	{
		cout<<"enter withdrawl amount:";
		cin>>withdrawl_amount;
		if(withdrawl_amount>balance)
	{	
		cout<<"insuficient funds! widthdrawl is not completed."<<endl;
    }
		else
	{
		balance-=withdrawl_amount;
		cout<<"withdrawl successful.\nnew balance is:Rs."<<balance<<endl;
	}
    }
	else if(transaction_type==2)
	{
		cout<<"enter deposit amount:";
		cin>>deposit_amount;
		balance+=deposit_amount;
		cout<<"deposit sucessful!\nnew balance is:Rs."<<balance<<endl;
	}
	else
	{
		cout<<"please enter valid transaction type 1 for withdrawl and 2 for deposit";
	}
	return 0;
}