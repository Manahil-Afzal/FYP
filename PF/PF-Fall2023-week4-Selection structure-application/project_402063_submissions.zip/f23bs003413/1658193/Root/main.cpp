/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main(){
    cout<<"Your current balance is 20000 Rupee"<<endl;
 int current_balance=20000;
 int amount_enter;
 int new_balance;
 char option;
 cout<<"Enter amount you want to withdraw or deposit:";
 cin>>amount_enter;
 cout<<"Enter W to withdraw or D for deposit:";
 cin>>option;
 if(option=='W'){
 	new_balance=current_balance - amount_enter;
 	cout<<"Your new balance is "<<new_balance;
 	}else if(option=='D'){
 		new_balance=current_balance + amount_enter;
 		cout<<"Your  new balance is "<<new_balance;
	 }else{
	 	cout<<"Wrong choice ";
	 } 
}