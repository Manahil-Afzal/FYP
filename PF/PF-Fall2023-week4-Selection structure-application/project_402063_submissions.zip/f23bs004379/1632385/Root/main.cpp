/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int balance=10000;
    int current_bal;
    int transaction;
    cout<<"enter the transaction amount";
    cin>>transaction;
    bool choice;
    cout<<"press 1 for withdraw or press 0 for deposit";
    cin>>choice;
    if(choice==1)
    {
        current_bal=balance-transaction;
        cout<<"The current balance is"<<current_bal<<endl;
        
    }
    else if(choice==0)
    {
        current_bal=balance+transaction;
        cout<<"the current balance is"<<current_bal<<endl;
    }
    else 
    cout<<"invalid num";
}