/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int existing_balance = 40000;
    int choice,withdraw, deposit,new_balance;
    cout<<"Please Press '0' for withdraw and '1'for deposit"<<endl;;
    cin>>choice;
    switch (choice) {
        case 0:
        cout<<"Please enter the amout you want to withdraw"<<endl;
        cin>>withdraw;
        new_balance = existing_balance - withdraw;
        cout<<"New balnace is: "<<new_balance;
        break;
        case 1:
        cout<<"Please enter the amout you want to deposit"<<endl;
        cin>>deposit;
        new_balance = existing_balance + deposit;
        cout<<"Your new balance is: "<<new_balance;
        break;
        default:
        cout<<"Pressed Wrong Key"<<endl;;
    }
}