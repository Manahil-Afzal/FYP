/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main ()
{
    int a ;
    long balance, withdraw, deposit;
    balance=100000;
    cout<<"your current balance is 100000."<<endl;
    cout<<"Enter 1 if you want to withdraw or enter 2 if you  want to deposit:"<<endl;
    cin>>a;
    if(a==1)
    {
        cout<<"enter the amount you want to withdraw:"<<endl;
        cin>>withdraw;
        if(withdraw>100000)
        cout<<"inappropriate message."<<endl;
        else
        balance=100000-withdraw;
        cout<<"your current balance is:"<<balance;
    }
    else if(a==2)
    {
        cout<<"Enter the amount you want to deposit:"<<endl;
        cin>>deposit;
        balance=100000+deposit;
        cout<<"your current balance is:"<<balance;
    }
else 
cout<<"inappropriate message.";
return 0;
}