/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main() 
{
    int a;
    long withdraw_amount,deposit_amount,current_balance;
    int total_amount=100000;
    cout<<"your total_amount is 100000.";
    cout<<"\n enter 1 if you want to  withdraw and enter 2 if you want to deposit :";
    cin>>a;
  if (a==2)
  {
      cout<<"enter deposit_amount";
      cin>>deposit_amount;
      current_balance=total_amount+deposit_amount;
      cout<<"your current_balance is"<<current_balance ;
 }
  else if (a==1)
  {
    {  cout<<"enter withdraw_amount";
      cin>>withdraw_amount;
      current_balance=total_amount-withdraw_amount;
      cout<<"your current_balance is"<<current_balance;
     
  }
     if  (withdraw_amount>100000)
      {
          cout<<"\n inappropirate value" ;
  }
  }
  }