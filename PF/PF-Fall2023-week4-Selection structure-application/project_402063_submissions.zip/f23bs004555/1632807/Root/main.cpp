#include<iostream>
using namespace std;
int main()
{
   long withdraw, deposit, balance;
   int number;
   balance=10000;
   cout<<"Your current balance is 10000."<<endl;
   cout<<"Enter number 1 if you want to withdraw and enter number 2 if you want to depodit."<<endl;
   cin>>number;
   if(number==1)
   {
   	cout<<"Enter the amount you want to withdraw:"<<endl;
	cin>>withdraw;
	if(withdraw>10000)
	cout<<"Inapprppriate message."<<endl;
	else
	balance=10000-withdraw;
	cout<<"Your current balance is:"<<balance;
	}
    else if(number==2)
	{
	cout<<"Enter the amount you want to deposit:"<<endl;
	cin>>deposit;
	balance=10000+deposit;
	cout<<"Your current balance is:"<<balance;
   } 
   else
   cout<<"Inappropriate value.";
}/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/