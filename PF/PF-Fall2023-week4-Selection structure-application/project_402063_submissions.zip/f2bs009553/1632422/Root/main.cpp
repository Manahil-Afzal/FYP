/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int deposit;
    int n_balance;
    int withdraw;
    int a;
    int remaining;
    cout<<"Welcome back dear Customer!";
    cout<<"\nyour current balance is= 6000\n";
    cout<<"\nto deposit money press 1 or for withdraw press 2\n";
    cin>>a;
    if(a==1)
   {
    cout<<"The amount you want to deposit=";
    cin>>deposit;
    n_balance=6000+deposit;
    cout<<"your new balance="<<n_balance;
  }
  else if(a==2)
  {
      cout<<"the amount you want to withdraw";
      cin>>withdraw;
      remaining=6000-withdraw;
      cout<<"The remaining amount="<<remaining;
      
  }
    return 0;
}