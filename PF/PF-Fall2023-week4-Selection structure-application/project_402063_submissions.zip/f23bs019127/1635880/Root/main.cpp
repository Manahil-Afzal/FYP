





/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/

#include <iostream>

using namespace std;

class BankAccount {
private:
    double balance;

public:
    BankAccount(double initialBalance) : balance(initialBalance) {}

    void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "Deposit successful. New balance: $" << balance << endl;
        } else {
            cout << "Invalid deposit amount. Please enter a positive value." << endl;
        }
    }

    void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "Withdrawal successful. New balance: $" << balance << endl;
        } else if (amount <= 0) {
            cout << "Invalid withdrawal amount. Please enter a positive value." << endl;
        } else {
            cout << "Insufficient funds. Withdrawal failed." << endl;
        }
    }

    double getBalance() const {
        return balance;
    }
};

int main() {
    double initialBalance;
    cout << "Enter initial account balance: $";
    cin >> initialBalance;

    BankAccount account(initialBalance);

    int choice;
    double amount;

    do {
        cout << "\nChoose a transaction type:" << endl;
        cout << "1. Deposit" << endl;
        cout << "2. Withdraw" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter the deposit amount: $";
                cin >> amount;
                account.deposit(amount);
                break;

            case 2:
                cout << "Enter the withdrawal amount: $";
                cin >> amount;
                account.withdraw(amount);
                break;

            case 3:
                cout << "Exiting program. Final balance: $" << account.getBalance() << endl;
                break;

            default:
                cout << "Invalid choice. Please select a valid option." << endl;
                break;
        }
    } while (choice != 3);

    return 0;
}
