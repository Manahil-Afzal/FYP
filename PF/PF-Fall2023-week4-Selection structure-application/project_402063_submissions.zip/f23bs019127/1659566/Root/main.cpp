/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>

using namespace std;

int main() {
    double balance = 1000.0; // Initial balance of the bank account

    cout << "Welcome to the Bank Account Transaction System" << endl;
    cout << "Your current balance is: $" << balance << endl;

    char transactionType;
    double amount;

    cout << "Enter 'W' to withdraw or 'D' to deposit: ";
    cin >> transactionType;

    if (transactionType == 'W' || transactionType == 'w') {
        cout << "Enter the amount you want to withdraw: $";
        cin >> amount;

        if (amount <= balance) {
            balance -= amount;
            cout << "Withdrawal of $" << amount << " was successful." << endl;
        } else {
            cout << "Insufficient balance. Withdrawal failed." << endl;
        }
    } else if (transactionType == 'D' || transactionType == 'd') {
        cout << "Enter the amount you want to deposit: $";
        cin >> amount;

        if (amount > 0) {
            balance += amount;
            cout << "Deposit of $" << amount << " was successful." << endl;
        } else {
            cout << "Invalid deposit amount. Deposit failed." << endl;
        }
    } else {
        cout << "Invalid transaction type. Please enter 'W' or 'D'." << endl;
    }

    cout << "Your updated balance is: $" << balance << endl;

    return 0;
}
