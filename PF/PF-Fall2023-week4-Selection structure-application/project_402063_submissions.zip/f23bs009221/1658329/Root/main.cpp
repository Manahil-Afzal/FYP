/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;
int main(){
    double balance, amount;
    char choice;
    
    cout<<"Enter the initial balance of your account: ";
    cin>>balance;
    
    cout<<"Do you want to deposit or withdraw money? ";
    cin>>choice;
    
    if( choice == 'D' || choice == 'd' ) //deposit
    {
        cout<<"Enter the amount to deposit: ";
        cin>>amount;
        
        if(amount > 0){
            balance += amount;
            cout<<"You have deposited "<<amount<<"rupees. \n";
        }
        else{
            cout<<"Invalid amount. Please try again. \n";
        }
    }
        else if(choice == 'W' || choice == 'w') //withdraw
        {cout<<"Enter the amount to withdraw ";
        cin>>amount;
        if(amount > 0 && amount <= balance){
            balance -= amount;
            cout<<"You have withdrawn "<<amount<< " rupees./n";
        }
        else{
            cout<<"Insufficient or invalid amount. Please try again. \n";
        }
    }
    
    else{
        cout<<"Invalid choice. Please try again.\n";
    }
    cout<<"Your current balance is" <<balance<<"rupees.";
    return 0;
}