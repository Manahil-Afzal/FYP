
#include<iostream>
using namespace std;
int main (){
    int a;
    long balance,withdraw,deposit;
    balance=100000;
    cout<<"your current balance is 100000.";
    cout<<"Enter 1 if you want to withdraw or enter 2 if you want to deposit:";
    cin>>a;
    if(a==1)
    {
        cout<<"enter the amount you want to withdraw:";
        cin>>withdraw;
        if(withdraw>100000){
        cout<<"inappropriate message.";
        }else
        balance=100000-withdraw;
        cout<<"your current balance is:"<<balance;
   } else if(a==2)
    {
        cout<<"Enter the amount you want to deposit:";
        cin>>deposit;
        balance=100000+deposit;
        cout<<"Your current balance is:"<<balance;
    }else
    cout<<"inappropriate message.";
}
    