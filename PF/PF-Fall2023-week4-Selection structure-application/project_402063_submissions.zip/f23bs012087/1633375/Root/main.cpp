#include <iostream>
using namespace std;
int main()
{
    double currentBalance = 200000;
    char response;
    double amount;
cout << "Current Balance: " << currentBalance << endl;
cout << "Do you want to withdraw or deposit? (Enter 'W' for withdraw or 'D' for deposit): ";
    cin >> response;

    if (response == 'W' || response == 'w') {
        cout << "Enter the amount to withdraw: ";
        cin >> amount;
        if (amount > currentBalance) {
            cout << "Insufficient balance." << endl;
        } else {
            currentBalance -= amount;
            cout << "Withdrawn =  " << amount << endl;
        }
    } else if (response == 'D' || response == 'd') {
        cout << "Enter the amount to deposit: ";
        cin >> amount;
        if (amount < 0) {
            cout << "Invalid deposit amount." << endl;
        } else {
            currentBalance += amount;
            cout << "Deposited =  " << amount << endl;
        }
    } else {
        cout << "Invalid choice." << endl;
    }

    cout << "Updated Balance: " << currentBalance << endl;

    return 0;
}