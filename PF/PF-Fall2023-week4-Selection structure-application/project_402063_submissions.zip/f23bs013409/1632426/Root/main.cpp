/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int balance=10000;
    int amount;
    int new_balance;
    char choice;
    cout<<"Enter amount :";
    cin>>amount;
    cout<<"To withdraw press 1 or deposit press 2 :";
    cin>>choice;
    if(choice=='1'){
        new_balance=balance-amount;
        cout<<new_balance<<" is your new balance.";
    }
    else if(choice==2){
        new_balance=balance+amount;
        cout<<new_balance<<" is your new balance.";
    }
    else{
        cout<<"inappropriate value";
    }
    return 0;
    }
    
   