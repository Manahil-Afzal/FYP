/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main(){
 int existingBalance=50000;
 int amountEntered;
 int newBalance;
 char choice;
 cout<<"Enter amount you want to withdraw or deposit:";
 cin>>amountEntered;
 cout<<"Enter W to withdraw or D for deposit:";
 cin>>choice;
 if(choice=='W'){
 	newBalance=existingBalance - amountEntered;
 	cout<<"you withdrew "<<amountEntered<<" and your new balance is "<<newBalance;
 	}else if(choice=='D'){
 		newBalance=existingBalance + amountEntered;
 		cout<<"you deposited "<<amountEntered<<" and your  new balance is "<<newBalance;
	 }else{
	 	cout<<"Inappropriate choice";
	 } 
}
