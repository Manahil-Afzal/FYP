/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int exbalance=100000;
    int amount;
    int balance;
    char choice;
    cout<<"enter your amount :";
    cin>>amount;
    cout<<"press 1 if you want to withdraw or press 0 if you want to deposit :";
    cin>>choice;
    if(choice=='1'){
        balance=exbalance-amount;
        cout<<balance <<" is your new balance.";
    }
    else if(choice=='0'){
        balance=exbalance+amount;
        cout<<balance <<" is your new balance.";
    }
    else{
        cout<<"inappropriate input";
    }
    
    return 0;
}