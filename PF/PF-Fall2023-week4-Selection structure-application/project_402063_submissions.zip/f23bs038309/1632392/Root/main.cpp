/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    cout<<"Welcome back, Dear Customer!";
    
    int remaining_balance;
    int deposit;
    int withdraw;
    int n_balance;
    cout<<"Your Current Balance=5000\n";
    cout<<"To withdraw press 1 or for deposit press 2 \n";
    int daw;
    cin>>daw;
    if(daw==2)
    {
    cout<<"\nThe balance you want to deposit=";
   cin>>deposit;
     n_balance=5000+deposit;
    cout<<"Your New Balance="<<n_balance;
   
    }
    else if(daw==1)
    {
    cout<<"The balance you want to withdraw=";
    cin>>withdraw;
    remaining_balance= 5000-withdraw;
    cout<<"your remaining balance="<<remaining_balance;
    }
    
    return 0;
    
}