/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/

	/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include<iostream>
using namespace std;
int main()
{
  int a;
  long balance,withdraw,deposit;
  balance=200000;
  cout<<"your current balance is 200000"<<endl;
  cout<<"enter 1 if you want to withdraw or enter 2 if you want to deposit:"<<endl;
  cin>>a;
  if(a==1)
  {
  	cout<<"enter the amount you want to withdraw:"<<endl;
	  cin>>withdraw;
	  if(withdraw>200000)
	  cout<<"inappropriate message:"<<endl;
	  else
	  balance=200000-withdraw;
	  cout<<"your current balance is:"<<balance;	
  }
  else if(a==2)
  {
  
  cout<<"enter the amount you want to deposit:"<<endl;
	  cin>>deposit;
balance=200000+deposit;
	  cout<<"your current balance is:"<<balance;
}
else
cout<<"inappropriate message:";
}