#include <iostream>
using namespace std;

int main() {
    int start, end;
    cout << "Enter the start of the range: ";
    cin >> start;
    cout << "Enter the end of the range: ";
    cin >> end;

    int evenSum = 0;
    int evenCount = 0;
    int oddSum = 0;
    int oddCount = 0;

    for (int i = start; i <= end; i++) {
        if (i % 2 == 0) {
            evenSum += i;
            evenCount++;
        } else {
            oddSum += i;
            oddCount++;
        }
    }

    if (evenCount > 0) {
        double evenAverage = static_cast<double>(evenSum) / evenCount;
        cout << "Average of even numbers: " << evenAverage << endl;
    } else {
        cout << "No even numbers in the range." << endl;
    }

    if (oddCount > 0) {
        double oddAverage = static_cast<double>(oddSum) / oddCount;
        cout << "Average of odd numbers: " << oddAverage << endl;
    } else {
        cout << "No odd numbers in the range." << endl;
    }

    return 0;
}
/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/