/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
int main() {
    int lower, upper;


    cout << "Enter the lower bound of the range: ";
    cin >> lower;

    cout << "Enter the upper bound of the range: ";
    cin >> upper;

    if (lower > upper) {
     cout << "Invalid range. The lower bound should be less than or equal to the upper bound.\n";
        return 1; 
    }

    double sumEven = 0, countEven = 0;
    double sumOdd = 0, countOdd = 0;

    for (int i = lower; i <= upper; ++i) {
        if (i % 2 == 0) {
            sumEven += i;
            countEven++;
        } else {
            sumOdd += i;
            countOdd++;
        }
    }


    double avgEven = (countEven == 0)?0 : sumEven / countEven;
    double avgOdd = (countOdd == 0) ?0: sumOdd / countOdd;

    cout << "Average of even numbers: " << avgEven <<endl;
    cout << "Average of odd numbers: " << avgOdd <<endl;

    return 0;
}