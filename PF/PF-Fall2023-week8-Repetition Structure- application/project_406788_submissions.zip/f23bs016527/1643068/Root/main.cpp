/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
 main() {
    int lower, higher;

    cout << "Enter the lower value of the range: ";
    cin >> lower;

    cout << "Enter the higher value of the range: ";
    cin >> higher;

    if (lower >= higher) {
        cout << "enter the correct range number :" <<endl;
    }

    int sumEven = 0, sumOdd = 0;
    int countEven = 0, countOdd = 0;

    for (int num = lower; num <= higher; ++num) {
        if (num % 2 == 0) {
            sumEven += num;
            countEven++;
        } else { 
            sumOdd += num;
            countOdd++;
        }
    }

    float avgEven =(sumEven) / countEven;
    float avgOdd = (sumOdd) / countOdd;

    cout << "Average of even numbers in the range: " << avgEven<<endl;
    cout << "Average of odd numbers in the range: " << avgOdd <<endl;

}