/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
int high;
int low;
cout<<"enter lowest number";
cin>>low;
cout<<"enter highest number";
cin>>high;
cout<<endl;
int a=low;
int range1=0;
int range2=0;
int even=0;
int odd=0;
for(int i=a;i<high;i++)
{
low++;
if(low/2==0)
{
even=even+low;
range1++;
}
else
    {
    odd=odd+low;
    range2++;
    }
}
int avge=even/range1;
cout<<"E avg"<<avge;
int avgo=odd/range2;
cout<<"O avg"<<avgo;

}