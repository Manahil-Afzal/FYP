#include <iostream>
using namespace std;

int main() {
    int lower, upper;
    cout << "Enter the lower limit of the range: ";
    cin >> lower;
    cout << "Enter the upper limit of the range: ";
    cin >> upper;

    int even_sum = 0, odd_sum = 0;
    int even_count = 0, odd_count = 0;

    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) {
            even_sum += i;
            even_count++;
        } else {
            odd_sum += i;
            odd_count++;
        }
    }

    double even_avg = (even_count == 0) ? 0 : (double)even_sum / even_count;
    double odd_avg = (odd_count == 0) ? 0 : (double)odd_sum / odd_count;

    cout << "The average of even numbers between " << lower << " and " << upper << " is: " << even_avg << endl;
    cout << "The average of odd numbers between " << lower << " and " << upper << " is: " << odd_avg << endl;

    return 0;
}
