/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, upper;
    double even_sum = 0, odd_sum = 0;
    int even_count = 0, odd_count = 0;

    cout << "Enter the lower value of the range: ";
    cin >> lower;

    cout << "Enter the upper value of the range: ";
    cin >> upper;

    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) {
            even_sum += i;
            even_count++;
        } else {
            odd_sum += i;
            odd_count++;
        }
    }

    double even_avg = even_sum / even_count;
    double odd_avg = odd_sum / odd_count;

    cout << "The average of even numbers between " << lower << " and " << upper << " is: " << even_avg << endl;
    cout << "The average of odd numbers between " << lower << " and " << upper << " is: " << odd_avg << endl;

    return 0;
}
