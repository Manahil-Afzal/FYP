/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, higher;
    cout << "Enter the lower bound of the range: ";
    cin >> lower;
    cout << "Enter the higher bound of the range: ";
    cin >> higher;

    if (lower > higher) {
        cout << "Invalid range. Lower bound is greater than higher bound." << endl;
        return 1;
    }

    int sumEven = 0, sumOdd = 0;
    int countEven = 0, countOdd = 0;

    for (int i = lower; i <= higher; i++) {
        if (i % 2 == 0) {
            sumEven += i;
            countEven++;
        } else {
            sumOdd += i;
            countOdd++;
        }
    }

    if (countEven > 0) {
        double averageEven = static_cast<double>(sumEven) / countEven;
        cout << "Average of even numbers in the range: " << averageEven << endl;
    } else {
        cout << "No even numbers in the range." << endl;
    }

    if (countOdd > 0) {
        double averageOdd = static_cast<double>(sumOdd) / countOdd;
        cout << "Average of odd numbers in the range: " << averageOdd << endl;
    } else {
        cout << "No odd numbers in the range." << endl;
    }

    return 0;
}