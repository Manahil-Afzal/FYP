/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main(){
    int highest=0;
    int lowest=0;
    int evenSum=0;
    int oddSum=0;
    int flag1=0;
    int flag2=0;
    float evenAvg;
 float oddAvg;
    cout<<"Enter starting number:"<<endl;
    cin>>lowest;
    cout<<"Enter ending number:"<<endl;
    cin>>highest;
    for(int i=lowest;i<=highest;i++){
        if(i%2==0){
                   evenSum=evenSum+i;  
                   flag1++;
        }else{
              oddSum=oddSum+i;
            flag2++;
        }
    }evenAvg=(evenSum/flag1);
        cout<<"Average of even numbers is:"<<evenAvg<<endl;
        oddAvg=(oddSum/flag2);
        cout<<"Average of odd numbers is:"<<oddAvg<<endl;
	return 0;
}