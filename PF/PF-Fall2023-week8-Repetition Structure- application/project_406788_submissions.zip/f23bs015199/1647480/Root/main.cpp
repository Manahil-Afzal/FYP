/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, upper;
    cout << "Enter the lower bound of the range: ";
    cin >> lower;
    cout << "Enter the upper bound of the range: ";
    cin >> upper;

    if (lower > upper) {
        cout << "Invalid range. The lower bound cannot be greater than the upper bound." << endl;
    } else {
        int evenSum = 0, oddSum = 0;
        int evenCount = 0, oddCount = 0;

        for (int num = lower; num <= upper; num++) {
            if (num % 2 == 0) {
                evenSum += num;
                evenCount++;
            } else {
                oddSum += num;
                oddCount++;
            }
        }

        if (evenCount > 0) {
            double evenAverage = static_cast<double>(evenSum) / evenCount;
            cout << "Average of even numbers between " << lower << " and " << upper << ": " << evenAverage << endl;
        } else {
            cout << "No even numbers in the range." << endl;
        }

        if (oddCount > 0) {
            double oddAverage = static_cast<double>(oddSum) / oddCount;
            cout << "Average of odd numbers between " << lower << " and " << upper << ": " << oddAverage << endl;
        } else {
            cout << "No odd numbers in the range." << endl;
        }
    }

    return 0;
}
