/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
   int lowest,upper;
   int evensum=0;
   int oddsum=0;
   int flag1=0;
   int flag2=0;
   float oddaverage=0;
   float evenaverage=0;
   cout<<"enter the lowest range :";
   cin>>lowest;
   cout<<"enter the upper range :";
    cin>>upper;
   
    
    for(int i=lowest;i<=upper;i++)
    { 
        if(i%2==0){
            evensum=evensum+i;
            flag1++;
        }
        else{
            oddsum=oddsum+i;
            flag2++;
        }    
    }
            evenaverage=evensum/flag1;
            cout<<"average of even number is :"<<evenaverage<<endl;
            oddaverage=oddsum/flag2;
            cout<<"average of odd number is : "<<oddaverage<<endl;
            return 0;
    }
            
            
            
            
            
            
            
            
        
    
    