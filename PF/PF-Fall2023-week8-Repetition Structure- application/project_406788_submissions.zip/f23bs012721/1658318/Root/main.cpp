/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>

using namespace std;

int main() {
    int lower, higher;

    // Input lower and higher values
    cout << "Enter the lower value of the range: ";
    cin >> lower;
    cout << "Enter the higher value of the range: ";
    cin >> higher;

    int sumEven = 0, countEven = 0;
    int sumOdd = 0, countOdd = 0;

    // Calculate the averages of even and odd numbers
    for (int num = lower; num <= higher; num++) {
        if (num % 2 == 0) {
            sumEven += num;
            countEven++;
        } else {
            sumOdd += num;
            countOdd++;
        }
    }

    // Calculate the averages
    double avgEven = (countEven > 0) ? static_cast<double>(sumEven) / countEven : 0;
    double avgOdd = (countOdd > 0) ? static_cast<double>(sumOdd) / countOdd : 0;

    // Display the results
    cout << "Average of even numbers between " << lower << " and " << higher << ": " << avgEven << endl;
    cout << "Average of odd numbers between " << lower << " and " << higher << ": " << avgOdd << endl;

    return 0;
}