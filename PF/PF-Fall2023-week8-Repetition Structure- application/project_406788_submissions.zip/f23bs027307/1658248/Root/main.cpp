/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, higher;
    
    cout << "Enter the lower value of the range: ";
    cin >> lower;
    
    cout << "Enter the higher value of the range: ";
    cin >> higher;
    
    if (lower > higher) {
        cout << "Invalid range. The lower value should be less than or equal to the higher value." << endl;
    } else {
        int sumEven = 0, countEven = 0;
        int sumOdd = 0, countOdd = 0;
        
        for (int i = lower; i <= higher; i++) {
            if (i % 2 == 0) { // Even number
                sumEven += i;
                countEven++;
            } else { // Odd number
                sumOdd += i;
                countOdd++;
            }
        }
        
        if (countEven > 0) {
            double averageEven = static_cast<double>(sumEven) / countEven;
            cout << "Average of even numbers: " << averageEven << endl;
        } else {
            cout << "No even numbers in the range." << endl;
        }
        
        if (countOdd > 0) {
            double averageOdd = static_cast<double>(sumOdd) / countOdd;
            cout << "Average of odd numbers: " << averageOdd << endl;
        } else {
            cout << "No odd numbers in the range." << endl;
        }
    }
    
    return 0;
}
