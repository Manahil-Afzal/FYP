/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
	int high,low,i,sumeven=0,sumodd=0,counteven=0,countodd=0;
	cout<<"Enter The Higher Value Of Range"<<endl;
	cin>>high;
cout<<"Enter The Lover Value Of Range"<<endl;
	cin>>low;
	for (i=low;i<=high;i++){
	
	if (i%2==0){
	
	sumeven=sumeven+i;
	counteven++;}
	else{
	
	sumodd=sumodd+i;
	countodd++;}
	
}
	double averageeven=(double)sumeven/counteven;
	double averageodd=(double)sumodd/countodd;
	cout<<"The Avergae of even numbers is "<<averageeven<<endl;
	cout<<"The Avergae of odd numbers is "<<averageodd<<endl;
}