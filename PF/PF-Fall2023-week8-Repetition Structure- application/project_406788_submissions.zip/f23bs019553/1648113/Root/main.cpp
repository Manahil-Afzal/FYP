/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>

using namespace std;

int main() {
    int lower, higher, sum_even = 0, sum_odd = 0, count_even = 0, count_odd = 0;

    cout << "Enter the lower limit: ";
    cin >> lower;

    cout << "Enter the higher limit: ";
    cin >> higher;

    for(int i = lower; i <= higher; i++) {
        if(i % 2 == 0) {
            sum_even += i;
            count_even++;
        } else {
            sum_odd += i;
            count_odd++;
        }
    }

    float average_even = (float)sum_even / count_even;
    float average_odd = (float)sum_odd / count_odd;

    cout << "Average of even numbers: " << average_even << endl;
    cout << "Average of odd numbers: " << average_odd << endl;

    return 0;
}