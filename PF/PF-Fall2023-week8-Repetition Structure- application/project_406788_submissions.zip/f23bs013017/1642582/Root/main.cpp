/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>

int main() {
    int lower, upper;
    int sumEven = 0, sumOdd = 0;
    int countEven = 0, countOdd = 0;

    // Input lower and upper limits of the range
    std::cout << "Enter the lower limit of the range: ";
    std::cin >> lower;

    std::cout << "Enter the upper limit of the range: ";
    std::cin >> upper;

    if (lower > upper) {
        std::cout << "Invalid range. The lower limit should be less than or equal to the upper limit." << std::endl;
        return 1;
    }

    // Calculate the sum and count of even and odd numbers in the range
    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) { // Even number
            sumEven += i;
            countEven++;
        } else { // Odd number
            sumOdd += i;
            countOdd++;
        }
    }

    // Calculate and display the averages
    if (countEven > 0) {
        double avgEven = static_cast<double>(sumEven) / countEven;
        std::cout << "Average of even numbers in the range: " << avgEven << std::endl;
    } else {
        std::cout << "No even numbers in the range." << std::endl;
    }

    if (countOdd > 0) {
        double avgOdd = static_cast<double>(sumOdd) / countOdd;
        std::cout << "Average of odd numbers in the range: " << avgOdd << std::endl;
    } else {
        std::cout << "No odd numbers in the range." << std::endl;
    }

    return 0;
}