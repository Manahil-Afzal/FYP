/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
main()
{
   int lowerrange,upperrange;
    cout<<"enter the lower range:";
    cin>>lowerrange;
    cout<<"enter the upper range:";
    cin>>upperrange;
    if(lowerrange>upperrange){
        cout<<"invalid range:the lower value should be less than or equal to upper value";
    }
    int sumeven=0,counteven=0;
    int sumodd=0,countodd=0;
    int evenaverage=0,oddaverage=0;
    for(int num=lowerrange;num<=upperrange;num++){
        if(num%2==0){
            sumeven+=num;
            counteven++;
        }
        else{
        	  sumodd+=num;
            countodd++;
        }
    }
    if(counteven>0){
        double averageeven=sumeven/counteven;
        cout<<"average of even numbers is:"<<evenaverage<<endl;
    }
    if(countodd>0){
        double averageodd=sumodd/countodd;
        cout<<"average of odd numbers is:"<<oddaverage<<endl;
    }
}