#include <iostream>

using namespace std;

int main() {
    int lower, higher;
    cout << "Enter the lower limit of the range: ";
    cin >> lower;
    cout << "Enter the higher limit of the range: ";
    cin >> higher;

    if (lower > higher) {
        cout << "Invalid range. The lower limit should be less than or equal to the higher limit." << endl;
    } else {
        int evenSum = 0;
        int evenCount = 0;
        int oddSum = 0;
        int oddCount = 0;

        for (int num = lower; num <= higher; num++) {
            if (num % 2 == 0) {
                evenSum += num;
                evenCount++;
            } else {
                oddSum += num;
                oddCount++;
            }
        }

        if (evenCount > 0) {
            double evenAverage = static_cast<double>(evenSum) / evenCount;
            cout << "Average of even numbers between " << lower << " and " << higher << ": " << evenAverage << endl;
        } else {
            cout << "No even numbers found in the range." << endl;
        }

        if (oddCount > 0) {
            double oddAverage = static_cast<double>(oddSum) / oddCount;
            cout << "Average of odd numbers between " << lower << " and " << higher << ": " << oddAverage << endl;
        } else {
            cout << "No odd numbers found in the range." << endl;
        }
    }

    return 0;
}
