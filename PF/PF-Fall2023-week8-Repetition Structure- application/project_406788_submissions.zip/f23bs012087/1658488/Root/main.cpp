/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
int main()
{
    int lower, upper;
    int evenCount = 0,oddCount = 0;
    double evenSum = 0.0 , oddSum = 0.0;

    cout << "Enter the lower limit of the range : ";
    cin >> lower;
    cout << "Enter the upper limit of the range : ";
    cin >> upper;

    for (int num = lower; num <= upper; num++) 
    {
        if (num % 2 == 0) 
        {  // Check if the number is even
            evenSum += num;
            evenCount++;
        } else {
            oddSum += num;
            oddCount++;
        }
    }

    double evenAverage = evenCount > 0 ? evenSum / evenCount : 0;
    double oddAverage = oddCount > 0 ? oddSum / oddCount : 0;

    cout << "Average of even numbers between " << lower << " and " << upper << ": " << evenAverage << endl;
    cout << "Average of odd numbers between " << lower << " and " << upper << ": " << oddAverage << endl;

    return 0;
}