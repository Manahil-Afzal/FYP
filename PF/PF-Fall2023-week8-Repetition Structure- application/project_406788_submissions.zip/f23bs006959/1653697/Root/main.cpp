/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/

#include<iostream>
using namespace std;
int main()
{
    int lowest=0;
    int highest=0;
    int evensum=0;
    int oddsum=0;
    int flag1=0;
    int flag2=0;
    float evenavg;
    float oddavg;
    cout<<"enter the starting number\n";
    cin>>lowest;
    cout<<"enter the ending number\n";
    cin>>highest;
    for(int i=lowest; i<=highest;i++){
        if(i%2==0){
                   evensum=evensum+i;  
                   flag1++;
        }else{
              oddsum=oddsum+i;
            flag2++;
        }
    }evenavg=(evensum/flag1);
        cout<<"Average of even numbers is:"<<evenavg<<endl;
        oddavg=(oddsum/flag2);
        cout<<"Average of odd numbers is:"<<oddavg<<endl;
	return 0;
}