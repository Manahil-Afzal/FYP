/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values*/
#include<iostream>
using namespace std;
int main()
{
    int lowest=0;
    int highest=0;
    int even=0;
    int odd=0;
    int range1=0;
    int range2=0;
    cout<<"ebter the highest value="<<endl;
    cin >>highest;
    cout<<"enter the lowest value="<<lowest;
    cin>>lowest;
    for(int i=lowest;lowest<highest;i++)
    {
        lowest++;
        if(lowest%2==0)
        {
            even=even+lowest;
            range1++;
        }
        else{
            odd=odd+lowest;
            range2++;}
        
    }
            
        int avge=even/range1;
        cout<<"even average is="<<avge;
        int avgo=odd/range2;
        cout<<"odd average is="<<avgo;
    
}