/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/

#include <iostream>
using namespace std;

int main() {
    int lower, higher;
    cout << "Enter the lower value of the range: ";
    cin >> lower;
    cout << "Enter the higher value of the range: ";
    cin >> higher;

    int sumEven = 0, countEven = 0;
    int sumOdd = 0, countOdd = 0;

    for (int i = lower; i <= higher; i++) {
        if (i % 2 == 0) {
            sumEven += i;
            countEven++;
        } else {
            sumOdd += i;
            countOdd++;
        }
    }

    cout << "Average of even numbers: ";
    if (countEven > 0) {
        cout << (double)sumEven / countEven << endl;
    } else {
        cout << "No even numbers in the range." << endl;
    }

    cout << "Average of odd numbers: ";
    if (countOdd > 0) {
        cout << (double)sumOdd / countOdd << endl;
    } else {
        cout << "No odd numbers in the range." << endl;
    }

    return 0;
}
