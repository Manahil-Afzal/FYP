/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
main ()
{
  float evenSum=0,oddSum=0,evenCount=0,oddCount=0;
  int upper,lower;
  cout << "enter lower range : ";
  cin>>lower;
  cout << "enter upper range : ";
  cin>>upper;
  lower++;
  for(;lower<upper;lower++)
  {
    if(lower%2==0)
    {
        evenSum = evenSum+lower;
        evenCount++;
    }
    else
    {
        oddSum=oddSum+lower;
        oddCount++;
    }
  }
  cout<<"even numbers average is :" <<evenSum/evenCount<<endl;
  cout<<"odd numbers average is: " <<oddSum/oddCount;
    
    
}