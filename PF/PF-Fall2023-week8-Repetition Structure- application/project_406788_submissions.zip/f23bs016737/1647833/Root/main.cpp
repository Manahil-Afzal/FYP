/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
#include<math.h>
using namespace std;
int main()
{
    int higher=0;
    int even=0;
    int lower=0;
    int odd=0;
    int enumbers=0;
    int onum=0;
    
    
    cout<<"Please enter lower number :"<<endl;
    cin>>lower;
    cout<<"Please enter higher number :"<<endl;
    cin>>higher;
  int i=lower+1;
if(lower<higher&&higher>0)
{
                  
for( ;i<higher;i++)
{
    if(i%2==0)
    {
        even+=i;
        enumbers++;
       
    }
    else
{
    odd+=i;
    onum++;
}
   
}
float AveEven=(even/enumbers);
float AveOdd=(odd/onum);

 cout<<"Average of even numbers :"<<AveEven<<endl;
 cout<<"Average of odd numbers :"<<AveOdd;
}
else
{
    string opt;
    
    cout<<"Sorry, Please enter valid numberrs :"<<endl;
    
    cout<<"Do you Want to try again  :"<<endl;
    cout<<"Enter yes or no for further process: "<<endl;
    cin>>opt;
    if(opt=="yes")
    {
        cout<<"Please enter lower number :"<<endl;
    cin>>lower;
    cout<<"Please enter higher number :"<<endl;
    cin>>higher;
  int i=lower+1;
if(lower<higher&&higher>0)
{
                  
for( ;i<higher;i++)
{
    if(i%2==0)
    {
        even+=i;
        enumbers++;
       
    }
    else
{
    odd+=i;
    onum++;
}
   
}
float AveEven=(even/enumbers);
float AveOdd=(odd/onum);

 cout<<"Average of even numbers :"<<AveEven<<endl;
 cout<<"Average of odd numbers :"<<AveOdd;
} 
    }
    else
{
    cout<<"Thank you, you finished your programe ";
}
}

 
}