/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
main() {
    int start, end;
    // Input range of numbers
    cout << "Enter the starting number: ";
    cin >> start;
    std::cout << "Enter the ending number: ";
    std::cin >> end;
    // Validate the range
    if (start > end) {
        std::cout << "Invalid range. Starting number should be less than or equal to the ending number." << std::endl;
        return 1;
    }
    // Initialize variables for calculating averages
    int sumEven = 0, countEven = 0;
    int sumOdd = 0, countOdd = 0;

    // Calculate averages
    for (int i = start; i <= end; ++i) {
        if (i % 2 == 0) {
            // Even number
            sumEven += i;
            countEven++;
        } else {
            // Odd number
            sumOdd += i;
            countOdd++;
        }
    }

    // Display averages
    if (countEven > 0) {
        std::cout << "Average of even numbers: " << static_cast<double>(sumEven) / countEven << std::endl;
    } else {
        std::cout << "No even numbers in the range." << std::endl;
    }

    if (countOdd > 0) {
        std::cout << "Average of odd numbers: " << static_cast<double>(sumOdd) / countOdd << std::endl;
    } else {
        std::cout << "No odd numbers in the range." << std::endl;
    }

}