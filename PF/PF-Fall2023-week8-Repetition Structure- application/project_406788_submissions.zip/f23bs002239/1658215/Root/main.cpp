/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
int main()
{
    int i,num, oddSum=0,evenSum=0,oddCount=0,evenCount=0;    //1
double evenAvg,oddAvg;                     //2
    cout<<"Enter the value for num: ";     //3
    cin>>num;
    for(i=1; i<=num; i++)
    {           //4
    if(i % 2==0)
    {               //5
        evenSum=evenSum+i;
        evenCount++;
    }
    else
    {                            //6
        oddSum=oddSum+i;
        oddCount++;
    }
    }
}