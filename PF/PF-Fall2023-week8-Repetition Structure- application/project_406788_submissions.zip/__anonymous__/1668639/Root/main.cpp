/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main ()
{
    int low, high, evenSum = 0, oddSum = 0, evenCount = 0, oddCount = 0;
    double evenAvg, oddAvg;
    cout<<"Enter the lower value of the range:";
    cin>> low;
    cout<<"Enter the higher value of the range:";
    cin>> high;
    for(int i = low; i<= high; i++){
        if(i % 2 ==0 ){
            evenSum+= i;
            evenCount++;
            }
    }
    if (evenCount > 0) {
        evenAvg = (double)evenSum / evenCount;
        cout<< "The average of even numbers is" << evenAvg << endl;
    }
    if (oddCount > 0){
        oddAvg = (double)oddSum / oddCount;
        cout<<"The average of odd numbers is " << oddAvg << endl;
    }
    else{
        cout<< "There are no odd numbers in the range." << endl;
    }
    return 0;
    
}