/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
int i,num, oddSum=0,evenSum=0,oddCount=0,evenCount=0;    
double evenAvg,oddAvg;                    
    cout<<"Enter the value for num: ";     
    cin>>num;
    for(i=1; i<=num; i++)
    {           
    if(i % 2==0)
    {              
        evenSum=evenSum+i;
        evenCount++;
    }
    else
    {                            
        oddSum=oddSum+i;
        oddCount++;
    }

    } 
evenAvg=evenSum/evenCount;                     
oddAvg=oddSum/oddCount; 
cout<<"Average of odd numbers are: "<<oddAvg;    
cout<<"\n";
cout<<"Average of even numbers are: "<<evenAvg;

    return 0;
    
}