/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
int high,low,o=0,e=0,total1=0,total2=0;
float avge,avgo;
cout<<"Enter the lowest and highest value for range of numbers"<<endl;
cin>>low>>high;
for(int a=low;a<=high;a++)
{
    if(a%2==0)
    {
        total1=total1+a;
        e++;
    }
    else{
    total2=total2+a;
    o++;}
}
avge=total1/e;
avgo=total2/o;
cout<<"The average of even no is"<<avge<<endl;
cout<<"The average of odd no is"<<avgo<<endl;



return 0;
}