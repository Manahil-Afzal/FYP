/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/#include <iostream>
#include<iostream>
using namespace std;
int main() {
    int lower, higher;
    std::cout << "Enter the lower value of the range: ";
    std::cin >> lower;
    std::cout << "Enter the higher value of the range: ";
    std::cin >> higher;

    int sumEven = 0, countEven = 0;
    int sumOdd = 0, countOdd = 0;

    for (int num = lower; num <= higher; num++) {
        if (num % 2 == 0) {
            sumEven += num;
            countEven++;
        } else {
            sumOdd += num;
            countOdd++;
        }
    }

    double averageEven = (countEven == 0) ? 0 : static_cast<double>(sumEven) / countEven;
    double averageOdd = (countOdd == 0) ? 0 : static_cast<double>(sumOdd) / countOdd;

    std::cout << "Average of even numbers: " << averageEven << std::endl;
    std::cout << "Average of odd numbers: " << averageOdd << std::endl;

    return 0;
}



