/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, upper;
    cout << "Enter the lower bound of the range: ";
    cin >> lower;
    cout << "Enter the upper bound of the range: ";
    cin >> upper;

    if (lower > upper)
    {
        cout << "Invalid range. The lower bound should be less than or equal to the upper bound." << endl;
        return 1;
    }

    int sumEven = 0;
    int countEven = 0;
    int sumOdd = 0;
    int countOdd = 0;

    for (int num = lower; num <= upper; num++) 
    {
        if (num % 2 == 0)
        {
            sumEven += num;
            countEven++;
        }
        else 
        {
            sumOdd += num;
            countOdd++;
        }
    }

    if (countEven > 0)
    {
        double averageEven = static_cast<double>(sumEven) / countEven;
        cout << "Average of even numbers between " << lower << " and " << upper << ": " << averageEven << endl;
    }
    else
    {
        cout << "No even numbers in the range." << endl;
    }

    if (countOdd > 0)
    {
        double averageOdd = static_cast<double>(sumOdd) / countOdd;
        cout << "Average of odd numbers between " << lower << " and " << upper << ": " << averageOdd << endl;
    } else
    {
        cout << "No odd numbers in the range." << endl;
    }

    return 0;
}