/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, upper;
    cout << "Enter the lower range: ";
    cin >> lower;
    cout << "Enter the upper range: ";
    cin >> upper;

    int sumEven = 0, countEven = 0;
    int sumOdd = 0, countOdd = 0;

    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) {
            sumEven += i;
            countEven++;
        } else {
            sumOdd += i;
            countOdd++;
        }
    }

    if (countEven > 0) {
        double averageEven = static_cast<double>(sumEven) / countEven;
        cout << "Average of even numbers between " << lower << " and " << upper << " is: " << averageEven << endl;
    } else {
        cout << "No even numbers in the given range." << endl;
    }

    if (countOdd > 0) {
        double averageOdd = static_cast<double>(sumOdd) / countOdd;
        cout << "Average of odd numbers between " << lower << " and " << upper << " is: " << averageOdd << endl;
    } else {
        cout << "No odd numbers in the given range." << endl;
    }

    return 0;
}
