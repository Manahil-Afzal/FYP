/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;

struct Book{
	string bookId;
	float price;
	int pages;
}
myBook1,myBook2;
int main()
{
	string bookId;
	float price;
	int pages;
	cout<<"Enter deatail about book 1:"<<endl;
	cin>>myBook1.bookId;
	cin>>myBook1.price;
	cin>>myBook1.pages;
	
	cout<<"Enter deatail about book 2:"<<endl;
	cin>>myBook2.bookId;
	cin>>myBook2.price;
	cin>>myBook2.pages;
	
	if(myBook1.price>myBook2.price)
	{
		cout<<"Book 1 is costly"<<endl;
		cout<<"The record about the book 1 are:"<<endl;
		cout<<"Book 1 id is:"<<myBook1.bookId<<endl;
		cout<<"Book 1 price is:"<<myBook1.price<<endl;
		cout<<"Book 1 pages are:"<< myBook1.pages<<endl;
	}
	else{
		cout<<"Book 2 is costly"<<endl;
		cout<<"The record about the book 2 are:"<<endl;
		cout<<"Book 2 id is:"<<myBook2.bookId<<endl;
		cout<<"Book 2 price is:"<<myBook2.price<<endl;
		cout<<"Book 2 pages are:"<< myBook2.pages<<endl;
		
	}
}