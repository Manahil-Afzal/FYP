/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;

struct books
{
int bookID;
float price;
int pages;
};
     int main()
     {
         books b1,b2;
         cout<<"Enter the Id of 1st book ";
         cin>>b1.bookID;
         cout<<"Enter the Price of 1st book ";
         cin>>b1.price;
         cout<<"Enter the Pages of 1st book ";
         cin>>b1.pages;
         cout<<"Enter the Id of 1st book ";
         cin>>b2.bookID;
         cout<<"Enter the Price of 1st book ";
         cin>>b2.price;
         cout<<"Enter the Pages of 1st book ";
         cin>>b2.pages;
         if(b1.price>b2.price)
         {
             cout<<"Book 1 is more costly and it's records are :"<<endl;
             cout<<"ID : "<<b1.bookID<<endl;
             cout<<"Price : "<<b1.price<<endl;
             cout<<"Pages : "<<b1.pages<<endl;
         }
         else
         {
             cout<<"Book 2 is more costly and it's records are :"<<endl;
             cout<<"ID : "<<b2.bookID<<endl;
             cout<<"Price : "<<b2.price<<endl;
             cout<<"Pages : "<<b2.pages<<endl;
         }
         return 0;
     }