/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
 
// A structure for book
struct Book {
    char name[100];
    int price;
    int page;
};
 
int main() {
    Book b;
     
    cout << "Enter name of book\n";
    cin>>b.name;
    cout << "Enter price of book\n";
    cin >> b.price;
    cout << "Enter the pages\n";
    cin >> b.page;
     
    // Printing Book details
    cout << "\n*** Book Details ***" << endl;
    cout << "Name : " << b.name << endl;
 cout << "Price : " << b.price << endl;
    cout << "page : " << b.page;
     
    return 0;
}