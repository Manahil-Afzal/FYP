/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
char id[20];
int price;
int pages;
};
int main(){
   book book1,book2;
   book b[2]={book1,book2};
   for(int i=0;i<2;i++){
   cout<<"Enter book "<<i+1<<" Id"<<endl;
   cin>>b[i].id;
   cout<<"Enter book "<<i+1<<" Price"<<endl;
   cin>>b[i].price;
   cout<<"Enter book "<<i+1<<" Pages"<<endl;
   cin>>b[i].pages;
   }
   if (b[0].price>b[1].price){
   cout<<"Costly book Id is: "<<b[0].id<<endl;
   cout<<"Costly Book Price is: "<<b[0].price<<endl;
   cout<<"Costly Book Pages are: "<<b[0].pages<<endl;
   }
   else{
   cout<<"Costly book Id is: "<<b[1].id<<endl;
   cout<<"Costly Book Price is: "<<b[1].price<<endl;
   cout<<"Costly Book Pages are: "<<b[1].pages<<endl;
   }
}




