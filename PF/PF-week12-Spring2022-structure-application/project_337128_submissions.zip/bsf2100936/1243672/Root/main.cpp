/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
int main(){
struct {
    string bookid;
    float price;
    int pagesofbook;
} x,y;
cout<<"Enter book1 id"<<endl;
cin>>x.bookid;
cout<<"Enter book1 price"<<endl;
cin>>x.price;
cout<<"Enter pages of book1"<<endl;
cin>>x.pagesofbook;
cout<<"Enter book2 id"<<endl;
cin>>y.bookid;
cout<<"Enter book2 price"<<endl;
cin>>y.price;
cout<<"Enter pages of book2"<<endl;
cin>>y.pagesofbook;
if(x.price>y.price){
       cout<<"book 1 is more costly"<<endl;
       cout<<"book id : "<<x.bookid<<endl;
       cout<<" book pages : "<<x.pagesofbook<<endl;
       cout<<"book price : "<<x.price;
}
else{
        cout<<"book 2 is more costly"<<endl;
       cout<<"book id : "<<y.bookid<<endl;
       cout<<"book pages : "<<y.pagesofbook<<endl;
        cout<<"book price : "<<y.price;
    
}
return 0;
}