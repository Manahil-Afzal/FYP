/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
using namespace std;
struct bookDetail {
    int BookId;
    float Price;
    int Pages;
};
void display(bookDetail);
int main() {
    bookDetail book1, book2;
    cout<<"\t"<<"\t"<<"\t"<<"Enter the book1 Details: "<<endl;
    cout<<"Enter the Book Id:"<<endl;
    cin>>book1.BookId;
    cout<<"Enter the Price of Book Id:"<<book1.BookId<<endl;
    cin>>book1.Price;
    cout<<"Enter the Pages of Book :"<<book1.BookId<<endl;
    cin>>book1.Pages;
    cout<<"\t"<<"\t"<<"\t"<<"Enter the book2 Details: "<<endl;
    cout<<"Enter the Book Id:"<<endl;
    cin>>book2.BookId;
    cout<<"Enter the Price of Book Id:"<<book2.BookId<<endl;
    cin>>book2.Price;

    cout<<"Enter the Pages of Book :"<<book2.BookId<<endl;
    cin>>book2.Pages;

    if(book1.Price > book2.Price)
    display(book1);

    else
    display(book2);
    return 0;
}

void display(bookDetail book) 
{

    cout<<"\t"<<"\t"<<"\t"<<"Displaying the Details of Costly Book :"<<endl;
    cout<<"The Book Id of Costly Book is: "<<book.BookId<<endl;
    cout<<"The Price of Costly Book is: "<<book.Price<<endl;
    cout<<"The No. of Pages of Costly Book is: "<<book.Pages<<endl;

}
