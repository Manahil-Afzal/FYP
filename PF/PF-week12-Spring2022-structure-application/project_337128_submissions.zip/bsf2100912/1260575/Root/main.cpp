/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct book{
	int BookId;
	int Price;
	int Pages;
    };
int main()
{
	book book1,book2;
	cout<<"Enter ID of 1st Book:";
	cin>>book1.BookId;
	cout<<"Enter Price of 1st Book:";
	cin>>book1.Price;
	cout<<"Enter Pages of 1st Book:";
	cin>>book1.Pages;
	cout<<"Enter ID of 2nd Book:";
	cin>>book2.BookId;
	cout<<"Enter Price of 2nd Book:";
	cin>>book2.Price;
	cout<<"Enter Pages of 2nd Book:";
	cin>>book2.Pages;	
	if(book1.Price>book2.Price)
		cout<<"BookId of more costly book:"<<book1.BookId<<endl<<"Price of more costly book:"<<book1.Price<<endl<<"Pages of more costly book:"<<book1.Pages;
	else if (book1.Price<book2.Price)
		cout<<"BookId of more costly book:"<<book2.BookId<<endl<<"Price of more costly book:"<<book2.Price<<endl<<"Pages of more costly book:"<<book2.Pages;
	return 0;	
	
}