/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
int main(){
struct {
    string bookid;
    float price;
    int pagesofbook;
} a,b;
cout<<"enter book1 id"<<endl;
cin>>a.bookid;
cout<<"enter book1 price"<<endl;
cin>>a.price;
cout<<"enter pages of book1"<<endl;
cin>>a.pagesofbook;
cout<<"enter book2 id"<<endl;
cin>>b.bookid;
cout<<"enter book2 price"<<endl;
cin>>b.price;
cout<<"enter pages of book2"<<endl;
cin>>b.pagesofbook;
if(a.price>b.price){
       cout<<"book 1 is more costly"<<endl;
       cout<<"book id : "<<a.bookid<<endl;
       cout<<" book pages : "<<a.pagesofbook<<endl;
       cout<<"book price : "<<a.price;
}
else{
        cout<<"book 2 is more costly"<<endl;
       cout<<"book id : "<<b.bookid<<endl;
       cout<<"book pages : "<<b.pagesofbook<<endl;
        cout<<"book price : "<<b.price;
    
}
return 0;
}