/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

 struct Book{
     int id;
     int price;
     int pages;
     };

int main(){
    Book b1,b2;
    
    cout<<"enter the Id, Price, No of pages respectively for book 1. \n";
    cin>>b1.id>>b1.price>>b1.pages;
    cout<<"enter the Id, Price, No of pages respectively for book 2. \n";
    cin>>b2.id>>b2.price>>b2.pages;
    
    if(b1.price > b2.price)
        cout<<"Book 1 is more costly";
    else
        cout<<"Book 2 is more costly";
        
}