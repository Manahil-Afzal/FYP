/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
using namespace std;
 struct book {
 string bookId;
 int price;
 int page;
 };	
 
int main(){
	book book1,book2;
	cout<<"enter the book "<<endl;
	cin>>book1.bookId;
	cout<<"enter the price "<<endl;
	cin>>book1.price;
	cout<<"enter the page"<<endl;
	cin>>book1.page;
	cout<<"\n";
	// here we give the information  of book2
	
	cout<<"enter the book "<<endl;
	cin>>book2.bookId;
	cout<<"enter the price "<<endl;
	cin>>book2.price;
	cout<<"enter the page"<<endl;
	cin>>book2.page;
	if(book1.price>book2.price){
		
		cout<<"book1 is most costly than book2";
		
	}
	else
		cout<<"book2 is most costly than book1";
	
	return 0;
		
	
}
	
	