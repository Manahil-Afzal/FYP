/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
struct {
  string bookId;
  int price;
  int pages;
} book1, book2;
int main()
{
string bookId;
  int price;
  int pages;
  cout << "Enter details about book 1: " << endl;
   cin >> book1.bookId;
   cin >> book1.price;
   cin >> book1.pages;
  cout << "Enter details about book 2:"<< endl;
   cin >> book2.bookId;
   cin >>book2.price;
   cin >>book2.pages;
if(book1.price > book2.price){
    cout << "book 1 is  costly "    << endl;
    cout << "The records about book1 are:"  << endl;
    cout << "the book 1  Id is : "  << book1.bookId<< endl;
    cout <<  "The book 1 price is:" << book1.price << endl;
    cout << "The book 1 pages are: "<< book1.pages << endl;
}
 else{
    cout << "  book  2  is  costly" << endl;
    cout << "The record about book2 are : " << endl;
    cout << "the book 2  Id is : "  << book2.bookId<< endl;
    cout <<  "The book 2 price is:" << book2.price << endl;
    cout << "The book 2 pages are: "<< book2.pages << endl;
    }
    return 0;
}