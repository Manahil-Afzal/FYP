/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book
{
int bookid;
float bookprice;
int bookpages;	
};
main ()
{
	book book1,book2;
	cout<<"enter 1st book detail:\n";
	cout<<"enter book id:\n";
	cin>>book1.bookid;
	cout<<"enter book pages:\n";
	cin>>book1.bookpages;
	cout<<"enter book price:\n";
	cin>>book1.bookprice;
	cout<<"\n enter 2nd book detail:\n";
	cout<<"enter book id:\n";
	cin>>book2.bookid;
	cout<<"enter book pages:\n";
	cin>>book2.bookpages;
	cout<<"enter book price:\n";
	cin>>book2.bookprice;
	cout<<"the more costly book record:\n";
     if(book1.bookprice>book2.bookprice)
     cout<<"book id:"<<book1.bookid<<"\nbook pages:"<<book1.bookpages<<"\nbook price:"<<book1.bookprice;
      else
    cout<<"book id:"<<book2.bookid<<"\nbook pages:"<<book2.bookpages<<"\nbook price:"<<book2.bookprice;
}
