/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Book
{
	int BookID;
	float Price;
	int Pages;
};
int main()
{
	Book book1, book2;
	float costly=0;
	cout<<"Enter bookID of book1: "<<endl;
	cin>>book1.BookID;
	cout<<"Enter bookID of book2: "<<endl;
    cin>>book2.BookID;
    
    cout<<"Enter price of book1: "<<endl;
    cin>>book1.Price;
    cout<<"Enter price of book2: "<<endl;
    cin>>book2.Price;
    
    cout<<"Enter the pages of book1: "<<endl;
    cin>>book1.Pages;
    cout<<"Enter the pages of book2: "<<endl;
    cin>>book2.Pages;
    
if(book1.Price>book2.Price)
{
	cout<<"Book1 is costly"<<endl;
	cout<<"The record about book1 is: "<<endl;
	cout<<"Book1 ID is: "<<book1.BookID<<endl;
	cout<<"Book1 price is: "<<book1.Price<<endl;
	cout<<"Book1 pages are: "<<book1.Pages<<endl;
}
else
{
	cout<<"Book2 is costly"<<endl;
	cout<<"The record about book2 is: "<<endl;
	cout<<"Book2 ID is: "<<book2.BookID<<endl;
	cout<<"Book2 price is: "<<book2.Price<<endl;
	cout<<"Book2 pages are: "<<book2.Pages<<endl;
}

}