/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/#include<iostream>
#include<iostream>
using namespace std;
struct Book
{
    int b_id;
    char b_name[30];

    int price;
    };
struct Order
{int i;
   int order_id;
   Book b[100];
};
int main()
{
    Order c;
    cout<<"enter number of books :";
    int n;
    cin>>n;
    cout<<"Enter your Order Id: ";
    cin>>c.order_id;
    cout<<"Enter details of five books: \n";
    for(int i=0;i<n;i++)
{
      cout<<"\nEnter Book Id: ";
      cin>>c.b[i].b_id;
      cout<<"Enter Book Name: ";
      cin>>c.b[i].b_name;
      cout<< " Enter Price of the Book: ";
      cin>>c.b[i].price;
 }
    cout<<"\n Order details is as follows: "<<endl;
    cout<<" Order Id: "<<c.order_id<<endl;
    cout<<" Book Id\t Book Name \t Price "<<endl;
    for(int i=0;i<n;i++)
{
    cout<<c.b[i].b_id<<"\t\t"<<c.b[i].b_name<<"\t\t"<<c.b[i].price<<endl;
}
int i ;
int x=0;
for(int i=0;i<n;i++)
if(c.b[0].price<c.b[i].price)
x=i;
cout<<"most costly book detail is :\n";
cout<<c.b[x].b_id<<"\t\t"<<c.b[x].b_name<<"\t\t"<<c.b[x].price<<endl;
}
