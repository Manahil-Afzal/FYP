/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
struct book{
    string BookId;
    float price;
    int pages;
    
};
int main(){
    book b1,b2;
    cout<<"Enter the Book I'd "<<endl;
    cin.ignore();
    getline(cin,b1.BookId);
    //cin>>b1.BookId;
    cout<<"Enter the price of book "<<endl;
    cin>> b1.price;
    cout<<"Enter the number of pages "<<endl;
    cin>> b1.pages;
    cout<<"Ënter information about second book"<<endl;
    
    cout<<"Enter the Book I'd "<<endl;
    cin.ignore();
    getline(cin, b2.BookId);
    //cin>>b2.BookId;
    cout<<"Enter the price of book "<<endl;
    cin>> b2.price;
    cout<<"Enter the number of pages "<<endl;
    cin>> b2.pages;
    cout<<endl;
    cout<<"The record of more expensive book is: "<<endl;
    
    if(b1.price>b2.price){
    cout<<" BookId : "<<b1.BookId<<endl;
    cout<<"Price : "<<b1.price<<endl;
    cout <<"No. Of Pages : "<<b1.pages<<endl;
    }
    else
    cout<<" BookId : "<<b2.BookId<<endl;
    cout<<"Price : "<<b2.price<<endl;
    cout<< "No. Of Pages: "<<b2.pages<<endl;
    
    
    
    
    return 0;
    
}