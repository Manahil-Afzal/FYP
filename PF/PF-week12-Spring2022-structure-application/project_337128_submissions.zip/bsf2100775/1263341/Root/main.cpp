/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Books
{
    int book_id;
    int book_pages;
    int bookprice;
    };
struct compare
{
   Books b[100];
};
int main()
{
    compare c;
    int n=2;
    cout<<"Enter details of 2  books: \n";
    for(int i=0;i<n;i++)
{
      cout<<"\nEnter Book Id: ";
      cin>>c.b[i].book_id;
      cout<<"Enter Pages: ";
      cin>>c.b[i].book_pages;
      cout<< "Enter Price of the Book: ";
      cin>>c.b[i].bookprice;
 }
    cout<<"\n Books details is as follows: "<<endl;
    cout<<" Book Id\t Book Price \t Price "<<endl;
    for(int i=0;i<n;i++)
{
    cout<<c.b[i].book_id<<"\t\t"<<c.b[i].book_pages<<"\t\t"<<c.b[i].bookprice<<endl;
}
int x=0;
for(int i=0;i<n;i++)
if(c.b[0].bookprice<c.b[i].bookprice)
x=i;
cout<<"most costly book detail is :\n";
cout<<c.b[x].book_id<<"\t\t"<<c.b[x].book_pages<<"\t\t"<<c.b[x].bookprice<<endl;
} 
