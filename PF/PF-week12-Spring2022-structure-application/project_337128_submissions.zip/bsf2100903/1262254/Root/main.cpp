/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>

using namespace std;

struct books
{
	int bookid;
	int price, pagesofbook;
};
int main()
{
	books b1,b2;
	char anykey;
cout << "Enter the data of first book" << endl;
cout << "Enters the first book id : ";
cin >> b1.bookid;
cout << "Enter the price of first book : ";
cin >> b1.price;
cout << "Enter the pages of first book : ";
cin >> b1.pagesofbook;
cout <<endl << "Enter the second book" << endl;
cout << "Enter the second book id : ";
cin >> b2.bookid;
cout << "Enter the price of second book : ";
cin >> b2.price;
cout << "Enter the pages of second book : ";
cin >> b2.pagesofbook;

if (b1.price > b2.price)
{
	cout <<endl<< "Price of the first book is greater then the price of second book" << endl;
	cout << "The rocord of first book is" << endl;
	cout << "First book id="    << b1.bookid << endl;
	cout << "First book price=" << b1.price << endl;
	cout << "First book Pages=" << b1.pagesofbook << endl;
	
}
else if (b1.price == b2.price)
{
	cout <<endl <<"The price of both books are same" << endl;
}
else
{
	cout << endl<<"Price of the second book is greater than the first book" << endl;
	cout << "The rocord of second book is" << endl;
	cout << "Second book id=" << b2.bookid << endl;
	cout << "Second book price=" << b2.price << endl;
	cout << "Second book Pages=" << b2.pagesofbook << endl;
	
}
//system("pause");

return 0;
}