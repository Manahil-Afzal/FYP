/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;

// define structure
struct bookStruct {
    int bookId, pages;
    float price;
};

// function
void display(bookStruct book) {
    cout<<"\t"<<"\t"<<"Displaying the record of most costly book."<<"\t"<<"\t";
    cout<<"Id of costly book is "<<book.bookId<<endl;
    cout<<"Price of costly book is "<<book.price<<endl;
    cout<<"No. of pages of costly book is "<<book.pages<<endl;
}


main()
{
    bookStruct book1, book2;

    cout<<"\t\tBook1 Details\n";
    cout<<"Enter book1 ID: ";
    cin>>book1.bookId;
    
    cout<<"Enter book1 price: ";
    cin>>book1.price;
    
    cout<<"Enter book1 pages: ";
    cin>>book1.pages;
    
    cout<<"\t\tBook2 Details\n";
    cout<<"Enter book2 ID: ";
    cin>>book2.bookId;
    
    cout<<"Enter book2 price: ";
    cin>>book2.price;
    
    cout<<"Enter book2 pages: ";
    cin>>book2.pages;
    
    if (book1.price > book2.price) display(book1);
    else display(book2);
    
    return 0;
}

