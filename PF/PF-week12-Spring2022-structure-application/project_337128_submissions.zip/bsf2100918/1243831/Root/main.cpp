/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;


  struct {
    string BookId;
    int Price;
    int Pages;
  } book1, book2; 
  int main()
  {
      string BookId;
      int Prices;
      int Pages;
      cout<<"enter details about book1"<<endl;
      cin>>book1.BookId;
      cin>>book1.Price;
      cin>> book1.Pages;
  cout<<"enter details about book2"<<endl;
  cin>> book2.BookId;
  cin>> book2.Price;
  cin>> book2.Pages;
 if(book1.Price>book2.Price)
 {
     cout<<"book1 is costly"<<endl;
     cout<<"the records about book1 are :"<<endl;
     cout<<"the BookId of book1 is : "<<book1.BookId<<endl;
     cout<<"the Price of book1 is : "<<book1.Price<<endl;
     cout<<"the pages of book1 are : "<<book1.Pages<<endl;
 }
     else
     {
         cout<<"book2 is costly"<<endl;
     cout<<"the records about book2 are :"<<endl;
     cout<<"the BookId of book2 is : "<<book2.BookId<<endl;
     cout<<"the Price of book2 is : "<<book2.Price<<endl;
     cout<<"the pages of book2 are : "<<book2.Pages<<endl;
     }
 
  return 0;
}
