/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;

struct Book{
	string bookId;
	int price;
	int pages;
}
myBook1, myBook2;
int main()
{
	string bookId;
	int price;
	int pages;
	cout<< "Enter detail about book 1:"<<endl;
	cin>>myBook1.bookId;
	cin>> myBook1.price;
	cin>> myBook1.pages;
	cout<< "Enter the detail of book 2:"<<endl;
	cin>>myBook2.bookId;
	cin>>myBook2.pages;
	cin>>myBook2.pages;
	if( myBook1.price > myBook2.price){
		cout<<"book 1 is costly"<<endl;
		cout<<"the record about book 1 are: "<<endl;
		cout<<" the book 1 Id is:"<<myBook1.bookId<<endl;
		cout<<"The book 1 price is:"<<myBook1.price<<endl;
		cout<<" The book 1 pages are:"<<myBook1.pages<<endl;	
	}
	else {
		cout<<"book 2 is costly"<<endl;
		cout<<"the record about book 2 are: "<<endl;
		cout<<" the book 2 Id is:"<<myBook2.bookId<<endl;
		cout<<"The book 2 price is:"<<myBook2.price<<endl;
		cout<<" The book 2 pages are:"<<myBook2.pages<<endl;
	}
	
}
