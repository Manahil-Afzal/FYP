/*Write a program that defines a structure to store BookId, Price and Pages of a book.
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Books
{
    int book_id;
    char book_name[30];

    int bookprice;
    };
struct Order
{int i;
   int order_id;
   Books b[100];
};
int main()
{
    Order c;
    cout<<"enter number of books :";
    int n;
    cin>>n;
    cout<<"Enter your Order Id: ";
    cin>>c.order_id;
    cout<<"Enter details of  books: \n";
    for(int i=0;i<n;i++)
{
      cout<<"\nEnter Book Id: ";
      cin>>c.b[i].book_id;
      cout<<"Enter Book Name: ";
      cin>>c.b[i].book_name;
      cout<< "Enter Price of the Book: ";
      cin>>c.b[i].bookprice;
 }
    cout<<"\n Order details is as follows: "<<endl;
    cout<<" Order Id: "<<c.order_id<<endl;
    cout<<" Book Id\t Book Name \t Price "<<endl;
    for(int i=0;i<n;i++)
{
    cout<<c.b[i].book_id<<"\t\t"<<c.b[i].book_name<<"\t\t"<<c.b[i].bookprice<<endl;
}
int i ;
int x=0;
for(int i=0;i<n;i++)
if(c.b[0].bookprice<c.b[i].bookprice)
x=i;
cout<<"most costly book detail is :\n";
cout<<c.b[x].book_id<<"\t\t"<<c.b[x].book_name<<"\t\t"<<c.b[x].bookprice<<endl;
}
