/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book
{
    int bookID;
    float price;
    int pages;
};
float max(float a, float b);
int main()
{
    float costy;
    book b1,b2;
    cout<<" Enter the ID of book 1-  ";
    cin>>b1.bookID;
    cout<<" Enter the price of book 1-  ";
    cin>>b1.price;
    cout<<" Enter the number of pages of book 1-  ";
    cin>>b1.pages;
    cout<<" Enter the ID of book 2-  ";
    cin>>b2.bookID;
    cout<<" Enter the price of book 2-  ";
    cin>>b2.price;
    cout<<" Enter the number of pages of book 2-  ";
    cin>>b2.pages;
    if(b1.price>b2 .price)
    {
        cout<<" Book ID "<<b1.bookID;
        cout<<"\n"<<" Book price   "<<b1.price;
        cout<<"\n"<<"Book pages  "<<b1.pages;
    }
    else
    {
        cout<<" Book ID "<<b2.bookID;
        cout<<"\n"<<" Book price   "<<b2.price;
        cout<<"\n"<<"Book pages  "<<b2.pages;
    }
}