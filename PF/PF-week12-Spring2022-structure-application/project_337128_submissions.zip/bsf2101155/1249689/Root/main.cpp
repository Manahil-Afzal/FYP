/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>

using namespace std;

struct books
{
	int bookID;
	int price;
	int pages;
};
int main()
{
	books book1,book2;
	char anykey;
cout << "Enter the data of first book" << endl;
cout << "Enters the first book ID : ";
cin >> book1.bookID;
cout << "Enter the Price of first book : ";
cin >> book1.price;
cout << "Enter the Pages of first book : ";
cin >> book1.pages;
cout <<endl << "Enter the second book" << endl;
cout << "Enter the second book id : ";
cin >> book2.bookID;
cout << "Enter the price of second book : ";
cin >> book2.price;
cout << "Enter the pages of second book : ";
cin >> book2.pages;

if (book1.price > book2.price)
{
	cout <<endl<< "Price of the first book is greater then the price of second book" << endl;
	cout << "The rocord of first book is" << endl;
	cout << "First book id="    << book1.bookID << endl;
	cout << "First book price=" << book1.price << endl;
	cout << "First book Pages=" << book1.pages  << endl;
	
}
else if (book1.price == book2.price)
{
	cout <<endl <<"The price of both books are same" << endl;
}
else
{
	cout << endl<<"Price of the second book is greater than the first book" << endl;
	cout << "The rocord of second book is" << endl;
	cout << "Second book id=" << book2.bookID<< endl;
	cout << "Second book price=" << book2.price << endl;
	cout << "Second book Pages=" << book2.pages << endl;
	
}


return 0;
}