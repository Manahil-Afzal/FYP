/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
	string BookId;
	int Price;
	int Pages;
};	
int main()
{
	book book1,book2;
	
	cout<<"Enter the information about book1:"<<endl;
	cout<<"----------------------------------"<<endl;
	cout<<"Enter the  BookId: ";
	cin>>book1.BookId;
	cout<<"Enter the Price: ";
	cin>>book1.Price;
	cout<<"Enter the Pages: ";
	cin>>book1.Pages;
	
	cout<<"\nEnter the information about book2:"<<endl;
	cout<<"------------------------------------"<<endl;
	cout<<"Enter the BookId: ";
	cin>>book2.BookId;
	cout<<"Enter the Price: ";
	cin>>book2.Price;
	cout<<"Enter the Pages: ";
	cin>>book2.Pages;
	
	if(book1.Price>book2.Price)
	{	
		cout<<"\nbook1 is more costly than book2.";
	}
	else
		cout<<"\nbook2 is more costly than book1.";
		
	return 0;
}
	
	
	