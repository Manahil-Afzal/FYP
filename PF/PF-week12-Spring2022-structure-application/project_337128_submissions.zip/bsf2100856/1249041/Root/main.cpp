/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book
{
    string bookId;
    int price;
    int pages;
};
int main()
{
    book book1,book2;
    cout<<"enter the information about book1:";
    cout<<"enter the bookId:";
    cin>>book1.bookId;
    cout<<"enter the price:";
    cin>>book1.price;
    cout<<"enter the pages:";
    cin>>book1.pages;
    
    cout<<"enter the information about book2:";
    cout<<"enter the bookId:";
    cin>>book2.bookId;
    cout<<"enter the price:";
    cin>>book2.price;
    cout<<"enter the pages:";
    cin>>book2.pages;
    
    if(book1.price<book2.price)
    {
        cout<<"book1 i costly then book2:";}
        else
        cout<<"book2 is costly then book1:";
        return 0;
}
