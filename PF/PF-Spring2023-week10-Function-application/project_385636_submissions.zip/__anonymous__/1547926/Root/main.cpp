/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
int small(int a,int b,int c);
int large(int a,int b,int c);
int average (int a,int b,int c);
main(){
    int x=1,y=4,z=6,sma,lar,ave;
    sma=small(x,y,z);
    lar=large(x,y,z);
    ave=average(x,y,z);
    cout<<"small number"<<sma<<endl;
    cout<<"large number "<<lar<<endl;
    cout<<"average "<<ave<<endl;
    
    
}
int small(int a,int b,int c){
    if(a<b&&a<c){
    return a;
    }
    if(b<a&&b<c){
    return b;}
    if(c<b&&c<a){
    return c;
    }
}
    int large(int a,int b,int c){
        if(a>b&&a>c){
    return a;
    }
    if(b>a&&b>c){
    return b;}
    if(c>b&&c>a){
    return c;
    }
    
}
int average (int a,int b,int c){
    return(a+b+c)/3;
}