/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

// Function to calculate and return the average of three numbers
double average(double x, double y, double z) {
    return (x + y + z) / 3.0;
}

// Function to find and return the smallest of three numbers
double smallest(double x, double y, double z) {
    double smallest = x;
    if (y < smallest) {
        smallest = y;
    }
    if (z < smallest) {
        smallest = z;
    }
    return smallest;
}

// Function to find and return the largest of three numbers
double largest(double x, double y, double z) {
    double largest = x;
    if (y > largest) {
        largest = y;
    }
    if (z > largest) {
        largest = z;
    }
    return largest;
}

int main() {
    double num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    // Display the average, smallest and largest of the three numbers
    cout << "Average of the numbers = " << average(num1, num2, num3) << endl;
    cout << "Smallest of the numbers = " << smallest(num1, num2, num3) << endl;
    cout << "Largest of the numbers = " << largest(num1, num2, num3) << endl;

    return 0;
}
