#include <iostream>
using namespace std;

// Function to calculate the average
double calculateAverage(double num1, double num2, double num3) {
    return (num1 + num2 + num3) / 3;
}

// Function to find the smallest number
double findSmallest(double num1, double num2, double num3) {
    return min(min(num1, num2), num3);
}

// Function to find the largest number
double findLargest(double num1, double num2, double num3) {
    return max(max(num1, num2), num3);
}

int main() {
    double num1, num2, num3;

    // Input three numbers
    cout << "Enter the first number: ";
    cin >> num1;
    cout << "Enter the second number: ";
    cin >> num2;
    cout << "Enter the third number: ";
    cin >> num3;

    // Calculate and display the average
    double average = calculateAverage(num1, num2, num3);
    cout << "Average: " << average << endl;

    // Find and display the smallest
    double smallest = findSmallest(num1, num2, num3);
    cout << "Smallest: " << smallest << endl;

    // Find and display the largest
    double largest = findLargest(num1, num2, num3);
    cout << "Largest: " << largest << endl;

    return 0;
}/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/