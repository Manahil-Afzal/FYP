/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;

int mini(int num1,int num2,int num3){
    if(num1<=num2&&num1<=num3){
     return num1;
    }
    else if(num2<=num1&&num2<=3){
     return num2;}
     else {
         return num3;
     }
    
    
} 
 int maxi(int num1,int num2,int num3){
    if(num1>=num2&&num1>=num3){
     return num1;
    }
    else if(num2>=num1&&num2>=3){
     return num2;}
     else {
         return num3;
     }
    
    
}

float average(int num1,int num2,int num3){
    return (num1+num2+num3)/3;
}
int main()
{
 int num1,num2,num3;
 cin>>num1;
 cin>>num2;
 cin>>num3;
 int min=mini(num1,num2,num3);
 cout<<"minimum = "<<min;
int max=maxi(num1,num2,num3);
cout<<" maximum= "<<max;
float avg=average(num1,num2,num3);
cout<<" average= "<<avg;

}
 
    

    