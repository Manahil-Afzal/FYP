#include <iostream>
using namespace std;

// Function to calculate average of three numbers
double average(double num1, double num2, double num3)
{
    return (num1 + num2 + num3) / 3.0;
}

// Function to find smallest of three numbers
double smallest(double num1, double num2, double num3)
{
    double min = num1;

    if (num2 < min)
        min = num2;
    if (num3 < min)
        min = num3;

    return min;
}

// Function to find largest of three numbers
double largest(double num1, double num2, double num3)
{
    double max = num1;

    if (num2 > max)
        max = num2;
    if (num3 > max)
        max = num3;

    return max;
}

int main()
{
    double num1, num2, num3;

    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    cout << "Average: " << average(num1, num2, num3) << endl;
    cout << "Smallest: " << smallest(num1, num2, num3) << endl;
    cout << "Largest: " << largest(num1, num2, num3) << endl;

    return 0;
}
