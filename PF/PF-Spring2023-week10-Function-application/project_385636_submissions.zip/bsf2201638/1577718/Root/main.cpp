/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>

using namespace std;
int avrage(int a,int b,int c){
    int result;
    result=a+b+c/3;
    cout<<"\nThe average is :"<<result<<endl;

}
int  small(int a,int b, int c){
    if(a<b&&a<c)
        cout<<"the small number is:"<<a<<endl;
    else if(b<a&&b<c)
        cout<<"the small number is"<<b<<endl;
    else
        cout<<"the small number is:"<<c<<endl;
}
int largest(int a,int b, int c){
    if(a>b&&a>c)
        cout<<"the largest number is:"<<a<<endl;
    else if(b>a&&b>c)
        cout<<"the largest number is"<<b<<endl;
    else
        cout<<"the largest number is:"<<c<<endl;
}


int main()
{
    int x,y,z;
    cout << "enter the first number" << endl;
    cin>>x;
     cout << "enter the second number" << endl;
    cin>>y;
     cout << "enter the third number" << endl;
    cin>>z;
    avrage(x,y,z);
     small(x,y,z);
     largest(x,y,z);
    return 0;
}
