/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

// Function to calculate the average of three numbers
double average(double num1, double num2, double num3) {
    double sum = num1 + num2 + num3;
    double avg = sum / 3.0;
    return avg;
}

// Function to find the smallest of three numbers
double smallest(double num1, double num2, double num3) {
    double smallest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    return smallest;
}

// Function to find the largest of three numbers
double largest(double num1, double num2, double num3) {
    double largest = num1;
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    return largest;
}

int main() {
    double num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    // Call the average function and display the result
    double avg = average(num1, num2, num3);
    cout << "The average is " << avg << endl;

    // Call the smallest function and display the result
    double smallest_num = smallest(num1, num2, num3);
    cout << "The smallest number is " << smallest_num << endl;

    // Call the largest function and display the result
    double largest_num = largest(num1, num2, num3);
    cout << "The largest number is " << largest_num << endl;

    return 0;
}
