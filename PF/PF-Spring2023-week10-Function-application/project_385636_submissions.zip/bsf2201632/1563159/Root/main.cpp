/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;

double average(double num1,double num2,double num3){
    return (num1+num2+num3)/3;
    
}
double smallest(double num1,double num2,double num3){
    double min= num1;
    if(num2<min){
        min=num2;
    }
    if(num3<min){
        min=num3;
    }
    return min;
}
double largest(double num1,double num2,double num3){
    double max= num1;
    if(num2>max){
        max=num2;
    }
    if(num3>max){
        max=num3;
    }
    return max;
}
int main(){
    double num1,num2,num3;
    cout<<"Enter Number 1:"<<endl;
    cin>>num1;
    cout<<"Enter Number 2:"<<endl;
    cin>>num2;
    cout<<"Enter Number 3:"<<endl;
    cin>>num3;
    cout<<"Average is:"<<average(num1,num2,num3)<<endl;
    cout<<"Smallest Number is:"<<smallest(num1,num2,num3)<<endl;
    cout<<"Largest Number is:"<<largest(num1,num2,num3)<<endl;
    
    return 0;
}