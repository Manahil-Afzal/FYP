/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

// Function prototypes
double average(double num1, double num2, double num3);
double smallest(double num1, double num2, double num3);
double largest(double num1, double num2, double num3);

int main() {
    double num1, num2, num3;

    // Input the three numbers
    cout << "Enter the first number: ";
    cin >> num1;
    cout << "Enter the second number: ";
    cin >> num2;
    cout << "Enter the third number: ";
    cin >> num3;

    // Display the results
    cout << "The average is: " << average(num1, num2, num3) << endl;
    cout << "The smallest number is: " << smallest(num1, num2, num3) << endl;
    cout << "The largest number is: " << largest(num1, num2, num3) << endl;

    return 0;
}

// Function to calculate the average of three numbers
double average(double num1, double num2, double num3) {
    return (num1 + num2 + num3) / 3.0;
}

// Function to find the smallest of three numbers
double smallest(double num1, double num2, double num3) {
    double smallest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    return smallest;
}

// Function to find the largest of three numbers
double largest(double num1, double num2, double num3) {
    double largest = num1;
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    return largest;
}