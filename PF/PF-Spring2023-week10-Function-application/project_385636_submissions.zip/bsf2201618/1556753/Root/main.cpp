/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
double avg(double a,double b,double c);
int small(int,int,int);
int large(int,int,int);
main()
{
    double y,g,v;
    cout<<"Enter three numbers:"<<endl;
    cin>>y>>g>>v;
    cout<<"average of numbers is:"<<avg(y,g,v)<<endl;
    cout<<"large number is:"<<large(y,g,v)<<endl;
    cout<<"smallest number is:"<<small(y,g,v)<<endl;
    
}
double avg(double a, double b,double c)
{
    return(a+b+c)/3;
}
int large (int a,int b,int c)
{
    if(a>b&&a>c)
    return a;
    else if(b>a&&b>c)
    return b;
    else 
    return c;
}
int small(int a,int b,int c)
{
    if(a<b&&a<c)
    return a;
    else if (b<a&&b<c)
    return b;
    else
    return c;
}