/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

// Function to calculate average of three numbers
double average(double num1, double num2, double num3) {
    return (num1 + num2 + num3) / 3;
}

// Function to find the smallest of three numbers
double smallest(double num1, double num2, double num3) {
    if (num1 <= num2 && num1 <= num3) {
        return num1;
    } else if (num2 <= num1 && num2 <= num3) {
        return num2;
    } else {
        return num3;
    }
}

// Function to find the largest of three numbers
double largest(double num1, double num2, double num3) {
    if (num1 >= num2 && num1 >= num3) {
        return num1;
    } else if (num2 >= num1 && num2 >= num3) {
        return num2;
    } else {
        return num3;
    }
}

int main() {
    double num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    cout << "Average: " << average(num1, num2, num3) << endl;
    cout << "Smallest: " << smallest(num1, num2, num3) << endl;
    cout << "Largest: " << largest(num1, num2, num3) << endl;

    return 0;
}
