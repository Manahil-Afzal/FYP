/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

// Function to calculate average
double calculateAverage(double num1, double num2, double num3) {
    return (num1 + num2 + num3) / 3.0;
}

// Function to find smallest number
double findSmallest(double num1, double num2, double num3) {
    double smallest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    return smallest;
}

// Function to find largest number
double findLargest(double num1, double num2, double num3) {
    double largest = num1;
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    return largest;
}

int main() {
    double num1, num2, num3;

    // Input three numbers
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    // Call functions to calculate and display average, smallest, and largest numbers
    double avg = calculateAverage(num1, num2, num3);
    cout << "Average: " << avg << endl;

    double smallest = findSmallest(num1, num2, num3);
    cout << "Smallest number: " << smallest << endl;

    double largest = findLargest(num1, num2, num3);
    cout << "Largest number: " << largest << endl;

    return 0;
}
