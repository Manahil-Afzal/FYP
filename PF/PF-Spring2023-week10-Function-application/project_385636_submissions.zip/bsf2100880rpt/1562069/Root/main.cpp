/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
int avg (int a, int b, int c);
int sml (int a, int b, int c);
int lrg (int a, int b, int c);
int main()
{
    int num1, num2, num3;
    cout<<"Enter the first digit :"<<endl;
    cin>>num1;
    cout<<"Enter the second digit : "<<endl;
    cin>>num2;
    cout<<"Enter the third digit :"<<endl;
    cin>>num3;
    avg(num1,num2,num3);
    sml(num1,num2,num3);
    lrg(num1,num2,num3);
}
int avg(int a , int b, int c) {
    int sum, avg ;
    sum = a+b+c;
    avg = sum / 3;
    cout<<"The average of three numbers is: "<<avg<<endl;
}
int sml(int a, int b,int c) {
    if(a < b && a < c)
    cout<<"The smallest number is :"<<a <<endl;
    else if (b < c && a < c)
    cout<<"The smallest number is :"<<b<<endl;
    else
    cout<<"The smallest number is:"<<c<<endl;
}
int lrg(int a, int b, int c) {
    if(a>=b && a>=c)
    cout<<"The largest number is :"<<a<<endl;
    else if(b>a && b>c)
    cout<<"The largest number is : "<<b<<endl;
    else
    cout<<"The largest number is: "<<c<<endl;
}