/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers*/

#include <iostream>
using namespace std;

// Function prototypes
double average(double g, double f, double h);
double smallest(double g, double f , double h);
double largest(double g , double f, double h);

int main()
{
    double x, y, z;
    cout << "Enter three numbers: ";
    cin >> x >> y >> z;
    cout << "Average: " << average(x, y, z) << endl;
    cout << "Smallest: " << smallest(x, y, z) << endl;
    cout << "Largest: " << largest(x, y, z) << endl;
    
    return 0;
}

double average(double g, double f, double h)
{
    return (g + f + h) / 3;
}

double smallest(double g, double f, double h)
{
    double smallest = g;
    
    if (f < smallest) {
        smallest = f;
    }
    
    if (h < smallest) {
        smallest =h;
    }
    
    return smallest;
}

double largest(double g, double f, double h)
{
    double largest = g;
    
    if (f > largest) {
        largest = f;
    }
    
    if (h > largest) {
        largest = h;
    }
    
    return largest;
}
