/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/

#include<iostream>
using namespace std;
double calculateAverage(double, double, double);
double findSmallest(double, double, double);
double findLargest(double, double, double);
int main()
{
	double num1, num2, num3;
	cout<<"Enter three numbers: ";
	cin>>num1 >>num2 >>num3;
	cout<<"Average: "<<calculateAverage(num1, num2, num3)<<endl;
	cout<<"Smallest: "<<findSmallest(num1, num2, num3)<<endl;
	cout<<"Largest: "<<findLargest(num1, num2, num3)<<endl;
	return 0;
}
    double calculateAverage(double num1, double num2, double num3){
       return (num1+num2+num3)/3;
	}
	double findSmallest(double num1, double num2, double num3){
		double smallest= num1;
		if(num2 < smallest){
			smallest= num2;
		}
		if (num3 < smallest){
			smallest= num3;
		}
		return smallest;   
	}
	double findLargest(double num1, double num2, double num3){
		double largest= num1;
		if(num2> largest){
			largest = num2;
		if(num3 > largest){
			largest = num3;
		}
		return largest;
		}
}