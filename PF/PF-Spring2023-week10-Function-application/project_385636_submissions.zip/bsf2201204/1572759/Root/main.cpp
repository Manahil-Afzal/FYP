/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>

using namespace std;

// Function to calculate and display the average of three numbers
void calculateAverage(int num1, int num2, int num3) {
    float avg = (num1 + num2 + num3) / 3.0;
    cout << "The average of " << num1 << ", " << num2 << ", and " << num3 << " is " << avg << endl;
}

// Function to find and display the smallest of three numbers
void findSmallest(int num1, int num2, int num3) {
    int smallest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    cout << "The smallest of " << num1 << ", " << num2 << ", and " << num3 << " is " << smallest << endl;
}

// Function to find and display the largest of three numbers
void findLargest(int num1, int num2, int num3) {
    int largest = num1;
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    cout << "The largest of " << num1 << ", " << num2 << ", and " << num3 << " is " << largest << endl;
}

int main() {
    int num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;
    calculateAverage(num1, num2, num3);
    findSmallest(num1, num2, num3);
    findLargest(num1, num2, num3);
    return 0;
}