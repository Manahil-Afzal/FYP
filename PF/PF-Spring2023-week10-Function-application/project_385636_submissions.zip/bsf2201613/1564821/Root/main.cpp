/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

double average(double num1, double num2, double num3) {
    double avg = (num1 + num2 + num3) / 3;
    return avg;
}
double smallest(double num1, double num2, double num3) {
    double minNum = num1;
    if (num2 < minNum) {
        minNum = num2;
    }
    if (num3 < minNum) {
        minNum = num3;
    }
    return minNum;
}
double largest(double num1, double num2, double num3) {
    double maxNum = num1;
    if (num2 > maxNum) {
        maxNum = num2;
    }
    if (num3 > maxNum) {
        maxNum = num3;
    }
    return maxNum;
}

int main() {
    double num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;
    cout << "Average: " << average(num1, num2, num3) << endl;
    cout << "Smallest: " << smallest(num1, num2, num3) << endl;
    cout << "Largest: " << largest(num1, num2, num3) << endl;

    return 0;
}
