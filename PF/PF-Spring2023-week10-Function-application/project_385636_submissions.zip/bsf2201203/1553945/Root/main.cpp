/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;

float average(int, int, int);
int small(int, int, int);
int large(int, int, int);

int main(){
    int a, b, c, sml, lrg;
    float avg;
    cout<<"Enter three numbers: "<<endl;
    cin>>a>>b>>c;
    avg = average(a,b,c);
    sml = small(a,b,c);
    lrg = large(a,b,c);
    cout<<"Average of three numbers is: "<<avg<<endl;
    cout<<"Smallest of three numbers is: "<<sml<<endl;
    cout<<"Largest of three numbers is: "<< lrg<<endl;
    return 0;
    }
    
float average(int a, int b, int c){
     int sum;
     sum = a + b + c;
     return sum/3;
}

int small(int a, int b, int c){
    int sml;
    if (a<b && a<c){
        sml = a;
    }else if(b<a && b<c){
        sml = b;
    }else{
        sml = c;
    }
    return sml;
}

int large( int a, int b, int c){
    int lrg;
    if (a>b && a>c){
        lrg = a;
    }else if(b>a && b>c){
        lrg = b;
    }else{
        lrg = c;
    }
    return lrg;
}
