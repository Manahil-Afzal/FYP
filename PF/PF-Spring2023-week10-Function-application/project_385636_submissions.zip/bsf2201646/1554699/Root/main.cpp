/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/

#include <iostream>
using namespace std;


double average(double a, double b, double c) {
    return (a + b + c) / 3.0;
}


double smallest(double a, double b, double c) {
    if (a <= b && a <= c) {
        return a;
    } else if (b <= a && b <= c) {
        return b;
    } else {
        return c;
    }
}


double largest(double a, double b, double c) {
    if (a >= b && a >= c) {
        return a;
    } else if (b >= a && b >= c) {
        return b;
    } else {
        return c;
    }
}

int main() {
    double a, b, c;
    cout << "Enter three numbers: ";
    cin >> a >> b >> c;
   
    double avg = average(a, b, c);
    cout << "Average: " << avg << endl;

    double small = smallest(a, b, c);
    cout << "Smallest: " << small << endl;

    double large = largest(a, b, c);
    cout << "Largest: " << large << endl;

    
}
