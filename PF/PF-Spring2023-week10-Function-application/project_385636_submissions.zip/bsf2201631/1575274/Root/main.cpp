/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;
double calculateavg(double num1,double num2,double num3){
  return (num1+num2+num3)/3;
}
int large(double num1,double num2,double num3){
  int large=num1;
  if(num2>large){
     large=num2;
  }
  if(num3>large){
    large=num3;
  }
}
int small(double num1,double num2,double num3){
  int small=num1;
  if(num2<small){
     small=num2;
  }
  if(num3<small){
    small=num3;
  }
}
int main(){
  int num1,num2,num3;
  cout<<"enter the no 1"<<endl;
  cin>>num1;
    cout<<"enter the no 2"<<endl;
    cin>>num2;
    cout<<"enter the no 3"<<endl;
    cin>>num3;
  float avg=calculateavg(num1,num2,num3);
  cout<<avg;
  int lar=large(num1,num2,num3);
  cout<<lar;
  int sma=small(num1,num2,num3);
  cout<<sma;


  return 0;
}
