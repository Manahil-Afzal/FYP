/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
int max(int,int,int);
int min(int,int,int);
int sum(int,int,int);
int Ave(int,int,int);
int main()
{
  int x,y,z,maxmium,minimum,sum;
  
  float Average;
  
  cout<<"Enter three Number=";
  cin>>x>>y>>z;
  minimum=min(x,y,z);
  cout<<"Minimum num is="<<minimum<<"\n";
  sum=x+y+z;
  cout<<"Total sum is="<<sum<<"\n";
}
 int max(int a,int b,int c)
 {
     if(a>b && a>c)
     return a;
     if(b>a && b>c)
     return b;
     else
     return c;
 }
 int min(int a,int b,int c)
 {
     if(a<b && a<c)
     return a;
     if(b<a && b<c)
     return b;
     if(c<a && c<b)
     return c;
 }
 int sum(int a,int b,int c)
 {
     int Submission;
     Submission=a+b+c;
     return Submission;
 }
 int Ave(int a,int b,int c)
 {
     int Add,Ave;
     Add=a+b+c;
     Ave=Add/3;
     return Ave;
 }

        
      
   
   
    

