/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;
double average(double a, double b, double c) {
    return (a + b + c) / 3.0;
}
double smallest(double a, double b, double c) {
    double min_val = a;
    if (b < min_val) {
        min_val = b;
    }
    if (c < min_val) {
        min_val = c;
    }
    return min_val;
}
double largest(double a, double b, double c) {
    double max_val = a;
    if (b > max_val) {
        max_val = b;
    }
    if (c > max_val) {
        max_val = c;
    }
    return max_val;
}

int main() {
    double num1, num2, num3;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;
    cout << "Average: " << average(num1, num2, num3) << endl;
    cout << "Smallest: " << smallest(num1, num2, num3) << endl;
    cout << "Largest: " << largest(num1, num2, num3) << endl;

    return 0;
}