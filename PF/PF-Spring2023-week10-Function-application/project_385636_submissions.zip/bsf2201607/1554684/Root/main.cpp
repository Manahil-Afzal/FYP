/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

// Function to calculate the average of three numbers
double calcAverage(double num1, double num2, double num3)
{
    double average = (num1 + num2 + num3) / 3;
    return average;
}

// Function to calculate the smallest of three numbers
double calcSmallest(double num1, double num2, double num3)
{
    double smallest = num1;
    if (num2 < smallest)
    {
        smallest = num2;
    }
    if (num3 < smallest)
    {
        smallest = num3;
    }
    return smallest;
}

// Function to calculate the largest of three numbers
double calcLargest(double num1, double num2, double num3)
{
    double largest = num1;
    if (num2 > largest)
    {
        largest = num2;
    }
    if (num3 > largest)
    {
        largest = num3;
    }
    return largest;
}

int main()
{
    double num1, num2, num3;

    // Prompt the user to enter three numbers
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    // Calculate and display the average
    double average = calcAverage(num1, num2, num3);
    cout << "The average of the three numbers is: " << average << endl;

    // Calculate and display the smallest
    double smallest = calcSmallest(num1, num2, num3);
    cout << "The smallest of the three numbers is: " << smallest << endl;

    // Calculate and display the largest
    double largest = calcLargest(num1, num2, num3);
    cout << "The largest of the three numbers is: " << largest << endl;

    return 0;
}