/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/

#include <iostream>
using namespace std;

void getNumbers(int& a, int& b, int& c) {
    cout << "Enter three numbers: ";
    cin >> a >> b >> c;
}

double calculateAverage(int a, int b, int c) {
    return static_cast<double>(a + b + c) / 3;
}

int findSmallest(int a, int b, int c) {
    int smallest = a;
    if (b < smallest) {
        smallest = b;
    }
    if (c < smallest) {
        smallest = c;
    }
    return smallest;
}

int findLargest(int a, int b, int c) {
    int largest = a;
    if (b > largest) {
        largest = b;
    }
    if (c > largest) {
        largest = c;
    }
    return largest;
}

int main() {
    int a, b, c;
    getNumbers(a, b, c);
    
    double average = calculateAverage(a, b, c);
    int smallest = findSmallest(a, b, c);
    int largest = findLargest(a, b, c);
    
    cout << "The average of the three numbers is " << average << endl;
    cout << "The smallest of the three numbers is " << smallest << endl;
    cout << "The largest of the three numbers is " << largest << endl;
    
    return 0;
}
