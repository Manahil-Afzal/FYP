//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main ()
{
    int x,y,result;
    cout<<"enter the value of x : "<<endl;
    cin>>x;
    cout<<"enter the value of y : "<<endl;
    cin>>y;
    result=y-x;
    cout<<"The result is = "<<result<<endl;
    return 0;
    
/*  enter the value of x : 4
    enter the value of y : 6
    The result is = 2    */
}