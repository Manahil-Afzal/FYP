//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int num1=0, num2=0;
    cout<<"Enter first integer value ";
    cin>>num1;
    cout<<"\nEnter second integer value ";
    cin>>num2;
    cout<<"\nThe answer is "<<num1-num2;
}