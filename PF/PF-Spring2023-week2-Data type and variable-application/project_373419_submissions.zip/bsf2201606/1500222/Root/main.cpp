//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x,y;
    cout<<"Enter the first number";
    cin>>x;
    cout<<"Enter the second number";
    cin>>y;
    cout<<"The subtraction of x and y is ="<<x-y<<endl;
    
}
