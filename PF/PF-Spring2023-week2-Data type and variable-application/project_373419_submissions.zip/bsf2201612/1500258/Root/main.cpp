//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int a,b,sub;
    cout<<"enter first num"<<a;
    cin>>a;
    cout<<"enter second num"<<b;
    cin>>b;
    sub=b-a;
    cout<<"result of subtracting first from second"<<sub;
}