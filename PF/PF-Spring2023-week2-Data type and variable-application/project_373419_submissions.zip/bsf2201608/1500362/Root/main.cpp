//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second num
#include <iostream>
using namespace std;
 int main()
    {
        int x,y;
        int subtract;
        cout<<"enter the first number";
        cin>>x;
        cout<<"enter the second number";
        cin>>y;
        subtract=y-x;
        cout<<"subtract first number from second number"<<subtract;
    }
        
        
