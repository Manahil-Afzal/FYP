//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{ int a,b;
    cout<<"enter the value of a = ";
    cin>>a;
    cout<<"\nenter the value of b = ";
    cin>>b;
    cout<<"the subtraction is : "<<b-a;
}