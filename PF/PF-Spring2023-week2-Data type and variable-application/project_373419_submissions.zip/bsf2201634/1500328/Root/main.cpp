//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
 int main()
{
    int x=0,y=0;
    int subtract=0;
    cout<<"enter value of x";
    cin>>x;
    cout<<"enter value of y";
    cin>>y;
    subtract =y-x;
    cout<<"y-x="<<subtract;
}