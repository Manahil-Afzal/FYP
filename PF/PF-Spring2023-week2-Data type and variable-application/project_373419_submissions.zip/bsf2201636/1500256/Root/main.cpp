//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int a,b,sub;
    cout<<"enter first number"<<a;
    cin>>a;
    cout<<"enter second number"<<b;
    cin>>b;
    sub=b-a;
    cout<<"result after subtracting first number from second"<<sub;
}