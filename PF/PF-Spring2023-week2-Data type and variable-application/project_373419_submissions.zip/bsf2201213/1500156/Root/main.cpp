#include<iostream>
using namespace std;
int main (){
    int a;// program for difference
    int b;
    cout<<"enter the value of a ";
    cin>>a;
    cout <<"enter the value of b ";
    cin>>b;
    cout<<"diff of value "<< a-b;
    
}