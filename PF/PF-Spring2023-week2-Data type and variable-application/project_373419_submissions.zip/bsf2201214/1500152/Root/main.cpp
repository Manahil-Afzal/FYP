//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
 int x,y;
 cout<<"Enter the value of x";
 cin>>x;
 cout<<"Enter the value of y";
 cin>>y;
 cout<<"subtration is:"<<y-x;
}