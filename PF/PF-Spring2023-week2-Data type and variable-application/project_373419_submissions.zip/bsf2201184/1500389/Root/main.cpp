//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>

using namespace std;

main()
{
    int a,b=0;
    cout<<"enter first num";
    cin>>a;
    cout<<"enter second num";
    cin>>b;
    cout<<"subtract first num from second num"<<b-a;
    
}
