//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.5
#include<iostream>
using namespace std;
main()
{
    int a,b;
    cout << "enter two numbers";
    cin >> a >> b;
    cout << "b-a is " << b-a;

}