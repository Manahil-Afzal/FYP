//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x=0;
    int y=0;
    int sub=0;
    cout<<"enter the value of x";
    cin>> x;
    cout<<"enter the value of y";
    cin>>y;
    sub=x-y;
    cout<<"value of sub is;"<<sub;
    
}
