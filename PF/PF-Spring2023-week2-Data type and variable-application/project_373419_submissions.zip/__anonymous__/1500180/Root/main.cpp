//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;

main(){
    int a,b,subtract;
    cout<<"Enter First Number: = ";
    cin>>a;
    cout<<"Enter Second Number: = ";
    cin>>b;
    subtract =a-b;
     cout<<"Enter difference of a and b : = "<<subtract;
}