//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
 int main()
{
int x,y;
 int difference=0;
 cout<<"enter first number";
 cin>>x;
 cout<<"enter second number";
 cin>>y;
 cout<<"difference = "<<x-y;
 }