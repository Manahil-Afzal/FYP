//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
# include<iostream>
using namespace std;
 main(){
    int x=0,y=0;
    cout <<"enter the first number x:";
    cin>> x;
    cout<<"Enter the seccnd numbergreater than first y:"<<endl;
    cin >>y;
    cout<<"the subtractin of two numbers is:"<<y-x<<endl;
}