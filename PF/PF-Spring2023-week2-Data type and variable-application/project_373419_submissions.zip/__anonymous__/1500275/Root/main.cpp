//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;
int main(){
    int x,y;
    cout<<"Enter A Number";
    cin>>x;
    cout<<"Enter An Other Number";
    cin>>y;
    cout<<"Subtraction of " << x <<" and " << y <<" is " <<x-y;
    return 0;
}