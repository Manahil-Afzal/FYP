#include<iostream>
using namespace std;
main()
{
    int a=0;
    int b=0;
    int subtract=0;
    cout<<"Enter value of a";
    cin>>a;
    cout<<"\n Enter value of b";
    cin>>b;
    subtract=a-b;
    cout<<"\n subtracting a from b is"<<subtract;
}//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.