//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std ;
main()
{
    int x=0;
     int y=0;
    cout<<"enter value of x";//insertion operator 
    cin>>x;
    cout<<"enter value of y";//ectraction operator
    cin>>y;
    cout<<"sub x from y"<<y-x;
}