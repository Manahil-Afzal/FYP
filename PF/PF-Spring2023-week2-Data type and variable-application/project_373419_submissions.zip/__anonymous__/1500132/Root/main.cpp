#include<iostream>
using namespace std;
int main()
{
    // program to find difference
    int x,y,diff;
    cout<<"enter the value of x";
    cin>>x;
    cout<<"enter the value of y";
    cin>>y;
    diff=y-x;
    cout<<"diff of values is"<<diff;
    return 0;
}