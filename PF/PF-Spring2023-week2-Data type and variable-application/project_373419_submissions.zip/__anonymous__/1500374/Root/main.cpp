//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int y=0;
    int x=0;
    int sub=0;
    cout<<"enter the value for y";
    cin>>y;
    cout<<"enter the value for x";
    cin>>x;
    sub=y-x;
    cout<<"value of sub is;"<<sub;
}