#include<iostream>
using namespace std;
main()
{
    // program to find difference
    int x,y;
    cout<<"enter the value of x ";
    cin>>x;
    cout<<"enter value of y";
    cin>>y;
    cout<<"diff is "<<endl<<y-x;
}
