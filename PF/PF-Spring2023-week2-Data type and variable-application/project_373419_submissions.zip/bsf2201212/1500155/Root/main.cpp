//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x=0;
    int y=0;
    int subt=0;
    cout<<"enter the value for x";
    cin>>x;
    cout<<"\n enter the value for y";
    cin>>y;
    subt=x-y;
    cout<<"\n value of subt is;"<<x-y;
}