//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;

main()

{
   int A;
   int B;
  
    cout << "Enter First Integer:";
    cin >> A;
    cout << "Enter second Integer:";
    cin >> B;
    int sum= A+B;
    cout<<"The sum of given two integers is:" ;
    cout<< sum;
    
    
}