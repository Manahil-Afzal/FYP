//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int X=0,Y=0;
    int sub=0;
    cout<<"enter value of X";
    cin>>X;
    cout<<"enter value of Y";
    cin>>Y;
    sub=Y-X;
    cout<<"Y-X="<<sub;
}