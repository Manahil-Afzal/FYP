//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
int x=0;
int y=0;
int subtract=0;
cout<<"Enter value for x ";
cin>>x;
cout<<"/n value for y ";
cin>>y;
subtract=x-y;
cout<<"/n value of sum is:"<<subtract;

}