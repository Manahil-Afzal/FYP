//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int a =0 ,b=0;
    int sub=0;
    cout<<"please entre the first integer a";
    cin>>a;
    cout<<"please entre the second integer b";
    cin>>b;
    cout<<"the result of two numbers after subtraction"<<a-b;

    
}