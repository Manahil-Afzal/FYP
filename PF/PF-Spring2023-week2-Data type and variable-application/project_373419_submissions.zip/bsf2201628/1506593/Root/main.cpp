//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main(){
    int x,y;
    cout<<"Enter the value of first number x is ";
    cin>>x;
    cout<<"Enter the value of secnd number y is   ";
    cin>>y;
    int sub=y-x;
    cout<<"y-x= "<<sub;
    
}