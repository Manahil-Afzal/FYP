//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x=0;
    int y=0;
    int substract=0;
    cout<<"Enter the First valu for x";
    cin>>x;
    cout<<"Enter the second value for y";
    cin>>y;
    substract=x-y;
    cout<<"substracted resut is "<<substract;
}