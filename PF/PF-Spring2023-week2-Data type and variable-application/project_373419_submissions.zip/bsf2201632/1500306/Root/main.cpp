//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
	int firstnum=0;
	int secondnum=0;
	int substract=0;
	cout<<"enter the value of secondnum";
	cin>>secondnum;
	cout<<"enter the value of firstnum";
	cin>>firstnum;
	substract= secondnum-firstnum;
	cout<<"value of substract is;"<<substract;
	
}