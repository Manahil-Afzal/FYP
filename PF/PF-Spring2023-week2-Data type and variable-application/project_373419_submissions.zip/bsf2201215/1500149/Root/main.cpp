//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x=0;
    int y=0;
    int subt=0;
           cout<<"enter the value of x";
           cin>>x;                                                                                                                                                     
           cout<<"/n enter the value of y";
           cin>>y;
           subt=y-x;
           cout<<"/n value of subt y from x"<<subt;
}