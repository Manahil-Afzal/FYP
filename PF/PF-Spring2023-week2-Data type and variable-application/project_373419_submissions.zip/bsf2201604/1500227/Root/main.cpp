//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x;
    int y;
    cout << "value of x is :";
    cin>> x;
    cout <<"value of y is :";
    cin>> y;
     int sum= x+y;
    cout<<"sum of two number is ";
    cout<< sum;
}