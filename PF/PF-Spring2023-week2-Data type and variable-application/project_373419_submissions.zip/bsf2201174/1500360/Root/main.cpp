//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int a=0,b=0;
    cout<<"enter value for a";
    cin>>a;
    cout<<"\n entrer value for b";
    cin>>b;
    cout<<"sub the value of a and b is"<<b-a;
    
}