//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from seco#
#include<iostream>
using namespace std;
int main()
{
    int a=0,b=0;
    cout<<"enter number for a";
    cin>>a;
    cout<<"\nenter number for b";
    cin>>b;
    
    cout<<"sub the value of a and b is"<<b-a;
}