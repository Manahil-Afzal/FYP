//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x,y;
    int difference;
    cout<<"Enter value of x ";
    cin>>x;
    cout<<"Enter value of y ";
    cin>>y;
    difference=y-x;
    cout<<"the difference is "<<difference;
}