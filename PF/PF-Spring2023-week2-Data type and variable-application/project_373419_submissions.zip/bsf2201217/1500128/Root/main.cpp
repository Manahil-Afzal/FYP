//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x=0,y=0;
      cout<<"Enter the value of x =";
    cin>>x;
     cout<<"Enter the value of y =";
    cin>>y;
     cout<<"the subtraction is :"<<y-x;

}