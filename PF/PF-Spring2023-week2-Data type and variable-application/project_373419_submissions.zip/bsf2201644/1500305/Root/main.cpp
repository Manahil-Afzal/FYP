//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int a,b;
    int sub;
    cout<<"enter value of a";
    cin>>a;
    cout<<"enter valuye of b";
    cin>>b;
    sub=a-b;
    cout<<"subtract first number from second number"<<sub;
}