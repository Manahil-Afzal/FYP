//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x,y;//program for difference
    int diff;
    cout<< "Enter value of x ";
    cin>>x;
    cout<< "\nEnter value of y ";
    cin>>y;
    cout<<"\n diff of values is "<<y-x;
}