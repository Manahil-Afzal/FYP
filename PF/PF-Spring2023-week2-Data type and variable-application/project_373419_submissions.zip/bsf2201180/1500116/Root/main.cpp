//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x=0 , y=0;
    cout<<"enter the value for x";//insertion operation
    cin>>x;
    cout<<"enter the value for y";//extraction operation
    cin>>y;
    cout<<"sub x from y"<<y-x;
}