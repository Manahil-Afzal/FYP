//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int A;
    int B;
    
    cout<< "Enter First integer";
    cin >> A;
    cout<< "Enter Second integer";
    cin >> B;
    int subtraction= A-B
   ;cout <<"The subtraction of given two integers is";
    cout<< subtraction;
}
    
