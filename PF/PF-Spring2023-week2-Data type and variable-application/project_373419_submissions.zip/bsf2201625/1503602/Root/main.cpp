//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;
main()
{
    int a,b,sub;
    cout<<"enter 1st number=";
    cin>>a;
    cout<<"enter 2nd number=";
    cin>>b;
    sub=b-a;
    cout<<"Sub="<<sub<<endl;
    
}