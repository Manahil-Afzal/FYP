//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x,y;
    cout<<"enter the value for x ";
    cin>>x;
    cout<<"enter the value for y ";
    cin>>y;
    cout<<" sub of x and y is "<<y-x;}
    