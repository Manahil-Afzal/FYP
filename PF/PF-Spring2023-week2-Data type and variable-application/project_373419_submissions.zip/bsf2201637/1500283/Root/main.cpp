#include <iostream>
using namespace std;
int main ()
{
    int a,b;
    
    cout << "enter two numbers";
    
    cin >> a >> b;
    
    cout << "b-a is" << b-a;
        }