//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x,y;
    int sub;
    cout<<"enter first number x";
    cin>>x;
    cout<<"enter second number y";
    cin>>y;
    sub=y-x;
cout<<"subtract first number forom second"<<sub;
}