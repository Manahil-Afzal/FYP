//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x,y;
    cout<<"Enter first num=";
    cin>>x;
    cout<<"Enter second num=";
    cin>>y;
    cout<<"Result y-x="<<y-x;
}