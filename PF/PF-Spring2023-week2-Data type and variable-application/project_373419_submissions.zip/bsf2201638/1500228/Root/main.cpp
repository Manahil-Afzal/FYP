//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
	int a,b,sub;
	cout<<"Enter the values of a!"<<endl;
	cin>>a;
	cout<<"Enter the values of b!"<<endl;
	cin>>b;
	sub = a-b;
	cout<<"The result is = "<<sub<<endl;
	
}