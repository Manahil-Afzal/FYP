//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>;
using namespace std;
int main()
{
    int x=0;
    int y=0;
    cout<<"enter first num  ";
    cin>>x;
    cout<<"enter second num ";
    cin>>y;
    cout<<"substraction of two number is "<<x-y;
    
}