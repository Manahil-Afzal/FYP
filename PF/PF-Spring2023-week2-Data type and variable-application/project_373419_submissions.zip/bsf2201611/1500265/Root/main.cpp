//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x;
    int y;
    cout<< " value for x is = ";
    cin>>x;
    cout<< " value for y is = ";
    cin>>y;
    cout<< "subtract of two values is "<<x-y;
}