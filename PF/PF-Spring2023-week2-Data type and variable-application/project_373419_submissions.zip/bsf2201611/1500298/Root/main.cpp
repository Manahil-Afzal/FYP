//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;

main()

{
    int A;
    int B;
    cout<< "Enter First Number";
    cin>>A;
    cout<<"Enter second Number";
    cin>>B;
    int Sub=A-B;
    cout<<"The subtraction of two numbers is:";
    
    cout<< Sub;
    
}