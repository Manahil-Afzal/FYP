#include<iostream>
using namespace std;
int main()
{
    int a,b,sub;
    cout<<"Enter value of a";
    cin>>a;
    cout<<"\n Enter value of b";
    cin>>b;
    sub=a-b;
    cout<<"\n subtracting a from b is"<<sub;
}//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.io