//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number
#include<iostream>
using namespace std;
main()
{
    int a=0;
    int b=0;
    int sub=0;
    cout<<"enter value of a= ";
    cin>>a;
    cout<<"enter value of b= ";
    cin>>b;
    sub=b-a;
    cout<<"subtracting a from b is= "<<sub;
}