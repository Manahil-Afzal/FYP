//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x=0;
    int y=0;
    int diff=0;
    cout<<"enter the value of x\n";
    cin>>x;
    cout<<"enter the value of y\n";
    cin>>y;
    diff=y-x;
    cout<<" diff of x and y"<<diff;
}