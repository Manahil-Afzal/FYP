//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number
#include<iostream>
using namespace std;
main()
{
    int X=0, Y=0;
    cout<<"enter the value of X ";
    cin>>X;
    cout<<"enter the value of Y ";
    cin>>Y;
    cout<<"subtraction of two numbers is "<<X-Y;
}