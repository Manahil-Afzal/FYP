//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
int x,y;
cout<<"enter the value of x ";
cin>>x;
cout<<"enter the value of y ";
cin>>y;
cout<<"subtraction"<<x-y;
}