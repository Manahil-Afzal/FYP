#include<iostream>
using namespace std;
int main()
{
    int x,y;//program for difference
    cout<<"enter value of x ";
    cin>>x;
    cout<<"enter value of y ";
    cin>>y;
    cout<<"diff of values is "<<x-y;
}