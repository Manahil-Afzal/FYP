//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;

main()
{
    cout<<"Enter 1st number: ";
    int a=0;
    cin>>a;
    
    cout<<"Enter 2nd number: ";
    int b=0;
    cin>>b;
    
    cout<<"subtracting two numbers: "<<a-b;
}