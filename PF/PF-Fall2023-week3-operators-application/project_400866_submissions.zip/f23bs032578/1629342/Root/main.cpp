/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
main()
{
    int age,PDS,days,monthly_sallery;
    string name;
    cout<<"employ profile:";
    cout<<"\nenter name:";
    cin>>name;
    cout<<"\nage:";
    cin>>age;
    cout<<"\nper day salary:";
    cin>>PDS;
    cout<<"\nworking days:";
    cin>>days;
    cout<<days*PDS;
}