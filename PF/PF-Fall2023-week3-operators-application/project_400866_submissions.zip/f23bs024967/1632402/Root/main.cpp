/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main()
{
    string name;
    int age;
    int perday_salary;
    int number_of_days;
    int total_salary;
    cout<<"ENTER YOUR NAME= ";
    cin>>name;
    cout<<"ENTER YOUR AGE= ";
    cin>>age;
    cout<<"ENTER YOUR PER DAY SALARY= ";
    cin>>perday_salary;
    cout<<"ENTER NUMBER OF DAYS WORKED IN A MONTH= ";
    cin>>number_of_days;
    total_salary=perday_salary*number_of_days;
    cout<<"YOUR NAME IS="<<name<<endl;
    cout<<"YOUR AGE IS= "<<age<<endl;
    cout<<"YOUR PERDAY SALARY IS= "<<perday_salary<<endl;
    cout<<"NUMBER OF DAYS IN A MONTH= "<<number_of_days<<endl;
    cout<<"YOUR TOTAL SALARY= "<<total_salary<<endl;
}