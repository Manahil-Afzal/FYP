/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
#include <string>

using namespace std;

int main()

 {
    string name;
    int age, days;
    double salary_per_day, monthly_salary;

    cout << "Enter name: ";
    getline(cin, name);

    cout << "Enter age: ";
    cin >> age;

    cout << "Enter salary per day: ";
    cin >> salary_per_day;

    cout << "Enter number of days worked in a month: ";
    cin >> days;

    monthly_salary = salary_per_day * days;

    cout << "\nName: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Salary per day: $" << salary_per_day << endl;
    cout << "Number of days worked in a month: " << days << endl;
    cout << "Monthly salary: $" << monthly_salary << endl;

    return 0;
}
