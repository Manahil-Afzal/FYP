/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
using namespace std;

int main() {
    string name;
    int age, salary_perday, DaysWork;
    
    cout << "Please enter your name: ";
    cin >> name;
    
    cout << "Enter your age: ";
    cin >> age;
    
    cout << "Enter your per day salary: ";
    cin >> salary_perday;
    
    cout << "How many days did you work in a month: ";
    cin >> DaysWork;
    
    cout << "My name is: " << name << endl;
    cout << "My age is: " << age << endl;
    cout << "My per day salary is: " << salary_perday << endl;
    
    int monthlySalary = salary_perday * DaysWork;
    cout << "My monthly salary is: " << monthlySalary << endl;
    
}