/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
main()
{
    int working_days,per_day_sallery,age,monthly_salery;
    string name;
    cout<<"EMPLOYE PROFILE:"<<endl;
    cout<<"enter your name:"<< endl;
    cin>>name;
    cout<<"enter your age:"<< endl;
    cin>>age;
    cout<<"enter your per day sallery:"<<endl;
    cin>>per_day_sallery;
    cout<<"enter number of days worked in a month:"<< endl;
    cin>>working_days;
    monthly_salery=per_day_sallery*working_days;
    cout<<monthly_salery;//this program finds the per day salery of employe
}