/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main ()
{
    string name;
    int age;
    int per_day_salary;
    int days , monthly_salary;
    cout<<"Employee's profile"<<endl;
    cout<<"Enter your name:";
    cin>>name;
    cout<<"Enter your age:";
    cin>>age;
    cout<<"Enter your per day salary:";
    cin>>per_day_salary;
    cout<<"Enter your number of days you worked in a month:";
    cin>>days;
    monthly_salary=per_day_salary*days;
    cout<<"your monthly_salary is:"<<monthly_salary;
    return 0;
    
}
