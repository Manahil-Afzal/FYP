/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main()
{
    string name;
    
    int age,day;
    
    double salary,monthlysalary;
    
    cout << "Enter your Name: ";
    cin >> name;
    
    cout << "Enter your Age: "; 
    cin >> age ;
    
    cout << "Enter your per day salary: ";
    cin >> salary;
    
    cout << "Enter number of days you worked in a month: ";
    cin >> day;
    
    monthlysalary = salary * day;
    
    cout << "Your monthly salary is " <<  monthlysalary  << " only"  << endl;
    
    return 0;
}
