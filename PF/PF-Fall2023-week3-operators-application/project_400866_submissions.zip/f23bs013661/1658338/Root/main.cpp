/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
int main()
{
    string name;
    int age;
    int perdaysalary;
    int noofdays;
    int totalsalary;
    cout<<"enter your name";
    cin>>name;
    cout<<"enter your age";
    cin>>age;
    cout<<"enter your salary";
    cin>>perdaysalary;
    cout<<"no of working days";
    cin>>noofdays;
    cout<<"your name is "<<name<<endl;
    cout<<"your age is"<<age<<endl;
    cout<<"your salary is"<<perdaysalary<<endl;
    cout<<"your no of working days"<<noofdays<<endl;
    totalsalary=noofdays*perdaysalary;
    cout<<"your net salary is"<<totalsalary;
}