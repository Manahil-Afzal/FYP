/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main()
{
	string name;
	int age;
	double per_day_salary;
	int days_worked;
	double monthly_salary;
	cout<<"****Please Enter your name****"<<endl;
	getline(cin,name);
	cout<<"****Please Enter your age****"<<endl;
	cin>>age;
	cout<<"****Please Enter your Per day salary****"<<endl;
	cin>>per_day_salary;
	cout<<"****Please Enter Days you worked in a month****"<<endl;
	cin>>days_worked;
	monthly_salary=per_day_salary*days_worked;
	cout<<"The name of employee:"<<name<<endl;
	cout<<"The age of employee:"<<age<<endl;
	cout<<"The per day salary of employee:"<<per_day_salary<<endl;
	cout<<"Total number of days that employee worked:"<<days_worked<<endl;
	cout<<"Monthly salary of employee:"<<monthly_salary<<endl;
	
	return 0;
	
}