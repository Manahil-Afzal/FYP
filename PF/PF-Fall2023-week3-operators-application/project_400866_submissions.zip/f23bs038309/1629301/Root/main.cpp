/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
int main()
{  
    cout<<"Employee profile:"<<endl;
    string name;
    int age;
    int salary;
    int working_days;
    int monthly_salary;
    
    cout<<"Name:\t";
    cin>>name;
    cout<<"Age:\t";
    cin>>age;
    cout<<"Per Day salary:\t";
    cin>>salary;
    cout<<"No of days worked in month:\t";
    cin>>working_days;
    monthly_salary=working_days*salary;
    cout<<"Monthly salary:\t"<<monthly_salary<<endl;
    
    return 0;
}