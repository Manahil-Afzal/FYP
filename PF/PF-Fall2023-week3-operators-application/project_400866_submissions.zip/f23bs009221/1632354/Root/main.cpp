/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
using namespace std;

int main()
{
	string name;
	int age;
	float perDaySalary;
	int workingDays;
	cout<<"Enter the name of Employee "<<endl;
	cin>>name;
	cout<<"Enter the age of Employee "<<endl;
	cin>>age;
	cout<<"Enter per day salary of Employee "<<endl;
	cin>>perDaySalary;
	cout<<"Enter the working days of Employee "<<endl;
	cin>>workingDays;
	
	int monthlySalary = perDaySalary*workingDays;
	
	cout<<"Employee's profile "<<endl;
	cout<<"Name: "<<name<<endl;
	cout<<"Age: "<<age<<endl;
	cout<<"Per Day Salary: "<<perDaySalary<<endl;
	cout<<"Number of days worked in a month: "<<workingDays<<endl;
	cout<<"Per Month Salary: "<<monthlySalary<<endl;
	return 0;
	
	
}