#include<iostream>
#include<string>
using namespace std;
int main(){
    string name;
    int age;
    int perDaySalary;
    int noOfWorkingDays;
    int netSalary;
    cout<<"Enter employee's name:";
    cin>>name;
    cout<<"Enter your age:";
    cin>>age;
    cout<<"Enter per day salary:";
    cin>>perDaySalary;
    cout<<"enter number of working days in month:";
    cin>>noOfWorkingDays;
    netSalary=perDaySalary*noOfWorkingDays;
    cout<<"Your name is "<<name<<endl;
    cout<<"Your age is "<<age<<endl;
    cout<<"Per day salary is "<<perDaySalary<<endl;
    cout<<"Number of working days "<<noOfWorkingDays<<endl;
    cout<<"Your net salary is "<<netSalary;
    return 0;
}