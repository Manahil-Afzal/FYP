#include<iostream>
#include<string>
using namespace std;
int main(){
    string name;
    int age;
    int per_day_salary;
    int no_of_working_days;
    int net_salary;
    cout<<"Enter employee's name:";
    cin>>name;
    cout<<"Enter your age:";
    cin>>age;
    cout<<"Enter per day salary:";
    cin>>per_day_salary;
    cout<<"enter number of working days in month:";
    cin>>no_of_working_days;
    net_salary=per_day_salary*no_of_working_days;
    cout<<"Your name is "<<name<<endl;
    cout<<"Your age is "<<age<<endl;
    cout<<"Per day salary is "<<per_day_salary<<endl;
    cout<<"Number of working days "<<no_of_working_days<<endl;
    cout<<"Your net salary is "<<net_salary;
    return 0;
}