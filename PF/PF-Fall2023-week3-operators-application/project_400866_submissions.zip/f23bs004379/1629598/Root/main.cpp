/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
main()
{
    string name,age;
    int days,per_day_sal,sal;
    cout<<"Enter your name"<<endl;
    cin>>name;
    cout<<"Enter your age"<<endl;
    cin>>age;
    cout<<"Enter your per day salary"<<endl;
    cin>>per_day_sal;
    cout<<"Number of days worked in a month"<<endl;
    cin>>days;
    sal=days*per_day_sal;
    cout<<"Emloyee Profile"<<endl;
    cout<<"Your name is :"<<name<<endl;
    cout<<" Your age is :"<<age<<endl;
    cout<<" num of working days is :"<<days<<endl;
    cout<<" per day salary is :"<<per_day_sal<<endl;
    cout<<"the monthly salary of employee is :"<<sal<<endl;
}
