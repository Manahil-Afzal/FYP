#include<iostream>
#include<string>
using namespace std;
int main(){
    string name;
    int age;
    int perdaysalary;
    int workingdays;
    int netsalary;
    cout<<"Enter employee's name:";
    cin>>name;
    cout<<"Enter your age:";
    cin>>age;
    cout<<"Enter per day salary:";
    cin>>perdaysalary;
    cout<<"enter number of working days in month:";
    cin>>workingdays;
    netsalary=perdaysalary*workingdays;
    cout<<"Your name is "<<name<<endl;
    cout<<"Your age is "<<age<<endl;
    cout<<"Per day salary is "<<perdaysalary<<endl;
    cout<<"Number of working days "<<workingdays<<endl;
    cout<<"Your net salary is "<<netsalary;
    return 0;
}