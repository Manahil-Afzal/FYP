#include<iostream>
using namespace std;
main()

{
    string name;
int age;
int perdaysalary;
int numberofdaysworkedinamonth;
int monthlysalary;
monthlysalary=perdaysalary*numberofdaysworkedinamonth;
cout<<"enter your age";
cin>>age;
cout<<"enter perdaysalary";
cin>>perdaysalary;
cout<<"enter numberofdaysworkedinamonth";
cin>>numberofdaysworkedinamonth;
cout<<"monthly salary";
}

