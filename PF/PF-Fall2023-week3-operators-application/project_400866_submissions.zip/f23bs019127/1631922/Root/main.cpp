/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
 using namespace std;
int main()
{
    string name;
    int age;
    int salary;
    int workingdays;
     int totalSalary;
    
    cout<<"please enter your name";
    cin>>name;

    cout<<"please enter your age";
    cin>>age;

    cout<<"please enter your salary";
    cin>>salary;
 
    cout<<"please enter your days of working";
    cin>>workingdays;
  
        cout<<"your name is "<<name<<endl;
        cout<<"your age is :"<<age<<endl;
           cout<< "your salary is :"<<salary<<endl;
             cout<<"your days of working is:"<<workingdays<<endl;
             totalSalary=workingdays*salary;
             cout<<"your total salary is:"<<totalSalary;
            
}