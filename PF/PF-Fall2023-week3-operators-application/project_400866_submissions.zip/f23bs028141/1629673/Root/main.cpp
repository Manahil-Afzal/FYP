/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
main()
{
int age,PDS,days,monthlysalary;
string name;
cout<<"employ profile:";
cout<<"enter name:";
cin>>name;
cout<<"age:";
cin>>age;
cout<<"per day salary:";
cin>>PDS;
cout<<"working days:";
cin>>days;
cout<<PDS*days;
}
