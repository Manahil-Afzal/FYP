#include <iostream>
using namespace std;
int main()
{
    string name;
    int age;
   int daysWorked;
    double perDaySalary;
    cout << "Enter employee name: ";
    cin>>name;
    cout << "Enter employee age: ";
    cin >> age;
    cout << "Enter per day salary: ";
    cin >> perDaySalary;
    cout << "Enter number of days worked in a month: ";
    cin >> daysWorked;
    double monthlySalary = perDaySalary * daysWorked;
    

    return 0;
}
