/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
int main()
{
    string Name;
    int age;
    int perday_salary;
    int days;
    int net_salary;
    cout<<"Enter Your Name:";
    cin>>Name;
    cout<<"Enter Your Age:";
    cin>>age;
    cout<<"Enter Your Per Day Salary:";
    cin>>perday_salary;
    cout<<"Number Of Days You Worked in a Month:";
    cin>>days;
    net_salary= perday_salary * 30;
    cout<<"Your Name is:"<<Name<<endl;
    cout<<"Your Age is:"<<age<<endl;
    cout<<"Your Per Day Salary is:"<<perday_salary<<endl;
    cout<<"Your Number of Days Worked in a Month is:"<<days<<endl;
    cout<<"Your Net Salary is:"<<net_salary<<endl;
    return 0;
    
    
}