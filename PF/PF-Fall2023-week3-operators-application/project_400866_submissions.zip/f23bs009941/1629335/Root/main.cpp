/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main()
{
string name;
int age;
 long int salary_per_day;
int working_days;
int monthly_salary;
cout<<"enter your name:";
cin>>name;
cout<<"enter your  age:";
cin>>age;
cout<<"enter your per day salary:";
cin>>salary_per_day;
cout<<"enter your working days:";
cin>>working_days;
monthly_salary=salary_per_day*working_days;
cout<<monthly_salary;
cout<<"your name is "<<name<<endl;
cout<<"your age is "<<age<<endl;
cout<<"your salary per day "<<salary_per_day<<endl;
cout<<"your working days is:"<<working_days<<endl;
cout<<"your monthly salary is"<<monthly_salary<<endl;

    return 0;
}