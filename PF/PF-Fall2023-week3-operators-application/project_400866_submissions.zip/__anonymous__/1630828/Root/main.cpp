/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
int main( )
{
    string employeename;
    string age;
    int perdaysalary;
    int numberofdays;
    cout<<"enter employeename";
    cin>>employeename;
    cout<<"enter age";
    cin>>age;
    cout<<"enter perdaysalary";
    cin>>perdaysalary;
    cout<<"enter numberofdays";
    cin>>numberofdays;
    cout<<perdaysalary*numberofdays;
    cout<<employeename<<age;
}