/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee*/
#include<iostream>
using namespace std;
main(){
    int age; 
    int per_daySalary;
    int month_working_Days;
    cout<<"Enter your age:";
    cin>> age;
    cin.ignore();
    cout<<"Enter your per day salary:";
    cin>>per_daySalary;
    cout<<"Enter working days in a month:";
    cin>> month_working_Days;
    string name;
    cout<<"Enter your name:";
    cin>> name;
    //Displays Empolyee's information
    cout<< "Name:"<<name<<endl;
    cout<< "Age:"<< age<<endl;
    cout<< "Per Day Salary:"<<per_daySalary<<endl;
    cout<< "Days Worked:"<<month_working_Days<<endl;
    //Monthly Salary
    int monthly_Salary=per_daySalary*month_working_Days;
    cout<< "Monthly Salary:" << monthly_Salary;
}