/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main()
{
    string name;
    int age;
    int per_day_salary;
    int days;
    int monthly_salary;
    cout<<"enter your name:";
    cin>>name;
    cout<<"enter your age:";
    cin>>age;
    cout<<"enter your per_day_ salary";
    cin>>per_day_salary;
    cout<<"enter your days:";
    cin>>days;
    monthly_salary=per_day_salary*days;
    cout<<monthly_salary;
    return 0;
}