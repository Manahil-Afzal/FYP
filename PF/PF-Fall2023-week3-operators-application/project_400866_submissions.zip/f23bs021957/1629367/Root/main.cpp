/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
using namespace std;

int main() {
    string name;
    int age, salary, DaysWorked;
    
    cout << "Please enter your name: ";
    cin >> name;
    
    cout << "Enter your age: ";
    cin >> age;
    
    cout << "Enter your per day salary: ";
    cin >> salary;
    
    cout << "How many days did you work in a month: ";
    cin >> DaysWorked;
    
    cout << "My name is: " << name << endl;
    cout << "My age is: " << age << endl;
    cout << "My per day salary is: " << salary << endl;
    
    int monthlySalary = salary * DaysWorked;
    cout << "My monthly salary is: " << monthlySalary << endl;
    
}