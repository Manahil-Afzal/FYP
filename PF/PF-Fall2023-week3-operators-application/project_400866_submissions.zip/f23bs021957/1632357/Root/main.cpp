/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
#include <string>
using namespace std;

int main() {
    string name;
    int age, salaryPerDay, daysWorked;

    
    cout << "Enter your name: ";
    cin>>name;
    cout << "Enter your age: ";
    cin >> age;
    cout << "Enter your per day salary: ";
    cin >> salaryPerDay;
    cout << "Enter the number of days worked in a month: ";
    cin >> daysWorked;

    
    cout << "Employee Information:" << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Per day salary:"<< salaryPerDay << endl;
    
    int monthlySalary = salaryPerDay * daysWorked;
    cout << "Monthly Salary " << monthlySalary << endl;

    return 0;
}