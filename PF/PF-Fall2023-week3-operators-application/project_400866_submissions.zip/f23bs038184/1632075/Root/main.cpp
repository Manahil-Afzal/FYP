#include <iostream>
#include <string>

using namespace std;

int main() {
    string name;
    int age;
    double perDaySalary;
    int daysWorked;

    cout << "Enter employee's name: ";
    getline(cin, name);

    cout << "Enter employee's age: ";
    cin >> age;

    cout << "Enter per day salary: ";
    cin >> perDaySalary;

    cout << "Enter number of days worked in a month: ";
    cin >> daysWorked;

    double monthlySalary = perDaySalary * daysWorked;

    cout << "\nEmployee Profile:" << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << " years" << endl;
    cout << "Per Day Salary: $" << perDaySalary << endl;
    cout << "Days Worked in a Month: " << daysWorked << " days" << endl;
    cout << "Monthly Salary: $" << monthlySalary << endl;

    return 0;
}