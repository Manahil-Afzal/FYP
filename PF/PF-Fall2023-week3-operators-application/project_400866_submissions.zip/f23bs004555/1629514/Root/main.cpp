#include<iostream>
using namespace std;
int main()
{
string name;
int age;
int perdaysalary;
int daysworked;
int monthlysalary;
cout<<"Enter your name:";
cin>>name;
cout<<"Enter your age:"<<age;
cin>>age;
cout<<"Enter your per day salary:"<<perdaysalary;
cin>>perdaysalary;
cout<<"Enter your working days:"<<daysworked;
cin>>daysworked;
monthlysalary=perdaysalary*daysworked;
cout<<"The monthly salary of employee is:"<<monthlysalary;
}