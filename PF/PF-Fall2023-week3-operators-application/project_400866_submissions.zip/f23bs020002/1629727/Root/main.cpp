/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
#include <string>
using namespace std;
main()
{
    string name;
    int age, salary, days, total;
    cout<<"Enter your name:";
    cin>>name;
    cout<<"Enter your age:";
    cin>>age;
    cout<<"Enter your per day salary:";
    cin>>salary;
    cout<<"Enter your no of working days in a month:";
    cin>> days;
    total=days*salary;
    cout<<"\nName of employee:"<<name;
    cout<<"\nAge of employee:"<<age;
    cout<<"\nPer day salary of employee:"<<salary;
    cout<<"\nNumber of working days of employee:"<<days;
    cout<<"\nMonthly salary of employee:"<<total;
    
    
    
}