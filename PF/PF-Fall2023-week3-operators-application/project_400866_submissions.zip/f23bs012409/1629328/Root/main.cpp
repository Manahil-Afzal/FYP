/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/#include<iostream>
#include<iostream>
using namespace std;
main()
{
 string name;
 int age,perdaysalary,noofdaysworkedinamonth,monthlysalary;
 cout<<"name of employe=";
cin>>name;
 cout<<"age of employe=";
 cin>>age;
 cout<<"per day salary=";
 cin>>perdaysalary;
 cout<<"no of days worked in  a month=";
 cin>>noofdaysworkedinamonth;
 cout<<"employes monthly salary=";
 cin>>monthlysalary;
}