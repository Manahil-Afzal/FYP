/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
int main()
{
	string name;
	int age;
	double perDaysalary;
	int daysworked;
	cout<<"Enter employee name";
	getline(cin,name);
	cout<<"Enter employee age";
	cin>> age;
	cout<<"Enter per day salary";
	cin>> perDaysalary;
	cout<<"Enter number of days worked in a month";
	cin>> daysworked;
	double monthlySalary= perDaysalary * daysworked;
	cout<<"\n Employee Profile:\n";
	cout<<"Name:"<<name<<endl;
	cout<<"Age:"<<age<<"years"<<endl;
	cout<<"Perdaysalary:Rs"<<perDaysalary<<endl;
	cout<<"Days worked in a month:"<<daysworked<<"days"<<endl;
	cout<<"monthlysalary:"<<monthlySalary<<endl;
	return 0;
}