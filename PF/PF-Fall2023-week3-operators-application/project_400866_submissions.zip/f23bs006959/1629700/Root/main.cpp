/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
int main()
{
    string name;
    int age;
    int pds;
    int days;
    int salary;
    
    cout<<"Employee's Profile\n";
    cout<<"Name:\t";
    cin>>name;
    cout<<"Age:\t";
    cin>>age;
    cout<<"Per day salary:\t";
    cin>>pds;
    cout<<"Numbers of Working Days:  ";
    cin>>days;
    
    cout<<"Employee name is "<<name<<"."<<"\n";
    cout<<"Age is "<<age<<"."<<"\n";
    cout<<"Per day salary is "<<pds<<"."<<"\n";
    cout<<"Numbers of working days are "<<days<<"."<<"\n";
    salary=pds*days;
    cout<<"Monthly salary of employee is "<<salary<<"."; 
    
    return 0;
    
}