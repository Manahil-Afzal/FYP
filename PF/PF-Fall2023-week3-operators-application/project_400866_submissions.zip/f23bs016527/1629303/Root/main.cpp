#include<iostream>
#include<string>
using namespace std;
main()
{
    string name;
    int age;
    int salary;
    int days_in_month;
    int Total_salary ;
    bool choice;
    cout<<"Enter Your Name : ";
    cin>>name;
    cout<<"Enter Your Age : ";
    cin>>age;
    cout<<"Enter Your Per-day Salary : ";
    cin>>salary; 
    cout<<"Enter Your working days in a month: ";
    cin>>days_in_month;
    cout<<"This is true information ?";
    cin>>choice;
    cout<<"YOUR NAME IS : "<<name<<endl;
    cout<<"YOUR AGE IS : "<<age<<endl;
    Total_salary=salary*days_in_month;
     cout<<"TOTAL SALARY : "<< Total_salary<<endl;
    return 0;   
}