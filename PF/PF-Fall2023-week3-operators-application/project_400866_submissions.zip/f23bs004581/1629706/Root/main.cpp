/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
main()
{
    string name;
    int age;
    int day_salary;
    int working_days;
    cout<<"Enter your name";
    cin>>name;
    cout<<"Enter your age";
    cin>>age;
    cout<<"Enter your per day salary";
    cin>>day_salary;
    cout<<"Enter your working days in a month";
    cin>>working_days;
    int monthly_salary = working_days * day_salary;
    cout<<"the employee's profile information is that his name is "<<name<< endl;
	cout<<"his age is "<<age<< endl;
	cout<<"his per day salary is "<<day_salary<< endl;
	cout<<"his Working days are " <<working_days<< endl;
    cout<<"and his monthly salary is "<<monthly_salary<< endl;
}