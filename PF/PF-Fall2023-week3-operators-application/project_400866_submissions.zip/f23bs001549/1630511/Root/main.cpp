/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
using namespace std;

main() {
    string name;
    int age;
    int perDaySalary;
    int daysWorked;
    int monthlySalary;
    cout << "Enter employee's name: ";
    cin>>name;
    cout << "Enter employee's age: ";
    cin >> age;
    cout << "Enter employee's per day salary: ";
    cin >> perDaySalary;
    cout << "Enter the number of days worked in a month: ";
    cin >> daysWorked;
    // Logic for monthly salary
    monthlySalary = perDaySalary * daysWorked;
    cout << "\nEmployee Profile:" << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Per Day Salary: " << perDaySalary << endl;
    cout << "Days Worked in a Month: " << daysWorked << " days" << endl;
    cout << "Monthly Salary: " << monthlySalary << endl;
}
