/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
using namespace std;
main()
{
string name,age;
string perdaysalary,noofdaysworkedinamonth,monthlysalary;
cout<<"employee name is=";
cin>>name;
cout<<"employee's age is=";
cin>>age;
cout<<"employee's per day salary is=";
cin>>perdaysalary;
cout<<"number of days employee worked in a month =";
cin>>noofdaysworkedinamonth;
cout<<"employee's monthly salary is=";
cin>>monthlysalary;


}