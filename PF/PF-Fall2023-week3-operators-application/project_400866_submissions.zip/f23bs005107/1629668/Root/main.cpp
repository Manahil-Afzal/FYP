/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/#include<iostream>
#include<string>
using namespace std;
int main()
{
	string name;
	int age;
	int salary;
	int noofdays;
	int totalsalary;
	cout<<"enter your name=";
	cin>>name;
	cout<<"enter your age=";
	cin>>age;
	cout<<"enter your salary of one day=";
	cin>>salary;
	cout<<"enter your working days in a month=";
	cin>>noofdays;
	totalsalary=noofdays*salary;
	cout<<"your net salary is="<<totalsalary;
}