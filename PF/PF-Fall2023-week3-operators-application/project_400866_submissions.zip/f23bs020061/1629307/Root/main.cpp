/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include <string>
using namespace std;
int main()
{
    string name;
    int age;
    int salary;
    int days;
    int totalsalary;
    cout<< "enter your name :";
    cin>>name;
    cout<<"enter your age :";
    cin>>age;
    cout<<"enter your salary :";
    cin>>salary;
    cout<<"number of days you have been working in a month :";
    cin>>days;
    cout<<"your name is "<<name<<endl;
    cout<<"your age is "<<age<<endl;
    cout<<"your salary is "<<salary<<endl;
    cout<<"your number of days you have been working in a single month is "<<days<<endl;
    totalsalary=days*salary;
    cout<<"your total salary is "<<totalsalary<<endl;
}