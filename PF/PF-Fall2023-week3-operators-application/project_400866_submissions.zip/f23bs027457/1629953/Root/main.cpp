#include <iostream>
#include <string>

using namespace std;

int main() {
    string name;
    int age;
    double perDaySalary;
    int daysWorked;

    // Input employee's information
    cout << "Enter employee's name: ";
    getline(cin, name);

    cout << "Enter employee's age: ";
    cin >> age;

    cout << "Enter employee's per day salary: ";
    cin >> perDaySalary;

    cout << "Enter the number of days worked in a month: ";
    cin >> daysWorked;

    // Calculate the monthly salary
    double monthlySalary = perDaySalary * daysWorked;

    // Display the employee's information and monthly salary
    cout << "\nEmployee Profile:" << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << " years" << endl;
    cout << "Per Day Salary: $" << perDaySalary << endl;
    cout << "Number of Days Worked in a Month: " << daysWorked << " days" << endl;
    cout << "Monthly Salary: $" << monthlySalary << endl;

    return 0;
}
