/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include<iostream>
#include<string>
using namespace std;
main(){
	string name,age;
	int perday_sallary,no_of_days_worked;
	
	cout<<"Enter your name";
	cin>>name;cout<<endl;
		cout<<"Enter your age";
	cin>>age;cout<<endl;
		cout<<"Enter your Perday salary";
	cin>>perday_sallary;cout<<endl;
		cout<<"Enter your no of days worked";
	cin>>no_of_days_worked;cout<<endl;
	
	cout<<"Employ name:";
	cout<<name;cout<<endl;
	cout<<"Employ age:";
	cout<<age;cout<<endl;
	cout<<"Employ Perday salary:";
	cout<<perday_sallary;cout<<endl;cout<<"Number of days Employ worked:";
	cout<<no_of_days_worked;cout<<endl;
	cout<<"monthly salry of employ";
	cout<<no_of_days_worked*perday_sallary;
}