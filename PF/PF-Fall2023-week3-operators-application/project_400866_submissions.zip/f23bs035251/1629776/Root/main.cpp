/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
using namespace std;
main()
{
    string name;
    int age;
    int salaryperday;
    int numberofdays;
    int totalsalary;
    cout<<"enter your name:";
    cin>>name;
    cout<<"enter your age:";
    cin>>age;
    cout<<"enter you salary per day:";
    cin>>salaryperday;
    cout<<"enter your number of days:";
    cin>>numberofdays;
   totalsalary=salaryperday*numberofdays;
    cout<<"monthly salary=salary per day*number of days";
}