/*Write a C++ program that takes following information as input for an
employee’s profile: name, age, per day salary and number of days worked in a month.
Display the data taken as input and also calculate and display the monthly salary of the employee.*/

#include <iostream>
using namespace std;

main()
{
    string name;
    int age, per_day_salary, working_days;
    // Now getting input from the user
    cout << "Give us the employee information!" << endl;
    cout << "Name of employee: ";
    cin >> name;
    cout << "Employee age in year: ";
    cin >> age;
    cout << "Employee per day salary: ";
    cin >> per_day_salary;
    cout << "Working Days of employee: ";
    cin >> working_days;

    // Printing the employe infromation

    cout << "Employee Information is given as: " << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Per Day Salary: " << per_day_salary << endl;
    cout << "Working Days in a month: " << working_days << endl;
    cout << "Monthly salary: " << (per_day_salary) * (working_days) << endl;
}