/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/
#include <iostream>
#include <string>

using namespace std;

int main() {
    string name;
    int age, daysWorked;
    double perDaySalary;

    // Input employee information
    cout << "Enter employee name: ";
    getline(cin, name);
    cout << "Enter employee age: ";
    cin >> age;
    cout << "Enter per day salary: ";
    cin >> perDaySalary;
    cout << "Enter number of days worked in a month: ";
    cin >> daysWorked;

    // Calculate monthly salary
    double monthlySalary = perDaySalary * daysWorked;

    // Display employee information
    cout << "\nEmployee Profile:" << endl;
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    cout << "Per Day Salary: $" << perDaySalary << endl;
    cout << "Days Worked in a Month: " << daysWorked << " days" << endl;
    cout << "Monthly Salary: $" << monthlySalary << endl;

    return 0;
}