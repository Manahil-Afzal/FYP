//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c;   //Declare char variable c without initializing it
    char a;   //Declare char variable c without initializing it
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;     //changed left angle brackets into right angle brackets
    cout<<"following characters are : "<<c<<a;  //write output <<c<<a;
    
    return 0;
}
