//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>
using namespace std;
int main()
{
    char c;
    char a;
    cout << "enter first characterc!";
    cin>>c;
    cout << "enter second character!a";
    cin>>a;
    cout<<"following characters are enteres";
    
}
