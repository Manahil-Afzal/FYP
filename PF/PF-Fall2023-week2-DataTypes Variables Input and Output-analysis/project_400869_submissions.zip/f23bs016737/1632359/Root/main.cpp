//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c='h';//use single quotes for char
    char a='u'; //use single quotes for char
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;//use >> instead of <<
    cout<<"following characters are enteres : "<<c<<" and "<<a;//<< it is not exist between c and a
    
}