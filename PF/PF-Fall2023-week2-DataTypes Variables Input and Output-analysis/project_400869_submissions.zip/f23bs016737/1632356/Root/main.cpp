//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c;//double quotes is not allowed for decleration of character
    char a;
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;//use >> this sign for cin
    cout<<"following characters are enteres :   "<< c <<"  and "<<a;//missing of << between c and a
    
    
}
