//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

 main()
{
    char c = 'b';
    char a = 'x';
    cout << "Enter first character: ";
    cin >> c;
    cout << "Enter second character: ";
    cin >> a;
    cout << "Following characters are entered: " << c << a << endl;
    
}