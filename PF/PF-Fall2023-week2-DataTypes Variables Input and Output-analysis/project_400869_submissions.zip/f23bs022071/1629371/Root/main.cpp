//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char a; 
    char b; 
    cout << "enter first character!a";
    cin>>a;
    cout << "enter second character!";
    cin>>b;
    cout<<"a is ="<<a<<endl;
    cout<<"b is ="<<b<<endl;
    return 0;
    
}
