//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c='b';
    //single quote should be used in character type
    char a='x';
    //character should be written in single quotes
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;
    //extraction operators are used for input function 
    cout<<"following characters are enteres"<<c<<a;
    //correct the output statement
    
}
