//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include<iostream>                                       //space is not allowed
using namespace std;
int main()
{
    char c='b';                                          //use single inverted commas
    char a='x';                                         //use single inverted commas
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;                                             //wrong insertion operator is use
    cout<<"following characters are enteres"<<c,a;      //comma should be use to differ the variables
    
}
