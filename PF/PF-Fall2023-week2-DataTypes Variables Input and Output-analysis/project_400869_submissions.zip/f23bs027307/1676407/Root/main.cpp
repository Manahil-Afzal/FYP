#include <iostream>
using namespace std;

int main() {
    char c = 'b'; // Use single quotes for characters
    char a = 'x'; // Assign 'x' to variable a
    cout << "Enter the first character: ";
    cin >> c;
    cout << "Enter the second character: ";
    cin >> a;
    cout << "The entered characters are: " << c << a << endl; // Correct output statement

    return 0;
}

