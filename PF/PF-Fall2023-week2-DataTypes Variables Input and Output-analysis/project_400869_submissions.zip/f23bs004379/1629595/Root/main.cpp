//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include<iostream>
using namespace std;

 main()
{
    char c;//declare and assigning two times
    char a;
    cout<< "enter first character!"<<endl;
    cin>>c;
    cout<< "enter second character!"<<endl;
    cin>>a;
    cout<<"following characters are enteres:"<<endl<<a<<endl<<c;

}
