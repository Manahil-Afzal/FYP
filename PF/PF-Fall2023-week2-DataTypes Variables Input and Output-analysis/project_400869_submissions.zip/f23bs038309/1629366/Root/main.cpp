//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{   char x; //x was not declared
    char b; //b was not declared
    char c=b; //"" will not use with character
    char a=x; //x was not declared
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a; // << will change into >> because it's cin 
    cout<<"following characters are enteres"<<c<<a; // << was not written there
    
}
