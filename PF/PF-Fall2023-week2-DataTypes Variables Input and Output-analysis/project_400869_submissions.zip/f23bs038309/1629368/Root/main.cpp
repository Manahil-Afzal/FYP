//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{ 
    char c; //extra statments 
    char a; //extra statments 
    cout << "enter first character:";
    cin>>c;
    cout << "enter second character:";
    cin>>a; // << will change into >> because it's cin 
    cout<<"following characters are enteries"<<c<<a; // << was not written there
    return 0; //return o; was not written
}
