//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

main()
{
    char c;//incorect declaration
    char a;//incorect declaration
    cout<< "enter first character!";
    cin>>c;
    cout<< "enter second character!";
    cin>>a;//incorrect use of operator
    cout<<"following characters are enteres"<<endl<<c<<endl<<a;
    
}
