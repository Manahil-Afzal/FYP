//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c; // Declare c as a character variable
    char a; // Declare a as a character variable
    
    cout << "Enter first character: ";
    cin >> c;
    
    cout << "Enter second character: ";
    cin >> a;
    
    cout << "Following characters are entered: " << c << a << endl;
    
    return 0; // Add a return statement to indicate successful execution
}