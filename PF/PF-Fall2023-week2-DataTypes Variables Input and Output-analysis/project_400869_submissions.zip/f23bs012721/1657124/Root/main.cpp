//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>
using namespace std;

int main()
{
  int x, y;
  cout << "Enter input variable y: "; 
  cin >> y; // Use >> instead of <<
  x = y;
  cout << "Value of x = " << x << endl; // Corrected the output formatting
  
  int a = 3, b = 5, c = 8;
  a += b; // Use += instead of =+
  c -= b; // Use -= instead of =-
  cout << "\na += b: " << a<<endl;// by using endl at the end  of character will not combine your answer
  cout << "\nc -= b: " << c<<endl;
  
  a *= b;
  b /= c; // Use /= instead of =/
  cout << "a *= b: " << a<<endl;
  cout << "b /= c: " << b<<endl;
  
  return 0;
    
}
