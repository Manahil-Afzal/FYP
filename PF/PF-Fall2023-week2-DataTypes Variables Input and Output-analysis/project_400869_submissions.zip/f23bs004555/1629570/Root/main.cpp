//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c;                   //remove the value of c
    char a;                  //remove the value of a
    cout << "enter first character:";                       //remove not operator
    cin>>c;
    cout << "enter second character:";                       //remove not operator
    cin>>a;                                                 //remove insertion operator and insert excertion operato
}
