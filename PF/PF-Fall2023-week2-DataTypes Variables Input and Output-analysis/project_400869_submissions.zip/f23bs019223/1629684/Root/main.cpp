//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.
#include <iostream>

using namespace std;

int main()
{
    char c='b';
    char a='x';
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;
    cout<<"following characters are enteres: " <<c << a;
    
}

//Here is the list of errors in program:

//1) The char c variable is initialize with double quote.
//2) The char a variable is initilze with out any quote.
//3) To get input c from the user you have use insertion operator.
//4) cout function has error that the output of two char variable are printing in one insertion operator 

// Solution to this code is given as:

//1) Use single quote '' instead of double "" in char c variable initialization
//2) Use single quote ''  in initializing the char a variable.
//3) Use extraction operator >> instead of insertion operator << for getting input from the user
//4) Use two insertion operators << separately one for each char
