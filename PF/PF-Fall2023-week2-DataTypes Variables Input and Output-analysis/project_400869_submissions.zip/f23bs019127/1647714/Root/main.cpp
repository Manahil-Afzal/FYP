#include <iostream>

using namespace std;

int main()
{
    char c;
    char a;
    
    cout << "Enter the first character: ";
    cin >> c;
    
    cout << "Enter the second character: ";
    cin >> a;
    
    cout << "The following characters are entered: " << c << a << endl;
    
    return 0;
}
