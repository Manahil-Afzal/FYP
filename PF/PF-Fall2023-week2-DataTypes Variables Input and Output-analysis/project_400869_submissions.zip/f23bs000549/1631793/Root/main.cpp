//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c = 'b'; //use single quotation mark for character
    char a; //declare variable 'a' without assigning a value
    cout << "Enter first character: ";
    cin >> c;
    cout << "Enter second character: ";
    cin >> a; //use '>>' for input function, not output function'<<'
    cout << "Following characters are entered: " << c << a << endl; //correct the output statement

    return 0; //add a return statement to indicate successful execution because int is used with main() function
}
