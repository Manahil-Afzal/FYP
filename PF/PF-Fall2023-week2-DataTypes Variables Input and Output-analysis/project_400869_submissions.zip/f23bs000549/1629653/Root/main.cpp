//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c = 'b'; // Use single quotes for character literals
    char a; // Declare variable 'a' without assigning a value
    cout << "Enter first character: ";
    cin >> c;
    cout << "Enter second character: ";
    cin >> a; // Use '>>' for input, not '<<'
    cout << "Following characters are entered: " << c << a << endl; // Correct the output statement

    return 0; // Add a return statement to indicate successful execution
}
