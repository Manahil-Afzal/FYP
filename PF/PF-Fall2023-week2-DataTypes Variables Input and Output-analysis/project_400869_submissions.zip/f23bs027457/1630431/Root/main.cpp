
#include <iostream>

using namespace std;

int main()
{
    char c;
    char a;
    cout << "Enter first character: ";
    cin>>c;
    cout << "Enter second character: ";
    cin>>a;
    cout<<"Following characters are entered:"<<c<<a;
    
    return 0;
}
