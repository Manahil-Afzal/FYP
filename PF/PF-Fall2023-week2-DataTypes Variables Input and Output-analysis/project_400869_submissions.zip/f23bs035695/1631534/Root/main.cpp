//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c = 'b'; // Initialize with a default value
    char x;       // Declare the second character variable 
    
    cout << "Enter first character: ";
    cin >> c;
    
    cout << "Enter second character: ";
    cin >> x;
    
    cout << "Following characters are entered: " << c << x << endl;
    
    return 0;
}
