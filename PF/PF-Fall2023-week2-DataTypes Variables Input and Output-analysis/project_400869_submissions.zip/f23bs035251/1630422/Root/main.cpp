//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include<iostream>
using namespace std;
int main()
{
    char c='b';
    char a='x';//inverted commas are missing
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;//errors in insertion operators
    cout<<"following characters are enteres"<<c,a;
    
}
