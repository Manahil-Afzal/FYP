//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c;
    char a;
    cout << "Enter the first character";
    cin>>c;
    cout << "Enter the second character";
    cin>>a;
    cout<<"Following characters are entered"<<c<<a;
    
}
