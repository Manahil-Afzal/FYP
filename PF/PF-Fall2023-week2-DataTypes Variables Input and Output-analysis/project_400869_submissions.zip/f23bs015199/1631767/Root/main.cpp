//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

//#include <iostream>

//using namespace std;

//int main()
//{
  //  char c="b";
//    char a=x;
    //cout << "enter first character!";
  //  cin>>c;
//    cout << "enter second character!";
    //cin<<a;
  //  cout<<"following characters are enteres"<<ca;
    
//}
//Here is  correct programme
#include <iostream>
using namespace std;

int main()
{
    char c = 'b'; // Use single quotes for character
    char a; // Declare 'a' without initializing it

    cout << "Enter first character: ";
    cin >> c;
    cout << "Enter second character: ";
    cin >> a;

    cout << "Following characters are entered: " << c << a << endl;

    return 0;
}
