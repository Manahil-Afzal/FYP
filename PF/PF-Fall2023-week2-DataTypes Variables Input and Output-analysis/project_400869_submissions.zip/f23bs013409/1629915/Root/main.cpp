//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.

#include <iostream>

using namespace std;

int main()
{
    char c;//incorrect declaration
    
    char a;//incorrect declaration
    cout<< "enter first character!";
    cin>>c;
    cout<< "enter second character!";
    cin>>a;//incorrect insertion operator
    cout<<"following characters are enteres"<<endl<<c<<endl<<a;
    
}
