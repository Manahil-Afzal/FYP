//This prrogram is meant to take two characters as inputs from user and display those charters. Identify and correct errors.
#include <iostream>
using namespace std;

int main()
{
    char c='b';
    //In character type single quotes should be used
    char a='x';
    //Character type should be written in single quotes
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;
    //Ectraction operators are used for input statement
    cout<<"following characters are enteres"<<c<<a;
    //Correct the output statement
    
}
