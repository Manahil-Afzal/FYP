/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class books{ 
public:    
string title;
float price ;
void putdata();
void getdata();
} ;
void books:: putdata(){
cout << " Enter Title :" << "\n";
cin>>title;
cout << " Enter Price :" << "\n";
cin>>price;
 
}
void books::getdata(){
cout<< " The Title is :" << title<<"\n";
cout<<" The Price is :" << price << "\n";
}
int main (){
books book1; 
books book2; 
books book3;
book1.putdata();
book1.getdata();
book2.putdata();
book2.getdata();
book3.putdata();
book3.getdata();
return 0;
}
