#include<iostream>
using namespace std;
int main()
{
   int arr[10];
   for(int i=0;i<10;i++)
   {
       arr[i]=i+100;
       
   } 
     for(int j=1;j<10;j+=2)
    {
       cout<<arr[j]<<endl;
    }
}