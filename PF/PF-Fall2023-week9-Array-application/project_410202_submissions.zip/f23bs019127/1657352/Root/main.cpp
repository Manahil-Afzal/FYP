//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;

int main() {
    const int arraySize = 10; // You can change the array size as needed
    int arr[arraySize];

    // Set array elements with values i + 100
    for (int i = 0; i < arraySize; i++) {
        arr[i] = i + 100;
    }

    // Display the values at odd index positions (1, 3, 5, etc.)
    cout << "Values at odd index positions:" << endl;
    for (int i = 1; i < arraySize; i += 2) {
        cout << "arr[" << i << "] = " << arr[i] << endl;
    }

    return 0;
}
