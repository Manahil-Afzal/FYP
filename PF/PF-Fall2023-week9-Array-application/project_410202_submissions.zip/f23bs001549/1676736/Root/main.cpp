//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;
int main() {
    int arraySize = 10;
    int myArray[arraySize];
    for (int i = 0; i < arraySize; ++i) {
        myArray[i] = i + 100;
    }
    for (int i = 1; i < arraySize; i += 2) {
        cout << "Value at index " << i << ": " << myArray[i] <<endl;
    }
    return 0;
}
