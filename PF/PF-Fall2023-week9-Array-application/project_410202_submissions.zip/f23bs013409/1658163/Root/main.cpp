//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main(){
    int arr[10]; //as array size wasn't specified so i used i's value as 10
    for(int i=0;i<10;i++){
        arr[i]=i+100;
    }for(int j=1;j<10;j+=2){
        cout<<arr[j]<<endl;
    }
}