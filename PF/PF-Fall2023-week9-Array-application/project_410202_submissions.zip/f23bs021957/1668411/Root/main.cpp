//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;
int main() {
    const int size = 15;
    int array[size];

    
    for (int i = 0; i < size; ++i) {
        array[i] = i + 100;
    }

    
    cout << "Values at odd index positions: ";
    for (int i = 1; i < size; i += 2) {
        cout << array[i] << " ";
    }

    return 0;
}