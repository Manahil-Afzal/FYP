#include<iostream>
using namespace std;

int main() {
    int array[9]; 

    for (int i = 0; i <=8; i++) {
        array[i] = 100 + i;
    

   
    if(array[i]%2!=0)
    
        cout<<"Index of "<<i <<":"<<array[i]<<endl;
    }
    }

   

