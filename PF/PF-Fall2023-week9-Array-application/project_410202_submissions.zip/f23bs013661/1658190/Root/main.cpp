//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int digit=10;
    int num[digit];
    for(int i=0;i<digit;i++)
    {
        num[i]=i+100;
        if(i%2==1)
        {
            cout<<num[i]<<endl;
        }
    }
}