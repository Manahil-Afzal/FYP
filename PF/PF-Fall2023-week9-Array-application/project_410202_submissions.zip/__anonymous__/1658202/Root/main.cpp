//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
   int n=10; 
   int odd[n];
   for(int i=0;i<10;i++)
   {
       odd[i]=i+100;
   }
 for(int i=1;i<10;i+=2)
 {
    
     cout<<"\n"<<"value at odd index"<<":"<<odd[i];
 }
 }