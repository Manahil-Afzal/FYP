//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;
int main() 
{
    int arraysize=10;//We can change the size
    int ray[arraysize];
    for(int i=0;i<arraysize;i++)
    {
	  ray[i]=i+100;
	}
    for(int i=1;i<arraysize;i+=2)
    {
	   cout<<"value at index is "<<i<<":"<<ray[i]<<endl;
	}
    
   
}