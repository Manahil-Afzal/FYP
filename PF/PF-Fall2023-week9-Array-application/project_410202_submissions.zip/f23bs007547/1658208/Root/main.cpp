//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int arr[100];
    cout<<"Enter the values of array:";
    for(int i=0; i<100;i++)
    cin>>arr[i];
    for(int i=0;i<100;i++)
    {
        if(i%2!=0){
        cout<<"The value of odd array is"<<arr[i]<<endl;
        }
    }
    return 0;
}