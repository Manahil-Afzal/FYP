//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.#include <iostream>
#include <iostream>
int main() {
    const int arraySize = 10;  // You can adjust the size as needed
    int arr[arraySize];

    // Set array with location values using the formula I++ * 100
    for (int i = 0; i < arraySize; ++i) {
        arr[i] = (i + 1) * 100;
    }

    // Display the values assigned to odd index positions
    std::cout << "Values at odd index positions:\n";
    for (int i = 1; i < arraySize; i += 2) {
        std::cout << "Index " << i << ": " << arr[i] << "\n";
    }

    return 0;
}