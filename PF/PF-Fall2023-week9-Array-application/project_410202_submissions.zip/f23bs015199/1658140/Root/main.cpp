//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>

int main() {
    const int arraySize = 10; // You can change the size as needed
    int arr[arraySize];

    // Set the values in the array
    for (int i = 0; i < arraySize; i++) {
        arr[i] = i + 100;
    }

    // Display values at odd index positions
    std::cout << "Values at odd index positions: ";
    for (int i = 1; i < arraySize; i += 2) {
        std::cout << arr[i] << " ";
    }

    std::cout << std::endl;

    return 0;
}
