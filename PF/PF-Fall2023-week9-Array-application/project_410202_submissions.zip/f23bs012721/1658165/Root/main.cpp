//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;
int main ()
{
int size= 15;

int myarr[size];

for (int i = 0; i < size; i++) { 
     myarr[i] = i+100; 
}
    cout << "Values at odd index positions are:" << endl;
for (int i = 1; i < size; i += 2) {
    cout << "arr[" << i << "] = " << myarr[i] << endl; 
    
}

return 0;
}