//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main ()
{
    int array[10];
    for(int i=0;i<10;i++)
    {
        array[i]=100+i;
        cout<<"value is;"<<array[i]<<endl;
    
    
    }
    
}