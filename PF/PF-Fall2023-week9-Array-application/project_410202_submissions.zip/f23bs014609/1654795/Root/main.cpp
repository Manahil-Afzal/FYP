//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include <iostream>
using namespace std;

int main() {
    int size = 10; // i have used 10 as size was not declared
    int array[size];
    for (int i = 0; i < size; i++){
        array[i] = i + 100;
    }
    cout<< "Values assigned to odd index values of the array:"<< endl;
    for (int i = 1; i < size; i += 2){
        cout<< "array[" << i << "] = " << array[i]<<endl;
    }

    return 0;
}
