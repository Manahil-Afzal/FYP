//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main(){
    int arr[10];
    for(int i=0; i < 10; i++){
        arr[i] = i + 100;
        
    }
    cout<< "Odd index values of the array are: ";
    for (int i=1; i<10; i += 2){
        cout<<arr[i]<<" ";
    }
    return 0;
}