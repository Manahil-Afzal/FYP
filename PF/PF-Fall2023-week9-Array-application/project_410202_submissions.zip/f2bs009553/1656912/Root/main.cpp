//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
#include<climits>
using namespace std;
int main()
{
    int array_size;
    cout<<"Numbers of Array=";
    cin>>array_size;
    int num[array_size];  
    for(int i=0;i<array_size;i++)   //taking array values from user
    {
        cin>>num[i];
        num[i]=i+100;               //adding 100 into the assigned value
    }
    cout<<"arrays in odd index:\n";   //showing odd index
    for(int i=1;i<array_size;i+=2)  
    {
        cout<<endl<<i<<"th  array="<<num[i];
    }
    return 0;
}