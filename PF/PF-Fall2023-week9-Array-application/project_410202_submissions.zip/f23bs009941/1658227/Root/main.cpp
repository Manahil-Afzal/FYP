//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.
#include<iostream>
using namespace std;
int main()
{
    int i,j;
    int arr[10];//array size is not specified
    for(int i=0;i<10;i++)
    {
        arr[i]=i+100;
        
    }for(j=1;j<10;j+=2){
        cout<<arr[j]<<endl;
    }
}