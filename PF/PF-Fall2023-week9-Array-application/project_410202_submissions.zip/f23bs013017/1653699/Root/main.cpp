//Write a C++ program that sets array ith location value to i+100. Display the values assigned to odd index values of array.

#include <iostream>

int main() {
    const int arraySize = 10; // You can change the size as needed
    int myArray[arraySize];

    // Initialize the array with values
    for (int i = 0; i < arraySize; i++) {
        myArray[i] = i + 100;
    }

    // Display the values at odd index positions
    for (int i = 1; i < arraySize; i += 2) {
        std::cout << "myArray[" << i << "] = " << myArray[i] << std::endl;
    }

    return 0;
}
