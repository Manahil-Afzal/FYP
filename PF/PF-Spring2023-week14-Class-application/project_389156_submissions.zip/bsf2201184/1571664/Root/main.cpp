#include <iostream>
#include <string>

using namespace std;

class Utility_Bill {
  string name;
  int bill_number;
  int units_consumed;
  string address;
  float per_unit_price;
public:
  Utility_Bill(string n, int bn, int uc, string a);
  void calculate_bill();
  void display();
};

Utility_Bill::Utility_Bill(string n, int bn, int uc, string a) {
  name = n;
  bill_number = bn;
  units_consumed = uc;
  address = a;
}

void Utility_Bill::calculate_bill() {
  if (units_consumed < 300) {
    per_unit_price = 8.0;
  } else if (units_consumed < 1000) {
    per_unit_price = 5.0;
  } else {
    per_unit_price = 14.0;
  }
}

void Utility_Bill::display() {
  cout << "Customer Name: " << name << endl;
  cout << "Bill Number: " << bill_number << endl;
  cout << "Units Consumed: " << units_consumed << endl;
  cout << "Customer Address: " << address << endl;
  cout << "Per Unit Price: Rs. " << per_unit_price << endl;
  cout << "Total Bill Amount: Rs. " << per_unit_price * units_consumed << endl;
}

int main() {
  string name, address;
  int bill_number, units_consumed;
  
  cout << "Enter customer name: ";
  getline(cin, name);
  cout << "Enter bill number: ";
  cin >> bill_number;
  cout << "Enter units consumed: ";
  cin >> units_consumed;
  cout << "Enter customer address: ";
  cin.ignore();
  getline(cin, address);
  
  Utility_Bill bill(name, bill_number, units_consumed, address);
  bill.calculate_bill();
  bill.display();
  
  return 0;
}
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/