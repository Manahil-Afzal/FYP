/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;

struct Book {
    int bookId, pages;
    double price;
};

int main() {
    Book book1, book2;
    
    cout << "Enter the Book ID of book1: ";
    cin >> book1.bookId;
    cout << "Enter the Price of book1: ";
    cin >> book1.price;
    cout << "Enter the Number of Pages of book1: ";
    cin >> book1.pages;
    
    cout << "Enter the Book ID of book2: ";
    cin >> book2.bookId;
    cout << "Enter the Price of book2: ";
    cin >> book2.price;
    cout << "Enter the Number of Pages of book2: ";
    cin >> book2.pages;
    
    if (book1.price > book2.price) {
        cout << "The record of the more costly book is: " << endl;
        cout << "Book ID: " << book1.bookId << endl;
        cout << "Price: " << book1.price << endl;
        cout << "Number of Pages: " << book1.pages << endl;
    } else {
        cout << "The record of the more costly book is: " << endl;
        cout << "Book ID: " << book2.bookId << endl;
        cout << "Price: " << book2.price << endl;
        cout << "Number of Pages: " << book2.pages << endl;
    }
    
    return 0;
}