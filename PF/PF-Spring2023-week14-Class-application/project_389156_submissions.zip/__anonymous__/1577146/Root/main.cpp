/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include <iostream>
using namespace std;

class UtilityBill {
private:
    string customerName;
    string billNumber;
    int unitsConsumed;
    string customerAddress;
    double perUnitPrice;

public:
    UtilityBill(string name, string number, int units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
        calculatePerUnitPrice();
    }

    void calculatePerUnitPrice() {
        if (unitsConsumed < 300) {
            perUnitPrice = 8;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5;
        } else {
            perUnitPrice = 14;
        }
    }

    double calculateBillAmount() {
        return unitsConsumed * perUnitPrice;
    }

    void displayBill() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Per Unit Price: Rs. " << perUnitPrice << "/-" << endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() << "/-" << endl;
    }
};

int main() {
    string name, number, address;
    int units;

    cout << "Enter Customer Name: ";
    getline(cin, name);

    cout << "Enter Bill Number: ";
    getline(cin, number);

    cout << "Enter Units Consumed: ";
    cin >> units;
    cin.ignore();

    cout << "Enter Customer Address: ";
    getline(cin, address);

    UtilityBill bill(name, number, units, address);
    cout << endl << "Utility Bill Details:" << endl;
    bill.displayBill();

    return 0;
}
