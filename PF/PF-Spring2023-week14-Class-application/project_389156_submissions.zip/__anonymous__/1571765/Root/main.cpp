/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

using namespace std;

class Utility_Bill {
private:
    string customer_name;
    int bill_number;
    int units_consumed;
    string customer_address;
    double per_unit_price;

public:
    Utility_Bill(string name, int bill_no, int units, string address) {
        customer_name = name;
        bill_number = bill_no;
        units_consumed = units;
        customer_address = address;
        
        if(units_consumed < 300) {
            per_unit_price = 8;
        }
        else if(units_consumed >= 300 && units_consumed < 1000) {
            per_unit_price = 5;
        }
        else {
            per_unit_price = 14;
        }
    }

    void display_bill() {
        double bill_amount = units_consumed * per_unit_price;
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;
        cout << "Bill Amount: " << bill_amount << endl;
    }
};

int main() {
	
	string name,customer_address; int bill_num,	units_consumed,per_unit_price;double bill_amount;
	
	cout<<"\n Enter the name of Customer: ";
	getline(cin , name);
	cout<<"\n Enter the customer_address: ";
	getline(cin, customer_address);
	
	cout<<"\n Enter the bill_num of Customer: ";
	cin>>bill_num;
	cout<<"\n Enter the units_consumed: ";
	cin>>units_consumed;
	cout<<"\n Enter the per_unit_price: ";
	cin>>per_unit_price;
	
    Utility_Bill bill1(name, bill_num, units_consumed, customer_address);
    bill1.display_bill();
    
    cout<<"\n Enter the name of Customer: ";
	getline(cin , name);
	cout<<"\n Enter the customer_address: ";
	getline(cin, customer_address);
	
	cout<<"\n Enter the bill_num of Customer: ";
	cin>>bill_num;
	cout<<"\n Enter the units_consumed: ";
	cin>>units_consumed;
	cout<<"\n Enter the per_unit_price: ";
	cin>>per_unit_price;

    Utility_Bill bill2(name, bill_num, units_consumed, customer_address);
    bill2.display_bill();
    
    cout<<"\n Enter the name of Customer: ";
	getline(cin , name);
	cout<<"\n Enter the customer_address: ";
	getline(cin, customer_address);
	
	cout<<"\n Enter the bill_num of Customer: ";
	cin>>bill_num;
	cout<<"\n Enter the units_consumed: ";
	cin>>units_consumed;
	cout<<"\n Enter the per_unit_price: ";
	cin>>per_unit_price;

    Utility_Bill bill3(name, bill_num, units_consumed, customer_address);
    bill3.display_bill();

    return 0;
}