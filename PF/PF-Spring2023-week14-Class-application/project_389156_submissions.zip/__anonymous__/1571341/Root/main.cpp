/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
# include <iostream>
using namespace std;

class Utility_bill{
  private:
   string customer_name;
    string address;
    int unit_consumed;
    public:
      void getdata(){
       cout<<"customer name";
       cin>>customer_name;
        cout<<"Unit consumed by customer";
        cin>>unit_consumed;
        cout<<"address of customer";
        cin>>address;
    } 
    void display(){
       cout<<"customer name"<<customer_name<<endl;
        cout<<"Unit consumed by customer"<<unit_consumed<<endl;
        cout<<"address of customer"<<address<<endl;
    }
    void bill_amount(){
        if(unit_consumed<300){
       unit_consumed*=8;
    }else if(unit_consumed<=300&&unit_consumed>1000){
       unit_consumed*=10;
    }else{
        unit_consumed*=14;
    }
    cout<<"billamount"<<";"<<unit_consumed;
    }
};


main(){
    Utility_bill  Utility_bill1;
    Utility_bill1.getdata();
    Utility_bill1.display();
    Utility_bill1.bill_amount();
    
}