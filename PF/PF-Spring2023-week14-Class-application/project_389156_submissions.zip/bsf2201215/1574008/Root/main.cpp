/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
public:
    void setCustomerInfo(string name, int number, float units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
    }
    
    void calculateBillAmount() {
        if (unitsConsumed < 300) {
            perUnitPrice = 8;
        }
        else if (unitsConsumed < 1000) {
            perUnitPrice = 5;
        }
        else {
            perUnitPrice = 14;
        }
        billAmount = unitsConsumed * perUnitPrice;
    }
    
    void displayBill() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
    
private:
    string customerName;
    int billNumber;
    float unitsConsumed;
    string customerAddress;
    float perUnitPrice;
    float billAmount;
};

int main() {
    string name, address;
    int number;
    float units;
    
    Utility_Bill bill;
    
    cout << "Enter Customer Name: ";
    getline(cin, name);
    cout << "Enter Bill Number: ";
    cin >> number;
    cout << "Enter Units Consumed: ";
    cin >> units;
    cin.ignore(); // To ignore the newline character in the input buffer
    cout << "Enter Customer Address: ";
    getline(cin, address);
    
    bill.setCustomerInfo(name, number, units, address);
    bill.calculateBillAmount();
    bill.displayBill();
    
    return 0;
}