/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
#include <string>

class UtilityBill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;

public:
    UtilityBill(std::string name, int number, int units, std::string address) : customerName(name), billNumber(number), unitsConsumed(units), customerAddress(address) {}

    float calculateBillAmount() {
        float perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed >= 300 && unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        return unitsConsumed * perUnitPrice;
    }

    void displayBill() {
        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Bill Amount: Rs. " << calculateBillAmount() << std::endl;
    }
};

int main() {
    std::string name, address;
    int number, units;

    std::cout << "Enter customer name: ";
    std::getline(std::cin, name);
    std::cout << "Enter bill number: ";
    std::cin >> number;
    std::cout << "Enter units consumed: ";
    std::cin >> units;
    std::cin.ignore(); 
    std::cout << "Enter customer address: ";
    std::getline(std::cin, address);

    UtilityBill bill(name, number, units, address);
    bill.displayBill();

    return 0;
}