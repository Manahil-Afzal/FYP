/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
#include<string>
using namespace std;

class UtilityBill {
  private:
    string customerName;
    string billNumber;
    string customerAddress;
    int unitsConsumed;
    double unitPrice;
    double totalAmount;
    
  public:
    UtilityBill(string name, string number, string address, int units) {
      customerName = name;
      billNumber = number;
      customerAddress = address;
      unitsConsumed = units;
      if(unitsConsumed < 300) {
        unitPrice = 0.08;
      } else if(unitsConsumed >= 300 && unitsConsumed < 1000) {
        unitPrice = 0.05;
      } else {
        unitPrice = 0.14;
      }
      totalAmount = unitPrice * unitsConsumed;
    }
    
    void displayBill() {
      cout << "Customer Name: " << customerName << endl;
      cout << "Bill Number: " << billNumber << endl;
      cout << "Customer Address: " << customerAddress << endl;
      cout << "Units Consumed: " << unitsConsumed << endl;
      cout << "Unit Price: Rs " << unitPrice << endl;
      cout << "Total Amount: Rs " << totalAmount << endl;
    }
};

int main() {
  string name, number, address;
  int units;
  cout << "Enter Customer Name: ";
  getline(cin, name);
  cout << "Enter Bill Number: ";
  getline(cin, number);
  cout << "Enter Customer Address: ";
  getline(cin, address);
  cout << "Enter Units Consumed: ";
  cin >> units;
  UtilityBill bill(name, number, address, units);
  bill.displayBill();
  return 0;
}