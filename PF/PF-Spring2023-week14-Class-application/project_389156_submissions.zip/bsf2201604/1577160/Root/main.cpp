/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
class UtilityBill {
private:
    std::string customer_name;
    int bill_number;
    int units_consumed;
    std::string customer_address;

public:
    UtilityBill(std::string name, int number, int units, std::string address) {
        customer_name = name;
        bill_number = number;
        units_consumed = units;
        customer_address = address;
    }

    void calculate_bill_amount() {
        int per_unit_price;
        if (units_consumed < 300) {
            per_unit_price = 8;
        } else if (units_consumed < 1000) {
            per_unit_price = 5;
        } else {
            per_unit_price = 14;
        }

        int bill_amount = units_consumed * per_unit_price;

        std::cout << "Customer Name: " << customer_name << std::endl;
        std::cout << "Bill Number: " << bill_number << std::endl;
        std::cout << "Units Consumed: " << units_consumed << std::endl;
        std::cout << "Customer Address: " << customer_address << std::endl;
        std::cout << "Bill Amount: Rs. " << bill_amount << std::endl;
    }
};

int main() {
    std::string name, address;
    int bill_number, units_consumed;
    std::cout << "Enter Customer Name: ";
    std::getline(std::cin, name);

    std::cout << "Enter Bill Number: ";
    std::cin >> bill_number;

    std::cout << "Enter Units Consumed: ";
    std::cin >> units_consumed;
    std::cin.ignore(); 
    std::cout << "Enter Customer Address: ";
    std::getline(std::cin, address);
    UtilityBill bill(name, bill_number, units_consumed, address);
    bill.calculate_bill_amount();

    return 0;
}
