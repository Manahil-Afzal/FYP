/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class customer {
public:
    long billNo;
    string address;
    int units;
    string name;
    int billAmount;
    void getDetails();
    void putDetail();
    void billDetail();
};
void customer::getDetails() {
    cout << "enter name ";
    cin >> name;
    cout << "enter your address ";
    cin >> address;
}
void customer :: billDetail() {
    cout << "enter bill no ";
    cin >> billNo;
    cout << "enter cosume units ";
    cin >> units;
    if (units < 300) {
        billAmount =  8 * units;
    }
    else if (units >= 300 && units < 1000) {
        billAmount =  5 * units;
    }
    else
    {
       billAmount = 14 * units;
    }
    cout << "the bill amount is " <<billAmount << endl;
    cout << "consume units is " << units << endl;
}

void customer::putDetail() {
    cout << "customer name is  " << name << endl;
    cout << "customer address is " << address << endl; 
}


int main() {
    customer you;
    you.getDetails();
    you.putDetail();
    you.billDetail();
    return 0;
}


