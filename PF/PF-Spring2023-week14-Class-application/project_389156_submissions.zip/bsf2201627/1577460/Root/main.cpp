/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;

class UtilityBill {
public:
    string name,address;
    float billnum,unitscon,billamount;
};

int main() {
    UtilityBill obj;

    cout << "Enter the name of the customer: ";
    cin >> obj.name;

    cout << "Enter the bill number: ";
    cin >> obj.billnum;

    cout << "Enter the number of units consumed: ";
    cin >> obj.unitscon;

    cout << "Enter the customer's address: ";
    cin >> obj.address;

    // Calculate the bill amount based on units consumed
    if (obj.unitscon < 300) {
        obj.billamount = obj.unitscon * 8;
    } else if (obj.unitscon >= 300 && obj.unitscon < 1000) {
        obj.billamount = obj.unitscon * 5;
    } else if (obj.unitscon > 999) {
        obj.billamount = obj.unitscon * 14;
    }

    cout << "Customer name: " << obj.name << endl;
    cout << "Bill number: " << obj.billnum << endl;
    cout << "Units consumed: " << obj.unitscon << endl;
    cout << "Customer address: " << obj.address << endl;
    cout << "Bill amount: " << obj.billamount << " Rs." << endl;

    return 0;
}
