/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bills{
    public:
    string customer_name;
    int billNo;
    int unit_consumed;
    string customer_address;
};
int main()
{
 utility_bills b1;
 cout<<"Enter the customer name:";
 cin>>b1.customer_name;
 cout<<"Enter the customer bill:";
 cin>>b1.billNo;
 cout<<"Enter the unit consumed:";
 cin>>b1.unit_consumed;
 cout<<"Enter the customer adress:";
 cin>>b1.customer_address;
 //display all the information that is inputed
 cout<<"Customer name:"<<b1.customer_name<<endl;
 cout<<"Customer bill:"<<b1.billNo<<endl;
 cout<<"Customer consumed units:"<<b1.unit_consumed<<endl;
 cout<<"Customer Adress:"<<b1.customer_address<<endl;
 //creating the formula 
 int per_unit_price;
 int bill_price;
 if(b1.unit_consumed<300)
 {
 	per_unit_price=8;
 	bill_price=b1.unit_consumed*per_unit_price;
 	cout<<"Bill Price="<<bill_price<<endl;
 	
 }
 else if(b1.unit_consumed>=300 || b1.unit_consumed<1000)
 {
 	per_unit_price=5;
 	bill_price=b1.unit_consumed*per_unit_price;
 	cout<<"Bill Price="<<bill_price<<endl;
 }
 else if (b1.unit_consumed>999)
 {
 	per_unit_price=14;
 	bill_price=b1.unit_consumed*per_unit_price;
 	cout<<"Bill Price="<<bill_price<<endl;
 }
 else
 {
 	cout<<"you enter the inappropriate units";
 	
 }
 return 0;

}