/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class UtilityBill {
    private:
        string customerName;
        int billNumber;
        int unitsConsumed;
        string customerAddress;
        float perUnitPrice;
        float billAmount;

    public:
        void inputDetails() {
            cout << "Enter customer name: ";
            cin >> customerName;

            cout << "Enter bill number: ";
            cin >> billNumber;

            cout << "Enter units consumed: ";
            cin >> unitsConsumed;

            cout << "Enter customer address: ";
            cin >> customerAddress;
        }

        void calculateBillAmount() {
            if (unitsConsumed < 300) {
                perUnitPrice = 8.0;
            } else if (unitsConsumed < 1000) {
                perUnitPrice = 5.0;
            } else {
                perUnitPrice = 14.0;
            }

            billAmount = unitsConsumed * perUnitPrice;
        }

        void displayDetails() {
            cout << "\nCustomer name: " << customerName << endl;
            cout << "Bill number: " << billNumber << endl;
            cout << "Units consumed: " << unitsConsumed << endl;
            cout << "Customer address: " << customerAddress << endl;
            cout << "Bill amount: " << billAmount << endl;
        }
};

int main() {
    UtilityBill bill;

    bill.inputDetails();
    bill.calculateBillAmount();
    bill.displayDetails();

    return 0;
}
