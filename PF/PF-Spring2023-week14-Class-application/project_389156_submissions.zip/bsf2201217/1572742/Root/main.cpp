/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include <iostream>
#include <iostream>
#include <string>

using namespace std;

class Utility_Bill {
public:
    Utility_Bill(string customer_name, int bill_number, int units_consumed, string customer_address)
        : customer_name(customer_name), bill_number(bill_number), units_consumed(units_consumed), customer_address(customer_address) {}

    void display() {
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;

        double per_unit_price;

        if (units_consumed < 300) {
            per_unit_price = 8;
        }
        else if (units_consumed < 1000) {
            per_unit_price = 5;
        }
        else {
            per_unit_price = 14;
        }

        double bill_amount = units_consumed * per_unit_price;

        cout << "Bill Amount: Rs. " << bill_amount << endl;
    }

private:
    string customer_name;
    int bill_number;
    int units_consumed;
    string customer_address;
};

int main() {
    Utility_Bill bill("John Doe", 12345, 500, "123 Main Street");

    bill.display();

    return 0;
}