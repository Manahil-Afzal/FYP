/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class bills{
    private:
    string name;
    double billno;
    int unit_consumed;
    string customer_address;
    int unit_price;
    int calculateunit;
    public:
   void getdetail();
   void  getdisplay();
};
int main(){
    bills b1;
    b1.getdetail();
    b1.getdisplay();
};
void bills::getdetail(){
    cout<<"enter the name"<<endl;
    cin>>name;
    cout<<"enter the bill no"<<endl;
    cin>>billno;
    cout<<"enter the customer address"<<endl;
    cin>>customer_address;
    cout<<"enter the unit consumed"<<endl;
    cin>>unit_consumed;
    if(unit_consumed<300){
        unit_price=8;
    }else if(unit_consumed>300 && unit_consumed<1000){
         unit_price=5;
    }else if(unit_consumed>999){
              unit_price=14;
    }
    calculateunit= unit_consumed*unit_price;
};
void bills::getdisplay(){
    

    cout<<"your name is "<<name;
    cout<<"your bill no"<<billno;
    cout<<"your unit consumed"<<unit_consumed;
    cout<<"your use nunits is"<<calculateunit;
}