/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class utilityBill{
    private:
        char name[50];
        string billno;
        float units;
        char address[100];
        
    public:
       void takinginput();
    	void displayinput();
        float calculation();
};

int main(){
	utilityBill electricity;
    electricity.takinginput();
    electricity.displayinput();
    cout<<"Your electricity bill is "<<electricity.calculation();
}

void utilityBill :: takinginput(){
    cout<<"Enter your name"<<endl;
    cin.getline(name,50);
    cout<<"Enter your Bill no# "<<endl;
    cin>>billno;
    cin.ignore();
    cout<<"Enter your units consumed "<<endl;
    cin>>units;
    cin.ignore();
    cout<<"Enter your address "<<endl;
    cin.getline(address,100);
    cout<<endl;
}

void utilityBill :: displayinput(){
    cout<<"Your name is "<<name<<endl;
    cout<<"Your Bill no. is "<<billno<<endl;
    cout<<"Your consumed units are "<<units<<endl;
    cout<<"Your address is "<<endl<<address<<endl;
    cout<<endl;
}

float utilityBill :: calculation(){
    float cost=0;
    if(units<300){
        cost = units*8;
    }else if(units>=300 && units<1000){
        cost = units*5;
    }else if(units>999){
        cost = units*14;
    }
    return cost;
}