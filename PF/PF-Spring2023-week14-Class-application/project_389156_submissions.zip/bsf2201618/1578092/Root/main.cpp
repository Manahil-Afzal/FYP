/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include <string>
using namespace std;

class UtilityBill
{
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    void getInput();
    void calculateBill();
    void displayBill();
};

void UtilityBill::getInput()
{
    cout << "Enter customer name: ";
    getline(cin, customerName);

    cout << "Enter bill number: ";
    cin >> billNumber;

    cout << "Enter units consumed: ";
    cin >> unitsConsumed;
    cin.ignore();

    cout << "Enter customer address: ";
    getline(cin, customerAddress);
}

void UtilityBill::calculateBill()
{
    int perUnitPrice;

    if (unitsConsumed < 300)
    {
        perUnitPrice = 8;
    }
    else if (unitsConsumed < 1000)
    {
        perUnitPrice = 5;
    }
    else
    {
        perUnitPrice = 14;
    }

    int billAmount = unitsConsumed * perUnitPrice;

    cout << "Bill amount: " << billAmount << endl;
}

void UtilityBill::displayBill()
{
    cout << "Customer name: " << customerName << endl;
    cout << "Bill number: " << billNumber << endl;
    cout << "Units consumed: " << unitsConsumed << endl;
    cout << "Customer address: " << customerAddress << endl;
}

int main()
{
    UtilityBill bill;
    bill.getInput();
    bill.calculateBill();
    bill.displayBill();

    return 0;
}