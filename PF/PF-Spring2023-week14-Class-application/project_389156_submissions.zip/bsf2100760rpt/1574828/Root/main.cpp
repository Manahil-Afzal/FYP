/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    
public:
    UtilityBill() {}
    
    void input(){
        cout<<"Enter Name:"<<endl;
        cin>>customerName;
        cout<<"Enter Bill_Number:"<<endl;
        cin>>billNumber;
        cout<<"Enter Units_Consumed:"<<endl;
        cin>>unitsConsumed;
        cout<<"Enter Customer_Address:"<<endl;
        cin>>customerAddress;
    }
    void displayBill() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        
        double perUnitPrice;
        
        if (unitsConsumed < 300) {
            perUnitPrice = 8;
        }
        else if (unitsConsumed < 1000) {
            perUnitPrice = 5;
        }
        else {
            perUnitPrice = 14;
        }
        
        double billAmount = unitsConsumed * perUnitPrice;
        cout << "Bill Amount: " << billAmount << endl;
    }
};

int main() {
    UtilityBill bill;
    bill.input();
    bill.displayBill();
    return 0;
}
