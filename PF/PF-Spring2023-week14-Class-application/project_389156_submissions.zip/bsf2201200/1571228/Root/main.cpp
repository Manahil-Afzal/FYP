/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
private:
    string name;
    int bill_number;
    int units_consumed;
    string address;
    float per_unit_price;
    float bill_amount;

public:
    Utility_Bill(string n, int bn, int uc, string addr) {
        name = n;
        bill_number = bn;
        units_consumed = uc;
        address = addr;
        if (units_consumed < 300) {
            per_unit_price = 8.0;
        } else if (units_consumed < 1000) {
            per_unit_price = 5.0;
        } else {
            per_unit_price = 14.0;
        }
        bill_amount = units_consumed * per_unit_price;
    }

    
    void display() {
        cout << "Customer Name: " << name << "\n";
        cout << "Bill Number: " << bill_number << "\n";
        cout << "Units Consumed: " << units_consumed << "\n";
        cout << "Customer Address: " << address << "\n";
        cout << "Per Unit Price: Rs. " << per_unit_price << "\n";
        cout << "Bill Amount: Rs. " << bill_amount << "\n";
    }
};

int main() {
    
    Utility_Bill bill("John Doe", 123456, 500, "123 Main St");

    bill.display();

    return 0;
}