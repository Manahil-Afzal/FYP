/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class UtilityBill {
    string customer_name;
    long bill_number;
    int units_consumed;
    int price;
    string address;
    double bill_amount;

public:
    void getdata() {
        cout << "Enter details:\n";
        cout << "Customer name: ";
        cin >> customer_name;
        cout << "Bill number: ";
        cin >> bill_number;
        cout << "Units consumed: ";
        cin >> units_consumed;
        cout << "Customer address: ";
        cin >> address;

        if (units_consumed < 300)
            price = 8;
        else if (units_consumed >= 300 && units_consumed < 1000)
            price = 5;
        else if (units_consumed >= 1000)
            price = 14;

        bill_amount = price * units_consumed;
    }

    void putdata() {
        cout << "\nDetails:\n";
        cout << "Customer name: " << customer_name << endl;
        cout << "Bill number: " << bill_number << endl;
        cout << "Address: " << address << endl;
        cout << "Units consumed: " << units_consumed << endl;
        cout << "Bill amount: " << bill_amount << endl;
    }
};

int main() {
    UtilityBill Mybill;
    Mybill.getdata();
    Mybill.putdata();
    return 0;
}

