/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

using namespace std;

class UtilityBill {
private:
    string customerName;
    string billNumber;
    int unitsConsumed;
    string customerAddress;
    float perUnitPrice;

public:
    UtilityBill(string name, string number, int units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        }
        else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        }
        else {
            perUnitPrice = 14.0;
        }
    }

    void displayBill() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Per Unit Price: Rs. " << perUnitPrice << endl;
        float billAmount = unitsConsumed * perUnitPrice;
        cout << "Total Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    string name, number, address;
    int units;
    cout << "Enter customer name: ";
    getline(cin, name);
    cout << "Enter bill number: ";
    getline(cin, number);
    cout << "Enter units consumed: ";
    cin >> units;
    cin.ignore();
    cout << "Enter customer address: ";
    getline(cin, address);
    UtilityBill bill(name, number, units, address);
    bill.displayBill();
    return 0;
}