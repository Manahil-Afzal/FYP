/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumedare greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
#include <string>

using namespace std;

class Utility_Bill {
    private:
        string customer_name;
        int bill_number;
        int units_consumed;
        string customer_address;
        float per_unit_price;

    public:
        Utility_Bill(string name, int number, int units, string address) {
            customer_name = name;
            bill_number = number;
            units_consumed = units;
            customer_address = address;

            if (units_consumed < 300) {
                per_unit_price = 8.0;
            } else if (units_consumed < 1000) {
                per_unit_price = 5.0;
            } else {
                per_unit_price = 18.0;
            }
        }

        void display_bill() {
            float bill_amount = units_consumed * per_unit_price;
            cout << "Customer Name: " << customer_name << endl;
            cout << "Bill Number: " << bill_number << endl;
            cout << "Units Consumed: " << units_consumed << endl;
            cout << "Customer Address: " << customer_address << endl;
            cout << "Per Unit Price: " << per_unit_price << endl;
            cout << "Bill Amount: " << bill_amount << endl;
        }
};

int main() {
    string customer_name, customer_address;
    int bill_number, units_consumed;

    cout << "Enter Customer Name: ";
    getline(cin, customer_name);

    cout << "Enter Bill Number: ";
    cin >> bill_number;

    cout << "Enter Units Consumed: ";
    cin >> units_consumed;

    cin.ignore();
    cout << "Enter Customer Address: ";
    getline(cin, customer_address);

    Utility_Bill bill(customer_name, bill_number, units_consumed, customer_address);
    bill.display_bill();

    return 0;
}

