// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;
int main()
{
float arr[5];//size should be 5
int i;
cout<<"enter five floating-point values:";

for(int i=0;i<5;i++)//condition should be i smaller than 5
cin>>arr[i];//array syntax 
cout<<"values in reverse order"<<endl;
for(i=4;i>=0;i--)//i should be equal to 4
cout<<arr[i];
}