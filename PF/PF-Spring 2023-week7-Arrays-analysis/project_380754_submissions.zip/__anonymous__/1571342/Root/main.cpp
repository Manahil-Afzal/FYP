// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main()
{
    const int SIZE = 5; // corrected array size to 5
    float arr[SIZE];
    int i;

    cout << "Enter five floating-point values: ";

    for (i = 0; i < SIZE; i++) { // corrected the loop condition and array index
        cin >> arr[i];
    }

    cout << "Values in reverse order:\n";

    for (i = SIZE - 1; i >= 0; i--) { // corrected the loop condition and added a newline character
        cout << arr[i] << endl;
    }

    return 0;
}
