// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main()
{
    float arr[5];  // Corrected error: Changed array size to 5 to match the number of input values
    cout << "Enter five floating-point values: ";

    for (int i = 0; i < 5; i++)  // Corrected error: Changed the condition from i <= 5 to i < 5
    {
        cin >> arr[i];
    }
    
    cout << "Values in reverse order:" << endl;
    for (int i = 4; i >= 0; i--)  // Corrected error: Changed the initial value of i from 0 to 4 and the condition from i > 0 to i >= 0
    {
        cout << arr[i] << " ";
    }

    return 0;
}

