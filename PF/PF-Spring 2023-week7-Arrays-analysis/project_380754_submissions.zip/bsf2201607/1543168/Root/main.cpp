// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main() {
   int arr[10];

   for(int i=0; i<10; i++) {
      arr[i] = i+100;
   }

   for(int i=1; i<10; i+=2) {
      cout << "Value at index " << i << " is: " << arr[i] << endl;
   }

   return 0;
}