#include <iostream>
using namespace std;

int main()
{
    const int SIZE = 4;
    float arr[SIZE];
    int i;
    
    cout << "Enter " << SIZE << " floating-point values: ";
    for(i = 0; i < SIZE; i++)
    {
        cin >> arr[i];
    }
    
    cout << "Values in reverse order: ";
    for(i = SIZE - 1; i >= 0; i--)
    {
        cout << arr[i] << " ";
    }
    
    return 0;
}