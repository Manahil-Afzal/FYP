// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main()
{
    const int array_size = 5;
    float arr[array_size];
    int i;

    cout << "Enter five floating-point values: ";

    for(i = 0; i < array_size; i++) {
        cin >> arr[i];
    }

    cout << "Values in reverse order:" << endl;
    for(i = array_size - 1; i >= 0; i--) {
        cout << arr[i] << endl;
    }

    return 0;
}
