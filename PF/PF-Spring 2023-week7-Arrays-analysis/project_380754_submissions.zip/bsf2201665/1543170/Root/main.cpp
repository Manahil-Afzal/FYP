// This program inputs five floating point values in an array and displays the values in reverse order in which the user has entered.

#include <iostream>
using namespace std;

int main()
{
    const int SIZE = 5;
    float arr[SIZE];
    
    cout << "Enter five floating-point values: ";
    
    for(int i = 0; i < SIZE; i++) {
        cin >> arr[i];
    }
    
    cout << "Values in reverse order:" << endl;
    
    for(int i = SIZE-1; i >= 0; i--) {
        cout << arr[i] << endl;
    }
    
    return 0;
}

