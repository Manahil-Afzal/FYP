/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;int i=1;

    cout<<"Enter a positive integer: ";
    cin>>n;

    for (i=1;i<=n;i++) 
        sum += i;
    
    cout << "Sum = " << sum;
    return 0;
}