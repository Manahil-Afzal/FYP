/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    
    int n, sum ;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 10; i <= n; i+10) {
        sum += i;
    
    cout << "Sum += "<<n << sum;
    return 0;
}
}