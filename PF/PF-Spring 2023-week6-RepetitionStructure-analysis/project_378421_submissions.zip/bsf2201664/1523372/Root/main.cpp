/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include<iostream>//sapce after include
using namespace std;
main()//int before main
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i+1)
    {
        sum += i;
    }
    cout << "Sum = " << sum;
    return 0;
}