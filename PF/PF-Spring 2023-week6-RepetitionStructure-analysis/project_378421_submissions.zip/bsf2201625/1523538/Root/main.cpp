/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( int i = 1; i <= n; i++) // variable i was not declared and commas were used instead of semi colons
    {
        sum += i;
    } // closing brackets were missing
    
    cout << "Sum = " << sum;
    return 0;
}