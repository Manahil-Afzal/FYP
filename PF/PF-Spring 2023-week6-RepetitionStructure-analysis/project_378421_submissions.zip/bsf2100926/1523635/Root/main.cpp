/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;
int main()
{
    int i, n, sum = 0;
    cout << "Enter a positive integer: ";
    cin >> n;

    for( i = 1; i <= n; i+1){    // i was not initilized and instead of  semi colon colon was there
        sum += i;
    } // curely braces was not there.
    cout << "Sum = " << sum;
    return 0;
}