/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++) { // corrected the syntax of the for loop
        sum += i;
    }

    cout << "Sum = " << sum << endl; // added the missing semicolon and a newline character
    return 0;
}
