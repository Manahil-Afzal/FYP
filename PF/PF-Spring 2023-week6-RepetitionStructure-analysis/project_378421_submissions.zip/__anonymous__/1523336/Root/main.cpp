/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0,i; //i is not declared below 

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( i = 1; i <= n;i++) {   //you have to write the  ';'  instead of  ',' 
        sum += i;
    } //not written the ending braces of scope
    cout << "Sum = " << sum;
    return 0;
}