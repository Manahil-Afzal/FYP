/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++)//Replace comma with semicolon and declare variable
    {
        sum += i;
    }//Insert close brace
    cout << "Sum = " << sum;
    return 0;
}