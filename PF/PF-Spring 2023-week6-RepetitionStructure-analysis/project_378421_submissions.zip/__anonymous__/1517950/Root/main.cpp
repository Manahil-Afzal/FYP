/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;
main()
{
    int n, sum = 0;
int i;
    cout << "Enter a positive integer: ";
    cin >> n;
    for ( i=1; i<= n; i+1)
    {
        sum += i;
    
    cout <<"Sum = "<<sum;
    }
}