/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;
    // i is not decleared in this scope
//use comma infront of i=1; 
//increment and decrement is not correct 
// curle bracket is also missing
    for ( int i=1; i<= n; i++) {
        sum += i;
    
    cout << "Sum = " << sum;
    }

}