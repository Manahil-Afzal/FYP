/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++)   // semicolon and increment and add datatype
    {
        sum += i;
    
    cout << "Sum = " << sum<<endl;
        
    }  // curly bracket close
    return 0;
}