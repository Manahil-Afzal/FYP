/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum=0 ;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++)//variable not declare & "," was used instead of ";"
    {
        sum += i;
    
}// this brace was missing
    
    cout << "Sum = " << sum<<endl;
    return 0;
}
