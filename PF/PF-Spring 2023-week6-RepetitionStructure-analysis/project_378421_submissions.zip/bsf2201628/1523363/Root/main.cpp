/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0,i;       //i is not declared 

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( i = 1; i <= n;i++) {              //use ; and use increment ++
        sum += i;
    }                           //closing breaket } is not mention
    cout << "Sum = " << sum;
    return 0;
}