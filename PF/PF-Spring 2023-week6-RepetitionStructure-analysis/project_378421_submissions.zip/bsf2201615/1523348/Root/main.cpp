/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n,i, sum = 0;// declaration of i

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( i = 1; i <= n; i+1) { // use semicolom instead of comma
        sum += i;
    
    cout << "Sum = " << sum;
    return 0;}
}