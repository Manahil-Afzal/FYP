/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( n = 1; n <=10; n++)
        sum += n;
    
    cout << "Sum = " << sum;
    return 0;
}