/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include<iostream>
using namespace std;
 main()
{
    int i,n; 
    int sum =0;

    cout <<"Enter a positive integer:";
    cin >> n;

    for ( i=1; i<=n; i++);
    {
        sum += i;
    }
    cout << "Sum = " << sum;

}