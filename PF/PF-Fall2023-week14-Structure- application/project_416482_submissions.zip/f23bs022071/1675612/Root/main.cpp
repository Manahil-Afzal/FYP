/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;

struct {
string id;
int price;
int pages;
}bookid,bookid1;
int main(){
	int n;
	cout<<"Enter the book id :";
	cin>>bookid.id;
	cout<<"Enter the price of the book :";
	cin>>bookid.price;
	cout<<"Enter its number of pages :";
	cin>>bookid.pages;
	cout<<"Enter the book 2 id :";
	cin>>bookid1.id;
	cout<<"Enter the price of the book 2 :";
	cin>>bookid1.price;
	cout<<"Enter its number of pages 2 :";
	cin>>bookid1.pages;

		if(bookid.price>bookid1.price)
{
cout<<"The most Costly Book is :"<<bookid.id<<" "<<"with a price of"<<" "<<bookid.price;}
	else
	
cout<<"The most Costly Book is :"<<bookid1.id<<" "<<"with a price of"<<" "<<bookid1.price;

}
