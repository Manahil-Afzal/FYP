/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
	int bookid;
	float price;
	int pages;
};
int main()
{
	book book1,book2;
	cout<<"details of book1 are";
	cout<<endl<<" id of book1 is:";
	cin>>book1.bookid;
	cout<<"price of book1 is:";
	cin>>book1.price;
	cout<<"pages of book1 are:";
	cin>>book1.pages;
	cout<<"details of book2 are";
	cout<<endl<<"id of book2 is:";
	cin>>book2.bookid;
	cout<<endl<<"price of book2 is:";
	cin>>book2.price;
	cout<<endl<<"pages of book2 are:";
	cin>>book2.pages;
	if(book1.price>book2.price)
	{
		cout<<"book1 is more costly";
		cout<<endl<<"price= "<<book1.price;
		cout<<endl<<"id= "<<book1.bookid;
		cout<<endl<<"pages= "<<book1.pages;
	}
	else
	{
	cout<<"book2 is more costly";
	cout<<endl<<"price= "<<book2.price;
	cout<<endl<<"id= "<<book2.bookid;
	cout<<endl<<"pages= "<<book2.pages;
	}
	return 0;
}