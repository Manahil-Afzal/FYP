/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
    int bookid;
    int price;
    int pages;
};
int main()
{
    book b1,b2;
   
    cout<<"Enter book1 Id:";
    cin>>b1.bookid;
    cout<<"Enter book1 price:";
    cin>>b1.price;
    cout<<"Enter book1 pages:";
    cin>>b1.pages;
     cout<<"Enter book2 Id:";
    cin>>b2.bookid;
    cout<<"Enter book2 price:";
    cin>>b2.price;
    cout<<"Enter book2 pages:";
    cin>>b2.pages;
    if(b1.price>b2.price){
    cout<<"book1 is costly.";
    cout<<"Id of book1:"<<b1.bookid<<endl;
    cout<<"price of book1:"<<b1.price<<endl;
    cout<<"pages of book1:"<<b1.pages<<endl;}
    else
    {
    cout<<"book2 is costly.";
    cout<<"Id of book2:"<<b2.bookid<<endl;
    cout<<"price of book2:"<<b2.price<<endl;
    cout<<"pages of book2:"<<b2.pages<<endl;}
    return 0;
    
}