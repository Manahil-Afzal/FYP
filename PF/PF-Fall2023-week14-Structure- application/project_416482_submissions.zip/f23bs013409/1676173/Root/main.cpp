/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
#include<string>
using namespace std;
struct book
{
    string book_id;
    float book_price;
    int book_pages;
    
};
int main()
{
    book book1,book2;
    cout<<"Enter Book 1 id :"<<endl;
    cin>>book1.book_id;
    cout<<"Enter Book 1 Price :"<<endl;
    cin>>book2.book_price;
    cout<<"Enter Book 1 Pages :"<<endl;
    cin>>book1.book_pages;
    cout<<"These are Book 1 Details :"<<endl;
    cout<<"Enter Book 2 id :"<<endl;
    cin>>book1.book_id;
    cout<<"Enter Book 2 Price :"<<endl;
    cin>>book2.book_price;
    cout<<"Enter Book 2 Pages :"<<endl;
    cin>>book2.book_pages;
    cout<<"These are Book 2 Details :"<<endl;
    if(book1.book_price>book2.book_price)
    {
        cout<<"Record of Costly Book is :"<<endl;
          cout<<"Record of Costly Book is :"<<endl;
        cout<<"Book Id :"<<book2.book_id<<endl;
        cout<<"Book Price :"<<book2.book_price<<endl;
        cout<<"Book Pages :"<<book2.book_pages<<endl;
        cout<<"Book 1 is More Expensive"<<endl;
        
    }
    
    else
    {
        cout<<"Record of Costly Book is :"<<endl;
        cout<<"Book Id :"<<book2.book_id<<endl;
        cout<<"Book Price :"<<book2.book_price<<endl;
        cout<<"Book Pages :"<<book2.book_pages<<endl;
        cout<<"Book 2 is More Expensive"<<endl;
        
    }
    return 0;
}