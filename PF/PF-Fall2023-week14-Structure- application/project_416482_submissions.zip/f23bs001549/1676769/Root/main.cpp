/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
struct Book {
    int bookId;
    float price;
    int pages;
};
int main() {
    Book book1, book2;
    cout << "Enter details for Book 1:\n";
    cout << "Book ID: ";
    cin >> book1.bookId;
    cout << "Price: ";
    cin >> book1.price;
    cout << "Pages: ";
    cin >> book1.pages;
    cout << "\nEnter details for Book 2:\n";
    cout << "Book ID: ";
    cin >> book2.bookId;
    cout << "Price: ";
    cin >> book2.price;
    cout << "Pages: ";
    cin >> book2.pages;
    if (book1.price > book2.price) {
        cout << "\nBook 1 is more costly:\n";
        cout << "Book ID: " << book1.bookId << endl;
        cout << "Price: " << book1.price << endl;
        cout << "Pages: " << book1.pages << endl;
    } else {
        cout << "\nBook 2 is more costly:\n";
        cout << "Book ID: " << book2.bookId << endl;
        cout << "Price: " << book2.price << endl;
        cout << "Pages: " << book2.pages << endl;
    }
    return 0;
}