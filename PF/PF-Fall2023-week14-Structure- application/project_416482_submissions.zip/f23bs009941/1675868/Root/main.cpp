/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
    struct book
    {
    int bookid;
    int price;
    int pages;
    };
    int main()
    {
    book book1,book2;
    cout<<"enter book1 id";
    cin>>book1.bookid;
    cout<<"enter book1 price";
    cin>>book1.price;
    cout<<"enter book 1 pages";
    cin>>book1.pages;
    cout<<"enter book2 id";
    cin>>book2.bookid;
    cout<<"enter book2 price";
    cin>>book2.price;
    cout<<"enter book 2 pages";
    cin>>book2.price;
    if(book1.price>book2.price)
    {
        cout<<"book 1 is costly";
        cout<<book1.bookid;
        cout<<book1.price;
        cout<<book1.pages;
    }
    else
    cout<<"book 2 is more costly";
    cout<<book2.bookid;
        cout<<book2.price;
        cout<<book2.pages;
    return 0;
    
}