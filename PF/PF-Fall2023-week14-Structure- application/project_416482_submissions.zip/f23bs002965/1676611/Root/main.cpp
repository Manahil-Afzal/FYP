/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Book{
    int bookID;
    double price;
    int pages;
} b1,b2;
int main(){
    cout<<"Enter the bookID:"<<endl;
    cin>>b1.bookID;
    cout<<"Enter the price:"<<endl;
    cin>>b1.price;
    cout<<"Enter the pages:"<<endl;
    cin>>b1.pages;
    cout<<"For b2:"<<endl;
    cout<<"Enter the bookID:"<<endl;
    cin>>b2.bookID;
    cout<<"Enter the price:"<<endl;
    cin>>b2.price;
    cout<<"Enter the pages:"<<endl;
    cin>>b2.pages;
    if(b1.price>b2.price){
        cout<<"Display:"<<endl;
        cout<<b1.bookID;
        cout<<b1.price;
        cout<<b1.pages;
    }else{
        cout<<"Display:"<<endl;
        cout<<b2.bookID<<endl;
        cout<<b2.price<<endl;
        cout<<b2.pages;
    }
    
}