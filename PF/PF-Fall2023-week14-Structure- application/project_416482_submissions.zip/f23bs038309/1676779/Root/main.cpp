/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
	int bookid;
	double price;
	int pages;
};
int main()
{
	book b1,b2;
     //book 1 input 
	cout<<"Book #1:\nBook I'D'=";
	cin>>b1.bookid;
	cout<<"Price of Book=";
	cin>>b1.price;
	cout<<"Pages of Book=";
	cin>>b1.pages;
	//book 2 input 
	cout<<endl<<"Book #2:\nBook I'D'=";
	cin>>b2.bookid;
	cout<<"Price of Book=";
	cin>>b2.price;
	cout<<"Pages of Book=";
	cin>>b2.pages;
    //determination of more costly book
	if(b1.price>b2.price)	
	{
	cout<<endl<<"The detail of more costful book are:";
	cout<<endl<<"Book_I'D"<<b1.bookid;
	cout<<endl<<"Book_Price"<<b1.price;
	cout<<endl<<"Book_Pages"<<b1.pages;
	}
	else
	{
	cout<<endl<<"The detail of more costful book are:";
	cout<<endl<<"Book_I'D="<<b1.bookid;
	cout<<endl<<"Book_Price="<<b1.price;
	cout<<endl<<"Book_Pages="<<b1.pages;
	}
	return 0;
}
