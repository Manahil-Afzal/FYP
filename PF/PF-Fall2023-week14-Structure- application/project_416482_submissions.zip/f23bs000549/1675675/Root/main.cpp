/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
#include<string>
using namespace std;
struct my_library
{
	string book_id;
	int price;
	int pages;	
};
int main()
{
	my_library book1,book2;
	cout<<"Enter Detail for book1...."<<endl;
	cout<<"Enter Book ID: ";
	cin>>book1.book_id;
	cout<<"Enter Price of Book:";
	cin>>book1.price;
	cout<<"Enter Book Pages:";
	cin>>book1.pages;
	cout<<"Enter Detail for book2...."<<endl;
	cout<<"Enter Book ID: ";
	cin>>book2.book_id;
	cout<<"Enter Price of Book:";
	cin>>book2.price;
	cout<<"Enter Book Pages:";
	cin>>book2.pages;
	my_library costlybook=(book1.price>book2.price)?book1:book2;
	cout<<"The book which is more costly"<<endl;
	cout<<"Price:	"<<costlybook.price<<endl;
	cout<<"Book ID:	"<<costlybook.book_id<<endl;
	cout<<"Pages:	"<<costlybook.pages<<endl;
	
	return 0;
	
}