/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
    int bookId;
    int price;
    int pages;
};
int main()
{
    book book1,book2;
    book1.bookId=12;
    book1.price=12000;
    book1.pages=100;
    book2.bookId=13;
    book2.price=14000;
    book2.pages=90;
    cout<<"The record of most costly book is:"<<endl;
    if(book1.price>book2.price)
    {
        cout<<"The book id is"<<book1.bookId<<endl<<"The book price is"<<book1.price<<endl<<"The book pages is"<<book1.pages;
    }
    else{
        cout<<"The book id is"<<book2.bookId<<endl<<"The book price is"<<book2.price<<endl<<"The book pages is"<<book2.pages;
    }
}