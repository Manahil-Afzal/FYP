/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
using namespace std;

struct book {
  	int bookid;
  	int price;
  	int book_pages;
};
int main(){


book book1,book2;
cout<<"Enter The book Id"<<endl;
cin>>book1.bookid;
cout<<"Enter The book price"<<endl;
cin>>book1.price;
cout<<"Enter The book pages"<<endl;
cin>>book1.book_pages;
cout<<"Enter The second Book Data"<<endl;
cout<<"Enter The book Id"<<endl;
cin>>book2.bookid;
cout<<"Enter The book price"<<endl;
cin>>book2.price;
cout<<"Enter The book pages"<<endl;
cin>>book2.book_pages;
if(book2.price>book1.price){

cout<<"The book id  of costly book is "<<book2.bookid<<endl;
cout<<"The book price of costly book is is "<<book2.price<<endl;
cout<<"The book pages  of costly book  is "<<book2.book_pages<<endl;}
else {

cout<<"The book id of costly book is "<<book1.bookid<<endl;
cout<<"The book price  of costly book is "<<book1.price<<endl;
cout<<"The book pages  of costly book5  is "<<book1.book_pages<<endl;}
}
