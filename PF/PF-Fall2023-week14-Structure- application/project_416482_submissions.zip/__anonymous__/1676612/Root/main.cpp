/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
#include<string>
using namespace std;
struct book
{
string  bookid;
int price;
string pages;
};
int main()
{
    book book1,book2;
    cout<<"Enter details for book 1"<<"\n";
    cout<<"Enter Bookid";
    cin>>book1.bookid;
    cout<<"Enter price:$";
    cin>>book1.price;
    cout<<"Enter pages";
    cin>>book1.pages;
    cout<<"\n";
    cout<<"Enter details for book 2"<<"\n";
    cout<<"Enter bookid";
    cin>>book2.bookid;
    cout<<"Enter prices:$";
    cin>>book2.price;
    cout<<"Enter pages of book";
    cin>>book2.pages;
    if (book1.price > book2.price) 
    {
        cout << "\nBook 1 is more costly:" << endl;
        cout << "Book ID: " << book1.bookid << endl;
        cout << "Price: $" << book1.price << endl;
        cout << "Number of pages: " << book1.pages << endl;
    } 
    else if (book2.price > book1.price) 
    {
        cout << "\nBook 2 is more costly:" << endl;
        cout << "Book ID: " << book2.bookid << endl;
        cout << "Price: $" << book2.price << endl;
        cout << "Number of pages: " << book2.pages << endl;
    } 
    else 
    {
        cout << "\nBoth books have the same price." << endl;
    }

    return 0;
}
