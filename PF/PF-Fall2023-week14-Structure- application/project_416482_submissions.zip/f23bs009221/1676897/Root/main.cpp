/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
	struct Book
	{
		char bookId[50];
		float bookPrice;
		int bookPages;
	};
	int main(){
		Book *bookPtr, book1,book2;
		bookPtr=&book1;
		bookPtr=&book2;
		cout<<"Enter details of Book1: "<<endl;
		cout<<"Enter Book Id: "<<endl;
		cin>>bookPtr->bookId;
		cout<<"Enter the price of the Book "<<endl;
		cin>>bookPtr->bookPrice;
		cout<<"Enter pages of the Book "<<endl;
		cin>>bookPtr->bookPages;
		cout<<"Enter details of Book2 "<<endl;
		cout<<"Enetr Book Id: "<<endl;
		cin>>bookPtr->bookId;
		cout<<"Enter the price of the Book: "<<endl;
		cin>>bookPtr->bookPrice;
		cout<<"Enter pages of the Book "<<endl;
		cin>>bookPtr->bookPages;
		
		if(book1.bookPrice>book2.bookPrice){
			cout<<"Book1 is costly "<<endl;
		}
		else{
			cout<<"Book2 is costly "<<endl;
		}
		
		return 0;
	}
	