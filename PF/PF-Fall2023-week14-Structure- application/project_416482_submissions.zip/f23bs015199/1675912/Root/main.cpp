/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/#include<iostream>

using namespace std;

// Define the structure to store Book information
struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    // Declare two structure variables
    Book book1, book2;

    // Input values for the first book
    cout << "Enter details for the first book:" << endl;
    cout << "Book ID: ";
    cin >> book1.bookId;
    cout << "Price: ";
    cin >> book1.price;
    cout << "Number of pages: ";
    cin >> book1.pages;

    // Input values for the second book
    cout << "\nEnter details for the second book:" << endl;
    cout << "Book ID: ";
    cin >> book2.bookId;
    cout << "Price: ";
    cin >> book2.price;
    cout << "Number of pages: ";
    cin >> book2.pages;

    // Determine the more costly book
    Book moreCostlyBook = (book1.price > book2.price) ? book1 : book2;

    // Display the record of the more costly book
    cout << "\nDetails of the more costly book:" << endl;
    cout << "Book ID: " << moreCostlyBook.bookId << endl;
    cout << "Price: " << moreCostlyBook.price << endl;
    cout << "Number of pages: " << moreCostlyBook.pages << endl;

    return 0;
}
