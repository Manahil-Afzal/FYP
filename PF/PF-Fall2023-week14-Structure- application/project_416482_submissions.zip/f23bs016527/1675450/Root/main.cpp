/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct details{
	 int bookid;
	 float price;
	 int pages;	 
};
 int main(){
 	 details book1,book2,book3;
 	 //book1
 	 cout<<"enter book 1 details :"<<endl;
 	 cout<<"bookid : ";
 	 cin>>book1.bookid;
 	 cout<<"book price : ";
 	 cin>>book1.price;
 	 cout<<"Pages of book : ";
 	 cin>>book1.pages;
 	 //book2
 	 cout<<"enter book 2 detaisl : "<<endl;
 	 cout<<"bookid : ";
 	 cin>>book2.bookid;
 	 cout<<"book price :";
 	 cin>>book2.price;
 	 cout<<"pages of book : ";
 	 cin>>book2.pages;
 	 if(book1.price>book2.price){
 	 	cout<<"Book1 is costly as compared to book2 having price : "<<book1.price;
	  }else{
	  	cout<<"Book2 is costly as compared to book1 having price : "<<book2.price;
	  }	
 }
