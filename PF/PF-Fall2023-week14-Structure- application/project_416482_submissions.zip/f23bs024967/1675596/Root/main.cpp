/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {
    Book book1, book2;
    cout << "Enter details for Book 1:\n";
    cout << "Book ID: ";
    cin >> book1.bookId;
    cout << "Price: ";
    cin >> book1.price;
    cout << "Number of pages: ";
    cin >> book1.pages;
    cout << "\nEnter details for Book 2:\n";
    cout << "Book ID: ";
    cin >> book2.bookId;
    cout << "Price: ";
    cin >> book2.price;
    cout << "Number of pages: ";
    cin >> book2.pages;
    Book moreCostlyBook = (book1.price > book2.price) ? book1 : book2;
    cout << "\nDetails of the more costly book:\n";
    cout << "Book ID: " << moreCostlyBook.bookId << "\n";
    cout << "Price: " << moreCostlyBook.price << "\n";
    cout << "Number of pages: " << moreCostlyBook.pages << "\n";

    return 0;
}
