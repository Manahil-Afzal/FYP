/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
#include<string>
using namespace std;
struct book
{ int pages;
float price;
string bookId;
} book1,book2;
int main()
{ cout<<"enter information for book 1.\n";
cout<<"enter the book pages"<<endl;
cin>>book1.pages;
cout<<"enter the price of book"<<endl;
cin>>book1.price;
cout<<"enter the id of book"<<endl;
cin>>book1.bookId;
cout<<"enter the information for book 2\n";
cout<<"enter the book pages"<<endl;
cin>>book2.pages;
cout<<"enter the price of book"<<endl;
cin>>book2.price;
cout<<"enter the id of book"<<endl;
cin>>book2.bookId;
if(book1.price>book2.price)
{ cout<<"entering information for book 1"<<endl;
cout<<book1.pages<<endl;
cout<<book1.price<<endl;
cout<<book1.bookId<<endl; }
else if (book1.price<book2.price)
{ cout<<"displaying information for book 2"<<endl;
cout<<book2.pages<<endl;
cout<<book2.price<<endl;
cout<<book2.bookId<<endl; }
else
cout<<"both books have same price"<<endl;
return 0; }