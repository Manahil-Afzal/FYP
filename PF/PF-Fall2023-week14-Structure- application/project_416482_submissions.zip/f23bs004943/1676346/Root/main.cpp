/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
using namespace std;
struct book
{
	int bookId;
	int price;
	int pages;
	
}; 
int main()
{
    struct book english;
    struct book urdu;
	english.bookId;
	english.price;
	english.pages;
	cout<<"the bookId of english book is ";
	cin>>english.bookId;
	cout<<"the price of english book is ";
	cin>>english.price;
	cout<<"the pages of english book is ";
	cin>>english.pages;

	urdu.bookId;
	urdu.price;
	urdu.pages;
	cout<<"the bookId of urdu book is ";
	cin>>urdu.bookId;
	cout<<"the price of urdu book is ";
	cin>>urdu.price;
	cout<<"the pages of urdu book is ";
	cin>>urdu.pages;
	if(urdu.price>english.price){
	
	cout<<"book urdu is expensive"<<endl;
	cout<<"displaying information of book urdu"<<endl;
	cout<<"the bookId of urdu book is "<<urdu.bookId<<endl;
	cout<<"the pages of urdu book is "<<urdu.pages<<endl;
	cout<<"the price of urdu book is "<<urdu.price<<endl;}
	else if(urdu.price<english.price){
	cout<<"book english is expensive"<<endl;
	cout<<"displaying information of book english"<<endl;
	cout<<"the bookId of english book is "<<english.bookId<<endl;
	cout<<"the pages of english book is "<<english.pages<<endl;
	cout<<"the price of english book is "<<english.price<<endl;}
	else 
	cout<<"both books have same price";
	return 0; 

}