/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct book
{
	string bookID;
	float price;
	int noOfpages;
}
 book1,book2;
 	int main(){
	 cout<<"information about book1"<<endl;
 	cout<<"enter bookID"<<endl;
 	cin>>book1.bookID;
 	cout<<"enter price"<<endl;
 	cin>>book1.price;
 	cout<<"enter noOfpages"<<endl;
 	cin>>book1.noOfpages;
 	cout<<"information about book2"<<endl;
 	cout<<"enter bookID"<<endl;
 	cin>>book2.bookID;
 	cout<<"enter price"<<endl;
 	cin>>book2.price;
 	cout<<"enter noOfpages"<<endl;
 	cin>>book2.noOfpages;
 	if(book1.price>book2.price){
 	cout<<"book1 is more costly";
 	cout<<book1.bookID<<endl;
 	cout<<book1.price<<endl;
 	cout<<book1.noOfpages<<endl;
 	}else{
	cout<<"book2 is more costly";
	cout<<book2.bookID<<endl;
 	cout<<book2.price<<endl;
 	cout<<book2.noOfpages<<endl;}
 	}

