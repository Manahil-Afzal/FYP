/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
#include<string.h>
using namespace std;
    struct Book
    {
        int price;
        int pages;
        string id;
    };
    int main()
	{
	 Book book[4];
	 int i;
    for(i=0;i<=2;i++)
     {
       cout<<"Book Id:";
       cin>>book[i].id;
       cout<<"Book Pages:";
       cin>>book[i].pages;
       cout<<"Book Price:";
       cin>>book[i].price;
    }
    for(i=0;i<=2;i++)
     {
     	if(book[0].price<book[i].price)
		 {
		 	cout<<"The "; 
              cout<<"Book Id    "<<book[i].id<<"\n";
              cout<<"Book Price  "<<book[i].price<<"\n";
              cout<<"Book Pages  "<<book[i].pages<<"\n";
              cout<<"is very costly book";
        }
     }
}