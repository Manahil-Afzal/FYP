#include <iostream>

using namespace std;

struct Book {
    int bookID;
    float price;
    int pages;
};

int main() {
    Book book1, book2;

    cout << "Enter book ID for book 1: ";
    cin >> book1.bookID;

    cout << "Enter price for book 1: ";
    cin >> book1.price;

    cout << "Enter pages for book 1: ";
    cin >> book1.pages;

    cout << "\nEnter book ID for book 2: ";
    cin >> book2.bookID;

    cout << "Enter price for book 2: ";
    cin >> book2.price;

    cout << "Enter pages for book 2: ";
    cin >> book2.pages;

    Book moreCostlyBook;

    if (book1.price > book2.price) {
        moreCostlyBook = book1;
    } else {
        moreCostlyBook = book2;
    }

    cout << "\nRecord of the more costly book:" << endl;
    cout << "Book ID: " << moreCostlyBook.bookID << endl;
    cout << "Price: " << moreCostlyBook.price << endl;
    cout << "Pages: " << moreCostlyBook.pages << endl;

    return 0;
}