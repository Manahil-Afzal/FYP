/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
#include<string>
using namespace std;
struct books{
	string BookId;
	int price;
	int numOfPages;
}book1,book2;
int main(){
	cout<<"Enter book1 id: ";
	cin>>book1.BookId;
	cout<<"Enter book1 price: ";
	cin>>book1.price;
	cout<<"Enter book1 total number of pages: ";
	cin>>book1.numOfPages;
	cout<<"Enter book2 id: ";
	cin>>book2.BookId;
	cout<<"Enter book2 price: ";
	cin>>book2.price;
	cout<<"Enter book2 total number of pages: ";
	cin>>book2.numOfPages;
	cout<<"Most costly book!"<<endl;
	if(book1.price>book2.price){
		cout<<"Book Id: "<<book1.BookId<<endl;
		cout<<"Price: "<<book1.price<<endl;
		cout<<"Total number of pages: "<<book1.numOfPages<<endl;
	}else{
		cout<<"Book Id: "<<book2.BookId<<endl;
		cout<<"Price: "<<book2.price<<endl;
		cout<<"Total number of pages: "<<book2.numOfPages<<endl;
	}
}
