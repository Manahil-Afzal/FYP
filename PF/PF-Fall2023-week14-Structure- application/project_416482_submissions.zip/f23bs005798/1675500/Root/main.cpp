/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int BookId;
    float Price;
    int Pages;
};

int main() {
    Book book1, book2;
    cout << "Enter BookId, Price, and Pages of book1: ";
    cin >> book1.BookId >> book1.Price >> book1.Pages;
    cout << "Enter BookId, Price, and Pages of book2: ";
    cin >> book2.BookId >> book2.Price >> book2.Pages;
    if (book1.Price > book2.Price) {
        cout << "Book1 is more costly with BookId " << book1.BookId << endl;
    } else {
        cout << "Book2 is more costly with BookId " << book2.BookId << endl;
    }
    return 0;
}
