/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
#include<string>
using namespace std;
struct kitaab{
	int bookid;
	int price;
	int pageno;
};

int main(){
	kitaab book1,book2;
	cout<<"enter the info of book 1:"<<endl;
	cout<<"enter a id of book 1:";
	cin>>book1.bookid;
	cout<<"enter a price of book 1:";
	cin>>book1.price;
	cout<<"enter a page number of book 1:";
	cin>>book1.pageno;
	cout<<endl;
	cout<<"enter the info of book :"<<endl;
	cout<<"enter a id of book 2:";
	cin>>book2.bookid;
	cout<<"enter a price of book 1:";
	cin>>book2.price;
	cout<<"enter a page number of book 1:";
	cin>>book2.pageno;
	if(book1.price>book2.price){
		cout<<"the record of expensive book:"<<endl;
		cout<<"book 1 is expensive"<<endl;
		cout<<"id of book 1:"<<book1.bookid<<endl;
	cout<<"price of book 1:"<<book1.price<<endl;
	cout<<"page number of book 1:"<<book1.pageno<<endl;
	}else{
		cout<<"the record of expensive book:"<<endl;
		cout<<"book 2 is expensive"<<endl;
		cout<<"id of book 2:"<<book2.bookid<<endl;
	cout<<"price of book 2:"<<book2.price<<endl;
	cout<<"page number of book 2:"<<book2.pageno<<endl;
	}
	
    
	return 0;
}