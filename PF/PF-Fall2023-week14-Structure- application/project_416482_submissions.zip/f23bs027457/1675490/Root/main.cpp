/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Book
{
    char bookid;
    float price;
    int pagesofbook;
};
int main(){
    Book *bookPtr,book1,book2;
    bookPtr=&book1;
    bookPtr=&book2;
    cout<<"Enter details of book1:"<<endl;
    cout<<"Enter bookid"<<endl;
    cin>>bookPtr->bookid;
    cout<<"Enter price "<<endl;
    cin>>bookPtr->price;
    cout<<"Enter pages of book"<<endl;
    cin>>bookPtr->pagesofbook;
    cout<<"Enter details of book2:"<<endl;
    cout<<"Enter bookid"<<endl;
    cin>>bookPtr->bookid;
    cout<<"Enter price "<<endl;
    cin>>bookPtr->price;
    cout<<"Enter pages of book"<<endl;
    cin>>bookPtr->pagesofbook;
    if(book1.price>book2.price){
        cout<<"book1 is costly"<<endl;
    }
    else{
        cout<<"book2 is costly"<<endl;
    }
    
    return 0;
}