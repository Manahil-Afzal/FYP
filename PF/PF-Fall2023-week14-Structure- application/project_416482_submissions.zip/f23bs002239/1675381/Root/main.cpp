/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {
    
    Book book1, book2;

    
    cout << "Enter details for the first book:\n";
    cout << "Book ID: ";
    cin >> book1.bookId;
    cout << "Price: ";
    cin >> book1.price;
    cout << "Number of pages: ";
    cin >> book1.pages;

    
    cout << "\nEnter details for the second book:\n";
    cout << "Book ID: ";
    cin >> book2.bookId;
    cout << "Price: ";
    cin >> book2.price;
    cout << "Number of pages: ";
    cin >> book2.pages;

    
    if (book1.price > book2.price) {
        cout << "\nThe details of the more costly book are:\n";
        cout << "Book ID: " << book1.bookId << "\nPrice: " << book1.price << "\nPages: " << book1.pages << std::endl;
    } else {
        cout << "\nThe details of the more costly book are:\n";
        cout << "Book ID: " << book2.bookId << "\nPrice: " << book2.price << "\nPages: " << book2.pages << std::endl;
    }

    return 0;
}