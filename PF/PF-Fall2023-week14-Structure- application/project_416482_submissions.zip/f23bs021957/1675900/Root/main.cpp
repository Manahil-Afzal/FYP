/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

// Define the structure for a book
struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    // Declare two structure variables
    Book book1, book2;

    // Input values for the first book
    cout << "Enter details for Book 1:\n";
    cout << "Book ID: ";
    cin >> book1.bookId;
    cout << "Price: Rs=";
    cin >> book1.price;
    cout << "Pages: ";
    cin >> book1.pages;

    // Input values for the second book
    cout << "\nEnter details for Book 2:\n";
    cout << "Book ID: ";
    cin >> book2.bookId;
    cout << "Price: Rs=";
    cin >> book2.price;
    cout << "Pages: ";
    cin >> book2.pages;

    // Compare prices and display the record of the more costly book
    if (book1.price > book2.price) {
        cout << "\nBook with ID " << book1.bookId << " is more costly:\n";
        cout << "Price: Rs=" << book1.price << "\n";
        cout << "Pages: " << book1.pages << "\n";
    } else if (book2.price > book1.price) {
        cout << "\nBook with ID " << book2.bookId << " is more costly:\n";
        cout << "Price: Rs=" << book2.price << "\n";
        cout << "Pages: " << book2.pages << "\n";
    } else {
         cout << "\nBoth books have the same price.\n";
    }

    return 0;
}

