#include <stdio.h>

// Define the structure for a book
struct Book {
    int BookId;
    float Price;
    int Pages;
};

int main() {
    // Declare two structure variables
    struct Book book1, book2;

    // Input values for the first book
    printf("Enter details for Book 1:\n");
    printf("BookId: ");
    scanf("%d", &book1.BookId);
    printf("Price: ");
    scanf("%f", &book1.Price);
    printf("Pages: ");
    scanf("%d", &book1.Pages);

    // Input values for the second book
    printf("\nEnter details for Book 2:\n");
    printf("BookId: ");
    scanf("%d", &book2.BookId);
    printf("Price: ");
    scanf("%f", &book2.Price);
    printf("Pages: ");
    scanf("%d", &book2.Pages);

    // Display the record of the more costly book
    if (book1.Price > book2.Price) {
        printf("\nBook with ID %d is more costly:\n", book1.BookId);
        printf("Price: %.2f\n", book1.Price);
        printf("Pages: %d\n", book1.Pages);
    } else if (book2.Price > book1.Price) {
        printf("\nBook with ID %d is more costly:\n", book2.BookId);
        printf("Price: %.2f\n", book2.Price);
        printf("Pages: %d\n", book2.Pages);
    } else {
        printf("\nBoth books have the same price.\n");
    }

    return 0;
}

