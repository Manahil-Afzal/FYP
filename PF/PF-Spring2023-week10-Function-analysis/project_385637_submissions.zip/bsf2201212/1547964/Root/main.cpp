/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

int isPrime(long n);

int main()
{
	int num,my;
	cout<<"Enter an integer number: ";
	cin>>num;
	my=isPrime(num);
	if(my==1){
		cout<<num<<" is a prime number"<<endl;
}	else{
		cout<<num<<" is not a prime number"<<endl;
}	
	return 0;
}
int isPrime(long n)
{
	int prime=1;
	for(int i=2;i<(n-1);i++)
	{
		if(n%i==0)
		{
			prime=0;
			break;
		}
	}
	return prime;
}
