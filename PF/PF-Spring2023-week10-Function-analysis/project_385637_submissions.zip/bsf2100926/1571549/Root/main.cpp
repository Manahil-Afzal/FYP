#include <iostream>
using namespace std;

bool isPrime(long n)
{
    bool prime = true;

    if (n <= 1) {
        prime = false;
    } else {
        for (int i = 2; i <= n / 2; ++i) {
            if (n % i == 0) {
                prime = false;
                break;
            }
        }
    }

    return prime;
}

int main()
{
    long num;
    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num))
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}
