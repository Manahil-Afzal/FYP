/*This program checks and displays if a number is prime*/
#include <iostream>
#include<cmath> //added for efficient checking of prime numbers

using namespace std;

int isPrime(long n); //isprime is added before the main
int main()
{
    int num;
    cout << "Enter an integer number: ";
    cin >> num;
    if (isPrime(num))
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;
    return 0;
}

int isPrime(long n)
{
    int prime = 1;
    for (int i = 2; i <= sqrt(n); i++) //sqrt 'n' is added
    {
        if (n % i == 0)
        {
            prime = 0;
            break;
        }
    }
    return prime;
}