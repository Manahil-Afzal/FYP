/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

// Add function prototype for isPrime
int isPrime(long n);

int main()
{
    long num; // Change int to long

    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num)) // Correct variable name
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}


int isPrime(long n)
{
    // Initialize i variable
    int prime = 1;
    int i;

    // Start loop from 2 to sqrt(n)
    for (i = 2; i*i <= n; i++)
    {
        if (n % i == 0)
        {
            prime = 0;
            break;
        }
    }
    return prime;
}