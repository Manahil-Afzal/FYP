/*This program checks and displays if a number is prime*/

#include <iostream>
using namespace std;

int isPrime(int num); 

int main()
{
	int num;
	
	cout<<"Enter an integer number: ";
	cin>>num;
	
	if(isPrime(num)) 
		cout<<num<<" is a prime number"<<endl;
	else
		cout<<num<<" is not a prime number"<<endl;
		
	return 0;
}


int isPrime(int num) 
{
	
	int prime=1;
	
	for(int i=2;i<(num-1);i++) 
	{
		if(num%i==0)
		{
			prime=0;
			break;
		}
	}
	return prime;
}
