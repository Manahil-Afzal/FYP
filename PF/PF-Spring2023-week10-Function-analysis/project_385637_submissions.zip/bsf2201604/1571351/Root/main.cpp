/*This program checks and displays if a number is prime*/
#include <iostream>

using namespace std;

int isPrime(int n); // function prototype

int main()
{
    int num;

    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num))
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}

int isPrime(int n)
{
    if (n <= 1) // special case for 0 and 1
        return 0;

    for (int i = 2; i <= n/2; i++) // loop from 2 to n/2
    {
        if (n % i == 0) // if n is divisible by i, it's not prime
            return 0;
    }

    return 1; // n is prime
}


