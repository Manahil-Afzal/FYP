/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;
class Utility_Bill {
 public:
 string customer_name;
 int bill_number;
 int units_consumed;
 string customer_address;
 float per_unit_price;
 float bill_amount;
 void calculate_bill() {
 if (units_consumed < 300) {
 per_unit_price = 8;
 } else if (units_consumed >= 300 && units_consumed < 1000) {
 per_unit_price = 5;
 } else if (units_consumed >= 1000) {
 per_unit_price = 14;
 }
 bill_amount = units_consumed * per_unit_price;
 }
void display_bill() {
 cout << "Customer Name: " << customer_name << endl;
 cout << "Bill Number: " << bill_number << endl;
 cout << "Units Consumed: " << units_consumed << endl;
 cout << "Customer Address: " << customer_address << endl;
 cout << "Per Unit Price: Rs. " << per_unit_price << endl;
 cout << "Bill Amount: Rs. " << bill_amount << endl;
 }
};
int main() {
 Utility_Bill bill;
 cout << "Enter Customer Name: ";
 getline(cin, bill.customer_name);
 cout << "Enter Bill Number: ";
 cin >> bill.bill_number;
 cout << "Enter Units Consumed: ";
 cin >> bill.units_consumed;
 cin.ignore();
 cout << "Enter Customer Address: ";
 getline(cin, bill.customer_address);
 bill.calculate_bill();
 bill.display_bill();
 return 0;}
