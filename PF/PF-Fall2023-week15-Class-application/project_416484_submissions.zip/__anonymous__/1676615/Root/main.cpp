/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class UtilityBill 
{
private:
    string customer_name;
    string bill_number;
    int units_consumed;
    string customer_address;

public:
    UtilityBill(string& name, string& number, int consumed, string& address)
        : customer_name(name), bill_number(number), units_consumed(consumed), customer_address(address) {}

    int calculateBillAmount() const 
    {
        int per_unit_price;
        if (units_consumed < 300)
        {
            per_unit_price = 8;
        }
        else if (units_consumed < 1000)
        {
            per_unit_price = 5;
        } else 
        {
            per_unit_price = 14;
        }

        return units_consumed * per_unit_price;
    }

    void displayBill() const {
        cout << "Customer Name: " << customer_name<<"\n" ;
        cout << "Bill Number: " << bill_number <<"\n";
        cout << "Units Consumed: " << units_consumed<<"\n" ;
        cout << "Customer Address: " << customer_address <<"\n";
        cout << "Bill Amount: Rs. " << calculateBillAmount() <<"\n";
    }
};

int main() 
{
    string customer_name, bill_number, customer_address;
    int units_consumed;

    cout << "Enter customer name: ";
    cin>> customer_name;
    cout << "Enter bill number: ";
    cin>> bill_number;
    cout << "Enter units consumed: ";
    cin >> units_consumed;
    cout << "Enter customer address: ";
    cin>>customer_address;
    


    UtilityBill customer(customer_name, bill_number, units_consumed, customer_address);
    customer.displayBill();

    return 0;
}

