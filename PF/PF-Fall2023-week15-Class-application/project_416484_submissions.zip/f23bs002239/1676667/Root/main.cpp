#include<iostream>
#include<string>
class Utility_Bill {
public:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;
    double perUnitPrice;

public:
    Utility_Bill(const std::string& name, int billNo, int units, const std::string& address)
        : customerName(name), billNumber(billNo), unitsConsumed(units), customerAddress(address) {
        // Set per unit price based on units consumed
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }
    }

    void displayBill() const {
        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Per Unit Price: Rs. " << perUnitPrice << std::endl;
        std::cout << "Total Bill Amount: Rs. " << calculateBillAmount() << std::endl;
    }

    double calculateBillAmount() const {
        return unitsConsumed * perUnitPrice;
    }
};
int main() {
    // Example usage
    Utility_Bill customerBill("John Doe", 12345, 500, "123 Main Street");
    // Display the bill details
    customerBill.displayBill();
    return 0;
}
