/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class info{
	public:
	 string customer_name;
	 int bill_number;
	 float consumed_unit;
	 string address;
};
int main(){
	
	float total_bill;
	 int a;
	cout<<"number of customers:";     //array size
	cin>>a;
	 info utilities_bill[a];
	 for(int i=0; i<a; i++){
	 	cout<<"enter the name of customer "<<i+1<<":"<<endl;
	 cout<<"enter name of customer : "<<endl;
	 cin.ignore();
	 getline(cin,utilities_bill[i].customer_name);
	 cout<<"enter the bill numer/code : "<<endl;
	 cin>>utilities_bill[i].bill_number;
	 cout<<"enter the amount of consumed unit : "<<endl;
	 cin>>utilities_bill[i].consumed_unit;
	 cout<<"enter the customer address : "<<endl;
	 cin>>utilities_bill[i].address;
	                                       // calculation
	 if(utilities_bill[i].consumed_unit < 300)
	 {	
	 	total_bill=utilities_bill[i].consumed_unit*8;
	 	cout<<"total bill amount : "<<total_bill<<endl;
	 }
	 else if(utilities_bill[i].consumed_unit> 999){
	 	
	 	total_bill=utilities_bill[i].consumed_unit* 14 ;
	 	cout<<"total bill amount : "<<total_bill<<endl;
	 }else if(utilities_bill[i].consumed_unit >=300 || utilities_bill[i].consumed_unit<=1000 )
	 {
	 	total_bill=utilities_bill[i].consumed_unit*5;
	 	cout<<"total bill amount : "<<total_bill<<endl;
	 }
}
     
}