/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class Utility_Bill {
    private:
        string customer_name;
        int bill_number;
        int units_consumed;
        string customer_address;
        float per_unit_price;
        float bill_amount;
    public:
        void get_data() {
            cout << "Enter customer name: ";
            getline(cin, customer_name);
            cout << "Enter bill number: ";
            cin >> bill_number;
            cout << "Enter units consumed: ";
            cin >> units_consumed;
            cout << "Enter customer address: ";
            cin.ignore();
            getline(cin, customer_address);
        }
        void calculate_bill() {
            if (units_consumed < 300) {
                per_unit_price = 8;
            } else if (units_consumed >= 300 && units_consumed < 1000) {
                per_unit_price = 5;
            } else if (units_consumed >= 1000) {
                per_unit_price = 14;
            }
            bill_amount = units_consumed * per_unit_price;
        }
        void display_data() {
            cout << "\nCustomer Name: " << customer_name;
            cout << "\nBill Number: " << bill_number;
            cout << "\nUnits Consumed: " << units_consumed;
            cout << "\nCustomer Address: " << customer_address;
            cout << "\nBill Amount: Rs. " << bill_amount;
        }
};

int main() {
    Utility_Bill bill;
    bill.get_data();
    bill.calculate_bill();
    bill.display_data();
    return 0;
}
