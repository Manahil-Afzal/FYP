/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class Utility_Bill {
private:
    string customerName;
     string billNumber;
     int unitsConsumed;
    string customerAddress;

public:
    void getInput() {
        cout << "Enter Customer Name: ";
        getline(std::cin >> std::ws, customerName);

        cout << "Enter Bill Number: ";
        cin >> billNumber;

        cout << "Enter Units Consumed: ";
        cin >> unitsConsumed;

        cout << "Enter Customer Address: ";
        getline(std::cin >> std::ws, customerAddress);
    }

    void displayBill() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        cout << "\nCustomer Name: " << customerName << std::endl;
        cout << "Bill Number: " << billNumber << std::endl;
        cout << "Units Consumed: " << unitsConsumed << std::endl;
        cout << "Customer Address: " << customerAddress << std::endl;
        cout << "Bill Amount: Rs. " << billAmount << std::endl;
    }
};

int main() {
    Utility_Bill bill;

    // Input customer details
    bill.getInput();

    // Display the utility bill
    bill.displayBill();

    return 0;
}

