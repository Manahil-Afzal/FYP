/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string.h>
using namespace std;
class utilitybill
{
    public:
    string name;
    int bilnum;
    int unitconsumed;
    string customeradress;
    int calculatebillamount(){
    	int billamount;
	
    if(unitconsumed<300)
    {
       cout<<"per unit price is 8"<<endl;
       billamount=unitconsumed*8;
    }
else if(unitconsumed>=300&&unitconsumed<1000)

{
    cout<<"per unit price is 5"<<endl;
    billamount=unitconsumed*5;
    
}
    else 
    {
        cout<<"per unit price is 14"<<endl;
        billamount=unitconsumed*14;
    }
    return billamount;
    
}};
int main()
{
    utilitybill bill ;
    cout<<"enter customer name"<<endl;
    cin>>bill.name;
    cout<<"enter billnum"<<endl;
    cin>>bill.bilnum;
    cout<<"unitconsumed"<<endl;
    cin>>bill.unitconsumed;
    cout<<"enter customer adress"<<endl;
    cin>>bill.customeradress;
   cout<<"The bill is :"<<bill.calculatebillamount()<<endl;
    cout<<"your name is: "<<bill.name<<endl;
    cout<<"The bill name is :"<<bill.bilnum<<endl;
    cout<<"The unit are :"<<bill.unitconsumed<<endl;
    cout<<"Your address is :"<<bill.customeradress<<endl;
   
    
    return 0;
    
}