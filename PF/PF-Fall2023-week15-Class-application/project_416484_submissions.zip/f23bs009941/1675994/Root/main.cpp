/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string.h>
using namespace std;
class utilitybill
{
    public:
    string name;
    int bilnum;
    int unitconsumed;
    string customeradress;
    int calculatebillamount(){
    	int billamount;
	
    if(unitconsumed<300)
    {
       cout<<"per unit price is 8"<<endl;
       billamount=unitconsumed*8;
    }
else if(unitconsumed>=300&&unitconsumed<1000)

{
    cout<<"unit consumed is 5";
    billamount=unitconsumed*5;
    
}
    else 
    {
        cout<<"per unit price is 14";
        billamount=unitconsumed*14;
    }
    return billamount;
    
}};
int main()
{
    utilitybill bill ;
    cout<<"enter customer name"<<endl;
    cin>>bill.name;
    cout<<"enter billnum"<<endl;
    cin>>bill.bilnum;
    cout<<"unitconsumed"<<endl;
    cin>>bill.unitconsumed;
    cout<<"enter customer adress"<<endl;
    cin>>bill.customeradress;
   cout<<bill.calculatebillamount();
    cout<<bill.name<<endl;
    cout<<bill.bilnum<<endl;
    cout<<bill.unitconsumed<<endl;
    cout<<bill.customeradress<<endl;
    cout<<"billamount is"<<bill.calculatebillamount();
    
    return 0;
    
}