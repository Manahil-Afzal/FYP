#include <iostream>
using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    float perUnitPrice;

public:
    Utility_Bill(string name, int billNo, int units, string address)
        : customerName(name), billNumber(billNo), unitsConsumed(units), customerAddress(address) {
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }
    }

    void displayDetailsAndBillAmount() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Per Unit Price: Rs. " << perUnitPrice << endl;

        float billAmount = unitsConsumed * perUnitPrice;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    string name, address;
    int billNo, units;

    cout << "Enter Customer Name: ";
    getline(cin, name);

    cout << "Enter Bill Number: ";
    cin >> billNo;

    cout << "Enter Units Consumed: ";
    cin >> units;

    cin.ignore(); // Clear the newline character from the input buffer
    cout << "Enter Customer Address: ";
    getline(cin, address);

    Utility_Bill customerBill(name, billNo, units, address);
    customerBill.displayDetailsAndBillAmount();

    return 0;
}
