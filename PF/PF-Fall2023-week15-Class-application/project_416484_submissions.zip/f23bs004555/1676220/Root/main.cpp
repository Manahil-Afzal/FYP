/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Bill
{
	public:
	string name;
	long  billno;
	int unitconsumed;
	string customeraddress;
};
 int main()
 {
 	Bill billobj1;
 	cout<<"Customer Name:   ";
 	cin>>billobj1.name;
 	cout<<"Bill no:   ";
 	cin>>billobj1.billno;
 	cout<<"Unit Consumed:   ";
 	cin>>billobj1.unitconsumed;
 	cout<<"Customer Address:   ";
 	cin>>billobj1.customeraddress;
 	int billamount;
 	if(billobj1.unitconsumed<300)
 	{
 		billamount=billobj1.unitconsumed*8;
 		cout<<"The bill is:"<<billamount<<endl;
	}
    if(300<=billobj1.unitconsumed<1000)
	{
     	billamount=billobj1.unitconsumed*5;
 		cout<<"The bill is:"<<billamount<<endl;
 	}
 	if(billobj1.unitconsumed>999)
	{
     	billamount=billobj1.unitconsumed*14;
 		cout<<"The bill is:"<<billamount<<endl;
 	}
 }