/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill
{
    public:
   string customer_name;
    int bill_number;
    int unit_consumed;
    string customer_address;
    
    int bill_amount()
{
    float total_bill;

if(unit_consumed<300)
{
    cout<<"Per Unit Price is 8"<<endl;
    total_bill=unit_consumed*8;
}
else if(unit_consumed<=300&&unit_consumed>100)
{
    cout<<"Per Unit Price is 5"<<endl;
    total_bill=unit_consumed*5;
}

else if(unit_consumed>=1000)
{
    cout<<"Per Unit Price is 14"<<endl;
    total_bill=unit_consumed*14;
}

    return total_bill;
}
};
int main()
{
    utility_bill bill;
    cout<<"Enter the Costumer Name :"<<endl;
cin>>bill.customer_name;
cout<<"Enter the Bill Number :"<<endl;
cin>>bill.bill_number;
cout<<"Enter the Units Consumed :"<<endl;
cin>>bill.unit_consumed;
cout<<"Enter The customer Address :"<<endl;
cin>>bill.customer_address;
    bill.bill_amount();
    cout<<"total Bill is :"<<bill.bill_amount();
    
    
    return 0;
    
}