/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class Utility_Bill{
    public:
    string name;
    string billno;
    int units;
    string address;
};
int main()
{int bill;

    Utility_Bill myinfo;
    cout<<"Enter Your Name :";
    getline(cin,myinfo.name);
    cout<<"Enter your address :";
    getline (cin, myinfo.address);
    cout<<"Enter Your bill no:";
    cin>>myinfo.billno;
    cout<<"Enter the  amount of units consumed:";
    cin>>myinfo.units;
    
    if(myinfo.units<300)
    bill=myinfo.units*8;
    else if(myinfo.units>300 && myinfo.units<1000)
    bill=myinfo.units*5;
    else if(myinfo.units>999)
    bill=myinfo.units*14;
   cout<<"Your name is :"<<myinfo.name<<endl;
   cout<<"Your bill number is :"<<myinfo.billno<<endl;
   cout<<"Your Number of units are :"<<myinfo.units<<endl;
   cout<<"Your Address is :"<<myinfo.address<<endl;
   cout<<"Your Amount of bill is :"<<bill<<endl;
   
    
    
    
}
