/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include<iostream>
#include<string>

using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    // Function to input data
    void inputDetails() {
        cout << "Enter Customer Name: ";
        getline(cin, customerName);

        cout << "Enter Bill Number: ";
        cin >> billNumber;

        cout << "Enter Units Consumed: ";
        cin >> unitsConsumed;

        // Clear the input buffer
        cin.ignore();

        cout << "Enter Customer Address: ";
        getline(cin, customerAddress);
    }

    // Function to calculate and display the bill amount
    void displayBill() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        // Displaying the input values and bill amount
        cout << "\nCustomer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    // Create an object of the Utility_Bill class
    Utility_Bill bill;

    // Input details from the user
    bill.inputDetails();

    // Display the utility bill
    bill.displayBill();

    return 0;
}
