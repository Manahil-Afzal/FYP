/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class utility_bill{
	public:
	string name;
	int unitsconsumed;
	string address;
	int billnumber;
	int calculate(int unitsconsumed){
		int billamount;
		if(unitsconsumed<300){
			billamount=unitsconsumed*8;
		}else if(unitsconsumed>300&&unitsconsumed<1000){
			billamount=unitsconsumed*5;
		}else{
			billamount=unitsconsumed*14;
		}
		return billamount;
	}
};
int main(){
	utility_bill bill;
	cout<<"Enter the name:";
	cin>>bill.name;
	cout<<"Enter address: ";
	cin>>bill.address;
	cout<<"Enter bill number: ";
	cin>>bill.billnumber;
	cout<<"Enter units consumed: ";
	cin>>bill.unitsconsumed;
	cout<<"Consumer name is "<<bill.name<<endl;
	cout<<"Consumer address is "<<bill.address<<endl;
	cout<<"Bill number is "<<bill.billnumber<<endl;
	cout<<"Units consumed are "<<bill.unitsconsumed<<endl;
	cout<<"Bill amount is "<<bill.calculate(bill.unitsconsumed);
}
