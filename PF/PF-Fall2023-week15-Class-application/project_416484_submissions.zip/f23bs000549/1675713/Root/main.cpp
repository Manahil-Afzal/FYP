/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/ 
#include<iostream>
 using namespace std;
 class Utility_Bill
 {
 	 public:
     string customer_name;
     long long bill_number;
	 long  units_consumed;
	 string customer_address;
     int total_bill_amount;
 };
 int main()
 {
 	Utility_Bill billinfo;
 	cout<<"Enter your information: "<<endl;
 	cout<<"Enter your name:";
 	getline(cin,billinfo.customer_name);
 	cout<<"Enter your Bill Number:";
 	cin>>billinfo.bill_number;
 	cout<<"Enter Units you consumed:";
 	cin>>billinfo.units_consumed;
 	cin.ignore();
 	cout<<"Enter your address:";
 	getline(cin,billinfo.customer_address);
 	if(billinfo.units_consumed<300)
 	 {  
	 billinfo.total_bill_amount=billinfo.units_consumed*8;
     }
 	else if(billinfo.units_consumed>300&&billinfo.units_consumed<1000)
 	 {
	 billinfo.total_bill_amount=billinfo.units_consumed*5;
	 }
 	else
	 {
 		billinfo.total_bill_amount=billinfo.units_consumed*14;
	 }
	 cout<<"******Information you Entered is:******"<<endl;
	 cout<<"Your Name is:"<<billinfo.customer_name<<endl;
	 cout<<"Your Bill Number is:"<<billinfo.bill_number<<endl;
	 cout<<"Your consumed units are:"<<billinfo.units_consumed<<endl;
	 cout<<"Your Address is:"<<billinfo.customer_address<<endl;
	 cout<<"Your Total Amount of Bill is:"<<billinfo.total_bill_amount<<endl;
	 return 0;
	 
 }