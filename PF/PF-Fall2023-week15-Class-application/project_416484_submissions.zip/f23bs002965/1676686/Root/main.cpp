/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address 
//as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill{
    public:
    string name;
    int bill_num;
    int unit_consumed;
    string address;
    int billTotal;
    void billAmount(Utility_Bill b){
         int perunitPrice;
        if(unit_consumed<300){
          perunitPrice=8;
          cout<<"Price per unit:"<<perunitPrice;
        }
        else if(unit_consumed>=300 && unit_consumed<1000){
             //int perunitPrice;
             perunitPrice=5;
             cout<<"Price per unit:"<<perunitPrice;
        }
        else if(unit_consumed>999){
            //int perunitPrice;
            perunitPrice=14;
            cout<<"Price per unit:"<<perunitPrice;
        }
        double   billTotal=b.unit_consumed*perunitPrice;
        cout<<"Total Bill:"<<billTotal<<endl;
    }
};
int main(){
   
  
    Utility_Bill bill;
    cout<<"Enter name:"<<endl;
    cin>>bill.name;
    cout<<"Enter bill number:"<<endl;
    cin>>bill.bill_num;
    cout<<"Enter unit consumed:";
    cin>>bill.unit_consumed;
    cout<<"Enter the address:";
    cin>>bill.address;
    
    bill.billAmount(bill);
    cout<<endl;
  
    //cout<<"Bill:"<<bill.billTotal;
}
