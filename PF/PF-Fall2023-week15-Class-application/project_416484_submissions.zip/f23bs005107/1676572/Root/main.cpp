/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

using namespace std;

class UtilityBill {
public:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;


    
    void displayBill() {
        double perUnitPrice;

       
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed>300&&unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

       
        double billAmount = unitsConsumed * perUnitPrice;

        
        cout << "\nUtility Bill Details:\n";
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << " units" << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Per Unit Price: Rs. " << perUnitPrice << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
   
    UtilityBill bill1;
    cout<<"enter name"<<endl;
    cin>>bill1.customerName;
    cout<<"enter the bill number"<<endl;
    cin>>bill1.billNumber;
    cout<<"enter the units consumed"<<endl;
    cin>>bill1.unitsConsumed;
    cout<<"enter the address"<<endl;
    cin>>bill1.customerAddress;
   

    
   
    bill1.displayBill();
   

    return 0;
}
