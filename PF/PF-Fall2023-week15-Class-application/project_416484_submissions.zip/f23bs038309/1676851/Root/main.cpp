/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
 #include<iostream>
  #include<string>
  using namespace std;
  class ub{
  	public:
  	string name;
  	int Billno;
  	int units;
  	string address;	
  };
 int main()
{  //input
  ub c;int money;
  cout<<"        -- INPUTS --      \n Utility Bill:"<<endl;
  cout<<"Custumer Name=";
  cin>>c.name;
  cout<<"Bill Number=";
  cin>>c.Billno;
  cout<<"Unit Consumed=";
  cin>>c.units;
  cout<<"Customer Address=";
  cin>>c.address;
  //output
  cout<<endl<<"OUTPUT";
  cout<<endl<<"Custumer Name="<<c.name<<endl;
  cout<<"Bill Number="<<c.Billno<<endl;
  cout<<"Unit Consumed="<<c.units<<endl;
  cout<<"Customer Address="<<c.address<<endl;
  if(c.units<300)
 { money=c.units*8; cout<<"Bill Amount="<<money;}
  else if(c.units<1000&&c.units>299)
  {money=c.units*5; cout<<"Bill Amount="<<money;}
  else if(c.units>999)
  {money=c.units*14; cout<<"Bill Amount="<<money;}
  
  return 0;
}