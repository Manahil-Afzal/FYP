/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
struct UtilityBill {
 string customerName;
 int billNumber;
 int unitsConsumed;
 string customerAddress;
};
double calculateBillAmount(UtilityBill bill) {
 double perUnitPrice;
 if (bill.unitsConsumed < 300) {
 perUnitPrice = 8; }
else if (bill.unitsConsumed>300&&bill.unitsConsumed < 1000) {
 perUnitPrice = 5; }
else {
 perUnitPrice = 14; }
 return bill.unitsConsumed * perUnitPrice;}
void displayBillDetails(UtilityBill bill) {
 cout << "Customer Name: " << bill.customerName << endl;
 cout << "Bill Number: " << bill.billNumber << endl;
 cout << "Units Consumed: " << bill.unitsConsumed << endl;
 cout << "Customer Address: " << bill.customerAddress << endl;
 cout << "Bill Amount: " << calculateBillAmount(bill) << endl;}
int main() {
 UtilityBill bill;
 cout << "Enter customer name:";
 cin >> bill.customerName;
 cout << "Enter bill number: ";
 cin >> bill.billNumber;
 cout << "Enter units consumed: ";
 cin >> bill.unitsConsumed;
 cout << "Enter customer address: "; 
 cin >> bill.customerAddress;
 displayBillDetails(bill);
 return 0; }