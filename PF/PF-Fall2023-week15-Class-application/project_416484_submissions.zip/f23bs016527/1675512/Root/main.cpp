/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
#include<string>
using namespace std;

class info{
	public:
	 string customer_name;
	 int bill_number;
	 float consumed_unit;
	 string address;
};
int main(){
	
	float total_bill;
	 info utilities_bill;
	 cout<<"enter name of customer : ";
	 cin>>utilities_bill.customer_name;
	 cout<<"enter the bill numer/code : ";
	 cin>>utilities_bill.bill_number;
	 cout<<"enter the amount of consumed unit : ";
	 cin>>utilities_bill.consumed_unit;
	 cout<<"enter the customer address : ";
	 cin>>utilities_bill.address;
	 // bill calculation
	 
	 if(utilities_bill.consumed_unit < 300)
	 {	
	 	total_bill=utilities_bill.consumed_unit*8;
	 	cout<<"total bill amount : "<<total_bill;
	 }
	 else if(utilities_bill.consumed_unit> 999){
	 	
	 	total_bill=utilities_bill.consumed_unit* 14 ;
	 	cout<<"total bill amount : "<<total_bill;
	 }else if(utilities_bill.consumed_unit >=300 || utilities_bill.consumed_unit<=1000 )
	 {
	 	total_bill=utilities_bill.consumed_unit*5;
	 	cout<<"total bill amount : "<<total_bill;
	 }
	 
}