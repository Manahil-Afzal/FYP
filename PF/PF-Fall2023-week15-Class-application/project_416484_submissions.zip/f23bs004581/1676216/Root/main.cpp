/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include<string>
using namespace std;
class electricitybill{
 private:
 int unitPrice;
 string name;
 int billno;
 float units;
 string address;
 float billAmount;
 public:
 void getDetails();
 void displayDetails();
};
int main(){
 electricitybill Billcal;
 Billcal.getDetails();
 Billcal.displayDetails();
}
void electricitybill:: getDetails(){
 cout<<"Enter Customer name:"<<endl;
 cin>>name;
 cout<<"Enter Bill number:"<<endl;
 cin>>billno;
 cout<<"Enter Address:"<<endl;
 cin>>address;
 cout<<"Consumed Units:"<<endl;
 cin>>units;
 if(units<300){
 unitPrice=8;
 }else if(units>=300 && units<1000){
 unitPrice=5;
 }else if(units>999){
 unitPrice=14;
 }
 billAmount=units*unitPrice;
 
}
void electricitybill::displayDetails(){
 cout<<"Name:"<<name<<endl;
 cout<<"Bill Number:"<<billno<<endl;
 cout<<"Address:"<<address<<endl;
 cout<<"Consumed Units:"<<units<<endl;
 cout<<"Bill Amount:"<<billAmount<<endl;
}