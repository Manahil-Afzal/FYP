//*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
//If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14
#include<iostream>
#include<string.h>
using namespace std;
class utility_bill{
	public:
		string customer_name;
		string bill_no;
		int unit_consumed;
		string customer_address;
		float billamount(){
			float bill_amount;
			if(unit_consumed>300){
				cout<<"Per unit price is rs8:"<<endl;
				bill_amount=8*unit_consumed;
			}
			else if(unit_consumed>=300 & unit_consumed<1000){
				cout<<"Per unit price is rs5:"<<endl;
				bill_amount=5*unit_consumed;
			}
			else{
				cout<<"Per unit price is rs14:"<<endl;
				bill_amount=14*unit_consumed;
			}
			return bill_amount;
		}
};
int main(){
	utility_bill electricity_bill;
	cout<<"Enter customer name"<<endl;
	getline(cin,electricity_bill.customer_name);
	cout<<"Enter bill_no:"<<endl;
	cin>>electricity_bill.bill_no;
	cout<<"Enter unit_consumed"<<endl;
	cin>>electricity_bill.unit_consumed;
	cout<<"Enter customer_address"<<endl;
	cin>>electricity_bill.customer_name;
	cout<<"The customer name is:"<<electricity_bill.customer_name<<endl;
	cout<<"The electricity bill no is:"<<electricity_bill.bill_no<<endl;
	cout<<"The unit consumed are:"<<electricity_bill.unit_consumed<<endl;
	cout<<"The customer address is:"<<electricity_bill.customer_address<<endl;
    cout<<"The total bill of customer is:"<<electricity_bill.billamount()<<endl; 
	return 0;
}