#include<iostream>
using namespace std;

int main() {
	int *iptr[5];
	int fa = 65, fb = 66, fc = 67, fd = 68, fe = 69;
	int i;

	// initialize array pointers by making them point to 5 different ints
	iptr[0] = &fa;
	iptr[1] = &fb;
	iptr[2] = &fc;
	iptr[3] = &fd;
	iptr[4] = &fe;

	// now print the values being pointed to by the pointers
	for (i = 0; i < 5; i++) {
		cout << "Pointer " << i << " points to " << *iptr[i] << "\n";
	}
	cout << '\n';

	// now print the addresses stored in the array
	for (i = 0; i < 5; i++) {
		cout << "The address stored in iptr[" << i << "] is " << iptr[i] << "\n";
	}

	return 0;
}
/*Changes made:

The assignments of iptr[0] to iptr[4] have been corrected to use the address-of operator (&) to assign the addresses of the variables fa, fb, fc, fd, and fe to the array of pointers.
In the first for loop, the condition has been corrected to i < 5 since the array has 5 elements.
The cout statement in the first for loop has been corrected to use iptr[i] instead of ptr[i] to access the elements of the array of pointers.
The incorrect use of Cout has been corrected to cout in the second for loop.
The >> operator in the second for loop has been corrected to << for the cout statement to print the address.*/