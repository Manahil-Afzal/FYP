/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */
#include <iostream>
#include <cstring>

using namespace std;

// Function to check if a given string is a palindrome
bool isPalindrome(char* str) {
    int len = strlen(str); // Get the length of the string
    char* start = str; // Pointer to the start of the string
    char* end = str + len - 1; // Pointer to the end of the string

    // Compare characters at the start and end pointers, moving towards each other
    while (start < end) {
        if (*start != *end) {
            return false; // If characters are not equal, it's not a palindrome
        }
        start++; // Move start pointer to the right
        end--; // Move end pointer to the left
    }
    return true; // If loop completes without finding any unequal characters, it's a palindrome
}
#include <iostream>
using namespace std;

// Function to calculate the average of three numbers
double calculateAverage(double num1, double num2, double num3) {
    return (num1 + num2 + num3) / 3.0;
}

// Function to find the smallest of three numbers
double findSmallest(double num1, double num2, double num3) {
    double smallest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    return smallest;
}

// Function to find the largest of three numbers
double findLargest(double num1, double num2, double num3) {
    double largest = num1;
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    return largest;
}

int main() {
    double num1, num2, num3; // Variables to store input numbers

    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3; // Input three numbers

    // Call functions to calculate and display average, smallest, and largest
    double average = calculateAverage(num1, num2, num3);
    double smallest = findSmallest(num1, num2, num3);
    double largest = findLargest(num1, num2, num3);

    // Display results
    cout << "Average: " << average << endl;
    cout << "Smallest: " << smallest << endl;
    cout << "Largest: " << largest << endl;

    return 0;
}