#include <iostream>

using namespace std;

// Function to calculate the average of three numbers
double calculateAverage(double num1, double num2, double num3) {
    return (num1 + num2 + num3) / 3.0;
}

// Function to find the smallest of three numbers
double findSmallest(double num1, double num2, double num3) {
    double smallest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    return smallest;
}

// Function to find the largest of three numbers
double findLargest(double num1, double num2, double num3) {
    double largest = num1;
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
    return largest;
}

int main() {
    double num1, num2, num3; // Variables to store input numbers

    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3; // Input three numbers

    // Call functions to calculate and display average, smallest, and largest
    double average = calculateAverage(num1, num2, num3);
    double smallest = findSmallest(num1, num2, num3);
    double largest = findLargest(num1, num2, num3);

    // Display results
    cout << "Average: " << average << endl;
    cout << "Smallest: " << smallest << endl;
    cout << "Largest: " << largest << endl;

    return 0;
}