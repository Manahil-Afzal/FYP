/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */

#include <iostream>
using namespace std;

int main() {
    int *iptr[5]; // declare an array of 5 integer pointers
    int fa = 65, fb = 66, fc = 67, fd = 68, fe = 69; // initialize some integers
    int i;

    // initialize the pointers to point to the integers
    iptr[0] = &fa;
    iptr[1] = &fb;
    iptr[2] = &fc;
    iptr[3] = &fd;
    iptr[4] = &fe;

    // print the values being pointed to by the pointers
    for (i = 0; i < 5; i++) {
        cout << "Pointer " << i << " points to " << *iptr[i] << "\n";
    }
    cout << '\n';

    // print the addresses stored in the array
    for (i = 0; i < 5; i++) {
        cout << "The address stored in " << i << " is " << iptr[i] << "\n";
    }

    return 0;
}