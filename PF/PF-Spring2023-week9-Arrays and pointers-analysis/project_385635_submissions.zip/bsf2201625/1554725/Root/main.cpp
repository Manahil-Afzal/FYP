/* This program demonstrates the use of arrays using pointers. Identify and correct errors. */
#include<iostream>
using namespace std;

int main(){
	int *iptr[5];
	int fa=65, fb=66, fc=67, fd=68, fe=69;
	int i;

	// initialize array pointers by making them point to 5 different ints
	iptr[0] = &fa;  //use refrence operator '&' to get the address
	iptr[1] = &fb;  //use refrence operator '&' to get the address
	iptr[2] = &fc;  //use refrence operator '&' to get the address
	iptr[3] = &fd;  //use refrence operator '&' to get the address
 	iptr[4] = &fe; //use refrence operator '&' to get the address

	// now prints the values being pointed to by the pointers
	for(i=0; i<5; i++) //changing loop condition 'i<6' to 'i<5'
	{
		cout<<"Pointer "<<i<<" points to "<<*iptr[i]<<"\n"; //correct 'ptr' to 'iptr'
	}
	cout<<'\n';

	// now print the addresses stored in the array
	for(i=0; i<5; i++)
	{
		cout<<"The address stored in iptr["<<i<<"] is "<<iptr[i]<<"\n"; //use correct insertion operator
	}

	return 0;
}