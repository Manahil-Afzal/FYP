/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;

void square(int n) {
    cout << "Actual number is " << n << " and its square is " << n * n << endl; //this will display the value and its square
}

int main() {
    int arr[10];
    for (int i = 0; i < 10; i++) {
        cout<<"Enter "<<i+1<<" number:";
        cin >> arr[i];
    }
    for (int i = 0; i < 10; i++) {
        square(arr[i]);
    }
    return 0;
}
