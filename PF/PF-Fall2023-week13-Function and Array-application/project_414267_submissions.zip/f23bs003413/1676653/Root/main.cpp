/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
using namespace std;
// Function to display the actual value and its square
void displaySquare(int element) {
   cout << "Actual value: " << element << ", Square: " << element * element << endl;
}

int main() {
    const int arraySize = 10;
    int numbers[arraySize];

    // Input 10 integers into the array
   cout << "Enter 10 integers:" << endl;
    for (int i = 0; i < arraySize; ++i) {
       cout << "Enter integer #" << i + 1 << ": ";
       cin >> numbers[i];
    }

    // Pass each element of the array to the displaySquare function
    cout << "\nDisplaying the actual value and its square:" << endl;
    for (int i = 0; i < arraySize; ++i) {
        displaySquare(numbers[i]);
    }

    return 0;
}
