/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
using namespace std;
int displaysquare(int num)
{ cout<<"		Actual number is: "<<num<<" 		It's square is: "<<num*num<<endl;
}
int main()
{
	int arr[10];
	cout<<"Enter ten integer numbers"<<endl;
	for(int i=0;i<10;i++)
	{	
		cout<<"Enter integer:";
		cin>>arr[i];
	}	for(int i=0;i<10;i++)
	{
	  displaysquare(arr[i]);
	}	
}