/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
using namespace std;
void suqaure(int n){
    cout<<"Actual number : "<<n<< " And its square : "<<n*n<<endl;
}
int main(){
    int ar[10];
    for(int i=0; i<10; i++){
        cout<<"Enter number "<<i+1<<":"<<endl;
        cin>>ar[i];
    }
    for(int i=0; i<10;i++){
        suqaure(ar[i]);
    }
    return 0;
}