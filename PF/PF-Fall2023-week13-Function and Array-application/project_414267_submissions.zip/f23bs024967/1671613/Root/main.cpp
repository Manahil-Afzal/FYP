#include <iostream>
using namespace std;
void displaySquare(int value) {
    int square = value * value;
    cout << "The square of " << value << " is: " << square << std::endl;
}

int main() {
    const int arraySize = 10;
    int integerArray[arraySize];
    for (int i = 0; i < arraySize; ++i) {
        cout << "Enter integer " << i + 1 << ": ";
        cin >> integerArray[i];

        
        while (cin.fail()) {
            cin.clear();  
            cin.ignore( '\n');  
            cout << "Invalid input. Please enter an integer: ";
            cin >> integerArray[i];
        }
    }
    for (int i = 0; i < arraySize; ++i) {
        displaySquare(integerArray[i]);
    }

    return 0;
}
