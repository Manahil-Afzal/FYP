/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;

void displaySquare(int element) {
    cout << "Element: " << element << ", Square: " << element * element << endl;
}

int main() {
    const int size = 10;
    int myArray[size];

    cout << "Please enter 10 integers:" << endl;
    for (int i = 0; i < size; ++i) {
        cin >> myArray[i];
    }

    
    for (int i = 0; i < size; ++i) {
        displaySquare(myArray[i]);
    }

    return 0;
}
