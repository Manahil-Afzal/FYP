/*Write a program that inputs 10 integers in an array.
 It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
int vns(int arr[], int);
using namespace std;
int main()
{
    cout<<"------------------------------------------\n             INPUTS ";
	cout<<"           \n------------------------------------------\n";
    int num[10];
    for(int i=0; i<10 ; i++)
   {
	 cout<<"Enter "<<i+1<<"th number=";
	 cin>>num[i];
	 
    }vns(num, 10);
    
    return 0;
    
}
int vns(int arr[], int size )
{
	cout<<"------------------------------------------\n              results ";
	cout<<"           \n------------------------------------------\n";
	for(int i=0; i<size; i++)
	{
		cout<< i+1 << "th num=" << arr[i] <<endl;
		cout<<"square of "<< i+1 <<"th num="<<arr[i]*arr[i]<<endl;
		
	}
	return 0;
}
