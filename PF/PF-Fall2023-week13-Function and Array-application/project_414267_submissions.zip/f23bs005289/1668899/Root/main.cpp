/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square*/
#include<iostream>
using namespace std;
void square(int x)
{
    cout<<"the square is"<<x*x<<endl;}
    
int main()
{
    int size=10;
    int myarray[size];
    cout<<"enter the numbers"<<endl;
    for(int i=0;i<size;i++){
    cin>>myarray[i];
}
for(int i=0;i<size;i++){
    square(myarray[i]);
    return 0;
}
}