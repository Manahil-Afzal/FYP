/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;
void display(int arr[], int n)
{
	for (int i=0;i<=10;i++)
	{
		cout<<"Element"<<i+1<<":"<<arr[i]<<", Square:"<<arr[i]*arr[i]<<endl;	
	}
}
int main()
{
	int arr[10];
	cout<<"Enter 10 integers:"<<endl;
	for(int i=0;i<=10;i++)
	{
		cin>>arr[i];
	}
	display(arr, 10);
	return 0;
}