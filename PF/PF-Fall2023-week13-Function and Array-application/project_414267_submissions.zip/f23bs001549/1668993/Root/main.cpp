/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
using namespace std;
int fun()
{
	int arr[10];
	for(int a=0; a<10;a++)
	{
		cout<<"Enter your  :"<< a +1<<" number " <<endl;
		cin>>arr[a];
	
	
	}
	for(int a=0; a<5; a++)
{
		cout<<"Your actual value is :"<<arr[a]<<" and its square is "<<arr[a]*arr[a]<<endl;
}
}
int main()
{
	fun();
}