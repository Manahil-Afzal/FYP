/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
# include <iostream>
using namespace std;
void square  (int n ){
    cout<<"actual number:"<<n<<"and its square is"<<n*n<<endl;
}
int main()
{
int arr[10];
for(int i=0;i<10;i++)
{
    cout<<"enter number"<<i+1<<":"<<endl;
    cin>>arr[i];
}
    for(int i=0;i<10;i++)
    {
        square(arr[i]);
    }
    return 0;
    }