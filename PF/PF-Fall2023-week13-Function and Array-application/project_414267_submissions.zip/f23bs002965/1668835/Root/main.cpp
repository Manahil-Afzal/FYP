/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;

void displaySquares(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << "Element " << i + 1 << ": " << arr[i] << ", Square: " << arr[i] * arr[i] << endl;
    }
}

int main() {
    const int size = 10;
    int arr[size];

    cout << "Enter 10 integers: " << endl;
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    displaySquares(arr, size);

    return 0;
}
