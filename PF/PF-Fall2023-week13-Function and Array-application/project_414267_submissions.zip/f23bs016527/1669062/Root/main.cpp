/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
using namespace std;
 void square( int n);
int main(){
       int arr[10];
       for( int i=0 ;i<10 ; i++){
           
           cout<<"Enter the number "<<i+1<<":";
           cin>>arr[i];
           
       }
       cout<<"calling the funcation : ";
            for( int i ; i<10 ; i++)
              square(arr[i]); 
            return 0;
       }
void square( int n){
    
    cout<<n<<"\t"<<n*n<<endl;
}       
     