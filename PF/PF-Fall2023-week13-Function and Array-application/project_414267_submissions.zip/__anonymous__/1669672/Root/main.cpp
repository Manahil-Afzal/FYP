/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
# include<iostream>
using namespace std;
void displaySquare(int value)
{
    int square = value * value;
    cout << "The square of " << value << " is: " << square ;
}

int main() {
    
    int integerArray[10];

   
    for (int i = 0; i < 10; ++i) 
    {
        cout << "Enter integer #" << i + 1 << ": ";
        cin >> integerArray[i];
        
    }

    
    for (int i = 0; i < 10; ++i)
    {
        cout<<"\n";
        displaySquare(integerArray[i]);
    }
	}
