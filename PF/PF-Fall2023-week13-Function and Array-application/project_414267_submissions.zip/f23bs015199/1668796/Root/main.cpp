/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;

// Function to display the value and square of an element
void displaySquare(int num){
    cout << "Value: " << num << ", Square: " << num * num << endl;
}

int main() {
    int arr[10];

    // Inputting 10 integers into the array
    cout << "Enter 10 integers into the array: ";
    for(int i=0; i<10; i++){
        cin >> arr[i];
    }

    // Passing each element of the array to the displaySquare function
    for(int i=0; i<10; i++){
        displaySquare(arr[i]);
    }

    return 0;
}