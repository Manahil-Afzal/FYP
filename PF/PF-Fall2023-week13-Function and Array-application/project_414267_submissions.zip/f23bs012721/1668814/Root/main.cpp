/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;

// Function to display the square of a number
void displaySquare(int num) {
    cout << "The square of " << num << " is: " << num * num <<endl;
}

int main() {
    const int size = 10;
    int myArray[size];

    // Input 10 integers into the array
     cout << "Enter 10 integers:" << endl;
    for (int i = 0; i < size; ++i) {
     cin >> myArray[i];
    }

    // Pass each element of the array to the function
    for (int i = 0; i < size; ++i) {
        displaySquare(myArray[i]);
    }

    return 0;
}