/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;
int fun(int a)
{
cout<<"Actual value is:"<<a<<endl;
cout<<"Square is:"<<a*a<<endl;}
int main()
{
    int arry[10];
    cout<<"Enter 10 integer:"<<endl;
     for(int i=0; i<10; i++)
     {
    cout<<"Enter integer #"<<i+1<<":";
    cin>>arry[i];
     }
     cout<<"\nDisplay the actual value and square:"<<endl;
     for(int i=0; i<10; i++)
     fun(arry[i]);
}