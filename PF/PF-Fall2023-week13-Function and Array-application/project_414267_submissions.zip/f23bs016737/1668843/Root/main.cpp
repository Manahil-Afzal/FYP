/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>
using namespace std;
int fun(int a)

{
    cout<<"Your actual number is :"<<a<<endl;
    cout<<"Square of number is :"<<a*a<<endl;
}
int main()
{
    int arr[10];
for(int a=0; a<10;a++)
{
    cout<<"Enter your number :"<<endl;
    cin>>arr[a];
    fun(arr[a]);
}
}