/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <iostream>

using namespace std;

void calculateSquare(int number) {
    cout << "The actual value of the element is: " << number << endl;
    cout << "The square of the element is: " << number * number << endl;
}

int main() {
    int array[10];
    cout << "Enter 10 integers: ";

    for (int i = 0; i < 10; i++) {
        cin >> array[i];
        calculateSquare(array[i]);
    }

    return 0;
}