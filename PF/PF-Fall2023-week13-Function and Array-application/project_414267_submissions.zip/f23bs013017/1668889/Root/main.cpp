/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include <stdio.h>

// Function to display the actual value and its square
void displaySquare(int num) {
    printf("Actual Value: %d, Square: %d\n", num, num * num);
}

int main() {
    int array[10];

    // Input 10 integers into the array
    printf("Enter 10 integers:\n");
    for (int i = 0; i < 10; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &array[i]);
    }

    // Pass each element to the displaySquare function
    for (int i = 0; i < 10; i++) {
        displaySquare(array[i]);
    }

    return 0;
}