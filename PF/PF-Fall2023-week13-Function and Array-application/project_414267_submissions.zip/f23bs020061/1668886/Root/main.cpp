#include<iostream>
using namespace std;
void suqaure(int n){
    cout<<"actual number is "<<n<< " and its square is "<<n*n<<endl;
}
int main(){
    int arr[10];
    for(int i=0; i<10; i++){
        cout<<"enter number "<<i+1<<":"<<endl;
        cin>>arr[i];
    }
    for(int i=0; i<10;i++){
        suqaure(arr[i]);
    }
    return 0;
}