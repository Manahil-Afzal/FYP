/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
    int id;
    float price;
    int pages;
}book1, book2;
 int main(){
      cout<<"Enter the book1 Id"<<endl;
      cin>>book1.id;
      cout<<"Enter the book1 price"<<endl;
      cin>>book1.price;
      cout<<"Enter the book1 pages"<<endl;
      cin>>book1.pages;
      cout<<"Enter the book2 Id"<<endl;
      cin>>book2.id;
      cout<<"Enter the book2 price"<<endl;
      cin>>book2.price;
      cout<<"Enter the book2 pages"<<endl;
      cin>>book2.pages;
      if(book1.price>book2.price){
          cout<<"Book id="<<book1.id;
      cout<<"Book Price="<<book1.price;
      cout<<"Book Pages="<<book1.pages;
      }else{
          cout<<"Book id="<<book2.id;
          cout<<"Book Price="<<book2.price;
          cout<<"Book Pages="<<book2.pages;
      }
      }