/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
using namespace std;
struct BookStore
{
    int bookId;
    int Price;
    int bookPages;
};
int main(){
    
    BookStore var1,var2;
    cout<<"Enter the BookId:";
    cin>>var1.bookId;
    cout<<"Enter the Price of the book:";
    cin>>var1.Price;
    cout<<"Enter the BookPages:";
    cin>>var1.bookPages;
    
    // second time information
    cout<<"Enter the BookId:";
    cin>>var2.bookId;
    cout<<"Enter the Price of the book:";
    cin>>var2.Price;
    cout<<"Enter the BookPages:";
    cin>>var2.bookPages;
    //costly book
    if (var1.Price>var2.Price){
    cout<<"Book Id:"<<var1.bookId<<endl;
    cout<<"Book Price:"<<var1.Price<<endl;
    cout<<"BookPages:"<<var1.bookPages<<endl;
    
    }
    else{
    cout<<"Book Id:"<<var2.bookId<<endl;
    cout<<"Book Price:"<<var2.Price<<endl;
    cout<<"BookPages:"<<var2.bookPages<<endl;
    }
    return 0;
    
    
    
    
    
}