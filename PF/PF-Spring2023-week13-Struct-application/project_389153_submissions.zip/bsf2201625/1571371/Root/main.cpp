/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>

using namespace std;

// Define a structure to store BookId, Price, and Pages
struct Book {
    int BookId;
    double Price;
    int Pages;
};

int main() {
    // Declare two structure variables
    Book book1, book2;

    // Input values for book1
    cout << "Enter BookId for book1: ";
    cin >> book1.BookId;
    cout << "Enter Price for book1: ";
    cin >> book1.Price;
    cout << "Enter Pages for book1: ";
    cin >> book1.Pages;

    // Input values for book2
    cout << "Enter BookId for book2: ";
    cin >> book2.BookId;
    cout << "Enter Price for book2: ";
    cin >> book2.Price;
    cout << "Enter Pages for book2: ";
    cin >> book2.Pages;

    // Determine which book is more costly
    Book more_costly_book;
    if (book1.Price > book2.Price) {
        more_costly_book = book1;
    } else {
        more_costly_book = book2;
    }

    // Display the record of the more costly book
    cout << "The record of the more costly book is: \n";
    cout << "BookId: " << more_costly_book.BookId << endl;
    cout << "Price: " << more_costly_book.Price << endl;
    cout << "Pages: " << more_costly_book.Pages << endl;

    return 0;
}