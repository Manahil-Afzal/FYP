/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
    int book_id;
    float price;
    int pages;
} book1, book2;
int main(){
    cout<<"Enter book 1`_id"<<"Enter book 1 price"<<"Enter book 1 pages"<<endl;
    cin>>book1.book_id>>book1.price>>book1.pages;
    cout<<"Enter book 2`_id"<<"Enter book 2 price"<<"Enter book 2 pages";
    cin>>book2.book_id>>book2.price>>book2.pages;
    if(book1.price>book2.price){
        cout<<"book_id"<<book1.book_id<<"book_price"<<book1.price<<"book pages"<<book1.pages;
    }else{
        cout<<"book_id"<<book2.book_id<<"book_price"<<book2.price<<"book pages"<<book2.pages;
    }
}