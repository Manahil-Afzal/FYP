#include <iostream>

using namespace std;

struct Book {
    int BookId;
    double Price;
    int Pages;
};

int main() {
    Book book1, book2;
    
    // input values for book1
    cout << "Enter book1 BookId: ";
    cin >> book1.BookId;
    cout << "Enter book1 Price: ";
    cin >> book1.Price;
    cout << "Enter book1 Pages: ";
    cin >> book1.Pages;
    
    // input values for book2
    cout << "Enter book2 BookId: ";
    cin >> book2.BookId;
    cout << "Enter book2 Price: ";
    cin >> book2.Price;
    cout << "Enter book2 Pages: ";
    cin >> book2.Pages;
    
    // compare prices
    if (book1.Price > book2.Price) {
        // book1 is more costly
        cout << "Book1 is more costly with the following details:\n";
        cout << "BookId: " << book1.BookId << endl;
        cout << "Price: " << book1.Price << endl;
        cout << "Pages: " << book1.Pages << endl;
    } else if (book2.Price > book1.Price) {
        // book2 is more costly
        cout << "Book2 is more costly with the following details:\n";
        cout << "BookId: " << book2.BookId << endl;
        cout << "Price: " << book2.Price << endl;
        cout << "Pages: " << book2.Pages << endl;
    } else {
        // both books have the same price
        cout << "Both books have the same price.\n";
    }
    
    return 0;
}
