#include <iostream>
using namespace std;
struct bookstore
{
 int bookid;
 int pages;
 int bookprices;
};

int main(){
  bookstore book1,book2;
  cout<<"enter the bookid of bookk 1"<<endl;
cin>>book1.bookid;
  cout<<"enter the pages of bookk 1"<<endl;
cin>>book1.pages;
  cout<<"enter the bookprices of bookk 1"<<endl;
cin>>book1.bookprices;
  cout<<"enter the bookid of bookk 2"<<endl;
cin>>book2.bookid;
  cout<<"enter the pages of bookk 2"<<endl;
cin>>book2.pages;
  cout<<"enter the bookprices of bookk 2"<<endl;
cin>>book2.bookprices;
if(book1.bookprices>book2.bookprices){
  cout<<"the book1 is costly"<<book1.bookprices;
}
if(book1.bookprices<book2.bookprices){
  cout<<"the book2 is costly"<<book2.bookprices;
}

  return 0;
}