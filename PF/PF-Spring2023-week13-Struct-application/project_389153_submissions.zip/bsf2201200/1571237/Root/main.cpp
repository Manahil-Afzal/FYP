#include <iostream>
using namespace std;


struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {

    Book book1, book2;
    cout << "Enter Book 1 ID: ";
    cin >> book1.bookId;
    cout << "Enter Book 1 Price: ";
    cin >> book1.price;
    cout << "Enter Book 1 Pages: ";
    cin >> book1.pages;
    cout << "Enter Book 2 ID: ";
    cin >> book2.bookId;
    cout << "Enter Book 2 Price: ";
    cin >> book2.price;
    cout << "Enter Book 2 Pages: ";
    cin >> book2.pages;

    
    if (book1.price > book2.price) {
        cout << "Book 1 is more costly." << endl;
        cout << "Book 1 ID: " << book1.bookId << endl;
        cout << "Book 1 Price: " << book1.price << endl;
        cout << "Book 1 Pages: " << book1.pages << endl;
    }
    else {
        cout << "Book 2 is more costly." << endl;
        cout << "Book 2 ID: " << book2.bookId << endl;
        cout << "Book 2 Price: " << book2.price << endl;
        cout << "Book 2 Pages: " << book2.pages << endl;
    }

    return 0;
}