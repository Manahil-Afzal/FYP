/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int BookId;
    float Price;
    int Pages;
};

int main() {
    Book book1, book2;
    
    // Input values for book1
    cout << "Enter BookId, Price, and Pages of book1: ";
    cin >> book1.BookId >> book1.Price >> book1.Pages;
    
    // Input values for book2
    cout << "Enter BookId, Price, and Pages of book2: ";
    cin >> book2.BookId >> book2.Price >> book2.Pages;
    
    // Find the more costly book
    Book moreCostlyBook = (book1.Price > book2.Price) ? book1 : book2;
    
    // Display the record of the more costly book
    cout << "BookId: " << moreCostlyBook.BookId << endl;
    cout << "Price: " << moreCostlyBook.Price << endl;
    cout << "Pages: " << moreCostlyBook.Pages << endl;
    
    return 0;
}
