/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>

using namespace std;

// define the Book structure
struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {
    Book book1, book2;
    cout << "Enter the book ID, price, and pages of book 1: ";
    cin >> book1.bookId >> book1.price >> book1.pages;

    cout << "Enter the book ID, price, and pages of book 2: ";
    cin >> book2.bookId >> book2.price >> book2.pages;

    if (book1.price > book2.price) {
        cout << "Book 1 is more costly:" << endl;
        cout << "Book ID: " << book1.bookId << endl;
        cout << "Price: " << book1.price << endl;
        cout << "Pages: " << book1.pages << endl;
    } else {
        cout << "Book 2 is more costly:" << endl;
        cout << "Book ID: " << book2.bookId << endl;
        cout << "Price: " << book2.price << endl;
        cout << "Pages: " << book2.pages << endl;
    }

    return 0;
}