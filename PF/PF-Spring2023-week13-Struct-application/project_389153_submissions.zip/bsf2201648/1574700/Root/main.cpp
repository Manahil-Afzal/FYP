/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    Book book1, book2;

    // Input values for book1
    cout << "Enter Book1 ID: ";
    cin >> book1.bookId;
    cout << "Enter Book1 Price: "<<endl;
    cin >> book1.price;
    cout << "Enter Book1 Pages: "<<endl;
    cin >> book1.pages;

    // Input values for book2
    cout << "Enter Book2 ID: ";
    cin >> book2.bookId;
    cout << "Enter Book2 Price: ";
    cin >> book2.price;
    cout << "Enter Book2 Pages: ";
    cin >> book2.pages;

    // Determine the more costly book
    Book costlyBook;
    if (book1.price > book2.price) {
        costlyBook = book1;
    } else {
        costlyBook = book2;
    }

    // Display the record of the more costly book
    cout << "\nRecord of the more costly book:" << endl;
    cout << "Book ID: " << costlyBook.bookId << endl;
    cout << "Price: " << costlyBook.price << endl;
    cout << "Pages: " << costlyBook.pages << endl;

    return 0;
}