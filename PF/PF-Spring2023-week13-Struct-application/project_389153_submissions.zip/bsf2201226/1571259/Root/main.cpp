/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct store{
	int bookid;
	int price;
	int pages;
	
};
int main() {
	store book[8];
	for(int i=0;i<8;i++) {
		cout<<"enter the details of book:"<<i+1<<endl;
		cout<<"enter the id of the book:";
		cin>>book[i].bookid;
		cout<<"enter price of the book:";
		cin>>book[i].price;
		cout<<"enter pages of the book:";
		cin>>book[i].pages;
		
	}
	for(int i=0;i<8;i++) {
		cout<<"details of the books"<<i+1<<endl;
		cout<<"bookid"<<book[i].bookid<<endl;
		cout<<"price "<<book[i].price<<endl;
		cout<<"pages"<<book[i].pages<<endl;
	}
	for(int i=0;i<8;i++) {
	
	if(book[i].price>2000) {
		cout<<"these are more costly books:"<<i+1<<":"<<book[i].price<<endl;
		}
	}
	return 0;
}