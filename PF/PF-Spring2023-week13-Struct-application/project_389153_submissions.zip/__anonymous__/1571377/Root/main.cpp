/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {
    Book book1, book2;

    
    cout << "Enter book1 ID: ";
    cin >> book1.bookId;
    cout << "Enter book1 price: ";
    cin >> book1.price;
    cout << "Enter book1 number of pages: ";
    cin >> book1.pages;

    
    cout << "Enter book2 ID: ";
    cin >> book2.bookId;
    cout << "Enter book2 price: ";
    cin >> book2.price;
    cout << "Enter book2 number of pages: ";
    cin >> book2.pages;


    Book moreCostlyBook = (book1.price > book2.price) ? book1 : book2;

    
    cout << "\nRecord of the more costly book: " << endl;
    cout << "Book ID: " << moreCostlyBook.bookId << endl;
    cout << "Price: " << moreCostlyBook.price << endl;
    cout << "Number of pages: " << moreCostlyBook.pages << endl;

    return 0;
}