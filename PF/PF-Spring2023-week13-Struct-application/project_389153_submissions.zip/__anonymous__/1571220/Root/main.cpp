/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;
struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {
    Book book1, book2;
    cout << "Enter book1 Id: ";
    cin >> book1.bookId;
    cout << "Enter book1 price: ";
    cin >> book1.price;
    cout << "Enter book1 pages: ";
    cin >> book1.pages;
    cout << "Enter book2 Id: ";
    cin >> book2.bookId;
    cout << "Enter book2 price: ";
    cin >> book2.price;
    cout << "Enter book2 pages: ";
    cin >> book2.pages;
    Book moreCostlyBook = book1;
    if (book2.price > book1.price) {
        moreCostlyBook = book2;
    }
    cout << "Book Id: " << moreCostlyBook.bookId << endl;
    cout << "Price: " << moreCostlyBook.price << endl;
    cout << "Pages: " << moreCostlyBook.pages << endl;

    return 0;
}