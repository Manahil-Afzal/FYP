/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct book{
	//declaration
	int bookId;
	float price;
	int pages;

};

int main()
{
	// define
	book b1, b2;
	//Book 1 daTa from user:
	cout<<"Enter the book 1 data from user :"<<endl;
	cout<<"Enter the book id :";
	cin>>b1.bookId;
	
	cout<<"Enter the book price :";
	cin>>b1.price;

	cout<<"Enter the book pages :";
	cin>>b1.pages;
	
	
		//Book 2 daTa from user:
	cout<<"Enter the book 2 data from user :"<<endl;
	
	cout<<"Enter the book id :";
	cin>>b2.bookId;
	
	cout<<"Enter the book price :";
	cin>>b2.price;

	cout<<"Enter the book pages :";
	cin>>b2.pages;
	
/*	
	cout<<"The book data 1 is given below :"<<endl;
		
	cout<<" The book 1 id is : "<<b1.bookId<<endl;
	cout<<" The book 1 id is : "<<b1.price<<endl;
	cout<<" The book 1 id is : "<<b1.pages<<endl;
	
	cout<<endl<<"The book data 2 is given below :"<<endl;
	
	cout<<" The book 2 id is : "<<b2.bookId<<endl;
	cout<<" The book 2 id is : "<<b2.price<<endl;
	cout<<" The book 2 id is : "<<b2.pages<<endl;
	*/
	if(b2.price>b1.price)
	{
	    
	    cout<<"Book 2 is  costly.  "<<b2.price ;
	}
	else
	{
	 {
	    
	    cout<<"Book 1 is  costly. "<< b1.price;
	 }
	}
	
}