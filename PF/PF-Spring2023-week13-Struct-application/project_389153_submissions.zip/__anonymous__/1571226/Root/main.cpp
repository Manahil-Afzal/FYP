/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/#include <iostream>
using namespace std;

// Define the book structure
struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    // Declare two book structure variables
    Book book1, book2;

    // Input values for book1
    cout << "Enter Book 1 Id: ";
    cin >> book1.bookId;
    cout << "Enter Book 1 Price: ";
    cin >> book1.price;
    cout << "Enter Book 1 Pages: ";
    cin >> book1.pages;

    // Input values for book2
    cout << "Enter Book 2 Id: ";
    cin >> book2.bookId;
    cout << "Enter Book 2 Price: ";
    cin >> book2.price;
    cout << "Enter Book 2 Pages: ";
    cin >> book2.pages;

    // Find the more costly book and display its record
    if (book1.price > book2.price) {
        cout << "Book 1 is more costly" << endl;
        cout << "Book 1 Id: " << book1.bookId << endl;
        cout << "Book 1 Price: " << book1.price << endl;
        cout << "Book 1 Pages: " << book1.pages << endl;
    } else {
        cout << "Book 2 is more costly" << endl;
        cout << "Book 2 Id: " << book2.bookId << endl;
        cout << "Book 2 Price: " << book2.price << endl;
        cout << "Book 2 Pages: " << book2.pages << endl;
    }

    return 0;
}