 /*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;

struct Book {
    int BookId;
    float Price;
    int Pages;
};

int main() {
    Book b1, b2;
    
    // Input values for the first book
    cout << "Enter details of book 1:\n";
    cout << "BookId: ";
    cin >> b1.BookId;
    cout << "Price: ";
    cin >> b1.Price;
    cout << "Pages: ";
    cin >> b1.Pages;
    
    // Input values for the second book
    cout << "Enter details of book 2:\n";
    cout << "BookId: ";
    cin >> b2.BookId;
    cout << "Price: ";
    cin >> b2.Price;
    cout << "Pages: ";
    cin >> b2.Pages;
    
    // Compare the prices and display the record of the more costly book
    if (b1.Price > b2.Price) {
        cout << "Record of the more costly book:\n";
        cout << "BookId: " << b1.BookId << endl;
        cout << "Price: " << b1.Price << endl;
        cout << "Pages: " << b1.Pages << endl;
    } else {
        cout << "Record of the more costly book:\n";
        cout << "BookId: " << b2.BookId << endl;
        cout << "Price: " << b2.Price << endl;
        cout << "Pages: " << b2.Pages << endl;
    }
    
    return 0;
}