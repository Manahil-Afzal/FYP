/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
  int BookId;
  float Price;
  int Pages;
};

int main() {
  Book book1, book2;
  
  // Input values for book1
  cout << "Enter BookId for book1: ";
  cin >> book1.BookId;
  cout << "Enter Price for book1: ";
  cin >> book1.Price;
  cout << "Enter Pages for book1: ";
  cin >> book1.Pages;
  
  // Input values for book2
  cout << "Enter BookId for book2: ";
  cin >> book2.BookId;
  cout << "Enter Price for book2: ";
  cin >> book2.Price;
  cout << "Enter Pages for book2: ";
  cin >> book2.Pages;
  
  // Display the record of the more costly book
  if (book1.Price > book2.Price) {
    cout << "BookId: " << book1.BookId << endl;
    cout << "Price: " << book1.Price << endl;
    cout << "Pages: " << book1.Pages << endl;
  } else {
    cout << "BookId: " << book2.BookId << endl;
    cout << "Price: " << book2.Price << endl;
    cout << "Pages: " << book2.Pages << endl;
  }
  
  return 0;
}