/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;

struct book{
    int book_Id;
    int Book_price;
    int book_pages;
};

int main(){
    book b1, b2;
    
    cout<<"Enter the book 1 data:"<<endl;
    cout<<"Enter the book 1 id: ";
    cin>>b1.book_Id;
    cout<<"Enter the book 1 price: ";
    cin>>b1.Book_price;
    cout<<"Enter the book 1 pages: ";
    cin>>b1.book_pages;
    
    cout<<"Enter the book 2 data:"<<endl;
    cout<<"Enter the book 2 id: ";
    cin>>b2.book_Id;
    cout<<"Enter the book 2 price: ";
    cin>>b2.Book_price;
    cout<<"Enter the book 2 pages: ";
    cin>>b2.book_pages;
    
    if(b1.Book_price>b2.Book_price)
    {
        cout<<"The book 1 is costly.";
    }
    else if(b2.Book_price>b1.Book_price)
    {
    	cout<<"The book 2 is most costly.";
	}
    else
    {
        cout<<"Both books are equally costly.";
    }
    
    return 0;
}
