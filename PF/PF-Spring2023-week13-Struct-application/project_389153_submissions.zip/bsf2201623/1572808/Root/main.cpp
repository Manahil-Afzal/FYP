/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly */
#include<iostream>
using namespace std;
struct Book
{
    int bookId;
    float price;
    int pages;
};
main()
{
    Book book1,book2;
    
    cout<<"enter book1 details"<<endl;
    cout<<"bookId";
    cin>>book1.bookId;
    cout<<"price";
    cin>>book1.price;
    cout<<"pages";
    cin>>book1.pages;
    
     cout<<"enter book2 details"<<endl;
    cout<<"bookId";
    cin>>book2.bookId;
    cout<<"price";
    cin>>book2.price;
    cout<<"pages";
    cin>>book2.pages;
    
    Book moreCostlyBook=book1.price>book2.price ? book1:book2;
    cout<<"the more costly book is"<<endl;
    cout<<"bookId"<<moreCostlyBook.bookId<<endl;
    cout<<"pages"<<moreCostlyBook.pages<<endl;
    cout<<"prices"<<moreCostlyBook.price<<endl;

}