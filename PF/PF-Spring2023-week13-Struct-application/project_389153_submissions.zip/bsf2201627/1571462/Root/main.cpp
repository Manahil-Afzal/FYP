/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;
    
    struct book{
        int bookid;
        float price;
        int pages;
    } book1,book2;
    
int main(){
   cout<<"Enter the details of book 1:"<<endl;
    cout<<"Enter Book ID:"<<endl;
    cin>>book1.bookid;
    cout<<"Enter the price:"<<endl;
    cin>>book1.price; 
    cout<<"Enter the pages of book:";
    cin>>book1.pages; 
    
    cout<<"Enter the details of book 2:"<<endl;
    cout<<"Enter Book ID:"<<endl;
    cin>>book2.bookid;
    cout<<"Enter the price:"<<endl;
    cin>>book2.price; 
    cout<<"Enter the pages of book:";
    cin>>book2.pages; 
    
    if(book1.price>book2.price){
        cout<<"Book 1 is more costly than book2."<<endl;
        
       
    }
    else{cout<<"Book 2 is more costly than book 1.";}
    
}