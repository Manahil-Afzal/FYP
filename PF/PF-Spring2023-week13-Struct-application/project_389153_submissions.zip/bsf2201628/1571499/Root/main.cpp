/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

// define a structure to store BookId, Price, and Pages of a book
struct Book {
    int bookId;
    double price;
    int pages;
};

int main() {
    // declare two structure variables
    Book book1, book2;

    // input values for book1
    cout << "Enter Book 1 ID: ";
    cin >> book1.bookId;
    cout << "Enter Book 1 Price: ";
    cin >> book1.price;
    cout << "Enter Book 1 Pages: ";
    cin >> book1.pages;

    // input values for book2
    cout << "Enter Book 2 ID: ";
    cin >> book2.bookId;
    cout << "Enter Book 2 Price: ";
    cin >> book2.price;
    cout << "Enter Book 2 Pages: ";
    cin >> book2.pages;

    // compare the prices of the two books
    if (book1.price > book2.price) {
        // book1 is more costly
        cout << "Book 1 is more costly." << endl;
        cout << "Book 1 ID: " << book1.bookId << endl;
        cout << "Book 1 Price: " << book1.price << endl;
        cout << "Book 1 Pages: " << book1.pages << endl;
    } else {
        // book2 is more costly
        cout << "Book 2 is more costly." << endl;
        cout << "Book 2 ID: " << book2.bookId << endl;
        cout << "Book 2 Price: " << book2.price << endl;
        cout << "Book 2 Pages: " << book2.pages << endl;
    }

    return 0;
}
