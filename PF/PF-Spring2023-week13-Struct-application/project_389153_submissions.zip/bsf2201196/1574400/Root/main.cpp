/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Book {
    int bookId;
    float price;
    int pages;
};
  int main(){
    Book book1,book2;
    //input detail of first book
    cout<<"enter the detail of book 1:"<<endl;
    cout<<"book ID:";
    cin>>book1.bookId;
    cout<<"price:";
    cin>>book1.price;
    cout<<"page:";
    cin>>book1.pages;
    //input detail of second book
    cout<<"enter the detail of book 2:"<<endl;
    cout<<"book ID:";
    cin>>book2.bookId;
    cout<<"price:";
    cin>>book2.price;
    cout<<"page:";
    cin>>book2.pages;
    if (book1.price > book2.price) {
        cout << "Book " << book1.bookId << " is more costly." << endl;
        cout << "Price: " << book1.price << endl;
        cout << "Pages: " << book1.pages << endl;
    } else if (book2.price > book1.price) {
        cout << "Book " << book2.bookId << " is more costly." << endl;
        cout << "Price: " << book2.price << endl;
        cout << "Pages: " << book2.pages << endl;
    } else {
        cout << "Both books have the same price." << endl;
    }

    return 0;    
  }

