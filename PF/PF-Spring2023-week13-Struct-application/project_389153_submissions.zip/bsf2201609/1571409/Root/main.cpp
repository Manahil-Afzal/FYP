/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>

using namespace std;

// Define a structure to store book details
struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    // Declare two structure variables
    Book book1, book2;

    // Input values for book1
    cout << "Enter details for book1:" << endl;
    cout << "Book ID: ";
    cin >> book1.bookId;
    cout << "Price: ";
    cin >> book1.price;
    cout << "Pages: ";
    cin >> book1.pages;

    // Input values for book2
    cout << "Enter details for book2:" << endl;
    cout << "Book ID: ";
    cin >> book2.bookId;
    cout << "Price: ";
    cin >> book2.price;
    cout << "Pages: ";
    cin >> book2.pages;

    // Compare prices of two books
    if (book1.price > book2.price) {
        // Display book1 details
        cout << "Details of the more costly book:" << endl;
        cout << "Book ID: " << book1.bookId << endl;
        cout << "Price: " << book1.price << endl;
        cout << "Pages: " << book1.pages << endl;
    }
    else {
        // Display book2 details
        cout << "Details of the more costly book:" << endl;
        cout << "Book ID: " << book2.bookId << endl;
        cout << "Price: " << book2.price << endl;
        cout << "Pages: " << book2.pages << endl;
    }

    return 0;
}
