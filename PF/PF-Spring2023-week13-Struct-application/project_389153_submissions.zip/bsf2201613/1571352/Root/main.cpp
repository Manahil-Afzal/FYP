/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    Book book1, book2;
    cout << "Enter the BookId, Price, and Pages of book1: ";
    cin >> book1.bookId >> book1.price >> book1.pages;
    cout << "Enter the BookId, Price, and Pages of book2: ";
    cin >> book2.bookId >> book2.price >> book2.pages;

    if (book1.price > book2.price) {
        cout << "The details of the more costly book (book1) are:\n";
        cout << "BookId: " << book1.bookId << "\nPrice: " << book1.price << "\nPages: " << book1.pages;
    }
    else {
        cout << "The details of the more costly book (book2) are:\n";
        cout << "BookId: " << book2.bookId << "\nPrice: " << book2.price << "\nPages: " << book2.pages;
    }
    return 0;
}
