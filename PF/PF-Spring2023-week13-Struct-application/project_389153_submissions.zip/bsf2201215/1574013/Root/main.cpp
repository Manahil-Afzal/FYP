/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
#include <string> // added missing header for string type

using namespace std;

class book {
    string title;
    float price;
public:
    void getdata(); // removed redundant declaration
    void putdata();
};

void book::getdata() { // corrected syntax for function definition
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void book::putdata() {
    cout << "Title: " << title << endl; // corrected output format
    cout << "Price: " << price << endl;
}

int main() {
    book book1, book2, book3;
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}