/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
   int bookId;
   float price;
   int pages;
};

int main() {
   Book book1, book2;
   cout << "Enter details for book 1:\n";
   cout << "Book ID: ";
   cin >> book1.bookId;
   cout << "Price: ";
   cin >> book1.price;
   cout << "Number of pages: ";
   cin >> book1.pages;
   cout << "\nEnter details for book 2:\n";
   cout << "Book ID: ";
   cin >> book2.bookId;
   cout << "Price: ";
   cin >> book2.price;
   cout << "Number of pages: ";
   cin >> book2.pages;

   if (book1.price > book2.price) {
      cout << "\nDetails of the more costly book:\n";
      cout << "Book ID: " << book1.bookId << endl;
      cout << "Price: " << book1.price << endl;
      cout << "Number of pages: " << book1.pages << endl;
   } else {
      cout << "\nDetails of the more costly book:\n";
      cout << "Book ID: " << book2.bookId << endl;
      cout << "Price: " << book2.price << endl;
      cout << "Number of pages: " << book2.pages << endl;
   }
   return 0;
}