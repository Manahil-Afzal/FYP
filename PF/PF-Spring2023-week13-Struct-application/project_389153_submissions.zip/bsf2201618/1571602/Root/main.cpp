/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;

struct Book {
    int BookId;
    float Price;
    int Pages;
};

int main() {
    Book book1, book2;
    
    // Input values for book1
    cout << "Enter BookId, Price, and Pages for book1:\n";
    cin >> book1.BookId >> book1.Price >> book1.Pages;
    
    // Input values for book2
    cout << "Enter BookId, Price, and Pages for book2:\n";
    cin >> book2.BookId >> book2.Price >> book2.Pages;
    
    // Compare the prices of the two books
    if (book1.Price > book2.Price) {
        // Display the details of book1 as it is more costly
        cout << "\nDetails of the more costly book:\n";
        cout << "BookId: " << book1.BookId << endl;
        cout << "Price: " << book1.Price << endl;
        cout << "Pages: " << book1.Pages << endl;
    } else {
        // Display the details of book2 as it is more costly or both have same price
        cout << "\nDetails of the more costly book:\n";
        cout << "BookId: " << book2.BookId << endl;
        cout << "Price: " << book2.Price << endl;
        cout << "Pages: " << book2.Pages << endl;
    }
    
    return 0;
}