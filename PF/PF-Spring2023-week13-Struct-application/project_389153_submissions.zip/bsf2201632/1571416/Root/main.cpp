/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include<iostream>
using namespace std;
struct Book{
    int bookid;
    float price;
    int pages;
} book1, book2;
int main(){
    cout<<"Enter book 1 id, Price, Pages:-"<<endl;
    cin>>book1.bookid>>book1.price>>book1.pages;
    cout<<"Enter the id, price and pages of book 2:-"<<endl;
    cin>>book2.bookid>>book2.price>>book2.pages;
    if(book2.price>book1.price){
        cout<<"Book id="<<book2.bookid;
        cout<<"Book Price="<<book2.price;
        cout<<"Book Pages="<<book2.pages;
    }else{
        cout<<"Book id="<<book1.bookid<<endl;
        cout<<"Book Price="<<book1.price<<endl;
        cout<<"Book Pages="<<book1.pages<<endl;
    }
}