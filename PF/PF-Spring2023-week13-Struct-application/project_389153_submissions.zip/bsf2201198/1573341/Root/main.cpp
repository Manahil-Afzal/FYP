/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/
#include <iostream>
using namespace std;

struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    Book book1, book2;
    
    // Input values for book1
    cout << "Enter Book 1 ID: ";
    cin >> book1.bookId;
    cout << "Enter Book 1 Price: ";
    cin >> book1.price;
    cout << "Enter Book 1 Pages: ";
    cin >> book1.pages;
    
    // Input values for book2
    cout << "Enter Book 2 ID: ";
    cin >> book2.bookId;
    cout << "Enter Book 2 Price: ";
    cin >> book2.price;
    cout << "Enter Book 2 Pages: ";
    cin >> book2.pages;
    
    // Compare prices and display the record of the more costly book
    if (book1.price > book2.price) {
        cout << "Book 1 is more costly:\n";
        cout << "Book ID: " << book1.bookId << endl;
        cout << "Price: " << book1.price << endl;
        cout << "Pages: " << book1.pages << endl;
    } else if (book2.price > book1.price) {
        cout << "Book 2 is more costly:\n";
        cout << "Book ID: " << book2.bookId << endl;
        cout << "Price: " << book2.price << endl;
        cout << "Pages: " << book2.pages << endl;
    } else {
        cout << "Both books have the same price.\n";
    }
    
    return 0;
}
