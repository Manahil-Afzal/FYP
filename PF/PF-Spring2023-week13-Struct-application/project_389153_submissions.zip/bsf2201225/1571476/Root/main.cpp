/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;

struct Book {
    int bookId;
    float price;
    int pages;
};

int main() {
    Book book1, book2;

    // data for book1
    cout << "Enter BookId, Price, and Pages for Book1: ";
    cin >> book1.bookId >> book1.price >> book1.pages;

    //data for book2
    cout << "Enter BookId, Price, and Pages for Book2: ";
    cin >> book2.bookId >> book2.price >> book2.pages;

    // determine which book is more costly
    Book moreCostlyBook;
    if (book1.price > book2.price) {
        moreCostlyBook = book1;
    } else {
        moreCostlyBook = book2;
    }

    // display the record of the more costly book
    cout << "The record of the more costly book is:\n";
    cout << "BookId: " << moreCostlyBook.bookId << "\n";
    cout << "Price: " << moreCostlyBook.price << "\n";
    cout << "Pages: " << moreCostlyBook.pages << "\n";

    return 0;
}
