/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;

struct Book {
  int BookId;
  double Price;
  int Pages;
};

int main() {
  Book book1, book2;

  // Input values for book1
  cout << "Enter BookId, Price, and Pages for book1: ";
  cin >> book1.BookId >> book1.Price >> book1.Pages;

  // Input values for book2
  cout << "Enter BookId, Price, and Pages for book2: ";
  cin >> book2.BookId >> book2.Price >> book2.Pages;

  // Display the record of the more costly book
  if (book1.Price > book2.Price) {
    cout << "Book1 is more costly. Details are: \n";
    cout << "BookId: " << book1.BookId << endl;
    cout << "Price: " << book1.Price << endl;
    cout << "Pages: " << book1.Pages << endl;
  } else {
    cout << "Book2 is more costly. Details are: \n";
    cout << "BookId: " << book2.BookId << endl;
    cout << "Price: " << book2.Price << endl;
    cout << "Pages: " << book2.Pages << endl;
  }

  return 0;
}