/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include<iostream>
using namespace std;
struct book{
    int bookid;
    float price;
    int pages;
};
main(){
    book book1,book2;
    cout<<"Enter book 1 details:\n"<<"book 1 id:";
    cin>>book1.bookid;
    cout<<"price:";
    cin>>book1.price;
    cout<<"pages:";
    cin>>book1.pages;
    
    cout<<"Enter book 2 details:\n"<<"bookid:";
    cin>>book2.bookid;
    cout<<"price:";
    cin>>book2.price;
    cout<<"pages:";
    cin>>book2.pages;
    
    
    if(book1.price > book2.price)
    {cout<<"book1 is more costly.\n"<<"Bookid:"<<book1.bookid;
    cout<<"Price:"<<book1.price<<"Pages:"<<book1.price;
        
    }
    
     if(book2.price > book1.price)
    {cout<<"book2 is more costly.\n"<<"Bookid:"<<book2.bookid;
    cout<<"\nPrice:"<<book2.price<<"\nPages:"<<book2.price;
        
    }
    
}