/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/


#include<iostream>
using namespace std;

struct Book{
    string id;
    float price;
    int pages;
};

int main(){
    Book book1, book2;
    for(int i=0; i<2; i++){
        cout<<"Enter "<<i+1<<" book id:"<<endl;
        cin>>book1.id;
        cout<<"Enter "<<i+1<<" book price:"<<endl;
        cin>>book1.price;
        cout<<"Enter "<<i+1<<" book pages:"<<endl;
        cin>>book1.pages;
        if(i==0){
        	book2 = book1;
       }
       cout<<endl;
    }
    if(book1.price>book2.price){
        cout<<"Expensive book id is: "<<book1.id<<endl;
        cout<<"Expensive book price is: "<<book1.price<<endl;
        cout<<"Expensive book pages are: "<<book1.pages<<endl;
    }else{
        cout<<"expensive book id is: "<<book2.id<<endl;
        cout<<"Expensive book price is: "<<book2.price<<endl;
        cout<<"Expensive book pages are: "<<book2.pages<<endl;
}
}