/*Write a program that defines a structure to store BookId, Price and Pages of a book. 
It declares two structure variables and input values displays the record of the more costly book.*/

#include <iostream>
using namespace std;

struct Book{
  int BookId;
  int Price;
  int Pages;
  void input(){
      cout<<"Enter Book ID"<<endl;
      cin>>BookId;
      cout<<"Enter Book Price"<<endl;
      cin>>Price;
      cout<<"Enter Book Pages"<<endl;
      cin>>Pages;
  }  
  void display(){
      cout<<"Book ID : "<<BookId<<endl;
      cout<<"Book Price : "<<Price<<endl;
      cout<<"Book Pages : "<<Pages<<endl;
  }
};


int main(){
    Book Book1,Book2;
    Book1.input();
    Book2.input();
    if(Book1.Price>Book2.Price)
    Book1.display();
    else
    Book2.display();
    
    
    
    
    return 0;
}