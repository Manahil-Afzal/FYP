#include <iostream>
using namespace std;
int main(){
    int balance=2300;
    int choice;
    cout<<"what you want to perform"<<endl;
    cout<<"1.widthdraw"<<endl;
    cout<<"2.deposit"<<endl;
    cin>>choice;
    switch (choice)
    {
    case 1:
    cout<<"enter the amount to be widthdraw "<<endl;
    int amount;
    cin>>amount;
    if(amount>balance){
        cout<<"your balance is not sufficent"<<endl;
        cout<<"current balance is "<<balance;
    }else{
    balance-=amount;
    }
        break;
    case2:{
        cout<<"enter the balnce to be deposit "<<endl;
        int amount;
        cin>>amount;
        balance+=amount;
    }
    default:
    cout<<"invalid action"<<endl;
        break;
    }
    cout<<balance;

    return 0;
}