/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
	#include <iostream>
using namespace std;
int main(){
	string p;
	int total=2332;
	cout<<"enter your name";
	cin>>p;
	cout<<"if you want to deposit wrie d else  w";
	cout<<"enter your action";
		char dep='d';
	     char with='w';
		cin>>dep,with;

	if(dep='d'){
		cout<<"enter the amount you want to deposit"<<endl;
		int a;
		cin>>a;
		cout<<"you have deposit amount successfully"<<endl;
		cout<<"now your current balance is"<<total+a;
	}
	else{
		cout<<"enter your amount you want to withdraw"<<endl;
		int b;
		cin>>b;
		cout<<"you withdraw amount successfully"<<endl;
		cout<<"now the current balance  is"<<total-b;
	}
	return 0;
}