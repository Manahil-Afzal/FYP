/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
#include<string>
using namespace std;
main()
{
    int existingbal=90000,withdrawamount,remainingbal,x,depositamount;
    cout<<"your existing balance is"<<existingbal<<endl;
    cout<<" for deposit press 1\n for withdraw press 2"<<endl;
    cin>>x;
    if(x=1)
    cout<<"please enter the amount you want to deposit"<<endl;
    cin>>depositamount;
    remainingbal=existingbal+depositamount;
    cout<<"your new balance is"<<endl;
    cout<<remainingbal;
    if(x=2)
    cout<<"please enter the amount you want to withdraw"<<endl;
    cin>>withdrawamount;
    remainingbal=existingbal-withdrawamount;
    cout<<"your remaning balance is"<<endl;
    cout<<remainingbal;
}

