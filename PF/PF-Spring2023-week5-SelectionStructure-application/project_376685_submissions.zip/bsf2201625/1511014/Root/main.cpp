/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
 {
     int total,withdraw,deposit,remaining;
     char option;
     cout<<"enter the current balance =";
     cin>>total;
     cout<<"Do you want to deposit or withdraw =";
     cin>>option;
     if(option=='D')
     {
         cout<<"enter the amount you want to deposit =";
         cin>>deposit;
         remaining=total+deposit;
         cout<<"Total amount after deposit ="<<remaining;
         
     }
     else if(option=='W')
     {
         cout<<"enter the amount you want to withdraw =";
         cin>>withdraw;
         remaining=total-withdraw;
         cout<<"Remaining amount after withdraw ="<<remaining; 
     }
     else
     cout<<"INVALID VALUE";
 }
 