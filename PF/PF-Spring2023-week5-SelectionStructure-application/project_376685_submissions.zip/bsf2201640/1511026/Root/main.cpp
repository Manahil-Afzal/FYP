/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;

int main() {
    double balance = 50000; // initialize the starting balance
    double transaction;
    // display the current balance
    cout << "Current balance: " << balance << endl;
    
    // ask the user for the transaction amount

    cout << "Enter transaction amount: ";
    cin >> transaction;
    
    // ask the user if they want to deposit or withdraw
    char choice;
    cout << "Do you want to deposit (D) or withdraw (W)? ";
    cin >> choice;
    
    // perform the transaction based on the user's choice
    if (choice == 'D' || choice == 'd') {
        balance += transaction;
        cout << "Transaction successful. New balance: " << balance << endl;
    } else if (choice == 'W' || choice == 'w') {
        if (transaction > balance) {
            cout << "Transaction failed. Insufficient balance." << endl;
        } else {
            balance -= transaction;
            cout << "Transaction successful. New balance: " << balance << endl;
        }
    } else {
        cout << "Invalid choice. Transaction cancelled." << endl;
    }
    
    return 0;
}

