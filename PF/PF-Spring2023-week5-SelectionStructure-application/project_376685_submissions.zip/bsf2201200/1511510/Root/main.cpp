/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    float balance;
    char transactionType;
    float transactionAmount;
    cout<<"enter current balance";
    cin>>balance;
    cout<<"enter transaction type (d for deposit, w for withdraw)";
    cin>>transactionType;
    cout<<"enter transaction amount";
    cin>>transactionAmount;
    if (transactionType=='d') {
        balance+=transactionAmount;
        cout<<"deposit successful"<<endl;
    }else if (transactionType=='w') {
        if (transactionAmount>balance) {
            cout<<"insufficient funds for withdrawal"<<endl;
        } else {
            balance-=transactionAmount;
            cout<<"withdrawal successful"<<endl;
        }
    }else {
        cout<<"invalid transaction type. Please enter 'd' for deposit or 'w' for withdrawal"<<endl;
        return 0;
    }
    }