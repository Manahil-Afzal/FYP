/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main ()
{
    long balance, transaction;
    int option;
    balance=50000; // let blance is 50000
    cout<<"enter 1 to deposit or 2 to withdraw"<<endl;
    cin>>option;
    if(option==1)
   {
    cout<<"enter amount you want to deposit"<<endl;
    cin>>transaction;
    cout<<"you have successfully deposited PKR"<<transaction<<endl;
    cout<<"your current balance is PKR"<<balance+transaction;
     }else if(option==2)
     
    {
        cout<<"enter amount you want to withdraw"<<endl;
        cin>>transaction;
        if (transaction>balance){
            cout<<"you don't have sufficient amount in your account";
            }else
            {
                cout<<"you have successfully withdraw PKR"<<transaction<<endl;
                cout<<"your current balance is PKR"<<balance-transaction;
                
            }

         
     }else
     cout<<"slect a valid option";
     
}