/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int account= 10000,x,y;
    cout<<"you want to diposite cash?,type 1 for yes or 0 for no:";
    cin>>x;
    if (x==1)
    {
    cout<<"enter amount you want to diposite:";
    cin>>y;
   account+=y;
    }
    else if(x==0)
    {
        cout<<"enter amount you want to withdraw:";
        cin>>y;
        account-=y;
    }
    else
    cout<<"you want transaction:"<<endl;
    cout<<"remaning balance:"<<account;
    
}