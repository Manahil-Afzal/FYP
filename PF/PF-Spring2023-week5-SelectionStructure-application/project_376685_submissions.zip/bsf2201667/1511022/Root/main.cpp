/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;
main()
{
    int account=5000, x,z;
   cout<<"Enter 1 if you want to deposite money or press 0 if you want to withdraw money:";
   cin>>x;
   if (x==1)
   {
   cout<<"Enter the amount you want to deposite:";
   cin>>z;
   account+=z;
   }
    else if (x==0)
   {cout<<"Enter the amount you want to withdraw:";
   cin>>z;
   account-=z;
   }
   else                              //if any other key is pressed
   cout<<"no transaction made"<<endl;
   cout<<"Remaining balance:"<<account;
}