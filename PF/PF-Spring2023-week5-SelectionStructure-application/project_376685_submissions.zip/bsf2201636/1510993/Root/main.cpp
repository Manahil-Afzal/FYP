/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int B_Balance,WD_Amount,DP_Amount;//WD(Withdraw),Dp(Deposit)
    string transaction; 
   cout<<"Enter Your Bank Balance";
    cin>>B_Balance;
    cout<<"Your Entered Bank Balance="<<B_Balance;
    cout<<"\nWhat type of transaction you want WD or DP";
    cin>>transaction;
    if(transaction=="WD"){
        cout<<"Enter Amount How Much You Want To WithDraw";
        cin>>WD_Amount;
        B_Balance-=WD_Amount;
        cout<<"your B_Balance After WD="<<B_Balance;
        
    }
    else if(transaction=="DP"){
        cout<<"Enter Amount How Much You Want to Deposite";
        cin>>DP_Amount;
        B_Balance+=DP_Amount;
        cout<<"Your B_Balance After Deposit="<<B_Balance;
        }
                                                                                                                                                                                        
    else{
         cout<<"You Enter Invalid";
         }
    
}