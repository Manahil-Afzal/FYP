/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/

#include<iostream>
using namespace std;
main()
{
	int totalamount=1000, choice, currentamount, deposit, withdraw;
	cout<<"choose what you want";
	cout<<"\n Enter 1 for deposit";
	cout<<"\n Enter 2 for withdrawl";
	cout<<"\n enter here: ";
	cin>>choice;
	if(choice==1)
	{
		cout<<"\nenter the amount to deposit: ";
		cin>>deposit;
		cout<<"\nyour current balance after deposit is : ";
		currentamount=totalamount+deposit;
		cout<<currentamount;
	}
	else if(choice==2)
	{
		cout<<"\nenter the amount to withdraw: ";
		cin>>withdraw;
		currentamount=totalamount-withdraw;
		if(currentamount>0)
		{
		cout<<"\nyour current balance after withdrawl is: ";
		cout<<currentamount;}
		if(currentamount<0)
		cout<<"\nYour account does not have enough balance, please deposit cash, your current balance is "<<totalamount;
	}
	else
	cout<<"invalid input";
	
}