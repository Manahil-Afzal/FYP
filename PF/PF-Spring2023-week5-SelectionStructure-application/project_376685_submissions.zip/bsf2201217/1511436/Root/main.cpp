/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;
main()
{
    int total_amount=10000, choice, current_amount, deposite, withdraw;
    cout<<"Chose what you want";
    cout<<"\n enter 1 for deposite :";
    cout<<"\n enter 2 for withdraw :";
    cin>>choice;
    if(choice==1)
{
    cout <<"\n enter the amount you want to deposite:";
    cin>>deposite;
    cout <<"now your current balance is :2";
    current_amount=total_amount+deposite;
    cout<<current_amount;
}
    else
    if(choice==2)
{
    cout<<"\n enter the amount you want to withdraw :";
    cin>>withdraw;
    cout<<"now your current balance is :";
    current_amount=total_amount-withdraw;
    cout<<current_amount;
}

}
   
    
    
