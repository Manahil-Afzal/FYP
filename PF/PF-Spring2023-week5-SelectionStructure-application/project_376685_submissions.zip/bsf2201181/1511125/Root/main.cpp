/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    long balance, transaction;
    int option;
    balance=50000;              // Let balance is 50000
    cout<<"Enter 1 to Deposit or 2 to Withdraw"<<endl;
    cin>>option;
    if (option==1)
    {
        cout<<"Enter amount you want to deposit "<<endl;
        cin>>transaction;
        cout<<"You have successfully deposited PKR"<<transaction<<endl;
        cout<<"Your current balance is PKR"<<balance+transaction;
    }else if (option==2)
    {
        cout<<"Enter amount you want to withdraw"<<endl;
        cin>>transaction;
        if (transaction>balance){
        cout<<"You don't have sufficient amount in your account";
        }else
        {
        cout<<"You have successfully withdrawn PKR"<<transaction<<endl;
        cout<<"Your current balance is PKR"<<balance-transaction;
        }
    }
    else
    cout<<"Select a valid option";
}