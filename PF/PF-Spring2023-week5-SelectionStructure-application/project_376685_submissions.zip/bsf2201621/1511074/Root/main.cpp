/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int balance=3000;
    int cash;
    cout<<"enter cash to deposite";
    cin>>cash;
    balance=balance+cash;
    cout<<"total balance after deposite is="<<balance;
}