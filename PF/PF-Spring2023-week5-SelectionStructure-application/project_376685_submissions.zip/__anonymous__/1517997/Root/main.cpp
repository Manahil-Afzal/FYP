/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
 main()
{
    int amount,deposit,withdraw,currentbalance;
    cout<<"enter amount";
    cin>>amount;
    cout<<"what you want to do"<<endl<<"deposit or withdraw"<<endl<<"press 1 to withdraw or 2 to deposit";
    int x;
    cin>>x;
    if (x==1)
    {
        cout<<"how much do you want to withdraw"<<endl<<"enter value";
        cin>>withdraw;
        if(withdraw<=amount)
        {
            currentbalance=amount-withdraw;
            cout<<"your currentbalance is "<<endl<<currentbalance;
        }
    }
        if(x==2)
        {
            cout<<"how much money do you want to deposit"<<endl<<"enter value";
            cin>>deposit;
            currentbalance=amount+deposit;
            cout<<"your current balance is"<<endl<<currentbalance;
        }
   
    cout<<"thanks for coming";Compilation successful
2
User: bsf2201197 Role: Project user
  
}