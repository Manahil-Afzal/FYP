#include<iostream>
using namespace std;
main()
{
	 int DepositAmmount1,WithdrawAmmount1;
	 float bal;
	 cout<<" Balance = ";
	 cin>>bal;
        cout<<" Enter Deposit Amount = ";
		cin>>DepositAmmount1;
        bal+=DepositAmmount1;
        cout<<" Enter Withdraw Amount = ";
        cin>>WithdrawAmmount1;
        bal-=WithdrawAmmount1;
          cout<<"***********"<<endl;
          cout<<" Current Balance : "<<bal<<endl;
          if(WithdrawAmmount1>bal)
                cout<<" Cannot withdraw amount";
}