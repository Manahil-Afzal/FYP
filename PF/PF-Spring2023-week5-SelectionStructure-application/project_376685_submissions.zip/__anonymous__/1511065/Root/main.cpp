/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int balance=50000,amount;
    cout<<"Enter the amount you want to deposit =";
    cin>>amount;
    if(amount<0)
    {
        cout<<"Enter the positive amount."<<endl;
    }
    else if (amount >balance)
    {
        cout<<"This is too less to deposit"<<balance<<endl;
    }
    else
    {
        balance+=amount;
    }
    cout<<"after depositing balance is ="<<balance<<endl;
    cout<<"Transaction successful."<<endl;
}