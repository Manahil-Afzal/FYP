#include<iostream>
using namespace std;
int main()
{
	long balance, transaction;
	int option;
	cout<<"Enter your current balance";
	cin>>balance;
	cout<<"Enter 1 for deposit and 2 for withdrawal";
	cin>>option;
	if(option==1)
	{
	cout<<"Enter amount you want to deposit";
	cin>>transaction;
	cout<<"Your current balance is "<<transaction+balance;
}
	else if(option==2)
	{	
	cout<<"Enter amount you want to withdraw";
	cin>>transaction;
	if(transaction>balance) {
	cout<<"You don't have sufficient balance Enter valid amount";}
}
cout<<"Your current balance is "<<balance-transaction;
	
	}