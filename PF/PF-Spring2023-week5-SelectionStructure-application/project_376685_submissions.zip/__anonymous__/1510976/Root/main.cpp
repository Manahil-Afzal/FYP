/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/



#include <iostream>
using namespace std;
int main(){
    int current_amount=1000,transaction_amount,new_amount;
    string method;
    cout<<"Do you want to withdraw or deposit";
    cin>>method;
    if(method=="deposit"){
        cout<<"Enter the amount you want to deposit";
        cin>>new_amount;
        current_amount=current_amount+new_amount;
    }else{
        cout<<"Enter the amount you want to withdraw";
        cin>>new_amount;
        current_amount=current_amount-new_amount;
    }
    
    cout<<"Your current balence is " << current_amount;
    
    return 0;
}
