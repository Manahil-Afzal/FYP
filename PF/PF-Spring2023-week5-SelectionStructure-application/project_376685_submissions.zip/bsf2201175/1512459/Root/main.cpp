/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
int balance,withdraw_amount,deposit_amount,current_balance,work;
cout<<"enter the current amount in bank account";
cin>> balance;
cout<<"what you want to do in your account,press 1 for withdraw money,press 2 for deposit money";
cin>>work;
if(work==1){
    cout<<"how much amount you want to withdraw?";
    cin>>withdraw_amount;
    int total=balance-withdraw_amount;
    cout<<"the remaining amount that left after withdrawing is,now your current balance is:"<<total;
}else if(work==2){
    cout<<"how much money you want to deposit?";
    cin>>deposit_amount;
    int total=balance+deposit_amount;
    cout<<"the amount after deposit money in it,now your current balance is:"<<total;
}else{
    cout<<"your current balance is:"<<balance;
     }
}