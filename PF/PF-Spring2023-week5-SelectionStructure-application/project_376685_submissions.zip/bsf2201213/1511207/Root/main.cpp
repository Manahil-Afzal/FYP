/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account
*/
#include <iostream>
using namespace std;
int main()
{
    long double balance=50000;
    long double transection;
    int choice;
    cout<<"enter 0 or 1 for diposit or withdraw ";
    cin>>choice;
    if(choice==0)
    {
        cout<<" \n enter amount ";
        cin>>transection;
        balance = balance+transection;
        cout<<"your new balance is "<<balance;
    }
    else if(choice == 1)
    {
        cout<<"enter amount which you want to withdraw  "<<endl;
        cin>>transection;
        if(transection > balance )
        {
            cout<<"insuficient balance ";
        }
        if(transection < balance )
        {
            balance = balance - transection;
            cout<<"transection is done and new balance is "<<balance;
        }
    }
    else 
    {
        cout<<"invalid input ";
    }
    return 0;
}