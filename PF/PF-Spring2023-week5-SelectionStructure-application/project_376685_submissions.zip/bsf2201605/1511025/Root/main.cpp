/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int total,with,dep,rem;
    char op;
    cout<<"enter current balance=";
    cin>>total;
    cout<<"Do you want to deposit or withdraw?=";
    cin>>op;
    if (op=='D')
    {
        cout<<"Enter the amount you want to deposit=";
        cin>>dep;
        rem=total+dep;
        cout<<"total amount after deposit="<<rem;
}
else if(op=='W')
{
    cout<<"enter the amount you want to withdraw=";
    cin>>with;
    rem=total-with;
    cout<<"remaining amount after withdraw="<<rem;
    
}
else
cout<<"INVALID VALUE";
}