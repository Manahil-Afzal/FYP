/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
 int account=5000,x,z;
 cout<<"you want to deposite cash ? type 1 for yes or 0 for no:";
 cin>>x;
 if(x==1)
 {
     cout<<"enter amount you want to deposite:";
     cin>>z;
     account+=z;
}
else if(x==0)
{
    cout<<"enter amount you want to withdraw:";
    cin>>z;
    account-=z;
}
else
cout<<"no trasactiion"<<endl;
cout<<"Remaining Balance:"<<account;
}