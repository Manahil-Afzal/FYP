/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include <iostream>
using namespace std;

int main() {
    float balance = 1000.00; // initialize account balance to $1000.00
    float amount; // to store the amount to be withdrawn or deposited
    char choice; // to store the user's choice (w or d)
    
    cout << "Current balance: $" << balance << endl;
    cout << "Do you want to withdraw (w) or deposit (d) money? ";
    cin >> choice;
    
    switch(choice) {
        case 'w': // withdraw money
            cout << "Enter the amount to be withdrawn: $";
            cin >> amount;
            if(amount > balance) {
                cout << "Insufficient balance!" << endl;
            } else {
                balance -= amount;
                cout << "New balance: $" << balance << endl;
            }
            break;
        case 'd': // deposit money
            cout << "Enter the amount to be deposited: $";
            cin >> amount;
            balance += amount;
            cout << "New balance: $" << balance << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
            break;
    }
    
    return 0;
}
