/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
	int total, deposit, withdraw, remaining;
	char op;
	cout<<"enter the current blance:";
	cin>>total;
	cout<<"what do you want deposit or withdraw money:";
	cin>>op;
	if(op=='D')
	{
		cout<<"enter the money you want to deposit:";
		cin>>deposit;
		remaining=total+deposit;
		cout<<"total amount after deposit:"<<remaining;
	}
	else if(op=='W')
	{
		cout<<"enter the amount you want to withdraw:";
		cin>>withdraw;
		remaining=total-withdraw;
		cout<<"total amount after withdraw:"<<remaining;
	}
	else
	cout<<("invalid value");
}