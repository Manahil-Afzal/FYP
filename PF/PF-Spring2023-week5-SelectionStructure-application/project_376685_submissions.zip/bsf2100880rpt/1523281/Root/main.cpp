/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int existingBalance=20000;
    cout<<"Existing balance of a Bank’s account: "<<existingBalance<<endl;
    int choice,withdraw,deposit,currentBalance;
    cout<<"if you want to withdraw then press 1, For deposit press 2, For exit press 0 :"<<endl;
    cin>>choice;
    switch(choice)
    {
        case 1:
        cout<<"enter amount for withdraw:  ";
        cin>>withdraw;
        currentBalance = existingBalance - withdraw;
         if(withdraw > existingBalance)
        {
            cout<<"YOU HAVE NOT ENOUGH AMOUNT."<<endl;
        }
        else
        {
            cout<<"successfully withdraw."<<endl;
            cout<<"After Transaction."<<endl;
            cout<<"Current Balance : "<<currentBalance;
        }
        
        
        break;
        
        case 2:
        cout<<"enter amount for deposit:  ";
        cin>>deposit;
        currentBalance = existingBalance + deposit;
        cout<<"After Transaction."<<endl;
        cout<<"Current Balance : "<<currentBalance;
        break;
        
        case 0:
        return 0;
        break;
    }
    
    return 0;
}