/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
 int main()
  
 {
    float balance;
    char transactionType;
    float transactionAmount;
    cout << "Enter current balance: ";
    cin >> balance;
 cout << "Enter transaction type (d for deposit, w for withdrawal): ";
    cin >> transactionType;
cout << "Enter transaction amount: ";
    cin >> transactionAmount;
 if (transactionType == 'd') {
        balance += transactionAmount;
        cout << "Deposit successful." << endl;
    } else if (transactionType == 'w') {
        if (transactionAmount > balance) {
            cout << "Insufficient funds for withdrawal." << endl;
        } else {
            balance -= transactionAmount;
            cout << "Withdrawal successful." << endl;
        }
    } else {
        cout << "Invalid transaction type. Please enter 'd' for deposit or 'w' for withdrawal." << endl;
        return 0;
    }cout << "Current balance: " << balance << endl;
	return 0;
}
        