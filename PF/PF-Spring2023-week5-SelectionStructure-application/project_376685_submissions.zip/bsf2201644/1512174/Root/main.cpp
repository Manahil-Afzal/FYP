
#include <iostream>

using namespace std;

int main()
{
    float balance = 1000.00; // existing balance in the bank account
    float amount; // amount to be deposited or withdrawn
    char transaction; // transaction type (deposit or withdrawal)

    cout << "Enter transaction type (D for deposit, W for withdrawal): ";
    cin >> transaction;

    if (transaction == 'D' || transaction == 'd') // if deposit
    {
        cout << "Enter amount to deposit: ";
        cin >> amount;
        balance += amount; // add amount to balance
        cout << "Deposit successful." << endl;
    }
    else if (transaction == 'W' || transaction == 'w') // if withdrawal
    {
        cout << "Enter amount to withdraw: ";
        cin >> amount;
        if (amount > balance) // check if withdrawal amount is greater than balance
        {
            cout << "Insufficient balance." << endl;
        }
        else
        {
            balance -= amount; // subtract amount from balance
            cout << "Withdrawal successful." << endl;
        }
    }
    else // if invalid transaction type
    {
        cout << "Invalid transaction type." << endl;
    }

    cout << "Current balance: " << balance << endl; // display current balance

    return 0;
}