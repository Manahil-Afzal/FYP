/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main ()
{
float balance;
char transactionType;
float transactionAmount;
cout<<"enter current balance :";
cin>>balance;
cout<<"enter transaction type (d for deposit,w for withdrawal):";
cin>>transactionType;
cout<<"enter transaction amount :";
cin>>transactionAmount;
if(transactionType=='d')
{
	balance+=transactionAmount;
	cout<<"deposit successful."<<endl;
}
else if (transactionType=='w') {

if(transactionAmount>balance)
{
	cout<<"incufficient funds for withdrawal."<<endl;
}
else {
balance-=transactionAmount;
cout<<"withdrawal successful."<<endl;
} 
}else {
cout<<"invalid transationType.please enter 'd' for deposit or 'w' for withdrawal."<<endl;
return 0;
}
cout<<"current balance :"<<balance<<endl;
return 0;
}