/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main(){
    int save_amount=5000,transaction,new_balance,current_amount;
    string method;
    cout<<"Do you want to withdraw or deposite ?";
    cin>>method;
    if(method=="deposit"){
        cout<<"Enter the amount you want to deposit ";
        cin>>new_balance;
        current_amount=save_amount+new_balance;
    }else{
        cout<<"Enter the amount you want to withdraw ";
        cin>>new_balance;
        current_amount=save_amount-new_balance;
    }
    cout<<"your current balance is "<<current_amount;
}