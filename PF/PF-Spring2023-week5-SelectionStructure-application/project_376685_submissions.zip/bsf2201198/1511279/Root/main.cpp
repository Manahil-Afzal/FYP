/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{

    long balance,amount;
    int option;
    balance=50000;         //let balance is 50000
    cout<<"Enter 1 to Deposit or 2 to Withdraw"<<endl;
    cin>>option;
    if (option==1){
    cout<<"Enter amount you want to deposite "<<endl;
    cin>>amount;
    cout<<"You have successfully deposited PKR "<<amount<<endl;
    cout<<"Your current balance is PKR"<<balance+amount;
    }
    else if(option==2){
     cout<<" Enter amount you want to withdraw"<<endl;
     cin>>amount;
        if(amount>balance){
        
        cout<<"you dont have sufficient amount in your account "<<endl;
        
        }
        else
        {
            cout<<"You successfully withdraw PKR"<<amount<<endl;
            cout<<"Your current balance is"<<balance- amount; 
        }
        }
    
else{
    cout<<"Select valid option ";
}
}