/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int amount=150000,deposit,withdraw;
    char choice;
    cout<<"press  \"w\" for withdraw press  \"d\" for deposit cash";
    cin>>choice;
    if(choice=='w' || choice=='W')
    {
        cout<<"enter the amount you want to withdraw";
        cin>>withdraw;
        if(withdraw>amount)
            {
                cout<<"insufficient balance";
                
            }
            else
            {
                amount=amount-withdraw;
                cout<<"your new balance= "<<amount;
                
            }
    }
    else if(choice=='d' || choice=='D')
        {
            cout<<"enter the amount you want to deposit";
            cin>>deposit;
            amount=amount+deposit;
            cout<<"your new  balance= "<<amount;
        }

}