/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
    int account=5000, deposite,withdraw,z,x;
    cout<<"you want to deposit cash?, type 1 for yes or 0 for no;";
    cin>>x;
    if (x==1)
    {
        cout<<"enter the amount;";
        cin>>deposite;
        account+=deposite;
    }
   
    else
     {  
         cout<<"you want to withdraw cash ?,type 1 for yes or 0 for no;";
      cin>>z;
      if(z==1)
        {
		cout<<"enter the amount;";
        cin>>withdraw;
        account-=withdraw;}
		
    }
    
    
    cout<<"remaining balance;"<<account;
}