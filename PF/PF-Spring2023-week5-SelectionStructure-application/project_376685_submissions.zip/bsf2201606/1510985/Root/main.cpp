/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main()
{
    int EB=5000,w;
    cout<<"Enter the withdrawl balance";
    cin>>w;
    EB=EB-w;
    cout<<"The existing balance is ="<<EB<<endl;
    
}