/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
{
	int amount,CBalance,Afwithdraw;
	cout<<"Enter the Current Balance to your Account!"<<endl;
	cin>>CBalance;
	cout<<"Enter the Withdraw amount to your Account!"<<endl;
	cin>>amount;
	Afwithdraw = CBalance - amount;
	cout<<"The total balance after Withdraw is = "<<Afwithdraw<<endl;
	
	
}