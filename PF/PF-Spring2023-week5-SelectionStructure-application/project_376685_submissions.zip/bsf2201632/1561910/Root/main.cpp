/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main(){
    float balance=10000;
    float transactionAmount;
    cout<<"Enter the Transaction Amount"<<endl;
    cin>>transactionAmount;
    char transactionType;
    cout<<"Enter the Transaction Type (W for withdrawal, D for deposit):"<<endl;
    cin>>transactionType;
    if(transactionType=='D'){
        balance+=transactionAmount;
        cout<<"Deposit Successful"<<endl;
    }
    else if(transactionType=='W'){
        if(transactionAmount>balance){
            cout<<"Insufficient Funds"<<endl;
        }else{
            balance-=transactionAmount;
            cout<<"Withdrawal Successful"<<endl;
        }
         }else{
             cout<<"Invalid Transaction"<<endl;
         }
         cout<<"Current balance"<<balance<<endl;
}