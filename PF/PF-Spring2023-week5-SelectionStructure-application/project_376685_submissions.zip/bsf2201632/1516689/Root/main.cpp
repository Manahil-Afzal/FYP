#include<iostream>
using namespace std;

int main()
{
    int total=200000;
    char dep,with;
    cout<<"what you want"<<endl;
    cin>>dep,with;
    if(dep=='d')
    {
    int am;
    cout<<"how much"<<endl;
    cin>>am;
    cout<<"current balance is"<<total+am;
    }
    
    else(with='w');
    {
    cout<<"how much you withdraw";
    int rem;
    cout<<"enter amount";
    cin>>rem;
    cout<<total-rem;
    }
    
    
}/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/