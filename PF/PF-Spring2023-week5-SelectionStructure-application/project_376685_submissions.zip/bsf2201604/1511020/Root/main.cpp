/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
main()
 {
     int tot,w,dep,r;
     char n;
     cout<<"enter current balance =";
     cin>>tot;
     cout<<"Do you want to deposit or withdraw(D/W) =";
     cin>>n;
     if(n=='D')
     {
         cout<<"enter the amount you want to deposit =";
         cin>>dep;
         r=tot+dep;
         cout<<"Total amount after deposit ="<<r;
         
     }
     else if(n=='W')
     {
         cout<<"enter the amount you want to withdraw =";
         cin>>w;
         r=tot-w;
         cout<<"Remaining amount after withdraw ="<<r; 
     }
     else
     cout<<"Invalid character entered";
 }
 