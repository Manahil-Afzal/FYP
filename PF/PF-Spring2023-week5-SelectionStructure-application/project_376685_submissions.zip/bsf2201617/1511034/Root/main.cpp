/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
#include<string>
using namespace std;

int main()
{  
    int balance=3000;
    int cash;
    cout<<"enter cash to deposit";
    cin>>cash;
    cout<<"total balance aafter deposite is="<<balance;
}

    