/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
/*Write a C++ program that performs a transaction in the existing balance of a Bank’s account. 
Take input from the user the amount he/she wants to either withdraw or deposit from account’s balance and displays 
the current balance after performing the transaction user wants to perform on the Bank’s account.*/
#include<iostream>
using namespace std;
int main(){
	int T_amount=20000;
	int choice,c_balance,withdraw,deposit;
	cout<<"press 1 to withdraw"<<endl;
	cout<<"press 2 to deposit"<<endl;
	cout<<"press 3 to exit"<<endl;
	cout<<"enter your choice=";
	cin>>choice;
	switch(choice){
		case 1:
		cout<<"input the amount,you want to withdraw in your account=";
		cin>>withdraw;
		c_balance=T_amount-withdraw;
		cout<<"current amount is="<<c_balance;
		cout<<"\nThanks For Using Bank Account System ";
		break;	
		case 2:
		cout<<"input the amount,you want to deposit in your account=";
		cin>>deposit;
		c_balance=T_amount+deposit;
		cout<<"current amount is="<<c_balance;
		cout<<"\nThanks For Using Bank Account System ";
		break;	
		case 3:
			cout<<"Thanks For Using Bank Account System";
		break;	
	}
	return 0;
}