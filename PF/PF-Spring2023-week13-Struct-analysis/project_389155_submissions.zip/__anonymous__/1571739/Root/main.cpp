// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
};// d1, d2, sumOfDistances;

int main() {
    Distance distance1,distance2,sumOfDistances;
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: ";
    cin>>distance1.feet;
    cout<<"Enter inch: ";
    cin>>distance2.inch;
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>distance2.feet;
    cout<<"Enter inch: ";
    cin>>distance2.inch;

    sumOfDistances.feet=distance1.feet=distance2.feet;
    sumOfDistances.inch=distance1.inch+distance2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = ";
cout<<sumOfDistances.feet<<":"<<sumOfDistances.inch;
    return 0;
}


