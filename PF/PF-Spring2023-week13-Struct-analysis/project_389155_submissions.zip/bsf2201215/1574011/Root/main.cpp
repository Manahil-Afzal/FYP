// Identify and correct errors.

#include <iostream>
using namespace std;

struct Distance {
    int feet;
    float inch;
};

int main() {
    Distance d1, d2, sumOfDistances;
    cout << "Enter information for 1st distance\n";
    cout << "Enter feet: ";
    cin >> d1.feet;
    cout << "Enter inch: ";
    cin >> d1.inch;
    cout << "\nEnter information for 2nd distance\n";
    cout << "Enter feet: ";
    cin >> d2.feet;
    cout << "Enter inch: ";
    cin >> d2.inch;

    sumOfDistances.feet = d1.feet + d2.feet;
    sumOfDistances.inch = d1.inch + d2.inch;

    if (sumOfDistances.inch >= 12.0) {
        sumOfDistances.inch = sumOfDistances.inch - 12.0;
        ++sumOfDistances.feet;
    }

    cout << "\nSum of distances = ";
    cout << sumOfDistances.feet << " feet, " << sumOfDistances.inch << " inches.";
    return 0;
}
