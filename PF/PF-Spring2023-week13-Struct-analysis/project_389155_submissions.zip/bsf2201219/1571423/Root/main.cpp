// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
};

int main() {
	Distance d1, d2, sumOfDistances;
	float feet ,inch; //declaration of variables
    cout<<"Enter information for 1st distance\n";
    cout<<"Enter feet: "; //extra bracket error
    cin>>feet;
    cout<<"Enter inch: ";
    cin>>inch;
    d1.feet= feet;
    d1.inch= inch;
    cout<<"\nEnter information for 2nd distance\n";
    cout<<"Enter feet: ";
    cin>>d2.feet; // extra bracket error
    cout<<"Enter inch: ";
    cin>>d2.inch;

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = ";// inverted comma error
cout<<sumOfDistances.feet, sumOfDistances.inch;
    return 0;
}


