#include <iostream>
using namespace std;

struct Distance {
    int feet;
    float inch;
};

int main() {
    Distance d1, d2, sumOfDistances;  // declare variables

    cout << "Enter information for 1st distance\n";
    cout << "Enter feet: ";          // fixed a syntax error
    cin >> d1.feet;                  // read feet of first distance
    cout << "Enter inch: ";
    cin >> d1.inch;                  // read inch of first distance

    cout << "\nEnter information for 2nd distance\n";
    cout << "Enter feet: ";
    cin >> d2.feet;                  // read feet of second distance
    cout << "Enter inch: ";
    cin >> d2.inch;                  // read inch of second distance

    sumOfDistances.feet = d1.feet + d2.feet;
    sumOfDistances.inch = d1.inch + d2.inch;

    if (sumOfDistances.inch >= 12.0) { // fixed a logic error
        sumOfDistances.inch = sumOfDistances.inch - 12.0;
        ++sumOfDistances.feet;
    }
    cout << "\nSum of distances = " << sumOfDistances.feet << " feet, " << sumOfDistances.inch << " inches\n"; // fixed a syntax error
    return 0;
}
