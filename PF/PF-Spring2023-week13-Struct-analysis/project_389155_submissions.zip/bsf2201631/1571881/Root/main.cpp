#include <iostream>
using namespace std;

struct Distance {
    int feet;
    float inch;
}; // moved variable declaration below struct definition
Distance d1, d2, sumOfDistances; // added variable names here

int main() {
    // corrected syntax error
    cout << "Enter information for 1st distance\n";
    cout << "Enter feet: ";
    cin >> d1.feet; // added variable name
    cout << "Enter inch: ";
    cin >> d1.inch; // added variable name
    cout << "\nEnter information for 2nd distance\n";
    cout << "Enter feet: ";
    cin >> d2.feet; // removed -> and added variable name
    cout << "Enter inch: ";
    cin >> d2.inch; // removed -> and added variable name

    sumOfDistances.feet = d1.feet + d2.feet;
    sumOfDistances.inch = d1.inch + d2.inch;

    if (sumOfDistances.inch > 12.0) {
        sumOfDistances.inch = sumOfDistances.inch - 12.0;
        ++sumOfDistances.feet;
    }

    // corrected quotation marks and added a space between variables
    cout << "\nSum of distances = ";
    cout << sumOfDistances.feet << " feet " << sumOfDistances.inch << " inches";

    return 0;
}