/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

int isPrime(int n); // Correct function declaration

int main()
{
    int num;

    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num)) // Correct variable name
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}

int isPrime(int n) // Correct parameter type
{
    if (n <= 1)
        return 0;

    for (int i = 2; i * i <= n; i++) // Correct loop condition
    {
        if (n % i == 0)
        {
            return 0; // It's not a prime number
        }
    }
    return 1; // It's a prime number
}