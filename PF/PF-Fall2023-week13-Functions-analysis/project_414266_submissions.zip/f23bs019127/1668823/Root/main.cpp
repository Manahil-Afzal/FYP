/*This program checks and displays if a number is prime*/


#include <iostream>
using namespace std;

int isPrime(int n); 

int main() {
    int num;

    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num)) // Corrected the variable name from 'nm' to 'num'
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}

int isPrime(int n) { // Corrected the parameter type from 'long' to 'int'
    if (n <= 1) {
        return 0; // 0 and 1 are not prime numbers
    }

    for (int i = 2; i * i <= n; ++i) { // Changed the loop condition for optimization
        if (n % i == 0) {
            return 0; // Not a prime number
        }
    }
    return 1; // Prime number
}
