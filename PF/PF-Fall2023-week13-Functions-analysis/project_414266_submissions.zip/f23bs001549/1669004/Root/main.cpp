/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

int isPrime(int n);  // Corrected the function signature

int main()
{
    int num;

    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num))  // Changed 'nm' to 'num'
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}

int isPrime(int n)
{
    if (n <= 1)
        return 0;  // 0 and 1 are not prime numbers

    for (int i = 2; i <= n / 2; i++)  // Changed the loop condition
    {
        if (n % i == 0)
        {
            return 0;  // n is divisible by i, so it's not prime
        }
    }

    return 1;  // If no factor is found, it's a prime number
}