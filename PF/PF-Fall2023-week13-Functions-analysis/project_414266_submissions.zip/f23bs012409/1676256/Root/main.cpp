#include<iostream>
using namespace std;
int isPrime(int n); //Data type is not mentioned
int main()
{ int num;
cout<<"Enter an integer number:";
cin>>num;
if(isPrime(num)) //Wrong spelling of num
cout<<num<<" is a prime number"<<endl;
else
cout<<num<<" is not a prime number"<<endl;
return 0; }
int isPrime(int n) //Wrong data type
{ int prime=1;
for(int i=2;i<(n-1);i++) //Data type is missing
{ if(n%i==0)
{ prime=0;
break; }
} return prime; }
