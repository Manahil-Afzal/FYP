/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

int isPrime(int n);

int main()
{
	int num;
	
	cout<<"Enter an integer number: ";
	cin>>num;
	
	if(isPrime(num))//variable name was writtwn wrong
		cout<<num<<" is a prime number"<<endl;
	else
		cout<<num<<" is not a prime number"<<endl;
		
	return 0;
}


int isPrime(int n)//variable type in prototype and functiom should be same
{
	
	int prime=1;
	
	for(int i=2;i<(n-1);i++)//data type of i was not declare
	{
		if(n%i==0)
		{
			prime=0;
			break;
		}
	}
	return prime;
}
