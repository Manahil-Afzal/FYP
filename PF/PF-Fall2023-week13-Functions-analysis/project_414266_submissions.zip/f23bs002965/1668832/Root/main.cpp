/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

bool isPrime(long n);

int main()
{
    long num;
    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num))
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}

bool isPrime(long n)
{
    bool prime = true;

    for (long i = 2; i <= n / 2; ++i) {
        if (n % i == 0) {
            prime = false;
            break;
        }
    }

    return prime;
}
