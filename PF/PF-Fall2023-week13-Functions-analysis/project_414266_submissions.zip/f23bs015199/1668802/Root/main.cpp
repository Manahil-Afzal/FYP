// /*This program checks and displays if a number is prime just identify errors*/
// #include <iostream>
// using namespace std;

// int isPrime(n);

// int main()
// {
// 	int num;
	
// 	cout<<"Enter an integer number: ";
// 	cin>>num;
	
// 	if(isPrime(nm))
// 		cout<<num<<" is a prime number"<<endl;
// 	else
// 		cout<<num<<" is not a prime number"<<endl;
		
// 	return 0;
// }


// int isPrime(long n)
// {
	
// 	int prime=1;
	
// 	for(i=2;i<(n-1);i++)
// 	{
// 		if(n%i==0)
// 		{
// 			prime=0;
// 			break;
// 		}
// 	}
// 	return prime;
// }
#include <iostream>
using namespace std;

bool isPrime(long n); // Explicitly declare the function return type and parameter type

int main()
{
    long num;  // Use 'long' instead of 'int' to accommodate larger values
	
    cout << "Enter an integer number: ";
    cin >> num;
	
    if (isPrime(num)) // Use the correct variable 'num'
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;
		
    return 0;
}

bool isPrime(long n) // Match the function declaration and function definition
{
    if (n <= 1) {
        return false;
    }
	
    for (int i = 2; i * i <= n; i++) // Initialize 'i', and use i * i <= n for efficiency
    {
        if (n % i == 0)
        {
            return false;
        }
    }
    return true;
}
