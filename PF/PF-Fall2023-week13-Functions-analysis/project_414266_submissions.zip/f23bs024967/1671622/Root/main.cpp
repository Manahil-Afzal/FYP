#include <iostream>
using namespace std;

int isPrime(int n);

int main()
{
    int num;

    cout << "Enter an integer number: ";
    cin >> num;

    if (isPrime(num))
        cout << num << " is a prime number" << endl;
    else
        cout << num << " is not a prime number" << endl;

    return 0;
}

int isPrime(int n)
{
    if (n <= 1)
        return 0; // 0 and 1 are not prime

    for (int i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return 0; // not a prime number
        }
    }
    return 1; // prime number
}


