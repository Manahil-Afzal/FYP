#include <iostream>

using namespace std;

void average(int a, int b, int c) {
  float avg = (a + b + c) / 3.0;
  cout << "The average of " << a << ", " << b << ", and " << c << " is " << avg << endl;
}

void smallest(int a, int b, int c) {
  int smallest = a; // Assume a is the smallest initially

  if (b < smallest) {
    smallest = b;
  }

  if (c < smallest) {
    smallest = c;
  }

  cout << "The smallest of " << a << ", " << b << ", and " << c << " is " << smallest << endl;
}

void largest(int a, int b, int c) {
  int largest = a; // Assume a is the largest initially

  if (b > largest) {
    largest = b;
  }

  if (c > largest) {
    largest = c;
  }

  cout << "The largest of " << a << ", " << b << ", and " << c << " is " << largest << endl;
}

int main() {
  int a, b, c;

  cout << "Enter three numbers: ";
  cin >> a >> b >> c;

  average(a, b, c);
  smallest(a, b, c);
  largest(a, b, c);

  return 0;
}
