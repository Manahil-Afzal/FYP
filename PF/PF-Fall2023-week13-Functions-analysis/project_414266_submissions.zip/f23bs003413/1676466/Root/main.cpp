/*This program checks and displays if a number is prime*/
#include <iostream>
using namespace std;

int isPrime(long n);

int main()
{
	int num;
	
	cout<<"Enter an integer number: ";
	cin>>num;
	
	if(isPrime(num))
		cout<<num<<" is a prime number"<<endl;
	else
		cout<<num<<" is not a prime number"<<endl;
		
	return 0;
}


int isPrime(long n)
{
	
	int prime=1;
	
	for(prime=2;prime<(n-1);prime++)
	{
		if(n%prime==0)
		{
			prime=0;
			break;
		}
	}
	return prime;
}
