/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
#include<string>
using namespace std;
int main()
{ 
 string name;
 int age,salary,working_days,monthly_salary;
 cout<<"Enter the name";
 cin>>name;
 cout<<"Enter the age";
 cin>>age;
 cout<<"Enter the salary";
 cin>>salary;
 cout<<"Enter the woking days";
 cin>>working_days;
 monthly_salary=salary*working_days;
 cout<<"Monthely salary="<<monthly_salary;
 return 0;
    
}