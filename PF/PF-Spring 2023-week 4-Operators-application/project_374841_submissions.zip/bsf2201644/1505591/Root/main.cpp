/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
#include<string>
using namespace std;
 main()
{
    string name;
    int age;
    int salary;
    int days;
    int total=0;
    cout<<"enter employee name";
    cin>>name;
    cout<<"enter the emloyee age";
    cin>>age;
    cout<<"enter thr per day salary";
    cin>>salary;
    cout<<"number of days worked in a month";
    cin>>days;
    total=salary*days;
    cout<<name<<age<<total;
    return 0;
}