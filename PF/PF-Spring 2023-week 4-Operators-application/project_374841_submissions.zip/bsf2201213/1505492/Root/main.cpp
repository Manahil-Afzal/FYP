/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main (){
    string name ,age;
    int salery,days,monthlySalery;
    cout<<"enter empolyee name ";
    cin>>name;
    cout<<"enter empolyee age ";
    cin>>age;
    cout<<"enter per day salery ";
    cin>>salery;
    cout<<"enter number of days empolyee work in month ";
    cin>>days;
    monthlySalery=salery*days;
    cout<<"\n\n empolyee name is"<<name<<endl;
    cout<<"empolyee age is "<<age<<endl;
    cout<<"empolyee per day salery "<<monthlySalery;                                                      
}