/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include <iostream>
using namespace std;
main(){
    string name,age;
    int per_day_salary=0,number_of_day_worked=0;
    int monthly_salary=0;
    cout<<"enter the employee name:";
    cin>>name;
    cout<<"age of employee:";
    cin>>age;
    cout<<"enter the earned salaray in one day:";
    cin >>per_day_salary;
    cout<<"number of day worked in month :";
    cin>>number_of_day_worked;
    monthly_salary=per_day_salary*number_of_day_worked;
    cout<<"monthly salary of the employee:"<<monthly_salary;

    
}