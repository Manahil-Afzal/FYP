/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
 main()
{
    string name,age;
    int perdaysalary,numberofdays;
    cout<<"enter name";
    cin>>name;
    cout<<"enter age";
    cin>>age;
    cout<<"enter per day salary";
    cin>>perdaysalary;
    cout<<" enter the number of days worked in month";
    cin>>numberofdays;
    int monthlysalary=perdaysalary*numberofdays;
     cout<<"monthly salary of employee"<<monthlysalary;
}

