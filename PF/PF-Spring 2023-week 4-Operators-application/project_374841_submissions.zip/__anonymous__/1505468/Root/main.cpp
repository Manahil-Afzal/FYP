/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string name;
    int age,perdaysalary,numberofdaysworkedinamonth,monthlysalary;
    cout<<"name of employee";
    cin>>name;
    cout<<"display age";
    cin>>age;
    cout<<"per day salary";
    cin>>perdaysalary;
    cout<<"number of days woek in a month";
    cin>>numberofdaysworkedinamonth;
    monthlysalary=perdaysalary*numberofdaysworkedinamonth;
    cout<<"name of employee"<<name;
    cout<<"disply age"<<age;
    cout<<"per day salary"<<perdaysalary;
    cout<<"days in month"<<numberofdaysworkedinamonth;
    cout<<"monthly salary"<<monthlysalary;
}