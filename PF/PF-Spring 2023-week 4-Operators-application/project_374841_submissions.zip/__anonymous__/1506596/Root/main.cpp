/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string name;
    int age;
    int x;
    int y;
    int Monthly_salary;
    cout<<"name:";
    cin>>name;
    cout<<"age:";
    cin>>age;
    cout<<"per salary day:";
    cin>>x;
    cout<<"number of days worked in a month:";
    cin>>y;
    Monthly_salary=x*y;
    cout<<"Name:"<<name<<endl;
    cout<<"Age:"<<age<<endl;
    cout<<"Monthly_salary:"<<Monthly_salary<<endl;
}