#include<iostream>
using namespace std;
int main()
{
    string name;
    int age,salary,days,total_salary;
    cout<<"Enter your name";
    cin>>name;
    cout<<"Enter your age";
    cin>>age;
    cout<<"Enter your per day salary";
    cin>>salary;
    cout<<"Enter days you have worked";
    cin>>days;
    cout<<name<<endl<<age<<endl<<days;
    total_salary=days*salary;
    cout<<total_salary;
    
}