#include<iostream>
#include<string>
using namespace std;
main()
{
	string name;
	int age,salary,workdays,totalsalary;
	cout<<"enter name";
	cin>>name;
	cout<<"enter age ";
	cin>>age;
	cout<<"enter salary";
	cin>>salary;
	cout<<"enter working days";
	cin>>workdays;
	cout<<"name is "<<name<<endl<<"age is"<<age<<endl<<"salary is"<<salary<<endl<<"workdays is"<<workdays;
	
	totalsalary=salary*workdays;
	cout<<"total salary is"<<endl<<totalsalary;
}/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */