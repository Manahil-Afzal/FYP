/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    int salaryperday,num_work_day,total_salary;
    int age;
    string name;
    cout<<"\n enter your name";
    cin>>name;
    cout<<"\n enter your age in years";
    cin>>age;
    cout<<"\n enter your per day salary";
    cin>>salaryperday;
    cout<<"\n enter your num_work_day";
    cin>>num_work_day;
    total_salary=salaryperday*num_work_day;
    cout<<"name:"<<name<<"\n age:"<<age<<"\num_work _day:"<<"\n salaryperday:"<<salaryperday<<"\n";
    cout<<"\n total salary:"<<total_salary<<"\n";

}
