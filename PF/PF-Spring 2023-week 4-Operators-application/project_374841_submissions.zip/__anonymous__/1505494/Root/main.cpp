 #include<iostream>
#include<string>
using namespace std;
main ()
{
    string name;
 int age,perdaysalary,workingdays,totalsalary;
    cout<<"enter name: ";
    cin>>name;
    cout<<"enter age: ";
    cin>>age;
    cout<<"perdaysalary: ";
    cin>>perdaysalary;
    cout<<"workingdays: ";
    cin>>workingdays;
    cout<<"your name is "<<name<<endl<<"your age is "<<age<<endl<<"your perdaysalary is "<<perdaysalary<<endl<<"workingdays are "<<workingdays<<endl;
    
     totalsalary=perdaysalary*workingdays;
    cout<<"totalsalary is "<<totalsalary<<endl;
}