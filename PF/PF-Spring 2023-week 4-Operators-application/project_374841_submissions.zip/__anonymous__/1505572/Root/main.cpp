/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include <iostream>
using namespace std;
int main(){
    string name;
    int age,per_day_salary,number_of_days;
    cout << "Enter your name";
    cin >> name;
    cout << "enter your age";
    cin>> age;
    cout<<"Enter your salary";
    cin>>per_day_salary;
    cout<<"Enter No Days";
    cin>>number_of_days;
    int total_salary=per_day_salary*number_of_days;
    cout<<name<<endl <<age <<endl <<per_day_salary<<endl <<total_salary<<endl;
}