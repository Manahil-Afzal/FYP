/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main(){
string employee_name;
int age,sallary,number_of_days,total_sallary;
cout<<"Enter the name of the employee";
cin>>employee_name;
cout<<"Enter the age of the employee";
cin>>age;
cout<<"Enter the sallary of one day";
cin>>sallary;
cout<<"Enter the number of days of the employee";
cin>>number_of_days;
cout<<"Total sallary of the employee is "<<sallary*number_of_days;
}