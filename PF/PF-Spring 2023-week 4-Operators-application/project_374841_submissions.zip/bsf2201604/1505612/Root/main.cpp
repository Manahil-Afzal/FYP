/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    int age,salary,nod,total;
    string name;
    cout<<"Enter name of Employee:";
    cin>>name;
    cout<<"enter age of the employee:";
    cin>>age;
    cout<<"enter the per day salary of employee:";
    cin>>salary;
    cout<<"enter the number of days that an employee work:";
    cin>>nod;
    total=salary*nod;
    cout<<"NAME:"<<name<<endl;
    cout<<"AGE:"<<age<<endl;
    cout<<"per day salary:"<<salary<<endl;
    cout<<"EMPLOYEE WORKING DAYS:"<<nod<<endl;
    cout<<"TOTAL SALARY:"<<total<<endl;
    
}