/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main ()
{
    //data members
    string name;
    int age;
    int per_day_salary;
    int number_of_working_days;
    int total_salary;
    //taking input
    cout<<"enter name of the employee: ";
    cin>>name;
    cout<<"enter age of the employee: ";
    cin>>age;
    cout<<"enter per day salary: ";
    cin>>per_day_salary;
    cout<<"enter number of working days: ";
    cin>>number_of_working_days;
    //calculating salary
    total_salary=per_day_salary*number_of_working_days;
    //display
    cout<<"\t Employee Details... "<<endl;
    cout<<"Name : "<<name<<endl;
    cout<<"Age : "<<age<<endl;
    cout<<"Per day salary : "<<per_day_salary<<endl;
    cout<<"Number of working days : "<<number_of_working_days<<endl;
    cout<<"Total salary : "<<total_salary<<endl;
    return 0;
}