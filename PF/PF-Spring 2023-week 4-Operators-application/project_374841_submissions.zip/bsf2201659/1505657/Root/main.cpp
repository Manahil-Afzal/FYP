/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    //Decalartion of data
    string name;
    int age,per_day_salary,no_working_days,salary;
    
    //Taking data from user
    cout<<"Enter the name of employee  :";
    cin>>name;
    
    cout<<"Enter the age of employee :";
    cin>>age;
    
    cout<<"No of working days :";
    cin>>no_working_days;
    
     cout<<" Employee per day salary:";
     cin>>per_day_salary;
     
     salary=per_day_salary*no_working_days;
     
     
     //Display data
     
     cout<<"Name of emplyee  = " <<name<<endl;     
     
     cout<<"age of emplyee  = "<<age<<endl;
     
     cout<<"No_working_days of emplyee  = "<<no_working_days<<endl;
     
     cout<<"Per_day_salary of emplyee  = "<<per_day_salary<<endl;
     
     
         cout<<"Salary of emplyee  = "<<salary; 
         
    
    
    
}
