/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string name,age;
    int salary;
    int workingdays;
    cout<<"entername";
    cin>>name;
    cout<<"enter age";
    cin>>age;
    cout<<"enter per day salary";
    cin>>salary;
    cout<<"enter working days";
    cin>>workingdays;
    cout<<"monthly salary:"<<salary*workingdays<<endl;
   
    
    
}