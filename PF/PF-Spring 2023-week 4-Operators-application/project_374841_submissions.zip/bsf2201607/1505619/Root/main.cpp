/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    int n1,n2,n3, n4;
    string n;
    cout<<"enter the name of employee=";
    cin>>n;
    cout<<"enter the age of employee=";
    cin>>n1;
    cout<<"enter the per day salary of employee=";
    cin>>n2;
    cout<<"enter the number of days that an employee work=";
    cin>>n3;
    n4=n2*n3;
    cout<<"Name"<<n<<endl;
    cout<<"Age"<<n1<<endl;
    cout<<"Per day salary"<<n2<<endl;
    cout<<"Employee work days"<<n3<<endl;
    cout<<"salary"<<n4<<endl;
    
    
    
    
}