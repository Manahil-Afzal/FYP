/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
	int n1,n2,n3,n4;
	string n;
	cout<<"name of employee=";
	cin>>n;
	cout<<"age of employee=";
	cin>>n1;
	cout<<"per day sallery=";
	cin>>n2;
	cout<<"no of days work=";
	cin>>n3;
	n4=n2*n3;
	cout<<"Name"<<n<<endl;
	cout<<"Age"<<n1<<endl;
	cout<<"Sallery"<<n2<<endl;
	cout<<"Days"<<n3<<endl;
	cout<<"Total sallery"<<n4<<endl;
}
