/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */

#include <iostream>
using namespace std;
main()
{
      string name;
      int x,y,z;
      cout<<"enter employee name:";
      cin>>name;
      cout<<"enter employee age:";   
      cin>>x;
      cout<<"enter per day salay:";  
      cin>>y;
        cout<<"enter worked days in month:";
        cin>>z;
        cout<<"name:"<<name<<endl<<"age:"<<x<<endl<<"per day salary:"<<y<<endl<<"worked days in month:"<<z<<endl<<"monthly salary of the employee:"<<y*z;
        }