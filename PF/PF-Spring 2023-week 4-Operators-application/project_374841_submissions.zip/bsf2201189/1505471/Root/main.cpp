/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
    {
        string name,age;
        int salary ,days,monthlysalary;
        cout<<"enter employee name";
        cin>>name;
        cout<<"enter employee age";
        cin>>age;
        cout<<"enter employee per day salary: PKR";
        cin>>salary;
        cout<<"enter the number of days employee work in a month";
        cin>>days;
        monthlysalary=salary*days;
        cout<<"\n employee name is "<<name<<endl;
        cout<<"employee age is "<<age<<endl;
        cout<<"enter employee per day salary is PKR"<<salary<<endl;
        cout<<"employee work"<<days<<"days in a month "<<endl;
        cout<<"employee monthly salary is PKR"<<monthlysalary;
    }