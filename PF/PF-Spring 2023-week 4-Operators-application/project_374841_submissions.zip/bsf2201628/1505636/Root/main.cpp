/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */

#include<iostream>
using namespace std;
main(){
    string name;
    int age, salary,days;
    
    cout<<"Enter your name  ";
    cin>>name;
    cout<<"Enter your age ";
    cin>>age;
    cout<<"Enter per day salary ";
    cin>>salary;
    cout<<"Enter number of day worded in a month ";
    cin>>days;
     cout<<endl;
     cout<<name<<endl;
     cout<<age<<endl;
     cout<<salary<<endl;
     cout<<days<<endl;
     int x=salary*days;
     cout<<x;
     
     
    
}