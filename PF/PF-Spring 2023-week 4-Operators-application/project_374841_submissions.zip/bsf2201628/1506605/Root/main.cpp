/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main(){
    string name;
    int age, x, y;
    cout<<"enter your name  ";
    cin>>name;
    cout<<"enter your age ";
    cin>>age;
    cout<<"enter per day salary  ";
    cin>>x;
    cout<<"enter number of days worked in a month ";
    cin>>y;
    cout<<endl;
    cout<<"name="<<name<<endl <<"age = "<<age <<endl <<"salary="<<x  <<endl<<"no of days ="<<y <<endl;
    int z=x*y;
    cout<<"monthly salary of employee  "<<z;
}