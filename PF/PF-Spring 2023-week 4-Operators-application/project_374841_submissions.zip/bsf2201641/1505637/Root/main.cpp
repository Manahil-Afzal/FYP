        /*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */ 
#include<iostream>
#include<string>
using namespace std;
main()
{
    string name;
    int age, salary, days;
    int total=0;
    cout<<"Employee Name=";
    cin>>name;
    cout<<"Employee Age=";
    cin>>age;
    cout<<"Per day salary=";
    cin>>salary;
    cout<<"No of working days=";
    cin>>days;
    total=salary*days;
    cout<<name<<endl<<age<<endl<<total;
}