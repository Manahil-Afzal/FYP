/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name;
    int age,salary,days,monthlysalary;
cout<<"name of the employee\n";
cin>>name;
cout<<"age of the employee\n";
cin>>age;
cout<<"per day salary of employee\n";
cin>>salary;
cout<<"number of working days\n";
cin>> days;
monthlysalary = salary*days;
cout<<"monthly salary"<<monthlysalary;
}