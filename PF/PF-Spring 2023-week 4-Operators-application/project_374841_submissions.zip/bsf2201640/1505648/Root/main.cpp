/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main(){
    string employename;
    int age,sallary,numberofdayswork,totalsallary;
    cout<<"enter the name of employe ";
    cin>>employename;
     cout<<"enter the age of employe ";
    cin>>age;
    cout<<"enter the salary of employe ";
    cin>>sallary;
     cout<<"enter the number of days of the employe ";
    cin>>numberofdayswork;
    cout<<"total sallary of the employe "<<sallary*numberofdayswork;
    
}