/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include <iostream>
using namespace std;
main()
{
    string name,age;
   int salary,numberofdaysworked,monthlysalary;
   cout<<" Enter name";
   cin>>name;
   cout<<"Enter age";
   cin>>age;
   cout<<"Enter per day salary";
   cin>>salary;
   cout<<"Enter number of days worked in a month";
   cin>>numberofdaysworked;
   monthlysalary=salary*numberofdaysworked;
   cout<<"monthly salary of employee"<<monthlysalary;
    
}