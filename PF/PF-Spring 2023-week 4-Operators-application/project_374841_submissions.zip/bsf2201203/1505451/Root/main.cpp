/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */

#include<iostream>
using namespace std;
int main()
{
   int age, day, work, earn;
    string name;
    cout<<"Write youe name below: \n";
    cin>>name;
    cout<<"write your age below: \n";
    cin>>age;
    cout<<"how much you got for the day: \n";
    cin>>day;
    cout<<"how many days you work in a month: \n";
    cin>>work;
    earn=work*day;
    cout<<"the name of the user is "<<name<< " and is " <<age<<" old who works "<<work<<" days in a month and got salary "<<day<<"per day";
    cout<<"the user earns " <<earn<< " in a month";

}