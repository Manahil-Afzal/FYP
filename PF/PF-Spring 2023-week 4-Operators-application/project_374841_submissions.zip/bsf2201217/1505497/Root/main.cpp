/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main ()
{
    string name,age;
    int per_day_salary,number_of_days_worked,monthly_salary;
    cout<<"Enter the name of employee: "; 
    cin>>name;
    cout<<"Enter the age of employe: ";
    cin>>age;
    cout<<"Enter the per day scalery: ";
    cin>>per_day_salary;
    cout<<"Enter number of days worked in a month:";
    cin>>number_of_days_worked;
    monthly_salary=per_day_salary*number_of_days_worked;
    cout<<"Monthly salary of employees: "<<monthly_salary;
    
}
