/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string empname;
    int empage,perdaysal,workdays,monthlysal;
    cout<<"enter the name of the employee:";
    cin>>empname;
    cout<<"enter the age of the employee:";
    cin>>empage;
    cout<<"enter perday salary of the employee:";
    cin>>perdaysal;
    cout<<"enter the number of days worked in a month:";
    cin>>workdays;
    monthlysal=perdaysal*workdays;
    cout<<"monthly salary of the employee";
    cin>>monthlysal;
}

