/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include <iostream>
using namespace std;
int main()
{
	string name;
	int age,salary,NOD;
	cout<<"name of empoyee:";
	cin>>name; 
	cout<<"age of employee:";
	cin>>age ;
	cout<<"salary of empoyee:";
	cin>>salary;
	cout<<"no.of days:";
	cin>>NOD;
	cout<<"monthly salary of empoyee:"<<NOD*salary;
	
}