/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    int a,s,w, t;
    string n;
    cout<<"enter the name of employee=";
    cin>>n;
    cout<<"enter the age of employee=";
    cin>>a;
    cout<<"enter the per day salary of employee=";
    cin>>s;
    cout<<"enter the number of days that an employee work=";
    cin>>w;
    t=s*w;
    cout<<"Name of employee ="<<n<<endl;
    cout<<"Age of employee ="<<a<<endl;
    cout<<"Per day salary of employee ="<<s<<endl;
    cout<<"Employee work days ="<<w<<endl;
    cout<<"Monthly salary ="<<t<<endl;
    
    
    
    
}