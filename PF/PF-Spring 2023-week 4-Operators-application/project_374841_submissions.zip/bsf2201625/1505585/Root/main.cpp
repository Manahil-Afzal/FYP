/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    int age,sal,nod, total;
    string name;
    cout<<"enter the name of employee=";
    cin>>name;
    cout<<"enter the age of employee=";
    cin>>age;
    cout<<"enter the per day salary of employee=";
    cin>>sal;
    cout<<"enter the number of days that an employee work=";
    cin>>nod;
    total=sal*nod;
    cout<<"NAME ="<<name<<endl;
    cout<<"AGE ="<<age<<endl;
    cout<<"PER DAY SALARY ="<<sal<<endl;
    cout<<"EMPLOYEE WORK DAYS ="<<nod<<endl;
    cout<<"TOTAL SALARY ="<<total<<endl;
    
    
    
    
}