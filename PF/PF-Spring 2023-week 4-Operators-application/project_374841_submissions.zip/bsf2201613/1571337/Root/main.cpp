/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string name;
    int age, days;
    double perDaySalary;
    cout << "Enter name: ";
    getline(cin, name);
    cout << "Enter age: ";
    cin >> age;
    cout << "Enter per day salary: ";
    cin >> perDaySalary;
    cout << "Enter number of days worked in a month: ";
    cin >> days;
    cout << "\nEmployee profile:\n"
         << "Name: " << name << endl
         << "Age: " << age << endl
         << "Per day salary: " << perDaySalary << endl
         << "Days worked in a month: " << days << endl;

    double monthlySalary = perDaySalary * days;
    cout << "Monthly salary: " << monthlySalary << endl;

    return 0;
}
