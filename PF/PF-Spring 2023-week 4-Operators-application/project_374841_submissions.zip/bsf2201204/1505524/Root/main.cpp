/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    int salaryPerday,Num_work_day,total_salary;
    int age;
    string name;
    cout<<"Enter name\n";
    cin>>name;
    cout<<"Enter age\n";
    cin>>age;
    cout<<"Enter per day salary\n";
    cin>>salaryPerday;
    cout<<"Enter Your Num_day_work\n";
    cin>>Num_work_day;
    total_salary=salaryPerday*Num_work_day;
    cout<<"Name:"<<name<<"\nAge:"<<age<<"\nNum_work_day:"<<Num_work_day<<"\nsalaryPerday:"<<salaryPerday<<"\n";
    cout<<"\n Total Salary"<<total_salary<<"\n";
}