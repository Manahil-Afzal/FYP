/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
	cout<<"Employee Profile Display :"<<endl;
	string  name;
	int  age,salary,workdays;
	cout<<"Enter the names of Employees:"<<endl;
	cin>>name;
	cout<<"Enter the age of Employees:"<<endl;
	cin>>age;
	cout<<"Enter the salary of Employees:"<<endl;
	cin>>salary;
	cout<<"Enter the working days of Employees in a Month:"<<endl;
	cin>>workdays;
	cout<<"Display the data take as input!"<<endl;
	cout<<"Name = "<<name<<endl;
	cout<<"Age = "<<age<<endl;
	cout<<"Per Day Salary = "<<salary<<endl;
	cout<<"Working days in a month = "<<workdays<<endl;
	int monthlysalary;
	monthlysalary = salary*workdays;
	cout<<"The total monthly salary of employee = "<<monthlysalary;
}