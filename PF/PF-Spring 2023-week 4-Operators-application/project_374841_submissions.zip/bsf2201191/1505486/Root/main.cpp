/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee*/
#include <iostream>
using namespace std;
main()
{
    string name;
    int age, salary, working, income, day;
    cout<<"enter the name of employee\n ";
    cin>>name;
    cout<<"enter the age of employee\n "; 
    cin>>age;
    cout<<"enter the per day salary\n ";
    cin>>salary;
    cout<<"enter the working day in month\n ";
    cin>>working;
    income=salary*working;
    cout<<"income salary"<<income<<endl;
}