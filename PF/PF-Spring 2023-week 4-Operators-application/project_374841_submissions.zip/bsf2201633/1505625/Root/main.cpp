#include<iostream>
using namespace std;

main()

{
	string name;
	int age;
	int perdaysalary;
	int noofdays;
	cout<<"Employee name is :";
	cin>>name;
	cout<<"Employee age :";
	cin>>age;
	cout<<"Employee per day salary :";
	cin>>perdaysalary;
	cout<<"Employee no of days worked in a month :";
	cin>>noofdays;
	cout<<"The monthly salary of the Employee :"<<perdaysalary*noofdays;
}