/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main(){
string name;
int age,no_of_days,per_day_sal,mon_sal;
cout<<"Enter the name of employee=";
cin>>name;
cout<<"Enter the age of employee=";
cin>>age;
cout<<"Enter the per day salary of employee=";
cin>>per_day_sal;
cout<<"Enter the no.of days worked in a month =";
cin>>no_of_days;
mon_sal=per_day_sal * no_of_days;
cout<<"name of employee is="<<name<<endl;
cout<<"age of employee is="<<age<<endl;
cout<<"monthly salary of employee is="<<mon_sal<<endl;
return 0;
}