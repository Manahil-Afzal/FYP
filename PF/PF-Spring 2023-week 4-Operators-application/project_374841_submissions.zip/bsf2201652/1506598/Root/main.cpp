/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
 #include<iostream>
 #include<string>
 using namespace std;
 int main()
 {
     string employeename;
     int employeeage,perdaysalary,workingdays,monthlysalary;
     cout<<"enter the name of employee";
     cin>>employeename;
     cout<<"enter the age of employee";
     cin>>employeeage;
     cout<<"enter the per day salary of employee";
     cin>>perdaysalary;
     cout<<"enter the working days of employee";
     cin>>workingdays;
     monthlysalary=perdaysalary*workingdays;
     cout<<"enter the monthly salary";
     cin>>monthlysalary;
      }