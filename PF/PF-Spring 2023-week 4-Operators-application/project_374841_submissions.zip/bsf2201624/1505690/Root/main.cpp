#include<iostream>
using namespace std;
main()
{
  
string name;
int age,p_d_salary,days_worked_in_month;
cout<<"employee profile\n";
cout<<"employee name \n";
cin>>name;
cout<<"age of employee\n";
cin>>age;
cout<<"per day salary\n";
cin>>p_d_salary;
cout<<"no of days worked in month\n";
cin>>days_worked_in_month;
cout<<endl; 

cout<<name<<endl;
cout<<age<<endl;
cout<<p_d_salary<<endl;
cout<<days_worked_in_month<<endl;
cout<<endl;

cout<<p_d_salary*days_worked_in_month<<"="<<"monthly salary";
cout<<endl;


}/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */