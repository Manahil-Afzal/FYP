/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string name,age;
    int perdaysalary,numberofworkingdays, totalsalary;
    cout<<"enter the name\n";
    cin>>name;
    cout<<"enter the age\n";
    cin>>age;
    cout<<"enter the per day salary\n";
    cin>>perdaysalary;
    cout<<"enter the number of working days\n";
    cin>>numberofworkingdays;
    cout<<"\nname:"<<name<<"\n age:"<<age<<"\n numberofworkingdays:"<<numberofworkingdays<<"\n perdaysalary:"<<perdaysalary;
    totalsalary=perdaysalary*numberofworkingdays;
    cout<<"\nmonthly salary "<<totalsalary;
}