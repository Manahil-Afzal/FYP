/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;\
int main()
{
    string name;
    int salaryPerday=0,Num_work_day=0,total_salary=0;
    int age;
    cout<<"\n Enter name ";
    cin>>name;
    cout<<"\n Enter age ";
    cin>>age;
    cout<<"\n Enter per day salary  ";
    cin>>salaryPerday;
    cout<<"\n Enter your Num_work_day ";
    cin>>Num_work_day;
total_salary=salaryPerday*Num_work_day;
cout<<"Name:"<<name<<"\nAge:"<<age<<"\nNum_work_day:"<<Num_work_day<<"\nsalaryPerday:"<<salaryPerday<<"\n";
cout<<"\nTotal_salary:"<<total_salary<<"\n";
}

