/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name,age;
    int monthlysalary, perdaysalary, numberofdaysworkedinmonth;
    cout<<"enter employee name"<<endl;
    cin>>name;
    cout<<"enter emplyee age"<<endl;
    cin>>age;
    cout<<"employee per day salary"<<endl;
    cin>>perdaysalary;
    cout<<"number of days worked in a month"<<endl;
    cin>>numberofdaysworkedinmonth;
    monthlysalary=perdaysalary*numberofdaysworkedinmonth;
    cout<<"name of employee is "<<name<<endl;
    cout<<"age of employee is "<<age<<endl;
    cout<<"employee per day salary is PKR "<<perdaysalary<<endl;
    cout<<"emplooyee working days"<<numberofdaysworkedinmonth<<"working days in a month<<"<<endl;
    cout<<"employee monthly salary is PKR "<<monthlysalary<<endl;
}