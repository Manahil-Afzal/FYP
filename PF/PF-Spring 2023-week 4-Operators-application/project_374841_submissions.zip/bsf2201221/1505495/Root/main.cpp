/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name,age;
    int monthlysalary,perdaysalary,numberofdaysworkedinmonth;
    cout<<" enter employee name "<<endl;
    cin>>name;
    cout<<"enter employee age :"<<endl;
    cin>>age;
    cout<<"enter employee per day salary :"<<endl;
    cin>>perdaysalary;
    cout<<" enter number of days worked in month :"<<endl;
    cin>>numberofdaysworkedinmonth;
    //calculating monthly salary
    monthlysalary=perdaysalary*numberofdaysworkedinmonth;
    cout<<"employee name is :"<<name<<endl;
    cout<<"employee age is :"<<age<<endl;
    cout<<"employee per day salary is PKR  :"<<perdaysalary<<endl;
    cout<<"employee workin g days : "<<numberofdaysworkedinmonth<<"working days in a month is :"<<endl;
    cout<<"employee monthly salary is PKR :"<<monthlysalary<<endl;
    return 0;
}