/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name,age;
    int salary, days, monthlysalary;
    cout<<"enter employee,s name"<<endl;
    cin>>name;
    cout<<"enter employee,s age"<<endl;
    cin>>age;
    cout<<"enter employee,s per day salary"<<endl;
    cin>>salary;
    cout<<"enter the number of days empolyee work in a month"<<endl;
    cin>>days;
   monthlysalary=salary*days;
   cout<<"\n\nemployee name is"<<name<<endl;
   cout<<"employee age is"<<age<<endl;
   cout<<"employee salary per day"<<salary<<endl;
   cout<<"employee  work"<<days<<"days in month."<<endl;
   cout<<"employee monthly salary in PKR"<<monthlysalary;
   
   
    
}