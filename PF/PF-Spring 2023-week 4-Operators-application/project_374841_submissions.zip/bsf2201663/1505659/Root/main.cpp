/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
#include<string>
using namespace std;
int main ()

{
    string  employename;
    int age,sallary,noofdays,totalsallary;
    cout<<"enter the name of employee";
    cin>>employename;
    cout<<"enter the employe age";
    cin>>age;
    cout<<"per day salary";
    cin>>sallary;
    cout<<"no of days";
    cin>>noofdays;
    cout<<"total sallary"<<sallary*noofdays;

    
}