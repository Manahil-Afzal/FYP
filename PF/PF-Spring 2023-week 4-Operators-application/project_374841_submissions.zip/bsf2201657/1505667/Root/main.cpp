/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */

#include<iostream>
#include<string>
using namespace std;
main()
{
    string name;
    int age,salary,days;
    int Total=0;
    cout<<"enter employee name:";
    cin>>name;
    cout<<"enter employee age:";
    cin>>age;
    cout<<"Per day salary:";
    cin>>salary;
    cout<<"Number of days worked in a month:";
    cin>>days;
    Total=salary*days;
    cout<<name<<endl<<age<<endl<<Total;
}