/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name;
int age,salary,workingdays,monthlysalary;
cout<<"Enter the name of employee ";
cin>>name;
cout<<"Enter the age of employee ";
cin>>age;
cout<<"Enter the working days of employee ";
cin>>workingdays;
cout<<"Enter the monthly salary of employee ";
cin>>salary;
monthlysalary=salary*workingdays;
cout<<"monthly salary "<<monthlysalary;

}
