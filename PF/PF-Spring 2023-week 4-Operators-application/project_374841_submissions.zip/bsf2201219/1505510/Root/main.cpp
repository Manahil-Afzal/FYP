/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */

#include<iostream>
using namespace std;
int main(){
    string name,age;
    int salary,days,monthlysalary;
    cout<<"Enter the name of employee: ";
    cin>>name;
    cout<<"Enter the age of employee: ";
    cin>>age;
    cout<<"Enter the per day salary of employee : PKR";
    cin>> salary;
    cout<<"Enter the number of days employee work in a month: ";
    cin>>days;
    monthlysalary=salary*days;
    cout<<"Employee name is "<<name<<endl;
    cout<<"Employee age is "<<age<<endl;
    cout<<"Per day salary of employee is PKR "<<salary<<endl;
    cout<<"Employee work"<<days<<"days in a month"<<endl;
    cout<<"Employee monthlysalary is PKR"<<monthlysalary;
    
}