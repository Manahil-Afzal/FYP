/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
#include<string>
using namespace std;
main()
{
    string name;
    int age;
    int salary;
    int days;
    int Total=0;
    cout<<"Enter your name: ";
    cin>>name;
    cout<<"Enter your age:";
    cin>>age;
    cout<<"enter perday salary:";
    cin>>salary;
    cout<<"days:";
    cin>>days;
    Total=salary*days;
    cout<<name<<endl<<age<<endl<<Total;
    
}