/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string name;
    int age,salary,days;
    
    cout<<"enter name";
    cin>>name;
    cout<<"enter age";
    cin>>age;
    cout<<"enter per day salary";
    cin>>salary;
    cout<<"enter no.of days worked in month";
    cin>>days;
    cout<<endl;
    cout<<"age:"<<age<<endl;
    cout<<"name:"<<name<<endl;
    cout<<"salary:"<<salary<<endl;
    cout<<"days:"<<days<<endl;
    int x=salary*days;
    cout<<"monthlysalary;"<<x;
    
}