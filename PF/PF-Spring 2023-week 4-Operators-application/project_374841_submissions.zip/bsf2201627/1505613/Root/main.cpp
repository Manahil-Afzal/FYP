/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee.*/

#include<iostream>
#include<string>
using namespace std;

int main(){
    string Name;
    int Age,salary,workdays;
    cout<<"Enter your name:";
    cin>>Name;
    cout<<"Enter your age:";
    cin>>Age;
    cout<<"Enter your per day salary:";
    cin>>salary;
    cout<<"Enter number of working days:";
    cin>>workdays;
    cout<<"Display the data taken:"<<endl;
    cout<<"Name="<<Name<<endl;
    cout<<"Age="<<Age<<endl;
    cout<<"Per day salary="<<salary<<endl;
    cout<<"Monthly salary="<<workdays*salary<<endl;
}