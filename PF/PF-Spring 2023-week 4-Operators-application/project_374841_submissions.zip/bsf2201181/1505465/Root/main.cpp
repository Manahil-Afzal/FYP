/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name, age;
    int salary, days, monthlysalary;
    cout<<"Enter Employee's name: ";
    cin>>name;
    cout<<"Enter employee's age: ";
    cin>>age;
    cout<<"Enter employee per day salary: PKR ";
    cin>>salary;
    cout<<"Enter the number of days employye work in a month: ";
    cin>>days;
    monthlysalary = salary*days;
    cout<<"\n\nEmployee name is "<<name<<endl;
    cout<<"Employee age is "<<age<<endl;
    cout<<"Employee per day salary is PKR "<<salary<<endl;
    cout<<"Employee work "<<days<<" days in a month."<<endl;
    cout<<"Employee monthly salary is PKR "<<monthlysalary;
}