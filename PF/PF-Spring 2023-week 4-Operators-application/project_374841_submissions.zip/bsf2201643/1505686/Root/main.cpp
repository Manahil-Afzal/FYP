/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{
    string name;
    int x,y,z;
    cout<<"Enter employee name:";
    cin>>name;
    cout<<"Enter employee age:";
    cin>>x;
    cout<<"Enter per day salary:";
    cin>>y;
    cout<<"Enter number of days worked in a month:";
    cin>>z;
    cout<<"Name:"<<name<<endl<<"age:"<<x<<endl<<"per day salary:"<<y<<endl<<"number of days worked in a month:"<<z<<endl<<"monthly salary of the employee:"<<y*z;
}
