/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
 #include<iostream>
 using namespace std;
 main()
 {
     string name;
     int age, x,y,monthlysal;
     cout<<"enter the name of the employee";
     cin>>name;
     cout<<"enter the age of the employee";
     cin>>age;
     cout<<"enter perday salary otf the employee";
     cin>>x;
     cout<<"enter the number of days worked in a month";
     cin>>y;
     monthlysal=x*y;
     cout<<"monthly salary of the employee"<<monthlysal;
    
 
 }