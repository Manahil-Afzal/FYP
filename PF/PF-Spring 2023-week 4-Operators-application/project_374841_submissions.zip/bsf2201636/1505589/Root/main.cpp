/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
string name;
int age,P_D_salary,N_of_Days_work_in_month,monthly_salary;
cout<<"Enter Employee Name!";
cin>>name;
cout<<"Enter Employee Age!";
cin>>age;
cout<<"Enter Employee P_D_salary!";
cin>>P_D_salary;
cout<<"Enter Number of days Employee work!";
cin>>N_of_Days_work_in_month;
monthly_salary=P_D_salary*N_of_Days_work_in_month;
cout<<"Empolyee Salary Is:"<<monthly_salary;
}