/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string name,age;
    int per_day_salary,number_of_days_worked,monthly_salary;
    cout<<"enter the number of employee:";
    cin>>name;
    cout<<"enter the age of employee:";
    cin>>age;
    cout<<"enter per day salary of employee:";
    cin>>per_day_salary;
    cout<<"enter no of working days:";
    cin>>number_of_days_worked;
    monthly_salary=per_day_salary*number_of_days_worked;
    cout<<"monthly salary of employee"<<monthly_salary;
}