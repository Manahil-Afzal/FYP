/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
main()
{ 
  string name,age;
  int per_day_salary,number_of_working_days,monthly_salary;
    cout<<"enter name\n";
    cin>>name;
    cout<<"enter age\n";
    cin>>age;
    cout<<"enter per day salary\n";
    cin>>per_day_salary;
    cout<<"enter number of days worked in month\n";
    cin>>number_of_working_days;
    cout<<name<<"\n"<<age<<"\n"<<per_day_salary<<"\n"<<number_of_working_days<<"\n";
    monthly_salary=per_day_salary*number_of_working_days;
    cout<<"monthly salary of employees:"<<monthly_salary;
}