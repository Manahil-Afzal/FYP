/*Write a C++ program that takes following information as input for an 
employee’s profile: name, age, per day salary and number of days worked in a month. 
Display the data taken as input and also calculate and display the monthly salary of the employee. */
#include<iostream>
using namespace std;
int main()
{
    string employeename;
    int employeeage,perdaysalary,workdays,monthlysalary;
    cout<<"enter the name of emplyee";
    cin>>employeename;
    cout<<"enter the age of employee";
    cin>>employeeage;
    cout<<"enter the perdaysalary of employee";
    cin>>perdaysalary;
    cout<<"enter the number of days worked in a month";
    cin>>workdays;
    monthlysalary=perdaysalary*workdays;
    cout<<"monthlysalary of employee";
    cin>>monthlysalary;
    
    
}