/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    int length,i;
    int flag=0;
    
    char name[100];
    cout<<"Enter the character=";
    cin>>name;
    length=strlen(name);
    
    for(i=0;i<length;i++)
    
    {
        if(name[i]!=name[length-i-1])
        {
            flag=1;
        }
        
    }
    if(flag==1)
    {
        cout<<"Not palidrome";
    }
    else
    cout<<"Palidrome";
    
}