/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
using namespace std;
main()
{
	
    char i,j;
	char *ptr1,*ptr2;
    char Word[5];
    cout<<"Enter a word of 5 alphabets=";
    cin>>Word;
    for(int i=0;i<5;i++)
    ptr1=&Word[i];
    for(int j=5;j>=0;j--)
    ptr2=&Word[j];
    if(*ptr1==*ptr2)
    cout<<"The word is a palindrome";
    else
    cout<<"The word is not a palindrome";
    
	
}
