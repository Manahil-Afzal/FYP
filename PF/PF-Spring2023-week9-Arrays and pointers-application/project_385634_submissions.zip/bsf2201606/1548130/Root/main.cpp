/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
int main()
{
    string str;
    char  string_arr[15];
    cout<<"Enter the string:";
    cin>>string_arr;
    string string_str;
    string_str=string_arr;
    reverse(string_str.begin(),string_str.end());
    if(string_arr==string_str)
    {
        cout<<"You enter the palindrome:"<<string_arr<<endl;
    }
    else
    {
        cout<<"The word is not a palindrome:"<<string_arr<<endl;
    }
    
    return 0;
}