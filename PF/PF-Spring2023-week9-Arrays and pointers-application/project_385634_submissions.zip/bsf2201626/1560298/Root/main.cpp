#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    const int MAX_SIZE = 100;
    char str[MAX_SIZE];

    cout << "Enter a string: ";
    cin.getline(str, MAX_SIZE);

    int len = strlen(str);
    char *start = str;
    char *end = str + len - 1;
    bool isPalindrome = true;

    while (start < end)
    {
        if (*start != *end)
        {
            isPalindrome = false;
            break;
        }
        start++;
        end--;
    }

    if (isPalindrome)
        cout << str << " is a palindrome." << endl;
    else
        cout << str << " is not a palindrome." << endl;

    return 0;
}
