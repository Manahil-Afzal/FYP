/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <stdio.h>
#include <string.h>

#define MAX_LEN 100

int is_palindrome(char *str);

int main() {
    char str[MAX_LEN];
    printf("Enter a string: ");
    fgets(str, MAX_LEN, stdin);

    if (is_palindrome(str)) {
        printf("The string is a palindrome.\n");
    } else {
        printf("The string is not a palindrome.\n");
    }

    return 0;
}

int is_palindrome(char *str) {
    int len = strlen(str) - 1;
    char *start = str;
    char *end = str + len - 1;

    while (end > start) {
        if (*start != *end) {
            return 0;
        }

        start++;
        end--;
    }

    return 1;
}
