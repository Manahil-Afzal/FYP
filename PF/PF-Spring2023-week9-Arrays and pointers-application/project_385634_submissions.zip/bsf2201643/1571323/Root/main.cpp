    /*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/

#include <iostream>
#include <cstring>
using namespace std;

bool isPalindrome(char* str, int len) {
    
    char* p1 = str;
   
    char* p2 = str + len - 1;
    
    
    while (p1 < p2) {
        if (*p1 != *p2) {
            return false;
        }
      
        p1++;
        p2--;
    }
    
    return true;
}

int main() {
    const int MAXLEN = 100;
    char str[MAXLEN];
    
    cout << "Enter a string: ";
    cin.getline(str, MAXLEN);
    
    int len = strlen(str);
    if (isPalindrome(str, len)) {
        cout << str << " is a palindrome" << endl;
    }
    else {
        cout << str << " is not a palindrome" << endl;
    }
    
    return 0;
}
