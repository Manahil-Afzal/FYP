/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

bool isPalindrome(const char* str) {
    int length = strlen(str);
    const char* start = str;
    const char* end = str + length - 1;

    while (start < end) {
        if (*start != *end) {
            return false;
        }

        start++;
        end--;
    }

    return true;
}

int main() {
    const int maxInputLength = 100;
    char input[maxInputLength];

    std::cout << "Enter a string: ";
    std::cin.getline(input, maxInputLength);

    if (isPalindrome(input)) {
        std::cout << "The input is a palindrome." << std::endl;
    } else {
        std::cout << "The input is not a palindrome." << std::endl;
    }

    return 0;
}