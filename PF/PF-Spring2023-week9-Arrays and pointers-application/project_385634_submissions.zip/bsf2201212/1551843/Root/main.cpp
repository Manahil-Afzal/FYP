/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main() {
    const int MAX_SIZE = 100;
    char input[MAX_SIZE];
    cout << "Enter a string: ";
    cin.getline(input, MAX_SIZE);

    char* start = input; // Pointer to start of input
    char* end = input + strlen(input) - 1; // Pointer to end of input

    bool isPalindrome = true;
    while (end > start) {
        if (*start != *end) {
            isPalindrome = false;
            break;
        }
        start++;
        end--;
    }

    if (isPalindrome) {
        cout << "The input is a palindrome." << endl;
    } else {
        cout << "The input is not a palindrome." << endl;
    }

    return 0;
}