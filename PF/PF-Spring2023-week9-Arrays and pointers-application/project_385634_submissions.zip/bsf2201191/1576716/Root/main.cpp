/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>
using namespace std;
bool is_palindrome(char *str);
int main()
{
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    if (is_palindrome(str))
    {
        cout << str << " is a palindrome.\n";
    }
    else
    {
        cout << str << " is not a palindrome.\n";
    }
    return 0;
}
bool is_palindrome(char *str)
{
    int len = strlen(str);
    char *ptr1 = str;
    char *ptr2 = str + len - 1;
    while (ptr2 > ptr1)
    {
        if (*ptr1 != *ptr2)
        {
            return false;
        }
        ptr1++;
        ptr2--;
    }
    return true;
}
