/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    char* start = str;
    char* end = str + strlen(str) - 1;
    bool palindrome = true;

    while (start < end)
    {
        if (*start != *end)
        {
            palindrome = false;
            break;
        }
        start++;
        end--;
    }

    if (palindrome)
    {
        cout << "The string is a palindrome." << endl;
    }
    else
    {
        cout << "The string is not a palindrome." << endl;
    }

}
