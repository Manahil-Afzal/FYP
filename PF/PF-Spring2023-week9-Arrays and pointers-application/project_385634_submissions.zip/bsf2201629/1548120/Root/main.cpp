
#include <iostream>
#include <cstring>

using namespace std;

int main() {
    char str[100];
    bool isPalindrome = true;
    
    cout << "Enter a string: ";
    cin.getline(str, 100);
    
    int len = strlen(str);
    char *ptr1 = str;
    char *ptr2 = str + len - 1;
    
    while(ptr2 > ptr1) {
        if(*ptr1 != *ptr2) {
            isPalindrome = false;
            break;
        }
        ptr1++;
        ptr2--;
    }
    
    if(isPalindrome) {
        cout << "The input string is a palindrome." << endl;
    } else {
        cout << "The input string is not a palindrome." << endl;
    }
    
    return 0;
}
