/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100); // read input string

    char *begin = str; // pointer to the beginning of the string
    char *end = str + strlen(str) - 1; // pointer to the end of the string

    bool isPalindrome = true;
    while (begin < end) {
        if (*begin != *end) {
            isPalindrome = false;
            break;
        }
        begin++;
        end--;
    }

    if (isPalindrome) {
        cout << str << " is a palindrome" << endl;
    } else {
        cout << str << " is not a palindrome" << endl;
    }

    return 0;
}