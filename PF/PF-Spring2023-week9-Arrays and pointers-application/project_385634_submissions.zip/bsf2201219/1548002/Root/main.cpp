/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/

#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    char *begin_ptr = str;
    char *end_ptr = str + strlen(str) - 1;
    bool palindrome = true;

    while (begin_ptr < end_ptr) {
        if (*begin_ptr != *end_ptr) {
            palindrome = false;
            break;
        }
        begin_ptr++;
        end_ptr--;
    }

    if (palindrome)
        cout << "The input represents a palindrome." << endl;
    else
        cout << "The input does not represent a palindrome." << endl;

    return 0;
}