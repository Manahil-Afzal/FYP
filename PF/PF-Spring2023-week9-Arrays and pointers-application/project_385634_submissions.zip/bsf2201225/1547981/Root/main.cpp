/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main() {
    const int MAX_LEN = 100;
    char input[MAX_LEN];
    bool isPalindrome = true;

    // Read input from user
    cout << "Enter a string: ";
    cin.getline(input, MAX_LEN);

    // Use pointers to check if input is palindrome
    int len = strlen(input);
    char *p1 = input, *p2 = input + len - 1;
    while (p1 < p2) {
        if (*p1 != *p2) {
            isPalindrome = false;
            break;
        }
        ++p1;
        --p2;
    }

    // Display appropriate message
    if (isPalindrome) {
        cout << "The input represents a palindrome" << endl;
    } else {
        cout << "The input does not represent a palindrome" << endl;
    }

    return 0;
}
