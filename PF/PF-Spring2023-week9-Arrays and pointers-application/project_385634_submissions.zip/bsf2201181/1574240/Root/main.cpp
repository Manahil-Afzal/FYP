/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>
using namespace std;
int main(){
    char string[20];
    int length;
    int flag = 0;
    cout << "Enter a string: "; 
	cin >> string;
    length = strlen(string);
    for(int i=0; i<length ; i++)
	{
        if(string[i] != string[length-i-1])
		{
            flag = 1;
            break;
        }
    }
    if (flag) 
        cout << string << " is not a palindrome"<<endl; 
    else 
        cout << string<< " is a palindrome"<<endl; 
    return 0;
}