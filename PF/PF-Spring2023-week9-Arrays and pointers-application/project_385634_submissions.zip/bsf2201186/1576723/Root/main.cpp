#include <iostream>
#include <cstring>
using namespace std;
bool isPalindrome(const char* str) {
 int len = strlen(str);
 const char* start = str;
 const char* end = str + len - 1;
 while (start < end) {
 if (*start != *end) {
 return false;
 }
 ++start;
 --end;
 }
 return true;
}
int main() {
 const int MAX_SIZE = 100;
 char input[MAX_SIZE];
 cout << "Enter a string: ";
 cin.getline(input, MAX_SIZE);
 if (isPalindrome(input)) {
 cout << "The input represents a palindrome." << endl;
 } else {
 cout << "The input does not represent a palindrome." << endl;
 }
 return 0;
}
