/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
#include<cstring>
int main()
{
    char array[20];
    
    cout<<"\n Enter Array: ";
    cin>>array;
    
    // cout<<"\n Array:  "<<array;
    
    int n = strlen(array);
    bool flag =true;
    for(int i=0;i<n;i++){
        if(array[i]!=array[n-1]){
            flag = false;
            break;
        }
        n=n-1;
    }
    
    if(flag==true){
        cout<<"\n Array is palindrome: ";
    }
    else{
         cout<<"\n Array NOT is palindrome: ";
    }
    
}
