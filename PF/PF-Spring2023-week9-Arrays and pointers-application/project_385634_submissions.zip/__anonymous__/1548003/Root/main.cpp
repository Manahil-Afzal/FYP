/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
# include <iostream>
using namespace std;
main(){
char arr[5],*a;
int b=0;
cout<<"enter the palindoram";
cin>>arr;
a=arr;
int k=0;
while(arr[k]!='\0'){
    cout<<arr[k];
    k++;
}
for(int i=k;i>=0;i--){
    if(arr[i]==*a){
        b=1;
        a++;
        break;
    }else 
    a++;
    b=0;
}
if(b!=1){
    cout<<"its palindroam"<<endl;
}else 
cout<<"not a palindroam"<<endl;
}
