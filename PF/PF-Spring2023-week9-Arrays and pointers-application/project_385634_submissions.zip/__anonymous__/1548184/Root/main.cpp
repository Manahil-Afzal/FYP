/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/#include <iostream>
#include <cstring>

using namespace std;

bool isPalindrome(char* str);

int main()
{
    char str[100];

    cout << "Enter a string: ";
    cin >> str;

    if (isPalindrome(str)) {
        cout << "The string is a palindrome." << endl;
    } else {
        cout << "The string is not a palindrome." << endl;
    }

    return 0;
}

bool isPalindrome(char* str)
{
    int len = strlen(str);
    char* start = str;
    char* end = str + len - 1;

    while (end > start) {
        if (*start != *end) {
            return false;
        }

        start++;
        end--;
    }

    return true;
}