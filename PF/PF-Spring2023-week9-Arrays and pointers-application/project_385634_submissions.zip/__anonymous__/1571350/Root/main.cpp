/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/

#include <iostream>
#include <cstring> // for strlen() function
using namespace std;

bool isPalindrome(char* str, int len);

int main()
{
    const int MAX_LENGTH = 100;
    char str[MAX_LENGTH];

    cout << "Enter a string: ";
    cin.getline(str, MAX_LENGTH);

    int len = strlen(str);

    if (isPalindrome(str, len)) {
        cout << "The input is a palindrome.\n";
    } else {
        cout << "The input is not a palindrome.\n";
    }

    return 0;
}

bool isPalindrome(char* str, int len)
{
    char* p1 = str;
    char* p2 = str + len - 1;

    while (p1 < p2) {
        if (*p1 != *p2) {
            return false;
        }
        p1++;
        p2--;
    }

    return true;
}
