/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char str[100];
    cout << "Enter a string: ";
    cin >> str;

    int len = strlen(str);
    char *front_ptr = str;
    char *back_ptr = str + len - 1;
    bool is_palindrome = true;

    while (back_ptr > front_ptr)
    {
        if (*front_ptr != *back_ptr)
        {
            is_palindrome = false;
            break;
        }
        front_ptr++;
        back_ptr--;
    }

    if (is_palindrome)
    {
        cout << str << " is a palindrome." << endl;
    }
    else
    {
        cout << str << " is not a palindrome." << endl;
    }

    return 0;
}