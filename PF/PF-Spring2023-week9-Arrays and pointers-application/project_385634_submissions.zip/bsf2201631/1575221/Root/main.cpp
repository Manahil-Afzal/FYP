/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>
using namespace std;
bool ispaildrome(char* str){
  int lenght=strlen(str);
  for(int i=0;i<lenght/2;i++){
    if(str[i]!=str[lenght-i-1]){
      return false;
    }
  }
  return true;
}
int main(){
  int maxsize=100;
  char input[maxsize];
  cout<<"enter the string"<<endl;
  cin>>input;
  if(ispaildrome(input)){
    cout<<"the no is paildrome"<<endl;
  }else{
    cout<<"the no is paildrome"<<endl;
  }
  return 0;
}
