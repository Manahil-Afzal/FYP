/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main() {
    const int MAX_LENGTH = 100; // maximum length of input string
    char input[MAX_LENGTH]; // array of characters to store input
    cout << "Enter a string: ";
    cin.getline(input, MAX_LENGTH); // read input string

    // check if input is a palindrome
    char *start = input;
    char *end = input + strlen(input) - 1;
    bool isPalindrome = true;
    while (start < end) {
        if (*start != *end) {
            isPalindrome = false;
            break;
        }
        start++;
        end--;
    }

    // display appropriate message
    if (isPalindrome) {
        cout << "The input string is a palindrome.\n";
    } else {
        cout << "The input string is not a palindrome.\n";
    }
    return 0;
}
