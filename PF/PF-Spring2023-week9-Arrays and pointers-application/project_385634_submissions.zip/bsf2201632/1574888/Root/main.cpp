/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
 using namespace std;
 int main() 
{   char str[30],res [30];
 char *ptr,*t; 
cout<<"Enter any string:"<<endl; 
cin>>str; 
cout<<"Enter reverse of string:"<<endl;
 cin>>res ; 
 ptr=str;
  t=res;
   if(*ptr==*t) 
     cout<<"This string is a palindrome"; else 
     cout<<"This string is not palindrome"; return 0; 
} 