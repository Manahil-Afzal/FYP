/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    // Pointers to the first and last characters of the string
    char* ptr1 = str;
    char* ptr2 = str + strlen(str) - 1;

    bool isPalindrome = true;

    // Iterate through the string using the pointers
    while(ptr1 < ptr2)
    {
        if(*ptr1 != *ptr2)
        {
            isPalindrome = false;
            break;
        }
        ptr1++;
        ptr2--;
    }

    if(isPalindrome)
        cout << "The string is a palindrome.";
    else
        cout << "The string is not a palindrome.";

    return 0;
}