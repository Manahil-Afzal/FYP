/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

bool isPalindrome(char* str);

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin >> str;

    if (isPalindrome(str)) {
        cout << str << " is a palindrome." << endl;
    } else {
        cout << str << " is not a palindrome." << endl;
    }

    return 0;
}

bool isPalindrome(char* str) {
    int len = strlen(str);
    char* front = str;
    char* back = str + len - 1;

    while (back > front) {
        if (*front != *back) {
            return false;
        }
        front++;
        back--;
    }

    return true;
}
