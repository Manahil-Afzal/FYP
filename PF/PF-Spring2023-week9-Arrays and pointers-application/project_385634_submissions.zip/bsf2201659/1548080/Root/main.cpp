/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

int main() {
    const int MAX_LEN = 100;
    char input[MAX_LEN];

    // take input from the user
    cout << "Enter a string: ";
    cin.getline(input, MAX_LEN);

    // check if the input represents a palindrome
    char* start = input;
    char* end = input + strlen(input) - 1;
    bool isPalindrome = true;
    while (start < end) {
        if (*start != *end) {
            isPalindrome = false;
            break;
        }
        start++;
        end--;
    }

    // display appropriate messages
    if (isPalindrome) {
        cout << "The input represents a palindrome." << endl;
    } else {
        cout << "The input does not represent a palindrome." << endl;
    }

    return 0;
}
