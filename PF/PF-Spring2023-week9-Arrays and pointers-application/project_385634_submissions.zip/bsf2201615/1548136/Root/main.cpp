/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>

using namespace std;

bool isPalindrome(char *str) {
    int len = strlen(str);
    char *start = str;
    char *end = str + len - 1;
    
    while(start < end) {
        if(*start != *end) {
            return false;
        }
        start++;
        end--;
    }
    
    return true;
}

int main() {
    const int MAX_LEN = 100;
    char input[MAX_LEN];
    
    cout << "Enter a string: ";
    cin.getline(input, MAX_LEN);
    
    if(isPalindrome(input)) {
        cout << "The input is a palindrome." << endl;
    }
    else {
        cout << "The input is not a palindrome." << endl;
    }
    
    return 0;
}