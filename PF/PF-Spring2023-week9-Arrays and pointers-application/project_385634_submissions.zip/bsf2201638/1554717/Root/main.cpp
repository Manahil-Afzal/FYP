/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
#include<cstring>
using namespace std;
 main()
 {
 	char   name[100];
 	int   lenght,i;
 	int   flag = 0;
 	 cout<<"Enter the Character "<<endl;
 	 cin>>name;
 	 
 	 lenght = strlen(name);
 	 
 	 for(int i=0;i<lenght;i++)
 	 {
 	 	if(name[i] != name[lenght-i-1])
 	 	{
 	 		flag = 1;
		  }
	  }
	  if(flag==1)
	  {
	  	cout<<name<<"is not palindrome"<<endl;
	  }
	  else
	  cout<<name<<"is Palindrome"<<endl;
 }