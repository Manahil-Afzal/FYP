/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( int i = 1;i<=n; i++) /*missing data type of "i" in declaration and used  comma instead of semi colon*/ 
	{
        sum += i;
        
}   
   cout << "Sum = " << sum; /*this statement was used inside the loop body which leads to logical error*/
    return 0;}