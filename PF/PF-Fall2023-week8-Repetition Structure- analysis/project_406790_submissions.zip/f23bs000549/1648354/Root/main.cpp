/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        sum += i;
    } // corrected the for loop structure and added curly braces for the loop body

    cout << "Sum = " << sum;

    return 0;
} // corrected the placement of the return statement, closing the main function, and added comments for clarity
