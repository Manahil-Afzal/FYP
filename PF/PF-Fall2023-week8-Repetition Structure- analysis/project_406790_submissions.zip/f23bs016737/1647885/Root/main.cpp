/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++)//i is not declared and use ; instead of ,
    {
        sum += i;
    }
    cout << "Sum = " << sum;
  
    //closed the braces of for loop
    return 0;
}