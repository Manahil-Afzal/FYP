/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;
int main()
{
    int n,i,sum = 0;                         //Initialization missing
    cout<<"Enter a positive integer:";  
    cin>>n;
    for(i=1;i<=n;++i)                       //Statement tereminator missing  //Wrong operator
{  
    sum+=i;                                 //Delimeter missing
}
    cout << "Sum = " << sum;
    return 0;
}