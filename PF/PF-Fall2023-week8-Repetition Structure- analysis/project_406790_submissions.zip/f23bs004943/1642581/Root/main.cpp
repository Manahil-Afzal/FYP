/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n,i,sum = 0;                //i is not declared

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( i = 1; i <= n; ++i) {         //wrong unary operator  //semicolon missing
        sum += i;
    }                           //missing delimeter
    cout << "Sum = " << sum;
    return 0;
}