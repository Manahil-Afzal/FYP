/* This program demonstrates sum of natural numbers. Identify and correct errors.*/
/*errros:
There is no int before i
There are commas instead of semicolouns
There is a curly bracket after for loop
The increment was done wrong,i++ or i=i+1 shall be used
*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for ( int i = 1; i <= n; i++) 
        sum += i;
    
    cout << "Sum = " << sum;
    return 0;
}