/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {  //i is not delared. I fix it
        sum += i;
    }
    cout << "Sum = " << sum; //Move the print statement out side the loop
    return 0; //Correct place for return statem
}

