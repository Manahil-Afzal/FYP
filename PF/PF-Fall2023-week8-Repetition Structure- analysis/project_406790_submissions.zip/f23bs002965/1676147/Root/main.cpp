/* This program demonstrates sum of natural numbers. Identify and correct errors.*/

#include <iostream>
using namespace std;

int main()
{
    int n, sum = 0;

    cout << "Enter a positive integer: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {//use semicolon to separate them instead of comas.
        sum += i;
}
cout << "Sum = " << sum;//put the return and cout out of the loop.
return 0;
}