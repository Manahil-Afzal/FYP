//This prrogram is meant to take two characters as inputs from user and display those characters.

#include<iostream>

using namespace std;

int main()
{
    char c;
    char x;
    cout << "enter first character";
    cin>>c;
    cout<< "enter second character";
    cin>>x;
    cout<<"following characters are entered = "<<c<<x;
    
}
