//This prrogram is meant to take two characters as inputs from user and display those charters.

#include <iostream>

using namespace std;

int main()
{
    char c=0;
    char a=0;
    cout << "Enter first character! ";
    cin>>c;
    cout << "Enter second character! ";
    cin>>a;
    cout<<"Following characters are enteres "<<c<<" & "<<a;
    
}
