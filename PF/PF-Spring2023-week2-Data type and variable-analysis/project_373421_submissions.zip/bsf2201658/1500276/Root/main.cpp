//This prrogram is meant to take two characters as inputs from user and display those characters.

#include<iostream>

using namespace std;

int main()
{
    char c='b'; //single qoute is used in character data type not dual qoutes 
    char a='x'; //single qoute is not used 
    cout<< "enter first character!";
    cin>>c;
    cout<< "enter second character!";
    cin>>a;//insertion operator
    cout<<"following characters are enteres="<<c<<a;//exreaction operator not used for sepration of ca
    
}
