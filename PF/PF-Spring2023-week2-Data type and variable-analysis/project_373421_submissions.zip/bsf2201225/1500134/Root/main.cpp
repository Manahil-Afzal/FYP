//This prrogram is meant to take two characters as inputs from user and display those charters.

#include <iostream>

using namespace std;

int main()
{
    char c,a;
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;
    cout<<"following characters are enteres="<<c<<"\t"<<a;
    return 0;
    
}
