//This prrogram is meant to take two characters as inputs from user and display those characters.

#include<iostream>//there was a space here
using namespace std;
 main()
{
    char c;
    char a;
    //values of c and a are given below
    cout << "enter first character=";
    cin>>c;
    cout << "enter second character=";
    cin>>a;//insertion operator werw wrong
    cout<<"following characters are entered:"<<c<<"\n";// c and a should've been seprated
     cout<<"following characters are entered:"<<a;
    
    
}
