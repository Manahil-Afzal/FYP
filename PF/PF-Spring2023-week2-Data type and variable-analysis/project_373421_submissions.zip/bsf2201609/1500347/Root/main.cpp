//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    char c='b';   //single quotation
    char a='x';   //single quotation
    cout << "enter first character!";  
    cin>>c;       
    cout << "enter second character!";
    cin>>a;       //extraction operator
    cout<<"following characters are enteres :a"<<c<<a;
    
}
