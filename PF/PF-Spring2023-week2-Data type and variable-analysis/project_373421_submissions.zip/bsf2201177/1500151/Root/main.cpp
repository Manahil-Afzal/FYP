//This prrogram is meant to take two characters as inputs from user and display those charters.

#include<iostream>

using namespace std;

int main()
{
    int a;
    int b;
    cout<<"enter the first value a";
    cin>>a;
    
     cout<<"enter the first value b";
    cin>>b;
    cout<<"the subtraction is: " <<b-a;
    
}
