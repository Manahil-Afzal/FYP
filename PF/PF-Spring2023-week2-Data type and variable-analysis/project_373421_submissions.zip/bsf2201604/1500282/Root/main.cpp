//This prrogram is meant to take two characters as inputs from user and display those characters.

#include<iostream> //There was a space here

using namespace std;

main() //There was a int function here
{
    char c;
    char a;
    // values of c and a are given below
    cout <<"enter first character!";
    cin>>c;
    cout <<"enter second character!";
    cin>>a;
    cout<<"following characters are enteres:"<<c<<a; // c and a should've been seprated
    
}
