//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    char c,a;
    cout<<"Enter first character";
    cin>>c;
    cout <<"Enter second character";
    cin>>a;
    cout<<"following characters are entered!"<<c<<a;

}
