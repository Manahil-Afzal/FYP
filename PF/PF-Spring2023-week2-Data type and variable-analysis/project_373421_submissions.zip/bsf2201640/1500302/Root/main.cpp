//This prrogram is meant to take two characters as inputs from user and display those characters.

#include<iostream>//there was a space here
using namespace std;
 main()//there was a int function here
{
    char c;
    char a;
    //values of c and a are given below
    cout << "enter first character";
    cin>>c;
    cout << "enter second character";
    cin>>a;//insection operator werw wrong
    cout<<"following characters are entered:"<<c<<a;// c and a should have beeen seperated
    
}
