//This prrogram is meant to take two characters as inputs from user and display those characters.

#include<iostream>

using namespace std;

main()
{
    char c;
    char a;
    // values of c and a are given below
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;
    cout<<"following characters are enteres"<<c<<a; // c and a should've been separated 
    
}
