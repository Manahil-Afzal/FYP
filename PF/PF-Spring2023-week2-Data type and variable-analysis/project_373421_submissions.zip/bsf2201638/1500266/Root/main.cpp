//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    char c='b';         // Including Apostrophies
    char a='x';         // Including Apostrophies
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;             // ADD Extraction instead of Insertion
    cout<<"following characters are enteres"<<endl<<c<<endl<<a<<endl;
    
}
