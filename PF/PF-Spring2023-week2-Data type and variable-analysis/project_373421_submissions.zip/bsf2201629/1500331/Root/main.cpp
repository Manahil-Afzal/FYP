//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

 main()
{
    char c='b';               //include single qout
    char a='x';               //include single qout
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;
    cout<<"following characters are enteres"<<c<<a;       //seprate the variables
    
    
}
