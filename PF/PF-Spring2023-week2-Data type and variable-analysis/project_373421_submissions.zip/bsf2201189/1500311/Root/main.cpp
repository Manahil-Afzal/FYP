//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    
    char c='b';
    char a='x';
    cout<<"enter first character!";
    cin>>c;
    cout<<"enter second character!";
    cin>>a;
    cout<<"following characters are enteres"<<c<<a;
    
}
