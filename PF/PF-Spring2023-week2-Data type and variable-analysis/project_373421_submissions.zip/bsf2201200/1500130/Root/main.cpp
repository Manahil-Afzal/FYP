// program to subtract two numbers 
#include <iostream>

using namespace std;
int main()
{
   //program for substraction
    int a =0;
    int b =0;
    int sub=0;
    
    cout<<"enter the first value of a ";
    cin>>a;
    cout<<"\nenter the first value of b ";
    cin>>b;
    cout<<"\nthe value after subtraction is :"<<a-b;
}