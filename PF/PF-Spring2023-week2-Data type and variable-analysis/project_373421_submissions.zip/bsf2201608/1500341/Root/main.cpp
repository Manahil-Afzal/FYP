//This prrogram is meant to take two characters as inputs from user and display those charters.

#include<iostream>

using namespace std;

int main()
{
    char c='b';                //single Quotes are use
    char a='x';
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;                   //extraction operator is used
    cout<<"following characters are enteres" <<c <<a;   //seprate extraction is used for both character
    
}
