//This prrogram is meant to take two characters as inputs from user and display those characters.
#include <iostream>
using namespace std;
main()
{
    char c='b';//single qoute
    char a='x';//single qoute
    cout<<"enter first character!";
    cin>>c;
    cout<<"enter second character!";
    cin>>a;//extraction operator
    cout<<"following characters are enteres "<<c<<a;//insertion operator
    
}
