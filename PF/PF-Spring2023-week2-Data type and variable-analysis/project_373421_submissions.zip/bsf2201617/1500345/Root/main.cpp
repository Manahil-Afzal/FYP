//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>
using namespace std;
 main()
{
    char c;
    char b;
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>b;
    cout<<"display the following chracters"<<c<<b;
    
}
