//This prrogram is meant to take two characters as inputs from user and display those character
#include <iostream>
using namespace std;
int main()
{
    char c='b';// replace double quote with single quotes
    char a='x';// insert single quotes
    cout << "enter first character=";
    cin>>c;
    cout << "enter second character=";
    cin>>a;//REPLACE WITH 2 GREATER THAN SIGNS 
    cout<<"following characters are enteres:"<<c<<a;// insert 2 less than signs before a 
}