//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    char c, a; //intiallizing all virable in one line
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a; //replace insertion operator with extraction operator
    cout<<"following characters are enteres "<<c <<" and " << a; //write an ather insertion operator for writing and
}
