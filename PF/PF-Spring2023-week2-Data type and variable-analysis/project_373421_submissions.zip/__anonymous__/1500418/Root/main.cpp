//This prrogram is meant to take two characters as inputs from user and display those charters.

#include <iostream>

using namespace std;

int main()
{
    char c='b'; //charachter should be in single quotes
    char a='x';
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a; // >> are used with cin
    cout<<"following characters are enteres"<<c<<a; // every variable must be saperated by <<
    
}
