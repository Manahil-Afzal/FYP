//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    //character is in single quot
    //char c='b';
    //must use the singl quot against the character
    //char a='x';
    //cout << "enter first character!";
    //cin>>c;
    //cout << "enter second character!";
    //cin<<a;
    //cout<<"following characters are enteres"<<ca;
    //Right Program
    char x,y;
    cout<<"Enter the first character";
    cin>>x;
    cout<<"Enter the second character";
    cin>>y;
    cout<<"The First Character is="<<x;
    
    cout<<"\nThe Second character is="<<y;
    
}
