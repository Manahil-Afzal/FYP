//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    char c='b';//double quotes were used
    char a='x';//single quotes were absent
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a;//<< these were used
    cout<<"following characters are enteres:"<<c<<a;
    
}
