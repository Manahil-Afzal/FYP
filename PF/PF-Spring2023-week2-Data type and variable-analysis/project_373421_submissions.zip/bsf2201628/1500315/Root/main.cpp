//This prrogram is meant to take two characters as inputs from user and display those characters.

#include <iostream>

using namespace std;

int main()
{
    char c='b'; // use single quate
    char a='x';  // use single quate
    cout << "enter first character!";
    cin>>c;
    cout << "enter second character!";
    cin>>a; //extraction operation >>
    cout<<"following characters are enteres"<<a; 
}
