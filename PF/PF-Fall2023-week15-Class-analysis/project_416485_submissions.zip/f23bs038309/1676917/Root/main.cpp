/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;

class Book {
public:
    string title;
    float price;

    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter information for book1:\n";
    book1.getData();

    cout << "\nEnter information for book2:\n";
    book2.getData();

    cout << "\nEnter information for book3:\n";
    book3.getData();

    cout << "\nDetails of book1:\n";
    book1.putData();

    cout << "\nDetails of book2:\n";
    book2.putData();

    cout << "\nDetails of book3:\n";
    book3.putData();

    return 0;
}

