/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;

// Class definition for Book
class Book {
private:
    string title;
    float price;

public:
    // Function to get data from the user
    void getData();

    // Function to display data
    void putData();
};

// Implementation of getData function
void Book::getData() {
    cout << "Enter the title: ";
    cin >> title;
    cout << "Enter the price: ";
    cin >> price;
}

// Implementation of putData function
void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

// Main function
int main() {
    // Create three Book objects
    Book book1, book2, book3;

    // Prompt the user to enter details for each book
    cout << "Enter details for book 1:\n";
    book1.getData();

    cout << "Enter details for book 2:\n";
    book2.getData();

    cout << "Enter details for book 3:\n";
    book3.getData();

    // Display details of each book
    cout << "\nDetails of books:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}

