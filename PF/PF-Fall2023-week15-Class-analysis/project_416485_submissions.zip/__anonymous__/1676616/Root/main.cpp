/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;

// Define the Book class
class Book {
private:
    string title;
    float price;

public:
    // Member functions to get and put book data
    void getData();
    void putData();
};

// Implementation of getData function to input book details
void Book::getData() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

// Implementation of putData function to display book details
void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    // Create instances of the Book class for three books
    Book book1, book2, book3;

    // Prompt the user to enter details for each book
    cout << "Enter details for book 1:\n";
    book1.getData();

    cout << "Enter details for book 2:\n";
    book2.getData();

    cout << "Enter details for book 3:\n";
    book3.getData();

    // Display details of all three books
    cout << "\nDetails of books:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
