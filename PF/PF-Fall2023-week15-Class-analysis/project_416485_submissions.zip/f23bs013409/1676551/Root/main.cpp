/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>

using namespace std;

class book
{
private: // Added access specifier to make data members private
    string title;
    float price;

public:
    // Removed the extra declaration of getdata
    void getdata();
    void putdata();
};

// Corrected function definitions with the class scope resolution operator ::
void book::getdata()
{
    cout << "Title:";
    cin >> title;
    cout << "Price:";
    cin >> price;
}

void book::putdata()
{
    cout << "Title:" << title << "\n";
    cout << "Price:" << price << "\n";
}

int main()
{
    // Corrected the object declarations
    book book1, book2, book3;
    
    book1.getdata();
    book2.getdata();
    book3.getdata();

    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}