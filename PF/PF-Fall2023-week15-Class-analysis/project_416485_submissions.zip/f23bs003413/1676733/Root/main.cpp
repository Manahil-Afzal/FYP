/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include<string>
using namespace std;

class book
{
 public:
string title;
float price ;

void getdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
 
}
void putdata ()
{
	cout<<"selected books are : "<<endl;
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
} ;
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata();
book2.putdata();
book3.putdata();

return 0;
}