// /* This program implements a class of Book and displays the data of three books entered by user.
// identify and correct errors*/

// #include <iostream>

// using namespace std;

// class book
// {
// string title;
// float price ;
// void getdata ();
// public:
// void getdata ();
// void putdata ();
// } ;
// void books : getdata ()
// {
// cout<<"Title:”;
// cin>>title;
// cout<<"Price:”;
// cin>>price;
 
// }
// void books : putdata ()
// {
// cout<<"Title:"<<title<< "\n";
// cout<<"Price:"<<price<< "\n”;
// int main ()
// {
// books book1, book2, book3;
// book1.getdata();
// book2.getdata();
// book3.getdata();
// book1.putdata() ;
// book2.putdata() ;
// book3.putdata() ;

// return 0;
// }
#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore(); // To consume the newline character left in the buffer
    getline(cin, title);

    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "\nTitle: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter data for book 1:\n";
    book1.getData();

    cout << "\nEnter data for book 2:\n";
    book2.getData();

    cout << "\nEnter data for book 3:\n";
    book3.getData();

    cout << "\nDetails of books entered:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
