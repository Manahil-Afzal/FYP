#include <iostream>
using namespace std;

class Book {
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Enter Title: ";
    cin.ignore(); // Clear input buffer
    getline(cin, title); // Allowing input with spaces
    cout << "Enter Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "Displaying Book Details:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
