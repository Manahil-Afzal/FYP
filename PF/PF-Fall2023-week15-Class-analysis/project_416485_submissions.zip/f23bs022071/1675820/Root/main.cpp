/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
    public : //public should be used above all the data types to use data publically
string title;
float price ;
void getdata ();

void putdata ();
} ;
void book :: getdata () //double colon should be used //data type corrected
{
cout<<"Title :"; //double comma added
cin>>title;
cout<<"Price:" ;//double comma added
cin>>price;
 
}
void book :: putdata () //double colon should be used //data type corrected
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";} //double comma added
int main ()
{
book book1, book2, book3; //data type corrected
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
