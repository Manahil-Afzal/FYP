/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore(); // Ignore any leftover newline characters
    getline(cin, title); // Use getline() to read the entire title including spaces
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter data for Book 1:\n";
    book1.getData();

    cout << "\nEnter data for Book 2:\n";
    book2.getData();

    cout << "\nEnter data for Book 3:\n";
    book3.getData();

    cout << "\nBook 1 Details:\n";
    book1.putData();

    cout << "\nBook 2 Details:\n";
    book2.putData();

    cout << "\nBook 3 Details:\n";
    book3.putData();

    return 0;
}