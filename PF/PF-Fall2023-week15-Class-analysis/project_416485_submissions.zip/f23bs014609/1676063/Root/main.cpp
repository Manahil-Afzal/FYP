/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
string title;
float price ;

public:
// void getdata ();  same function was used twice which leads to function overloading
void putdata ();
void getdata ();  // this was used before specifying access specifier so default (private) specifier was implemented
} ;
void book :: getdata ()  //colon (:) wasa used instead of scope resolution operator(::) and class name was written wrong
{ 
cout<<"Title:"; //missing terminating " character
cin>>title; 
cout<<"Price:"; //missing terminating " character
cin>>price;
 
}
void book :: putdata ()  //colon (:) wasa used instead of scope resolution operator(::) and class name was written wrong
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";  //missing terminating " character
} //missing closing braces of function
int main()
{
book book1, book2, book3; //class name was written wrong
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}