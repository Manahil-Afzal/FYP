/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class book {
public:
    string title;
    float price;

    void getdata();
    void putdata();
};

void book::getdata() {
    cout << "Title: ";
    cin.ignore(); // Clear newline character from buffer
    getline(cin, title); // Read the whole line for the title
    cout << "Price: ";
    cin >> price;
}

void book::putdata() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    book book1, book2, book3;

    cout << "Enter data for book 1" << endl;
    book1.getdata();

    cout << "\nEnter data for book 2" << endl;
    book2.getdata();

    cout << "\nEnter data for book 3" << endl;
    book3.getdata();

    cout << "\nData of entered books:" << endl;
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}

