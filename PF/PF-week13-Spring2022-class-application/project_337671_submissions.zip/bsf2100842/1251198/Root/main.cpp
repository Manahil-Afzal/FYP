/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include <iostream>
using namespace std;

class person {
  public:
    int personAge(int age);
};

int person::personAge(int age) {
  return age;
}

int main() {
  person myObj; // Create an object of persom
  cout << "My age is: "  << myObj.personAge(20); // Call the method with an argument
  return 0;
}