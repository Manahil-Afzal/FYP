/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include <iostream>

using namespace std;

class book
{
string title;
float price ;
public:
void getdata ();
void putdata ();
};
void book :: getdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
 
}
void book :: putdata()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}