/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class myclass{
    public:
    int age(){
        int AGE;
        cout<<"Enter your age:";
        cin>>AGE;
        return AGE;
        }
};
int main(){
    myclass obj;
    cout<<"Your age is: "<<obj.age();
}
