/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std ;
class person {
    public:
    int method(int age);
};
int person:: method(int age){
    return age;
}
int main()
{   
    person myobj;
     cout<<myobj.method(50);
     return 0 ;
    
}