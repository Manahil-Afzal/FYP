/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */

#include<iostream>
using namespace std;
class Age
{
public:
    int ageCalc(int age);
};
int Age::ageCalc(int age)
{
    int result;
    cout<<"Enter your age : ";
    cin>>age;
    cout<<"Your age is : ";
    return age;
}
int main()
{
    Age usr1;
    int age;
    cout<<usr1.ageCalc(age);
}