/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
struct books
{
	int RIJABOOK;
	int price, contentsofbook;
};
int main()
{
	books b1,b2;
	char anykey;
cout << "Enter the data of first book" << endl;
cout << "Enters the first RIJABOOK : ";
cin >> b1.RIJABOOK;
cout << "Enter the price of first book : ";
cin >> b1.price;
cout << "Enter the content of first book : ";
cin >> b1. contentsofbook;
cout <<endl << "Enter the second book" << endl;
cout << "Enter the second RIJABOOK : ";
cin >> b2.RIJABOOK;
cout << "Enter the price of second book : ";
cin >> b2.price;
cout << "Enter the content of second book : ";
cin >> b2.contentsofbook;

if (b1.price > b2.price)
{
	cout <<endl<< "Price of the first book is greater then the price of second book" << endl;
	cout << "The rocord of first book is" << endl;
	cout << "First RIJABOOK="    << b1.RIJABOOK << endl;
	cout << "First book price=" << b1.price << endl;
	cout << "First book contents=" << b1. contentsofbook << endl;
	
}
else if (b1.price == b2.price)
{
	cout <<endl <<"The price of both books are same" << endl;
}
else
{
	cout << endl<<"Price of the second book is greater than the first book" << endl;
	cout << "The rocord of second book is" << endl;
	cout << "Second RIJABOOK=" << b2.RIJABOOK << endl;
	cout << "Second book price=" << b2.price << endl;
	cout << "Second book contents=" << b2. contentsofbook << endl;
	
}

return 0;
}