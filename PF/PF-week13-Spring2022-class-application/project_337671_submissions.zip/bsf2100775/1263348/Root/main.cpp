/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class info{
    public:
    float get(float age){
        return age;



    }

};
int main()
{
    float age1;
    cout<<"Enter Your Age";
    cin>>age1;
    info object1;
    cout<<"Your Age is:"<<object1.get(age1);
    

}