/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class person{
public:
int personAge(int myAge);
};
int person::personAge(int myAge){
    return myAge;
}
int main(){
    person myObj;
    cout<<myObj.personAge(30);
    return 0;
}
