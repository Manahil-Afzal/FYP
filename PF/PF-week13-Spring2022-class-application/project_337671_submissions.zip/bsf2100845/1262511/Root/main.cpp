/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;

class Age
{
    int age;
public:
    void setAge(int a)
    {
        age = a;
    }
    void displayAge()
    {
        cout <<"Your age is: " <<age;
    }
};


int main()
{
    Age a;
    int input;
    cout << "Enter your age: ";
    cin>>input;
    a.setAge(input);
    a.displayAge();
    return 0;
}