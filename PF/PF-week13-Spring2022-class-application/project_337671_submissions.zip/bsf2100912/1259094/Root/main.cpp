/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class Age{
    public:
    int age(int myAge);
};

int Age::age(int myAge){
return myAge;}

main(){
    Age object;
    cout<<object.age(22)<<"yrs";
    return 0;
}