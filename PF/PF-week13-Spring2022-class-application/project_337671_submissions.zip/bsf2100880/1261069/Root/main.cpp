/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */#include<iostream>
using namespace std;
class Age {
    public:
    int getAge(int currentAge);
};
int Age::getAge(int currentAge) {
    return currentAge;
}
int main() {
    Age myAge;
    cout<<myAge.getAge(20);
    return 0;
}