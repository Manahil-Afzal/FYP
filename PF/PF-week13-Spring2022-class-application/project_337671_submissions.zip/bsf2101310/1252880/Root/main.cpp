/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;

class Person{
    public:
    int age(int myAge);
    
};

int Person::age(int myAge){
    return myAge;
}

int main()
{
    Person myObj;
    cout<<"My age is: "<<myObj.age(18);
    return 0;
}