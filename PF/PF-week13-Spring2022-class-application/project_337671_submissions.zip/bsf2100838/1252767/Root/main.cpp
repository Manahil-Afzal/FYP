/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class Human
{
	public:
	
	int func(int age);
};
int Human::func(int age)
{
	cout<<"Enter the age dear=";
	cin>>age;
    return age;
}
int main()
{
    Human myObj;
	cout<<myObj.func(0);
	return 0;
}
