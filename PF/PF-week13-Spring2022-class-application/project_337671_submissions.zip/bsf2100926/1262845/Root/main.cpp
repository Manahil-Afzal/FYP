/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class Human
{
	public:
	Human(){}
	int func(int age);
};
int Human::func(int age)
{
    return age;
}
int main()
{
	Human myObj;
	cout<<myObj.func(50);
	return 0;
}