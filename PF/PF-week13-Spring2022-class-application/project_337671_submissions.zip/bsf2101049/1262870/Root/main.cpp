/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class Age
{
public:
    int myage(int age);
};
int Age::myage(int age)
{
    int result;
    cout<<"Enter your age ";
    cin>>age;
    cout<<"your age is ";
    return age;
}
int main()
{
    Age c1;
    int age;
    cout<<c1.myage(age);
}