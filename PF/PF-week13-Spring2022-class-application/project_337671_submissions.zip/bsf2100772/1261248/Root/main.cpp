/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include <iostream>
using namespace std;

class Myself{
    public:
  
  int Myage (int age){
    

    return age;
  };
    
};
int main(){

    Myself years;
    	int age;
    	cout<<"Enter your age :"<<endl;
	cin>>age;
     
     
   
   
    cout<<"Your age: "<<years.Myage(age);
    return 0;
}