/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include <iostream>
using namespace std;
class myage
{
    public:
    int a ;
    void getmyage()
    {
        cout<<"Enter your age ";
        cin>>a;
    }
    int showdata(int a)
    {
        cout<<"your age is="<<a;
    return a;
    }
};
int main()
{
    myage obj1;
    obj1.getmyage();
    obj1.showdata(obj1.a);
    return 0;
}
