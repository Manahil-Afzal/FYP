/*Write a C++ program that defines a class which has method that takes your age as a parameter and returns and displays it in main function. 
Create an object of that class and displays your age by calling the method accordingly. */
#include<iostream>
using namespace std;
class Myclass{
public:
int method(int age);
};
int Myclass::method(int age){
    return age;
}
int main(){
    Myclass myObj;
    cout<<myObj.method(60);
    return 0;
}
    
