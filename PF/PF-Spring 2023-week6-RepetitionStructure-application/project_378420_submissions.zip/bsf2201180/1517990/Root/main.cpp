/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main()
{
    int start, end, sumeven = 0, sumodd = 0, counteven = 0, countodd = 0;
    
    cout << "Enter the start of the range: ";
    cin >> start;
    cout << "Enter the end of the range: ";
    cin >> end;
    
    cout << "\nThe even numbers between the given range are: ";
    for (int i = start; i <= end; i++)
    {
        if (i % 2 == 0)
        {
            cout << i << " ";
            sumeven += i;
            counteven++;
        }
    }
    
    cout << "\nThe odd numbers between the given range are: ";
    for (int i = start; i <= end; i++)
    {
        if (i % 2 != 0)
        {
            cout << i << " ";
            sumodd += i;
            countodd++;
        }
    }
    
    double aveven = (double)sumeven / counteven;
    double avgodd = (double)sumodd / countodd;
    
    cout << "\nThe average of even numbers in the given range is: " << aveven;
    cout << "\nThe average of odd numbers in the given range is: " << avgodd;
    
    return 0;
}