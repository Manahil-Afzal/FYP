/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
main()
{
int low, high, even = 0, odd = 0, count_even = 0, count_odd = 0;
cout << "Enter lower and higher range: ";
cin >> low >> high;
for (int i = low; i <= high; i++)
 {
   if (i % 2 == 0)
    {
     even += i;
     count_even++;
    }
     else
     {
      odd += i;
      count_odd++;
     }
 }
if (count_even == 0)
 {
  cout << "No even numbers in the range." << endl;
 }
  else
  {
    double avg_even=even/count_even;
    cout << "Average of even numbers: " << avg_even << endl;
  }
if (count_odd == 0)
 {
  cout << "No odd numbers in the range." << endl;
 }
 else
 {
  double avg_odd =odd/count_odd;
  cout << "Average of odd numbers: " << avg_odd << endl;
  }
}

