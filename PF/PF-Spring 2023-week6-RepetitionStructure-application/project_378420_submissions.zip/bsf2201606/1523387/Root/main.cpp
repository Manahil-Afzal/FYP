/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
int nmbr,o,sum,i;
float avg;
cout<<"Enter the number=";
cin>>nmbr;
for(int i=0; i<=nmbr; i=i+2)
sum=sum+i;
avg=sum/nmbr;
cout<<"The average of even number is="<<avg;

for(int i=1; i<=nmbr; i=i+2)
o=o+i;
avg=o/nmbr;
cout<<"\nThe average of odd number is="<<avg;
}




