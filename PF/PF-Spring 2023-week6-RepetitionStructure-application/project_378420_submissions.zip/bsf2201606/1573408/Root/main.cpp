/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
main ()
{
    int a,b;
    int sume=0,sumo=0,counte=0,counto=0;
    float avge,avgo;
    cout<<"enter the lower number =";
    cin>>a;
    cout<<"enter higher number =";
    cin>>b;
    for(int i=a;i<=b;i++)
    {
        if(i%2==0)
        {
            sume+=i;
            counte++;
        }
        else
        {
            sumo+=i;
            counto++;
        }
    }
    if(sume==0)
    {
        cout<<"no even number exist";
    }
    else
    {
        avge=sume/counte;
        cout<<"Average of even numbers ="<<avge<<endl;
    }
    if(sumo==0)
    {
        cout<<"no odd number exist";
    }
    else
    {
        avgo=sumo/counto;
        cout<<"Average of odd numbers ="<<avgo<<endl;
        
    }
}