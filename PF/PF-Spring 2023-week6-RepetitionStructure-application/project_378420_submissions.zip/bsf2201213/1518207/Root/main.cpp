/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main (){
    int lower=0 ,uper=0;
    int count1=0,count2=0;
    double even=0,odd=0;
    double averageE,averageO;
    cout<<"enter lower limit ";
    
    
    cin>>lower;
    lower=lower+1;
    cout<<endl;
    cout<<"enter upper limit ";
    cin>>uper;
    for(int i=lower;lower<uper ; lower++)
    {
        if(lower%2==0)
        {
            even = even+lower;
            count1++;
        }
        else
        {
            odd=odd+lower;
            count2++;
        }
    }
    averageE = even/count1;
    averageO = odd/count2;
    cout<<"Average of even numbers is "<<averageE<<endl;
    cout<<"Average of odd numbers is  "<<averageO<<endl;
    
    
    return 0;
}