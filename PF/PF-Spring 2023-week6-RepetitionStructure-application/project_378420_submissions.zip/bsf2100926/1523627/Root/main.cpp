/*Write a C++ program which displays the average of even numbers and
average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and 
display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
int main()
{
int i,num, Even_Sum=0,Odd_Sum=0,Even_Count=0,Odd_Count=0;
double Even_Ave,Odd_Ave;
cout<<"Enter the number= ";
cin>>num;
for(i=1; i<=num; i++)
{
if(i % 2==0)
{
Even_Sum=Even_Sum+i;
Even_Count++;
}
else{
Odd_Sum=Odd_Sum+i;
Odd_Count++;
}
}
Even_Ave=Even_Sum/Even_Count;
Odd_Ave=Odd_Sum/Odd_Count;
cout<<"Average of odd numbers = "<<Odd_Ave;
cout<<" \n ";
cout<<"Average of even numbers = "<<Even_Ave;
return 0;
}
