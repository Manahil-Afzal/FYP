/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/

#include <iostream>
using namespace std;

int main() {
    int lower, upper;
    cout << "Enter lower and upper bounds of range: ";
    cin >> lower >> upper;

    int sumEven = 0, countEven = 0;
    int sumOdd = 0, countOdd = 0;

    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) {
            sumEven += i;
            countEven++;
        } else {
            sumOdd += i;
            countOdd++;
        }
    }

    double avgEven = 0, avgOdd = 0;
    if (countEven > 0) {
        avgEven = (sumEven) / countEven;
    }
    if (countOdd > 0) {
        avgOdd = (sumOdd) / countOdd;
    }

    cout << "Average of even numbers: " << avgEven << endl;
    cout << "Average of odd numbers: " << avgOdd << endl;

    return 0;
}
