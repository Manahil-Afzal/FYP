#include<iostream>
using namespace std;
int main()
{
int lower, upper, evensum, oddsum, evencount, oddcount, n,i,j;
double avg_e, avg_o;
cout<<"Enter the lower range value";
cin>>lower;
cout<<"Enter the upper eange value";
cin>>upper;
for(int i=lower;i<=upper;i++)
if(i%2==0){
evensum+=1;
n=(lower+upper)/2;
avg_e=evensum/n;
}
for(int a=lower;j<=upper;j++)
if (j%2!=0){
oddsum+=j;
avg_o=oddsum/n;
}
cout<<"Even Average = "<<avg_e;
cout<<"\nOdd Average = "<<avg_o;
}