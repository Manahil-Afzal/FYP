/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/


#include <iostream>
using namespace std;

int main()
{
    int lower, upper;
    cout << "Enter lower limit of range: ";
    cin >> lower;
    cout << "Enter upper limit of range: ";
    cin >> upper;

    int sum_even = 0, count_even = 0;
    int sum_odd = 0, count_odd = 0;

    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) {  // i is even
            sum_even += i;
            count_even++;
        } else {           // i is odd
            sum_odd += i;
            count_odd++;
        }
    }

    double avg_even = 0.0, avg_odd = 0.0;
    if (count_even > 0) {
        avg_even = static_cast<double>(sum_even) / count_even;
    }
    if (count_odd > 0) {
        avg_odd = static_cast<double>(sum_odd) / count_odd;
    }

    cout << "Average of even numbers: " << avg_even << endl;
    cout << "Average of odd numbers: " << avg_odd << endl;

    return 0;
}
