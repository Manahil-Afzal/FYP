/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
	int lower;
	int higher;
	int oddsum;
	int evensum;
	
	double oddaverage, evenavg;
	int evenCount,Oddcount;
	
	cout<<"Enter Lower Number: ";
	cin>>lower;
	cout<<" Enter Highr Number: ";
	cin>>higher;
	
	for(int i=lower;i<=higher; i++){
		if(i%2==0){
			evensum=evensum+i;
			evenCount++;
		}
		
		else{
			oddsum=oddsum+i;
			Oddcount++;
		}
	}
	
	cout<<"\n Sum of Even Number: = "<<evensum<<"\n";
	evenavg=evensum/evenCount;
	cout<<"\n Average of Even Number: = "<<evenavg<<"\n";
	
	cout<<"\n Sum of Odd Number: = "<<oddsum<<"\n";
	oddaverage = oddsum/Oddcount;
	cout<<"\n Average of Odd Number: = "<<oddaverage<<"\n";
}