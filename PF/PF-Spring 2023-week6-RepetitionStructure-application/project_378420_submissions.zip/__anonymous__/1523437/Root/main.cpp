/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, upper, even_sum = 0, even_count = 0, odd_sum = 0, odd_count = 0;
    cout << "Enter lower  values of the range: ";
    cin >> lower;
cout<<"Enter upper value of the range:";
cin>>upper;
    for (int i = lower; i <= upper; i++) {
        if (i % 2 == 0) { // Even number
            even_sum += i;
            even_count++;
        } else { // Odd number
            odd_sum += i;
            odd_count++;
        }
    }

    if (even_count > 0) {
        cout << "Average of even numbers: " << (double)even_sum / even_count << endl;
    } else {
        cout << "No even numbers found in the range." << endl;
    }

    if (odd_count > 0) {
        cout << "Average of odd numbers: " << (double)odd_sum / odd_count << endl;
    } else {
        cout << "No odd numbers found in the range." << endl;
    }

    return 0;
}