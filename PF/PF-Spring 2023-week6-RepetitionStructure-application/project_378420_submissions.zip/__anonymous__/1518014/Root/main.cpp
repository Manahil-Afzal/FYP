#include<iostream>
using namespace std;
int main()
{
    int a, lownum, highnum, e_sum, o_sum,i ,j;
    double avr_e, avr_o;
    cout<<"Enter the Low value of range: ";
    cin>>lownum;
    cout<<"Enter the High value of range: ";
    cin>>highnum;
     
     for (int i=lownum; i<=highnum; i++)
     if (i%2==0)
     e_sum +=i;
     a=(lownum+highnum)/2;
     avr_e=e_sum/a;
     
      for (int j=lownum; j<=highnum; j++)
      if (j%2!=0)
      o_sum +=j;
      avr_o=o_sum/a;
      cout<<"Average of odd numbers: "<<avr_o;
      cout<<"\nAverage of even numbers: "<<avr_e;
}