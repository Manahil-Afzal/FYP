/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/

#include <iostream>

using namespace std;

int main() {
    int lower, higher, evenSum = 0, oddSum = 0, evenCount = 0, oddCount = 0;
    double evenAvg, oddAvg;

    cout << "Enter the lower value of the range: ";
    cin >> lower;

    cout << "Enter the higher value of the range: ";
    cin >> higher;

    for (int i = lower; i <= higher; i++) {
        if (i % 2 == 0) {
            evenSum += i;
            evenCount++;
        } else {
            oddSum += i;
            oddCount++;
        }
    }

    if (evenCount != 0) {
        evenAvg = static_cast<double>(evenSum) / evenCount;
        cout << "Average of even numbers: " << evenAvg << endl;
    } else {
        cout << "No even numbers in the range." << endl;
    }

    if (oddCount != 0) {
        oddAvg = static_cast<double>(oddSum) / oddCount;
        cout << "Average of odd numbers: " << oddAvg << endl;
    } else {
        cout << "No odd numbers in the range." << endl;
    }

    return 0;
}

