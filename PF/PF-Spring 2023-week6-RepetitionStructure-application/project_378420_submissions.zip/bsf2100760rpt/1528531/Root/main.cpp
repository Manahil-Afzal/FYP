/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/

#include <iostream>
using namespace std;

int main(){
    int lower_range;
    int higher_range;
    int even_count=0;
    int odd_count=0;
    int even_average;
    int odd_average;
    int even_sum=0;
    int odd_sum=0;
    cout<<"Enter the lower range"<<endl;
    cin>>lower_range;
     cout<<"Enter the higher range"<<endl;
    cin>>higher_range;
    for(int i=lower_range;i<=higher_range;i++){
        if(i%2==0){
            even_count++;
            even_sum+=i;
        }
        else{
            odd_count++;
            odd_sum+=i;
        }
    }
    
    even_average=even_sum/even_count;
    odd_average=odd_sum/odd_count;
    cout<<"Average of Even numbers within the given range is :"<<even_average<<endl;
    cout<<"Average of Odd numbers within the given range is :"<<odd_average<<endl;
    
    
    return 0;
}