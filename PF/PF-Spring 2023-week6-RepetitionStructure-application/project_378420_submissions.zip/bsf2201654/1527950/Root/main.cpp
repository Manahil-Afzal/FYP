/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lower, higher, sumEven = 0, sumOdd = 0, countEven = 0, countOdd = 0;

    cout << "Enter lower value of range: ";
    cin >> lower;

    cout << "Enter higher value of range: ";
    cin >> higher;

    for (int i = lower; i <= higher; i++) {
        if (i % 2 == 0) { // if i is even
            sumEven += i;
            countEven++;
        } else { // if i is odd
            sumOdd += i;
            countOdd++;
        }
    }

    double avgEven = (double)sumEven / countEven;
    double avgOdd = (double)sumOdd / countOdd;

    cout << "Average of even numbers between " << lower << " and " << higher << " is " << avgEven << endl;
    cout << "Average of odd numbers between " << lower << " and " << higher << " is " << avgOdd << endl;

    return 0;
}
