/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/#include<iostream>
using namespace std;
main()
{
	int i,lower,higher,evensum=0,oddsum=0,evencount=0,oddcount=0;
	double evenAvg,oddAvg;
	cout<<"enter the lower value:";
	cin>>lower;
	cout<<"\n enter the higher value:";
	cin>>higher;
	for(i=lower;i<=higher;i++){
		if(i%2==0){
		evensum=evensum+i;
		evencount++;
		}
	else{
		oddsum=oddsum+i;
		oddcount++;
	}
	}
	evenAvg=evensum/evencount;
	oddAvg=oddsum/oddcount;
	cout<<"Average of odd numbers are:"<<oddAvg;
	cout<<"\n";
	cout<<"Average of even number are:"<<evenAvg;
}