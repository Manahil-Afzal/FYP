/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
main()
{
	int       lowest,heightest,a,b;
	          a=0;
	          b=0;
	cout<<"Enter a lowest  numbers !"<<endl;
	cin>>lowest;
		cout<<"Enter a largest  numbers !"<<endl;
	cin>>heightest;
	for(int i=lowest;i<heightest;i++)
	{
		if(i%2==0)
		{
			a++;
		}
		
		else
		{
			b++;
			
		}

	}
			cout<<"total even numbers = "<<a<<endl;
		cout<<"total odd numbers = "<<b<<endl;
}
		
		
		
		
		
		
		
