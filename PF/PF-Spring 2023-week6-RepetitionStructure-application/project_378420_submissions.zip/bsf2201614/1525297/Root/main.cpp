/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main()
{
    int lower, higher;
    cout << "Enter lower and higher values of range: ";
    cin >> lower >> higher;
    
    int sum_even = 0, count_even = 0;
    int sum_odd = 0, count_odd = 0;
    
    for(int i = lower; i <= higher; i++) {
        if(i % 2 == 0) {
            sum_even += i;
            count_even++;
        } else {
            sum_odd += i;
            count_odd++;
        }
    }
    
    double avg_even = (count_even != 0) ? (double) sum_even / count_even : 0;
    double avg_odd = (count_odd != 0) ? (double) sum_odd / count_odd : 0;
    
    cout << "Average of even numbers: " << avg_even << endl;
    cout << "Average of odd numbers: " << avg_odd << endl;
    
    return 0;
}