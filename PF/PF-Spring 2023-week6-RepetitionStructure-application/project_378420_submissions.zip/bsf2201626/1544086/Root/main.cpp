/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main() {
    int lowest, uppest, sum_even = 0, sum_odd = 0, count_even = 0, count_odd = 0;
    float avg_even, avg_odd;

    cout << "Enter lowest value of range: ";
    cin >> lowest;
    cout << "Enter uppest value of range: ";
    cin >> uppest;

    for(int i = lowest; i <= uppest; i++) {
        if(i % 2 == 0) {
            sum_even += i;
            count_even++;
        }
        else {
            sum_odd += i;
            count_odd++;
        }
    }

    if(count_even != 0) {
        avg_even = (float)sum_even / count_even;
        cout << "Average of even numbers between " << lowest << " and " << uppest << " is " << avg_even << endl;
    }
    else {
        cout << "No even numbers found in the given range." << endl;
    }

    if(count_odd != 0) {
        avg_odd = (float)sum_odd / count_odd;
        cout << "Average of odd numbers between " << lowest << " and " << uppest << " is " << avg_odd << endl;
    }
    else {
        cout << "No odd numbers found in the given range." << endl;
    }

    return 0;
}
