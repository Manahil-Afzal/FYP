/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
main()
{
    int n, low, high, evensum, oddsum, evencount, oddcount;
    double avreven, avrodd;
    cout<<"enter the lower value: ";
    cin>>low;
    cout<<"\n enter higher value: ";
    cin>>high;

    
	for(int i=low; i<=high; i++)
{

	if (i%2==0)
    evensum +=i;
    n=(low+high)/2;
	avreven=evensum/n;
}
    for(int j=low; j<=high; j++)
 {
	   
	if (j%2!=0)
    oddsum +=j;
    n=(low+high)/2;
    avrodd=oddsum/n;
}
	cout<<"avarege sum of even is "<<avreven;
    cout<<"\navarage sum of odd is "<<avrodd;
    
    
    
}