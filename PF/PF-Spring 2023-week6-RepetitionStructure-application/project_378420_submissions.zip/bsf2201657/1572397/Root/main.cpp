/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;

int main () 
{
    int n, x, oddSum = 0, evenSum = 0;
    cout << "Enter the number of values: ";
    cin >> n;
    cout << "Enter your values:" << endl;
    for (int i = 0; i < n; i++) 
    {
    cin >> x;
    if (x % 2 == 0)
    evenSum += x;
    else
    oddSum += x;
    }
    cout << "Sum of Even Numbers: " << evenSum << endl;
    cout << "Sum of Odd Numbers: " << oddSum << endl;
    return 0;
}