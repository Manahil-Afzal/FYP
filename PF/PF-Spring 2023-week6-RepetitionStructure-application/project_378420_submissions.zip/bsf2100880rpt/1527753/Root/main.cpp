/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
    int lower_range,higher_range;
    int even_sum=0,odd_sum=0,even_count=0,odd_count=0;
    double even_avg,odd_avg;
    cout<<"enter lower_range: "<<endl;
    cin>>lower_range;
    cout<<"enter higher_range: "<<endl;
    cin>>higher_range;
    for(int i=lower_range; i<=higher_range;i++)
    {
    	if(i%2==0)
    	{
    		even_sum=even_sum+i;
    		even_count++;
		}
		else
		{
			odd_sum=odd_sum+i;
			odd_count++;
		}
		even_avg=even_sum/even_count;
		odd_avg=odd_sum/odd_count;
		
		cout<<"avg of even no : "<<even_avg<<endl;
		cout<<"avg of odd no : "<<odd_avg<<endl;
	}
    return 0;
}