/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>
using namespace std;
int main(){
   int lower,higher;
   cout<<"enter the lower number"<<endl;
   cin>>lower;
   cout<<"enter the higher no"<<endl;
   cin>>higher;
   int evensum=0;
   int evencount=0;
   int oddsum=0;
   int oddcount=0;
   for(int num=lower;num<=higher;num++){
    if(num%2==0){
        evensum+=num;
        evencount++;
    }else{
        oddsum+=num;
        oddcount++;
    }
   }
   double oddavg=oddsum/oddcount;
   double evenavg=evensum/evencount;
   cout<<"the average of odd nos are"<<oddavg<<endl;
   cout<<"the average of even nos are"<<evenavg;
   

   
    return 0;
}