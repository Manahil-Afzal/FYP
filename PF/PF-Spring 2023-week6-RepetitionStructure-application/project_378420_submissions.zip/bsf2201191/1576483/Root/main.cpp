/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;

int main()
{
    int lower, higher, evenSum=0, evenCount=0, oddSum=0, oddCount=0;

    cout<<"Enter lower limit of range: ";
    cin>>lower;
    cout<<"Enter higher limit of range: ";
    cin>>higher;

    for(int i=lower; i<=higher; i++)
    {
        if(i%2==0)
        {
            evenSum += i;
            evenCount++;
        }
        else
        {
            oddSum += i;
            oddCount++;
        }
    }

    if(evenCount!=0)
    {
        float evenAverage = (float)evenSum/evenCount;
        cout<<"Average of even numbers between "<<lower<<" and "<<higher<<" is "<<evenAverage<<endl;
    }
    else
    {
        cout<<"No even numbers found in given range."<<endl;
    }

    if(oddCount!=0)
    {
        float oddAverage = (float)oddSum/oddCount;
        cout<<"Average of odd numbers between "<<lower<<" and "<<higher<<" is "<<oddAverage<<endl;
    }
    else
    {
        cout<<"No odd numbers found in given range."<<endl;
    }

    return 0;
}