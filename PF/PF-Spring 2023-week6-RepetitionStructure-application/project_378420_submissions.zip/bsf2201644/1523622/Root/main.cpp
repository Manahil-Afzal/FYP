#include <iostream>
using namespace std;

int main() {
   int lower, upper, even_sum = 0, odd_sum = 0, even_count = 0, odd_count = 0;

   cout << "Enter lower limit: ";
   cin >> lower;

   cout << "Enter upper limit: ";
   cin >> upper;

   // calculate sum and count of even and odd numbers
   for (int i = lower; i <= upper; i++) {
      if (i % 2 == 0) {
         even_sum += i;
         even_count++;
      } else {
         odd_sum += i;
         odd_count++;
      }
   }

   // calculate average of even and odd numbers
   double even_avg = (even_count == 0) ? 0 : (double)even_sum / even_count;
   double odd_avg = (odd_count == 0) ? 0 : (double)odd_sum / odd_count;

   // display results
   cout << "Average of even numbers: " << even_avg << endl;
   cout << "Average of odd numbers: " << odd_avg << endl;

   return 0;
}
