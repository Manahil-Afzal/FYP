/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
int main()
{
    int low,high,odd_sum=0,even_sum=0,count_even=0,count_odd=0;
    cout<<"please enter lower value of range: ";
    cin>>low;
    cout<<"please enter higher value of range: ";
    cin>>high;
    for(int a=low; a<=high; a++)
    {
        if(a%2==0)
        {
            even_sum+= a;
            count_even++;
            
        }else{
            odd_sum+=a;
            count_odd++;
        }
}
cout<<" the avg of even numbers in the range is :"<<even_sum/count_even<<endl;
cout<<" the avg of odd numbers in the range is :"<<odd_sum/count_odd<<endl;
}