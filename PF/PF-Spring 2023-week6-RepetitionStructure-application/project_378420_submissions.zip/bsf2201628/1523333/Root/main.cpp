/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include <iostream>

using namespace std;

int main() {
    int lower, higher, sumEven = 0, sumOdd = 0, countEven = 0, countOdd = 0;
    double avgEven, avgOdd;

    cout << "Enter the lower value of the range: ";
    cin >> lower;

    cout << "Enter the higher value of the range: ";
    cin >> higher;

    for (int i = lower; i <= higher; i++) {
        if (i % 2 == 0) {
            sumEven += i;
            countEven++;
        } else {
            sumOdd += i;
            countOdd++;
        }
    }

    if (countEven != 0) {
        avgEven = static_cast<double>(sumEven) / countEven;
        cout << "The average of even numbers between " << lower << " and " << higher << " is " << avgEven << endl;
    } else {
        cout << "There are no even numbers between " << lower << " and " << higher << endl;
    }

    if (countOdd != 0) {
        avgOdd = static_cast<double>(sumOdd) / countOdd;
        cout << "The average of odd numbers between " << lower << " and " << higher << " is " << avgOdd << endl;
    } else {
        cout << "There are no odd numbers between " << lower << " and " << higher << endl;
    }

    return 0;
}