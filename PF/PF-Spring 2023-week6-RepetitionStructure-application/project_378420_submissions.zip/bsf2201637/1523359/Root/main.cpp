/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/

#include <iostream>
using namespace std;

main()
{
int lower, higher, sum_even=0, sum_odd=0, count_even=0, count_odd=0;
float avg_even=0, avg_odd=0;

cout<<"Enter the Lower value of range : ";
cin>>lower;
cout<<"Enter the Higher value of range : ";
cin>>higher;

for(int i=lower; i<=higher; i++)
{
if(i%2 == 0)
{
sum_even += i;
count_even++;
}
else
{
sum_odd += i;
count_odd++;
}
}

if(count_even == 0)
{
cout<<"No Even numbers found in given range"<<endl;
}
else
{
avg_even = (float)sum_even/count_even;
cout<<"Average of Even Numbers between "<<lower<<" and "<<higher<<" : "<<avg_even<<endl;
}

if(count_odd == 0)
{
cout<<"No Odd numbers found in given range"<<endl;
}
else
{
avg_odd = (float)sum_odd/count_odd;
cout<<"Average of Odd Numbers between "<<lower<<" and "<<higher<<" : "<<avg_odd<<endl;
}

return 0;
}
