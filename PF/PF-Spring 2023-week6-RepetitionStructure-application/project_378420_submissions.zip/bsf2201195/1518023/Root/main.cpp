/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
main()
{int low_value,high_value,even_sum,odd_sum,n,i,j;
 double avg_even,avg_odd;
 cout<<"enter lower value";
 cin>>low_value;
 cout<<"\n enter higher value";
 cin>>high_value;
 for(i=low_value;i<=high_value;i++)
 
   if(i%2==0)
   even_sum +=i;
   n=(low_value+high_value)/2;  
   avg_even=even_sum/n;
   
 for(j=low_value;j<=high_value;j++) 
   
   if(j%2!=0) 
   odd_sum +=j;
   avg_odd=odd_sum/n;
   
   cout<<"average sum of even is"<<avg_even;
   cout<<"\naverage sum of odd is"<<avg_odd;
}