/*Write a C++ program which displays the average of even numbers and average of odd numbers between a range of numbers.
You need to take inputs of lower and higher values of a range and display the averages of even numbers and odd numbers fall between those values.*/
#include<iostream>
using namespace std;
main()
{
    int lower,higher,a,b;
    a=0;
    b=0;
    cout<<"Enter lower number:";
    cin>>lower;
    cout<<"Enter higher number:";
    cin>>higher;
    for(int i=lower;i<higher;i++)
    {
if(i%2==0)
{
    a++;
}
else
{
    b++;
}      
        
    }
cout<<"total even number ="<<a<<endl;
cout<<"total odd number ="<<b<<endl;
}


   