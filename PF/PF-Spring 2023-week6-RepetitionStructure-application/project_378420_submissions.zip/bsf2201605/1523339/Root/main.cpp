 #include<iostream>
using namespace std;
main()
{
    int lower, higher, sum_even = 0, sum_odd = 0, count_even = 0, count_odd = 0;

    cout << "Enter lower and higher range: ";
    cin >> lower >> higher;

    for (int i = lower; i <= higher; i++)
    {
        if (i % 2 == 0)
        {
            sum_even += i;
            count_even++;
        }
        else
        {
            sum_odd += i;
            count_odd++;
        }
    }

    if (count_even == 0)
    {
        cout << "No even numbers in the range." << endl;
    }
    else
    {
        double avg_even = static_cast<double>(sum_even) / count_even;
        cout << "Average of even numbers: " << avg_even << endl;
    }

    if (count_odd == 0)
    {
        cout << "No odd numbers in the range." << endl;
    }
    else
    {
        double avg_odd = static_cast<double>(sum_odd) / count_odd;
        cout << "Average of odd numbers: " << avg_odd << endl;
    }

    return 0;
}