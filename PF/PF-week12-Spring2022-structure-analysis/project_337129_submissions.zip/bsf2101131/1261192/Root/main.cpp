// Identify and correct errors.

#include <iostream>
using namespace std;


struct Distance {
    int feet;
    float inch;
} d1, d2, sumOfDistances; //semi colon not used when we create structure variable

int main() {
    // feat and inch variable are not declare so we declare
    int feet;
    float inch;
    cout<<"Enter information for 1st distance\n"; //correct the close quote
    cout<<"Enter feet: "; //remove the clode pranthises
    cin>>feet;
    cout<<"Enter inch: ";
    cin>>inch;
    cout<<"\nEnter information for 2nd distance\n";//correct the close quote
    cout<<"Enter feet: ";
    cin>>d2.feet; // use dot sign and remove close prentheses
    cout<<"Enter inch: ";
    cin>>d2.inch; //use dot sign

    sumOfDistances.feet=d1.feet+d2.feet;
    sumOfDistances.inch=d1.inch+d2.inch;
   
    if (sumOfDistances.inch>12.0) {
        sumOfDistances.inch = sumOfDistances.inch-12.0;
        ++sumOfDistances.feet;
    }
        cout<<"\nSum of distances = "; ///correct the close quote
cout<<sumOfDistances.feet, sumOfDistances.inch;
    return 0;
}


