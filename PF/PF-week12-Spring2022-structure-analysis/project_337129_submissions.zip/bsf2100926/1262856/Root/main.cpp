// Identify and correct errors.

#include<iostream>
using namespace std;
struct Distance{
    	int feet;
    	float inch;
}; 
int main()
{
   	 Distance d1,d2,sumOfDistances;
cout<<"Enter information about d1:"<<endl;
    	cout<<"Enter feet: ";
    	cin>>d1.feet;
    	cout<<"Enter inch: ";
   	cin>>d1.inch;
    	cout<<"\nEnter information about d2:"<<endl;
    	cout<<"Enter feet: ";
    	cin>>d2.feet;
    	cout<<"Enter inch: ";
    	cin>>d2.inch;
   	sumOfDistances.feet=d1.feet+d2.feet;
    	sumOfDistances.inch=d1.inch+d2.inch;
    	if (sumOfDistances.inch>=12.0)
{
        	sumOfDistances.inch = sumOfDistances.inch-12.0;
        	++sumOfDistances.feet;
}
cout<<"\nSum of distances : "<<sumOfDistances.feet<<","<<sumOfDistances.inch;
        	return 0;
}