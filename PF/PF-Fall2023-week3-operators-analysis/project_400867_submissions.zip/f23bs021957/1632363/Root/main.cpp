// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//use>> instead of <<
  x = y;
  cout<<"Value of x = "<<x<<endl;//missing of "
  
  int a = 3,b = 5,c = 8;
  a += b;//use += instead =+
  c -= b;//use-= instead =-
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c<<endl;
  
  a *= b;
  b /= c;//use/= instead =/
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b<<endl;
  
  return 0;
  }


