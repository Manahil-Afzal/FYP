 // Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; //wrong insertion operator
  x = y;
  cout<<"Value of x =" <<x<<endl;//Incorrect way of using cout fuction not using double qoutes on both side of  "value of x=".
  
  int a = 3,b = 5,c = 8;
  a += b;
  c -= b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c << endl;
  
  a *= b;
  b /= c;//Incorrect way of using asignment operators "a=+b and c=-b".
  cout<<"a *= b: "<<a << endl;
  cout<<"b /= c: "<<b;
  
  return 0;
  }




