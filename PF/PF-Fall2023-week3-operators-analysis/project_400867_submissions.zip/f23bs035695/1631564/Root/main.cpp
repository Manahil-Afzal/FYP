// Identify and correct errors. Also comment your identified errors and corrections
#include <iostream>
using namespace std;
int main()
{
  int x, y;
  cout << "Enter input variable y: "; // Corrected the input statement operator from '<<' to '>>'
  cin >> y; // Corrected '<<' to '>>' to read input into 'y'
  x = y;
  cout << "Value of x = " << x << endl; // Corrected the output statement format
  int a = 3, b = 5, c = 8;
  a += b; // Corrected the assignment operator to '+='
  c -= b; // Corrected the assignment operator to '-='
  cout << "\na += b: " << a;
  cout << "\nc -= b: " << c;
  a *= b; // Corrected the assignment operator to '*='
  b /= c; // Corrected the assignment operator to '/='
  cout << "\na *= b: " << a;
  cout << "\nb /= c: " << b;
  return 0;
}
