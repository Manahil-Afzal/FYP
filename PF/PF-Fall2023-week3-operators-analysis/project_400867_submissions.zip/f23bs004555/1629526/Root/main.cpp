
#include<iostream>           //remove space
using namespace std;
int main()
{
  int x,y;
  cout<<"Enter input variable y:"; //remove space
  cin>>y;                            //remove insertion operators and add exertion operators
  x = y;
  cout<<"Value of x ="<<x<<endl;   //insert inverted commas
  
  int a = 3,c = 8;
  float b=5;
  a += b;                           //change assignment operators
  c -= b;
  cout<<"a += b:"<<a;            //remove backslash n
  cout<<"c -= b:"<<c;            //remove backslash n
  
  a *= b;
  b /= c;
  cout<<"a *= b:"<<a;              //remove space 
  cout<<"b /= c:"<<b;              //remove space
  }


