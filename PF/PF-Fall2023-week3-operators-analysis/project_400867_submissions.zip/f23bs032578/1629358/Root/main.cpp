// Identify and correct errors. Also comment your identified errors and corrections

#include<iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//here wrong angle braCKET IS USED
  x=y;
  cout<<"Value of x = "<<x<<endl; //here the quatation mark is missed
  int a = 3,b = 5,c = 8;
  a += b;//here wrong compound assignment operator is used
  c -= b;//here wrong compound assignment operator is used
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  return 0;
  }


