
 #include <iostream>
using namespace std;

int main()
{
  int x, y;
  cout << "Enter input variable y: ";
  cin >> y; // Changed cin<<y; to cin >> y; to correctly input the value of y.
  x = y;
  cout << "Value of x = " << x << endl; // Fixed the formatting for output.

  int a = 3, b = 5, c = 8;
  a += b; // Changed =+ to += to correctly perform addition.
  c -= b; // Changed =- to -= to correctly perform subtraction.
  cout << "\na += b: " << a;
  cout << "\nc -= b: " << c;

  a *= b; // Corrected the *= operator for multiplication.
  b /= c; // Corrected the /= operator for division.
  cout << "\na *= b: " << a;
  cout << "\nb /= c: " << b; // Added a newline character at the end for proper formatting.
}

