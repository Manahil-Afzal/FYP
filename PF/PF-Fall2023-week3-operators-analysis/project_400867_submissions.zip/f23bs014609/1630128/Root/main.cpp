
#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;        //used insertion opertors instead of extraction operator
  x = y;
  cout<<"Value of x = "<<x<<endl;   //missing closing double qoutes
  
  int a = 3,b = 5,c = 8;
  a += b;  //wrong syntax of add AND assignment opertor
  c -= b;   //wrong syntax of subtract AND assignment opertor
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c<<endl;  //used endl to increase readability
  a *= b;
  b /= c;    //wrong syntax of division AND assignment opertor
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


