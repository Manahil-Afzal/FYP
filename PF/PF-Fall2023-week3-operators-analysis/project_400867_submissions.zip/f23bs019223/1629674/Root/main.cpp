// Identify and correct errors. Also comment your identified errors and corrections
#include <iostream>
using namespace std;

int main()
{
    int x, y;
    cout << "Enter input variable y: ";
    cin >> y;
    x = y;
    cout << "Value of x = " << x << endl;

    int a = 3, b = 5, c = 8;
    a += b;
    c -= b;
    cout << "\na += b: " << a;
    cout << "\nc -= b: " << c << endl;

    a *= b;
    b /= c;
    cout << "a *= b: " << a << endl;
    cout << "b /= c: " << b;

    return 0;
}
/*Here is the number of errors in program:

1) extraction operator in getting input of y variable from the user
2) Use compound assignment operator in correct way i.e a += b or c -= b and b /= c
3) I have also use some endl function to create new line for better output
*/
