// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{ 
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//extraction operators(>>) was use instead of insection operators(<<)
  x = y;
  cout<<"Value of x = "<<x<<endl;//this section("") was not close
  
  int a = 3,b = 5,c = 8;
  a =+ b;
  c =- b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;//the correct condition is (/=) instead of (=/)
  cout<<"a *= b: "<<a;
  cout<<"b /=c: "<<b;
  
  return 0;
  }


