// Identify and correct errors. Also comment your identified errors and corrections

#include<iostream>                               //space is not allowed
using namespace std;
int main()
{
  int x,y;
  cout<<"Enter input variable y:";              
  cin>>y;                                       //exertion operator
  x=y;                              
  cout<<"Value of x:"<<x<<endl;                 //missing double qoutes
  int a=3,b=5,c=8;
  a +=b;
  c -=b;                                         //wrong compound  assignment operators
  cout<<"\na+=b:"<<a;
  cout<<"\nc-=b:"<<c;
  
  a *=b;
  b /=c;
  cout<<"\na*=b:"<<a;
  cout<<"\nb/=c:"<<b;                            
 
  return 0;
  }


