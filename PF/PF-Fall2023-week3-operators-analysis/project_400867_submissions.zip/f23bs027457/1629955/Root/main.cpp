#include <iostream>
using namespace std;

int main()
{
    int x, y;

    // Issue 1: The cin line should use >> to read input into the 'y' variable.
    cout << "Enter input variable y: ";
    cin >> y;

    x = y;

    // Issue 2: The cout line should use << to display the value of 'x'.
    cout << "Value of x = " << x << endl;

    int a = 3, b = 5, c = 8;
    
    // Issue 3: The assignment operator is '+=' instead of '=+'.
    a += b;

    // Issue 4: The assignment operator is '-=' instead of '=-'.
    c -= b;

    cout << "\na += b: " << a;
    cout << "\nc -= b: " << c;

    a *= b;

    // Issue 5: The assignment operator is '*=' instead of '=*'.
    
    // Issue 6: There should be a space before '/' to separate the variables.
    b /= c;

    cout << "\na *= b: " << a;
    cout << "b /= c: " << b;

    return 0;
}



