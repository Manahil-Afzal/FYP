// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; //Insertion operator is used Instead of Extraction operator
  x = y;
  cout<<"Value of x =" <<x<<endl; //Quotation sign is Missing
  
  int a = 3,b = 5,c = 8;
  a =+ b;
  c =- b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;         //Divison Symbol shoul be used before Equality
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


