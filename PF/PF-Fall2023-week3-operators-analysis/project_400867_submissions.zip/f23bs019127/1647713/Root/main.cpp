#include <iostream>
using namespace std;

int main()
{
  int x, y;
  cout << "Enter input variable y: ";
  cin >> y; // Use '>>' instead of '<<' for input

  x = y;
  cout << "Value of x = " << x << endl; // Corrected the formatting of the output statement

  int a = 3, b = 5, c = 8;
  a += b; // Use 'a += b;' for addition
  c -= b; // Use 'c -= b;' for subtraction

  cout << "\na += b: " << a;
  cout << "\nc -= b: " << c;

  a *= b; // Use 'a *= b;' for multiplication
  b /= c; // Use 'b /= c;' for division

  cout << "a *= b: " << a;
  cout << "b /= c: " << b;

  return 0;
}
