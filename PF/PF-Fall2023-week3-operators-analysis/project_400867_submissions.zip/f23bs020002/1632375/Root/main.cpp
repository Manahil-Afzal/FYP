// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;               //inseration operator is used instead of extraction operator.
  x = y;
  cout<<"Value of x =" <<x<<endl;   // " sign is missing.
  
  int a = 3,b = 5,c = 8;
  a =+ b;   
  c =- b;   
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;       // sign / always comes in left in compount statements.
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


