// Identify and correct errors. Also comment your identified errors and corrections

// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: ";
  cin>>y;
  x = y;
  cout<<"Value of x =" <<x<<endl;  //missing closing double qoutes
  
  int a = 3,b = 5,c = 8;
  a += b;    //wrong syntax of add and assignment operator
  c -= b;    //wrong syntax of subtract assignment opertor
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;    //wrong syntax of division assignment opertor
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }





