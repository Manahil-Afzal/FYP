// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;
  //use extraction operators for input function
  x = y;
  cout<<"Value of x = "<<x<<endl;
  //use inverted commas
  
  int a = 3,b = 5,c = 8;
  a += b;
  // a =+ b should be a += b
  c -= b;
  //c =- b should be c-= b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;
  // =/ should be /=
  cout<<"\na *= b: "<<a;
  cout<<"\nb /= c: "<<b;
  
return 0;
  }



