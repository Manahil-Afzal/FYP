// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
    int x, y;
    cout << "Enter input variable y: ";
    cin >> y; // Use >> for input, not <<

    x = y;
    cout << "Value of x = " << x << endl; // Correct the output format string

    int a = 3, b = 5, c = 8;
    a = a + b; // Use += instead of =+
    c = c - b; // Use -= instead of =-

    cout << "\na += b: " << a;
    cout << "\nc -= b: " << c;

    a *= b; // Use *= for multiplication assignment
    b /= c; // Use /= for division assignment

    cout << "\na *= b: " << a;
    cout << "\nb /= c: " << b; // Added a space before the operator

    return 0;
}
