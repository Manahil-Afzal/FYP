// Identify and correct errors. Also comment your identified errors and corrections
#include<iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;
  x = y;
  cout<<"Value of x =" <<x<<endl;
  
  int a = 3,b = 5,c = 8;
  a += b;
  c -= b;
  cout<<"\na += b: "<<a<<endl;
  cout<<"\nc -= b: "<<c<<endl;
  
  a *= b;
  b /= c;
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b<<endl;
  
  return 0;
  }


