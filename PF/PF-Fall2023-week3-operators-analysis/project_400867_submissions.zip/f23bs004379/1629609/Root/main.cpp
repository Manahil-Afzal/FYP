// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//incorrect insertion operator
  x = y;
  cout<<"Value of x =" <<x<<endl;//double quotes missing
  
  int a = 3,b = 5,c = 8;
  a += b;//incorrect sequence of compound assignment opertor
  c -= b;//incorrect sequence of compound assignment opertor
  cout<<"\na += b: "<<a<<endl;
  cout<<"\nc -= b: "<<c<<endl;
  
  a *= b;
  b /= c;//incorrect sequence of compound assignment opertor
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


