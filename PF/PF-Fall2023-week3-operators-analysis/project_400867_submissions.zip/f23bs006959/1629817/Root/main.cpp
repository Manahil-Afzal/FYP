// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;       //changed cin<<y into cin>>y
  x = y;
  cout<<"Value of x = "<<x<<endl;        //Double Quatation correction
  
  int a = 3,b = 5,c = 8;
  a += b;        //changed a =+ b into a += b
  c -= b;        //changed c =- b into c -= b
  cout<<"\na += b: "<<a;         
  cout<<"\nc -= b: "<<c;         
  
  a *= b;
  b /= c;       //changed =/ into /=
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


