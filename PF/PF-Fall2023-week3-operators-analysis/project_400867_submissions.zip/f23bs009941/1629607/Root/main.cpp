// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//incorrect insertion operator
  x = y;
  cout<<"Value of x = "<<x<<endl;//incorrect use of double qoutes
  
  int a = 3,b = 5,c = 8;
  a += b;//incorrect use of compound assignment
  c -=b;//incorrect use of compound assignment
  cout<<"\na += b: "<<a<<endl;
  cout<<"\nc -= b: "<<b<<endl;
  
  a *= b;
  b/=c;//incorrect use compound assignment operator
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b<<endl;
  
  return 0;
  }


