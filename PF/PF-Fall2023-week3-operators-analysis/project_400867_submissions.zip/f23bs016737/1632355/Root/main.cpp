// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//use >> this sign instead of <<
  x = y;
  cout<<"Value of x =" <<x<<endl; 
  //missing of quates
  
  int a = 3,b = 5,c = 8;
  a += b;//+ sign should before =
  c -= b;//- sign should before =
  cout<<"\na += b: "<<a<<endl;
  cout<<"\nc -= b: "<<c<< endl;
  
  a *= b;
  b /= c;//  / sign should before =
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


