// Identify and correct errors. Also comment your identified errors and corrections

//#include <iostream>
//using namespace std;

//int main()
//{
  //int x,y;
  //cout<<"Enter input variable y: "; 
  //cin<<y;
  //x = y;
  //cout<<"Value of x = <<x<<endl;
  
  //int a = 3,b = 5,c = 8;
  //a =+ b;
 // c =- b;
  //cout<<"\na += b: "<<a;
  //cout<<"\nc -= b: "<<c;
  
  //a *= b;
  //b =/ c;
//  cout<<"a *= b: "<<a;
  //cout<<"b /= c: "<<b;
  
  //return 0;
//  }
// corected programe is here.

#include <iostream>
using namespace std;

int main()
{
  int x, y;
  cout << "Enter input variable y: "; 
  cin >> y; // Use >> instead of << for cin to input a value
  x = y;
  cout << "Value of x = " << x << endl; // Corrected the output statement
  
  int a = 3, b = 5, c = 8;
  a += b; // Use += for addition assignment
  c -= b; // Use -= for subtraction assignment
  cout << "\na += b: " << a;
  cout << "\nc -= b: " << c;
  
  a *= b; // Use *= for multiplication assignment
  b /= c; // Use /= for division assignment
  cout << "\na *= b: " << a; // Added the missing '\n' for a new line
  cout << "\nb /= c: " << b; // Added the missing '\n' for a new line
  
  return 0;
}


