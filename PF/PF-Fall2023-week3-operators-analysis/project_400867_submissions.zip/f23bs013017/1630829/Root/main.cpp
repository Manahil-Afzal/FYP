// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//here wrong angle bracket is used
  x = y;
  cout<<"Value of x =" <<x<<endl;//here sign of quotation is missed
  
  int a = 3,b = 5,c = 8;
  a += b;//here wrong assignment operator is used
  c -= b;//here wrong assignment operator is used
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;//here wrong assignment operator is used
  cout<<"b /= c: "<<b;
  
  return 0;
  }


