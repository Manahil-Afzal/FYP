// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin >> y;  // Changed "<<y" to ">> y" for input
  x = y;
  cout << "Value of x = " << x << endl;  // Fixed the cout""" statement
  
  int a = 3,b = 5,c = 8;
  a += b;  // Corrected the assignment operator
  c -= b;  // Corrected the assignment operator
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;  // Corrected the assignment operator
  b /= c;  // Corrected the assignment operator
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


