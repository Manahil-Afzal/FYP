// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;
  //Extraction operators are used in input statement
  x = y;
  cout<<"Value of x = "<<x<<endl;
  //Closing invertes commas are also necessary
  
  int a = 3,b = 5,c = 8;
  a += b;
  //a =+ b should be a+=b
  c -= b;
  //c =- b should be c-= b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;
  // =/  should be /=
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
 return 0;
  }


