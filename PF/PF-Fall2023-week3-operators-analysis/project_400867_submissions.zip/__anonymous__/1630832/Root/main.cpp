// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;
int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;// error in Assignment operator
  x = y;
  cout<<"Value of x = <<x<<endl";//Error of commas
  
  int a = 3,b = 5,c = 8;
  a += b;//errors of space and compound operator
  c -= b;//errors of space and compound operator
  cout<<"\na += b: "<<a;// error of/n and a space
  cout<<"\nc -= b: "<<c;
  
  a *= b;//errors of space and compound operator
  b /= c;//errors of space and compound operator
  cout<<"a *= b: "<<a;//error of /n
  cout<<"b /= c: "<<b;//error of /n
  
   return 0;
  }


