// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y; // << will be change into >>
  x = y;
  cout<<"Value of x ="<<x<<endl; //insertion operator was missing
  
  int a = 3,b = 5,c = 8;
  a =+ b;
  c =- b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c; // there was error in operator syntax
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


