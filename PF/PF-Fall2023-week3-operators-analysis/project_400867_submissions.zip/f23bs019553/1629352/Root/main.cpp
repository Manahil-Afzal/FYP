// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//here wrong angle bracket is used
  x = y;
  cout<<"Value of x = " <<x<<endl;// here quatation mark is missed
  int a=3,b= 5,c=8;
  a+=b;//wrong compound ASSINGMENT operator is used
  c-=b;//wrong compound ASSINGMENT operator is used
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


