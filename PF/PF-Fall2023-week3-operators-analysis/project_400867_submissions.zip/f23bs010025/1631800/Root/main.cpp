// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
    int x,y;
    cout<<"Enter input variable y:";
    cin>>y; //error: cin>>y;instead of cin<<y;
	x=y;
    cout<<"Value of x ="<<x<<endl;//it should be as cout<<"Value of x =" <<x<<endl;
    int a=3,b=5,c=8;
    a+=b; //it should be as a+=b; instead of a=+b
    c-=b; //it should be as c-=b; instead of c=-b
    cout<<"\na+=b:"<<a;
    cout<<"\nc-=b:"<<c;
    a*= b; // Correct
    b/= c; //it should be as b/=c; instead of b=/c;
    cout <<"\na*=b:"<<a;
    cout <<"\nb/=c:"<<b;

    return 0;
}