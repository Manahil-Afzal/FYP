// Identify and correct errors. Also comment your identified errors and correction
#include <iostream>
using namespace std;

int main()
{
    int x, y, a, b, c; // Declare variables x, y, a, b, and c
    cout << "Enter input variable y: ";
    cin >> y;
    x = y;
    cout << "Value of x = " << x << endl; // Correct the output statement

    a = 3, b = 5, c = 8; // Declare and initialize variables a, b, and c
    a += b;
    c -= b;
    cout << "\na += b: " << a;
    cout << "\nc -= b: " << c;

    a *= b;
    b /= c; // Correct the operator to /
    cout << "\na *= b: " << a;
    cout << "\nb /= c: " << b; // Correct the output statement

    return 0;
}


