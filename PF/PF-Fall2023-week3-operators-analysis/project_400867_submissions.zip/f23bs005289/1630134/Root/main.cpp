// Identify and correct errors. Also comment your identified errors and corrections

#include<iostream>                                 //space is not allowed
using namespace std;
int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;                                         //wrong insertion operator is use
  x = y;
  cout<<"Value of x:"<<x<<endl;                   //inverted commas are missing
  
  int a = 3,b = 5,c = 8;
  a =+ b;
  c =- b;
  cout<<"\na += b: "<<a;
  cout<<"\nc -= b: "<<c;
  
  a *= b;
  b /= c;                                       //wrong assignment operator is use
  cout<<"a *= b: "<<a;
  cout<<"b /= c: "<<b;
  
  return 0;
  }


