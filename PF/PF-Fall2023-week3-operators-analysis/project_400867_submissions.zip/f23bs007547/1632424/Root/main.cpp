// Identify and correct errors. Also comment your identified errors and corrections

#include <iostream>
using namespace std;

int main()
{
  int x,y;
  cout<<"Enter input variable y: "; 
  cin>>y;//insertion operators are wrong
  x = y;
  cout<<"Value of x ="<<x<<endl;//commas was missing
  
  int a = 3,b = 5,c = 8;
  a += b;//logic was wrong
  c -= b;//logic was wrong
  cout<<"\na += b: "<<a<<endl;
  cout<<"\nc -= b: "<<c<<endl;
  
  a *= b;
  b /= c;//logic was wrong
  cout<<"a *= b: "<<a<<endl;
  cout<<"b /= c: "<<b<<endl;
  
  return 0;
  }


