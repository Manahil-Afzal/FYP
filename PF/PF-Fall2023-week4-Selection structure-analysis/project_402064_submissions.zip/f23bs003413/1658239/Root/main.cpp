/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;
    cout<<"Input x,y,z :";
    cin>>x>>y>>z;
    if (x>y&&x>z){
        cout<<"x is large number :" <<x;
    }
     if (y>x&&y>z){
        cout<<"y is large number :" <<y;
    }
     if (z>x&&z>y){
        cout<<"z is large number :" <<z;
    }
    
    
}