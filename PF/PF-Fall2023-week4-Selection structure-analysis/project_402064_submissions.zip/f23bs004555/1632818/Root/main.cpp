/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;                                           //remove large
    cout<<"Input x,y, and z:";                          //insert semicolon in the output statement
    cin>>x>>y>>z;
    if (y>x&&y>z)                                      //remove semicolon after if condition
    cout<<"y is largest:"<<y;
    if (z>x&&z>y)
	cout<<"z is largest:"<<z;
    if(x>y&&x>z)
    cout<<"x is largest:"<<x;
    return 0;
}
