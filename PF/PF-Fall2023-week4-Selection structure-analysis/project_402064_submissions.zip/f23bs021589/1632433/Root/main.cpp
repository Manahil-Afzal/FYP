/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z:"; //EXTRA SEMICOLON USED ,//colon should be used to sincrease readability
    cin>>x>>y>>z;
    if (y > large)
    	x = large; 
    if (z > large)
	large =z; //semicolon not used
	if (x > large) //value of x should also be used 
	   x=large;
    cout<<"Largest of x, y, and z is:"<<large<<endl;
    return 0;
}
