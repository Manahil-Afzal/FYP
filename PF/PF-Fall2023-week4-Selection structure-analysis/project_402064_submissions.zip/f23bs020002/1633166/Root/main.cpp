/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z";
    cin>>x>>y>>z;
    if (x>y&&x>z)
    cout<<"x is greater:"<<x;
    else if (y>x&&y>z)
    cout<<"y is greater:"<<y;
    else if (z>x&&z>y)
    cout<<"z is greater:"<<z;
    else 
    cout<<"Numbers are equal";
    return 0;
}
