/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;
    cout<<"Input x,y and z;"<<endl;
    cin>>x>>y>>z;
    if (y > x && y>z){
        
        cout<<" y is largest number : " <<y;
    }
    if (x>y && x>z){ 
        cout<<"X is largest number : " <<x;
    }
    if (z>x && z>y){
        cout<<"z is largest number : " <<z;
    }
    return 0;

}
