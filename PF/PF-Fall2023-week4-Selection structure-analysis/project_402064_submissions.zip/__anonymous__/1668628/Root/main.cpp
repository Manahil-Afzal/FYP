/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;
    cout<<"Input x,y, and z:";
    cin>>x>>y>>z;
    if (y>y&&x>z)
    cout<<"the larger number is:"<<x<<endl;
    else if(y>x&&y>z)
    cout<<"the larger number is:"<<y<<endl;
    else
    cout<<"the larger number is:"<<z<<endl;
    
    return 0;
}
