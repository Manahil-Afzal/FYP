/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;

int main() {
    int x, y, z, large;
    
    cout << "Input x, y, and z: ";
    cin >> x >> y >> z;
    
    large = x;  // Initialize 'large' with the value of 'x'

    if (y > large)
        large = y;  // Update 'large' if 'y' is larger

    if (z > large)
        large = z;  // Update 'large' if 'z' is larger

    cout << "Largest of x, y, and z is: " << large << endl;
    
    return 0;
}






