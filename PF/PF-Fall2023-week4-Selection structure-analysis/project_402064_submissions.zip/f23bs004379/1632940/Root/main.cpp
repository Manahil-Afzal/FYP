/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z;
    cout<<"Input x,y, and z";
    cin>>x>>y>>z;
    if (y>x&&y>z)
    cout<<"The largest num is :"<<y<<endl;
    else if(x>y&&x>z)
    cout<<"The largest num is :"<<x<<endl;
    else
    cout<<"The largest num is :"<<z<<endl;
    return 0;
}
