/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main()
{
    int x, y, z, large;
    char var;
    cout << "Input x, y and z: ";
    cin >> x >> y >> z;
    // Finding the largest value
    if (x > y && x > z)
    {
        large = x;
        var = 'x';
    }
    else if (y > x && y > z)
    {
        large = y;
        var = 'y';
    }
    else
    {
        large = z;
        var = 'z';
    }
    cout << "The largest value is of " << var << ": " << large << endl;
    return 0;
}

  /* errors:
1) The conditions to determine whether an x, y, or z value is bigger than each other are all incorrect.
2) use of; following the if (y > huge) condition
3) The greatest value in x, y, and z is returned by the cout function, however it is unclear if x, y, or z is the largest value.
*/