/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large=0;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (y > x&&y>z)  //; cannot be placed here and place x instead of large
    	large = y;//assign large value in large 
    
   else if (z >x&&z>y)//use else if after if 
   {
       	large =z;
       cout<<"Largest of x, y, and z is:"<<large<<endl; 
   }

	else if(x>y&&x>z)//use another else if to check condition
	{
	    	large=x;
	          cout<<"Largest of x, y, and z is:"<<large<<endl; 
	}

	else//use else if all numbers are same
	{
	    cout<<"All numbers are equal ";
	    
	}
   
    return 0;
}
