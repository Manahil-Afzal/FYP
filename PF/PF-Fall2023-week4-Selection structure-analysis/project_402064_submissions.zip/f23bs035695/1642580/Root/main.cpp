/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;// initialize 'large' with the value of 'x' to start comparing
    if (y > large)//remove semicolon
    	x = large;//initialize the large variable with the value of x to start the comparison
    if (z > large)
	large =z;
    cout<<"Largest of x, y, and z is:"<<large<<endl;
    return 0;
}
