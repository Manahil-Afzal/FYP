/*Identify and correct errors in the following program that is meant to
take input of three numbers from user and displays the largest*/

/* Here is the list of errors in given program:

1) The conditions to check weahter the x, y or z is greater then each
   other are not correct all are not correct.
2) use of ; after the condition  if (y > large)
3) In the cout function we are getting the largest value in x, y and z
   but it is not clearing weahter the x, y or z is largest value.

*/

// The correct version of code is given as:

#include <iostream>
using namespace std;
int main()
{
    int x, y, z, large;
    char var;
    cout << "Input x, y and z: ";
    cin >> x >> y >> z;
    // Finding the largest value
    if (x > y && x > z)
    {
        large = x;
        var = 'x';
    }
    else if (y > x && y > z)
    {
        large = y;
        var = 'y';
    }
    else
    {
        large = z;
        var = 'z';
    }
    cout << "The largest value is of " << var << ": " << large << endl;
    return 0;
}
