/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;
int main(){
	int x,y,z,large;
    cout<<"Input x,y, and z;";
    cin>>x>>y>>z;
    if (x > y){
    if (x > z)
    large=x;
    cout<<large<<" is largest!";}
	else if(y >z){
	large = y;
	cout<<large<<" is largest!";}
    else{
    large = z;
    cout<<large<<" is largest!";}
    return 0;
}
