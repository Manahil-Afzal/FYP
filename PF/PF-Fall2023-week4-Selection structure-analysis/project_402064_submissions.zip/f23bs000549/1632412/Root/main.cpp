/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include <iostream>
using namespace std;

int main() 
{
    int x, y, z, large;
    cout << "Input x, y, and z: "; // Added a space after the colon
    cin >> x >> y >> z;
    large = x; // Initialize 'large' with 'x' to compare with 'y' and 'z'

    if (y > large) // Removed the semicolon after the if statement
        large = y; // Assign 'y' to 'large' if 'y' is larger

    if (z > large)
        large = z; // Assign 'z' to 'large' if 'z' is larger

    cout << "Largest of x, y, and z is: " << large << endl;
    return 0;
}
