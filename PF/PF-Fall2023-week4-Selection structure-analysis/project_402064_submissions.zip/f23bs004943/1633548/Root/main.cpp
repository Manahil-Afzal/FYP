/*Identify and correct errors in the following program that is meant to 
take input of three numbers from user and displays the largest*/

#include<iostream>
using namespace std;
int main()
{
	int x,y,z;
    cout<<"enter the value of x:"<<endl;
    cin>>x;
    cout<<"enter the value of y:"<<endl;
    cin>>y;
    cout<<"enter the value of z:"<<endl;
    cin>>z;
    if (x>y&&x>z)
    cout<<"the largest number is:"<<x<<endl;
    else if (y>x&&y>z)
    cout<<"the largest number is:"<<y<<endl;
    else
    cout<<"the largest number is:"<<z<<endl;
    return 0;
}
