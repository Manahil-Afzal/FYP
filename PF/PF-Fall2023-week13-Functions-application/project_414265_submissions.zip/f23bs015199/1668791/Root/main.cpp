/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/

   #include <iostream>
using namespace std;

// Function to calculate the average of three numbers
float calculateAverage(int num1, int num2, int num3) {
    float average = (num1 + num2 + num3) / 3.0;
    return average;
}

// Function to find the smallest number among three numbers
int findSmallest(int num1, int num2, int num3) {
    int smallest = min(min(num1, num2), num3);
    return smallest;
}

// Function to find the largest number among three numbers
int findLargest(int num1, int num2, int num3) {
    int largest = max(max(num1, num2), num3);
    return largest;
}

int main() {
    int num1, num2, num3;

    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    float average = calculateAverage(num1, num2, num3);
    int smallest = findSmallest(num1, num2, num3);
    int largest = findLargest(num1, num2, num3);

    cout << "Average: " << average << endl;
    cout << "Smallest: " << smallest << endl;
    cout << "Largest: " << largest << endl;

    return 0;
} 
    
    
    