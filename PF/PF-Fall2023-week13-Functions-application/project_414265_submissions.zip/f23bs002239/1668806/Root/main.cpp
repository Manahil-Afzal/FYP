/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;
void calculate(float a, float b, float c, float& avg, float& smallest, float& largest){
    avg=(a+b+c)/3;
    smallest=min(a,min(b,c));
    largest=max(a,max(b,c));
}
int main(){
    float a,b,c,avg,smallest,largest;
    cout<<"enter three numbers:";
    cin>>a>>b>>c;
    calculate(a,b,c,avg,smallest,largest);
    cout<<"Average"<<avg<<endl;
    cout<<"Smallest"<<smallest<<endl;
    cout<<"Largest"<<largest<<endl;
    return 0;
}