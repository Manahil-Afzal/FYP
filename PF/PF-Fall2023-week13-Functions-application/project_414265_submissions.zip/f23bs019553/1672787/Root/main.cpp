/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.&*/				
#include<iostream>
using namespace std;
int smallest (int num1,int num2,int num3);
int largest (int num1,int num2,int num3);
float avg (int num1, int num2, int num3);
int main()
{
int a,b,c;
cout<<"Enter Three Numberz"<<endl;
cin>>a>>b>>c;
 

 
cout<<"the smallest number is "<<smallest(a,b,c)<<endl;

cout<<"The Largest Number Is    "<<largest(a,b,c)<<endl;
cout<<"The Average Is "<<avg(a,b,c)<<endl;
return 0;

}
int smallest (int num1,int num2,int num3)
{
	int result;
if (num1<num2 and  num1<num3)

result=num1;
else if (num2<num1 && num2<num3)
result= num2;
else  
result =num3;
return result ;
}
int largest (int num1,int num2,int num3)
{
	int result;
if (num1>num2 and  num1>num3)

result=num1;
else if (num2>num1 && num2>num3)
result= num2;
else  
result =num3;
return result ;
}

	float avg (int num1, int num2, int num3)
	{
	
	int result;
	result =(num1+num2+num3)/3;
	return result;
}