/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>

using namespace std;

float calculateAverage(int a, int b, int c) {
    return (a + b + c) / 3.0;
}

int findSmallest(int a, int b, int c) {
    return min(a, min(b, c));
}

int findLargest(int a, int b, int c) {
    return max(a, max(b, c));
}

int main() {
    int a, b, c;
    cout << "Enter three numbers: ";
    cin >> a >> b >> c;

    cout << "Average of the numbers is: " << calculateAverage(a, b, c) << endl;
    cout << "Smallest of the numbers is: " << findSmallest(a, b, c) << endl;
    cout << "Largest of the numbers is: " << findLargest(a, b, c) << endl;

    return 0;
}