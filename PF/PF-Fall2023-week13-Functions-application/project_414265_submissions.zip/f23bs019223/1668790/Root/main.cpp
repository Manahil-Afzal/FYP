/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

using namespace std;

int main() {
    double a, b, c;

    cout << "Enter the first number: ";
    cin >> a;

    cout << "Enter the second number: ";
    cin >> b;

    cout << "Enter the third number: ";
    cin >> c;

    double smallest = min(a, min(b, c));
    double largest = max(a, max(b, c));
    double avg = (a + b + c) / 3.0;

    cout << "The smallest number is " << smallest << endl;
    cout << "The largest number is " << largest << endl;
    cout << "The average of " << a << ", " << b << ", and " << c << " is " << avg << endl;

    return 0;
}
