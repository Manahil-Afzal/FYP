/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
# include<iostream>
using namespace std;
int  ave(int a,int b,int c)
{
    int ave=(a+b+c)/3;
    cout<<"your avg number is:"<<ave<<endl;
}
 int smallest(int a,int b,int c)
 {
     if(a<b&&a<c)
     {
         cout<<"your smallest number is :"<<a<<endl;
     }
     else if(b<a&&b<c)
     {
         cout<<"your smallest number is :"<<b<<endl;
     }else
     {
         cout<<"your smallest number is :"<<c<<endl;
     }
 }int largest(int a,int b,int c)
 {
     if(a>b&&a>c)
     {
         cout<<"your number is greater:"<<a<<endl;
         
     }else if(b>a&&b>c)
     {
         cout<<"your number is greater:"<<b<<endl;
     }else
     {
         cout<<"your number is greater:"<<c<<endl;
     }
 }int main()
 {
     int num1,num2,num3;
     cout<<"enterfirst number:"<<endl;
     cin>>num1;
     cout<<"enter second number:"<<endl;
     cin>>num2;
     cout<<"enter third number:"<<endl;
     cin>>num3;
     ave(num1,num2,num3);
     smallest(num1,num2,num3);
     largest(num1,num2,num3);
 }