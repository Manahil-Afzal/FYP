/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
double avg(double num1, double num2,  double num3){
return ((num1+num2+num3)/3);}
double largest(double num1,double num2,double num3){
return max(max(num1,num2),num3);}
double smallest(double num1,double num2,double num3){
return min(min(num1,num2),num3);}
int main ()
{
	double num1,num2,num3;
	cout<<"Enter the first number: ";
	cin>>num1;
	cout<<"Enter the second number: ";
	cin>>num2;
    cout<<"Enter the third number: ";
    cin>>num3;
    double average=avg(num1,num2,num3);
    double maximum=largest(num1,num2,num3);
    double minimum=smallest(num1,num2,num3);
    cout<<"The average of three number is "<<average<<endl;
    cout<<"The largest  of three number is "<<maximum<<endl;
    cout<<"The smallest of three number is "<<minimum<<endl;
    
    return 0;
}

