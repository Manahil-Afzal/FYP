#include<iostream>
using namespace std;
float avg(int a,int b,int c)
{float avg=a+b+c/3;
cout<<"your average number is"<<avg<<endl;
}

float smallest(int a,int b,int c)
{
if(a<b&&a<c)
{
cout<<"your smallest number is"<<a<<endl;}
else if(b<a&&b<c)
{cout<<"your smallest number is"<<b<<endl;}
else
{cout<<"your smallest number is"<<c<<endl;}
}
float largest(int a,int b,int c)
{
if(a>b&&a>c)

{cout<<"your largest number is"<<a<<endl;}
else if(b>a&&b>c)
{cout<<"your largest number is"<<b<<endl;}
else
{cout<<"your largest number is"<<c<<endl;}
}

int main()
{
    int n1,n2,n3;
    cout<<"enter the first number"<<endl;
    cin>>n1;
    cout<<"enter the second number"<<endl;
    cin>>n2;
    cout<<"enter the third number"<<endl;
    cin>>n3;
    avg(n1,n2,n3);
    smallest(n1,n2,n3);
    largest(n1,n2,n3);
}
