/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
int avg(int a,int b,int c)
{
    int avg=(a+b+c)/3;
    cout<<"your avg is:"<<avg<<endl;
}
int smallest(int a,int b,int c)
{
    if(a<b&&a<c)
    {
        cout<<"your smallest number is:"<<endl;
        cout<<a;
    }
    else if(b<a&&b<c)
    {
    cout<<"your smallest number is:"<<b<<endl;
    }
    else
    cout<<"your smallest number is:"<<c<<endl;}
    int largest(int a,int b,int c)
    {
        if(a>b&&a>c)
        {
            cout<<"your largest number is:"<<a<<endl;
        }
        else if(b>a&&b>c)
        {
            cout<<"your largest number is:"<<b<<endl;
        }else
          cout<<"your largest number is:"<<c<<endl;
        
    }
int main()
{
    int num1,num2,num3;
    cout<<"enter the three number is:"<<endl;
    cin>>num1;
    cin>>num2;
    cin>>num3;
    avg(num1,num2,num3);
    smallest(num1,num2,num3);
    largest(num1,num2,num3);
return 0;}