/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers*/
#include<iostream>
using namespace std;
double getaverage(double num1,double num2,double num3){

return (num1+num2+num3)/3;}

	double getminimum(double num1,double num2,double num3){
	
	return min(min(num1,num2),num3);}
	double getmaximum(double num1,double num2,double num3){
	
return max(max(num1,num2),num3);}
int main(){
	double num1,num2,num3;
	cout<<"enter the first number";
	cin>>num1;
	cout<<"enter the second number";
	cin>>num2;
	cout<<"enter the third number";
	cin>>num3;
	double average=getaverage(num1,num2,num3);
	double smallest=getminimum(num1,num2,num3);
	double largest=getmaximum(num1,num2,num3);
	cout<<"the average is"<<average<<endl;
	cout<<"the smallest is "<<smallest<<endl;
	cout<<"the largest is"<<largest<<endl;
	return 0;}
	

