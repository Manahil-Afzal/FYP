/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;

void avg(int a,int b ,int c){
	int average;
	average=(a+b+c)/3;
	cout<<"Average of given number is "<<average<<endl;
}
void checksmallest(int a,int b,int c){
	int smallest;
	if(a<b && a<c){
		smallest=a;
		cout<<"Smallest number is "<<smallest<<endl;
	}else if(b<a && b<c){
		smallest=b;
	     cout<<"Smallest number is "<<smallest<<endl;
	}else{ smallest=c;
		cout<<"Smallest number is "<<smallest<<endl;
	}
}

void checklargest(int a,int b,int c){
	int largest;
	if(a>b && a>c){
		largest=a;
		cout<<"Largest number is "<<largest<<endl;
	}else if(b>a && b>c){
		largest=b;
	     cout<<"Largest number is "<<largest<<endl;
	}else{ largest=c;
		cout<<"Largest number is "<<largest<<endl;
	}
}
int main(){
	int num1,num2,num3;
	cout<<"Enter First number ";
	cin>>num1;
	cout<<"Enter Second number ";
	cin>>num2;
	cout<<"Enter Third number ";
	cin>>num3;
	checksmallest(num1,num2,num3);
	checklargest(num1,num2,num3);
	avg(num1,num2,num3);
}