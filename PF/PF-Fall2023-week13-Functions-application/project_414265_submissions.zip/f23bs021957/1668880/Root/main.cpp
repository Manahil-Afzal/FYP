#include <iostream>
using namespace std;
int avg(int a ,int b,int c)
{
    int avg=(a+b+c)/3;
    cout<<"your avrage is:"<<avg<<endl;
}
int samalest(int a,int b,int c)
{
    if(a<b&&a<c){
    cout<<"samalest number is:"<<a<<endl;}
    else if(b<a&&b<c)
   { cout<<"samalest number is:"<<b<<endl;}
    else
   { cout<<"samalest number is:"<<c<<endl;}
}
int largest(int a,int b,int c)
{
    if(a>b&&a>c){
    cout<<"lagest number is:"<<a<<endl;}
    else if(b>a&&b>c)
   { cout<<"largest number is:"<<b<<endl;}
    else
    cout<<"largest number is:"<<c<<endl;
    
}
int main()
{
    int a,b,c;
    cout<<"Enter your first number:";
    cin>>a;
    cout<<"Enter your second number:";
    cin>>b;
    cout<<"Enter your third number:";
    cin>>c;
    avg(a,b,c);
    largest(a,b,c);
    samalest(a,b,c);
}