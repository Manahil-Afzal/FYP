#include<iostream>
using namespace std;

 int large(int num1 , int num2 , int num3){
 int largest;
     if(num1>num2 && num1>num3){
          largest=num1;
     }
     else if(num2>num3 && num2>num1){
     	largest=num2;
	 }
	 else{
          largest= num3;
	 }
	 return largest;
}
int small(int num1, int num2, int num3){
int small;
	 if(num1<num2 && num1<num3){
          small=num1;
     }
     else if(num2<num3 && num2<num1){
     	small=num2;
	 }
	 else{
     	small=num3;
	 }
	 return small;
	 
}
float avg(int num1 , int num2, int num3)
{
	 float average,sum;
	 sum=num1+num2+num3;
	 average=sum/3;
	 return average;
}

int main(){
      int a,b,c,smallest,largest;
      float average;
      cout<<"Enter the first number :" ;
      cin>>a;
      cout<<"Enter the second number :" ;
      cin>>b;
      cout<<"Enter the third number :" ;
      cin>>c;
      smallest=small(a,b,c);
      cout<<"smallest is : "<<small(a,b,c)<<endl;
      largest=large(a,b,c);
      cout<<"largest is : "<<large(a,b,c)<<endl;
      average=avg(a,b,c);
      cout<<"average is : "<<avg(a,b,c)<<endl;
      return 0;
    
} 