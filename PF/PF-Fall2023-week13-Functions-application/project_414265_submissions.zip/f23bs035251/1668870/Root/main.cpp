/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
int avg(int num1,int num2, int num3){
    int avg=(num1+num2+num3)/3;
    return avg;
}
int min(int num1,int num2,int num3){
    int result;
    if(num1<num2)
    result=num1;
    if(num2<num3)
    result=num2;
    if( num1<num3)
    result=num1;
    return result;
    
}
int max(int num1,int num2,int num3){
    int result;
    if(num1>num2)
    result=num1;
    if(num2>num3)
    result=num2;
    if(num3>num1)
    result=num3;
    return result;
}

int main(){
    int a,b,c;
    cout<<"enter first number";
    cin>>a;
    cout<<"enter second number";
    cin>>b;
    cout<<"enter third number";
    cin>>c;
    cout<<avg(a,b,c)<<endl;
    cout<<min(a,b,c)<<endl;
    cout<<max(a,b,c)<<endl;
}