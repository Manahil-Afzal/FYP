
#include <iostream>

using namespace std;

void average(int a, int b, int c) {
  float avg = (a + b + c) / 3.0;
  cout << "The average of " << a << ", " << b << ", and " << c << " is " << avg << endl;
}

void smallest(int a, int b, int c) {
  int smallest;

  if (a <= b && a <= c) {
    smallest = a;
  } else if (b <= a && b <= c) {
    smallest = b;
  } else {
    smallest = c;
  }

  cout << "The smallest of " << a << ", " << b << ", and " << c << " is " << smallest << endl;
}

void largest(int a, int b, int c) {
  int largest;

  if (a >= b && a >= c) {
    largest = a;
  } else if (b >= a && b >= c) {
    largest = b;
  } else {
    largest = c;
  }

  cout << "The largest of " << a << ", " << b << ", and " << c << " is " << largest << endl;
}

int main() {
  int a, b, c;

  cout << "Enter three numbers: ";
  cin >> a >> b >> c;

  average(a, b, c);
  smallest(a, b, c);
  largest(a, b, c);

  return 0;
}