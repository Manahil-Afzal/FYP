/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
float average(int a,int b,int c);
int largest(int a,int b,int c);
int smallest(int a,int b,int c);
int main(){
	int n, m, o;
	int small,large;
	cout<<"Enter first number: "<<endl;
	cin>>n;
	cout<<"Enter second number: "<<endl;
	cin>>m;
	cout<<"Enter third number: "<<endl;
	cin>>o;
	average(n,m,o);
	large=largest(n,m,o);
	cout<<"largest is "<<large<<endl;
	small=smallest(n,m,o);
	cout<<"smallest is "<<small;
	
	return 0;
}float average(int a, int b,int c){
	float avg;
	avg = (float) (a+b+c)/3;
	cout<<"Average is "<<avg<<endl;
}
int largest(int a,int b,int c){
    int large;
    	if(a>b && a>c){
		large=a;
	}else if(b>a && b>c){
		large=b;
	}else{
		large=c;
	}
    return large;
}
	int smallest(int i,int k,int j){
	    int small;
	    	if(i<k && i<j){
	    small=i;
	}else if(k<i && k<j){
	    small=k;
	}else{
	    small=j;
	}
	return small;
}