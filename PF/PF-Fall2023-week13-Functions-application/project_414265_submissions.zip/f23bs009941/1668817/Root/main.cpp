/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;

float avg(int a,int b,int c)
{
    int sum;
float avg;
sum =a+b+c;
    avg=sum/3;
    return avg;
    
}
int small(int a,int b,int c)
{
int min;
if(a<b&&a<c)
min=a;
 else if(b<a&&b<c)
 min =b;
 else
 min=c;
 return min;
}
int large(int a,int b,int c)
{
    int max;
    if(a>b&&a>c)
    max=a;
    else if(b>a&&b>c)
    max=b;
    else
    max=c;
    return max;
    
}
int main()
{
int a,b,c;
cout<<"enter the value ";
cin>>a>>b>>c;
cout<<"The max no is"<<large(a,b,c)<<endl<<"the min no is"<<small(a,b,c)<<endl<<"the average is"<<avg(a,b,c)<<endl;
return 0;}