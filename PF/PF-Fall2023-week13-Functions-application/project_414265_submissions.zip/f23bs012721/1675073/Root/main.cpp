/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/

#include <iostream>
using namespace std;
int ave(int a ,int b ,int c)
{
int ave=(a+b+c)/3;
cout<<"Your average number is :"<<ave<<endl;
}
int smallest(int a,int b,int c)
{
    if(a<b&&a<c)
    {
        cout<<"your Smallest number is :"<<a<<endl;
    }
    else if(b<a&&b<c)
    {
         cout<<"Your Smallest number is :"<<b<<endl;
    }
    else
    {
         cout<<"your Smallest number is :"<<c<<endl;
    }
}
int largest(int a,int b,int c)
{
    if(a>b&&a>c)
    {
        cout<<"your greater number is :"<<a<<endl;
    }
    else if(b>a&&b>c)
    {
         cout<<"Your greater number is :"<<b<<endl;
    }
    else
    {
         cout<<"your greater number is :"<<c<<endl;
    }
}

int main()
{
    int num1,num2,num3;
    cout<<"Enter your first number :"<<endl;
    cin>>num1;
       cout<<"Enter your second number :"<<endl;
    cin>>num2;
       cout<<"Enter your third number :"<<endl;
    cin>>num3;
    ave(num1,num2,num2);
    smallest(num1,num2,num3);
    largest(num1,num2,num3);

}