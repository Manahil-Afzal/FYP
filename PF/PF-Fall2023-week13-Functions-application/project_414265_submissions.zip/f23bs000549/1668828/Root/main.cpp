/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
float ave(int a,int b,int c)
{
float ave=(a+b+c)/3;
cout<<"Your average number is: "<<ave<<endl;
}
int smallest(int a,int b,int c)
 {	
 if(a<b&&a<c)
  { 	
      cout<<"Your smallest number is: "<<a<<endl;
  }
else if(b<a&&b<c)
 {	
    cout<<"Your smallest number is: "<<b<<endl;
 }
else
 {
    cout<<"Your smallest number is: "<<c<<endl;
 }
}
int largest(int a,int b,int c)
{
	if(a>b&&a>c)
 { 	
 	cout<<"Your greater number is: "<<a<<endl;
 }
else 	if(b>a&&b>c)
{	
	cout<<"Your greater number is: "<<b<<endl;
}
else
{
	cout<<"Your greater number is: "<<c<<endl;
}
}
int main()
{ int n1,n2,n3;
cout<<"Enter first number"<<endl;
cin>>n1;
cout<<"Enter second number"<<endl;
cin>>n2;
cout<<"Enter third number"<<endl;
cin>>n3;
ave(n1,n2,n3);
smallest(n1,n2,n3);
largest(n1,n2,n3);
}