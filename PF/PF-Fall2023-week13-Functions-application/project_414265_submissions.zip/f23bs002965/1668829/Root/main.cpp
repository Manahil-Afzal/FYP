/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;

void calculate(double num1, double num2, double num3, double& avg, double& smallest, double& largest) {
    avg = (num1 + num2 + num3) / 3;
    smallest = num1;
    largest = num1;
    if (num2 < smallest) {
        smallest = num2;
    }
    if (num3 < smallest) {
        smallest = num3;
    }
    if (num2 > largest) {
        largest = num2;
    }
    if (num3 > largest) {
        largest = num3;
    }
}

void display(double avg, double smallest, double largest) {
    cout << "Average: " << avg << endl;
    cout << "Smallest: " << smallest << endl;
    cout << "Largest: " << largest << endl;
}

int main() {
    double num1, num2, num3, avg, smallest, largest;
    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;
    calculate(num1, num2, num3, avg, smallest, largest);
    display(avg, smallest, largest);
    return 0;
}
