/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;
int avg(int a,int b,int c)
{
    float d,avg;
    d=a+b+c;
    avg=d/3;
    cout<<"Average is :"<<avg<<endl;
    return avg;
    
}
int smallest(int x,int y,int z)
{
     if(x<y &&x<z)
    cout<<"Smaller Number is :"<<x<<endl;
    else if(y<x &&y<z)
    cout<<"Smaller number is :"<<y<<endl;
    else if(z<x && z<y)
    cout<<"Smaller number is :"<<z<<endl;
    return 0;}
    
    
float large(float a,float b,float c)
 {
      if(a>b && a>c)
    cout<<"Greater Number is :"<<a<<endl;
    else if(b>a && b>c)
    cout<<"Greater number is :"<<b<<endl;
    else if(c>a && c>b)
    cout<<"Greater number is :"<<c<<endl;
    return 0;  
    }
int main() {
    
    int x,y,z;
    cout<<"Enter the Numbers :";
    cin>>x>>y>>z;
    avg(x,y,z);
   smallest(x,y,z);
   large(x,y,z);
    return 0;
}
 