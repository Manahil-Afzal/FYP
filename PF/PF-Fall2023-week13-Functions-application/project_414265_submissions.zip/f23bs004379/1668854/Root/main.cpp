/*Write a program that inputs 10 integers in an array. It passes all elements of the array to a function one by one. 
The function displays the actual value of the element and its square.*/
#include<iostream>
using namespace std;
void displaysquare(int num)
{
    cout<<"The actual value is:"<<num<<endl;
    cout<<"The square of"<<num<<"is:"<<num*num<<endl;
}
int main()
{
    int arr[10],i;
    cout<<"Enetr an integer:";
    for(i=0;i<10;i++)
    cin>>arr[i];
for(i=0;i<10;i++)
displaysquare(arr[i]);
return 0;
}