/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
float average(int a,int b,int c)
{
    int d;
  d=a+b+c;
  return d/3;
}
int max(int a,int b,int c)
{
    int ret;
    if(a>b&&a>c){
    ret=a;
    }
    else if(b>a&&b>c)
    {
        ret=b;
    }
    else
    ret=c;
    return ret;
}
int min(int a,int b,int c)
{
    int ret;
    if(a<b&&a<c)
    {
        ret=a;
    }
    else if(b<c&&b<a)
    {
        ret=b;
    }
    else
    ret=c;
    return ret;
}
int main(){
int num1,num2,num3,maxno,minno;
float avg;
cout<<"Enter three numbers:";
cin>>num1>>num2>>num3;
maxno=max(num1,num2,num3);
minno=min(num1,num2,num3);
avg=average(num1,num2,num3);
cout<<"The max no is"<<maxno<<endl<<"The min no is"<<minno<<endl<<"the avg of 3 no is"<<avg<<endl;
return 0;
}