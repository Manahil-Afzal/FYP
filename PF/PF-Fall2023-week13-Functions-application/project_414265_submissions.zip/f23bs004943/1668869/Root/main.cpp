/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
double avg( double num1, double num2, double  num3)
{
return ((num1+num2+ num3)/3);}
double largest( double num1, double num2,double num3){
return max( max (num1,num2),num3);}
double smallest( double num1, double num2, double  num3){
return min( min (num1,num2),num3);}
int main()
{
	double num1,num2,num3;
	cout<<"enter the first number : ";
	cin>>num1;
	cout<<"enter the second number :";
	cin>>num2;
	cout<<"enter the third number : ";
	cin>>num3;
	double average=avg( num1,num2, num3);
	double maximum= largest(  num1,  num2, num3);
	double  minimum=smallest( num1, num2, num3);
	cout<<"the average is: "<<average<<endl;
	cout<<"the largest number is:  "<<maximum<<endl;
	cout<<"the smallest number is: "<<minimum<<endl;
	return 0;
	
}