/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/

#include<iostream>
using namespace std;


float avg(float num1,float num2, float num3)
{
	return((num1+num2+num3)/3);
}
float largest(float num1,float num2, float num3)
{
	return max(max(num1,num2),num3);
}
float smallest(float num1,float num2, float num3)
{
	return min(min(num1,num2),num3);
}
int main()
{
	float num1,num2,num3;
	cout<<"Enter a number ";
	cin>>num1;
	cout<<"Enter a number ";
	cin>>num2;
	cout<<"enter a number ";
	cin>>num3;
float average=avg(num1,num2,num3);
float maximum=largest(num1,num2,num3);
float minimum=smallest(num1,num2,num3);
cout<<"The average is "<<average<<"\n";
cout<<"The largest is "<<maximum<<"\n";
cout<<"The smallest is "<<minimum<<"\n";
return 0;

}


 
  