/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
float avg(int, int, int);
int snl(int, int, int);
using namespace std;
int main()
{
    int first, second, third, average;
    cout<<"Enter First number:"<<endl;
    cin>>first;
    cout<<"Enter Second number:"<<endl;
    cin>>second;
    cout<<"Enter Third number:"<<endl;
    cin>>third;
    average=avg(first,second,third);
    cout<<"The average of these numbers="<<average<<endl;
    snl(first,second,third);
    
    
    return 0;
}
float avg(int a, int b, int c)
{
    int sum;
    float ave;
    sum=a+b+c;
    ave=sum/3;
    
    return ave;
}
int snl(int a, int b, int c)
{
    if(a>b)
    {
        if(a>c)
        cout<<a<<" is greater"<<endl;
        else
        cout<<c<<" is greater"<<endl;
    }else{
        cout<<b<<" is greater"<<endl;
    }
    return 0;
    
}