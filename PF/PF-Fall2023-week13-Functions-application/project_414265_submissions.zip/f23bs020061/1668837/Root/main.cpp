/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
float avg(float a, float b, float c ){
    float avg =(a+b+c)/3;
    cout<<"average of numbers is "<<avg;
}
float largest(float a,float b,float c){    
	if(a>b&&a>c){
		cout<<"largest number="<<a;
	}else if(b>a&&b>c){
		cout<<"largest number="<<b;
	}else{
		cout<<"largest nummber="<<c;
	}}
	float smallest(float a, float b, float c){
	if(a<b&&a<c){
		cout<<"smalest number"<<a;
	}else if(b<a&&b<c){
	
		cout<<"smallest number"<<b;
	}else{
		cout<<"smallest number"<<c;}
	    	return 1;
	}
	int main(){
	int a,b,c;
	cin>>a>>b>>c;
avg(a,b,c);
largest(a,b,c);
smallest(a,b,c);
	
}