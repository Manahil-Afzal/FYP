/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include <iostream>
using namespace std;


double calculateAverage(double a, double b, double c) {
    return (a + b + c) / 3.0;
}


double findSmallest(double a, double b, double c) {
    return min(min(a, b), c);
}

double findLargest(double a, double b, double c) {
    return max(max(a, b), c);
}

int main() {
    double num1, num2, num3;

    cout << "Enter three numbers: ";
    cin >> num1 >> num2 >> num3;

    
    cout << "Average: " << calculateAverage(num1, num2, num3) << endl;

    
    cout << "Smallest: " << findSmallest(num1, num2, num3) << endl;

    
    
    cout << "Largest: " << findLargest(num1, num2, num3) << endl;

    return 0;
}
