/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
using namespace std;
int average(int a, int b, int c) {
    //int a,b,c;
    return (a+ b + c ) /3;
}
//int smallest( int s1, s2,s3){
//	if()
int smallest(int s1, int s2, int s3) {
	if(s1<s2 && s1<<s3) {
		return s1;
}
	else if( s2<s3 && s2<s1) {
		return s2;
	}
	else 
		return s3;
}
int largest(int l1, int l2, int l3) {
	if(l1>l2 && l1>l3) {
		return l1;
}
	else if( l2>l1 && l2>l3) {
		return l2;
	}
	else 
		return l3;
}
int main() {
	int num1, num2, num3;
	cout<<"Enter numbers one by one"<<endl;
    cin>>num1 >>num2>>num3;
    int avg =  average (num1,  num2,  num3);
   cout<<"the average is : "<<avg<<endl;
   int small = smallest(num1,num2,num3);
    cout<<"Smallest num: "<<small<<endl;
    int large = largest(num1,num2,num3);
    cout<<"The largest is: "<<large;
    return 0;
}