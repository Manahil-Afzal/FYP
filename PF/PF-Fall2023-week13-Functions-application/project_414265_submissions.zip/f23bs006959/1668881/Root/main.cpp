/*Write a program that inputs three numbers in main function.
The program implements three functions to calculate and display the average, smallest and largest of those numbers.*/
#include<iostream>
float avg(int, int, int);
int small(int, int, int);
int large(int, int, int);
using namespace std;
int main()
{
	int num1, num2, num3;
	float average;
	cout<<"Enter First Number:"<<endl;
	cin>>num1;
	cout<<"Enter Second Number"<<endl;
	cin>>num2;
	cout<<"Enter Third Number"<<endl;
	cin>>num3;
	average=avg(num1,num2,num3);
	cout<<"The average of the numbers ="<<average<<endl;
	small(num1,num2,num3);
	cout<<endl;
	large(num1,num2,num3);
	return 0;
	
}
float avg(int a,int b, int c)
{
	int sum;
	float ave;
	sum=a+b+c;
	ave=sum/3;
	return ave;
	
}
int large(int a, int b, int c)
{
	if(a>b)
	{
		if(a>c)
		cout<<a<<" is greater";
		else
		cout<<c<<" is greater";
	}else{
		cout<<b<<" is greater";
	}
}
int small(int a, int b, int c)
{

    if(a<b)
	{
		if(a>c)
		cout<<c<<" is smaller";
		else
		cout<<a<<" is smaller";
	}else{
		cout<<b<<" is smaller";}
	return 0;
	}
	