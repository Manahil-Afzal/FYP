//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
# include <iostream>
using namespace std;

int main()
{
    int a, b;
    cout<<"Enter the first number: ";
    cin>>a;
    cout<<"Enter the second number: ";
    cin>>b;
    // Subtracting a and b 
    cout<<"Value of a subtract b is: "<< a - b;
}