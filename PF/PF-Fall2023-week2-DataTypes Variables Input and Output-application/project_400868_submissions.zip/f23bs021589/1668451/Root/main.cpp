//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.#include <iostream>
#include <iostream>
using namespace std;

int main() {
    // Declare variables to store user inputs
    int firstNumber, secondNumber;

    // Get user input for the first number
    cout << "Enter the first number: ";
    cin >> firstNumber;

    // Get user input for the second number
    cout << "Enter the second number: ";
    cin >> secondNumber;

    // Calculate the result by subtracting the first number from the second number
    int result = secondNumber - firstNumber;

    // Display the result
    cout << "Result after subtracting first number from second number: " << result << endl;

    return 0;
}

