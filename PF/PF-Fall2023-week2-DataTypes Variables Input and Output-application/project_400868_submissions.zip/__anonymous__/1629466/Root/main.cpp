//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number
#include<iostream>
using namespace std;
int main( )
{
    int a;
    int b;
    cout<<"enter the value of a";
    cin>>a;
    cout<<"enter the value of b";
    cin>>b;
    cout<<a-b;
}