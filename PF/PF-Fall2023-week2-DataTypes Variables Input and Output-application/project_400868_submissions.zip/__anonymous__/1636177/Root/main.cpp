//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;

int main()
{
    int a;
    int b;
    cout<<"Enter the first number ";
    cin>>a;
    cout<<"Enter the second number ";
    cin>>b;
    
    int subtract;
    subtract = a-b;
    cout<<"The value of subtraction is "<<subtract;
    
return 0;
}