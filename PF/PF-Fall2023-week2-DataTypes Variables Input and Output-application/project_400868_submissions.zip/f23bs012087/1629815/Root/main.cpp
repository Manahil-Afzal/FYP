#include<iostream>
using namespace std;
int main()
{
    int num1,num2,result;
    
    cout << "Enter the first integer = ";
    cin >> num1;
    
    cout << "Enter the second integer = ";
    cin >> num2;
    
    result= num2-num1;
    
    cout << "The result of subtracting " << num1 << " from " << num2 << " is: " << result << endl;
    return 0;
}
