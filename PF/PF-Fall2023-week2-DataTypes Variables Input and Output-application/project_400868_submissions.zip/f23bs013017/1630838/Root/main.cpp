//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number
#include<iostream>
using namespace std;
int main()
{
    int a,b,result;
    cout<<"enter first number :"<<endl;
    cin>>a;
      cout<<"enter second number :"<<endl;
    cin>>b;
    result=b-a;
    cout<<"your result is :"<<result;
    
}