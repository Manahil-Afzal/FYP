#include<iostream>
using namespace std;
main()
{
    int number1=0;
    int number2=0;
    int subtract;
    cout<<"Enter number1:"<<number1<<endl;
    cin>>number1;
    cout<<"Enter number2:"<<number2<<endl;
    cin>>number2;
    subtract=number2-number1;
    cout<<"Enter the result="<<subtract;
}//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.u