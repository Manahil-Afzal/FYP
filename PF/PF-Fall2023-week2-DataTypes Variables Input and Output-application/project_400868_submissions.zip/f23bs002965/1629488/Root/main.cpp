//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main(){
    int num1,num2, result;
    cout<<"Enter first number:";
    cin>> num1;
    cout<<"Enter second number:";
    cin>> num2;
    //Result after subtracting first number from second number.
    result= num2-num1;
    cout<<"Dispay the result of two numbers:"<< result<<endl;
}