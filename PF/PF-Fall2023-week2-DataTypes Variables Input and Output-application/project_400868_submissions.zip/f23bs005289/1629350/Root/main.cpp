//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int x;
    int y;
    int sub;
    cout<<"Enter the value for x=";
    cin>>x;
    cout<<"Enter the value for y=";
    cin>>y;
    sub=y-x;
    cout<<"Sub of y and x is="<<sub<<endl;
}