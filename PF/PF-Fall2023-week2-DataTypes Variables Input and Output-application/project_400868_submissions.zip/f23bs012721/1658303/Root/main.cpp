//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>

using namespace std;

int main() {
    int firstNumber, secondNumber;

    cout << "Enter the first integer: ";
    cin >> firstNumber;

    cout << "Enter the second integer: ";
    cin >> secondNumber;

    int result = secondNumber - firstNumber;

    cout << "Result of subtracting the first number from the second number: " << result << endl;

    return 0;
}