//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int firstnumber,secondnumber,subtraction;
    cout<<"enter first number:";
    cin>>firstnumber;
    cout<<"enter second number:";
    cin>>secondnumber;
    subtraction=firstnumber-secondnumber;
    cout<<subtraction;
    
}
