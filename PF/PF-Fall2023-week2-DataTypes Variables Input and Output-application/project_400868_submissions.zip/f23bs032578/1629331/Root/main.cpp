//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
	int a,b;
	cout<<"enter first integer:";
	cin>>a;
	cout<<"enter second integer:";
	cin>>b;
	cout<<b-a;
	return 0;
}