//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;

main() {
    int x;
    int y;
    int subtract;
    
    cout << "Please Enter First number" << endl;
    cin >> x;
    
    cout << "Please Enter Second number" << endl;
    cin >> y;
    
    subtract = y - x;
    
    cout << "The value of numbers after subtracting first number from the second number is: " << subtract << endl;
}
