//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int n1,n2,difference;
    cout<<"Enter the value of num1 and num2 :"<<endl;
    cin>>n1>>n2;
    difference=n2-n1;
    cout<<"the difference of two number is:"<<difference <<endl;
}