//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int a,b;
    int difference;
    cout<<"enter first variable:"<<endl;
    cin>>a;
    cout<<"enter second variable:"<<endl;
    cin>>b;
    difference=b-a;
    cout<<"The difference is:"<<difference;
    return 0;
    
    
}