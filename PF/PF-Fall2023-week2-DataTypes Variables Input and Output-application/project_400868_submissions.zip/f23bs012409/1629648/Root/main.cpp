//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
int x,y,subtraction;
cout<<"enter 1st integer=";
cin>>x;
cout<<"enter 2nd integer=";
cin>>y;
subtraction=x-y;
cout<<"subtraction="<<subtraction;
}