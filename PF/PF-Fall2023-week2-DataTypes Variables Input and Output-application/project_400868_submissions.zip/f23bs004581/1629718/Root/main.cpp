//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
       int var_1;
    int var_2;
    cout<<"Enter the first integer ";
    cin>>var_1;
    cout<<"Enter the second integer ";
    cin>>var_2;
    int subtract = var_2 - var_1;
    cout<<"the subtraction of two integer is " <<subtract<< endl;

}