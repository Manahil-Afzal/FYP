//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;

int main()
 {
    int num1, num2;

    // Prompt the user to enter the first number
    cout << "Enter the first number: ";
    cin >> num1;

    // Prompt the user to enter the second number
    cout << "Enter the second number: ";
    cin >> num2;

    // Calculate the result by subtracting num1 from num2
    int result = num2 - num1;

    // Display the result
    cout << "Result: " << result;

    return 0;
}