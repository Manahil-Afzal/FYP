//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x;
    int y;
    int sum;
    cout<<"Enter First Number=";
    cin>>x;
    cout<<"\nEnter Second Number=";
    cin>>y;
    sum=x+y;
    cout<<"\nSum of these integars="<<sum;
    
    return 0;
}