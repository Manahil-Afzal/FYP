//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
	int x;
	int y;
	cout<<"*****Enter first number*****"<<endl;
	cin >>x;
	cout<<"*****Enter second number*****"<<endl;
	cin >>y;
	int z=y-x;
	cout<<"subtraction of first number from second number is:"<<z<<endl;	
}
