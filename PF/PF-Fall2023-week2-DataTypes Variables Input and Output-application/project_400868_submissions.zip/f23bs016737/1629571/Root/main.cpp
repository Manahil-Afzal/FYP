//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;
int main()
{
    int firstNo,secondNo,Answer;
    cout<<"Enter first number :"<<endl;
    cin>>firstNo;
    cout<<"Enter second number :"<<endl;
    cin>>secondNo;
    Answer=secondNo-firstNo;
    cout<<"Your answer after subtracting first number from second number is: "<<Answer;
    return 0;
    
}