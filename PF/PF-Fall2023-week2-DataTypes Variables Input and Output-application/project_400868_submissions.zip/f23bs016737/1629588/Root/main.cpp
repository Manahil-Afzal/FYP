//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;
int main()
{
    int Number1,Number2,val;
    cout<<"Enter first number :"<<endl;
    cin>>Number1;
    cout<<"Enter second number :"<<endl;
    cin>>Number2;
    val=Number2-Number1;
    cout<<"Your answer after subtracting first number from second number : "<<val;
}