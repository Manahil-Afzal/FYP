//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
    int number1;
    int number2;
    int subtract;
    subtract=number2-number1;
    cout<<"enter number1";
    cin >>number1;
    cout<<"enter number2";
    cin>>number2;
    cout<<"subtractis"<<subtract<<endl;
}