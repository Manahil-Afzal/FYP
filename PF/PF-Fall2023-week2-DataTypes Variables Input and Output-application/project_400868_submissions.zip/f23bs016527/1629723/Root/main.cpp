//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
 main(){
     float first_int,second_int,subtraction;
     
     cout<<"Enter First Integer : ";
     cin>>first_int;
     
     cout<<"Enter Second Integer : ";
     cin>>second_int;
     
     subtraction=second_int- first_int;
     
     cout<<"Subtraction = "<<subtraction;
     
     return 0;
 }
 