//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int a;
    int b;
    cout<<"ENTER YOUR FIRST NO: ";
    cin>>a;
    cout<<"ENTER YOUR SECOND N0: ";
    cin>>b;
    cout<<b-a;
}