//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
main()
{
int a,b,difference;
cout<<"enter first number:";
cin>>a;
cout<<"enter second number:";
cin>>b;
difference=b-a;
cout<<"the difference is: "<<difference<<endl;

}