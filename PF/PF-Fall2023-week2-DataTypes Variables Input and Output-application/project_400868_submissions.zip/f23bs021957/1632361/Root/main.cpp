//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>

using namespace std;

int main() {
    int num1, num2;


    cout << "Enter the first integer: ";
    cin >> num1;

  
    cout << "Enter the second integer: ";
    cin >> num2;


    int result = num2 - num1;

 
    cout << "Result of subtraction: " << result << endl;

    return 0;
}