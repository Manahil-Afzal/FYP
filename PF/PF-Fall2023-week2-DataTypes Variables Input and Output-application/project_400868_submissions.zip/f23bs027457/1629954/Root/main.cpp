#include<iostream>

int main()
{
    int num1, num2, result;

    std::cout << "Enter the first integer: ";
    std::cin >> num1;

    std::cout << "Enter the second integer: ";
    std::cin >> num2;

    result = num2 - num1;

    std::cout << "Result of " << num2 << " - " << num1 << " is: " << result;

    return 0;
}
