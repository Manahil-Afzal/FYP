#include<iostream>
using namespace std;
int main()
{
	int x,y,z;
	cout<<"enter first integer number:";
	cin>>x;
	cout<<"enter second integer number:";
	cin>>y;
	z=x-y;
	cout<<"z:"<<z;
}//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.