#include <iostream>
using namespace std;

int main() {
    int firstNumber, secondNumber, result;

    // Input the two numbers
    cout << "Enter the first number: ";
    cin >> firstNumber;

    cout << "Enter the second number: ";
    cin >> secondNumber;

    // Subtract the first number from the second number
    result = secondNumber - firstNumber;

    // Display the result
    cout << "Result of subtracting the first number from the second number: " << result << endl;

    return 0;
}
