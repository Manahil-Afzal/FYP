//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second numbe
#include <iostream>
using namespace std;

int main()
 {
    int num1, num2;

    
    cout << "Enter the first number: ";
    cin >> num1;

    
    cout << "Enter the second number: ";
    cin >> num2;

    
    int result = num2 - num1;

    
    cout << "Result: " << result;

    return 0;
}