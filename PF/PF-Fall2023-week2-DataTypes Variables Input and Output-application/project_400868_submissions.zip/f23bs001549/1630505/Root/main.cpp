//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>

using namespace std;

int main() {
    int firstNumber, secondNumber, result;

    cout << "Enter the first number: ";
    cin >> firstNumber;

    cout << "Enter the second number: ";
    cin >> secondNumber;

    result = secondNumber - firstNumber;

    cout << "Result of subtraction: " << result << endl;

    return 0;
}
