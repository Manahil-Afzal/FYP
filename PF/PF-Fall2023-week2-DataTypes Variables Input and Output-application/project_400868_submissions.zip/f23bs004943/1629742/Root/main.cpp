//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
	int x,y,z;
	cout<<"Enter first integer:";
	cin>>x;
	cout<<"Enter second integer:";
	cin>>y;
	z=x-y;
	cout<<"z:"<<z;
}