//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main()
{
    int x,y;
    cout<<"Enter The Value of x:";
    cin>>x;
    cout<<"Enter The value of y:";
    cin>>y;
    cout<<y-x;
    return 0;
}