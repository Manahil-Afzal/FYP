//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include <iostream>
using namespace std;

int main()
{
    int firstnumber;
    int secondnumber;
    int ans;
    
    cout << "Enter the value of first number: ";
    cin >> firstnumber;
    
    cout << "Enter the value of second number: ";
    cin >> secondnumber;
    
    ans = secondnumber - firstnumber; 
    
    cout << "The answer of this subtraction is " << ans << endl;
    
    return 0;
}
