//Write a C++ program that takes two integer inputs from users and displays the result after subtracting first number from second number.
#include<iostream>
using namespace std;
int main ()
{
    int a, b, difference;
    cout<<"Enter first variable:"<<endl;
    cin>>a;
    cout<<"Enter second variable:"<<endl;
    cin>>b;
    difference=b-a;
    cout<<"The difference is:"<<difference;
    return 0;
    
}