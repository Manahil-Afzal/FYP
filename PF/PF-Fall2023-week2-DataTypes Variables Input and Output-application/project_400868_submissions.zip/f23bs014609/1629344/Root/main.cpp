#include<iostream>
using namespace std;
int main(){
    int a;
    int b;
    int result;
    cout<<"Enter 1st number:";
    cin>>a;
    cout<<"Enter 2nd number:";
    cin>>b;
    result=b-a;
    cout<<"Result is :"<<result;
}