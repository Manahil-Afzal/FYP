/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the word length"<<endl;
    cin>>n;
    char arr[n];
    char *ptr;
    cout<<"enter the word:";
    cin>>arr;
    ptr=arr;
    cout<<endl;
    if(ptr[1]==ptr[n-2]&&ptr[0]==ptr[n-1]&&ptr[2]==ptr[n-3])
    cout<<"This is palindrome";
    else
    cout<<"This is not palindrome";
    return 0;
}