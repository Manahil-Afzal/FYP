#include <iostream>
using namespace std;

int main() {
    int size;
    cout << "How many letters in your word: " << endl;
    cin >> size;
    char arr[size];
    int findP = 1;

    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    char *val1;
    char *val2;

    for (int i = 0; i < size / 2; i++) {
        val1 = &arr[i];
        val2 = &arr[size - 1 - i];
     
        if (*val1 != *val2) {
            cout << "Your word is not a palindrome" << endl;
            findP = 0;
            break;
        }
    }
    if (findP == 1) {
        cout << "Your word is a palindrome" << endl;
    }

    return 0;
}
