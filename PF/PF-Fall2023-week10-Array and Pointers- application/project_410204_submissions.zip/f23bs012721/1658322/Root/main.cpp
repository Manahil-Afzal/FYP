/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/

#include <iostream>
using namespace std;
main ()
{
int n;

cout<<"enter number of characters:";

cin>>n;

char name[n];

cout<<"etnter the name:"; 
for(int i=0;i<n;i++)
{
cin>>name[i];
}
if (name [0]==name [n-1]&&name [1]==name[n-2])
{
    cout<<"this is palandrom";
    cout<<endl;
    
}

else

cout<<"this is not palandrome";

}