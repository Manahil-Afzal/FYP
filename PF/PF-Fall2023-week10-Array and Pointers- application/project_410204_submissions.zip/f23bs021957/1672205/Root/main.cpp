/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>
using namespace std;

bool isPalindrome(const char *str);

int main() {
    const int MAX_SIZE = 100;
    char input[MAX_SIZE];

    cout << "Enter a string: ";
    cin.getline(input, MAX_SIZE);

    if (isPalindrome(input)) {
        cout << "The entered string is a palindorme." << endl;
    } else {
        cout << "The entered string is not a palindrome." << endl;
    }

    return 0;
}

bool isPalindrome(const char *str) {
    int length = strlen(str);
    const char *begin = str;
    const char *end = str + length - 1;

    while (begin < end) {
        if (*begin != *end) {
            return false;
        }
        begin++;
        end--;
    }

    return true; 
}
