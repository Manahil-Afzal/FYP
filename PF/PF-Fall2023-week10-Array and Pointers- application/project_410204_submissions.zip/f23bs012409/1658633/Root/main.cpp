/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
main()
{
    char arr[5];
    char*ptr1;
    char*ptr2;
    ptr1=arr;
    ptr2=&arr[4];
    int i,j;
    for(i=0;i<5;i++)
    cin>>arr[i];
    for(i=0,j=0;i<2,j>2;i++,j--)
    {if(*ptr1++=*ptr2--)
    continue;
    else
    cout<<"not palindrom";
    break;
    }
    cout<<"palindrom";
}