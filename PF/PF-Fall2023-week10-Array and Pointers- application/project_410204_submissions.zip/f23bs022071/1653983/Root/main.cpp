/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{
	int n;
	char name[n];
	cout<<"Enter The number of chars :";
	cin>>n;
	cout<<"Enter the word :";
	for(int i=0;i<n;i++)
	{
		cin>>name[i];
	}
	if (name[0]==name[n-1]&&name[1]==name[n-2])
	{
		cout<<"Given word is a palindrome !";
	}
	else
	cout<<"Given word isn't' a palindrome !";
	
	return 0;
	}
