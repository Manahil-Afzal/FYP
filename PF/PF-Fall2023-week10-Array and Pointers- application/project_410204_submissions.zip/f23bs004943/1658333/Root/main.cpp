/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{ 
    int n;
int*ptr=&n;
cout<<"enter the word's length:";
cin>>n;
char name[*ptr];
cout<<"enter the word:";
for(int i=0;i<n;i++){
cin>>name[i];
}
if(name[0]==name[*ptr-1]&&name[1]==name[*ptr-2]){
cout<<"this is a palindrome";}
else{
cout<<"this is not a palindrome";}
return 0;
}