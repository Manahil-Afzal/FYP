/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
using namespace std;
int main()
{
    char word;
    int size;
    char arr[size];
    int arrFind[size];
    cout<<"How many letters in your word :"<<endl;
    cin>>size;
    cout<<"Enter your letters and press enter :"<<endl;
    for(int i=0;i<=size-1;i++ )
    {
        cin>>arr[i];
    }
     
 for(int i=0;i<=size-1;i++)
{
    char *val1;
    char *val2;
   val1=&arr[i];
   cout<<*val1;
   val2=&arr[size-i];
   cout<<val2;
   if(val1==val2)
   {
       arrFind[i]=1;
   }
   else
   {
       cout<<"Your word is not palendrome :"<<endl;
       i=size;
   }
   
 }
 if(arrFind[size]==1)
 {
     cout<<"Your word is palendrom :";
 }


}