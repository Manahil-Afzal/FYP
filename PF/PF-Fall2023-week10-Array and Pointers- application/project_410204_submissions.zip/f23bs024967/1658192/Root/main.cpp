/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
using namespace std;

int main()
{
	int n;
    cout<<"Enter the number of words"<<endl;
    cin>>n;
    char name[n];
    for(int i=0;i<n;i++)
    {
    	cout<<"Enter the words:";
    	cin>>name[i];
	}
	if(name[0]==name[n-1]&&name[1]==name[n-2])
	{
		cout<<"It is palindrom"<<endl;
	}
	else
	{
	 cout<<"It's not palindrom"<<endl;
	}
}