/*Write a program that uses array of characters to take input from 
user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main(){
	int n;
	int *ptr=&n;
	cout<<"enter a number of characters:";
	cin>>n;
	char name[*ptr];
	cout<<"enter name=";
	for(int i=0;i<n;i++){
		cin>>name[i];
	}
	if(name[0]==name[*ptr-1]&&name[1]==name[*ptr-2]){
		cout<<"this is palindrome.";
	}else{
		cout<<"this is not palindrome.";
	}
}
