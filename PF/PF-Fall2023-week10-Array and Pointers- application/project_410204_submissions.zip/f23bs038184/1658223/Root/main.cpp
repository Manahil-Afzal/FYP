/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
main()
{
    int n;
    cout<<"enter any character";
    cin>>n;
    char name[n];
    cout<<"enter any character";
    for(int i=0;i<n;i++){
        cin>>name[n];
    }
    if(name[0]==name[n-1]&&name[1]==name[n-2]){
        cout<<"this is palindrom";
        
    }
    else{
        cout<<"this is not palindrome";
    }
    return 0;

}

