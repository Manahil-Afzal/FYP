/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main(){
	int n=0;
	char arr[10];
	char *ptr;
	cout<<"Enter the word :";
	cin>>arr;
	ptr=arr;
	while(arr[n]!='\0'){
		cout<<ptr[n];
		n++;
	}cout<<endl;
	if(ptr[1]==ptr[n-2]&& ptr[0]==ptr[n-1])
	cout<<"This is palindrome!";
	else
	cout<<"This isn't palindrome!";
}
	