/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{
    int a,i;
    cout<<"enter the number of character you want to make palindrome";
    cin>>a;
    char palin[a];
    for(i=0;i<a;i++)
    {cout<<"enter the word";
    cin>>palin[i];
    }
    if(palin[0]==palin[a-1]&&palin[1]==palin[a-2])
    cout<<"this is a palindrome";
    else
    cout<<"this is not a palindrome";
    
}