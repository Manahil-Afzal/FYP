/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin >> str;
    int len = strlen(str);
    char *ptr1 = str;
    char *ptr2 = str + len - 1;
    bool is_palindrome = true;
    while (ptr2 > ptr1) {
        if (*ptr1 != *ptr2) {
            is_palindrome = false;
            break;
        }
        ptr1++;
        ptr2--;
    }
    if (is_palindrome) {
        cout << str << " is a palindrome.\n";
    } else {
        cout << str << " is not a palindrome.\n";
    }
    return 0;
}
