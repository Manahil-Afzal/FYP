/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main(){
	int n=0;
	cout<<"enter the word's length:";
	cin>>n;
		char arr[n];
	char *nam;
	cout<<"Enter the word :";
	cin>>arr; 
	nam=arr;
cout<<endl;
	if(nam[1]==nam[n-2]&& nam[0]==nam[n-1]&&nam[2]&&nam[n-3])
	cout<<"This is palindrome!";
	else
	cout<<"This isn't palindrome!";
}
	