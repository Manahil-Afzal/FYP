/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{
    int*iptr[5];
    int fa=65,fb=66,fc=67,fd=68,fe=69;
    int i;
    iptr[0]=&fa;
    iptr[1]=&fb;
    iptr[2]=&fc;
    iptr[3]=&fd;
    iptr[4]=&fe;
    for(i=0;i<5;i++)
    {
        cout<<"pointer"<<i<<"points to"<<*iptr[i]<<"\n";
    }
    cout<<"\n";
    for(i=0;i<5;i++)
    {
        cout<<"the address stored in iptr["<<i<<"]is"<<&iptr[i]<<"\n";
    }
    return 0;
}
    