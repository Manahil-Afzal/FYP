/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the lenght of palindrome=";
    cin>>n;
    char array[n];
    char *nam;
    nam=array;
    cout<<"\nEnter the Word:\n";
    for(int i=0;i<n;i++)
    {
        cin>>array[i];
    }
    
    if(nam[0]==nam[n-1]&&nam[1]==nam[n-2])
    {
    	cout<<"This is palindrome";
    }
	else
	{
		cout<<"This is not palindrome";
		
	}
    return 0;
}