/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the lenght of palindrome=";
    cin>>n;
    char array[n];
    char *nam;
    nam=array;
    cout<<"\nEnter the Word:\n";
    for(int i=0;i<n;i++)
    {
        cin>>array[i];
    }int s,l,h;
    s=0;
    l=n-1;
    h=n/2;
    for(int p=0;p<=h;p++)
    if(nam[s]==nam[l])
    {
    	cout<<"Palindrome";
    }
	else
	{
		cout<<"This is not palindrome";
		
	}
    return 0;
}