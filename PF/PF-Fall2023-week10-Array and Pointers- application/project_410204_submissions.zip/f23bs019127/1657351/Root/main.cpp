/*Write a program that uses array of characters 
to take input from user and checks whether the input represents a palindrome or not, using pointer arithmetic. 
In both cases the program should display appropriate messages.*/
#include <iostream>
#include <cstring>
using namespace std;

bool isPalindrome(const char* str) {
    int length = strlen(str);
    const char* start = str;
    const char* end = str + length - 1;

    while (start < end) {
        if (*start != *end) {
            return false; // Not a palindrome
        }
        start++;
        end--;
    }
    return true; // It's a palindrome
}

int main() {
    const int maxLen = 100; // Maximum string length
    char input[maxLen];

    cout << "Enter a string: ";
    cin.getline(input, maxLen);

    if (isPalindrome(input)) {
        cout << "The input is a palindrome." << endl;
    } else {
        cout << "The input is not a palindrome." << endl;
    }

    return 0;
}
