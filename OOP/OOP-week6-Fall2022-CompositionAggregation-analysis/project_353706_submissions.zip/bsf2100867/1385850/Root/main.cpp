//This program is meant to post-increment a time's object and display the results
#include<iostream>
#include<string>
using namespace std;
class Engine {
private:
	string engine_number;
public:
	Engine(string a) {
	engine_number = a;
}
	string getEngineNumber()
	{
		return this->engine_number;
	}
};
class Passenger {
private:
	string passenger_name;
public:
	Passenger(string n) {
	passenger_name = n;
 }
	string getPassengerName()
	{
		return this->passenger_name;
	}
};
class Car {
private:
	Engine* engine;
	Passenger* passenger;
public:
	Car(Engine* engine, Passenger* passenger)
	{
		this->engine = engine;
		this->passenger = passenger;
	}
	void display()
	{
		cout << "Engine Number: " << engine->getEngineNumber()<<endl;
		cout << "Passenger Name: " << passenger->getPassengerName();
	}
};
int main()
{
	Engine eng("LZX-8932");
	Passenger pass("Raza");
	Car newCar(&eng, &pass);
	newCar.display();

}

