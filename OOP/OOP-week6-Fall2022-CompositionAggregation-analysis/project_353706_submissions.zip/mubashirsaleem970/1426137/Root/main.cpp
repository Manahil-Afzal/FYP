//This program is meant to post-increment a time's object and display the results
/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

class Time
{
  int hr, min;
public:
    Time (int h, int m)
  {
    hr = h;
    min = m;
  }
  int operator+ ()
  {
    ++hr;
    ++min;
    cout << "\n Hours and Minutes " << hr << "'" << min;
    return 0;
}
};

int
main ()
{
  Time t1 (4, 45);
  t1.operator+();
  return 0;
}

