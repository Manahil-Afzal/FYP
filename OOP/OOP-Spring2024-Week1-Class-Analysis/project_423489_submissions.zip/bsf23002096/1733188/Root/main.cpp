#include <iostream>
using namespace std;

class Vehicle {
  public:
  int Maxspeed(int);
  Vehicle(){};
    

};


int Vehicle::Maxspeed(int max) {
  return max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Maxspeed(150); 
  return 0;
}
