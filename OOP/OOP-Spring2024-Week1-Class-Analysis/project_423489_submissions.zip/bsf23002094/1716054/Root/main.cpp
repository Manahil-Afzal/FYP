//class, constructor

#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed; 

public:
   
    Vehicle() : maxSpeed(0) {}

    
    void setMaxSpeed(int max) {
        maxSpeed = max;
    }

   
    int getMaxSpeed() const {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;
    myObj.setMaxSpeed(150); 

    cout << "Max Speed: " << myObj.getMaxSpeed() << endl;

    return 0;
}
