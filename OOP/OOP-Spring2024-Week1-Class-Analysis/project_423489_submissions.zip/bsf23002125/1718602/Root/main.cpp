//class, constructor
#include <iostream>
using namespace std;

class Vehicle {                     // Correct the spelling of the class
  public:
    int maxSpeed(int);             // Correct the spelling of function
    Vehicle(){                      // Correct the construstor vehicle
        
    };                              // Put a semi-colon
    
};                                  // Put a Semi-colon

int Vehicle::maxSpeed(int max) {    // Put a double colon instead of 1 and again correct the spelling
  return max;                       // Correct the return max instead of maxSpeed
}

int main() {
  Vehicle myObj;  
  cout << myObj.maxSpeed(150);      // Correct the spelling
  return 0;
}
