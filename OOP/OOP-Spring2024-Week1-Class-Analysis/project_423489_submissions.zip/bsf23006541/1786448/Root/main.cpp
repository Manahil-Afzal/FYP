//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
public:
    int MaxSpeed(int max) {
        return max; // Placeholder implementation
    }
};

int main() {
    Vehicle myObj;  
    cout << myObj.MaxSpeed(150); 
    return 0;
}
