#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed; 
public:
  Vehicle() {} 

  int getMaxSpeed() 
  const { return maxSpeed; } 

  void setMaxSpeed(int speed)
  { maxSpeed = speed; } 
};

int main() {
  Vehicle myObj;
  myObj.setMaxSpeed(150);
  cout << myObj.getMaxSpeed();
  return 0;
}

