
// here is the modifie and error free code
#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed; // Member variable to store max speed

public:
  // Constructor should not have a return type, and it should initialize the member variable
  Vehicle() {
    maxSpeed = 0; // Default value, you can modify it based on your requirements
  }

  // Getter function to retrieve the max speed
  int getMaxSpeed() {
    return maxSpeed;
  }

  // Setter function to set the max speed
  void setMaxSpeed(int max) {
    maxSpeed = max;
  }
};

int main() {
  Vehicle myObj;

  // Corrected function call syntax, and set the max speed
  myObj.setMaxSpeed(150);

  // Corrected function call syntax, and retrieve the max speed
  cout << myObj.getMaxSpeed();

  return 0;
}
