//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  
  public:
  	int maxspeed(int);
     Vehicle(){}
    

};


int Vehicle::maxspeed(int max) {
  return max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.maxspeed(150); 
  return 0;
}
