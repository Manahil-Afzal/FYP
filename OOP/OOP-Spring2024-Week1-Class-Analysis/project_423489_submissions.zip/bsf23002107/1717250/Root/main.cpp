
    
#include<iostream>
using namespace std;

class Vehicle{
int maxSpeed; //Fix member variable declaration
public:
Vehicle() {} // Fix constructor declaration

int getMaxSpeed() {
    return maxSpeed; } //Fix member function declaration
    
    void setMaxSpeed(int max)
    {maxSpeed=max;} // Add a function to set maxSpeed
};
int main(){
    Vehicle myObj;
    myObj.setMaxSpeed(150); // Set max speed
    cout<<myObj.getMaxSpeed();
    return 0;
}

