//class, constructor
#include<iostream>
using namespace std;

class Vehicle {
  int maxSpeed;  // Corrected member variable name
public:
  Vehicle() {}  // Corrected constructor declaration
  int MaxSpeed(int);  // Corrected function declaration
};


int Vehicle::MaxSpeed(int max){
	maxSpeed=max;
  return maxSpeed;
}

int main() {
  Vehicle myObj;  
  cout<<myObj.MaxSpeed(150); 
  return 0;
}
