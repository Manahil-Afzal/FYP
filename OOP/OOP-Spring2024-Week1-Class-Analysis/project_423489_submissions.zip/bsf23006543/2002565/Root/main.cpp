#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    // Constructor
    Vehicle() {
        maxSpeed = 0; // Default value
    }

    // Method to set max speed
    void setMaxSpeed(int speed) {
        maxSpeed = speed;
    }

    // Method to get max speed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;             // Create object
    myObj.setMaxSpeed(150);    // Set speed using method
    cout << "Max Speed: " << myObj.getMaxSpeed() << endl;  // Display result

    return 0;
}
