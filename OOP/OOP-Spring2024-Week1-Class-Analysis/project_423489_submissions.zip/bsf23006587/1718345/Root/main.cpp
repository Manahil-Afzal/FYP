//class, constructor
#include <iostream>
using namespace std;

class Vehicle {  //name correction
    public:     //access specifier corrected
  int maxSpeed(int max);//"Max" is keyword for built-in funtion and "-" cannot be used in name of data members/methods
  public:
     Vehicle(){} //constructor doesn't have any type like void or int
    

};//";" was missing


int Vehicle::maxSpeed(int max) {//":"  was used instead of"::"
  return max;           //"maxSpeed" was used for return instead of "max"
}

int main() {
  Vehicle myObj;  
  cout << myObj.maxSpeed(150); //name correction
  return 0;
}