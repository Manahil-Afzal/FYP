//class, constructor
#include <iostream>
using namespace std;

class Vehice {
  public:
    
  int max_speed(int max);
    

};


int Vehice::max_speed(int max) {
  return max;
}

int main() {
  Vehice myObj;  
  cout << myObj.max_speed(150); 
  return 0;
}
