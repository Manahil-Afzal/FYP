// //class, constructor
// #include <iostream>
// using namespace std;

// class Vehice {
//   int Max-Speed(int);
//   public:
//     void Vehicle(){}
    

// }


// int Vehicle:Max-speed(int max) {
//   return maxSpeed;
// }

// int main() {
//   Vehicle myObj;  
//   cout << myObj.Max-speed(150); 
//   return 0;
// }
//corrected programme
#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    // Constructor
    Vehicle() {
        maxSpeed = 0;
    }

    // Setter method for maxSpeed
    void setMaxSpeed(int max) {
        maxSpeed = max;
    }

    // Getter method for maxSpeed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;

    // Setting max speed
    myObj.setMaxSpeed(150);

    // Getting and printing max speed
    cout << "Max Speed: " << myObj.getMaxSpeed() << endl;

    return 0;
}
