//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
private:
  int MaxSpeed;
  public:
    Vehicle(int max){
        MaxSpeed=max;
    }
    int Max_Speed();

};


int Vehicle::Max_Speed() {
  return MaxSpeed;
}

int main() {
  Vehicle myObj(150);  
  cout << myObj.Max_Speed(); 
  return 0;
}
