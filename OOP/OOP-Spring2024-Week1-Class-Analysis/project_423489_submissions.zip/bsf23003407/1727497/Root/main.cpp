//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;
public:
    Vehicle() {} // Constructor declaration
    
    // Setter function for maxSpeed
    void setMaxSpeed(int max) {
        maxSpeed = max;
    }

    // Getter function for maxSpeed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;  

    // Setting max speed
    myObj.setMaxSpeed(150);

    // Getting and printing max speed
    cout << "Max Speed: " << myObj.getMaxSpeed() << endl;

    return 0;
}
