#include <iostream>
using namespace std;

class Vehicle {
public:
    int MaxSpeed(int);
};

int Vehicle::MaxSpeed(int max) {
    return max; 
}

int main() {
    Vehicle myObj;
    cout << myObj.MaxSpeed(150);
    return 0;
}

