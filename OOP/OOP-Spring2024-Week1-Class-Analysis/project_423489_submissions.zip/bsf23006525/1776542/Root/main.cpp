#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    // Constructor
    Vehicle() {
        maxSpeed = 0; // Initialize maxSpeed to 0
    }

    // Member function to set maximum speed
    void setMaxSpeed(int max) {
        maxSpeed = max;
    }

    // Member function to get maximum speed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;

    // Set maximum speed to 150
    myObj.setMaxSpeed(150);

    // Display maximum speed
    cout << "Maximum Speed: " << myObj.getMaxSpeed() << endl;

    return 0;
}
