#include <iostream>
using namespace std;

class Vehicle {
    int maxSpeed; // Declare maxSpeed as a member variable
    
  public:
    // Constructor
    Vehicle() {
        maxSpeed = 0; // Initialize maxSpeed to 0
    }
    
    // Method to set max speed
    void setMaxSpeed(int speed) {
        maxSpeed = speed;
    }
    
    // Method to get max speed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;  // Set the max speed
    myObj.setMaxSpeed(150);
    
    cout << "Max Speed: " << myObj.getMaxSpeed() << " km/h";
    
    return 0;
}
