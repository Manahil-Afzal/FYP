//class, constructor
#include <iostream>
using namespace std;
class Vehicle {
  int maxspeed=0;
  public:
    int Max_speed(int max);
};
int Vehicle::Max_speed(int max) {
  return maxspeed=max;
}
int main() {
  Vehicle myObj;  
  cout << myObj.Max_speed(150); 
  return 0;
}
