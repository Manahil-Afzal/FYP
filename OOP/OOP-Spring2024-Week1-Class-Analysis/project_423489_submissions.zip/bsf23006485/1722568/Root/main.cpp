//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed; 
public:
  Vehicle() {} 
  int getMaxSpeed(); 
};

int Vehicle::getMaxSpeed() { 
  return maxSpeed;
}

int main() {
  Vehicle myObj;
  cout << myObj.getMaxSpeed(); 
  return 0;
}