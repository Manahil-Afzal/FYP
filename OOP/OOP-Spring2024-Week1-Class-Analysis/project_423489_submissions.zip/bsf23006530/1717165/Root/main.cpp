//class, constructor
#include <iostream>
using namespace std;

class Vehicle {  //spelling mistake
  int MaxSpeed;  //syntax correction
  public:
    Vehicle(){} //remove constructor type(void)
    
    int inputSpeed(int speed) {   //method for maxSpeed
  	MaxSpeed=speed;
    return MaxSpeed;
  }

};


 // int Vehicle:Max-speed(int max) {
 //   return maxSpeed;
// }

int main() {
  Vehicle myObj;  
  cout <<"Max-Speed: "<<myObj.inputSpeed(150); 
  return 0;
}
