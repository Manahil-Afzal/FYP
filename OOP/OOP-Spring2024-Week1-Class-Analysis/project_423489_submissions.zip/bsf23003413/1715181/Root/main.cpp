//class,constructor
#include<iostream>
using namespace std;
class Vehicle                       //Wrong spelling of vehicle
{
  public:
  int MaxSpeed(int);                //Symbol not allowed as variable name
};
int Vehicle::MaxSpeed(int max)      //Wrong scope resolution operator,wrong variable name
{  
  return max;
}
int main() 
{
  Vehicle myObj;  
  cout<<myObj.MaxSpeed(150);       //Wrong variable name
  return 0;
}
