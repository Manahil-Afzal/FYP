//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  int Maxspeed;
  public:
   
    int MaxSpeed(int);

};


int Vehicle::MaxSpeed(int max) {
    return Maxspeed=max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.MaxSpeed(150); 
  return 0;
}
