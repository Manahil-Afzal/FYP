//class, constructor
/*#include <iostream>
using namespace std;

class Vehice {
  int Max-Speed(int);
  public:
    void Vehicle(){}
    

}


int Vehicle:Max-speed(int max) {
  return maxSpeed;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Max-speed(150); 
  return 0;
}*/
                          //***CORRECTED PROGRAM****:
#include <iostream>
using namespace std;

class Vehicle {
	private:
		int maxSpeed;
    public:
    	Vehicle(int max ){
		maxSpeed=max;
		} 
	 int Max_Speed();   
};   

int Vehicle::Max_Speed() {
  return maxSpeed;
}

int main() {
  Vehicle myObj(150);  
  cout << myObj.Max_Speed(); 
  return 0;
}                          
