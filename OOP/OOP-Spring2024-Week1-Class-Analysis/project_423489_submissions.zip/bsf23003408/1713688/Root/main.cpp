//class, constructor
#include <iostream>
using namespace std;

class Vehicle{
  public:
  	int spee;
  int Max_Speed(int spee);
   Vehicle(){}
};

int Vehicle::Max_Speed(int spee) {
  return spee;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Max_Speed(150); 
  return 0;
}