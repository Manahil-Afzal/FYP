//class, constructor
#include <iostream>
using namespace std;

class Vehicle {  
  int MaxSpeed;  
  public:
    Vehicle(){} 
    
    int inputSpeed(int speed) {   
  	MaxSpeed=speed;
    return MaxSpeed;
  }

};




int main() {
  Vehicle myObj;  
  cout <<"Maximum Speed: "<<myObj.inputSpeed(150); 
  return 0;
}