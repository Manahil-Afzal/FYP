//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
    public:
  int Max_Speed(int Speed);
  
    

};


int Vehicle::Max_Speed(int Speed) {
  return Speed;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Max_Speed(150); 
  return 0;
}
