#include<iostream>
using namespace std;
class Vehicle{
	int speed;
	public:
		Vehicle(){}
		int	max_speed(int);
};
int Vehicle::max_speed(int speed)
{
	return speed;
}
int main()
{
	Vehicle myobj;
	cout<<myobj.max_speed(150);
	return 0;
}