//class, constructor

#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed; // Corrected variable name
public:
  Vehicle(){} // Corrected constructor 
  int getMaxSpeed(int max); // Corrected function declaration
};

int Vehicle::getMaxSpeed(int max) {
  maxSpeed = max; //asigning value to maxSpeed
  return maxSpeed; // Corrected return value
}

int main() {
  Vehicle myObj;
  cout << myObj.getMaxSpeed(150) << endl; // Corrected function call
  return 0;
}