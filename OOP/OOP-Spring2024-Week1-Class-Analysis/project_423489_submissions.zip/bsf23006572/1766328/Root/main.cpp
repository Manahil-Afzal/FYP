// //class, constructor
// #include <iostream>
// using namespace std;

// class Vehice {
//   int Max-Speed(int);
//   public:
//     void Vehicle(){}
    

// }


// int Vehicle:Max-speed(int max) {
//   return maxSpeed;
// }

// int main() {
//   Vehicle myObj;  
//   cout << myObj.Max-speed(150); 
//   return 0;
// }
// These are the following mistakes :
// First the name of the class vehicle is incorrect 
// Second the data type of the function in class and outsite the class is not same 
// Third the access method to access the funtion outsite the class is not wright we should use scope opertor :: to access the funciton 
// Forth we must initialized the passed argument to the private data member of the class 
// Fifth some name of the functions and class must be same 
// The correct program is here 
#include <iostream>
using namespace std;

class Vehicle {
  int Max_Speed;
  public:
     int Maxspeed(int max);
    

};


int Vehicle::Maxspeed(int max) {
    Max_Speed=max;
  return Max_Speed;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Maxspeed(150); 
  return 0;
}
