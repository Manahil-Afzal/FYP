// //class, constructor
// #include <iostream>
// using namespace std;

// class Vehice {
//   int Max-Speed(int);
//   public:
//     void Vehicle(){}
    

// }


// int Vehicle:Max-speed(int max) {
//   return maxSpeed;
// }

// int main() {
//   Vehicle myObj;  
//   cout << myObj.Max-speed(150); 
//   return 0;
// }
// These are the following errors in the program:
// First the class name is not same in both cases
// Second private format spacifier is missing and no need of data type in prentheses in the data mamber of the class 
// Third Scop Resulation Operator is wrong in the function call outside the class 
// Forth data type of the functon inside the class and outside the class must be same 
// Fifth in the main the object must call the function not the data member which is defalut private
// The Correct program after removing all the errors 

#include <iostream>
using namespace std;

class Vehicle
{
private:
    int Max_Speed;

public:
    int speed(int speeed);
};

int Vehicle::speed(int maxspeed)
{
    Max_Speed = maxspeed;
    return Max_Speed;
}

int main()
{
    Vehicle myObj;
    cout<<"The maximum speed of the vehicle is = " << myObj.speed(45);
    return 0;
}
