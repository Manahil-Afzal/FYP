//class, constructor
#include<iostream>
using namespace std;
class vehicle{
	private:
		int maxspeed;
		public:
			int speed (int);
};
int vehicle ::speed(int max){
	return max;
}
int main(){
	vehicle myobj;
	cout<<myobj.speed(150);
	return 0;
}