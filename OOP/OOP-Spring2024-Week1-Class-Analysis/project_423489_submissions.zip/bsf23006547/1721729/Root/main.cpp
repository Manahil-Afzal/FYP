//class, constructor
#include <iostream>
using namespace std;

class Vehicle 
{
  public:
  int maxSpeed(int);
};

int Vehicle::maxSpeed(int max) 
{
  return max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.maxSpeed(150); 
  return 0;
}
