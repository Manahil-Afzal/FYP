//class, constructor
#include <iostream>
using namespace std;

class Vehice {
	public:
  int MaxSpeed(int);
  public:
    void Vehicle(){}
    

};


int Vehice::MaxSpeed(int max) {
  return max;
}

int main() {
  Vehice myObj;  
  cout << myObj.MaxSpeed(150); 
  return 0;
}