#include<iostream>
using namespace std;

class Vehicle{
int maxSpeed;
public:
Vehicle() {}

int getMaxSpeed() {
    return maxSpeed; }
    void setMaxSpeed(int max)
    {maxSpeed=max;}
};
int main(){
    Vehicle myObj;
    myObj.setMaxSpeed(150);
    cout<<myObj.getMaxSpeed();
    return 0;
}