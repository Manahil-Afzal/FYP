//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
 
  public:
  	 int maxSpeed(int maxspeed);
  
};
int Vehicle::maxSpeed(int maxspeed) {
  return maxspeed;
}
int main() {
  Vehicle myObj;  
  cout << myObj.maxSpeed(150); 
  return 0;
}