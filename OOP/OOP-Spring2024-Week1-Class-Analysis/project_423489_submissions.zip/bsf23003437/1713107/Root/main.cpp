#include <iostream>
using namespace std;

// Note: class name is case-sensitive, it should be Vehicle, not Vehice
class Vehicle {
public:
    // Constructor declaration
    Vehicle(int maxSpeed);

    int getMaxSpeed();

private:
    int maxSpeed;
};

// Constructor definition
Vehicle::Vehicle(int maxSpeed) : maxSpeed(maxSpeed) {}

int Vehicle::getMaxSpeed() {
    return maxSpeed;
}

int main() {
    Vehicle myObj(150); // Create a Vehicle object with max speed of 150
    cout << myObj.getMaxSpeed();
    return 0;
}