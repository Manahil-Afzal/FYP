#include <iostream>
using namespace std;
class Vehicle {
private:
  int maxSpeed;
public:
  // Constructor to initialize maxSpeed
  Vehicle(int max) : maxSpeed(max) {}

  // Method to get maxSpeed
  int getMaxSpeed() {
    return maxSpeed;
  }
};

int main() {

  // Creating an object of the Vehicle class with max speed 150
  Vehicle myObj(150);

  // Accessing the getMaxSpeed method to get the max speed
  cout<< myObj.getMaxSpeed()<< endl;

  return 0;
}