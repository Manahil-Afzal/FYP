//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    // Constructor
    Vehicle() {
        maxSpeed = 0;  // You may initialize maxSpeed to a default value if needed
    }

    // Member function to set maxSpeed
    void setMaxSpeed(int speed) {
        maxSpeed = speed;
    }

    // Member function to get maxSpeed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;
    myObj.setMaxSpeed(150);
    cout << myObj.getMaxSpeed();
    return 0;
}
