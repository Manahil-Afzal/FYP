//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
    private:
    int Maxspeed;
  public:
    Vehicle(int max){
        Maxspeed=max;
    }
    int Max_speed();
};

int Vehicle::Max_speed() {
  return Maxspeed;
}

int main() {
  Vehicle myObj(150);  
  cout << myObj.Max_speed(); 
  return 0;
}
