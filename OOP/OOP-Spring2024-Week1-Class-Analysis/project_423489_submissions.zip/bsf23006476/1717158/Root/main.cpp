//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  public:
  int MaxSpeed(int);
  Vehicle(){}
};


int Vehicle::MaxSpeed(int maxSpeed) {
  return maxSpeed;
}

int main() {
  Vehicle myObj;  
  cout << myObj.MaxSpeed(150); 
  return 0;
}
