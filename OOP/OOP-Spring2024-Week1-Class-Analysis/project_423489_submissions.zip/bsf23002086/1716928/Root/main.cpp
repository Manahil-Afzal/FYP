//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    // Constructor
    Vehicle() {}

    //  max speed
    void setMaxSpeed(int max) {
        maxSpeed = max;
    }

    //  get max speed
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;
    myObj.setMaxSpeed(150);
    cout << myObj.getMaxSpeed();
    return 0;
}



/*1: The class is declared as Vehice instead of Vehicle
2: Declaration of a method with a constructor-like syntax
3: Missing semicolon after class declaration
4: he method Max-speed is incorrectly defined
5: The variable maxSpeed is not defined in the method Max-speed*/
