#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;
public:
    Vehicle() {
        maxSpeed = 0; 
    }
    void setMaxSpeed(int speed) {
        maxSpeed = speed;
    }
    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;
    myObj.setMaxSpeed(150);
    cout << "Maximum speed of the vehicle: " << myObj.getMaxSpeed() << " km/h" << endl;
    return 0;
}
