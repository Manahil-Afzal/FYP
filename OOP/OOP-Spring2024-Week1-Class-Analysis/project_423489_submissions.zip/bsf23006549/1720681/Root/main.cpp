//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
	private:
		int maxSpeed;
    public:
    	Vehicle(){};// A default contructor to avoid compilation error at runtime due to creation of un-parmetrized object.
    	Vehicle(int); //A constructor to intiazlize Object's maxSpeed.
	    int Max_Speed(); // A Function Declartion to get the maxSpeed of the class Vehicle's object.
	    void set_Max(int);// Declariton of an "additional" setter function to set maxSpeed after creation of object.
};
Vehicle::Vehicle(int max){ //Constructor definition
	maxSpeed=max;
}
int Vehicle::Max_Speed() { //function definition of getter function(returns Max-Speed)
  return maxSpeed;
}
void Vehicle::set_Max(int m){
	maxSpeed=m;
}

int main() {
  Vehicle myObj(34),yourObj;  //Cretion of two objects

  cout << myObj.Max_Speed(); 
  return 0;
}
