#include<iostream>
using namespace std;

class Vehicle{
	int maxSpeed;
	public:
		Vehicle() {	}
		
		int getMaxSpeed()  {
			return maxSpeed;	}
			void setMaxSpeed (int max)
			{maxSpeed=max;}
};
int main() {
	Vehicle myobj;
	myobj.setMaxSpeed(150);
	cout<<myobj.getMaxSpeed();
	return 0;
}