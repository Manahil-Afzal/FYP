#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed; 

public:
    Vehicle(int max) : maxSpeed(max) {}

    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj(150);  
    cout << myObj.getMaxSpeed();

    return 0;
}
