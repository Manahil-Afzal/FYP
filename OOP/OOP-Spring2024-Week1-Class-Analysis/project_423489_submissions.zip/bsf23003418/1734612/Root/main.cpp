//class, constructor
#include <iostream>
using namespace std;

class Vehice {
public:
  int Max_Speed(int);
  
    void Vehicle();
    

};


int Vehice::Max_Speed(int max) {
  return max;
}

int main() {
  Vehice myObj;  
  cout << myObj.Max_Speed(150); 
  return 0;
}
