


#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed; 

public:
    Vehicle() : maxSpeed(0) {}

    void setMaxSpeed(int max) {
        maxSpeed = max;
    }

    int getMaxSpeed() {
        return maxSpeed;
    }
};

int main() {
    Vehicle myObj;

    myObj.setMaxSpeed(150);

    cout << "Max Speed: " << myObj.getMaxSpeed() << " km/h" << endl;

    return 0;
}

