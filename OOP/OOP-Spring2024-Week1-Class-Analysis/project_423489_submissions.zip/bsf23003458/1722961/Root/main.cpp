//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    Vehicle() {} // Constructor

    int Max_Speed(int max); // Function declaration
};

// Function definition
int Vehicle::Max_Speed(int max) {
    maxSpeed = max;
    return maxSpeed;
}

int main() {
    Vehicle myObj;  
    cout << myObj.Max_Speed(150); // Function call
    return 0;
}
