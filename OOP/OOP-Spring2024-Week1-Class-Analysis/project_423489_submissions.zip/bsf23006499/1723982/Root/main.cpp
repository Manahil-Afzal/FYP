//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  
  public:
	int Max_speed(int max);
    Vehicle(){}
};
int Vehicle::Max_speed(int max) {
  return max;
}
int main() {
  Vehicle myObj;  
  cout << myObj.Max_speed(150); 
  return 0;
}