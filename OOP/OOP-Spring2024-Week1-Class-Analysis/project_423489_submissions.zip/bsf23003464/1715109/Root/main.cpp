//class, constructor
#include <iostream>
using namespace std;

class Vehicle {             //Spelling Mistake
        // int sould also be included in public
  public:
  int Max_Speed(int max);
};


int Vehicle::Max_Speed(int max) {      
  return max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Max_Speed(150); 
  return 0;
}
