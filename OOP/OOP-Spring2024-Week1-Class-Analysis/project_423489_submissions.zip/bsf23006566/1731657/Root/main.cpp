#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed;
  public:
    Vehicle() {} 
    int MaxSpeed(int); 
};

int Vehicle::MaxSpeed(int max) {
  maxSpeed = max;
  return maxSpeed;
}

int main() {
  Vehicle myObj;  
  cout << myObj.MaxSpeed(150); 
  return 0;
}

