#include<iostream>
using namespace std;
class Vehicle {
int Speed;
public:
Vehicle(){}
int Max_Speed(int);
};
int Vehicle::Max_Speed(int speed)
{
return speed;
}
int main()
{
Vehicle myObj;
cout<<myObj.Max_Speed(150);
return 0;
}
