//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  private:
  int maxSpeed;
  public:
    int speed(int);
    

};


int Vehicle::speed(int max) {
  return max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.speed(150); 
  return 0;
}