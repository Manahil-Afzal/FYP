//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
     Vehicle() {}  
    int MaxSpeed(int max);  
};

int Vehicle::MaxSpeed(int max) {
    maxSpeed = max;
    return maxSpeed;
}

int main() {
    Vehicle myObj;
    cout << myObj.MaxSpeed(150);
    return 0;
}
