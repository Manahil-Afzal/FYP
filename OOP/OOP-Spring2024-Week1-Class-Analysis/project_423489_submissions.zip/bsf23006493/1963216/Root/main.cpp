//class, constructor
#include <iostream> 
using namespace std;

class Vehicle {
    int MaxSpeed;  // Member variable to store max speed

public:
    Vehicle() {   // Constructor to initialize MaxSpeed
        MaxSpeed = 0;  // Default initialization
    }

    // Method to set MaxSpeed
    int MaxSpeedMethod(int max) {
        MaxSpeed = max;
        return MaxSpeed;
    }
};

int main() {
    Vehicle myObj;
    cout << myObj.MaxSpeedMethod(150);  // Set MaxSpeed to 150 and print it
    return 0;
}
