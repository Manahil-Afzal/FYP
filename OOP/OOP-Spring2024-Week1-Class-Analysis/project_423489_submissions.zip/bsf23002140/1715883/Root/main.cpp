
#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed; // Fix the variable declaration here
public:
  Vehicle() {} // Constructor definition

  int MaxSpeed(int max) {  
    maxSpeed = max;
    return maxSpeed;
  }
};

int main() {
  Vehicle myObj;
  cout << myObj.MaxSpeed(150);  
  return 0;
  }