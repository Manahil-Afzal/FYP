//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
    public:
    int Max_Speed(int);
    Vehicle(){};
};


int Vehicle::Max_Speed(int max) {
  return max;
}

int main() {
  Vehicle myObj;  
  cout << myObj.Max_Speed(150); 
  return 0;
}
