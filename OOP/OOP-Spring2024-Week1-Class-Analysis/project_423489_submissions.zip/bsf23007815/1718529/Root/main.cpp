//class, constructor

#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed;  
public:
  Vehicle() {} 

  
  void setMaxSpeed(int speed) {
    maxSpeed = speed;
  }

 
  int getMaxSpeed() {
    return maxSpeed;
  }
};

int main() {
  Vehicle myObj;
  myObj.setMaxSpeed(150);
  cout << myObj.getMaxSpeed();
  return 0;
}
