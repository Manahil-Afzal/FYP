//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed;  // Member variable to store max speed

public:
  Vehicle() {}  // Default constructor

  int getMaxSpeed() {
    return maxSpeed;
  }

  void setMaxSpeed(int max) {
    maxSpeed = max;
  }
};

int main() {
  Vehicle myObj;
  myObj.setMaxSpeed(150);
  cout << myObj.getMaxSpeed();
  return 0;
}

