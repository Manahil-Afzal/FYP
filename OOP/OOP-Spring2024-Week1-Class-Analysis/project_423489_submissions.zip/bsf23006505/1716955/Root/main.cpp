//class, constructor
#include <iostream>
using namespace std;
class Vehicle {
  public:
  int speed(int maxSpeed);
};
int Vehicle::speed(int maxSpeed) {
  return maxSpeed;}
int main() {
  Vehicle myObj;  
  cout << myObj.speed(150); 
  return 0;
}
