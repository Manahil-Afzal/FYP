//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
public:
    Vehicle() {} //default constructer

    int MaxSpeed(int speed) {
        return speed; // Replace with actual implementation
    }
};

int main() {
    Vehicle myObj;
    cout << myObj.MaxSpeed(150) << endl; // Use endl for newline
    return 0;
}