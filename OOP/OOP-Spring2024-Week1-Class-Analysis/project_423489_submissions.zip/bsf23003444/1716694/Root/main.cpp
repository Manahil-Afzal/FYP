//class, constructor
#include <iostream>
using namespace std;

// Class name should be spelled correctly as "Vehicle," and the function name should be "maxSpeed" (not Max-Speed)
class Vehicle {
  int maxSpeed; // Declare a private member variable for maxSpeed
  
public:
  // Constructor should be declared without a return type and spelled correctly as "Vehicle"
  Vehicle() {}

  // Function declaration should match the class definition and return the maxSpeed
  int getMaxSpeed(int max) {
    maxSpeed = max; // Assign the value of max to maxSpeed
    return maxSpeed;
  }
};

int main() {
  Vehicle myObj;  
  // Call the correct function name: getMaxSpeed instead of Max-speed
  cout << myObj.getMaxSpeed(150);
  return 0;
}

