//class, constructor
#include<iostream>
using namespace std ;
class vehicle{
	public:
		int maxspeed(int max);
		vehicle(){
			
		}
	
};
int vehicle::maxspeed(int max){
	return max;
}
main(){
	vehicle myobj;
	cout<<myobj.maxspeed(150);
	return 0;
}
