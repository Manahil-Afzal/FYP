#include <iostream>
using namespace std;

class Vehicle {
private:
    int maxSpeed;

public:
    Vehicle() {
        maxSpeed = 0;
    }

    int getMaxSpeed() {
        return maxSpeed;
    }

    void setMaxSpeed(int max) {
        maxSpeed = max;
    }
};

int main() {
    Vehicle myObj;
    myObj.setMaxSpeed(150);
    cout << myObj.getMaxSpeed();
    return 0;
}