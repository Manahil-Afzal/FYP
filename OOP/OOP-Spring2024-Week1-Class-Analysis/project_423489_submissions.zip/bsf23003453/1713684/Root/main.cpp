//class, constructor
#include <iostream>
using namespace std;

class Vehicle {
  int maxSpeed;  // Add a member variable to store max speed

  public:
    Vehicle() {}  // Constructor definition

    int Max_Speed(int max) {
      maxSpeed = max;
      return maxSpeed;
    }
};

int main() {
  Vehicle myObj;  
  cout << myObj.Max_Speed(150); 
  return 0;
}

