/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

public:
    Student(string n, int i, float m, float c, int sn) : name(n), id(i), marks(m), cgpa(c), serialNumber(sn) {}
    void displayDetails() {
        cout << "Serial Number: " << serialNumber <<endl;
        cout << "Name: " << name <<endl;
        cout << "ID: " << id <<endl;
        cout << "Marks: " << marks <<endl;
        cout << "CGPA: " << cgpa <<endl;
        cout << "-------------------" <<endl;
    }
    float getMarks(){
        return marks;
    }
};

int main() {
    Student students[8] = {
        Student("Ali", 101, 85.5, 3.7, 1),
        Student("Baber", 102, 78.0, 3.4, 2),
        Student("Ahmad", 103, 92.3, 3.9, 3),
        Student("David", 104, 79.8, 3.5, 4),
        Student("Ameen", 105, 88.2, 3.8, 5),
        Student("Fakhar", 106, 95.0, 4.0, 6),
        Student("Hassan", 107, 82.7, 3.6, 7),
        Student("Haron", 108, 90.5, 3.9, 8)
    };
    float maxMarks = -1.0;
    int index = -1;
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            index = i;
        }
    }
    cout << "Details of the student with the highest marks:" <<endl;
    if (index != -1) {
        students[index].displayDetails();
    } else {
        cout << "No student data found." <<endl;
    }
    return 0;
}