/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
public:
    std::string name;
    int id;
    double marks;
    double cgpa;
    int serialNumber;

    void getDetails(int serial) {
        serialNumber = serial;
        std::cout << "Enter details for Student " << serialNumber << ":\n";
        std::cout << "Name: ";
        std::cin >> name;
        std::cout << "ID: ";
        std::cin >> id;
        std::cout << "Marks: ";
        std::cin >> marks;
        std::cout << "CGPA: ";
        std::cin >> cgpa;
    }

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << "\n";
        std::cout << "Name: " << name << "\n";
        std::cout << "ID: " << id << "\n";
        std::cout << "Marks: " << marks << "\n";
        std::cout << "CGPA: " << cgpa << "\n";
    }
};

int main() {
    Student students[8];

    // Input details for each student
    for (int i = 0; i < 8; i++) {
        students[i].getDetails(i + 1);
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    for (int i = 1; i < 8; i++) {
        if (students[i].marks > students[highestMarksIndex].marks) {
            highestMarksIndex = i;
        }
    }

    // Display the details of the student with the highest marks
    std::cout << "\nStudent with the highest marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;
}
