/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
public:
    int serialNumber;
    std::string name;
    int id;
    float marks;
    float cgpa;

    void inputDetails(int serial) {
        serialNumber = serial;
        std::cout << "Enter name for Student " << serialNumber << ": ";
        std::cin >> name;
        std::cout << "Enter ID for Student " << serialNumber << ": ";
        std::cin >> id;
        std::cout << "Enter marks for Student " << serialNumber << ": ";
        std::cin >> marks;
        std::cout << "Enter CGPA for Student " << serialNumber << ": ";
        std::cin >> cgpa;
    }

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }
};

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    for (int i = 0; i < numStudents; i++) {
        students[i].inputDetails(i + 1);
    }

    int maxMarksIndex = 0;
    for (int i = 1; i < numStudents; i++) {
        if (students[i].marks > students[maxMarksIndex].marks) {
            maxMarksIndex = i;
        }
    }

    std::cout << "Details of the student with the highest marks:" << std::endl;
    students[maxMarksIndex].displayDetails();

    return 0;
}