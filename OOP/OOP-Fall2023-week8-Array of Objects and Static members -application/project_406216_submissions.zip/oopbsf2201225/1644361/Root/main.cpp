/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string>

using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber; // Serial number based on the order of creation

public:
    // Constructor to initialize the serial number
    Student() {
        static int count = 1;
        serialNumber = count++;
    }

    // Member function to input details of the student
    void inputDetails() {
        cout << "Enter student details for Serial Number " << serialNumber << ":\n";
        cout << "Name: ";
        getline(cin, name);

        cout << "ID: ";
        cin >> id;

        cout << "Marks: ";
        cin >> marks;

        cout << "CGPA: ";
        cin >> cgpa;

        // Consume newline character left in the buffer
        cin.ignore();
    }

    // Member function to display details of the student
    void displayDetails() {
        cout << "\nDetails for Serial Number " << serialNumber << ":\n";
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Getter function for marks
    float getMarks() const {
        return marks;
    }
};

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; ++i) {
        students[i].inputDetails();
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    for (int i = 1; i < numStudents; ++i) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }

    // Display details of the student with the highest marks
    cout << "\nDetails of the student with the highest marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;
}
