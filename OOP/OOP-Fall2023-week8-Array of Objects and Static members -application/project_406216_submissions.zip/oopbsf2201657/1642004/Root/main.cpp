/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
public:
    static int count; 
    int id;
    string name;
    float marks;
    float cgpa;

    Student(string n, float m, float c) {
        id = ++count; 
        name = n;
        marks = m;
        cgpa = c;
    }

    void displayDetails() {
        cout << "Student ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int Student::count = 0; 
int main() {
    Student students[8] = {
        {"Faisal", 85.5, 3.7},
        {"Ahmed", 92.0, 3.9},
        {"Ali", 78.5, 3.5},
        {"Dawood", 88.7, 3.8},
        {"Esa", 91.2, 3.6},
        {"Farukh", 79.8, 3.4},
        {"Gule", 95.5, 4.0},
        {"Haisam", 89.3, 3.7}
    };

    float highestMarks = 0;
    int index = -1;

    
    for (int i = 0; i < 8; ++i) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            index = i;
        }
    }


    if (index != -1) {
        cout << "Student with the highest marks: " << endl;
        students[index].displayDetails();
    } else {
        cout << "No student data available." << endl;
    }

    return 0;
}
