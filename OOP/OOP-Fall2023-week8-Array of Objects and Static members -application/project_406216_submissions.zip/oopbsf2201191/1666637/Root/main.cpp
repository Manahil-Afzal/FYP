/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class student
{
private:
    string name, ID;
    int marks;
    float CGPA;

public:
    static int serial;

    void set_name()
    {
        cout << "Enter the name: " << endl;
    }
    void get_name()
    {
        cin >> name;
    }
    void set_ID()
    {
        cout << "Enter ID: " << endl;
    }
    void get_ID()
    {
        cin >> ID;
    }
    void set_marks()
    {
        cout << "Enter marks: " << endl;
    }
    void get_marks()
    {
        cin >> marks;
    }
    void set_CGPA()
    {
        cout << "Enter CGPA: " << endl;
    }
    void get_CGPA()
    {
        cin >> CGPA;
    }
    int passMarks()
    {
        return marks;
    }
    void display()
    {
        cout << ++serial << "\t" << name << "\t" << marks << "\t" << ID << "\t" << CGPA << endl;
    }
};

int student::serial;

int main()
{
    int highestMarksIndex = 0;
    student std[8];
    for (int i = 0; i < 8; i++)
    {
        cout << "Enter the detail of student " << i + 1 << endl;
        std[i].set_name();
        std[i].get_name();
        std[i].set_ID();
        std[i].get_ID();
        std[i].set_marks();
        std[i].get_marks();
        std[i].set_CGPA();
        std[i].get_CGPA();
        if (std[i].passMarks() > std[highestMarksIndex].passMarks())
        {
            highestMarksIndex = i;
        }
    }
    cout << "Detail of students:" << endl;
    std[highestMarksIndex].display();
}