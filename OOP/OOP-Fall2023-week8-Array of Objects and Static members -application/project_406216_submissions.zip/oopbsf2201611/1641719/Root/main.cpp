/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
public:
    static int serialNumberCounter; 
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;


    Student(string n, int i, float m, float c) : name(n), id(i), marks(m), cgpa(c) {
        serialNumber = ++serialNumberCounter;
    }


    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int Student::serialNumberCounter = 0;

int main() {
    Student students[8] = {
        {"Talha", 101, 85.5, 3.7},
        {"Saad", 102, 78.3, 3.2},
        {"Aleem", 103, 92.0, 3.9},
        {"Bilal", 104, 89.7, 3.8},
        {"Faizan", 105, 79.5, 3.4},
        {"Waqas", 106, 88.2, 3.6},
        {"Ahmad", 107, 94.5, 4.0},
        {"Noman", 108, 87.9, 3.5}
    };

    float highestMarks = 0.0;
    int highestMarksIndex = 0;

    
    for (int i = 0; i < 8; ++i) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            highestMarksIndex = i;
        }
    }

    cout << "Details of student with highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
