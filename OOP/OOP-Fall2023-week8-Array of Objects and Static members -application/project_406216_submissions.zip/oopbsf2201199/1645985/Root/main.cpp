/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;

class Student {
public:
    Student(std::string name, int id, float marks, float cgpa)
        : name(name), id(id), marks(marks), cgpa(cgpa), serialNumber(++serialCounter) {}

    void displayDetails() const {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }

    static Student getStudentWithHighestMarks(Student students[], int size) {
        Student maxMarksStudent = students[0];
        for (int i = 1; i < size; i++) {
            if (students[i].marks > maxMarksStudent.marks) {
                maxMarksStudent = students[i];
            }
        }
        return maxMarksStudent;
    }

private:
    std::string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;
    static int serialCounter;
};

int Student::serialCounter = 0;

int main() {
    Student students[] = {
        Student("Ali", 1, 9, 3.9),
        Student("Raza", 2, 79, 3.45),
        Student("Saad", 3, 72, 3.1),
        Student("Fahad", 4, 85, 3.75),
        Student("Mustafa", 5, 70, 3.0),
        Student("Sheriyar", 6, 87, 3.85),
        Student("Aqib", 7, 60, 2.5),
        Student("Farhan", 8, 90, 4.00)
    };

    Student maxMarksStudent = Student::getStudentWithHighestMarks(students, 8);
    std::cout << "Student with highest marks: " << std::endl;
    maxMarksStudent.displayDetails();

    return 0;
}