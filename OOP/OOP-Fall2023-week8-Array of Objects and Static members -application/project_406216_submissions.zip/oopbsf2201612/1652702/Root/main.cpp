/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
#include <string>

class Student {
private:
    std::string name;
    int id;
    double marks;
    double cgpa;
    static int serialNumber;

public:
    Student(const std::string& n, int i, double m, double c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        serialNumber++;
    }

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << "----------------------" << std::endl;
    }

    static int getSerialNumber() {
        return serialNumber;
    }

    double getMarks() {
        return marks;
    }
};

int Student::serialNumber = 0;

int main() {
    Student students[8] = {
        Student("John", 101, 85, 3.5),
        Student("Alice", 102, 90, 3.8),
        Student("Bob", 103, 78, 3.2),
        Student("Eve", 104, 95, 4.0),
        Student("Mike", 105, 88, 3.7),
        Student("Sara", 106, 91, 3.9),
        Student("David", 107, 76, 3.1),
        Student("Olivia", 108, 92, 3.9)
    };

    int highestMarks = 0;
    int highestMarksStudentIndex = 0;

    for (int i = 0; i < 8; i++) {
        students[i].displayDetails();
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksStudentIndex = i;
        }
    }

    std::cout << "Student with the highest marks: " << std::endl;
    students[highestMarksStudentIndex].displayDetails();

    return 0;
}
