/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
public:
    std::string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

    // Constructor to initialize the student object
    Student(std::string n, int i, float m, float c, int sn) : name(n), id(i), marks(m), cgpa(c), serialNumber(sn) {}

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << std::endl;
    }
};

int main() {
    // Create an array of pointers to Student objects for 8 students
    Student* students[8];

    // Input details for each student and allocate memory
    for (int i = 0; i < 8; i++) {
        std::string name;
        int id;
        float marks;
        float cgpa;

        std::cout << "Enter details for Student " << i + 1 << ":" << std::endl;
        std::cout << "Name: ";
        std::cin >> name;
        std::cout << "ID: ";
        std::cin >> id;
        std::cout << "Marks: ";
        std::cin >> marks;
        std::cout << "CGPA: ";
        std::cin >> cgpa;

        students[i] = new Student(name, id, marks, cgpa, i + 1);
        std::cout << std::endl;
    }

    // Find and display the student with the highest marks
    int highestMarksIndex = 0;
    float highestMarks = students[0]->marks;

    for (int i = 1; i < 8; i++) {
        if (students[i]->marks > highestMarks) {
            highestMarks = students[i]->marks;
            highestMarksIndex = i;
        }
    }

    std::cout << "Student with the highest marks:" << std::endl;
    students[highestMarksIndex]->displayDetails();

    // Free the allocated memory
    for (int i = 0; i < 8; i++) {
        delete students[i];
    }

    return 0;
}
