/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
public:
    string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber;
};

int main() {
    Student students[8];

    for (int i = 0; i < 8; i++) {
        cout << "Enter details for student " << i+1 << ":" << endl;
        cout << "Name: ";
        cin >> students[i].name;
        cout << "ID: ";
        cin >> students[i].id;
        cout << "Marks: ";
        cin >> students[i].marks;
        cout << "CGPA: ";
        cin >> students[i].cgpa;
        students[i].serialNumber = i + 1;
    }

    int maxMarks = 0;
    int maxMarksIndex = 0;

    for (int i = 0; i < 8; i++) {
        if (students[i].marks > maxMarks) {
            maxMarks = students[i].marks;
            maxMarksIndex = i;
        }
    }

    cout << "Details of the student with the highest marks:" << endl;
    cout << "Name: " << students[maxMarksIndex].name << endl;
    cout << "ID: " << students[maxMarksIndex].id << endl;
    cout << "Marks: " << students[maxMarksIndex].marks << endl;
    cout << "CGPA: " << students[maxMarksIndex].cgpa << endl;
    cout << "Serial Number: " << students[maxMarksIndex].serialNumber << endl;

    return 0;
}


