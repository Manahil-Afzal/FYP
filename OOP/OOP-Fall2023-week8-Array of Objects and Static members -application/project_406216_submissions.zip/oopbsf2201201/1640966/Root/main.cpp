/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;

class student{
    
private:
    string name;
    int id;
    double marks;
    double cgpa;
    static int serialnumber;
    int studentserialnumber;
    
public:
    student(){
        serialnumber++;
        studentserialnumber=serialnumber;
    }
    void inputdetails(){
        cout<<"enter name"<<name;
        cout<<"enter id"<<id;
        cout<<"enter marks"<<marks;
        cout<<"enter cgpa"<<cgpa;
    }
    
    void displaydetails(){
        cout<<"serialnumber"<<serialnumber;
        cout<<"name"<<name;
        cout<<"id"<<id;
        cout<<"marks"<<marks;
        cout<<"cgpa"<<cgpa;
    }
    
    double getmarks(){
        return marks;
    }
};

int student::serialnumber=0;
int main(){
    student students[8];
    for(int i=0;i<8;i++){
        cout<<"enter details for student"<<i+1<<std::endl;
        students[i].inputdetails();
    }
    double highestmarks=-1.0;
    int highestmarksindex=-1;
    
    for(int i=0;i<8;i++){
        if(students[i].getmarks()>highestmarks){
            highestmarks=students[i].getmarks();
            highestmarksindex=i;
        }
    }
    
    cout<<"details"<<std::endl;
    students[highestmarksindex].displaydetails();
    return 0;
}
    
        
    
    

    
    
    
        
    


