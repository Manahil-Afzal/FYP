/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
public:
    std::string name;
    int id;
    double marks;
    double cgpa;
    int serialNumber;

    Student() {
        static int count = 1;
        serialNumber = count++;
    }

    void input() {
        std::cout << "Enter Student Name: ";
        std::cin >> name;
        std::cout << "Enter Student ID: ";
        std::cin >> id;
        std::cout << "Enter Student Marks: ";
        std::cin >> marks;
        std::cout << "Enter Student CGPA: ";
        std::cin >> cgpa;
    }

    void display() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }
};

int main() {
    Student students[8];
    double highestMarks = -1.0;
    int studentWithHighestMarks = -1;

    for (int i = 0; i < 8; ++i) {
        std::cout << "Enter details for Student " << i + 1 << ":" << std::endl;
        students[i].input();

        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            studentWithHighestMarks = i;
        }
    }

    std::cout << "Details of the student with the highest marks:" << std::endl;
    students[studentWithHighestMarks].display();

    return 0;
}
