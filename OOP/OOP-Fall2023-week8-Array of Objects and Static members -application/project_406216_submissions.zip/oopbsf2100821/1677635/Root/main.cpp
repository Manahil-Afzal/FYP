#include<iostream>
using namespace std;

class Student {
    string name;
    int id;
    int marks;
    float cgpa;

public:
    void getinput() {
        cout << "Enter the name: ";
        cin >> name;
        cout << "Enter the student ID: ";
        cin >> id;
        cout << "Enter the marks: ";
        cin >> marks;
        cout << "Enter the CGPA: ";
        cin >> cgpa;
    }

    void display() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << "------------------------" << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int main() {
    Student details[8];

    // Get input for each student
    for (int i = 0; i < 8; i++) {
        cout << "Enter details for student " << i + 1 << ":" << endl;
        details[i].getinput();
    }

    // Display details for each student
    for (int i = 0; i < 8; i++) {
        cout << "Details for student " << i + 1 << ":" << endl;
        details[i].display();
    }

    // Find the student with the highest marks
    int maxMarks = details[0].getMarks();
    int maxIndex = 0;

    for (int i = 1; i < 8; i++) {
        if (details[i].getMarks() > maxMarks) {
            maxMarks = details[i].getMarks();
            maxIndex = i;
        }
    }

    // Display details of the student with the highest marks
    cout << "Student with the highest marks:" << endl;
    details[maxIndex].display();

    return 0;
}