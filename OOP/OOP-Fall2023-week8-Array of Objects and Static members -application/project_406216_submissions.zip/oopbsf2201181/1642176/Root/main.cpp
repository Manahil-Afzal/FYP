/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;

class Student{
    string name;
    int id, s_no;
    float marks, cgpa;
    static int serialNo;
    public:
        Student(){
            s_no = ++serialNo;
        }
        void input();
        float getMarks();
        int gets_no();
        void display();
};

int Student :: serialNo = 0;

int main(){
    Student arr[3];
    for(int j=0; j<3; j++){
        arr[j].input();
    }
    
    int id = 0;
    int temp = arr[0].getMarks();
    for(int i=0; i<8; i++){
        if(arr[i].getMarks() > temp){
            temp = arr[i].getMarks();
            id = i;
        }
    }
    
    arr[id].display();
}

void Student :: input(){
    cout<<"Enter your name: "<<endl;
            cin>>name;
            cout<<"Enter your ID: "<<endl;
            cin>>id;
            cout<<"Enter your marks: "<<endl;
            cin>>marks;
            cout<<"Enter your CGPA: "<<endl;
            cin>>cgpa;
            cout<<endl;
}

float Student :: getMarks(){
    return marks;
}

int Student :: gets_no(){
    return s_no;
}

void Student :: display(){
    cout<<"The details of  student with highest marks is"<<endl;
    cout<<endl;
    cout<<"Student name is: "<<name<<endl;
    cout<<"Student id is: "<<id<<endl;
    cout<<"Student serial no is: "<<s_no<<endl;
    cout<<"Student marks is: "<<marks<<endl;
    cout<<"Student CGPA is: "<<cgpa<<endl;
}