#include <iostream>
#include <string>

class Student {
public:
    Student(std::string name, int id, float marks, float cgpa)
        : name(name), id(id), marks(marks), cgpa(cgpa), serialNumber(++serialCounter) {}

    void displayDetails() const {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }

    static Student getStudentWithHighestMarks(Student students[], int size) {
        Student maxMarksStudent = students[0];
        for (int i = 1; i < size; i++) {
            if (students[i].marks > maxMarksStudent.marks) {
                maxMarksStudent = students[i];
            }
        }
        return maxMarksStudent;
    }

private:
    std::string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;
    static int serialCounter;
};

int Student::serialCounter = 0;

int main() {
    Student students[] = {
        Student("Alice", 1, 90, 3.8),
        Student("Bob", 2, 85, 3.7),
        Student("Charlie", 3, 92, 3.9),
        Student("David", 4, 88, 3.75),
        Student("Eve", 5, 95, 4.0),
        Student("Frank", 6, 89, 3.85),
        Student("George", 7, 91, 3.95),
        Student("Harry", 8, 87, 3.7)
    };

    Student maxMarksStudent = Student::getStudentWithHighestMarks(students, 8);
    std::cout << "Student with highest marks: " << std::endl;
    maxMarksStudent.displayDetails();

    return 0;
}