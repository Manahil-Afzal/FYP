/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
 #include<string>
 using namespace std;
 class student{
 	private:
 		string name;
 		int id;
 		int marks;
 	    float CGPA;
 		public:
 			static int serial_no;
			 void userinput()
			 {
			 	cout<<"ENTER STUDENT ID:"<<endl;
			 	cin>>id;
			 	cout<<"ENTER NAME:"<<endl;
			 	cin>>name;
			 	cout<<"ENTER MARKS:"<<endl;
			 	cin>>marks;
			 	cout<<"ENTER CGPA:"<<endl;
	            cin>>CGPA;
			}
			 void display()
			 {
			 	cout<<"\n"<<++serial_no<<"\t"<<id<<"\t"<<name<<"\t"<<marks<<"\t"<<CGPA<<endl;
			 }
 };
 int student::serial_no=0;
 int main()
 {
 	student std[8];
 	for(int i=0;i<8;i++)
 	{
 		cout<<"ENTER DETAIL OF STUDENT:"<<i+1<<endl;
 		std[i].userinput();
	 }
	 cout<<"DETAIL OF STUDENTS:"<<endl;
	 for(int i=0;i<8;i++)
 {

 	std[i].display();
 }
 cout<<"TOTAL NUMBERS OF OBJECTS:"<<student::serial_no<<endl;
 return 0;
 }
 
 
 
 
 