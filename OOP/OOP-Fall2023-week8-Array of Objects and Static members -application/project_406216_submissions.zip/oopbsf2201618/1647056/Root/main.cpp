/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;
class Student {
private:
    static int serialNumber;
    string name;
    int id;
    float marks;
    float cgpa;
public:
    Student() {
        id = ++serialNumber;
        name = "";
        marks = 0.0;
        cgpa = 0.0;
    }
    void inputDetails() {
        cout << "Enter student name: ";
        cin >> name;
        cout << "Enter student marks: ";
        cin >> marks;
        cout << "Enter student CGPA: ";
        cin >> cgpa;
    }
    void displayDetails() {
        cout << "Student #" << id << " Details:" << std::endl;
        cout << "Name: " << name <<endl;
        cout << "Marks: " << marks <<endl;
        cout << "CGPA: " << cgpa <<endl;
        cout << "------------------------" <<endl;
    }
    float getMarks() {
        return marks;
    }
};
int Student::serialNumber = 0;
int main() {
    const int numStudents = 8;
    Student students[numStudents];
    for (int i = 0; i < numStudents; i++) {
        cout << "Enter details for Student #" << i + 1 <<endl;
        students[i].inputDetails();
    }
    int highestMarksIndex = 0;
    for (int i = 1; i < numStudents; i++) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }
    cout << "Student with the highest marks:" <<endl;
    students[highestMarksIndex].displayDetails();
    return 0;
}
