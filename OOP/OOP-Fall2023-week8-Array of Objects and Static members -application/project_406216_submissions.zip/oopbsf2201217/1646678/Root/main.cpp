/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Student {
private:
    static int count; 
    int id;
    string name;
    float marks;
    float cgpa;

public:
    Student() {
        id = ++count; // Assign a serial number
    }

    void getData() {
        cout << "Enter student name: ";
        cin >> name;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter CGPA: ";
        cin >> cgpa;
    }

    void displayData() {
        cout << "Serial No: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    float getMarks() const {
        return marks;
    }
};

int Student::count = 0; // Initialize the static member

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    for (int i = 0; i < numStudents; i++) {
        cout << "Enter details for Student " << i + 1 << ":\n";
        students[i].getData();
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    float highestMarks = students[0].getMarks();

    for (int i = 1; i < numStudents; i++) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    cout << "Details of the student with the highest marks:\n";
    students[highestMarksIndex].displayData();

    return 0;
}