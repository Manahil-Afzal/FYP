/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
 
#include<iostream>
#include<string>
using namespace std;
struct student{
    string name;
    int id;
    int marks;
    double cgpa;
};
int main(){
    student students[8];
    for(int i=0;i<8;i++){
        cout<<"enter details for student"<<i+1<<":\n";
        
        cout<<"name:";
        cin>>students[i].name;
        
        cout<<"id:";
        cin>>students[i].id;
        
        cout<<"marks:";
        cin>>students[i].marks;
        
        cout<<"cgpa:";
        cin>>students[i].cgpa;
    }
  int highestMarks = -1;
  int highestMarksIndex = -1;
  
  for(int i=0;i<8;i++){
      if(students[i].marks > highestMarks)
      {
          highestMarks = students[i].marks;
          highestMarksIndex = i;
          
          }
      }
    cout<<"\nstudent with the highest marks:\n";
    cout<<"name:"<<endl;
    cout<<"id:"<<endl;
    cout<<"marks:"<<students[highestMarksIndex].marks<<endl;
    cout<<"cgpa:"<<students[highestMarksIndex].cgpa<<endl;
    return 0;
    
}
