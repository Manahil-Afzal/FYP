/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <iomanip>

class Student {
private:
    static int serialNumberCounter; // Static member to assign serial numbers
    int serialNumber;
    std::string name;
    int id;
    int marks;
    double cgpa;

public:
    Student() : serialNumber(++serialNumberCounter) {}

    void getData() {
        std::cout << "\nEnter details for Student " << serialNumber << ":\n";
        std::cout << "Name: ";
        std::cin.ignore(); // Clear the buffer
        std::getline(std::cin, name);

        std::cout << "ID: ";
        std::cin >> id;

        std::cout << "Marks: ";
        std::cin >> marks;

        std::cout << "CGPA: ";
        std::cin >> cgpa;
    }

    void displayData() const {
        std::cout << std::setw(5) << serialNumber << std::setw(15) << name << std::setw(10) << id
                  << std::setw(10) << marks << std::setw(10) << std::fixed << std::setprecision(2) << cgpa << std::endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::serialNumberCounter = 0; // Initialize static member

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    for (int i = 0; i < numStudents; ++i) {
        students[i].getData();
    }

    // Find the student with the highest marks
    int highestMarks = -1;
    int highestMarksIndex = -1;

    for (int i = 0; i < numStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Display details of the student with the highest marks
    std::cout << "\nDetails of the student with the highest marks:\n";
    std::cout << std::setw(5) << "Serial" << std::setw(15) << "Name" << std::setw(10) << "ID"
              << std::setw(10) << "Marks" << std::setw(10) << "CGPA" << std::endl;
    students[highestMarksIndex].displayData();

    return 0;
}
