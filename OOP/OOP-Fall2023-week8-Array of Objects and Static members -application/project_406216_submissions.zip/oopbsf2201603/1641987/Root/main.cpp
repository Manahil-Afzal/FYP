/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

using namespace std;

class Student {
public:
    string name;
    int id;
    double marks;
    double cgpa;
    int serialNumber;

    Student() {
        static int serial = 1;
        serialNumber = serial++;
    }

    void inputDetails() {
        cout << "Enter student name: ";
        cin >> name;
        cout << "Enter student ID: ";
        cin >> id;
        cout << "Enter student marks: ";
        cin >> marks;
        cout << "Enter student CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int main() {
    Student students[8];

    for (int i = 0; i < 8; i++) {
        cout << "Enter details for student " << i + 1 << ":" << endl;
        students[i].inputDetails();
    }

    int highestMarksIndex = 0;
    double highestMarks = students[0].marks;

    for (int i = 1; i < 8; i++) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            highestMarksIndex = i;
        }
    }

    cout << "Student with the highest marks is:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
