/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string>
using namespace std;

class student{
    private:
        string name;
        int id;
       
        float cgpa;
    public:
     int marks;
    static int serial_no;
        student(){
            serial_no++;
        }
        student(string n, int i, int m, float cpa){
            name = n;
            id = i;
            marks = m;
            cgpa = cpa;
            serial_no++;
        }
        
        void display_info(){
            cout<<"Name: "<<name<<endl<<"ID: "<<id<<endl<<"Marks: "<<marks<<endl<<"CGPA: "<<cgpa<<endl<<"Serial_no: "<<serial_no;
        }
};
int student::serial_no = 0;

int main(){
    int size = 8;
    student s[size];
    //taking input
    for(int i = 0; i < size; i++){
        string name;
        int id;
        int marks;
        float cgpa;
        
        cout<<"Taking student details: "<<endl;
        cout<<"Enter the name of the student: ";
        cin>>name;
        cout<<endl<<"Enter the ID of student: ";
        cin>>id;
        cout<<endl<<"Enter the student's marks: ";
        cin>>marks;
        cout<<endl<<"Enter the CGPA of student: ";
        cin>>cgpa;
        
        s[i] = student(name, id, marks, cgpa);
    }
    s[0].display_info();
    
    int highest;
          highest = s[0].marks;
      for(int i = 0; i < size; i++){
          
          if(s[i].marks > highest){
              highest = s[i].marks;
          }
      }
          cout<<"Highest marks are: "<<highest;
     
      
    return 0;
}