/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Student{
  public:
  string name;
  int id;
  float cgpa;
  int marks;
  void get_detail(){
      cout<<"Enter the name";
      cin >>name;
      cout<<"Enter the student id";
      cin>>id;
      cout<<"Enter the marks ";
      cin>>marks;
      cout<<"Enter the cgpa";
      cin>>cgpa;
  }
  void put_detail(){
      cout<<"Enter the name:"<<name<<endl;
      cout<<"Enter the student id:"<<id<<endl;
      cout<<"Enter the marks :"<<marks<<endl;
      cout<<"Enter the cgpa :"<<cgpa<<endl;
  }
  //void calculate(){}
     
};
main(){
    Student st[8];
     for( int i=0; i<8; i++ ){
         cout<<"Student "<<i+1<<endl;
      st[i].get_detail();
      }
    for( int i=0; i<8; i++ ){
    if(st[i].marks>st[0].marks){
        st[0].marks=st[i].marks;
        st[0].name=st[i].name;
        st[0].id=st[i].id;
        st[0].cgpa=st[i].cgpa;
     }
     }
     cout<<"The highet marks are:"<<st[0].marks<<endl;
     cout<<"the detail of the highest marks student"<<endl;
     st[0].put_detail();
     
}