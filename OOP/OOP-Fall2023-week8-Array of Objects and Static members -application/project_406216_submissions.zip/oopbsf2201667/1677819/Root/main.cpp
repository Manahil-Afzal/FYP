/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
#include<string>
using namespace std;
class Student{
    private:
    string name;
    int id;
    int marks;
    float CGPA;
    int serial;
    static int serialcount;
    public:
    int getmarks(){
       return marks; 
    }
    Student(){
        serial=serialcount++;
    };
    void getdata(int i);
    void putdata();
};
int Student::serialcount=0;
void Student:: getdata(int i){
    cout<<"======================="<<endl;
    cout<<i<<" Student data\n";
    cout<<"======================="<<endl;
    cout<<"Enter student name:"<<endl;
    cin>>name;
    cout<<"Enter student id:"<<endl;
    cin>>id;
    cout<<"Enter student marks:"<<endl;
    cin>>marks;
    cout<<"Enter student CGPA:"<<endl;
    cin>>CGPA;
};
void Student::putdata(){
    
    cout<<"\n"<<serial<<"\t"<<name<<"\t"<<id<<"\t"<<marks<<"\t"<<CGPA;
    
};
int main(){
    int HM_marks_index=0;
    int HM_marks=0;
    Student s1[8];
    for(int i=1;i<3;i++){
        s1[i].getdata(i);
    };
    cout<<"====================================="<<endl;
    cout<<"#\tName\tId\tMarks\tCGPA\n";
    cout<<"====================================="<<endl;
    for(int i=1;i<3;i++){
        s1[i].putdata();
        if(s1[i].getmarks()>HM_marks){
            HM_marks_index=i;
            HM_marks=s1[i].getmarks();
        }
    };
    cout<<"\n---------------------Details of the student with the highest marks--------------------------\n";
    cout<<"====================================="<<endl;
    cout<<"#\tName\tId\tMarks\tCGPA\n";
    cout<<"====================================="<<endl;
    s1[HM_marks_index].putdata();
    
     
    
    
}






