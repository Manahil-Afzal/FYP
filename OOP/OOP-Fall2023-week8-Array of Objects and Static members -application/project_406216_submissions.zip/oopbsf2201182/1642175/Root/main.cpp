/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;

class student{
   public:
    string name;
    string Id;
    int marks;
    float cgpa;
    int serial;
     static int count;
   
    void putdata()
    {
        cout<<"\n enter student name:";
        cin>>name;
        cout<<"\n enter student Id:";
        cin>>Id;
        cout<<"\n enter student marks:";
        cin>>marks;
        cout<<"\n enter student cgpa:";
        cin>>cgpa;
        serial =++count;
        
    }
    void getdata()
    {
        cout<<"name"<<name<<endl;
        cout<<"Id"<<Id<<endl;
        cout<<"marks"<<marks<<endl;
        cout<<"cgpa"<<cgpa<<endl;
        cout<<"serial"<<serial<<endl;
    }
    
   
    
};
int student::count = 0;
 void highestmarks( student arr[],int size)
    {
        student std;
        std.marks=0;
       for(int i=0;i<size;i++){
           if(std.marks<arr[i].marks)
           {
               std.marks=arr[i].marks;
               std.name=arr[i].name;
               std.cgpa=arr[i].cgpa;
               std.Id=arr[i].Id;
               std.serial=arr[i].serial;
           }
       }
        cout<<"name"<<std.name<<endl;
        cout<<"Id"<<std.Id<<endl;
        cout<<"marks"<<std.marks<<endl;
        cout<<"cgpa"<<std.cgpa<<endl;
       cout<<"serial"<<std.serial<<endl;
    }
    
int main()
{
    student std[8];
    for(int i=0;i<=7;i++)
    {
        cout<<"\nEnter details of "<<i+1<<" student";
        std[i].putdata();
    }

     
  for(int i=0;i<=7;i++)
  {
    cout<<"\nDetails of student";
    std[i].getdata();
  }
  
  highestmarks(std,8);
}