/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student {
    private :
    string name;
    int id,marks;
    float CGPA;
    public:
    void getdetail(){
        cout<<"Enter name of stdent";
        cin>>name;
        cout<<"Enter student id";
        cin>>id;
        cout<<"Enter marks";
        cin>>marks;
        cout<<"Enter cgpa";
        cin>>CGPA;}
        void putdetail(){
            cout<<"Name:"<<name<<endl;
            cout<<"ID:"<<marks<<endl;
            cout<<"Marks:"<<marks<<endl;
            cout<<"CGPA:"<<CGPA<<endl;
        }
               int getMarks() {
        return marks;
    }
 };
            main()
            {
                Student st[8];
                for (int i=0;i<8;i++)
                {
                    cout<<"student "<<i+1<<endl;
                    st[i].getdetail();
                }
                
    int highestMarks = 0;
    int highestMarksIndex = 0;
    for (int i = 0; i < 8; i++) {
        if (st[i].getMarks() > highestMarks) {
            highestMarks = st[i].getMarks();
            highestMarksIndex = i;
        }
    }
cout << "Student with the highest marks: " << endl;
    st[highestMarksIndex].putdetail();


}