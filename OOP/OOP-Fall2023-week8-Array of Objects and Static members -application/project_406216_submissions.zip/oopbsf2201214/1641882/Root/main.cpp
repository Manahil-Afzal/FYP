/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>

class Student {
private:
    static int serialNumber; // Static member to assign serial numbers
    int studentID;
    std::string name;
    int marks;
    double cgpa;

public:
    Student() {
        studentID = ++serialNumber; // Assign a serial number
    }

    // Method to input student details
    void inputDetails() {
        std::cout << "Enter student name: ";
        std::cin.ignore();
        std::getline(std::cin, name);

        std::cout << "Enter student marks: ";
        std::cin >> marks;

        std::cout << "Enter student CGPA: ";
        std::cin >> cgpa;
    }

    // Method to display student details
    void displayDetails() {
        std::cout << "Student ID: " << studentID << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }

    // Getter met hod for marks
    int getMarks() {
        return marks;
    }
};

int Student::serialNumber = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];
    int highestMarks = -1;
    int highestMarksIndex = -1;

    for (int i = 0; i < numStudents; i++) {
        std::cout << "Enter details for Student " << i + 1 << ":" << std::endl;
        students[i].inputDetails();

        // Check if this student has the highest marks
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    std::cout << "\nDetails of the student with the highest marks:" << std::endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}

    