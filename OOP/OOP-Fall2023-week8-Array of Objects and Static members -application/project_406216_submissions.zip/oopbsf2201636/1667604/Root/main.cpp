/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <iomanip>

class Student {
public:
    std::string name;
    int id;
    double marks;
    double cgpa;
    int serialNumber;

    // Parameterized constructor to initialize the object with given values
    Student(std::string n, int i, double m, double c, int serial)
        : name(n), id(i), marks(m), cgpa(c), serialNumber(serial) {}

    // Default constructor
    Student() : serialNumber(0) {}

    // Function to display student details
    void displayDetails() const {
        std::cout << "Serial Number: " << std::setw(2) << serialNumber
                  << " | Name: " << std::setw(15) << name
                  << " | ID: " << std::setw(5) << id
                  << " | Marks: " << std::setw(5) << marks
                  << " | CGPA: " << std::setw(4) << cgpa << std::endl;
    }
};

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; ++i) {
        std::cout << "Enter details for Student " << i + 1 << ":\n";
        std::cout << "Name: ";
        std::cin >> students[i].name;
        std::cout << "ID: ";
        std::cin >> students[i].id;
        std::cout << "Marks: ";
        std::cin >> students[i].marks;
        std::cout << "CGPA: ";
        std::cin >> students[i].cgpa;

        // Assigning serial number based on order of creation
        students[i].serialNumber = i + 1;
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    for (int i = 1; i < numStudents; ++i) {
        if (students[i].marks > students[highestMarksIndex].marks) {
            highestMarksIndex = i;
        }
    }

    // Display details of the student with the highest marks
    std::cout << "\nDetails of student with the highest marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;
}
