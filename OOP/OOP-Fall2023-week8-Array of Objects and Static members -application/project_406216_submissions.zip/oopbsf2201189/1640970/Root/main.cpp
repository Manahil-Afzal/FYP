/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;
class Student {
public:
    string name;
    int id;
    double marks;
    double cgpa;
    int serialNumber; // Serial number based on order of creation

    static int nextSerialNumber;

    Student() {
        serialNumber = nextSerialNumber++;
    }

    void inputDetails() {
        cout << "Enter student name: ";
        cin >> name;
        cout << "Enter student ID: ";
        cin >> id;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int Student::nextSerialNumber = 1;

int main() {
    Student students[8];

    for (int i = 0; i < 8; i++) {
        cout << "Enter details for student " << i + 1 << ":\n";
        students[i].inputDetails();
    }

    double highestMarks = 0.0;
    int highestMarksIndex = -1;

    for (int i = 0; i < 8; i++) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            highestMarksIndex = i;
        }
    }

    cout << "\nDetails of the student with the highest marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;}
