/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
private:
    int id;
    char name[100];
    int marks;
    float cgpa;

public:
    void inputData() {
        cout << "Enter Student's ID: ";
        cin >> id;

        cout << "Enter Student's Name: ";
        cin >> name;

        cout << "Enter Student's Marks: ";
        cin >> marks;

        cout << "Enter Student's CGPA: ";
        cin >> cgpa;
    }

    int getMarks() const {
        return marks;
    }

    void displayData() const {
        cout << "ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    for (int i = 0; i < numStudents; ++i) {
        cout << "\nEnter details for Student " << i + 1 << endl;
        students[i].inputData();
    }

    int highestMarksIndex = 0;
    for (int i = 1; i < numStudents; ++i) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }

    cout << "\nDetails of Student with Highest Marks:\n";
    students[highestMarksIndex].displayData();

    return 0;
}
