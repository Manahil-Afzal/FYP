/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
#include<string>

using namespace std;

class Students
{
	public:
		string stdName;
		string stdID;
		int marks;
		float CGPA;
		static int studentCount;
		Students (){
		stdID=studentCount++;
}

void getDetails(){
	cout<<"Enter student name:"<<endl;
	cin>>stdName;
	cout<<"Enter student ID:"<<endl;
	cin>>stdID;
	cout<<"Enter marks:"<<endl;
	cin>>marks;
	cout<<"Enter CGPA:"<<endl;
	cin>>CGPA;
}

void displayDetails(){
	cout<<"Student Name:"<<stdName<<"Student ID:"<<stdID<<"Marks:"<<marks<<"CGPA:"<<CGPA<<endl;
	}
};

int  Students::studentCount=1;

int main()
{
	const int NumofStudents=8;
	Students std[NumofStudents];
	
	for(int i=0; i<NumofStudents; ++i) {
		cout<<"Enter details for Student"<<i+1<<":"<<endl;
		std[i].getDetails();
	}
	
	int highestMarks=0;
	int highestMarksStudentsIndex=0;
	
	for(int i=0; i<NumofStudents; ++i) {
		if (std[i].marks>highestMarks) {
			highestMarks=std[i].marks;
			highestMarksStudentsIndex=i;
		}
	}
	
	cout<<"Details of the Student got highest marks:"<<endl;
	std[highestMarksStudentsIndex].displayDetails(); "\n" ;
	
	return 0;
}