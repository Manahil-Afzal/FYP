#include <iostream>
#include <string>

class Student {
private:
    static int serialNumber;
    std::string name;
    int id;
    double marks;
    double cgpa;

public:
    Student(const std::string& n, int i, double m, double c) : name(n), id(i), marks(m), cgpa(c) {
        id = serialNumber++;
    }

    void display() {
        std::cout << "Student #" << id << " - Name: " << name << ", ID: " << id << ", Marks: " << marks << ", CGPA: " << cgpa << std::endl;
    }

    double getMarks() {
        return marks;
    }
};

int Student::serialNumber = 1;

int main() {
    Student* students[8];

    for (int i = 0; i < 8; i++) {
        std::string name;
        double marks, cgpa;
        
        std::cout << "Enter details for Student " << i + 1 << ":" << std::endl;
        std::cout << "Name: ";
        std::cin >> name;
        std::cout << "Marks: ";
        std::cin >> marks;
        std::cout << "CGPA: ";
        std::cin >> cgpa;

        students[i] = new Student(name, i + 1, marks, cgpa);
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    double highestMarks = students[0]->getMarks();

    for (int i = 1; i < 8; i++) {
        if (students[i]->getMarks() > highestMarks) {
            highestMarks = students[i]->getMarks();
            highestMarksIndex = i;
        }
    }

    std::cout << "Details of the student with the highest marks:" << std::endl;
    students[highestMarksIndex]->display();

    // Clean up dynamic memory
    for (int i = 0; i < 8; i++) {
        delete students[i];
    }

    return 0;
}
