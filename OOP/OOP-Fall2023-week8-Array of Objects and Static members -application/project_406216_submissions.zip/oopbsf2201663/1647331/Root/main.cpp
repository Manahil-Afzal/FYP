/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

// Define a simple structure to store student details
struct Student {
    std::string name;
    int id;
    int marks;
    double cgpa;
};

int main() {
    Student students[8]; // An array to store details of 8 students

    // Input details for each student
    for (int i = 0; i < 8; i++) {
        std::cout << "Enter details for student " << i + 1 << ":\n";
        
        std::cout << "Name: ";
        std::cin >> students[i].name;
        
        std::cout << "ID: ";
        std::cin >> students[i].id;
        
        std::cout << "Marks: ";
        std::cin >> students[i].marks;
        
        std::cout << "CGPA: ";
        std::cin >> students[i].cgpa;
    }

    // Find the student with the highest marks
    int highestMarks = -1;
    int highestMarksIndex = -1;

    for (int i = 0; i < 8; i++) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            highestMarksIndex = i;
        }
    }

    // Display the details of the student with the highest marks
    std::cout << "\nStudent with the highest marks:\n";
    std::cout << "Name: " << students[highestMarksIndex].name << std::endl;
    std::cout << "ID: " << students[highestMarksIndex].id << std::endl;
    std::cout << "Marks: " << students[highestMarksIndex].marks << std::endl;
    std::cout << "CGPA: " << students[highestMarksIndex].cgpa << std::endl;

    return 0;
}