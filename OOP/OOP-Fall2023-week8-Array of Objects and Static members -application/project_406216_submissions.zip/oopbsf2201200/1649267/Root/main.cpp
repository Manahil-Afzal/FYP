/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/#include<iostream>
using namespace std;
class student
{
	private:
		char name[20];
		int id;
		int marks;
		float cgpa;
		public:
			void getdata()
			{
				cout<<"Enter name :";
				cin>>name;
				cout<<"Enter ID :";
				cin>>id;
				cout<<"Enter marks :";
				cin>>marks;
				cout<<"Enter cgpa :";
				cin>>cgpa;
			}
		void putdata(){
			cout<<"  Name :"<<name<<endl<<"  ID :"<<id<<endl<<"  Marks :"<<marks<<endl<<"  CGPA :"<<cgpa;
		}
};
int main()
{
	student s[8];
	for(int i=0;i<8;i++){
		cout<<"Enter Details of "<<i+1<<" Student :"<<endl;
		s[i].getdata();	
	}

cout<<"            ********          "<<endl;
	cout<<"Details of students are :"<<endl;
		for(int i=0;i<8;i++){
			cout<<"\nDetail of student "<<i+1<<" :"<<endl;
			s[i].putdata();
			cout<<"\n     ******      "<<endl;
		}
	return 0;
}