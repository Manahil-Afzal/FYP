/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
#include<string>
using namespace std;

class Employee{
    private:
    string empname;
    int Id,age,retyear,fig;
    
    public:
    void input();
    void retire();
    void output();
};

void Employee::input(){
    cout<<"Enter the employee's name"<<endl;
    cin>>empname;
    cout<<"Enter the employee's id"<<endl;
    cin>>Id;
    cout<<"Enter the employee's age in year 2020"<<endl;
    cin>>age;
}

void Employee::retire(){
    fig=60-age;
    retyear=2020+fig;
}
void Employee::output(){
    cout<<"The employee name is:"<<empname<<endl;
    cout<<"The employee id is: "<<Id<<endl;
    cout<<"The employee age in 2020 is:"<<age<<endl;
    cout<<"The retirment year for employee is:"<<retyear<<endl;
}
int main(){
    Employee obj;
    obj.input();
    obj.retire();
    obj.output();
    return 0;
}
