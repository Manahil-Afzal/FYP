/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;

class employee {
    private:
    string Name;
    int ID,age,RetYear,Fig ;
    public:
    void func_input();
    void func_Ret();
    void func_output();
};

void employee :: func_input(){
    cout<<"Enter employee's name:"<<endl ;
    cin>>Name ;
    cout<<"Enter employee's ID:"<<endl ;
    cin>>ID;
    cout<<"Enter employee's age in year 2020"<<endl ;
    cin>>age ;
} 

void employee ::  func_Ret() {
    Fig=60-age;
    RetYear= 2020+Fig;
}

void employee ::func_output(){
    cout<<"Enter employee's name:"<<Name<<endl ;
  
    cout<<"Enter employee's ID:"<<ID<<endl ;
    
    cout<<"Enter employee's age in year 2020"<<age<<endl ;
   
} 

int main() {
    
    employee obj ;
   obj .func_input() ;
   obj .func_Ret() ;
   obj . func_output();
    return 0;
}