
#include<iostream>

using namespace std;

class Employee {
	private:
		string name;
		int id;
		int ageIn2020;
		int retirementYear;
		public:
			void getEmployeeData(){
				cout<<"Enter Your name: ";
				cin>>name;
				cout<<"\nEnter Your id: ";
				cin>>id;
				cout<<"\nEnter Your age in 2020: ";
				cin>>ageIn2020;
			}
			
			void calculateRetirementYear(){
				int retirementAge=60;
				int remainingYears=60-ageIn2020;
				retirementYear=2020+remainingYears;
				
			}
			
			int getRetirementYear(){
				return retirementYear;
			}
	
};

int main(){
	Employee emp;
	emp.getEmployeeData();
	emp.calculateRetirementYear();
	
	cout<<"\nYour Of retirement: "<<emp.getRetirementYear();
	return 0;
}/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/