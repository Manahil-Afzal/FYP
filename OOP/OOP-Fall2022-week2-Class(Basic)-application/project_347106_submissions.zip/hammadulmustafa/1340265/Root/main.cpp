#include <iostream>
using namespace std;

class employee{
	private:
	 string name;
	 int id;
	 int age;
	 int year = 2020;
	 int retirement_year;
	 public:
	 void input(){
	 	cout<<"Please Enter the Employee's name: ";
	 	cin>>name;
	 	cout<<"Please Enter the ID: ";
	 	cin>>id;
	 	cout<<"Please Enter the age: ";
	 	cin>>age;
	 }
	 int req(int a){
	 	if(a >=60){
	 		cout<<"Already retire: age_";
	 		return a;
		 }
	 	return 60-a+2020;
	 }
	 void display(){
	 	cout<<"Employee Name's is: "<<name<<endl;
	 	cout<<"Id is: "<<id<<endl;
	 	cout<<"Age is: "<<age<<endl;
	 	cout<<"Retirement : ";
	 	cout<<req(age);
	 }
};
int main(){
	employee obj;
	obj.input();
	obj.display();
	return 0;
}