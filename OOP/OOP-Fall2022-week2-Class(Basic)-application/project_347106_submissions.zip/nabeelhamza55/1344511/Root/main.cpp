/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;


class Employee {
	public:
		string name;
		int id;
		int age;
		int retirement;
		
	void input(){
		cout<<"Enter name: ";
		cin>>name;
		cout<<"Enter ID: ";
		cin>>id;
		cout<<"Enter age in 2020: ";
		cin>>age;
		
		
	};
	
	void calculate(){
		int total = 60 - age;
		retirement = total + 2020;
	};
	
	void get(){
		cout<<"\nname: " <<name<<endl;
		cout<<"ID: "<<id<<endl;
		cout<<"Retirement year is: "<<retirement<<endl;
		
	};
};
 int main(){
 	Employee emp;
 	emp.input();
 	emp.calculate();
 	emp.get();
 }