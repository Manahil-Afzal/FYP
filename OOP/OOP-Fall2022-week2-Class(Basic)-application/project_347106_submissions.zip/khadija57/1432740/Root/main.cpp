/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class Employee
{
    char name[30];
    int id;
    int age;
    int retirement;
    public:
  void input()
{
    cout<<"Enter Employee Name"<<endl;
    cin>>name;
    cout<<"Enter Employee Id"<<endl;
    cin>>id;
    cout<<"Enter Age In Year 2020"<<endl;
    cin>>age;
}
void calculate()
{
 retirement=60-age+2020;
}
void display()
{
    cout<<"Details Of Employee"<<endl;
    cout<<"Employee Name:"<<name<<endl;
    cout<<"Employee Id:"<<id<<endl;
    cout<<"Employee Age:"<<age<<endl;
    cout<<"Employee Retirement Year:"<<retirement<<endl;
}
};
int main()
{
    int i;
    Employee e;
    for(i=0;i<=3;i++)
   {
       cout<<"Enter Details Of " <<i+1<<  "Employee"<<endl;
    e.input();
    }
    for(i=0;i<=3;i++)
{
    cout<<"Detail of" <<i+1<< "Employee";
    e.display();
}
return 0;
}