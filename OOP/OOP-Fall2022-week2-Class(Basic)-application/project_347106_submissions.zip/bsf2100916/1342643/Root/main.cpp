/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
#include<string>
using namespace std;
class Employees
{
    private:
string empName;
int Id, age, retYear,fig;
public:
void input_func();
void retire_func();
void output_func();
};
void Employees::input_func()
{
    cout<<"Enter the employee name:";
    cin>>empName;
    cout<<"Enter the employee Id:";
    cin>> Id;
    cout<<"Enter the employee age in 2020";
    cin>>  age;
    
}
void Employees::retire_func()
{
    fig=60-age;
    retYear=2020+fig;
}
void Employees::output_func()
{
    cout<< "the employee name is:"<< empName<< endl;
    cout<<"The employee Id is:"<<  Id<< endl;
    cout<<"The employee age in 2020 is:"<< age<< endl;
    cout<<"The retirement year for employee is"<<retYear<<endl;
    
}
int main()
{
Employees obj;
obj.input_func();
obj.retire_func();
obj.output_func();

return 0;
}