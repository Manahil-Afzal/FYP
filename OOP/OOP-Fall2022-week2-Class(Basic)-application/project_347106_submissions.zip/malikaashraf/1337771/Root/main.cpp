/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
using namespace std;


class employee{
	public:
		string name;
		int id;
		int age;
		int retire_year;
		
	void getfunciton(){
		cout<<"Enter name: "<<endl;
		cin>>name;
		cout<<"Enter ID: "<<endl;
		cin>>id;
		cout<<"Enter age in 2020: "<<endl;
		cin>>age;
	};
	
	void invokefunciton(){
		int total = 60 - age;
		retire_year = total + 2020;
	};
	
	void setfunction(){
		cout<<"Name= " <<name<<endl;
		cout<<"ID= "<<id<<endl;
		cout<<"AGE= "<<age<<endl;
		cout<<"Retirement year is= "<<retire_year<<endl;
		
	};
};
 int main(){
 	employee obj;
 	obj.getfunciton();
 	obj.invokefunciton();
 	obj.setfunction();
 }