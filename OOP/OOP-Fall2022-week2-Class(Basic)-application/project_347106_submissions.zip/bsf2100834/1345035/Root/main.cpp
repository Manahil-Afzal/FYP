/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;
class  employee{
public:
    string name;
    string Id;
    int age;
    int retirementYear;
    void inputFunction();  // method 1
    void calculation();       // method 2
    void display();             //  method 3
};
void employee:: inputFunction(){
    cout << "Enter the name of employee:" << endl;
    cin >> name;
    cout << "Enter the Id of employee:" << endl;
    cin >> Id;
    cout << "Enter the age of employee:" << endl;
    cin >> age;
    }
void employee:: calculation(){
    int retirementAge = 60;
    int startJobYear ;
    cout << "Enter the starting job year: " << endl;
    cin >> startJobYear;
    retirementYear = startJobYear + retirementAge;
}
void employee:: display(){
    cout << "The name of employee is  " << name << endl;
    cout << "The Id of employee is  " << Id << endl;
    cout << "The age of employee is  " << age << endl;
    cout << "The retirement Year of employee is  " << retirementYear << endl;
}
int main()
{
employee obj;
obj.inputFunction();
obj.calculation();
obj.display();
    return 0;
}