/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee{
     public:
    string name;
    int id;
    int age;
    int retirementYear;
    void method1();
    void method2();
    void method3();
};
void employee::method1()
{
    cout<<"enter the name of employee"<<endl;
    cin>>name;
    cout<<"enter the id"<<endl;
    cin>>id;
    cout<<"enter the age"<<endl;
    cin>>age;
}
void employee::method2()
{
    int birthYear;
    cout<<"enter your birth year"<<endl;
    cin>>birthYear;
    retirementYear=birthYear+59;
    cout<<"your retirement year is"<<retirementYear<<endl;
}
void employee::method3()
{
    cout<<"the name of employee is"<<name<<endl;
    cout<<"the id of employee is"<<id<<endl;
    cout<<"the age of employee is"<<age<<endl;
    cout<<"the retirement yearof employee is"<<retirementYear<<endl;
}
int main()
{
    employee obj;
   obj.method1();
   obj.method2();
    obj.method3();
    return 0;
}
