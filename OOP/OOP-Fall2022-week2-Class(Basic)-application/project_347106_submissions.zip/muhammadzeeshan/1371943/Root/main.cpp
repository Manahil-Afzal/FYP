/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
using namespace std;

class employee
{
    public:
    string name;
    int id, age, retirement_year;


    void fun_1()
    {
        cout<<"Enter your name here :"<<endl;
        cin>>name;
        cout<<"Enter your ID here :"<<endl;
        cin>>id;
        cout<<"Enter your age in 2020 here :"<<endl;
        cin>>age;
    }
    void fun_2()
    {
        retirement_year=age-60; 
        cout<<"your retirement age is :"<<retirement_year<<endl;
    }
    void display()
    {
        cout<<"your entered name is :"<< name<<endl;
        cout<<"your entered id is :"<<id<<endl;
        cout<<"your entered age is :"<<age<<endl;
    }
    
};

int main()

{
    employee obj;
    obj.fun_1();
    obj.display();
    obj.fun_2();
    return 0;
}
