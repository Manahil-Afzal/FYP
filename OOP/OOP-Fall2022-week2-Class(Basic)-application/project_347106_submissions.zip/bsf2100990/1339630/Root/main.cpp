/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee{
	private:
	string name;
	int id;
	int age;
	int retirement;
	public:
	int input(){
		cout<<"enter name :";
		cin>>name;
		cout<<"enter id:";
		cin>>id;
		cout<<"enter age in year 2020:";
		cin>>age;
	}
	int retirementyear(){
		retirement=2020;
		for(int i=0;i<60;i++){
			if(age+i==60){
				break;
			}
			else if(age>60){
				cout<<"you already work more then your retirement year:";
				retirement=false;
				break;
			}
			else{
				retirement+=1;
			}
		}
		
	}
	int display(){
		cout<<"\n yor Enter detail is:";
		cout<<"\n name:"<<name<<"\n id:"<<id<<"\n age:"<<age<<"\nretirement year:"<<retirement;
	}
};
main ()
{
employee emp1;
emp1.input();
emp1.retirementyear();
emp1.display();	
}