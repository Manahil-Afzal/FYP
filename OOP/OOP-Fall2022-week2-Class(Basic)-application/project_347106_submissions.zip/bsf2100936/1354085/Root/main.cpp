/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employees{
    private:
    string name;
    string id;
    int Agein2020,RetirementYear;
    public:
    void funInput();
    void Retirement();
    void Display();
};
void employees::funInput(){
    cout<<"Enter name:";
    cin>>name;
    cout<<"Enter id:";
    cin>>id;
    cout<<"Enter age in 2020:";
    cin>>Agein2020;
    
}
void employees::Retirement(){
    int yearLeftinRetirement,Retirement=60;
    if(Agein2020<=60){
        yearLeftinRetirement=Retirement-Agein2020;
        RetirementYear=yearLeftinRetirement+2020;
    }else{
        yearLeftinRetirement=Agein2020-Retirement;
        RetirementYear=2020-yearLeftinRetirement;
    }
}
void employees::Display(){
    cout<<"employee name:"<<name<<endl;
    cout<<"employee id:"<<id<<endl;
    cout<<"employee Age in 2020:"<<Agein2020<<endl;
    cout<<"Retirement Year:"<<name<<"is"<<RetirementYear;
}
int main(){
    employees Obj;
    Obj.funInput();
    Obj.Retirement();
    Obj.Display();
    
}