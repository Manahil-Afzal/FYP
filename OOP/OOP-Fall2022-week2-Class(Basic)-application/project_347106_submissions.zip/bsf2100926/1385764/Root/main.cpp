
/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>	
using namespace std;
class employees {
private:
	string name;
	string id;
	int AgeIn2020, RetirementYear;
public:
	void functionInput();
	void  Retirement();
	void Display();
	employees() {
		name = "";
		id = "";
		AgeIn2020 = 0;
		RetirementYear = 0;
	}
};
	void employees::functionInput() {
		cout << "enter name : ";
		cin >> name;
		cout << "enter id : ";
		cin >> id;
		cout << "enter age in 2020 : ";
		cin >> AgeIn2020;
		
	}
	void employees::Retirement() {
		int YearLeftINRetirement,retirement = 60;
		if (AgeIn2020 <= 60) {
			YearLeftINRetirement = retirement - AgeIn2020;
			RetirementYear = YearLeftINRetirement + 2020;
		}
		else {
			YearLeftINRetirement = AgeIn2020-retirement;
			RetirementYear = 2020-YearLeftINRetirement;
		}
	}
	void employees::Display(){
		cout << "Employee's Name is : " << name<<endl;
		cout << "Employee's id is : " << id<<endl;
		cout << "Employee's Age in 2020 : " << AgeIn2020<<endl;
		cout << "Retirement year of " << name << " is " << RetirementYear;

	}

	int main() {
		employees obj;
		obj.functionInput();
		obj.Retirement();
		obj.Display();

	}
