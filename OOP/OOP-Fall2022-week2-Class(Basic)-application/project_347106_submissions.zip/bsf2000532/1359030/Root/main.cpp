/*Write a C++ program that defines a class for employee. The class should have four data members for 
employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include<iostream>
using namespace std;

class EMPLOYEE
{
	private:
    char name[25];
    string id;
    int age;
    int retirement_age;

    public:
    void GetData()           
    {
        cout<<"Enter Employee's Name: ";
        cin>>name;
        cout<<"Enter Employee's Id: ";
        cin>>id;
        cout<<"Enter Current Employee's Age: ";
        cin>>age;
        calculate_retirement_year();
    }

    void calculate_retirement_year()           
    {
        int a=60;
        retirement_age= a-age;
    }
    void display_employee_data()
    {
        cout<<endl<<endl<<endl;
        cout<<"**************Employee Details**************"<<endl;
        cout<<"Name="<<name<<endl;
        cout<<"ID="<<id<<endl;
        cout<<"Current Age="<<age<<endl;
        cout<<"Retirement after="<<retirement_age<<" year"<<endl;
    }

};


int main()
{
    EMPLOYEE employee;
    employee.GetData();
    employee.display_employee_data();           
}
