/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;

class Employee{
	private:
	string name;
	int id;
	int age;
	int ret_year;
	public:
		void getData()
		{
			cout << "Enter Data : ";
			cout <<endl << "Enter name : ";
			cin >> name;
			cout << endl << "Enter id : ";
			cin >> id;
			cout << endl << "Enter age : ";
			cin >> age;
		}
		void calRetirement()
		{
			if(age < 60)
			{
				ret_year = 2020 + 60 - age;
			}	
			else{
				ret_year = 2020;
			}
		}
		void putData()
		{
			cout << "Employee Data" << endl;
			cout << "Name : " << name << endl;
			cout << "Id : " << id << endl;
			cout << "Age ; " << age << endl;
			cout << "Retirement Year : " << ret_year << endl;
		}
};

int main()
{
	Employee e1;
	e1.getData();
	e1.calRetirement();
	e1.putData();
}