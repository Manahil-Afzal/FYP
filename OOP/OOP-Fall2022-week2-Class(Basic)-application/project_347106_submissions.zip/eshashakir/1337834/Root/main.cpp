/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
using namespace std;


class Employee {
	public://declare the variables.
		string name;
		int id;
		int age;
		int retirement_year;
	
	//First Method 
	void input_method(){
	    cout<<"-------------------------"<<endl;
		cout<<"|INFORMATION OF EMPLOYEE|"<<endl;
		cout<<"-------------------------"<<endl;
		cout<<"EMPLOYEE_NAME: "<<endl;
		cin>>name;
		cout<<"EMPLOYEE_ID: "<<endl;
		cin>>id;
		cout<<"EMPLOYEE_AGE IN 2020: "<<endl;
		cin>>age;
	};
	//Second Method 
	void calculate_method(){
		int total = 60 - age;
		retirement_year = total + 2020;
	};
	//Third Method 
	void output_method(){
	    cout<<"------------------------"<<endl;
		cout<<"| THE DATA  ENTERED IS |"<<endl;
		cout<<"------------------------"<<endl;
		cout<<"EMPLOYEE_NAME: " <<name<<endl;
		cout<<"EMPLOYEE_ID: "<<id<<endl;
		cout<<"EMPLOYEE_AGE IN 2020:"<<age<<endl;
		cout<<"RETIREMENT YEAR IS: "<<retirement_year;
		
	};
};
 int main(){
 	Employee myobj;
 	myobj.input_method();
 	myobj.calculate_method();
 	myobj.output_method();
 }