/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
#include<string.h>
 using namespace std;
 class employee{
     private:
     string emp_name;
     int emp_age;
     int emp_id;
     int rtr_year;
      public:
       
       void set_details ( )
       {
           cout<<"Enter the name of employee"<<endl;
           cin>>emp_name;
           cout<<"Enter the id of employee"<<endl;
           cin>>emp_id;
           cout<<"Enter the age of employee"<<endl;
           cin>>emp_age;
          
       }
       int calculate_rtr_yr ()
       {
           rtr_year=60-emp_age;
           rtr_year= rtr_year+2020;
           return rtr_year;
       }
       void get_details ()
       {
           cout<<"Employee name = "<<emp_name<<endl;
           cout<<"Employee Id = "<<emp_id<<endl;
           cout<<"Employee age = "<<emp_age<<endl;
           cout<<"Employee retirement year = "<<rtr_year<<endl;
           
       }
       
       
 };
 int main ()
 {
     employee emp1;
     emp1.set_details();
     emp1.calculate_rtr_yr();
     emp1.get_details();
     
 }