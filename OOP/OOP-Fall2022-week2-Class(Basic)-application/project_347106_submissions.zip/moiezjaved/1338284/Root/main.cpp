/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;


class Employee {
	public:
		string name;
		int id;
		int age;
		int retirement_year;
		
	void input_method(){
		cout<<"Enter name: "<<endl;
		cin>>name;
		cout<<"Enter ID: "<<endl;
		cin>>id;
		cout<<"Enter your age in 2020: "<<endl;
		cin>>age;
	};
	
	void calculate_method(){
		int total = 60 - age;
		retirement_year = total + 2020;
	};
	
	void output_method(){
		cout<<"name is: " <<name<<endl;
		cout<<"ID is: "<<id<<endl;
		cout<<"age is:"<<age<<endl;
		cout<<"Retirement year is: "<<retirement_year;
		
	};
};
 int main(){
 	Employee myobj;
 	myobj.input_method();
 	myobj.calculate_method();
 	myobj.output_method();
 }