/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee{
	private:
		string name;
		int id;
		int age;
		int ret_year;
	public:
		
		void method1(){
			cout<<"Enter the name of Employee"<<endl;
			cin>>name;
			cout<<"Enter the id of Employee"<<endl;
			cin>>id;
			cout<<"Enter the age of Employee in the 2020"<<endl;
			cin>>age;
		
			
		}
		void method2(){
			int ret;
		    if(age>=60){
		    	cout<<"The Employee is retired from Orgainzation";
			}
			else if(age<60){
				ret = 60 - age; 
				ret_year = 2020 + ret;
			}
			
		}
		void method3(){
			cout<<name<<endl;
			cout<<id<<endl;
			cout<<age<<endl;
			cout<<"The retirement Year of the Employee is    :"<<endl;
			cout<<ret_year;
		}
};
int main(){
	employee myobj;
	myobj.method1();
	myobj.method2();
	myobj.method3();
}