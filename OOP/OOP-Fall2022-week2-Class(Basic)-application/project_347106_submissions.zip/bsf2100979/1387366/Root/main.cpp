/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;

class person{
	private:
	string name;
	string id;
	int age;
	int retire_year;
	public:
int	fun_one();
int	fun_two();
int	fun_three();

	
		
	
};
int person::fun_one(){
	
	  cout<<"Enter name: ";
	   getline(cin,name);
		cout<<"Enter id: ";
	    cin>>id;
		cout<<"Enter current age: ";
	    cin>>age;
	    
	
	
};

int person::fun_two(){
	
	int n= 60-age;
    retire_year= 2020+ n;
    cout<<"you will be retire in: ";
	cout<<retire_year<<endl;
	cout<<endl;
};

int person::fun_three(){
	cout<<"your name : "<<name<<endl;
	cout<<"your id : "<<id<<endl;
	cout<<"your age : "<<age<<endl;
	cout<<"you will be retire in: "<<retire_year<<endl;
	
	
};



int main(){
  person obj;
   obj.fun_one();
    obj.fun_two();	
        obj.fun_three();
			
}



