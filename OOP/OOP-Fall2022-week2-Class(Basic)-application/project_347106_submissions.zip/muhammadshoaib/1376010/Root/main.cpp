/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
	#include<iostream>
#include<string>

using namespace std;

class employee
{
    public:
  string name;
  int id;
  int age;
  int retireYear;



void getdata()
{
   cout<<"enter employee id : ";
   cin>>id;
   cout<<"enter employee name : ";
   cin>>name;
   cout<<"enter  the age of employee in year 2020 : ";
   cin>>age;
   
   cout<<endl;
   
   if (age  > 0 && age <= 60)
   cout<<"The employee will get retired after"<< 60 - age <<" year";
     cout<<endl;  
	if  ( age >=61)
	 cout<<"Employee is retired from "<<age - 60 <<" year";
	 cout<<endl; 
   

}


void showData()
{
   cout<<endl;
   
    cout<<"employee id : "<<id<<endl;
    cout<<"employee name : "<<name<<endl;
    cout<<"age of employee : "<<age<<endl;
}

};


int main()
{
  employee o;
  o.getdata();
  o.showData();
  
  return 0;

}