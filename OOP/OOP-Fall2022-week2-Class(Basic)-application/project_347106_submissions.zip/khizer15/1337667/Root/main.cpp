/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

//************************solution********************************
#include <iostream>
using namespace std;


class Employee {
	public:
		string name;
		int id;
		int age;
		int retirement_year;
		
	void input_method(){
		cout<<"Enter name: "<<endl;
		cin>>name;
		cout<<"Enter ID: "<<endl;
		cin>>id;
		cout<<"Enter age in 2020: "<<endl;
		cin>>age;
	};
	
	void calculate_method(){
		int total = 60 - age;
		retirement_year = total + 2020;
	};
	
	void output_method(){
		cout<<"your name: " <<name<<endl;
		cout<<"your ID: "<<id<<endl;
		cout<<"your Retirement year is: "<<retirement_year<<endl;
		
	};
};
 int main(){
 	Employee obj;
 	obj.input_method();
 	obj.calculate_method();
 	obj.output_method();
 }