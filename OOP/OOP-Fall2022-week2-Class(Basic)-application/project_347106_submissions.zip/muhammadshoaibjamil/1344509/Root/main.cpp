/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include<iostream>
using namespace std;

int gap;
class Employee{
	public:
		string name;
		int id;
		int age;
		int retirement_year;
		
		void my_input(){
			cout<<"Please enter your name : ";
			cin>>name;
			cout<<"Please enter your id : ";
			cin>>id;
			cout<<"Please enter your age : ";
			cin>>age;
		}
		
		void retirement_calculation(){
			if(age <= 60){
				gap = 60 - age;
			}	
		}
		
		void my_output(){
			cout<<"name:"<<name<<endl;
			cout<<"id:"<<id<<endl;
			cout<<"age:"<<age<<endl;
			if(age>60 or age<0){
				cout<<"Age not accurate";
			}
			else{
				cout<<"Retirement year:"<<gap + 2020;
			}
		}
};
int main(){
	Employee myObj;
	myObj.my_input();
	myObj.retirement_calculation();
	myObj.my_output();
	return 0;
}