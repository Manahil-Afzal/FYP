/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
#include<iostream>
using namespace std;
class Employee{
	public:
		string name;
		int id;
		int age_in_2020;
		int retirement_year;
		//making three functions in class
		//first function
		int firstfunction(){
			cout<<"Enter the employee name "<<endl;
			cin>>name;
			cout<<"Enter the employee id  "<<endl;
			cin>>id;
			cout<<"Enter the employee age in 2020 "<<endl;
            cin>>age_in_2020;
		}
		//second function
		int secondfunction(){
			int a;
			a=60-age_in_2020;
			retirement_year=2020+a;
			cout<<"The retiremnt year of employee       = "<<retirement_year<<endl;
		}
		//third function
		int thirdfunction(){
			cout<<"The name of the employee =        "<<name<<endl;
			cout<<"The age of the employee =         " <<age_in_2020<<endl;
			cout<<"The id of te employee =           "<<id<<endl;
			cout<<"The retiremnt year of the employee  =         "<<retirement_year<<endl;
		}
		
};
int main()
{
	Employee obj;
	obj.firstfunction();
	obj.secondfunction();
	obj.thirdfunction();
	return 0;

}