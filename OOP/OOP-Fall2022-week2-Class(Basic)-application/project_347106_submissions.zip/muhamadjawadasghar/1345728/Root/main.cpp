/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
using namespace std;

class employee{
	public:
	char empname[10];
	string empid;
	int empage;
	int  retirementyear;
	
	void input()
	{
	cout<<"enter employee name"<<endl;
	cin>>empname;
	
	cout<<"enter employee id";
	cin>>empid;
	
	cout<<"enter employee empage"<<endl;
	cin>>empage;	
		
	}
	void retirement()
	{
		int currentyear,a, b;
		
		cout<<" current year"<<endl;
		cin>>currentyear;
	
	a=currentyear-empage;


		
	retirementyear =a+60;

	
	
}
	void output(){
		
	cout<<"Employee name"<<"    "<<empname<<endl;
	
	cout<<" employee id"<<"    "<<empid<<endl;
	
	cout<<" employee age"<<"    "<<empage<<endl;
	
		cout<<" Retritment year of employee"<<"    "<<retirementyear<< endl;
		
	}

};

int main()
{
employee e;
e.input();
e.retirement();
e.output();

	
}