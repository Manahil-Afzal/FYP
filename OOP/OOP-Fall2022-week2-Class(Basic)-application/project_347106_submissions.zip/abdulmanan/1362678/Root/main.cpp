/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
using namespace std;

       class Employee
       {
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              void GetData()           
              {
                    cout<<"\n\tEnter Employee Id : ";
                    cin>>Id;

                    cout<<"\n\tEnter Employee Name : ";
                    cin>>name;

                    cout<<"\n\tEnter Employee Age : ";
                    cin>>Age;

                    cout<<"\n\tEnter Employee Salary : ";
                    cin>>Salary;
              }

              void PutData()           
              {
                    cout<<"\n"<<Id<<"\t"<<name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


     int main()
       {

              Employee E[5];           

              for(int i=0;i<=5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee";
                   E[i].GetData();
              }

              cout<<"\nDetails of Employees";
              for(int i=0;i<=5;i++)
              E[i].PutData();

       }