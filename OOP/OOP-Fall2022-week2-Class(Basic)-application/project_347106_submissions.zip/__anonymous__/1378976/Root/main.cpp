/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
#include <string>
using namespace std;

class employee{
    private:
    string name;
    int id;
    int age;
    int retirementYear;
    
    public:
    void get_info() {
        cout<<"Enter employee name: ";
        cin>>name;
        cout<<"Enter employee id: ";
        cin>>id;
        cout<<"Enter employee age: ";
        cin>>age;
    }
    void calculate_retirement() {
        int yearsLeft = 60 - age;
        cout<<yearsLeft;
        retirementYear = 2022 + yearsLeft;
    }
    void display_info() {
        cout<<"\nEmployee name is "<<name;
        cout<<"\nEmployee ID is "<<id;
        cout<<"\nEmployee age is "<<age;
        cout<<"\nEmployee retirementYear is "<<retirementYear;
    }
};



int main() {
    employee E1;
    
    E1.get_info();
    E1.calculate_retirement();
    E1.display_info();
};