/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class Employee
{
    int eid;
    char ename[100];
    int age;
    int r;

    public:
    void accept_details()
    {
        cout<<"\n Enter Employee Id : ";
        cin>>eid;
        cout<<"\n Enter Employee Name : ";
        cin>>ename;
        cout<<"\n Enter employee age : ";
        cin>>age;
        cout<<"\n Enter employee age again  retirement : ";
        cin>>r;
    
    }

    void display_details()
    {
        cout<<"\n -------------------------- ";
        cout<<"\n Employee Id    : "<<eid;
        cout<<"\n Employee Name  : "<<ename;
        cout<<"\n Employee age  : "<<age<<"\n";
         cout<<"\n Employee retirement year  : "<<"\t"<<r<<"\n";
    }
    void retirement(){
    	if(r<60)
    	cout<<"employee is eligible for job"<<"\n";
    	else
    	cout<<"\n employee is retire for job";
	}
};

int main()
{
    
    Employee e;
    e.accept_details();
    e.display_details();
    e.retirement();
    return 0;
}