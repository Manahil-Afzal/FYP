/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

 #include<iostream>
 #include<string>
using namespace std;

class Employee{
	private:
		string empName;
		int Id, age, retYear, fig;
	public:
		void input_func();
		void retire_func();
		void output_func();
};

void Employee::input_func(){
	cout<<"Enter the employee's name: "<<endl;
	cin>>empName;
	cout<<"Enter the employee's Id: "<<endl;
	cin>>Id;
	cout<<"Enter the employee's age in year 2020: "<<endl;
	cin>>age;
}

void Employee::retire_func(){
	fig=60-age;
	retYear=2020+fig;
}

void Employee::output_func(){
	cout<<"The employee's name is: "<<empName<<endl;
	cout<<"The employee's Id is: "<<Id<<endl;
	cout<<"The employee's age in year 2020 is: "<<age<<endl;
	cout<<"The retirement year for employee is: "<<retYear<<endl;
}

int main(){
	Employee obj;
	obj.input_func();
	obj.retire_func();
	obj.output_func();
	return 0;
}