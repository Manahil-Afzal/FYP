/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee
{
private:
    string name;
    int id;
    int age;
    int retirement_year;
public:
    void get();
    void check();
    void show();
};
int main()
{
    employee e1;
    e1.get();
    e1.check();
    e1.show();
}
void employee::get()
{
    cout<<"name";
    cin>>name;
    cout<<"id";
    cin>>id;
    cout<<"age";
    cin>>age;
}
void employee::check()
{
    for(int i=0; i<60; i++)
    {
        if(age+i==60)
        {
            retirement_year=2020+i;
            
        }
        else
        {
            continue;
        }
    }

}
void employee::show()
{
cout<<"your name"<<name<<"\n";
cout<<"your id"<<id<<"\n";
cout<<"your age"<<age<<"\n";
cout<<"your retirement year"<<retirement_year<<"\n";

}