/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;
class employee {
	private:
		
	char name[20] ;
	int  Id ;
	int age, retr;
	public:
     int input(){
     	cout << "enter employee's name: "<<endl;
     	cin.getline(name, 20);
     	cout <<"enter employee's Id: "<<endl;
     	cin>> Id;
     	cout<< "enter employee's age in 2020:";
     	cin>> age;
     	return 0;
	 }	
	 int retirement()
	 {
	 	int x;
	 	if (retr<=60 ){
	 	     retr = 60-age;
			   
			  cout << "you have  "<<retr<<"  years left"<<endl<< "your retirement year is:"<<retr + 2020<<endl;
			 
		}
			  else
			  cout <<"you have reached your retirement year.";
		 
	 }
	 int display(){
	 	cout << "employee's name is: "<<name<<endl;
	 	cout << "employee's Id is: "<< Id<<endl;
	 	cout << "employee's age is: "<< age<<endl;
	 
	 	return 0;
	 	
	 }
};
int main (){
employee e1;
e1.input();
e1.retirement();
e1.display();
return 0;	
}