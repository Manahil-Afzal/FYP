/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee
{
    char name[50];
    int id;
    int age;
    int Retire;
    public:
    void TakeData()
    { cout<<"enter the name of employee"<<endl;
        cin>>name;
        cout<<"\nenter id"<<endl;
        cin>>id;
        cout<<"\nenter age"<<endl;
        cin>>age;
        
    }
    void calculate()
    {
       int year=60-age;
       Retire=2020+year;
        
    }
    
    void output()
    {
        cout<<"\n\nname of the employee "<<name<<endl;
        cout<<"\nid of employee "<<id<<endl;
        cout<<"\nage of employee in 2020 "<<age<<endl;
        cout<<"\nemployee retirement year "<<Retire;
        
}
};
    
    
int main()
{
    employee e1;
    e1.TakeData();
    e1.calculate();
    e1.output();
    return 0;

}

