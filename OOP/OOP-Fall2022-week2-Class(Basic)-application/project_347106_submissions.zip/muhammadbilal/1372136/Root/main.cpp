/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include<iostream>
#include<string>
using namespace std;

//Creating the class Employee.
class Employee{
   
    private:
    
    //Data Members.
    
    string employeeName;
    int employeeId;
    int employeeAge;
    int retirementLimit;
    int retirement;
   
    public:
    
    //First member function to take inputs.
    
 void getData(){
        cout<<"Input Employee's name:"<<endl;
        getline(cin, employeeName);
       
        cout<<"Enter employee's age in the year 2020: "<<endl;
        cin>>employeeAge;
        
        cout<<"Enter the employee I'd in numbers: "<<endl;
        cin>>employeeId;
    }
    
    //Second member function to calculate the retirement year as per the age taken in the year 2020.
    
    int retirementYear(){
       int retirementLimit = 60;
        int retirement = retirementLimit - employeeAge;
        return retirement+2020;
    }
    
    //Third member function to display the required calculated result.
    
    void displayData(){
        
        cout<<"Retirement Year is: "<<retirementYear()<<endl;
    }
    
};

    //The main program creates an object and drives the class.
    
    int main(){
        Employee E1; //Created an object
        E1.getData(); //Calling first member function.
        E1.retirementYear(); //Calling second member function to perform calculations.
        E1.displayData(); //Calling thir member function to display the result.
        return 0;
    }