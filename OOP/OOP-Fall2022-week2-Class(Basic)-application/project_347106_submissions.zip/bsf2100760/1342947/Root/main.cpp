/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;

class employee{
    public:
    string employee_name;
    int employee_Id;
    int employee_age;
   int  retirement_year;
    void get(){
        cout<<"Enter the name of employee"<<endl;
        cin>>employee_name;
          cout<<"Enter the iD of employee"<<endl;
        cin>>employee_Id;
          cout<<"Enter the Age of employee"<<endl;
        cin>>employee_age;
    }
    int retirement(){
        retirement_year=60-employee_age;
        return 2022+retirement_year;
    }
    void display(){
        cout<<"Name : "<<employee_name<<endl;
        cout<<"Age : "<<employee_age<<endl;
        cout<<"ID : "<<employee_Id<<endl;
        cout<<"Retirement Year : "<<retirement();
    }
};

int main(){
    employee E1;
    E1.get();
    E1.retirement();
    E1.display();
    
    
    return 0;
}