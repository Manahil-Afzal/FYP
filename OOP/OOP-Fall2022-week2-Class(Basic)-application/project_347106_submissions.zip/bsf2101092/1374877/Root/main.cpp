/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee{
    public:
    string name;
    int id;
    int age;
    int retirement_year;
    
    void member()
    {
        cout<<"enter the name of employee:"<<endl;
        cin>>name;
        cout<<"enter the id of employee:"<<endl;
        cin>>id;
        cout<<"enter the age of employee in 2020:"<<endl;
        cin>>age;
    }
    void year()
    {
        int year=60;
        retirement_year=2020;
        int add=year-age;
        retirement_year=2020+add;
        cout<<"retirement year is:"<<retirement_year<<endl;
        
    }
    void output()
        {
            cout<<"name:"<<name<<endl;
            cout<<"age:"<<age<<endl;
            cout<<"id:"<<id<<endl;
            
        }
    };
        int main()
        {
            employee emp;
            emp.member();
            emp.year();
            emp.output();
            return 0;
        }
