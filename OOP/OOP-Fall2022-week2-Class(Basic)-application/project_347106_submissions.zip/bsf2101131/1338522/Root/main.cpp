/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee{
    string name;
    int id;
    int age;
     int retairin;
    public:
    void userinfo(){
        cout<<"enter your name"<<endl;
        cin>>name;
        cout<<"enter your id"<<endl;
        cin>>id;
        cout<<"enter your age"<<endl;
        cin>>age;
        
        
    }
    void retairment(){
        retairin=60-age;
        cout<<"you are retair in "<<retairin<<endl;
    }
    void display(){
        cout<<"Name:"<<name<<endl;
        cout<<"ID"<<id<<endl;
        cout<<"retairment in:"<<retairin<<endl;
    }
};
    int main(){
        employee obj;
        obj.userinfo();
        obj.retairment();
        obj.display();
        
    }