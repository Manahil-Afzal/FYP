/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include<iostream>
using namespace std;
 
 class employee{
     private:
     string name;
     int age, id, RetYear;
      
        public:
       void TakeInput ( ){
           cout<<"Enter the name of employee: ";
           cin>>name;
           cout<<"Enter the id of employee: ";
           cin>>id;
           cout<<"Enter the age of employee: ";
           cin>>age;
          
       }
       
       int CallRetYear (){
           RetYear=60-age;
           RetYear= RetYear+2020;
           return RetYear;
       }
       void Display (){
           cout<<"\n ---------"<<endl;
           cout<<"Employee name = "<<name<<endl;
           cout<<"Employee Id = "<<id<<endl;
           cout<<"Employee age = "<<age<<endl;
           cout<<"Employee retirement year = "<<RetYear<<endl;
           
       }
       
       
 };
 int main ()
 {
     employee empObj;
     empObj.TakeInput();
     empObj.CallRetYear();
     empObj.Display();
     
 }