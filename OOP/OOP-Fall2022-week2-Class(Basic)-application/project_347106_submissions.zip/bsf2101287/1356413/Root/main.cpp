/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include<iostream>
using namespace std;

class Employee_Details{
    string employee_name;
    string employee_Id;
    int employee_age;
    int ret_year;
    public:
    void get_employee_details ();
    void calculate ();
    void put_details ();
};

void Employee_Details :: get_employee_details() {
    cout<<"Enter Employee Name: "<<endl;
    cin>>employee_name;
    cout<<"Enter Employee Id: "<<endl;
    cin>>employee_Id;
    cout<<"Enter the Employee Age in 2020's': "<<endl;
    cin>>employee_age;
    int ret_year;
    
}

void Employee_Details :: calculate() {
    int ret_age = 60;
    int ret_year = 2020;
    int add = ret_age - employee_age;
    ret_year = 2020 + add;
    cout<<"Employee will retire in "<<ret_year<<endl;
    
}

void Employee_Details :: put_details() {
    cout<<"Employee Name: "<<employee_name<<endl;
    cout<<"Employee Id: "<<employee_Id<<endl;
    cout<<"Employee Age: "<<employee_age<<endl;
}

int main() {
    Employee_Details data;
    data.get_employee_details();
    data.put_details();
    data.calculate();
}