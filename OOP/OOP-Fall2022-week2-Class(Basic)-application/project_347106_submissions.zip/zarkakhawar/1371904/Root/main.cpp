/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;
class Employee {
    private:
    string name;
    int id;
    int agein2020;
    int Retirementyear;
    public:
    void getEmployeedata(){
        cout<<"Enter your name:";
        cin>>name;
        cout<<"Enter your id:";
        cin>>id;
        cout<<"Enter your age in 2020:";
        cin>>agein2020;
        cout<<"Enter your retirement year:";
        cin>>Retirementyear;
    }
    void calculateRetiremenyear(){
        int RetirementAge=60;
       int  remainingyear=60-agein2020;
        Retirementyear=2020+remainingyear;
    }
    int getRetirementyear(){
        return Retirementyear;
    }
};
int main(){
    Employee emp;
    emp.getEmployeedata();
    emp.getRetirementyear();
    cout<<"\n Your retirement year is:"<<emp.getRetirementyear();
    return 0;
}
        
        
        
        
        
        
        
        
        
        
        
    