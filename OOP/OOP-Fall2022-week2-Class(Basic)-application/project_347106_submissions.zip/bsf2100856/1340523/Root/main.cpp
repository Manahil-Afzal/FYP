/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class employee
{
    char name[50];
    int id;
    int age;int retire;
    public:
    void takeData()
{   cout<<"enter the name of the employee"<<endl;
    cin>>name;
    cout<<"enter you id:"<<endl;
    cin>>id;
    cout<<"enter your age"<<endl;
    cin>>age;
    
}
void calculate()
{
    int year=60-age;
    retire=2020+year;
    
}
void input()
{
    cout<<"name of the employee"<<name<<endl;
    cout<<"id of the employee"<<id<<endl;
    cout<<"age of the employee in 2022"<<age<<endl;
    cout<<"employee retirement year"<<retire<<endl;
    
}
};
int main()
{
    employee e1;
    e1.takeData();
    e1.calculate();
    return 0;
    
}