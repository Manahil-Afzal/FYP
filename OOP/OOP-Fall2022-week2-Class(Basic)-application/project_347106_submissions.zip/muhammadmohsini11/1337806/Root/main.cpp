/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/

#include <iostream>
using namespace std;


class Employee {
	public:
		string name;
		int Id;
		int age;
		int retirement_year;
		
	void inp_funciton(){
		cout<<"Enter name: "<<endl;
		cin>>name;
		cout<<"Enter ID: "<<endl;
		cin>>Id;
		cout<<"Enter age in 2020: "<<endl;
		cin>>age;
		
		
	};
	
	void cal_funciton(){
		int total = 60 - age;
		retirement_year = total + 2020;
	};
	
	void dis_function(){
		cout<<"name: " <<name<<endl;
		cout<<"ID: "<<Id<<endl;
		cout<<"Retirement year is: "<<retirement_year<<endl;
		
	};
};
 int main(){
 	Employee myobj;
 	myobj.inp_funciton();
 	myobj.cal_funciton();
 	myobj.dis_function();
 	
 
 }


