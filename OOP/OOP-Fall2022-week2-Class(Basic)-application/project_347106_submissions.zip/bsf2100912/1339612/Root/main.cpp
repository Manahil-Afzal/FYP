/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include <iostream>
using namespace std;
class Employee{
	private:
		string name;
		int ID;
		int age;
		int ret_yr;
	public:
		void method1(){
			cout<<"Enter employee's name:";
			cin>>name;
			cout<<"Enter employee's ID:";
			cin>>ID;
			cout<<"Enter employee's age in 2020:";
			cin>>age;
		}
		void method2(){
	int count=0;
	if (age<60){
	 for(int i=age+1;i<=60;i++){
	 	count+=1;
	 }
	 ret_yr=2020+count;
	 }
	 else if (age==60)
	     ret_yr=2020;
	 else if (age>60){
	 	for(int i=age-1;i>=60;i--){
	 		count+=1;
		 }
		 ret_yr=2020-count;
	 }  
	 }  
	 
		void method3(){
	cout<<"Employee's name:"<<name<<endl;
	cout<<"Employee's ID:"<<ID<<endl;
	cout<<"Employee's age in 2020:"<<age<<endl;
	cout<<"Retirement year of the employee:"<<ret_yr;
	
}
};


int main(){
	Employee myObj;
	myObj.method1();
	myObj.method2();
	myObj.method3();
	return 0;
}