/*Write a C++ program that defines a class for employee. The class should have four data members for employee's name, Id, age in year 2020, and retirement year. 
Define three member functions in the class one of which should take input of first three data members, 
the second method should calculate the retirement year for the employee provided the retirement age is 60 years. 
The third method should display the name, Id, age and retirement year of the employee.*/
#include<iostream>
using namespace std;
class Employee{
	public:
    string name;
    int Id, age;
    int ret;
    void set(){
        cout<<"Employee's name :"<<endl;
        cin>>name;
        cout<<"Your Id :"<<endl;
        cin>>Id;
        cout<<"Enter your age :"<<endl;
        cin>>age;
        cout<<" Retirement Age : "<<endl;
        cin>>ret;
		 }
		 void show (){
		 	cout<<"Employee Name : "<<name<<endl;
		 	cout<<"Employee ID : "<<Id<<endl;
		 	cout<<"Employeee Age : "<<age<<endl;
		 	cout<<" Retirement Age : "<<ret<<endl;
		 }
		 void cal(){
		 	if(ret<60){
		 		cout<<" eligible for job";
			 }
			 else{
			 	cout<<"not Eligible For job";
			 }
		 }
    
};

int main(){

    Employee e;
    e.set();
    e.show();
    e.cal();
};