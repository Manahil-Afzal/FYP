
/*This code is meant to polymorphically call two methods print and show. 
Identify and correct any logical or compilation errors*/
#include <iostream> 
using namespace std; 

class base 
{ 
public: 
	virtual void print () // add virtual keyword
	{ cout<< "print base class" <<endl; } 

}; 

class derived:public base 
{ 
public: 
virtual	void print () 
	{ cout<< "print derived class" <<endl; } 

virtual	void show () 
	{ cout<< "show derived class" <<endl; } 
}; 

int main() 
{ 
	base *bptr; 
	derived d; 
	bptr = &d; 
	d.print(); 
	d.show(); 

	return 0; 
} 
