#include <iostream> 
using namespace std; 

class base 
{ 
public: 
    virtual void print () 
    { cout << "print base class" << endl; } 

    // Add a virtual destructor
    virtual ~base() {}
}; 

class derived: public base 
{ 
public: 
    virtual void print () override 
    { cout << "print derived class" << endl; } 

    virtual void show () 
    { cout << "show derived class" << endl; } 
}; 

int main() 
{ 
    base *bptr; 
    derived d; 
    bptr = &d; 

    // Call the print function using the pointer to the base class
    bptr->print(); 

    // To call the show function, you need to use a pointer to the derived class
    // or make the base class show function virtual.
    // bptr->show();  // This line will not work, uncomment it to see the compilation error

    return 0; 
}
