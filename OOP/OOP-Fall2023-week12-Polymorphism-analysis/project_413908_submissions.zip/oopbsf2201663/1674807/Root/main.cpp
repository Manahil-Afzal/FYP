
//This code is meant to polymorphically call two methods print and show. 
#include <iostream> 
using namespace std; 

class base 
{ 
public: 
    void print () 
    { 
        cout << "print base class" << endl; 
    } 
}; 

class derived : public base 
{ 
public: 
    virtual void print () 
    { 
        cout << "print derived class" << endl; 
    } 
    
    virtual void show () 
    { 
        cout << "show derived class" << endl; 
    } 
}; 

int main() 
{ 
    base *bptr; 
    derived d; 
    bptr = &d; 
    d.print(); // Calls print() of derived class
    // bptr->show(); // This line would throw a compilation error since the base class pointer cannot directly access derived class's specific functions
    
    return 0; 
} 