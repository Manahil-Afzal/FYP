#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
};

class A {
protected:
    int x;

public:
    void setx(int q) {
        x = q;
    }
};

class B {
protected:
    int y;
    int z; // Add this line to declare z in class B

public:
    void setz(int q) {
        z = q;
    }
};

class C : public A, public B {
public:
    void sety(int q) {
        y = q;
    }

    void sum() {
        cout << "Sum = " << x + y + z << endl;
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5); // Use sety(5) instead of setz(5)
    obj1.sum();
    return 0;
}
