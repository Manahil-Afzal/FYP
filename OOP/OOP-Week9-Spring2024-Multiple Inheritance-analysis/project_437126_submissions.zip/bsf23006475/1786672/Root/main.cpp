// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A:virtual public P  //inherite Class A with base Class P;
{
	protected:   //Change the private access specifier to protected access specifier;
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B:virtual public P  //inherite Class B with base Class P;
{
protected:
int y;
 	public:
 	//Add function to set the value of y;
 	void sety(int q){
 	    y=q;
 	}
 	void setz(int q)
    {
 	     z=y;
    }
};
class C : public A, public B   //replace the ;with , in between the class A and B;
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
