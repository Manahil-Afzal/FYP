// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
};

class A {
protected: // Change to protected to allow access in derived class
    int x;

public:
    void setx(int q) {
        x = q;
    }
};

class B {
protected: // Change to protected to allow access in derived class
    int y;

public:
    void sety(int q) {
        y = q;
    }
};

class C : public A, public B, public P { // Inherit publicly from all three classes
public:
    void sum() {
        cout << "Sum = " << x + y + z << endl; // Access x, y, and z from different classes
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
