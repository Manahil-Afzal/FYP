// Identify and correct errors ( also comment the errors).
#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
};

class A {
protected: // Changed from private to protected
    int x;
public:
    void setx(int q) {
        x = q;
    }
};

class B : public P { // Inherit from P to get access to z
protected:
    int y;
public:
    void sety(int q) { // Corrected function name to sety
        y = q;
    }
};

class C : public A, public B { // Corrected inheritance syntax
public:
    void sum() {
        cout << "Sum = " << x + y + z << endl;
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
