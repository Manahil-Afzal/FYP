#include <iostream>
using namespace std;

// Class P is removed, as it isn't used in this code snippet. 
// The error in B (undefined `z`) would cause compilation errors.

class A
{
private:
    int x;  // `x` should be private
public:
    void setx(int q)  // setter method to set `x`
    {
        x = q;
    }
    int getx() const // Getter to retrieve `x`
    {
        return x;
    }
};

class B
{
protected:
    int y;  // `y` is protected
public:
    void sety(int q)  // Corrected function name to match its use in main()
    {
        y = q;
    }
    int gety() const // Getter to retrieve `y`
    {
        return y;
    }
};

class C : public A, public B  // Changed semicolon to a comma between base classes
{
public:
    void sum()
    {
        // x, y, and z should be accessible by getters from A and B
        cout << "Sum = " << getx() + gety() << endl;  // Output should end with newline
    }
};

int main()
{
    C obj1;
    obj1.setx(4); // Setting `x` of A
    obj1.sety(5); // Setting `y` of B
    obj1.sum();   // Output sum of x + y
    return 0;
}