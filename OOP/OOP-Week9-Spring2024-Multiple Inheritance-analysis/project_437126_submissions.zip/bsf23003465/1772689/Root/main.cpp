// Identify and correct errors ( also comment the errors).

#include<iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
    int getZ() {
        return z;
    }
};

class A {
protected:
    int x;
public:
    void setx(int q) {
        x = q;
    }
    int getX() {
        return x;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) { // Changed from setz to sety
        y = q;
    }
    int getY() {
        return y;
    }
};

class C : virtual public A, virtual public B, virtual public P {
public:
    void sum() {
        cout << "Sum = " << getX() + getY() + getZ(); // Used accessor functions to get x, y, and z
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
