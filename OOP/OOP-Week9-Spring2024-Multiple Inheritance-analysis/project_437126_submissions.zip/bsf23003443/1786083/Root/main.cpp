// Identify and correct errors ( also comment the errors).
#include <iostream>
#include <string>
using namespace std;

class Course {
protected:
    string course_id;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> course_id;
    }
};

class IT : virtual public Course {  // Use virtual inheritance
public:
    void display() {
        cout << "IT Course ID: " << course_id << endl;
    }
};

class CS : virtual public Course {  // Use virtual inheritance
public:
    void display() {
        cout << "CS Course ID: " << course_id << endl;
    }
};

class SOS_course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID (IT): " << course_id << endl;
        cout << "SOS Course ID (CS): " << course_id << endl;
    }
};

int main() {
    SOS_course course;
    course.input();
    course.display();

    return 0;
}
