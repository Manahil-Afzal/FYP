// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;



class A
{
	protected:
	int x;
 	public:
 	void setx(int a)
    {
 	     x=a;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void sety(int b)
    {
 	     y=b;
    }
};
class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int c)
    {
 	     z=c;
    }
};
class C : public A, public B, public P   
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y + z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
