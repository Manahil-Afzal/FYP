// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
protected:
    int z;
public:
    void setz(int q)
    {
        z = q;
    }
    int getz() const // Add a public member function to access z
    {
        return z;
    }
};

class A
{
protected:
    int x;
public:
    void setx(int q)
    {
        x = q;
    }
};

class B
{
protected:
    int y;
public:
    void sety(int q)
    {
        y = q;
    }
};

class C : public A, public B // Corrected inheritance syntax
{
public:
    void sum()
    {
        P p; // Create an object of class P
        cout << "Sum = " << x + y + p.getz() << endl; // Access z using the getz() function from the object p
    }
};

int main()
{
    C obj1;
    P objP; // Create an object of class P
    objP.setz(3); // Set the value of z
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}



