#include<iostream>
using namespace std;

class Employee {
    protected:
        string Name;
        int Id;
        int working_hours;
        float per_hour_salary;
    public:
        Employee(string n, int i, int wh, float phs) {
            Name = n;
            Id = i;
            working_hours = wh;
            per_hour_salary = phs;
        }
};

class Adhoc_employee : public Employee {
    public:
        Adhoc_employee(string n, int i, int wh, float phs) : Employee(n, i, wh, phs) {}
        float salary() {
            return working_hours * per_hour_salary;
        }
        void display_info() {
            cout << "Name: " << Name << endl;
            cout << "Id: " << Id << endl;
            cout << "Working Hours: " << working_hours << endl;
            cout << "Per Hour Salary: " << per_hour_salary << endl;
        }
};

int main() {
    Adhoc_employee e("John Doe", 123, 40, 20.5);
    e.display_info();
    cout << "Salary: " << e.salary() << endl;
    return 0;
}  
