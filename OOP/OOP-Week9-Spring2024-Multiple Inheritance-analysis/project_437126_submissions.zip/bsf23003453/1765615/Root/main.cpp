#include <iostream>
using namespace std;

class P
{
protected:
    int z;

public:
    void setz(int q)
    {
        z = q;
    }
};

class A
{
private:
    int x;

public:
    void setx(int q)
    {
        x = q;
    }

    // Accessor for x
    int getx()
    {
        return x;
    }
};

class B
{
protected:
    int y;

public:
    void sety(int q)
    {
        y = q;
    }

    // Accessor for y
    int gety()
    {
        return y;
    }

    void setz(int q)
    {
        z = q; // Corrected to set the value of z
    }

    // Accessor for z
    int getz()
    {
        return z;
    }

private:
    int z;
};

class C : public A, public B
{
public:
    void sum()
    {
        B::setz(0); // Setting z through class B object
        cout << "Sum = " << A::getx() + B::gety() + B::getz(); // Accessing x from class A and y and z from class B
    }
};

int main()
{
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}

