#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
};

class A {
protected://make it protected
    int x;
public:
    void setx(int q) {
        x = q;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) { // Corrected the method name from setz to sety
        y = q;
    }
};

class C : public A, public B, public P { // Corrected the syntax for inheriting from multiple classes and also nherit P with C
public:
    void sum() {
        cout << "Sum = " << x + y + z; // Added z here, which is inherited from class P
    }
};

int main() {
    C obj1;
    obj1.setz(3); // Corrected the method name from setz to sety
    obj1.setx(4);
    obj1.sety(5); // Corrected the method name from setz to sety
    obj1.sum();
    return 0;
}
