// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P{
	protected:                                     // Correct the indentation
	    int z;
 	
    public: 	
        void setz(int q){z=q;}                      // Corrected the indentation
};

class A{
	protected:                                      // Used protected instead of private
	    int x;
 	public:
        void setx(int q){x=q;}
};

class B{
    protected:
        int y;
    
    public:
        void sety(int q){y=q;}
};
class C : public A, public B, public P{                   // Add comma instead of semi-colon
 	public:
        void sum(){
            cout << "Sum = " << x + y + z << endl;
        }
};

int main()
{
 	C obj1; 
 	obj1.setx(4);                       // Rearrange x, y and z
 	obj1.sety(5);
    obj1.setz(3);
 	obj1.sum();
 	return 0;
}  
