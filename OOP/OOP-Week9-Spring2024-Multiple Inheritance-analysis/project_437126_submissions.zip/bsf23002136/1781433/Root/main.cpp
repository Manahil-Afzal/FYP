#include <iostream>
using namespace std;

class P
{
protected:
    int z;
public:
    void setz(int q)
    {
        z = q;
    }
};

class A
{
protected:
    int x;
public:
    void setx(int q)
    {
        x = q;
    }
};

class B
{
protected:
    int y;
public:
    void sety(int q)
    {
        y = q;
    }
};

class C : public A, public B, public P // Inheriting from class P as well
{
public:
    // Constructor to initialize x, y, and z.
    C(int x_val, int y_val, int z_val) : A(), B(), P()
    {
        setx(x_val);
        sety(y_val);
        setz(z_val);
    }

    void sum()
    {
        // Accessing x, y, and z from the base classes A, B, and P respectively.
        cout << "Sum = " << x + y + z << endl;
    }
};

int main()
{
    C obj1(4, 5, 3); // Providing initial values for x, y, and z.
    obj1.sum();
    return 0;
}
