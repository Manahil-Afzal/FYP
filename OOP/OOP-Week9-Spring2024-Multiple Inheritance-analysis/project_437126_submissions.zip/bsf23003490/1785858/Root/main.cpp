#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
    int getz() const {
        return z;
    }
};

class A {
protected:
    int x;
public:
    void setx(int q) {
        x = q;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) {
        y = q;
    }
};

class C : public A, public B, public P { // Add P as base class
public:
    void sum() {
        cout << "Sum = " << x + y + getz() << endl; // Call getz() without object since it's not a static method
    }
};

int main() {
    C obj1;
    obj1.setz(3); // Call setz() through obj1 since it's not a static method
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
