// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
};

class A {
protected: // Change access specifier to protected
    int x;
public:
    void setx(int q) {
        x = q;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) { // Define sety() function
        y = q;
    }

    void setz(int q) {
        y = q; // Set y instead of z
    }
};

class C : public A, public B { // Correct inheritance syntax
public:
	int z;
    void sum() {
        cout << "Sum = " << x + y + z << endl; // Access x, y, and z from their respective classes
    }
};

int main() {
    C obj1;
    obj1.setz(3); // Call setz() from class B
    obj1.setx(4);
    obj1.sety(5); // Call sety() from class B
    obj1.sum();
    return 0;
}