#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
};

class A : virtual public P { // Making inheritance virtual to avoid ambiguity
protected:
    int x;

public:
    void setx(int q) {
        x = q;
    }
};

class B : virtual public P { // Making inheritance virtual to avoid ambiguity
protected:
    int y;

public:
    void sety(int q) {
        y = q;
    }
};

class C : public A, public B {
public:
    void sum() {
        cout << "Sum = " << x + y + z; // Access z directly
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
