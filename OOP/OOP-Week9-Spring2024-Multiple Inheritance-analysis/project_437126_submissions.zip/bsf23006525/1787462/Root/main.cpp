// Identify and correct errors ( also comment the errors).
#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
};

class A {
protected: 
    int x;

public:
    void setx(int q) {
        x = q;
    }
};

class B {
protected: 
    int y;

public:
    void sety(int q) {
        y = q;
    }
};

class C : public A, public B, public P {
public:
    void sum() {
        cout << "Sum = " << x + y + z << endl; 
    }
};

int main() {
    C obj1;
    obj1.setz(7);
    obj1.setx(8);
    obj1.sety(0);
    obj1.sum();
    return 0;
}
