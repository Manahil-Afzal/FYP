// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;
class P{
protected:
    int z;
public:
    void setz(int q)
    {
    z = q;
    }
 };
class A{
protected: // acess specifier should be public or protected so that it's derived class can acess it.
    int x;
public:
    void setx(int q)
    {
    x = q;
  }
};
class B : public P // Inheriting from class "P" for acess to 'z'.
{
protected:
    int y;
public:
    void sety(int q) // name of member function corrected to sety.
    {
    y = q; // set the value of 'y' not 'z'.
 }
};
class C : public A, public B // colon removed and parent classes are sperated by comma.
 {
public:
    void sum(){
    cout << "Sum = " << x + y + z;
   }
};
 int main(){
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
 }