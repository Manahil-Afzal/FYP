#include <iostream>
using namespace std;


class A
{
	protected:
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void sety(int q)
    {
 	     y=q;
    }
};

class C
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};
class p : public A, public B,public C   
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x+y+z;
 	}
};

int main()
{
 	 p obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
} 
