// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
protected:
	int z;
 	public:
 	void setz(int q)
    {
 	     z=q;
    }
    int getz(){
    	return z;
	}
};

class A : public P
{
protected:
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }
    int getx(){
    	return x;
	}
};

class B : public A
{
protected:
	int y;
 	public:
 	
 	void sety(int q)
    {
 	     y=q;
    }
    int gety(){
    	return y;
	}
};

class C :  public B
{
 	public:
 	void sum()
 	{
 		
 	    cout << "Sum = " << getx() + gety() + getz();
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}