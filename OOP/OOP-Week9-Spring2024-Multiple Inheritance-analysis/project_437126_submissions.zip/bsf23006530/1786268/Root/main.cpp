// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
protected:
    int z;

public:
    void setz(int q)
    {
        z = q;
    }
};

class A
{
protected://Public to Protected
    int x;

public:
    void setx(int q)
    {
        x = q;
    }
};

class B
{
protected:
    int y;

public:
    void sety(int q) // Corrected function name to sety to set y
    {
        y = q;
    }
};

class C : public A, public B, public P // Corrected class inheritance declaration
{
public:
    void sum()
    {
        cout << "Sum = " << x + y + z << endl; // Use of x, y, and z from inherited classes
    }
};

int main()
{
    C obj1;
    obj1.setz(3);
    obj1.setx(4); 
    obj1.sety(5);
    obj1.sum();   
    return 0;
}
