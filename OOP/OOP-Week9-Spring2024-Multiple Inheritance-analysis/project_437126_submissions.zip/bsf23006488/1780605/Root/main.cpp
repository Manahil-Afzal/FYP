// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

// Base class P with protected variable 'z'
class P {
protected:
    int z;
public:
    void setz(int q) {  // Setter for 'z'
        z = q;
    }
};

// Class A with private variable 'x'
class A {
private:
    int x;  // Private
public:
    void setx(int q) {  // Setter for 'x'
        x = q;
    }
    int getx() const {  // Getter for 'x'
        return x;
    }
};

// Class B with protected variable 'y'
class B {
protected:
    int y;  // Protected
public:
    void sety(int q) {  // Setter for 'y'
        y = q;
    }
};

// Class C with multiple inheritance from A, B, and P
class C : public A, public B, public P {  // Corrected inheritance
public:
    void sum() {  // Method to sum 'x', 'y', 'z'
        cout << "Sum = " << getx() + y + z << endl;  // Accessing 'x' via getter
    }
};

int main() {
    C obj1;
    obj1.setx(4);  // Set value of 'x' in class 'A'
    obj1.sety(5);  // Set value of 'y' in class 'B'
    obj1.setz(3);  // Set value of 'z' in class 'P'
    obj1.sum();    // Outputs the sum of 'x', 'y', 'z'
    return 0;
}


