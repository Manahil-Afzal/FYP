// Identify and correct errors ( also comment the errors).
#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
    // Added a getter function to access the protected member z
    int getz() {
        return z;
    }
};

class A {
private:
    int x;
public:
    void setx(int q) {
        x = q;
    }
    // Added a getter function to access the private member x
    int getx() {
        return x;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) {
        y = q;
    }
    // Added a getter function to access the protected member y
    int gety() {
        return y;
    }
};

class C : public A, public B {
private:
    P objP; // Create an object of class P within class C
public:
    void setz(int q) {
        // Call setz from the object of class P to set the value of z
        objP.setz(q);
    }

    void sum() {
        // Access x, y, and z using the getter functions from their respective classes
        cout << "Sum = " << getx() + gety() + objP.getz() << endl;
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
