// Identify and correct errors ( also comment the errors).
// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected: //exchanged "private" with "protected"
	int x; 
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void sety(int q) //changed method name to 'sety"
    {
 	     y=q; //changed variable name 'z' in assignment to 'q' & also corrected the syntax of assignment
    }
};
class C : public A, public B, public P  // Replaced ';' to ',' // Also inherited C from P so it can access 'z'
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
