// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	public:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	public:
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void setz(int q)
    {
 	     y=q;
    }
};
class C : public A, public B   
{
 	public:
 		int z;
 	void sum()
 	{
 		cout<<"sum"<<x+y+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setx(3);
 	 obj1.setx(4);
 	 obj1.setz(5);
 	 obj1.sum();
 	 return 0;
}  
