// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
};

class A {
private:
    int x;
public:
    void setx(int q) {
        x = q;
    }
    int getx() {
        return x;
    }
};

class B {
protected:
    int y;
    int z; // Moved from private to protected
public:
    void sety(int q) {
        y = q;
    }
    int gety() {
        return y;
    }
    void setz(int q) {
        this->z = q; // Corrected to use this pointer
    }
    int getz() {
        return z;
    }
};

class C : public A, public B {
public:
    void sum() {
        B::setz(0);
        cout << "Sum = " << A::getx() + B::gety() + B::getz() << endl;
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
