// Identify and correct errors ( also comment the errors).

// the errors are:
// 1- the inheritance declaration in class C is incorrect.
// 2- In class A, member "x" should be protected or public so that it can be access.
// 3-  In the sum() function of class C, we need to inherit y from class B .
// 4-  In class B, we have a function setz() which sets z to y, but z is not a member of class B. 
//  #include <iostream>
// using namespace std;

// class P
// {
// 	protected:
// 	int z;
//  	public:
 	
//  	void setz(int q)
//     {
//  	     z=q;
//     }
// };

// class A
// {
// 	private:
// 	int x;
//  	public:
//  	void setx(int q)
//     {
//  	     x=q;
//     }

// };
// class B
// {
// protected:
// int y;
//  	public:
 	
//  	void setz(int q)
//     {
//  	     z=y;
//     }
// };
// class C : public A; public B   
// {
//  	public:
//  	void sum()
//  	{
//  	    cout << "Sum = " << x + y+z;
//  	}
// };

// int main()
// {
//  	 C obj1; 
//      obj1.setz(3);
//  	 obj1.setx(4);
//  	 obj1.sety(5);
//  	 obj1.sum();
//  	 return 0;
// }  


// here's the correct code


#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
  
};

class A
{
	protected:
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B: virtual public P
{

protected:
int y;
 	public:
 	
 	void sety(int q)
    {
 	     y=q;
    }
};
class C : public A, public B   
{
	
 	public:
// 		int z;
// 		C (int z1){
// 			z=z1;
//		 }
 	void sum()
 	{
 	    cout << "Sum = " << x + y+z;
 	}
};

int main()
{
 	 C obj1; 
 	 obj1.setz(5);
     obj1.setx(3);
 	 obj1.sety(4);
 	 obj1.sum();
 	 return 0;
}  

