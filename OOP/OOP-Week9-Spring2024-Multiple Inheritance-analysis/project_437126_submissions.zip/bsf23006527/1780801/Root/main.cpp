#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
};

class A {
private:
    int x;
public:
    void setx(int q) {
        x = q;
    }
    // Add a method to access x
    int getx() const {
        return x;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) {
        y = q;
    }
    // Add a method to access y
    int gety() const {
        return y;
    }
};

class C : public A, public B, public P {
public:
    // Add a method to set the value of z
    void setz(int q) {
        P::setz(q);
    }

    void sum() const {
        // Access x, y, and z using the methods provided by A, B, and P
        cout << "Sum = " << getx() + gety() + z << endl;
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}

