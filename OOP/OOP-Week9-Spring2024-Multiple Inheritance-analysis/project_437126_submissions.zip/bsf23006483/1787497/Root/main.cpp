// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected:  //protected instead of private
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void sety(int q)//sety instead setz
    {
 	     y=q;//y=q;instead of z=y;
    }
};
class C : public A, public B,public P   //, instead of ; and public P was not inherited
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
