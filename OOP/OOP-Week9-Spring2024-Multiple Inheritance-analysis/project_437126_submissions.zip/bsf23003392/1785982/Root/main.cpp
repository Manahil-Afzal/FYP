#include <iostream>
using namespace std;

class P {
protected:
    int z;
public:
    void setz(int q) {
        z = q;
    }
    int getz() const { // Add a getter for z
        return z;
    }
};

class A {
private:
    int x;
public:
    void setx(int q) {
        x = q;
    }
    int getx() const {
        return x;
    }
};

class B {
protected:
    int y;
public:
    void sety(int q) {
        y = q;
    }
    int gety() const {
        return y;
    }
};

class C : public A, public B, public P {
public:
    void sum() {
        cout << "Sum = " << getx() + gety() + getz() << endl; // Access x, y, and z using getters
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
