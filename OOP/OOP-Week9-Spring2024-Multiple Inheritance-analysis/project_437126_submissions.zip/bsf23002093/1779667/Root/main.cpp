#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
    int getz() const { // Added a getter method for z
        return z;
    }
};

class A : virtual public P { // Made inheritance virtual to avoid ambiguity
private:
    int x;

public:
    void setx(int q) {
        x = q;
    }
    int getx() const { // Added a getter method for x
        return x;
    }
};

class B : virtual public P { // Made inheritance virtual to avoid ambiguity
protected:
    int y;

public:
    void sety(int q) {
        y = q;
    }
    int gety() const { // Added a getter method for y
        return y;
    }
};

class C : public A, public B {
public:
    void sum() {
        cout << "Sum = " << getx() + gety() + getz() << endl; // Access z using getz method
    }
};

int main() {
    C obj1;
    obj1.setz(3); // Set z using setz method
    obj1.setx(4); // Set x
    obj1.sety(5); // Set y
    obj1.sum();
    return 0;
}
