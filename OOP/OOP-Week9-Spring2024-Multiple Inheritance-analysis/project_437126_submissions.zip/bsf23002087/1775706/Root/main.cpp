// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected:// changed it to protected from private
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B: public P// Inherited from P so that we can access and use z
{
protected:
int y;
 	public:
 	
 	void sety(int q)//changed name to sety
    {
 	     y=q;// changed from z=y to y=q
    }
};
class C : public A, public B   // replaced ; with ,
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
