//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
  	
  	int speed;
Car(int maxSpeed)
{
		
 speed =maxSpeed;
}

Car(Car&obj)

{
 speed = obj.speed;
}
};
 

int main() 
{
  Car obj1(200);
  Car obj2(obj1);

  cout << obj2.speed; 
  return 0;
}
