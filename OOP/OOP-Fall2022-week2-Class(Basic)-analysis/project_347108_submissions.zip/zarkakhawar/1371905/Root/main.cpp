//class, constructor
#include <iostream>
using namespace std;
class Car
{ public:
    Car(){}
    int speed(int maxSpeed);
};
int Car::speed(int maxSpeed) {
  return maxSpeed;
}

int main() {
  Car myObj;
  cout << myObj.speed(200); 
  return 0;
}
