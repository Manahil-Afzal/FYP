#include <iostream>
using namespace std;

class Person {
protected: // Changed from private to protected to allow derived class access
    string subject;

public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl; // Corrected the string to be printed
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;

    cout << "Enter subject's name: "; // Corrected the quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected the function name
    teacher.display();

    return 0;
}
