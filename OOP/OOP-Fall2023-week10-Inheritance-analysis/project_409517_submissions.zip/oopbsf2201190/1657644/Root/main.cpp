/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
   string subject;
   
     public:
    
    void setname(string subjectname1)
    {
    subject= subjectname1;
    }
    string getname(){
        return subject;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << getname() << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name";
     cin>>subjectname;
     teacher.setname(subjectname);
     teacher.display();

     return 0;
}
