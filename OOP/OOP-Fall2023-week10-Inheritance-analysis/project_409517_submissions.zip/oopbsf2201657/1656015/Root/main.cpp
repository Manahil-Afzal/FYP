/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;
class Person
{
	protected:
     string subject; 
	 string teacher; 
    public:    
    void setsubject(string subject)
    {
    }        
   void setteacher(string teacher)
   {
   }
};
class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Sir Akram Majeed" << teacher << endl;           
        }
};
int main()
{
     MathsTeacher teacher;
     string subject;
	 cout<<"Enter subject name:";
     cin>>subject;
     cout<<"Enter teacher name:";
     teacher.display();
     return 0;
}

