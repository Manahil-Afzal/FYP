/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person {
protected: // Make subject protected to allow access from derived class
    string subject;

public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;

    cout << "Enter subject's name: "; // Corrected quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected setname to setsubject
    teacher.display();

    return 0;
}
