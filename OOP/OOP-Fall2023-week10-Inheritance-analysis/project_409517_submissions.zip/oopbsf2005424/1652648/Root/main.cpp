#include <iostream>
using namespace std;

class Person
{
protected: // You should use protected access specifier for 'subject'
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;

    cout << "Enter subject's name: "; // Use double quotes instead of ”
    cin >> subjectname;
    teacher.setsubject(subjectname); // Change setname to setsubject
    teacher.display();

    return 0;
}
