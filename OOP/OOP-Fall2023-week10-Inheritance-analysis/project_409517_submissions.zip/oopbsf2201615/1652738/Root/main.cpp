/* identify and correct errors. Also comment the identified error*/

#include <iostream>
using namespace std;

class Person {
protected: // Made 'subject' protected to make it accessible to derived class
    string subject;

public:
    void setSubject(string subjectName) {
        subject = subjectName;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectName; // Changed variable name to subjectName for consistency
    cout << "Enter subject's name: ";
    cin >> subjectName;
    teacher.setSubject(subjectName); // Corrected function name to setSubject
    teacher.display();

    return 0;
}
