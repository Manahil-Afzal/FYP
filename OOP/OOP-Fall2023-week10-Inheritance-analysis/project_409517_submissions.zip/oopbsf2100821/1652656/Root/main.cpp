/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
   protected:  // members should be protected
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject :" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name";// double quotation
     cin>>subjectname;
     teacher.setsubject(subjectname);// call setsubject instead of set name 
     teacher.display();

     return 0;
}
