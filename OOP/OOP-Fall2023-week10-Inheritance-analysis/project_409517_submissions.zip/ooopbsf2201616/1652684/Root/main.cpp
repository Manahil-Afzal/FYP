/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person {
protected:  // Add access specifier
    string subject;

public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: ";  // Use double quotes for the string
    cin >> subjectname;
    teacher.setsubject(subjectname);  // Correct the function name
    teacher.display();

    return 0;
}
