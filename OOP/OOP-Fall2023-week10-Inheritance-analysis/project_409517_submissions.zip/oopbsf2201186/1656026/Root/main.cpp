#include <iostream>
#include <string>  // Include the string header to use the string type
using namespace std;

class Person
{
protected: // Make subject protected to allow derived classes to access it
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Added a space after "Subject"
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Replaced curly quotes with straight quotes
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected the function name to setsubject
    teacher.display();

    return 0;
}