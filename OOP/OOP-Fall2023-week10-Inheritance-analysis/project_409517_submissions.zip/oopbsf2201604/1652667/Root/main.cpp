#include <iostream>
using namespace std;

class Person
{
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
    
    string getsubject() // You should add a getter method to access the 'subject' member.
    {
        return subject;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << getsubject() << endl; // Corrected and added "Subject: "
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Added a space after 'name'
    cin >> subjectname;
    teacher.setsubject(subjectname);
    teacher.display();

    return 0;
}
