/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
   string subject;
   string name;
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }

    void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
        
};

class MathsTeacher : public Person
{
       
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject is name";
     cin>>subjectname;
     teacher.setsubject(subjectname);
     teacher.display();

     return 0;
}
