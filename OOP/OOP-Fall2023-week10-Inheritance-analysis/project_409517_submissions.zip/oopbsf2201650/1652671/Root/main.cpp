/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    protected:
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname1;
	 cout<<"Enter subjects name";
     cin>>subjectname1;
     teacher.setsubject(subjectname1);
     teacher.display();

     return 0;
}
