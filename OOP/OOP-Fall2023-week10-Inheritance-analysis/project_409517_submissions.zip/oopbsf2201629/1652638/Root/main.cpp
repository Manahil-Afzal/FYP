/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person {
private:
  string subject;

public:
  void setSubject(string subjectName1) {
    subject = subjectName1;
  }

  string getSubject() {
    return subject;
  }
};

class MathsTeacher : public Person {
public:
  void display() {
    cout << "Subject: " << getSubject() << endl;
  }
};

int main() {
  MathsTeacher teacher;
  string subjectName;

  cout << "Enter subject's name: ";
  cin >> subjectName;

  teacher.setSubject(subjectName);
  teacher.display();

  return 0;
}