/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{   protected: //use access specifier to inherit
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
    string getsubject()
    {
    	return subject;
	}
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject: " << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     teacher.setsubject("Discrete Mathematics:");
     teacher.display();

     return 0;
}
