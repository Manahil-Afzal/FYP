/* identify and correct errors. Also comment the identified error*/
#include<iostream>
#include<string> // haven't included this header file 
using namespace std;

class Person
{
    protected:    //data members should be protected
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name"; // quotation marks should be right
     cin>>subjectname;
     teacher.setsubject(subjectname); // there should be setsubject() instead of setname()
     teacher.display();

     return 0;
}
