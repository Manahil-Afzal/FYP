/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    // The 'subject' member variable should be protected or private, not public
    // Also, it's a good practice to initialize member variables in the constructor
protected:
    string subject;

public:
    // Changed the function name to setSubject to match the member variable
    void setSubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        // Added a space after "Subject" for better formatting
        cout << "Subject: " << subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;

    // Corrected the quotation marks around the string
    cout << "Enter subject’s name: ";
    
    cin >> subjectname;

    // Changed the function name to setSubject to match the member variable
    teacher.setSubject(subjectname);
    teacher.display();

    return 0;
}