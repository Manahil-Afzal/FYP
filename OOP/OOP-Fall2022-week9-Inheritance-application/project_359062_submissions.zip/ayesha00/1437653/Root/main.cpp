/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
		string name;
		int id;
		int workHour;
		int HourSalary;
		public:
			void setName(string n)
			{
				name=n;
			}
			void setId (int i){
				id=i;
			}
			void setWorkHour(int h){
				workHour=h;
			}
			void setHourSalary(int s){
				HourSalary =s;
			}
			
};
class Adhoc_employee:public Employee{
	public:
		void display(){
			cout<<"name of Employee: "<<name<<endl;
			cout<<"ID of Employee: "<<id<<endl;
			cout<<"Work hour of Employee: "<<workHour<<endl;
		}
		int getSalary(){
			int w;
			w=workHour*HourSalary;
			cout<<w<<endl;
		}
};
int main(){
	Adhoc_employee e;
	e.setName("Ayesha ");
	e.setId(11);
	e.setWorkHour(5);
	e.setHourSalary(3400);
	cout<<"details of the Employee:"<<endl;
	e.display();
	cout<<"Total salary of Employee: ";
	e.getSalary();
	return 0;
}