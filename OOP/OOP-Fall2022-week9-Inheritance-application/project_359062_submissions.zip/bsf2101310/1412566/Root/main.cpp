/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
class Employee{
    public:
    string name;
    int Id, working_hours;
    float per_hour_salary;
    public:
   void setdata(){
       cout<<"enter the name of employee";
       cin>>name;
       cout<<"Enter the Id of employee: ";
       cin>>Id;
       cout<<"enter the hours of employee: ";
       cin>>working_hours;
       cout<<"enter the salary of employee: ";
       cin>>per_hour_salary;
   }
};     
class  Adhoc_employee:public Employee
{
    public:
    int salary(){
        cout<<"Salary of Employee: ";
        return(working_hours*per_hour_salary);
    }
    void print(){
        cout<<name<<""<<Id<<""<<working_hours<<""<<per_hour_salary<<"";
    }
};
int main()
{
    Adhoc_employee adh;
    adh.setdata();
    adh.print();
    cout<<"salary"<<adh.salary();
    return 0;
}