/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee
{
	protected:
		string Name;
		int Id;
		int Numberofworkinghours;
		int Perhoursalary;
		
	public:
		Employee()
		{
			Name="";
			Id=0;
			Numberofworkinghours=0;
			Perhoursalary=0;
		}
		void setName(string name)
		{
			Name=name;
		}
		void setId(int id)
		{
			Id=id;
		}
		void setNumberofworkinghours(int numberofworkinghours)
		{
			Numberofworkinghours=numberofworkinghours;
		}
		void setPerhoursalary(int perhoursalary)
		{
			Perhoursalary=perhoursalary;
		}
		string getName()
		{
			return Name;
		}
		int getId()
		{
			return Id;
		}
		int getNumberofworkinghours()
		{
			return Numberofworkinghours;
		}
		int getPerhoursalary()
		{
			return Perhoursalary;
		}
		
};
class Adhoc_employee:public Employee
{
	public:
		int salary()
		{
			return Numberofworkinghours*Perhoursalary;
		}
		void display_info()
		{
			cout<<"Name:"<<Name<<endl;
			cout<<"Id:"<<Id<<endl;
			cout<<"Number of working hours:"<<Numberofworkinghours<<endl;
			cout<<"Per hour salary:"<<Perhoursalary<<endl;
			cout<<"Salary:"<<salary()<<endl;
		}
	
};
int main()
{
	Adhoc_employee obj1;
	obj1.setName("jawad");
	obj1.setId(1);
	obj1.setNumberofworkinghours(10);
	obj1.setPerhoursalary(100);
	obj1.display_info();
	
	return 0;
}