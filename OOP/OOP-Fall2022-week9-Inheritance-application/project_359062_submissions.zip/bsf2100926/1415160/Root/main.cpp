/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string.h>
using namespace std;
class employee
{
	protected:
	 string name;
		int id;
		int no_of_working_hours;
  int salary_per_hours;
 public:
	 void details()
		{
	    	name="Ali Ahmad";
	    	id=2102;
	    	no_of_working_hours=8;
	    	salary_per_hours=500;	
		}    				
};
class Adhoc_employee:public employee{
	public:
		
	void  display_info()
	{
		cout<<"The employee Name = "<<name<<endl;
		cout<<"Thee employee id = "<<id<<endl;
		cout<<"The employee no_of_working_hours = "<<no_of_working_hours<<endl;
		cout<<"The employee salary_per_hours = "<<salary_per_hours<<endl;
    }
    	long salary()
	{
		return(no_of_working_hours*salary_per_hours);
	}	
};
int main()
{
  Adhoc_employee e1;
  e1.details();
  e1.salary();
  e1.display_info();
  cout<< "The salary of employee = " <<e1.salary()<<endl;
    	
}