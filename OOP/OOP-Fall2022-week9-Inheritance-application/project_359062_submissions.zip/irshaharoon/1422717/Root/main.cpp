/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#define PLAYER_HH
#include <string>
using namespace std;
class Car{
	public:
    string passenger;
    Car(string passenger_n){
    	passenger= passenger_n;
	};
	
};
class Passenger{
	public:
    Car* passenger_name;
    
};
class Engine{
public:
     int engine_number;
   Car* passenger_na;
   void display(int engine_numb, Car* passenger_n){
   passenger_na=passenger_n;
   engine_number=engine_numb;
    cout<<engine_number<<endl;
    cout<<passenger_na;
}
};

int main(){
    Car obj1= Car("ali");
    Engine obj2;
    obj2.display(1,&obj1);
}