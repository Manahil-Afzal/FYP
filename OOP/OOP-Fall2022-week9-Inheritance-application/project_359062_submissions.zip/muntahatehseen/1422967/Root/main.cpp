/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
    public:
    string name;
    int id;
    int working_hrs;
    int salary;
    public:
    
    
};
class Adhoc_employee:public Employee{
    public:
    int salary(int h, int s)
    {
        cout<<"Your salary is "<<h*s;
    }
    void display_info()
    {
        cout<<"Employee name "<< name;
        cout<<"Employee id "<<id;
            cout<<"Employee working hurs "<<working_hrs;
                cout<<"Employee salary "<<salary(3,4000);
                
        
        
    }
};
int main()
{
    Adhoc_employee a1;
    a1.salary(12,4000);
    a1.display_info();
}

    
    
    
    
    
