/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;

class Employee
{
protected:
	string name;
	string id;
	int whr;
	int psa;
	static int b;	
};

class Adhoc_employee:public Employee
{
	public:
		Adhoc_employee()
		{
			cout<<"----NO."<<b<<" Employee Data----"<<endl;
			cout<<"Enter Name:"<<endl;
			cin>>name;
			cout<<"Enter ID:"<<endl;
			cin>>id;
			cout<<"Enter Working Hours:"<<endl;
			cin>>whr;
			cout<<"Enter Per Hour Salary:"<<endl;
			cin>>psa;
			b++;
		}
		void putdata()
		{
			cout<<"Employee name:"<<name<<endl;
			cout<<"Employee ID:"<<id<<endl;
		}
		long salary()
		{
			return whr*psa;
		}
};
int Employee::b=1;
int main()
{
	int a;
	cout<<"Enter Number Of Employees"<<endl;
	cin>>a;
	Adhoc_employee e[a];
	for(int i=0;i<a;i++)
	{
		cout<<"----NO."<<i+1<<" Employee Data----"<<endl;
		e[i].putdata();
		cout<<"The salary Of Employee Is "<<e[i].salary()<<endl;
		
	}
	return 0;
}
