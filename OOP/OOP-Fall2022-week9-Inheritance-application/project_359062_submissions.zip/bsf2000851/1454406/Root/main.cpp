/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee. 
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods 
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;

class Employee{
	protected:
		string name;
		string id;
		int work_hours;
		int hour_salary;
		public:
		void set_name(string n){
			name=n;
		}	
		void set_id(string i){
			id=i;
		}
		void set_work_hours(int w){
			work_hours=w;
		}
		void set_hour_salary(int h){
			hour_salary=h;
		}
};
 class Adhoc_employee:public Employee
 {
 	public:
 		void get_information()
 		{
 			cout<<"Name of Employee:"<<name<<endl;
 			cout<<"Id of Employee:"<<id<<endl;
 			cout<<"Working hours of Employee:"<<work_hours<<endl;
		 }
		 int get_salary()
		 {
		 	int wh;
		 	wh=work_hours*hour_salary;
		 	cout<<wh<<endl;
		 }
 };
 main()
 {
 	Adhoc_employee emp;
 	emp.set_name("Samar Hayat");
 	emp.set_id("BSF2000851");
 	emp.set_work_hours(40);
 	emp.set_hour_salary(150);
 	cout<<"Information of the Employee:"<<endl<<endl;
 	emp.get_information();
 	cout<<"Salary of the employee:";
 	emp.get_salary();
 	return 0;
 	
 }
