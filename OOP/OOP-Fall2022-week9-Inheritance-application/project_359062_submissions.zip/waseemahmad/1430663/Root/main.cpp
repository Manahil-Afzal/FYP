/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>

using namespace std;

class Employee{
    public:
        string name;
        int id;
        int workingHours;
        int perHourSallery;
        
        Employee(string name, int id, int workingHours, int perHourSallery){
            this->name = name;
            this->id = id;
            this->workingHours = workingHours;
            this->perHourSallery = perHourSallery;
        }
};

class Adhoc_employee: public Employee{
    public:
        Adhoc_employee(string name, int id, int woringHours, int perHourSallery):Employee(name, id, woringHours, perHourSallery){
            
        }
        
        void display_info(){
            cout<<"Name : "<<name<<"\n";
            cout<<"ID : "<<id<<"\n";
            cout<<"Working hours : "<<workingHours<<"\n";
            cout<<"Per hour sallery : "<<perHourSallery<<"\n";
            
        }
        
        int calculateSallery(){
            int sallery = workingHours * perHourSallery;
            return sallery;
        }
};

int main(){
    
    Adhoc_employee e("Alex", 123, 180, 600);
    
    e.display_info();
    
    cout<<"Sallery : $"<<e.calculateSallery();
    
    return 0;
}