/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. 
The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
class Employee
{
    public:
    string name;
    int id;
    int hours;
    float salaryofhours;
    public:
    void setdata()
    {
        cout<<"enter the name of employee"<<endl;
        cin>>name;
        cout<<"enter the id of employee"<<endl;
        cin>>id;
        cout<<"enter the hours of employee"<<endl;
        cin>>hours;
        cout<<"enter the salary of employee"<<endl;
        cin>>salaryofhours;
    }
    
};
//derived class:
class  Adhocemployee:public Employee
{
    public:
    void print()
   {
      cout<<name<<" "<<id<<" "<<hours<<" "<<salaryofhours<<" ";
      
    }
    int displaysalary()
    {
        return (hours * salaryofhours);
    }
};
int main()
{
    Adhocemployee e1;
    e1.setdata();
  // cout<<"display info"<<
   e1.print();
  // <<endl;
    cout<<"salary"<<e1.displaysalary()<<endl;
    return 0;
}