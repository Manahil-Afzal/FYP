/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;

class Employee{
    protected:
    string name;
    int id;
    int no_of_working_hours;
    int per_hour_sal;
    
};
class Adhoc_employee : public Employee{
    int Salary;
    public:
    void salary(){
        cout<<"Enter name : ";
        cin>>name;
        cout<<"\nEnter id : ";
        cin>>id;
        cout<<"\nEnter number of working hours : ";
        cin>>no_of_working_hours;
        cout<<"\nEnter per hour salary";
        cin>>per_hour_sal;
        Salary=no_of_working_hours*per_hour_sal;
    }
    void display_info(){
        cout<<"\nName : "<<endl;
        cout<<"ID : "<<endl;
        cout<<" Per day Salary is : "<<Salary;
    }
};
int main()
{
    Adhoc_employee A1;
    A1.salary();
    A1.display_info();
    return 0;
}