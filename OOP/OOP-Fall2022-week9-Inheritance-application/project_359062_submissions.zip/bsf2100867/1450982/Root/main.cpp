/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee
{
protected:
int salary;
string name;
int id;
int workinghour;
int hoursalary;
public:
void set_name( string name1){
name=name1;}
void set_id(int id1){
id=id1;}
void set_workinghour(int hour){
workinghour=hour;}
void set_hoursalary(int salary1){
hoursalary=salary1;}

};
class adhoc_employee:public employee
{public:
int getsalary()
  {
      
      salary=workinghour*hoursalary;
     return salary;
  }
  void display_info()
  {
      cout<<"detail of employee is:"<<endl;
      cout<<"name is:"<<name<<endl;
      cout<<"id is :"<<id<<endl;
      cout<<"workinghour is :"<<workinghour<<endl;
      cout<<"hoursalary is :"<<hoursalary<<endl;
  }
};
int main()
{
    adhoc_employee B1;
    B1.set_name("irsa");
    B1.set_id(20);
    B1.set_workinghour(4);
    B1.set_hoursalary(2000);
     B1.display_info();
    cout<<"salary is :"<<B1.getsalary()<<endl;
   
    return 0;
    
}
