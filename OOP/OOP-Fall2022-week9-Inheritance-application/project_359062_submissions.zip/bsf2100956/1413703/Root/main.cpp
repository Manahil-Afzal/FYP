/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”.
The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee{
    protected:
    string Name;
    string ID;
    int working_hours;
    float per_hour_salary;
    float Total_salary;
    
    public:
    
    void set(){
         cout<<"Enter the name id working hours and per hour salary "<<endl;
        cin>>Name;
        cin>>ID;
        cin>>working_hours;
        cin>>per_hour_salary;
    }
    
    
    
};
class Adhoc_employee:public Employee{
    public:
    int  salary(){
        set();
        Total_salary=working_hours*per_hour_salary;
        return Total_salary;
        
        
    }
    void display(){
        cout<<" Name : "<<Name<<endl;
        cout<<" ID : "<<ID<<endl;
        cout<<" Working Hours : "<<working_hours<<endl;
        cout<<" Total Salary : "<<Total_salary<<endl;
        
    }
    
  
  
  
    
};


int main(){
    Adhoc_employee AE;
    AE.salary();
    AE.display();
    
    
    
    return 0;
}