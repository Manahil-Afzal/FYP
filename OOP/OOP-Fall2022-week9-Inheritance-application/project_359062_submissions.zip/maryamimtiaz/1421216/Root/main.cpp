#include<iostream>
#include<string>
using namespace std;
class employee{
protected:
string name;
string id;
int work_hours;
int hour_salary;
public:
void set_name(string n){
name=n;
}
void set_id(string i){
id=i;
}
void set_work_hours(int w){
work_hours=w;
}
void set_hour_salary( int h){
hour_salary=h;
}
};
class Adhoc_employee:public employee
{
public:
void get_information()
{
cout<<"name of employee:"<<name<<endl;
cout<<"id of employee:"<<id<<endl;
cout<<"work hours of employee"<<work_hours<<endl;
}
int get_salary()
{
int wh;
wh=work_hours*hour_salary;
cout<<wh<<endl;
}
};
main()
{
Adhoc_employee emp;
emp.set_name("hassan");
emp.set_id("112233");
emp.set_work_hours(24);
emp.set_hour_salary(20);
cout<<"information of the employee"<<endl;
emp.get_information();
cout<<"salary of the employee";
emp.get_salary();
return 0;
}