#include <iostream>
#define PLAYER_HH
#include <string>
using namespace std;
class Car{
	public:
    string passenger;
    Car(string passenger_n){
    	passenger= passenger_n;
	};
	
};
class Passenger{
	public:
    Car* passenger_name;
    
};
class Engine{
public:
     int engine_number;
   Car* passenger_na;
   void display(int engine_numb, Car* passenger_n){
   passenger_na=passenger_n;
   engine_number=engine_numb;
    cout<<engine_number<<endl;
    cout<<passenger_na;
}
};

int main(){
    Car obj1= Car("ali");
    Engine obj2;
    obj2.display(1,&obj1);
}