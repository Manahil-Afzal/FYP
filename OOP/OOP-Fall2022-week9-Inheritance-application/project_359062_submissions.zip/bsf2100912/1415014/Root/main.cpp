/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee{
	public:
	string Name;
	int Id;
	int working_hrs;
	int per_hr_salary;
	int salary;
};
class Adhoc_employee : public Employee{
	public:
		int salary(){
		    return (working_hrs*per_hr_salary);
		}
		void display_info(){
			cout<<"Name  "<<"\tID"<<"\tNo. of Working Hours"<<"\tPer Hour Salary"<<endl;
			cout<<Name<<"  \t"<<Id<<"\t      "<<working_hrs<<"\t\t\t    "<<per_hr_salary;
		}
};
int main(){
	Adhoc_employee obj;
	cout<<"Enter name: ";
	cin>>obj.Name;
	cout<<"Enter ID: ";
	cin>>obj.Id;
	cout<<"Enter Number of Working hours:";
	cin>>obj.working_hrs;
	cout<<"Enter per hour slary:"; 
	cin>>obj.per_hr_salary;
	obj.display_info();
	cout<<"\nSalary of employee:"<<obj.salary();
}