/*The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;

class Employee{
	public:
    string Name;
    int Id;
    int Number_of_working_hours;
    int Per_hour_salary;
    int total_working_days;
    public:
    void setName(string name){
        Name = name;
    }
    string getName(){
        return Name;
    }
    void setId(int id){
        Id = id;
    }
    int getId(){
        return Id;
    }
    void setWorkingHours(int working_hours){
        Number_of_working_hours = working_hours;
    }
    void setPerHourSalary(int hourly_salary){
        Per_hour_salary = hourly_salary;
    }
    void setWorkingDays(int working_days){
    	total_working_days = working_days;
	}
};

class Adhoc_employee : public Employee{
    public:
    int per_day_salary(){
        int per_day_salary;
        per_day_salary =  ( Number_of_working_hours * Per_hour_salary );
    }
    int monthly_salary(){
    	int monthly_salary;
    	monthly_salary =  ( per_day_salary() * total_working_days );
    	return monthly_salary;
	}
    void display_info(){
        cout<<"\n Employee Name :"<<getName();
        cout<<"\n Employee id : "<<getId();
        cout<<"\n Employee Salary in Hours is : "<<per_day_salary();
        cout<<"\n "<<getName()<<" "<<"Monthly Salary is : "<<monthly_salary();
    }
};

int main(){
	Adhoc_employee e;
	e.setName("Zohaib");
	e.setId(111);
	e.setWorkingHours(8);
	e.setPerHourSalary(200);
	e.setWorkingDays(20);
	e.display_info();
	
	return 0;
}