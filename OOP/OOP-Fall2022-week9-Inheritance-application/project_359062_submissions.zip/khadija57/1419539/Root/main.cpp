/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee
{
    protected:
    string name;
    int id;
    int workhours;
    int hoursalary;
    public:
    void setname(string n)
    {
        name=n;
    }
    void setid(int i)
    {
        id=i;
    }
    void setworkhour(int h)
    {
        workhours=h;
    }
    void sethoursalary(int s)
    {
        hoursalary=s;
    }
};
class Adhoc_Employee:public Employee
{
    public:
    void get_info()
    {
        cout<<"Name of Employee:"<<name;
        cout<<"Id Of Employee:"<<id;
        cout<<"Work Hours:"<<workhours;
    }
    int get_salary()
    {
        int wh;
        wh=workhours*hoursalary;
        cout<<wh;
    }
};
int main()
{
    Adhoc_Employee emp;
    emp.setname("Khadija");
    emp.setid(1);
    emp.setworkhour(22);
    emp.sethoursalary(34000);
    cout<<"Info Of Emp:";
    emp.get_info();
    cout<<"Salary Of Emp:";
    emp.get_salary();
    return 0;
}