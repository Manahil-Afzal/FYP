/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee {
protected:
	string Name, ID;
	int NumberOfWorkingHours;
	float PerHourSalary;
public:
	 Employee() {
		cout << " enter employee name ";
		cin >> Name;
		cout << "enter employee id ";
		cin >>ID ;
		cout << "enter employee NO's of working hours ";
		cin >> NumberOfWorkingHours;
		cout << "enter employee PER hour salary ";
		cin >>PerHourSalary ;
	}

};
class adhoc_Employee : public Employee {
	float EmployeeSalary;

public:
	void Salary() {
		EmployeeSalary = NumberOfWorkingHours * PerHourSalary;
	}
	void display() {
		cout << "Employee name : " << Name << endl;
		cout << Name << " ID : " << ID << endl;
		cout << Name << " Numbers of working hours : " << NumberOfWorkingHours << endl;
		cout << Name << " per hours salary : " << PerHourSalary << endl;
		cout << Name << " salary is " << EmployeeSalary;
	}

};
	int main() {
		
		adhoc_Employee obj1;
		obj1.Salary();
		obj1.display();
	}