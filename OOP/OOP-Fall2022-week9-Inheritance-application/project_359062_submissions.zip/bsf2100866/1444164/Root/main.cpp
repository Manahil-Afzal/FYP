/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee{
    protected:
    string name;
    int id;
    int workinghours;
    int perhoursalary;
    public:
  
    void set_name(string name1)
    {name =name1;}
    
      void set_id(int id1)
    {id =id1;}
      void set_workinghours(int hours)
    {workinghours=hours;
	}
      void set_perhoursalary(int salary)
    {perhoursalary =salary;}
};
class Adhoc_employee:public employee{
  public:
  int getSalary(){
 int salary;
  salary=workinghours*perhoursalary;
  return salary;}
  void display_info(){
      cout<<"The information of employee is"<<endl;
      cout<<name<<endl;
      cout<<id<<endl;
      cout<<workinghours<<endl;
      cout<<perhoursalary<<endl;
  }
};
int main()
{
    Adhoc_employee A1;
    A1.set_name("rija");
    A1.set_id(457890);
    A1.set_workinghours(20);
    A1.set_perhoursalary(200);
    A1.display_info();
    cout<<"The salary is"<<A1.getSalary()<<endl;
    return 0;
}

    
