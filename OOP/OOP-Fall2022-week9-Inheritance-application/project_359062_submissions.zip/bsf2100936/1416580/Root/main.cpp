/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee{
protected:
	string name, id;
	int numberOfworkinghours;
	float perHoursalary;
public:
	 employee(){
		cout<<" Enter employee name : ";
		cin>>name;
		cout<<"Enter employee id : ";
		cin>>id;
		cout<<"Enter employee no. of working hours : ";
		cin>>numberOfworkinghours;
		cout<<"Enter employee PER hour salary : ";
		cin>>perHoursalary ;
	}

};
class Adhoc_Employee : public employee {
	float EmployeeSalary;
public:
	void Salary(){
		EmployeeSalary = numberOfworkinghours * perHoursalary;
	}
	void display(){
		cout<<"Employee name : "<<name<<endl;
		cout<<" ID : "<<id<<endl;
		cout<<" Numbers of working hours : "<<numberOfworkinghours<<endl;
		cout<<" Per hours salary : "<<perHoursalary<<endl;
		cout<<" salary is : "<< EmployeeSalary;
	}

};
	int main() {
		
		Adhoc_Employee obj1;
		obj1.Salary();
		obj1.display();
	}