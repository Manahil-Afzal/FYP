/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
#include<string>
using namespace std;
class employee{
protected:
string name;
string id;
int work_hours;
int hour_salary;
public:
void set_name(string n){
name=n;
}
void set_id(string i){
id=i;
}
void set_work_hours(int w){
work_hours=w;
}
void set_hour_salary( int h){
hour_salary=h;
}
};
class Adhoc_employee:public employee
{
public:
void get_information()
{
cout<<"name of employee:"<<name<<endl;
cout<<"id of employee:"<<id<<endl;
cout<<"work hours of employee:"<<work_hours<<endl;
}
int get_salary()
{
int wh;
wh=work_hours*hour_salary;
cout<<wh<<endl;
}
};
main()
{
Adhoc_employee emp;
emp.set_name("ESHA");
emp.set_id("118964");
emp.set_work_hours(24);
emp.set_hour_salary(20);
cout<<"information of the employee:"<<endl;
emp.get_information();
cout<<"salary of the employee:";
emp.get_salary();
return 0;
}