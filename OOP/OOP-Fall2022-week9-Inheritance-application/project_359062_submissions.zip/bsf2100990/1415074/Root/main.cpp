/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
	string name;
	int id;
	float number_of_working_hour;
	float per_hour_salary;
	double salary;
	public:
	void input_info(){
		cout<<"\nENter employee information!\n";
		cout<<"NAME:";
		cin>>name;
		cout<<"ID:";
		cin>>id;
		cout<<"Number_of_working _hour:";
		cin>>number_of_working_hour;
		cout<<"per_hour_salary";
		cin>>per_hour_salary;
	}
	
};
class Adhoc_employee:public Employee{
	public:
	void salary_calculate(){
		salary=number_of_working_hour*per_hour_salary;
	}
	void display_info(){
		cout<<"\ndisplaying information of employee\n";
		cout<<"NAME:"<<name<<"\nID:"<<id<<"\nnumber_of_working _hour"<<number_of_working_hour;
		cout<<"\nper_hour_salary:"<<per_hour_salary<<"\nTotal Salary:"<<salary;
	}
};
int main (){
	Adhoc_employee E1;
	E1.input_info();
	E1.salary_calculate();
	E1.display_info();
}