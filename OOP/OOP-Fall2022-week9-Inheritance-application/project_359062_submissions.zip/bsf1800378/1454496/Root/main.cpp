/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee
{
	protected:
   string name;
   int id;
   int no_of_work;
   int sal;
   
     public:
    
    void setsalary(int s)
    {
    sal= s;
    }
    void setwork(int w)
    {
    no_of_work= w;
    }
        
};
class Adhoc_employee: public Employee{
	public:
int	getsalary(){
		return no_of_work * sal;
	}
	int display_info(){
		cout<<"name of employee"<<endl;
		cin>>name;
		cout<<"id of employee: "<<endl;
		cin>>id;
		cout<<"no of working hour: "<<no_of_work<<endl;
		cout<<"per hour salary: "<<sal<<endl;
	}
	
};
int main()
{
     Adhoc_employee e;
     e.setsalary(30000);
     e.setwork(10);
	 e.display_info();
	cout<<"salary "<<e.getsalary();


     return 0;
}