/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employe{
	protected:
		string id;
		string name;
		int wrk_hours;
		int hours_salary;
		public:
			void set_id(string i){
				id=i;
			}
				void set_name(string n){
				name=n;
			}	void set_wrk_hours(int w){
				wrk_hours=w;
			}	void set_hours_salary(int s){
				hours_salary=s;
			}
};

class Adhoc_employee:public employe{
	public:
	void get_infor(){
		cout<<"id of Employee:"<<id<<endl;
		cout<<"name of Employee:"<<name<<endl;
		cout<<"work hours of Employee :"<<wrk_hours<<endl;
	}	
	int get_salary(){
		int work_hours;
		 work_hours=wrk_hours*hours_salary;
		 cout<<work_hours<<endl;
	}
};
int  main(){
	Adhoc_employee e;
	e.set_id("990");
	e.set_name("SYED SHAHZAIB");
	e.set_wrk_hours(12);
	e.set_hours_salary(30);
	cout<<"\t\t\tInformation of Employee:"<<endl;
	e.get_infor();
	cout<<"Salary of Employee:";
	e.get_salary();
	return 0;
}