/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
		string name;
		int id;
		int no_of_working_hours;
		int per_hour_salary;
		
};
class Adhoc_employee: public Employee{
	public:
		int salary_of_employee;
		void salary_method()
		{
			cout<<"Enter name: ";
			cin>>name;
			cout<<"Enter id: ";
			cin>>id;
			cout<<"Enter no_of_working_hours: ";
			cin>>no_of_working_hours;
			cout<<"Enter per_hour_salary: ";
			cin>>per_hour_salary;
			salary_of_employee = no_of_working_hours * per_hour_salary; 
		}
		
		void display_info_method()
		{
			cout<<"\t---EMPLOYEE DETAILS---"<<endl;
			cout<<"Employee name is: "<<name<<endl;
			cout<<"Employee id is: "<<id<<endl;
			cout<<"Employee no_of_working_hours is: "<<no_of_working_hours<<endl;
			cout<<"Employee per_hour_salary is: "<<per_hour_salary<<endl;
			cout<<"Salary_of_employee is: "<<salary_of_employee<<endl;
		}
};
int main()
{
	Adhoc_employee emp_obj;
	emp_obj.salary_method();
	emp_obj.display_info_method();
	return 0;
}