/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/#include <iostream>
#include <stdio.h>
using namespace std;
class Employee
{
    protected:  
        char    Name[30];
        int     EmpId;
        int 	Workhours;
        int		Salary;
    public:
        void getEmployee(void)
        {
            cout << "Enter Name: "; 
            cin  >> Name;
            cout << "Enter Emp. Id: ";
            cin  >> EmpId;
            cout << "Enter Number of Work Hours: ";
            cin  >> Workhours;
            cout <<"Enter Per hour Salary:";
            cin  >> Salary;
        }
};

/*derived class - employee*/
class Adhoc_Employee:public Employee
{
    public:
    	int getSalary()
    	{	
    		return(Salary * Workhours);
		}
		void getEmployeeinfo(void)
		{
            cout << "Enter employee's basic info: " << endl;
        }
        void printEmployeeinfo(void)
        {
            cout << "Name: "      					<< Name   		<< endl;      //accessing protected data
            cout << "Employee ID: " 				<< EmpId  		<< endl;        //accessing protected data
            cout << "Number of work hours: "        << Workhours 	<< endl;
            cout << "Per hour Salary:" 				<< Salary 		<< endl;
             
        }
};
 
int main(void)
{
  Adhoc_Employee emp;
    emp.getEmployee();
    cout <<"Total salary:" <<emp.getSalary()<<endl; 
    emp.printEmployeeinfo();
    return 0;
}