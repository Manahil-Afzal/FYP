/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;

class Employee{
	protected:
		string Name;
		string Id;
		int Number_of_working_hours;
		float Per_hour_salary;
	public:
		Employee(){
			Name = "m.husnain";
			Id = "Bsf2101105";
			Number_of_working_hours = 8;
			Per_hour_salary = 2000.0;
		}
};

class Adhoc_employee : public Employee{
	public:
		float salary(){
			return Number_of_working_hours*Per_hour_salary;
			
		}
		void display_info(){
			cout<<"Employee name : "<<Name<<endl;
			cout<<"Employee id : "<<Id<<endl;
			cout<<"Employee number of working hours : "<<Number_of_working_hours<<endl;
			cout<<"Employee per hour salary : "<<Per_hour_salary<<endl;
			cout<<"Employee total salary : "<<salary()<<endl;
		}
};

int main(){
	Adhoc_employee emp1;
	emp1.display_info();
	return 0;
}