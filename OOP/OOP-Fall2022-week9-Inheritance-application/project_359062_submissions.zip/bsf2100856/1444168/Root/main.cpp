/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/#include<iostream>
#include<iostream>
using namespace std;
class Employee{
    protected:
    string name;
    int id;
    int workingHours;
    int perHourSalary;
    int salary;
    public:
    void set_name(string name1)
    {
        name=name1;
    }
    void set_id(int id1)
    {
        id=id1;
    }
    void set_workingHours(int hours)
    {
        workingHours=hours;
    }
    void set_perHourSalary(int salary)
    {
        perHourSalary=salary;
    }
};
class Adhoc_employee:public Employee
{
    public:
    int getSalary()
    {
        int salary;
        salary=workingHours*perHourSalary;
        return salary;
    }
    void display_info()
    {
        cout<<"the information of employee is"<<endl;
        cout<<name<<endl;
        cout<<id<<endl;
        cout<<workingHours<<endl;
        cout<<perHourSalary<<endl;
    }
};
int main()
{
    Adhoc_employee A1;
    A1.set_name("fiza");
    A1.set_id(747563);
    A1.set_workingHours(21);
    A1.set_perHourSalary(200);
    A1.display_info();
    cout<<"the salary is"<<A1.getSalary()<<endl;
    return 0;
}