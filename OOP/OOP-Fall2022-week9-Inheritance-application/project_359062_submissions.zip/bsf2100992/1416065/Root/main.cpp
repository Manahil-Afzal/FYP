/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
 #include<string>
 using namespace std;
 //base class
 class Employee{
 	protected:
 	string name;
 	int id;
 	int sal_of_employee;
 	int no_of_working_hours , per_hour_sal;
 	public:
 	void setname(string n){
 			name=n;
		 }
		
	
		 void setid(int i){
		 	id=i;
		 }
		
		 void setno_of_working_hours(int h){
		 	no_of_working_hours=h;
		 }
		 
		 void setper_hour_sal(int s){
		 	per_hour_sal=s;
		 }
		 
 };
 //derived class
 class  Adhoc_employee: public Employee{
 	public:
 	
 		int getsalary(){
 			
 			
			 return (no_of_working_hours*per_hour_sal);
		 }
 		int getdisplay_info(){
 			cout<<"Enter name of employee:"<<name<<endl;
 			cout<<"Entetr id of employee:"<<id<<endl;
 			cout<<"Enter no of working hour of employee:"<<no_of_working_hours<<endl;
 			cout<<"Enter per hour salary of employee:"<<per_hour_sal<<endl;
 		
 				cout<<"Total salary of employee is: "<<getsalary()<<endl;
 	
 		
	 }
 };
 int main(){
 	Adhoc_employee AEMP;
 	AEMP.setno_of_working_hours(12);
 	AEMP.setper_hour_sal(200);
 		cout<<"Total salary of employee is: "<<AEMP.getsalary()<<endl;
 		cout<<"Information about employee:"<<endl;
 		cout<<endl;
 	AEMP.setname("Zainab");
 	AEMP.setid(45);
 	
 	
 AEMP.getdisplay_info();
 	
 }


