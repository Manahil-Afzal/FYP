/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
 using namespace std;
 
 class employee{
 	protected:
 		string name;
 		string id;
 		int working_hours;
 		int perhour_salary;
 		
 	public:
 		void setName(string n){
 			name = n;
		 }
		 
 		void setId(string i){
 			id=i;
		 }
		 
 		void setWorking_hours(int w){
 			 working_hours = w;
		 }
		 
 		void setPerhour_salary(int p){
 			perhour_salary = p;
		 }
 };
 
 class Adhoc_employee: public employee{
 	public:
 	int getMonthly_salary(){
 			return working_hours * perhour_salary;
	 };
 	 	string displayname(){
 		return name;

		 };
		 string displayid(){
 		 return id;
		 };
 		
 		int displayhours(){
		return working_hours;

	 };
	  		int displayperhour(){

 		return perhour_salary;
	 };
 	
 }; 
 
 
 main(){
	Adhoc_employee emp;
	emp.setWorking_hours(70);
	 emp.setPerhour_salary(500);
	 emp.setName("abdullah Tanveer");
	 emp.setId("bsf2000532");
	 
	 
	 
	 cout<<"Employee's details: "<<endl;
	 cout<<"Name: "<<emp.displayname()<<endl;
	 cout<<"ID: "<<emp.displayid()<<endl;
	 cout<<"Working Hours: "<<emp.displayhours()<<endl;
	 cout<<"Per Hour Salary: "<<emp.displayperhour()<<endl<<endl;
	 
	 cout<<"employee's Monthly salary: "<<emp.getMonthly_salary();
 }