/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee{
    protected:
    string name;
    int id;
    int workhour;
    int hoursalary;
    public:
    void setname(string n){
        name=n;
    }
    void set_id(int d){
        id=d;
    }
    void setWorkHour(int h){
        workhour=h;
        
    }
    void sethoursalary(int s)
{ hoursalary=s;
}
    
};
class Adhoc_employee:public Employee{
    public:
    void getInfo(){
        cout<<"name of employee:"<<name<<endl;
        cout<<"Id of employee: "<<id<<endl;
        cout<<"work hour: "<<workhour<<endl;
    }
    int salary(){
        int sal;
        sal=workhour*hoursalary;
        cout<<sal;
    }
};
int main(){
    Adhoc_employee ep1;
    ep1.setname("ayesha");
    ep1.set_id(2);
    ep1.setWorkHour(34);
    ep1.sethoursalary(5600);
    cout<<"inf of employee: ";
    ep1.getInfo();
    cout<<"salary of employee:";
    ep1.salary();
    return 0;
}
