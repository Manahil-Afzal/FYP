// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include<iostream>
using namespace std;
class Employee
{
  int Id;
  char name[25];
  int Age;
 long Salary;
public:
    Employee getdata()           
              {
                    cout<<"\n\tEnter Employee Id : ";
                    cin>>Id;

                    cout<<"\n\tEnter Employee Name : ";
                    cin>>name;

                    cout<<"\n\tEnter Employee Age : ";
                    cin>>Age;

                    cout<<"\n\tEnter Employee Salary : ";
                    cin>>Salary;
              }

            Employee putdata()           
              {
                    cout<<"\n"<<Id<<"\t"<<name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


       int main()
       {

              Employee E;           
              int i=0;
              for(i=0;i<=5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee";
                    E.getdata();
              }

              cout<<"\nDetails of Employees";
              for(i=0;i<=5;i++)
              E.putdata();

       }
