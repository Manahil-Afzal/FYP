// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include<iostream>
using namespace std;

       class Employee
       {      private:
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              Employee getdata()           
              {
                    cout<<"Enter Employee Id : "<<endl;
                   cin>>Id;

                    cout<<"Enter Employee Name : "<<endl;
                    cin>>name;
                    

                    cout<<"Enter Employee Age : "<<endl;
                    cin>>Age;

                    cout<<"Enter Employee Salary : "<<endl;
                    cin>>Salary;
              }

             Employee putdata()           
              {
                    cout<<"\n" <<"your ID: "<<Id<<"\n"<<"your name: "<<name<<"\n"<<"your age: "<<Age<<"\n"<<"your salary: "<<Salary<<endl;
              }

       };


       int main()
       {

              Employee E;           

              for(int i=0; i<5; i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee"<<endl;
                    E.getdata();
                   
              }
              for(int i=0; i<5; i++)
              {
              	cout<<"\n details you entered: "<<endl;
              	E.putdata();
			  }
              

       }
