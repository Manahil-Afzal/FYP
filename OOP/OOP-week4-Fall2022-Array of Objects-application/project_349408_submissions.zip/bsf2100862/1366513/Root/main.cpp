/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/

#include <iostream>
using namespace std;
class Std{
    public:
    char name[10];
    float marks;
};
int main ()
{
    float h;
    Std st[5];
    for(int i=0; i<5; i++)
    {
		cout << "Student " << i + 1 << endl;
		cout << "Enter name" << endl;
		cin >> st[i].name;
		cout << "Enter marks" << endl;
		cin>>st[i].marks;
	}
	for( int i=0; i<5; i++)
	if (st[0].marks < st[i].marks)
	st[0].marks=st[i].marks;
	cout << "Heighest marks scored : " << st[0].marks << endl;
    return 0;
}
