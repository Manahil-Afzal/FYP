/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
#include<string>
using namespace std;
class student{
      public:
    string name;
    int id;
    float marks,CGPA;
  
    void getdata(){
        cout<<"Enter the student name:"<<endl;
        cin>>name;
        cout<<"Enter the student id: "<<endl;
        cin>>id;
        cout<<"Enter the student marks:"<<endl;
        cin>>marks;
        cout<<"Enter student CGPA: "<<endl;
        cin>>CGPA;
    }
    void putdata(){
        cout<<"Student name is:"<<name<<endl
        <<"Student id is:"<<id<<endl
        <<"Student marks are:"<<marks<<endl
        <<"Student CGPA is:"<<CGPA<<endl;
    }
};
int main(){
    int i;
    student s[8];
    for(i=0;i<8;i++){
        cout<<"Enter details of student "<<i+1<<":"<<endl;
        s[i].getdata();
    }
    cout<<"\nDetail of students:";
    for(i=0;i<8;i++){
        s[i].putdata();
    }
     for(i=0;i<8;i++){
         if(s[0].marks<=s[i].marks){
             s[0].marks=s[i].marks;
         }
     }
     cout<<"Highest marks are:"<<s[0].marks;
}