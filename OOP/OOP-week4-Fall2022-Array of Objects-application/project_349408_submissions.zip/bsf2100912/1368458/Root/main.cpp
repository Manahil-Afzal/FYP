/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;
class student{
  public:	
    char name[25];
    int Id;
    int marks;
    float CGPA;
     void getdata(){
         cout<<"Enter student's name:";
         cin>>name;
         cout<<"Enter student's ID:";
         cin>>Id;
         cout<<"Enter student's marks:";
         cin>>marks;
         cout<<"Enter student's CGPA:";
         cin>>CGPA;}
     void putdata(){
     	
         cout<<"\n"<<name<<"\t"<< Id<<"\t"<<marks<<"\t"<<CGPA;
     }  
};
int main(){
    student S[8];
    cout<<"\tEnter the detail of students \n";
        for(int i=0;i<8;i++){
        cout<<"Enter the details of student "<<i+1<<endl;
        S[i].getdata();}
        cout<<"\nDetails";
        cout<<"\n"<<"Name"<<"\t"<< "ID"<<"\t"<<"Marks"<<"\t"<<"CCGPA";
        for(int i=0;i<8;i++){
        S[i].putdata();}
        int max=S[0].marks;
        int n=0;
        for(int i=1;i<8;i++){
        	if(max<S[i].marks){
        	max=S[i].marks;
			n=i;}
		}
		cout<<"\nThe details of student who took highest marks: \n";
		S[n].putdata();
    
}