/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
#include<string>
using namespace std;
class  student{
    public:
    string stdName;
    int stdId;
    int stdMarks;
    float stdCGPA;
    void setDetails(){
        cout << "Enter name  of student:" << endl;
        cin >> stdName;
        cout << "Enter Id of student:" << endl;
        cin >> stdId;
        cout << "Enter marks of student:" << endl;
        cin >> stdMarks;
        cout << "Enter CGPA of student:" << endl;
        cin >> stdCGPA;
       
    }
    void getDetails(){
        cout << "The name of student is : " << stdName << endl;
        cout << "The Id of student is : " << stdId << endl;
        cout << "The marks of student are : " << stdMarks << endl;
        cout << "The CGPA of student is : " << stdCGPA << endl;
        
    }
};
int main(){
    int i;
    student std[8];
for(int i = 0 ; i < 8 ; i++){
      cout << "Enter details of student " << i + 1 << endl;
      std[i].setDetails();
     
  }
 

	for(i=0;i<8;i++){
	
if(std[i].stdMarks > std[0].stdMarks){

std[0].stdMarks=std[i].stdMarks;
}
}
cout<<"THe highest Marks are : " << std[0].stdMarks << endl;
cout << "The details about that student who get highest marks are  : "<< endl;
std[0].getDetails();
}