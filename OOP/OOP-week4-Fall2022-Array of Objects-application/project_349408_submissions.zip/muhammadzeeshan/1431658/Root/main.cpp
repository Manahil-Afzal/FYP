/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/

#include <iostream>
using namespace std;
 
#define MAX 10
 
class student
{
    private:
        string  name;
        int   rollNo;
        int   total;
        float cgpa;
    public:
        void getDetails(void);
        void putDetails(void);
};
 
void student::getDetails(void){
    cout << "Enter name: " ;
    cin >> name;
    cout << "Enter roll number: ";
    cin >> rollNo;
    cout << "Enter total marks outof 500: ";
    cin >> total;
    cout<<"Enter your CGPA out of 4: "<<endl;
    cin>> cgpa;
}
 
void student::putDetails(void){
    cout << "Student details: \n";
    cout << "Name: "<< name << ", Roll Number: " << rollNo << ", Total: " << total << ", CGPA: " << cgpa;
}
 
int main()
{
    student std[MAX];       
    int loop;
     
    cout << "Please enter the details of 8 students: "<<endl;
     
    for(loop=0;loop< 2; loop++){
        cout << "Enter details of student " << loop+1 << ":\n";
        std[loop].getDetails();
    }
     
    cout << endl;
     
    for(loop=0;loop< 2; loop++){
        cout << "\nDetails of student " << loop+1 << ":\n";
        std[loop].putDetails();
    }

    return 0;
}