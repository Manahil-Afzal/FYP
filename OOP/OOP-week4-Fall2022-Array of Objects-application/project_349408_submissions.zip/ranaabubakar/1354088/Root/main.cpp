/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
 #include<iostream>
 using namespace std;
 class Student
 {
     private:
     	 int id;
         int rno;
         char name[20];
         float  cgpa;
         float avgmarks;
     public:
         void read_data();
         void print_data();
 };
 void Student::read_data()
 {
 	 cout<<"Enter the student_id. ";
     cin>>id;
     cout<<"Enter the roll no. ";
     cin>>rno;
     cout<<"Enter name. ";
     cin>>name;
     cout<<"Enter Average Marks. ";
     cin>>avgmarks;
     cout<<"Enter cgpa. ";
     cin>>cgpa;
 }
 void Student::print_data()
 {
     cout<<rno<<"\t"<<name<<"\t"<<avgmarks<<endl;
 }
 int main()
 {
     Student std[8];
     for (int i=0;i<3;i++)
     {
         std[i].read_data();
     }
     cout<<"Student Information is"<<endl;
     cout<<"RNo\tName\tAvg Marks"<<endl;
     for (int i=0;i<3;i++)
     {
         std[i].print_data();
     }
     return 0;
 }