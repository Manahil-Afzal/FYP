/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;
class student
{
	private: 
	char name[10];
	int id, marks;
	public:
		
		void getdata()
		{
		cout<<"Student Name: ";
		cin>>name;
		cout<< "student id: ";
		cin>>id;
		cout<<"Marks: ";
		cin>>marks;
	}
	void displaydata()
	{
		cout<<name<<"\n"<<id<<"\t"<<marks<<endl;
		
	}
	
	int getmarks(){
		return marks;
	}
};

int main()

{

    student std[10];
    int i, n;
    int max=0;
 
    for(i=0;i< 10; ++i){
        cout << "Enter details of student " << i+1 << ":\n";
        std[i].getdata();
    }
     
    cout << endl;
     
    for(i=0;i< 10; ++i){
        cout << "Details of student " << (i+1) << ":\n";
        std[i].displaydata();
    }
    for(int i=1; i<10; ++i)
    {
    	if (std[0].getmarks() < std[i].getmarks())
    	max=std[i].getmarks();
	}
	cout<<"Maximum Marks="<<max;
    
    return 0;
}