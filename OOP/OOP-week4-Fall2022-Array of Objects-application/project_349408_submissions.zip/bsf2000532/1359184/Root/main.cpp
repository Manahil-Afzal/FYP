/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/

#include<iostream>
using namespace std;

class STUDENT
{
	private:
    char name[25];
    string id;
    float marks;
    float cgpa;

    public:
    void GetData()           
    {
        cout<<"Enter student's Name: ";
        cin>>name;
        cout<<"Enter student's Id: ";
        cin>>id;
        cout<<"Enter student's marks: ";
        cin>>marks;
        cout<<"Enter student's CGPA: ";
        cin>>cgpa;
    }


    static void find_highest_marks_student(STUDENT array[],int size)
    {
        STUDENT temp;
        for(int a=1; a<size; a++)
        {
            if(array[0].cgpa<array[a].cgpa)
            {
                temp=array[0];
                array[0]=array[a];
                array[a]=temp;
            }
        }
        display_employee_data(array[0]);
    }

    static void display_employee_data(STUDENT temp)
    {        
        cout<<endl<<endl<<endl;
        cout<<"**************Highest Marks Student's Details**************"<<endl;
        cout<<"Name="<<temp.name<<endl;
        cout<<"ID="<<temp.id<<endl;
        cout<<"Marks="<<temp.marks<<endl;
        cout<<"CGPA="<<temp.cgpa<<endl;
    }

};


int main()
{
    STUDENT student[8];
    for(int a=0; a<8; a++)
    {
        cout<<"Detail of student '"<<a+1<<"'"<<endl;
        student[a].GetData();
    }
    
    STUDENT temprary_array[8];
    for(int a=0; a<8; a++)
    {
        temprary_array[a]=student[a];
    }      
    STUDENT::find_highest_marks_student(temprary_array,8);
}
