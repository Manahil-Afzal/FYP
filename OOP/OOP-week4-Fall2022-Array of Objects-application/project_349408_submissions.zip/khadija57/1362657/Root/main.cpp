/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;
class Student{
    int id;
    int marks;
    float CGPA;
    char name[20];
public:
void getdata(){
    cout<<"Enter Student Name:";
    cin>>name;
    cout<<"Enter Student ID:";
    cin>>id;
    cout<<"Enter Student Marks:";
    cin>>marks;
    cout<<"Enter Student CGPA:";
    cin>>CGPA;
}
void putdata(){
    cout<<name<<"end1"<<id<<"end1"<<marks<<"end1"<<CGPA;
}
};

int main()
{
    int i;
    Student S[8];
    for (i=0;i<=8;i++)
    {
        cout<<"Enter Details of Student" <<i+1<<endl;
        S[i].getdata();
    }
    cout<<"Detail Of Student"<<"end1";
    for(i=0;i<=8;i++)
    S[i].putdata();
}
