/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;

class Student{
 
 private:
 string name;
 string id;
 int marks;
 float cgpa;
 
 public:
 
 	Student(string name="",string id="",int marks=0,float cgpa=0){
 		
 		this->name = name;
 		this->id = id;
 		this->marks = marks;
 		this->cgpa = cgpa;
	 }
        
		void takeInput(){
			
		cout<<"Enter Student Name :";
		cin>>name;
		cout<<"\nEnter student Id :";
		cin>>id;
		cout<<"\nEnter Student Marks :";
		cin>>marks;
		cout<<"\nEnter Studnt CGPA :";
		cin>>cgpa;
		
				}      
				
				void getStudentData(){
					
					cout<<"Name : " <<name<<"\n";
					cout<<"Id : " <<id<<"\n";
					cout<<"Marks : "<<marks<<"\n";
					cout<<"CGPA : "<<cgpa<<"\n";
				}
				
				Student getStudentWithHighestMarks(Student students[],int size){
					
					int highestMarks = 0;
					int index= 0;
					for(int i=0; i<size; i++){
					if(highestMarks < students[i].marks){
							highestMarks = students[i].marks;
							index = i;
						}
			   	}   
			
			  return students[index];
				}
				
				};
				
				int main(){
					
					int n = 8;
					Student students[n];
					Student highestMarks;
						for(int i=0; i<n; i++){
							students[i].takeInput();
						}
					
					highestMarks = highestMarks.getStudentWithHighestMarks(students,n);
					cout<<"\n\nStudent with highest Marks : \n\n\n";
					highestMarks.getStudentData();
				
					return 0;
					
				};