/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
#include<string>
using namespace std;
class student
{
    private:
    string name;
    string Id;
    int marks;
    float CGPA;
    public:
    void getdata()
    {
        cout<<"Enter student name:";
        cin>> name;
         cout<<"Enter student Id:";
         cin>> Id;
          cout<<"Enter student marks:";
         cin>> marks;
          cout<<"Enter student CGPA:";
           cin>>CGPA;
    }
    void putdata()
    {
         cout<<" "<<name<<endl;
         cout<<" "<<Id<<endl;
         cout<<" "<<marks<<endl;
         cout<<" "<<CGPA<<endl;
        
    }
    
};
int main()
{
    int i;
    student st[8];
    for(int i=0;i<8;i++)
    {
        cout<<"Enter details of"<<i+1<<"student";
        st[i].getdata();
        
    }
    
      st[i].putdata();
    return 0;
}