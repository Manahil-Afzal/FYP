/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
# include<iostream>
using namespace std;
class student{
   public:
    string name;
    int id;
    float marks;
    float cgpa;
    void getdata(){
        
         cout<<"enter the id of student"<<endl;
        cin>>id;
         cout<<"enter the name of student"<<endl;
        cin>>name;
        cout<<"enter the cgpa of student"<<endl;
        cin>>cgpa;
        cout<<"enter the marks of student"<<endl;
        cin>>marks;}
   void putdata(){
       cout<<" "<<id<<endl;
  cout<<" "<<name<<endl;
  cout<<" "<<cgpa<<endl;
       cout<<" "<<marks<<endl;
   }
        
};
int main()
{
    int i;
    student arr[2];
    for(int i=0;i<2;i++){
        cout<<"enter dwtails of"<<i+1<<"student"<<endl;
        arr[i].getdata();
    }
    
   
    for(int i=0;i<2;i++)
    {
        if(arr[0].marks<=arr[i].marks){
            arr[0]=arr[i];
        }}
    cout<<"the details of student who acheive highest marks"<<endl;
    
   cout<<arr[0].marks;
   arr[0].putdata();
        }
        
    
    


