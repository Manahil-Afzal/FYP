/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;

class Student{
	private:
		char name[30];
		int id;
		int marks;
		int cgpa;
	
	public:
		void get_Data()
		{
			cout << "Enter your name : ";
			cin >> name;
			cout << endl << "Enter your id : ";
			cin >> id;
			cout << endl << "Enter your marks : ";
			cin >> marks;
		}
		int calc()
		{
			return cgpa = (marks/500) * 100;
		}
		void putData()
		{
			cout << "Student with highest marks : " << endl;
			cout << "Name : " << name << endl;
			cout << "Id : " << id << endl;
			cout << "Marks : " << marks << endl;
		}
};

int main()
{
	Student s[3];
	int high;
	for(int i=0; i<3; i++)
	{
		cout << "Student : " << i+1 << endl;
		s[i].get_Data();
	}
	for(int i=0; i<2; i++)
	{
//		cout << s[i].calc() << endl;
//		cout << s[i].calc() << endl;
		if(s[i].calc() > s[i+1].calc())
			high = i;
		else
			high = i+1;
	}
	s[high].putData();
}