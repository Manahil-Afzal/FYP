/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;
class student{
    public:
    int id;
    char name[25];
    int marks;
    float cgpa;

  void  getdata(){
      cout<<"enter the name:"<<endl;
      cin>>name;
      cout<<"enter the id:"<<endl;
      cin>>id;
      cout<<"enter the marks:"<<endl;
      cin>>marks;
         cout<<"enter the cgpa:"<<endl;
      cin>>cgpa;
  } 
  void putdata(){
      cout<<name<<endl<<id<<endl<<marks<<endl<<cgpa<<endl;
      
  }
  
    
};
 int main(){
     student child[3];
     int i;
     for( i=0;i<3;i++){
         cout<<"enter the details of  student:"<<i+1<<endl;
         child[i].getdata();
     }
       for(int i=0;i<3;i++){
         cout<<" details of student with highest marks:"<<i+1<<endl;
         child[i].putdata();
     }
     	for(i=0;i<3;i++){
	
if(child[0].marks<child[i].marks){

child[0]=child[i];
}
cout<<"THe highest is=";
cout<<child[0].marks;
}
     
 }