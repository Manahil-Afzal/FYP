/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
#include<string>
using namespace std;

class student{
	public:
    string name;
    int id;
    int marks;
    float CGPA;
   void getdata(){
       cout<<"\n\t Enter the Student name:";
       cin>>name;
       cout<<"\n\t enter student id:";
       cin>>id;
       cout<<"\n\t Enter your marks:";
       cin>>marks;
       cout<<"\n\t Enter your CGPA:";
       cin>>CGPA;
     
   }
    void putdata(){
        cout<<"\n"<<name<<"\n"<<id<<"\n"<<marks<<"\n"<<CGPA;
    }
};
int main(){
    int i;
    student s[8];
	for(i=0;i<8;i++)
	                 {
                    cout<<"\nEnter details of "<<i+1<<" student";
                    s[i].getdata();
              }
cout<<"\nDetails of atudent";
              for(i=0;i<8;i++){
			  
              s[i].putdata();

       }

 

	for(i=0;i<8;i++){
	
if(s[0].marks<=s[i].marks){

s[0]=s[i];
}
}
cout<<"THe highest is=";
cout<<s[0].marks;
}
