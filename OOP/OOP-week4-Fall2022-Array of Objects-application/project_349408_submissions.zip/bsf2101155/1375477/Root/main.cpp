/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;

class student
{
	private:
		char  name[30];
		int   Id;
		int   marks;
		float CGPA;
	public:
		
		void STD_getDetails();
		void STD_putDetails();
};


void student::STD_getDetails(){
	cout << "Enter your name: " ;
	cin >> name;
	cout << "Enter your Id: ";
	cin >> Id;
	cout << "Enter total marks out of 500: ";
	cin >> marks;
	
	CGPA=(float)marks/500*100;
}


void student::STD_putDetails(){
	cout << "Student details:\n";
	cout << "Name:"<< name << ",ID:" << Id << ",Total Marks:" << marks << ",CGPA:" << CGPA;
}

int main()
{
	student std;	
	
	std.STD_getDetails();
	std.STD_putDetails();
	
	return 0;
}
