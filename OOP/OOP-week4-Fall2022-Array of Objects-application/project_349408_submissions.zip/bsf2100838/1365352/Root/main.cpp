/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;

class student{
	public:
	string name;
	string id;
	int marks;
	float CGPA;
	
 
int getdata(){
		cout<<"enter your name:";
     cin>>name;
	cout<<"enter your id:";
	cin>>id;
	cout<<"enter your marks:";
	cin>>marks;
	cout<<"enter your CGPA:";
	cin>>CGPA;
}
int putdata(){
		cout<<"your name:"<<name;
	cout<<endl;
	cout<<"your id:"<<id;
	cout<<endl;
	cout<<"your marks:"<<marks;
	cout<<endl;
	cout<<"your CGPA:"<<CGPA <<"\n";
}

	
};



int main (){
	
	student st[8];
	for(int i=0;i<8;i++){
		cout<<"	Enter detail of student"<<i+1<<endl;
		st[i].getdata();
	}
	
	
	for(int i=0;i<8;i++){
		st[i].putdata();
	}
	
	cout<<"\n\n\n\_____________________"<<endl;
	cout<<"Student of highest marks"<<endl;
	
	
	int m;
	int highest;
	highest= st[0].marks;
	for(int i=0;i<8;i++){
		
		if (highest<st[i].marks)
		{
			highest=st[i].marks;
			m=i;
		
		}
		
		
	}
	
     st[m].putdata();
	
}
	
	