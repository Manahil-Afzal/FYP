/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;

class Student{
    public:
    string name;
    int id;
    float marks;
    float cgpa;
   
    public:
    void set_data()
    {
        cout<<"Enter the name of student"<<endl;
        cin>>name;
        cout<<"Enter the student id"<<endl;
        cin>>id;
        cout<<"Enter student marks"<<endl;
        cin>>marks;
        cout<<"Enter student CGPA"<<endl;
        cin>>cgpa;
    }
    void get_data()
    {
        cout<<" Name of student = "<<name<<endl;
         cout<<" Student id = "<<id<<endl;
            cout<<"Student marks = "<<marks<<endl;
               cout<<"Student CGPA = "<<cgpa<<endl;
    }
    Student gethighest(Student st[],int size)
    {
        int index=0;
        int highestmarks=0;
        for(int i=0;i<size;i++)
        {
            if(highestmarks<st[i].marks)
            highestmarks=st[i].marks;
            index=i;
            
        }
        return st[index];
    }
};
int main()
{
    int n=8;
    Student st[n];
    Student highestmarks;
    for(int i=0;i<8;i++)
    {
        st[i];
        st[i].set_data();
    }
     for(int i=0;i<8;i++)
    {
        st[i];
        st[i].get_data();
    }
highestmarks=highestmarks.gethighest(st,n);
cout<<"Student with highest marks "<<endl;
highestmarks.get_data();

}