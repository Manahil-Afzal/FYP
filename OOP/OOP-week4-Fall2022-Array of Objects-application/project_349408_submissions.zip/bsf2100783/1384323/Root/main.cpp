/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
#include<string>
using namespace std;
class studentDetails {
private:
    string studentName;
    string id;
    float marks,CGPA;
    
public:

    void takedata();
    void displaydata();
    float getMarks();
    

};
void studentDetails::takedata() {
    cout << "Enter student name : ";
    getline(cin,studentName);
    cout << "Enter Student Id : ";
    cin >> id;
    cout << "Enter Student Marks : ";
    cin >> marks;
    cout << "Enter Student CGPA : ";
    cin >> CGPA;
    cin.ignore();
}
float studentDetails :: getMarks()
{
    return marks;
}

void studentDetails::displaydata() {
    cout << "Student name is "<<studentName<<endl;
    cout<<studentName<< " obtained highest marks : " <<endl;
    cout << studentName << " Id is ";
    cout<< id<<endl;
    cout << studentName<<" marks is  ";
    cout << marks<<endl;
    cout << studentName<<" CGPA is ";
    cout << CGPA<<endl;
}

int main() {
    studentDetails std[8];
    
    for (int i = 0; i < 8; i++) {
        cout << i+1<<")";
        std[i].takedata();
    }
    
    int max = std[0].getMarks();
    int index=0;
    for (int i = 0; i < 8; i++) {
        if (max < std[i].getMarks()) {
            max = std[i].getMarks();
            index = i;
        }
    }
    std[index].displaydata();
}
