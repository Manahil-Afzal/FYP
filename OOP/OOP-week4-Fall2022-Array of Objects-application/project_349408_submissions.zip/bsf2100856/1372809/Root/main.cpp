/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
#include<string>
 using namespace std;

class student{
    public:
    string name;
    int id;
    float marks,CGPA;
      void getdata(){
        cout<<"Enter Student name: "<<endl;
        cin>>name;
        cout<<"Enter Student ID: "<<endl;
        cin>>id;
        cout<<"Enter Student marks: "<<endl;
        cin>>marks;
        cout<<"Enter Student CGPA: "<<endl;
        cin>>CGPA;
    }
    void putdata(){
        cout<<"\n"<<"Student name is: "<<name
        <<"\n"<<"Student ID is: "<<id
        <<"\n"<<"Student marks are: "<<marks
        <<"\n"<<"Student CGPA is: "<<CGPA<<endl;
   }
   };
    
    int main(){
        int i;
        student s[8];
        for(i=0;i<8;i++)
        
        {
            cout<<"\nEnter details of student "<<i+1<<":"<<endl;
            s[i].getdata();
        }
        cout<<"\nDetails of student:";
        for(i=0;i<8;i++)
        {
            s[i].putdata();
        }
        for(i=0;i<8;i++)
        {
            if (s[0].marks<=s[i].marks){
                s[0].marks=s[i].marks;
            }
    }
    cout<<"\nThe Highest marks are: "<<s[0].marks;
    }