/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/

#include<iostream>
using namespace std;
const char* findGrade(float [], int);
int main()
{
    int i,Id;
	int roll_no, n;
	int marks;
    string name;
    float mark[6];
    for(int j=0;j<=8;j++){
	cout<<"---------------------------------------------"<<"\n";
     cout<<"Enter ID of Student: ";
    cin>>Id;
     cout<<"Enter Name of Student: ";
    cin>>name;
     cout<<"Enter Roll_no of Student: ";
    cin>>roll_no;
     cout<<"Enter Marks of Student Subjects (max. 6): ";
    cin>>n;
    cout<<"Enter Number of subjects obtained marks are: "<<n<<" Subjects: ";
    for(i=0; i<n; i++)
        cin>>mark[i];
    cout<<"\nGrade = "<<findGrade(mark, n);
    cout<<endl;
}
}
const char* findGrade(float mark[], int n)
{
    int i;
    string name;
    float sum=0, avg;
    for(i=0; i<n; i++)
        sum = sum+mark[i];
    avg = sum/n;
    cout<<"Total Marks:"<<avg<<"\n";
    if(avg>=91 && avg<=100){
	
        return "4.00 CGPA";}
    else if(avg>=81 && avg<91)
        return "3.8 CGPA";
    else if(avg>=71 && avg<81)
        return "3.5 CGPA";
    else if(avg>=61 && avg<71)
        return "3.00 CGPA";
    else if(avg>=51 && avg<61)
        return "2.5 CGPA";
    else if(avg>=41 && avg<51)
        return "2.2 CGPA";
    else if(avg>=33 && avg<41)
        return "2.0 CGPA";
    else if(avg>=21 && avg<33)
        return "F ";
    else if(avg>=0 && avg<21)
        return "F";
    else
        return "Invalid!";
    
           
        
}

