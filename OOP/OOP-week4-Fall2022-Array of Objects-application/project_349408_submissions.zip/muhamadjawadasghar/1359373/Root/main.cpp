/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/


#include <iostream>
using namespace std;

class student {
string name;
int marks;
long id;
float cgpa;
public:
void getName()
{
cin >> name;
}
void getId()
{
cin >> id;
}
void getMarks()
{
cin >> marks;
}
void getcgpa()
{
cin >> cgpa;
}
void displayinfo()
{
cout<<"Name :"<< name << endl;
cout<<"ID :"<<id << endl;
cout<<"Marks :"<< marks << endl;
cout<<"CGPA:"<< cgpa << endl;
}
int takemarks(){
return marks;
}
};
int main()
{
int largest=0;

student st[4];
for( int i=0;i<4;i++)
{
cout<<"Student"<<i+1<<endl;
cout<<"Enter name"<<endl;
st[i].getName();
cout<<"Enter ID"<<endl;
st[i].getId();
cout<<"Enter Marks"<<endl;
st[i].getMarks();
cout<<"Enter cgpa"<<endl;
st[i].getcgpa();

}
for( int i=0;i<8;i++)
{
cout<<"Student"<<i+1<<endl;
st[i].displayinfo();
}

for (int i=1; i<8; i++)
{
if (st[largest].takemarks()<st[i].takemarks())
largest=i;
}
cout<<largest<<endl;
cout<<"The Highest marks of the is given by"<<endl;
st[largest].displayinfo();
return 0;
}