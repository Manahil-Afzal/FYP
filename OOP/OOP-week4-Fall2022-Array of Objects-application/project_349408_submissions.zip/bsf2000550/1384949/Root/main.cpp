#include<iostream>
#include<string>
using namespace std;
class student
{
	private: 
	string name;
	int id, marks;
	public:
		void getdata()
		{
		cout<<"Student Name: ";
		cin>>name;
		cout<< "student id: ";
		cin>>id;
		cout<<"Marks: ";
		cin>>marks;
	}
	void displaydata()
	{
		cout<<name<<"\n"<<id<<"\t"<<marks<<endl;
	}
	int getmarks(){
		return marks;}
};
int main()
{
    student std[8];
    int i, n;
    int max=0;
  //  cout << "Enter total number of students: ";
   // cin >> n;
    for(i=0;i< 8; ++i){
        cout << "Enter details of student " << i+1 << ":\n";
        std[i].getdata();
    }
    cout << endl;
    for(i=0;i< 8; ++i){
        cout << "Details of student " << (i+1) << ":\n";
        std[i].displaydata();
    }
    for(int i=1; i<8; ++i)
    {
    	if (std[0].getmarks() < std[i].getmarks())
    	max=std[i].getmarks();
	}
	cout<<"Maximum Marks="<<max;
    return 0;
}