/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;
class student{
	public:
		string name;
		int id;
	    float marks;
		float cgpa;
		void in(){
			cout<<"Name:";
	        cin>>name;
			cout<<"Id:";
			cin>>id;
			cout<<"Marks:";
			cin>>marks;
			cout<<"Cgpa:";
			cin>>cgpa;
		}
		void display(){
		cout<<"NAME:"<<name<<"\t";
		cout<<"ID:"<<id<<"\t";
		cout<<"MARKS:"<<marks<<"\t";
		cout<<"CGPA:"<<cgpa<<"\t\n";
		}
		
};
int main (){
	student std[8];
	cout<<"Enter details of students:\n";
	for(int i=0;i<8;i++){
		cout<<"student:"<<i+1<<"details:\n";
		std[i].in();
	}
	cout<<"\n display details of students:\n";
	for(int i=0;i<8;i++){
		cout<<"("<<i+1<<")";
	  std[i].display();
	}
	int b,a=std[0].marks,count=1;
	for(int j=1;j<8;j++){
		if(a<std[j].marks)
		{
		b=j;	
		}
	}
		cout<<"\n\n student with the highest marks detail is:\n";

	std[b].display();


}


