/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;

class Student{
	public:
		string name;
		string id;
		float marks;
		float cgpa;
		
	int getdata(){
		cout<<"\nEnter your name: ";
   		cin>>name;
		cout<<"Enter your id: ";
		cin>>id;
		cout<<"Enter your marks: ";
		cin>>marks;
		cout<<"Enter your CGPA: ";
		cin>>cgpa;
	}

	int putdata(){
		cout<<"\nThe student's name is: "<<name<<endl;
		cout<<"The student's ID is: "<<id<<endl;
		cout<<"The student's marks are: "<<marks<<endl;
		cout<<"The student's CGPA is: "<<cgpa;
	}
};

int main(){
	
	Student st[8];
	for(int i=0; i<8; i++){
		cout<<"\nEnter details of student "<<i+1<<":";
		st[i].getdata();
	}
	
	cout<<"\nDetails of student with highest marks:";
	
	int m;
	int highest;
	
	highest= st[0].marks;
	
	for(int i=0; i<8; i++){
		if (highest<st[i].marks){
			highest=st[i].marks;
			m=i;
		}
	}
	
	st[m].putdata();
	return 0;
}