/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;
class student{
	private:
		char name[100];
		int id;
		float CGPA;

		
    public:
    	int mark;
    	int input(){
    		
        cout<<"enter your name:"<<endl;
         cin>>name;
    	cout <<"enter your id:"<<endl;
        cin>> id;
        cout << "enter your CGPA: "<<endl;
        cin>>CGPA;
        cout <<"enter your marks: "<<endl;
        cin>>mark;
       
       

		}
		
		int display(){
			
	    
        cout <<"your name: "<<name<<endl;
        cout <<"your id: "<<id<<endl;
        cout <<"your CGPA: "<<CGPA<<endl;
        cout<<"your mark: "<<mark<<endl;
        
    }
};
    int main(){
    	student s[8];
    	for(int i=0; i<8; i++){
    		cout<<"student    "<<i+1<<endl;
    		s[i].input();

		}
		    cout<< "details of what you entered: "<<endl;
	    	for(int i=0; i<8; i++){
    		cout<<"student  "<<i+1<<endl;
    		s[i].display();
    		
    	} 
    	   for(int j=1; j<8; j++){
    	if (s[0].mark<s[j].mark)
	 s[0]=s[j];
	}
	
	cout << "student who get highest mark is  "<< s[0].mark<<endl;
	s[0].display();
	return 0;
}