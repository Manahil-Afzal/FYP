/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;
class student{
    public:
    string name;
    int id;
    int marks;
    float Cgpa;
   
    void input(){
        cout<<"enter the name"<<endl;
        cin>>name;
        cout<<"enter the id";
        cin>>id;
         cout<<"enter the marks out of 600";
        cin>>marks;
         cout<<"enter the CGPA";
        cin>>Cgpa;
    
    }

    
    void output(){
        cout<<"ID:"<<id<<endl;
         cout<<"Name:"<<name<<endl;
          cout<<"Marks:"<<marks<<endl;
           cout<<"CGPA:"<<Cgpa<<endl;
        
    }
        
    
    
};
int main(){
    student Detail[8];
    for(int i=0; i<8; i++){
        cout<<i+1<<":Enter Detail"<<endl;
        Detail[i].input();
        
        
    }
    for(int i=0; i<8; i++){
        cout<<i+1<<":Student Detail"<<endl;
        Detail[i].output();
        
        
        
    }
    int m ;
    int high=Detail[0].marks;
    for(int i=0;i<8;i++){
        if(high<Detail[i].marks){
            high=Detail[i].marks;
            m=i;
        }
    }
    cout<<"\n\n\n_______________________"<<endl;
    cout<<"student with high marks is:"<<endl;
    Detail[m].output();
    
        
    }
    

    

    
