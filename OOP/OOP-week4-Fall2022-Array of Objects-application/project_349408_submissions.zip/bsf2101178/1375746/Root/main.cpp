/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/


 #include<iostream>
 using namespace std;
 
 class Student{
 	public:
 	string name;
 	string id;
 	float marks;
 	float cgpa;
 	public:
 		void GetDetails() {
 			cout<<"Enter Student Name: "<<endl;
 			cin>>name;
 			cout<<"Enter Student id: "<<endl;
 			cin>>id;
 			cout<<"Enter Student marks: "<<endl;
 			cin>>marks;
 			cout<<"Enter Student CGPA: "<<endl;
 			cin>>cgpa;
		 }
		 void PutData() {
		 	cout<<"\n"<<"Student Name:"<<name<<"\t"<<"Student Id:"<<id<<"\n"<<"Student Marks:"<<marks
			 <<"\n"<<"Student CGPA"<<cgpa<<"\n";
		 }
 };
 
 int main() {
 	Student data[8];
 	
 	
 	for(int i=0; i<8; i++) {
 		cout<<"Enter details of "<<i+1<<"Student"<<endl;
 		data[i].GetDetails();
	 }
	 
	 cout<<"\t \t \t"<<"Details of Students"<<endl;
	 for(int i=0; i<8; i++) {
	 	data[i].PutData();
	 }
	 
	 int max;
	 int highest = data[0].marks;
	 
	 for(int i=1; i<8; i++){
	 	
	 	if(highest<data[i].marks){
	 		highest = data[i].marks;
	 		 max = i;
		 }
	 }
	 
	 cout<<"\t \t \t \t \t \t"<<"Details of Highest Marks Student:"<<endl;
	 data[max].PutData();
	 return 0;
 }