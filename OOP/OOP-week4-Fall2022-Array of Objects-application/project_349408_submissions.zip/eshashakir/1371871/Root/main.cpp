/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/

#include<iostream>
using namespace std;

class Student{ 
	char Name[25];
	int Id;
	int Marks;
	float Cgpa;
public:
void GetData() 
{
cout<<"\nEnter Student Name : ";
cin>>Name;
cout<<"\nEnter Student ID: ";
cin>>Id;
cout<<"\nEnter Student Marks: ";
cin>>Marks;
cout<<"\nEnter Student CGPA: ";
cin>>Cgpa;
}
void PutData() {
cout<<"\n"<<Name<<"\t"<<Id<<"\t"<<Marks<<"\t"<<Cgpa;
}

};

int main()
{
int i;
Student E[8];
for(i=0;i<8;i++)//for loop
{
cout<<"\nEnter details of "<<i+1<<" Student : ";
E[i].GetData();
}
cout<<"\nDetails of Students";
cout<<"\nName"<<"\tID"<<"\tMarks"<<"\tCGPA";
for(i=0;i<8;i++)
E[i].PutData();
}