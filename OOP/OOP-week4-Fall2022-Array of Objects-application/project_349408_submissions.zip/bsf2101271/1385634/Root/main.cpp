/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include <iostream>
using namespace std;
class Std{
    public:
    char name[10];
    int id;
    float marks;
    float CGPA;
};
int main ()
{
    float hm;
    Std st[8];
    for(int i=0; i<8; i++)
    {
		cout << "Student " << i + 1 << endl;
		cout << "Enter name" << endl;
		cin >> st[i].name;
		cout << "Enter id" << endl;
		cin >> st[i].id;
		cout << "Enter marks" << endl;
		cin>>st[i].marks;
		cout << "Enter CGPA" << endl;
		cin>>st[i].CGPA;;
	}
	for( int i=0; i<8; i++)
	if (st[0].marks < st[i].marks)
	st[0].marks=st[i].marks;
	cout << "Heighest marks scored : " << st[0].marks << endl;
    return 0;
}
