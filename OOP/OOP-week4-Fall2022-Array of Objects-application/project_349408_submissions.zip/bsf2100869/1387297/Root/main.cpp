/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
using namespace std;
class  student{
	public:
	string name;
	int id;
	float marks;
	float cgpa;
	
	void getdata()
	{		cout<<"\tenter name of student: ";
			cin>>name;
			cout<<"\tenter id of student: ";
			cin>>id;
			cout<<"\tenter marks of student: ";
			cin>>marks;
			cout<<"\tenter cgpa of student: ";
			cin>>cgpa;
			
	}	
	void putdata()
	{	cout<<"\tName: "<<name<<endl;
		cout<<"\tId: "<<id<<endl;
		cout<<"\tMarks: "<<marks<<endl;
		cout<<"\tCgpa: "<<cgpa<<endl;
	}	
};
int main()
{	student  stu[8];
	for(int i=0;i<8;i++)
		{	cout<<"\tSTUDENT no: "<<i+1<<endl;
			stu[i].getdata();
		}
		
		int a;
		int b=stu[0].marks;
		for(int i=1;i<8;i++)
		{	
		
			if(b<stu[i].marks){
				b=stu[i].marks;
				a=i;
			}
		
		}
		cout<<"highest marks : "<<endl;
		stu[a].putdata();
	return 0;
}