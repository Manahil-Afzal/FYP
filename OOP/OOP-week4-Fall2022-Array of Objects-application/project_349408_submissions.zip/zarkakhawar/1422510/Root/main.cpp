/* Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students.*/
#include<iostream>
#include<string>
using namespace std;
class student
{
    public:
    string name;
    int id;
    int marks;
    void getdata(){cout<<"enter student name"<<endl;
    cin>>name;
    cout<<"enter student id"<<endl;
    cin>>id;
    cout<<"enter student marks"<<endl;
    cin>>marks;
}
void putdata(){
    cout<<endl<<name<<endl<<id<<endl<<marks<<endl;
}
};
int main()
{
    int i;
    student s[8];
    for(i=0;i<8;i++)
    {
        cout<<"enter details of "<<i+1<<"student"<<endl;
        s[i].getdata();
    }
    cout<<"details of student";
    for(i=0;i<8;++i)
    {
        if(s[0].marks<s[i].marks)
        s[0]=s[i];
    }
    cout<<"Student with the highest marks ";s[0].putdata();
    return 0;
}
        

    
    
    
    
    