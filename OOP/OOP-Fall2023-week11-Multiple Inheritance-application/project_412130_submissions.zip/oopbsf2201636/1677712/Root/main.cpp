/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include <iostream>
#include <string>
using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class IT
class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class CS
class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class SOS_Course with multiple inheritance from IT and CS
class SOS_Course : public IT, public CS {
public:
    void display() {
        // Access the IT and CS functionality through their methods
        IT::display();
        CS::display();
    }
};

int main() {
    SOS_Course sosCourse;

    // Input course ID using IT class
    sosCourse.IT::input();

    // Display course ID using SOS_Course class
    sosCourse.display();

    return 0;
}

