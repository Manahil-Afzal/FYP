/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;

class Course
{
protected:
    int ID;
public:
    void input()
    {
        cout<<"Enter course ID (Int): ";
        cin>>ID;
    }
};

class CS : public Course
{
public:
    void display()
    {
        cout << "Course ID (CS): " << ID << endl;
    }
};

class IT : public Course
{
public:
    void display()
    {
        cout << "Course ID (IT): " << ID << endl;
    }
};

class SOS_Course : public IT, public CS
{
public:
    void displaySOS()
    {
        cout << "Course ID (SOS_Course): " << 23 << endl;
    }
};

int main()
{
    SOS_Course sosCourse;
    
    sosCourse.displaySOS();
    return 0;
}
