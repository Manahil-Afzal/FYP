/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course
{
    protected:
    string courseId;
    public:
    void input(){
        cout<<"enter the course id";
        cin>>courseId;
    }
    };
    class IT : virtual public course{
        public:
        void display(){
            cout<<"IT course id:";
            cin>>courseId;
    }
    };
    class CS : virtual public course{
        public:
        void display(){
            cout<<"CS course id:";
            cin>>courseId;
    }
    };
    class SOS_course : public IT,public CS{
        public:
        void display(){
            IT::display();
            CS::display(); 
        }
        };
        int main(){
            SOS_course sosCourse;
            sosCourse.input();
             sosCourse.display();
        }
        