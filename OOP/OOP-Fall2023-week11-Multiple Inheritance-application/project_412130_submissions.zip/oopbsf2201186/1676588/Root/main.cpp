#include <iostream>
#include <string>

using namespace std;

// Base class: Course
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class: IT
class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class: CS
class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class: SOS_Course (inherits from both IT and CS)
class SOS_Course : public IT, public CS {
public:
    // Display method overridden to avoid ambiguity
    void display() {
        // Call display method of the base class explicitly
        IT::display();
    }
};

int main() {
    // Declare an object of SOS_Course
    SOS_Course sosCourse;

    // Input course ID for SOS_Course
    sosCourse.IT::input(); // Specify the input method from the IT class

    // Display the course ID for SOS_Course
    sosCourse.display();

    return 0;
}

