/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/


#include <iostream>
using namespace std;

class Course {
protected:
    int id;

public:
    void input(int i) {
        cout << "Enter course id: ";
        cin >> id;
    }
};

class CS {
public:
    int display(int d);
};

class SOS_Course {
protected:
    int id;

public:
    void input(int id) {
        cout << "Enter the Course id: ";
        cin >> id;
    }
};

class IT {
protected:
    int id;

public:
    void input(int id) {
        cout << "Enter the Course id: ";
        cin >> id;
    }
};

class Course1 : public IT, public CS {
public:
    void displayInfo() {
        cout << "Display info " << id << endl;
    }
};

class S0s_Course : public IT, public CS {
public:
    void displayInfo() {
        cout << "Display Info " << id << endl;
    }
};

int main() {
    Course1 obj1;
    obj1.input(123);
    obj1.displayInfo();

    S0s_Course obj2;
    obj2.input(456);
    obj2.displayInfo();

    return 0;
}