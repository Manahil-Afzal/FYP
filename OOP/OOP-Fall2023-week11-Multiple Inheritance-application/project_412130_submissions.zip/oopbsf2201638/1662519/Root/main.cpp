/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;

class course {
	protected:
		int  id;
		public:
			void input(){
				cout<<"Enter the Course id"<<endl;
				cin>>id;
			}
		void display(){
			cout<<"The course id = "<<id<<endl;
		}	
			
};

class IT: virtual public course{
	
};
class CS: virtual public course{
		
};

class SOS_course :  public IT, public CS{
	
};
int main(){
	SOS_course a1;
	a1.input();
    a1.display();
}