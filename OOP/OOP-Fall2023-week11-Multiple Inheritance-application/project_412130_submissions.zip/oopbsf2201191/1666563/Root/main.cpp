/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user.
Each child class in the hierarchy implements a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Course{
	protected:
		string course_ID;
	public:
		void input(){
			cout << "Enter the course ID: " << endl;
			cin >> course_ID;
		}
};

class IT :virtual public  Course{
	public:
	    void display1(){
			cout << "course ID of IT: " << course_ID << endl;
		}
};

class CS :virtual public Course{
	public:
		void display2(){
			cout << "course ID of CS: " << course_ID << endl;
		}
};

class SOS_Course:public IT,CS{
	public:
		void display3(){
			cout << "course ID: " << course_ID << endl;
		}
};

int main()
{
	SOS_Course obj;
	obj.input();
	obj.display3();
}
