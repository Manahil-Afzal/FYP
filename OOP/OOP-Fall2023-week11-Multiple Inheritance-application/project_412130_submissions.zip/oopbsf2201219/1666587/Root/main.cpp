/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT 
and CS. Course class has an attribute course Id and an input() method that takes input of course Id 
from user. Each child class in the hierarchy implements a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;

class Course
{
	protected:
		string course_Id;
	public:
		virtual void getcourse_Id()
		{
			cout<<"Enter course ID:";
			cin>>course_Id;
		}
};

class IT : virtual public Course
{
	public:
		void showcourse_Id1()
		{
			cout<<"Course ID:"<<course_Id<<endl;
		}
};


class CS : virtual public Course
{
	public:
		void showcourse_Id2()
		{
			cout<<"Course ID:"<<course_Id<<endl;
		}
};


class SOS_Course : public IT, public CS 
{
	public:
		void showcourse_Id3()
		{
			cout<<"Course ID:"<<course_Id<<endl;
		}
};


int main()
{
	SOS_Course obj1;
	obj1.getcourse_Id();
	obj1.showcourse_Id3();
	
	return 0;
}