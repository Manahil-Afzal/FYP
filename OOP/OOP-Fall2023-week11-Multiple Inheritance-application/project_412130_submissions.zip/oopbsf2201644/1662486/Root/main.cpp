/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

// Base class: Course
class Course {
protected:
    int courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class: IT
class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class: CS
class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class: SOS_Course (Inherited from IT and CS)
class SOS_Course : public IT, public CS {
public:
    void displaySOSCourseId() {
        cout << "SOS Course ID (from IT): ";
        IT::display(); // Displays IT Course ID
        cout << "SOS Course ID (from CS): ";
        CS::display(); // Displays CS Course ID
    }
};

int main() {
    SOS_Course sosCourse;

    // Input Course IDs
    sosCourse.IT::input(); // Input IT course ID
    sosCourse.CS::input(); // Input CS course ID

    // Display Course IDs
    cout << "Displaying SOS Course IDs:\n";
    sosCourse.displaySOSCourseId(); // Display SOS Course ID

    return 0;
}
