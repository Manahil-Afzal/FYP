/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

class Course {
protected:
    int courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

class SOS_Course : public IT, public CS {
public:
    // Resolve the ambiguity by explicitly calling input() of IT
    void inputSOS() {
        IT::input();
    }

    // Since both IT and CS have display methods, we need to resolve the ambiguity
    // by explicitly specifying which display method we want to use.
    void display() {
        // Display the IT course ID
        IT::display();
        // Display the CS course ID
        CS::display();
    }
};

int main() {
    SOS_Course sosCourse;

    // Input course ID for SOS_Course using the inputSOS method
    sosCourse.inputSOS();

    // Display course ID for SOS_Course
    sosCourse.display();

    return 0;
}
