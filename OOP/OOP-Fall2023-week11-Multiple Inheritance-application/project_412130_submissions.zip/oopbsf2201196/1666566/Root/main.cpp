/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user.
Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;

class course{
public:
            string ID;

        void input()
{
    cout<<"enter course id: ";
    cin>>ID;
}
};

class IT:virtual public course
{
public:
    void displayinputmethod()
{    
    cout<<"Enter user id: "<<ID<<endl;
        
    }
    
};

class CS :virtual public course
{ 
public:
     void displayinputmethod()
     {
         cout<<"Enter user id: "<<ID<<endl;
     }
    
};


class SOS_Course : public IT, public CS
{
public:
  
     void displayinputmethod()
     {
        IT::displayinputmethod();
        CS::displayinputmethod();
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input();
    sosCourse.displayinputmethod();
}