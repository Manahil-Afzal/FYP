/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

class Course {
public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }

    void display() {
        cout << "Course ID: " << courseId << endl;
    }

protected:
    int courseId;
};

class IT : virtual public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : virtual public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID: " << courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input(); // Input the Course ID for SOS_Course
    cout << "Displaying SOS Course Information:" << endl;
    sosCourse.display(); // Display the Course ID for SOS_Course

    return 0;
}
