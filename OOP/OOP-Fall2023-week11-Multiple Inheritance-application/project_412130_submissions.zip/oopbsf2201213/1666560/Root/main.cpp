/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Course{
    protected:
    string id;
    public:
    void input(){
        cout<<"Enter Course_id "<<endl;
         cin>>id;
    }
    };
class IT:public  virtual Course {
    public:
     void display(){
           cout<<"Your cours_id is "<<id<<endl;
} 
};
class CS : public virtual Course{
    public:
     void display(){
           cout<<"Your cours_id is "<<id<<endl;
} 
};
class SOS_course:public IT,public CS{
    public:
     void display(){
           cout<<"Your cours_id is "<<id<<endl;
} 
};
int main (){
    SOS_course user1;
    user1.input();
    user1.display();
    
}