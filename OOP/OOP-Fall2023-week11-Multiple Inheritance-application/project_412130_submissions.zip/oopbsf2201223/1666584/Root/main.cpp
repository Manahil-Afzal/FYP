/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;

class Course {
    int Cid;
public:
    Course(int x) : Cid(x) {
        cout << "Course constructor called" << endl;
    }
    void input() {
        cout << "Enter Course ID: ";
        cin >> Cid;
    }
    void display() {
        cout << "Course ID: " << Cid << endl;
    }
};

class IT : virtual public Course {
public:
    IT(int x) :  Course(x) {
        cout << "IT constructor called" << endl;
    }
    void display() {
        Course::display();
    }
};

class CS : virtual public Course {
public:
    CS(int x) : Course(x) {
        cout << "CS constructor called" << endl;
    }
    void display() {
        Course::display();
    }
};

class SOS_Course : public IT, public CS {
public:
    SOS_Course(int x) : IT(x), CS(x),Course(x) {
        cout << "SOS Course constructor called" << endl;
    }
    void display() {
        Course::display();
    }
};

int main() {
    SOS_Course sc1(123); // Replace '123' with the desired course ID
    sc1.display(); // Display the course ID set by the user
    return 0;
}