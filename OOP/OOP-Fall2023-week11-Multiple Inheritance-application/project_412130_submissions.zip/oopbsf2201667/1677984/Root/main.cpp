/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/


#include <iostream>
using namespace std;

class Course {
protected:
    int id;

public:
    void getdata() {
        cout << "Enter Course id: ";
        cin >> id;
    }
};

class IT : public Course {
public:
    void showdata() {
        cout << "IT Course id = " << id << endl;
    }
};

class CS : public Course {
public:
    void showdata() {
        cout << "CS Course id = " << id << endl;
    }
};

class SOS_Course : public IT, public CS {
public:
    SOS_Course(){};

    void showdata() {
        IT::showdata();
        CS::showdata();
    }
};

int main() {
    Course c1;
    SOS_Course s1;
    c1.getdata();
    s1.showdata();

    return 0;
}
