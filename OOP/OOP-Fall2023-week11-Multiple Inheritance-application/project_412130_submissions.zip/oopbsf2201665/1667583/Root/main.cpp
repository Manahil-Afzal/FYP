#include <iostream>
using namespace std;

// Base class with virtual inheritance
class Course {
protected:
    int courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class IT inheriting virtually from Course
class IT : virtual public Course {
public:
    // Display method to show IT course ID
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class CS inheriting virtually from Course
class CS : virtual public Course {
public:
    // Display method to show CS course ID
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class SOS_Course inheriting from IT and CS
class SOS_Course : public IT, public CS {
public:
    // Override display method in SOS_Course to resolve ambiguity
    void display() {
        // Use the scope resolution operator to specify the courseId from the Course class
        cout << "SOS_Course ID: " << Course::courseId << endl;
    }
};

int main() {
    // Declare an object of SOS_Course
    SOS_Course mySOS_Course;

    // Take input for course ID
    mySOS_Course.input();

    // Display the course ID set by the user
    mySOS_Course.display();

    return 0;
}
