/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;

class course {
protected:
    string id;

public:
    virtual void takeinput() {
        cout << "Enter course id:";
        cin >> id;
    }
};

class IT : virtual public course {
public:
    void display() {
        cout << "Course id:" << id << endl;
    }
};

class CS : virtual public course {
public:
    void display1() {
        cout << "Course id:" << id << endl;
    }
};

class SOS_course : public IT, public CS {
public:
    void display2() {
        cout << "Course id:" << id << endl;
    }
};

int main() {
    SOS_course obj;
    obj.IT::takeinput();  // Specify the base class for takeinput
    obj.display();
    obj.display1();
    obj.display2();
    return 0;
}
