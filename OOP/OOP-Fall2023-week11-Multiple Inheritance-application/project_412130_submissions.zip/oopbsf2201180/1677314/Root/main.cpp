/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
#include <string>

class Course {
protected:
    std::string courseId;

public:
    void input() {
        std::cout << "Enter Course ID: ";
        std::cin >> courseId;
    }
};

class IT : virtual  public Course {
public:
    void display() {
        std::cout << "IT Course ID: " << courseId << std::endl;
    }
};

class CS : virtual  public Course {
public:
    void display() {
        std::cout << "CS Course ID: " << courseId << std::endl;
    }
};

class SOS_Course : public IT, public CS {
public:
    // Overriding the display method to avoid ambiguity
    void display() {
        IT::display(); // Call IT's display method
        CS::display(); // Call CS's display method
        std::cout << "SOS Course ID: " << courseId << std::endl;
    }
};

int main() {
    // Declare an object of SOS_Course
    SOS_Course sosCourse;

    // Input the course ID
    sosCourse.input();

    // Display the course ID set by the user
    sosCourse.display();

    return 0;
}
