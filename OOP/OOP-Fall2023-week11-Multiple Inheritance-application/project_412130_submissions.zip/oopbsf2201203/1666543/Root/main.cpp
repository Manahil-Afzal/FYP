/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;

class course{
	protected:
		string ID;
	public:
		void input(){
			cout<<"Enter your course ID: "<<endl;
			cin>>ID;
		}
//			void display(){
//			cout<<"Your your IT course id is : " <<ID;
//		}
		
};

class IT : virtual public course{
	public:

		void display(){
			cout<<"Your your IT course id is : " <<ID<<endl;
		}
};

class CS : virtual public course{
	public:

		void display(){
			cout<<"Your your CS course id is : " <<ID;
		}
};


class SOS_course :  public IT,  public CS{
	public:
		void input(){
			course::input();
		}
		void display(){
			IT::display();
			CS::display();
		}
};

main(){
	SOS_course s1;
	s1.input();
	s1.display();
}