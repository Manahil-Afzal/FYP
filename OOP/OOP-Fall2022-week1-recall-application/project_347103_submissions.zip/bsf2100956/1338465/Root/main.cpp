/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include <iostream>
using namespace std;

void input(int arr[],int size){
    cout<<"Enter the 20 integers"<<endl;
    for(int i=0;i<20;i++){
        cin>>arr[i];
    }
}
void processing(int arr[],int size){
    int odd_count=0,even_count=0;
    for(int i=0;i<20;i++){
        if(arr[i]%2==0){
            even_count++;
        }
        if(arr[i]%2!=0){
            odd_count++;
        }
    }
    cout<<"Even numbers : "<<even_count<<endl;
     cout<<"Odd numbers : "<<odd_count<<endl;
}

int main(){
    int arr[20];
    input(arr,20);
    processing(arr,20);

    return 0;
}
