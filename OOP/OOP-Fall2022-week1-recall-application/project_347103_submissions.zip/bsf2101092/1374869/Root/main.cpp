/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;
void input(int arr[20])
{
    cout<<"enter an array"<<endl;
    for(int i=0;i<20;i++)
    {
        cin>>arr[i];
    }
}
void process(int arr[20]){
    int odd=0;
    int even=0;
    for(int i=0;i<20;i++)
    {
        if(arr[i]%2==0)
        {
            odd++;
        }
        else if(arr[i]%2!=0)
        {
           
            even++;
        }
    }
        cout<<"odd numbers are"<<odd<<endl;
         cout<<"even numbers are"<<even<<endl;
        
    }
    int main()
    {
        int arr[20];
        input(arr);
        process(arr);
         return 0;
}

