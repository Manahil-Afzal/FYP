/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include <iostream>
using namespace std;
int main()
{
    int arr[20];
    int i,odd=0,even=0;
    for(i=0; i<20; i++)
    {
        cout<<"Enter Integer"<<"/n";
        cin>>arr[i];
    }
    {
        if(arr[i]%2==0)
        {
            even=even+1;
        }
        else{
            odd=odd+1;
        }
        }
        cout<<"Total Even Num Of Array:"<<even<<"/n";
        cout<<"Total Odd Num Of Array:"<<odd<<"/n";
    
}
