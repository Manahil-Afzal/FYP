/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

int* input()
{
    int num[20];
    cout<<"Input 20 integers"<<endl;
    for(int a=0; a<20; a++)
    {
        cout<<a+1<<". number=";
        cin>>num[a];
    }
    return num;
}

void display(int array[],int size)
{
    int reminder,odd_number[20],odd_index=0,even_number[20],even_index=0;
    for(int a=0; a<size; a++)
    {
        reminder=array[a]%2;
        if(reminder==0)
        {
            even_number[even_index]=array[a];
            even_index++;
        }
        else
        {
            odd_number[odd_index]=array[a];
            odd_index++;
        }
    }
	
	cout<<endl<<endl<<endl;
    cout<<"Display Even integers"<<endl<<endl<<endl;
    for(int a=0; a<even_index; a++)
    {
        cout<<a+1<<". number="<<even_number[a]<<endl;
    }   

	cout<<endl<<endl<<endl;
    cout<<"Display Odd integers"<<endl<<endl;
    for(int a=0; a<odd_index; a++)
    {
        cout<<a+1<<". number="<<odd_number[a]<<endl;
    }   

}

int main()
{
    int number[20];
    int* temp_array=input();
    for(int a=0; a<20; a++)
    {
        number[a]=temp_array[a];
    }
    display(number,20);
}