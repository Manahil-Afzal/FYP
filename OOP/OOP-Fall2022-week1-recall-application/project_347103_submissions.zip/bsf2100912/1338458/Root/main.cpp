/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include <iostream>
using namespace std;
void input(int arr[20]){
    for(int i=0;i<20;i++){
        cout<<"Enter integer"<<i+1<<":";
        cin>>arr[i];
    }
}
void processing(int arr[20]){
    int even=0,odd=0;
    for(int i=0;i<20;i++){
        if(arr[i]%2==0)
           even+=1;
        else
           odd+=1;
    }
    cout<<"No. of even numbers is:"<<even<<endl;
    cout<<"No. of odd numbers is:"<<odd<<endl;
}
int main(){
    cout<<"\tEnter 20 numbers\n";
    int arr[20];
    input(arr);
    processing(arr);
    return 0;
}