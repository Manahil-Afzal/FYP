/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;


int arr[20];


void my_input(){
	for(int i=0; i<20; i++){
		cout<<"Enter value "<<i<<":";
		cin>>arr[i];
	}
};


int my_output(){
	int i=0;
	int odd = 0;
	int even = 0;
	while(i<20){
	
		if(arr[i] % 2 == 0 ){
			even ++;
		}
		else{
		
			odd ++;
		}
		i++;
	}
	cout<<"Number of Even "<<even<<endl;
	cout<<"Number of Odd "<<odd;
}

int main(){
	my_input();
	my_output();
}