/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>

using namespace std;

int arr[20];
int input()
{
    
    cout<<"Enter 20 integer numbers"<<endl;
    for(int i=0; i<5; i++)
    {
    	cin>>arr[i];
    	cout<<"your entered number is :";
    	cout<<arr[i]<<endl;
	}
}
int processing()
{
	int even = 0;
	int odd = 0;
	for (int j=0; j<5; j++)
	{
		if(arr[j]&1==1)
		odd++;
		else
		even++;
	}
	cout<< "Number of odd values are :"<<odd<<endl;
	cout<< "Number of even values are :"<< even;
	
}
    
int main()

{
    input();
    processing();
}