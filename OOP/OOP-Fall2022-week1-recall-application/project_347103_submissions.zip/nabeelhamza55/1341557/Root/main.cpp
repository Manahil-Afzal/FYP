/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
int getdata(){
	int size, x=0, y=0;
    cout<<"Enter array size:   ";
    cin>>size;
    int arr[size];
    cout<<"******* Enter array Integers *******"<<endl;
	
    for(int i=0; i<size; i++)
    {
		cout<<"Enter arr["<<i<<"] Integer: ";
		cin>>arr[i];
		if(arr[i]%2==0){
		    x++;
		}else{
		   y++;
		}
    }
    
    int even[x], odd[y];
    x=0, y=0;
  	for(int i=0; i<size; i++)
    {
       if(arr[i]%2==0){
            even[x]=arr[i];
            x++;
       }else{
           odd[y]=arr[i];
           y++;
       }
    }
 	cout<<"\nTotal even integers in Array are: "<<x<<endl;
  
  	cout<<"Total odd integers in Array are:  "<<y<<endl<<endl;
  
  	for (int i = 0; i < x; i++)
	{
	    cout<<"Even interger is: "<<even[i]<<", "<<endl;
	}
	for (int i = 0; i < y; i++)
	{
	    cout<<"odd interger is: "<<odd[i]<<", "<<endl;
	}
}
int main()
{
	getdata();
  	return 0;

}
  