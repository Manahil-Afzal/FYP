/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;
int myFunc(int arr[20]);
int processing();
int main()
{
    processing();
}
    int myFunc(int arr[20]){
    cout<<"enter number of arrays";
    for(int i=0;1<20;i++){
    
    cin>>arr[i];
    }}
    int processing()
    {
        int myArray[20];
        cout<<"enter number of arrays";
        for(int i=0;1<20;i++){
        cin>>myArray[i];
        }
        for(int i=0;i<20;i++){
        
        if(myArray[i]%2==0){
            cout<<"even numbers are"<<myArray[i]<<endl;
        }else{
            cout<<"odd numbers are"<<myArray[i]<<endl;
        }
        }
    }
    
