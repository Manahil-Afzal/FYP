/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

// Declaring the array global with size 20
int arr[20];

//Input function
void input_function (){
	for(int i=0; i<20; i++){
		cout<<"Enter the array value "<<i<<":";
		cin>>arr[i];
	}
};
int output_function (){
	int odd = 0;
	int even = 0;
	for (int i=0; i<20; i++){
		
		if(arr[i] % 2 == 0 ){
			even ++;
		}
		else{
		
			odd ++;
		}
	}
	cout<<" even number  in array are "<<even<<endl;
	cout<<" odd number in array are "<<odd;
}

int main(){
	input_function();
	output_function();
	
	return 0;
}