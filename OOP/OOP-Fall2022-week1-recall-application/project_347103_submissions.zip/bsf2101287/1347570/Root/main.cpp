/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;

void input(int arr[20]) {
    cout<<"Enter the array of 20 integers!"<<endl;
    for(int i  = 0; i < 20; i++) {
        cin>>arr[i];
    }
}

void process(int arr[20]) {
    int even_count = 0;
    int odd_count = 0;
    for(int i = 0; i < 20; i++) {
        if(i % 2 == 0) {
            even_count ++;
        }
        else
        odd_count ++;
    }
    cout<<"Even Numbers in the Array = "<<even_count<<endl;
    cout<<"Odd Numbers in the Array = "<<odd_count<<endl;

}


int main() {
    
    int arr[20];
    input(arr);
    process(arr);
}