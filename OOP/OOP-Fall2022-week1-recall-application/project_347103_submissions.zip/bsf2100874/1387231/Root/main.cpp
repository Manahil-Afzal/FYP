/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;

void input( int arr[20]){
	cout<<"Enter the arry"<<endl;
	for( int i=0; i<20; i++)
	{
		cin>>arr[i];
	}
}
void process( int arr[20]){
	int count_odd=0;
	int count_even=0;
	for(int i=0; i<20; i++){
		if(arr[i]%2==0){
			count_even++;
		} else if(arr[i]%2!=0){
			count_odd++;
		}
	}
	cout<<"Even num are:"<<count_even<<endl;
	cout<<"Odd num are:"<<count_odd;
}
int main(){
	int arr[20];
	input(arr);
	process(arr);
	
	
	return 0;
}