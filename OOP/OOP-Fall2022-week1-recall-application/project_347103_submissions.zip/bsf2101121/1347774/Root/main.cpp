/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
void input(int a[]);
void EvenOdd(int a[]);

int main()
{
int a[20];
int size=20;
input(a);
EvenOdd(a);
return 0;
}

void input(int a[20])
{
cout<<"Enter 20 integers";
for(int i=0;i<20;i++)
{
cin>>a[i];
}
}

void EvenOdd(int a[])
{
int even=0;
int odd=0;
for(int i=0;i<20;i++)
{
if(a[i]%2!=0)
 odd++;
else
 even++;
}
cout<<odd<<" integerss are odd"<<endl;
cout<<even<<"integerss are even"<<endl;
}
   



