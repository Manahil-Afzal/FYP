/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/


#include<iostream>
using namespace std;
void input(int arr[20]){
    cout<<"enter twenty numbers"<<endl;
    for(int i=0; i<20; i++){
        cin>>arr[i];
    }
}
 void processing(int arr[20]){
     int even_count=0;
     int odd_count=0;
     for(int i=0; i<20;i++){
          
          
         if(arr[i]%2==0){
             even_count++;
         } 
         else if(arr[i]%2 !=0){
             odd_count++;
         }
     }
     cout<<"odd number"<<odd_count<<endl;
      cout<<"even number"<<even_count<<endl;
 }
 int main(){
     int arr[20];
     input(arr);
     processing (arr);
     return 0;
 }
