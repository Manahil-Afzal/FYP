/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

// array of size 20
int arr[20];

//Input function
void input_function(){
	for(int i=0; i<20; i++){
		cout<<"Enter the values: "<<i<<":";
		cin>>arr[i];
	}
};

//output function
int output_function(){
	int i=0;
	int odd = 0;
	int even = 0;
	while(i<20){
		//Even values
		if(arr[i] % 2 == 0 ){
			even ++;
		}
		else{
			//For odd
			odd ++;
		}
		i++;
	}
	cout<<"Total even numbers in array:  "<<odd<<endl;
	cout<<"Total odd numbers in array:  "<<even;
}

int main(){
	input_function();
	output_function();
	
}