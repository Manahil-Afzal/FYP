/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include <iostream>
using namespace std;
int arr[20];
int process (int pr[20]);
int input(){
	for (int i=0; i<=20; i++){
		cout << "enter an integers: "<<i+1<<endl;
		cin>>arr[i];
	}
	
}
int process (int pr[]){
	
int even=0;
int odd=0;
for(int j=0; j<=20; j++){
	if (arr[j]%2==0)
	even++;
	else
	odd++;
}
cout <<" total number of even numbers are:"<<even<<endl;
cout << "total number of odd numbers are:"<< odd << endl;
}
int main (){
	int num[20];
	input ();
	process (num);
}
