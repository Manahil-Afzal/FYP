/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include <iostream>
using namespace std;

int *input() {
	static int arr[20];
	for (int i = 0; i < 20; i++) {
		cin >> arr[i];
	}
	return arr;
	}
	int processing(int *arr){
		{
			cout << "even numbers are : ";
			for (int i = 0; i < 20; i++)
			{
				if (arr[i] % 2 == 0)

					cout << arr[i] << " " ;
			}
			cout <<endl<< "odd numbers are : " ;
				for (int i = 0; i < 20; i++){

					if(arr[i]%2!=0)
					cout << arr[i] << " " ;
			}
			
		}
		return 0;
	}

	int main() {
        cout<<"enter numbers : " ;
		int *Array = input();
		processing(Array);

	}
