/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
int even_fun();
int odd_fun();

int main ()
{

	even_fun();
	odd_fun();
	
}

int even_fun()
{
   int arr[20];
   cout<<"loop elements"<<endl;
	for(int i=0;i<=20; i++)
	{
			cin>>arr[i];
	}
	
	cout<<"Even"<<endl;
    for (int i=0;i<=20;i++)
	    {
		if(arr[i]%2==0)
	    cout<<arr[i]<<endl;
		 		
		}
}
 
     int odd_fun()
{
	
	int arr[20];
	cout<<endl;
    cout<<"odd"<<endl;
	for(int i=0;i<20;i++)
	{
	
	if(arr[i]%2==1)
	cout<<arr[i]<<endl;
	}

}