/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

int array[20];

void my_input(){
	for(int a=0; a<20; a++){
		cout<<"Enter the array value "<<a<<":";
		cin>>array[a];
	}
};

int my_output(){
	int a=0;
	int odd=0;
	int even=0;
	while(a<=20){
		if(array[a] % 2 == 0 ){
			even ++;
		}
		else{
			odd ++;
		}
		a++;
	}
	cout<<"even number present in array "<<even<<endl;
	cout<<"odd number present in array "<<odd;
}

int main(){
	my_input();
	my_output();
	
	return 0;
}
