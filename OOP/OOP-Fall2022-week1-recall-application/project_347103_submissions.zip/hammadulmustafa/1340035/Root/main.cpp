/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;

int arr[19]; //Array Declare 
void input();  // Input Function Decleration
void process();	 // process Function Decleration

	
int main (){

	input();  //function Calling
	process(); //function Calling
	return 0;
}

	// Function Defination 
	void input(){
	for(int i=0; i<20; i++){
		cout<<"Please Enter "<<i<<"th Number: "; 
		cin>>arr[i];
	}
 } 
 
	// Function Defination
	void process(){
		for(int i=0; i<20; i++){
			if(arr[i]%2 == 0){
				cout<<"EVEN: "<<arr[i]<<endl;
			}
			else{
				cout<<"ODD: "<<arr[i]<<endl;
			}
		}
	}