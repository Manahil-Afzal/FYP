/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
void input(int arr[20])
{
 cout<<"input 20 integers";
 for(int i=0;i<20;i++){
 cin>>arr[i];
 }
}
 void processing(int arr[20])
 { 
 int even=0;
 int odd=0;
     for(int i=0;i<20;i++){
         if(arr[i]%2==0)
         {
             even++;
         }
        
		  else
        {
		 odd++;
         
         }
     
	 }
	 cout<<"enen numbers are:"<<even<<","<<endl;
	 cout<<"odd numbers are:"<<odd<<endl;}
         int main()
         {
         	int arr[20];
              input( arr);
             processing( arr);
            return 0;
     }