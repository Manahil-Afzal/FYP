/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array
and the processing function displays the number of even and odd 
numbers in that array*/
#include<iostream>
using namespace std;

// array declare.
int arr[20];
//Input function
void input(){
	for(int i=0; i<20; i++)
	{
		cout<<"Enter the array value "<<i<<":";
		cin>>arr[i];
	}
};
//output function
int output()
{
	int i=0;
	int odd = 0;
	int even = 0;
	while(i<=20)
	{
	  // display array elements
		if(arr[i] % 2 == 0 ){
			even ++;
		}
		else{
			odd ++;
		}
		i++;}
	cout<<"The number of even present in array is "<<even<<endl;
	cout<<"The number of odd present in array is "<<odd;
}
int main(){
	input();
	output();
	
	return 0;
}
