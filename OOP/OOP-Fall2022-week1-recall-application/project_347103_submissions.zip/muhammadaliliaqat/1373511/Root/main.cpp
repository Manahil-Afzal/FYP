/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;
int main()
{
    int cnt_even=0,cnt_odd=0;
    int arr[20];
    cout<<"Enter 20 numbers"<<endl;
    for(int i=0; i<20;i++){
        cin>>arr[i];
    }
    for(int i=0;i<20;i++){
        if (arr[i]%2==0)
        {
            cnt_even++;
         }
        else
        cnt_odd++;
    }
cout<<"Total number of even numbers="<<cnt_even<<endl;
cout<<"Total number of odd numbers="<<cnt_odd<<endl;
}





