/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include <iostream>

using namespace std;

void input(int n, int arr[]){
	
	for(int i=0; i<n; i++){
		cin>>arr[i];
	}
}

void processing(int n, int arr[]){
	int even = 0;
	int odd = 0;
	for(int i=0; i<n; i++){
		if(arr[i]%2 == 0){
			even++;
		}else{
			odd++;
		}
	}
	cout<<"Even numbers = "<<even<<"\n";
	cout<<"Odd number = "<<odd<<"\n";
}
int main(int argc, char** argv) {
	
	int n = 20;
	int arr[n];
	input(n,arr);
	processing(n,arr);
	return 0;
}