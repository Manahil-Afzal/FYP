/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
void processing();
void input();
int main()
{
    input();
    processing();
    return 0;
}
void input()
{
    int arr[20];
    int i,size=20;
    //input the array elements
    cout<<"\nEnter elements of array\n";
    for(i=0; i<20; i++ )
    {
        cout<<"Enter the element arr["<<i<<"] :";
        cin>>arr[i];//read input from the user for array elements
        
    }
}
void processing()
{
    int arr[20];
    int i, size=20,odd=0,even=0;
    for(i=0; i<20; i++)
    {
        if(arr[i]%2==0)
        {
            even++;
        }
    else
    {
        odd++;
    }
}
cout<<"\nTotal even numbers of an array :"<<even<<"\n";
cout<<"Total odd numbers of an array :"<<odd;

}
