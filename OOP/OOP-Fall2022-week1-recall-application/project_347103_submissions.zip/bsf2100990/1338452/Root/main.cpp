/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
int input(int array[],int size);
int processing(int array[],int size);
main ()
{
	int array[20];
	input(array,20);
}
int input(int array[],int size){
	for(int i=0;i<20;i++)
	{
		cout<<"enter number :"<<i+1<<":";
		cin>>array[i];
	}
	processing(array,size);
}
int processing(int array[],int size){
	int a=0,b=0;
	for(int i=0;i<20;i++){
		if(array[i]%2==0){
			a+=1;
		}
		else{
			b+=1;
		}
	}
	cout<<"the number of even  number is:"<<a;
	cout<<"\n the number of odd number is:"<<b;
}