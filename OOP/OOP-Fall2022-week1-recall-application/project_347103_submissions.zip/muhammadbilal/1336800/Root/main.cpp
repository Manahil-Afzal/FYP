/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

//Introducing Input Function

void input(int arr[])
{
    for (int i = 0; i<20; i++)
    cin>>arr[i]; //The program will ask to input 20 integers
}

//Introducing Processing Function

void processing(int arr[])
{
    int even = 0;
    int odd = 0;
    for (int i = 0; i<20; i++)
    {
        if (arr[i]%2 == 0)
        {
            even++;
        }
        else 
        {
            odd++;
        }
    }
    cout<<"Total Even numbers: "<<even<<endl;
    cout<<"Total Odd numbers: "<<odd<<endl;
}

int main()
{   cout<<"This program prints the count of even and odd numbers of 20 integers taken by the user. "<<endl;
    cout<<"Enter at least 20 integers: "<<endl;
    int arr[20];
    input (arr); //Calling Input Function
    processing (arr); //Calling Processing Function
    return 0;
}