/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
void input(int a[]);
void evenodd(int a[]);

int main()
{
    int a[20];
    int size=20;
    input(a);
    evenodd(a);
    return 0;
}

void input(int a[20])
{
    cout<<"enter 20 integars:";
    for(int i=0;i<20;i++)
    {
        cin>>a[i];
}
}

void evenodd(int a[])
{
    int even=0;
    int odd=0;
    for(int i=0;i<20;i++)
    {
        if(a[i]%2!=0)
        odd++;
        else
        even++;
    }
    cout<<odd<<"integars are odd"<<endl;
    cout<<even<<"integars are even"<<endl;
}