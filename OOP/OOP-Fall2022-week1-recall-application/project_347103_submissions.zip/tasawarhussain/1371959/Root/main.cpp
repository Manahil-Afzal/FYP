/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include <iostream>

using namespace std;

int input(int arr[]){
	
	for(int i=0; i<20; i++){
		cin>>arr[i];
	}
};

int processing(int arr[]){
	int even = 0;
	int odd = 0;
	for(int i=0; i<20; i++){
		if(arr[i]%2 == 0){
			even++;
		}else{
			odd++;
		}
	}
	cout<<"Even numbers = "<<even<<"\n";
	cout<<"Odd number = "<<odd<<"\n";
};
int main(){
	cout<<"Enter the numbers: ";
	int array[20];
	input(array);
	processing(array);
	return 0;
}
