/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
int arr[20];
void input (){
	for(int i=0; i<20; i++){
		cout<<"Enter the array value "<<i<<":";
		cin>>arr[i];
	}
};

int output (){
	int odd = 0;
	int even = 0;
	for (int i=0; i<=20; i++){
		if(arr[i] % 2 == 0 ){
			even ++;
		}
		else{
			odd ++;
		}
	}
	cout<<"The number of even present in array is "<<even<<endl;
	cout<<"The number of odd present in array is "<<odd;
}

int main(){
	input();
	output();
	
	return 0;
}