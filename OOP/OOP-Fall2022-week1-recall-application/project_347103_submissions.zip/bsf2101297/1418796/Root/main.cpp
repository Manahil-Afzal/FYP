/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;
int input(int arr[20]){
    cout<<"enter twenty integers="<<endl;
    
    for (int i=0;i<20;i++)
    cin>>arr[i];
}
    int processing(int arr [20]){
        int evenCount=0, oddCount=0;
        for (int i=0;i<20;i++)
        {
		
        if (arr[i]%2==0)
        evenCount++;
        else 
        oddCount++;
    }
        cout<<"even intgers="<<evenCount<<endl;
cout<<"odd intgers="<<oddCount<<endl;
    }

int main(){

int arr[20];
input(arr);
processing(arr);
return 0;
}

