/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
int num1();
int num2();
int main()
{
    int stored, display,arr[20];
    stored=num1();
    display=num2();
}
int num1()
{
    int stored;
    int arr[20];
    for(int i=0;i<20; i++)
    {
      cin>>arr[i];
    }
    return stored;
}
int num2()
{
    int display,a;
    int arr[20];
    for(int i=1;i<20; i++)
    {
   a=arr[i];
        if(a%2==0)
        {
            cout<<"even"<<arr[i]<<"\n";
        }
        else
        {
            cout<<"odd"<<arr[i]<<"\n";
        }

    }
    return display;
}