/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/


#include<iostream>
using namespace std;

int main()
{
   int arr[20],even[20],odd[20],i,j=0,k=0,size;

   cout<<"Enter array size:   ";
    cin>>size;
        cout<<"Enter array elements ";

        for(i=0; i<size; i++)
        {
            cout<<"Enter arr["<<i<<"] Element ";
                cin>>arr[i];
        }
   for(i=0; i<size;i++)
   {
   if(arr[i]%2==0)
   {
    even[j]=arr[i];
    j++;
   }
   else
   {
   odd[k]=arr[i];
   k++;
   }
   }
  cout<<"Even Elements in Array are: "<<j<<endl;
  
  cout<<"Odd Elements in Array are:  "<<k;
  return 0;

  }
