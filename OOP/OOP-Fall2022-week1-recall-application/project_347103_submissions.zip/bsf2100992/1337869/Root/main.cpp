/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include <iostream>
using namespace std;
int input_func();
int process_func();

int input_func(){
	int arr[20];
	cout<<"Enter the integers in array: "<<endl;
	for(int i=0; i<20; i++)
	{
		cin>>arr[i];
	}
}

int process_func(){
	int arr[20] , even=0 , odd=0;
	cout<<endl;
	cout<<"Even"<<endl;
	for(int i=0; i<20; i++)
	{
		if(arr[i]%2==0){
			even++;
		}
	}
	cout<<"Number of even integers: "<<even<<endl;
	
	cout<<endl;
	cout<<"Odd"<<endl;
	for(int i=0; i<20; i++)
	{
		if(arr[i]%2!=0){
			odd++;
		}
	}
	cout<<"Number of odd integers: "<<odd<<endl;
}

int main(){
	input_func();
	process_func();
}

