

#include<iostream>
using namespace std;
int main()
{
    int cnt_even=0,cnt_odd=0;
    int arr[20];
    cout<<"enter 20 numbers"<<endl;
    for(int i=0;i<20;i++){
        cin>>arr[i];
    }
    for(int i=0;i<20;i++){
        if(arr[i]%2==0)
        {
            cnt_even++;
        }
        else
        cnt_odd++;
        
    }
    cout<<"total number of even numbers = "<<cnt_even<<endl;
    cout<<"total number of odd numbers = "<<cnt_odd<<endl;
    
}
