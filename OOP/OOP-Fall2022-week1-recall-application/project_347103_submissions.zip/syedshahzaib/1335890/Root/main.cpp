/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
int main(){
	int arr[20],even[20],odd[20],evenn=0,oddn=0;
	cout<<"Enter first 20 integer numbers in the numberb are:"<<"\n";
	for(int i=0;i<20;i++)
	cin>>arr[i];
		for(int i=0;i<20;i++){
			if(arr[i]%2==0)
			even[evenn++]=arr[i];
			else
			odd[oddn++]=arr[i];
			
		}
		cout<<"The 1st 20 even numbers are:"<<"\n";
		 for(int i=0;i<evenn;i++)
		 cout<<even[i]<<" ";
		 cout<<"\n";
		 		cout<<"The 1st 20 odd numbers are:"<<"\n";
         for(int i=0;i<oddn;i++)
         cout<<odd[i]<<" ";
         return 0;
         
		 
}
