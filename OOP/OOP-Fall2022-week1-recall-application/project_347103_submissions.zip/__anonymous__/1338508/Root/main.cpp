/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include <iostream>
using namespace std;

void input(int array[]){
    cout<<"Enter 20 integers"<<endl;
    for (int i=0; i<20; i++){
        cin>>array[i];
    }
};
void processing(int array[]){
    int even=0, odd=0;
    for (int i=0; i<20; i++) {
        if (array[i]%2 == 0) 
            even++;
        else 
            odd++;
    }
    
    cout<<"Even numbers are: "<<even<<"\n";
    cout<<"Odd numbers are: "<<odd<<"\n";
};


int main() {
    int array[20];
    input(array);
    processing(array);
    return 0;
}
