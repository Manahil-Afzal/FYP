/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;
void input(int myArray[20]);//function declaration
void processing();//function declaration
int main(){
    int myArray[20];
    input(myArray);//function call
    processing();//function call
    return 0;
}
void input(int myArray[20])//function definition
{
    cout<<"enter the array elements"<<endl;
    for(int i=0;i<20;i++){
    cin>>myArray[i];}
   
    int even=0;
    int odd=0;
    
    for(int i=0;i<20;i++){
        if(myArray[i]%2==0){
            cout<<myArray[i]<<"is an even number"<<endl;
            even++;
        }else{
            cout<<myArray[i]<<"is an odd number"<<endl;
            odd++;
        }
}
}
void processing()//function definition
{
int even;
int odd;
   
    cout<<"number of even numbers are"<<even<<endl;
    cout<<"number of odd numbers are"<<odd<<endl;
}
