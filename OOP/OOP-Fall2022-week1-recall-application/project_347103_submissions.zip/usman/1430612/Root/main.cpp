/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/


#include<iostream>
using namespace std;
int main(){
    
	int arr[20];
	
	int even[20],odd[20];
	int e=0,o=0;
	cout<<"Enter  20 integer numbers"<<"\n";
	
	for(int i=0;i<20;i++)
	cin>>arr[i];
		for(int i=0;i<20;i++){
			if(arr[i]%2==0)
			even[e++]=arr[i];
			else
			odd[o++]=arr[i];
			cout<<endl;
			
		}
		cout<<"The  20 even numbers are"<<"\n";
		 for(int i=0;i<e;i++)
		 cout<<even[i]<<" ";
		 
		 		cout<<"The  20 odd numbers are"<<"\n";
         for(int i=0;i<o;i++)
         cout<<odd[i]<<" ";
         return 0;
}
