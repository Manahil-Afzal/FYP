/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

int array[20];

void input(){
	for(int i=0; i<20; i++){
		cout<<"Enter the array value "<<i<<":";
		cin>>array[i];
	}
};

int output(){
	int i=0,odd=0,even=0;
	while(i<=20){
		
		if(array[i] % 2 == 0 ){
			even ++;
		}
		else{
			odd ++;
		}
		i++;
	}
	cout<<"Even present in array is = "<<even<<endl;
	cout<<"Odd present in array is ="<<odd;
}

int main(){
	input();
	output();
	
	return 0;
}

