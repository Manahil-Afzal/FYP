/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include <iostream>
using namespace std;
void inputFunction(int arr[20]); // function1 declaration
void processing();                // function2 decalaration
int main()
{
    int arr[20];
    inputFunction(arr);       // function1 call
    processing();            // function2 call
    return 0;
}
void inputFunction(int arr[20]){ ; // function1 definition
    int i; 
    int even= 0;
    int odd= 0;
    cout << "Enter 20 numbers in an array" << endl;
    for(int i = 0; i < 20; i++){
        cin >> arr[i];
    }
    for(int i = 0; i < 20; i++){
    if(arr[i]%2==0){
        cout << arr[i] << " is an even number " << endl;
        even++;
    }
    else{
        cout << arr[i] << " is an odd  number " << endl;
        odd++;
    }
}
}
void processing(){            // function2 definition
    int odd ;
    int even;
    cout << "Number of even elements are " << even << endl;
    cout << "Number of odd elements are " << odd << endl;
}

