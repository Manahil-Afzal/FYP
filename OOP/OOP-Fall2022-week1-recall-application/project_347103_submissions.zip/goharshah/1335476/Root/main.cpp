/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;

int main()
{
   int arr[20],even[20],odd[20],a,b=0,c=0,size;

   cout<<"Enter array size:   ";
    cin>>size;
        cout<<"Enter array elements ";

        for(a=0; a<size; a++)
        {
            cout<<"Enter arr["<<a<<"] Element ";
                cin>>arr[a];
        }
   for(a=0; a<size;a++)
   {
   if(arr[a]%2==0)
   {
    even[b]=arr[a];
    b++;
   }
   else
   {
   odd[c]=arr[a];
   c++;
   }
   }
  cout<<"Even Elements in Array are: "<<b<<endl;
  
  cout<<"Odd Elements in Array are:  "<<c;
  return 0;

  }