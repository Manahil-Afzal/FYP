/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/

#include<iostream>
using namespace std;
void input()
{
	
	
		
	int  arr[20],i;
	cout<<"enter 20 array";
	for(i=0; i<20; i++)
	cin>>arr[i];
	

}
void processing()
{

		int arr[20], even=0, odd=0,i;
	
	for(i=0; i<20; i++)
	{
		if(arr[i]%2==0)
		even++;
		else
		odd++;
	}
	cout<<"total no off even="<<even<<endl;
	cout<<"total no off odd="<<odd<<endl;
	
}
int main()
{
	
 input();
 processing();
	
}