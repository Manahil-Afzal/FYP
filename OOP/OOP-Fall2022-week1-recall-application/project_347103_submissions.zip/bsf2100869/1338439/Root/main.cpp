/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include<iostream>
using namespace std;
int input( int arr[20]){
    cout<<"Enter the array numnbers are   "<<endl;
    for(int i=0;i<20;i++){
        cin>>arr[i];
    }
}
int process(int arr[20]){
    cout<<"Even numbers are "<<endl;
    for(int i=0;i<20;i++){
        if(arr[i]%2==0)
        {
            cout<<arr[i]<<endl;
        }
    }
    cout<<"Odd numbers are "<<endl;
    for(int i=0;i<20;i++){
        if(arr[i]%2==1)
        {
            cout<<arr[i]<<endl;
        } 
}
}
int main()
{
    int arr[20];
    input(arr);
    process(arr);
    return 0;
}
