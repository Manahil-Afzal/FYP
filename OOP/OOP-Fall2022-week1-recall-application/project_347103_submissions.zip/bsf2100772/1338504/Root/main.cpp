/*write a C++ program that defines two functions: input and processing. The input function
is meant to take input of 20 integers in array and the processing function displays the number of even and odd numbers in that array*/
#include <iostream>
using namespace std;
void input(int num[20]){
    for(int i=0;i<=20;i++){
    cout<<"enter number:";
    cin>>num[i];}
}
void processing(int num[20]){
    int even=0,odd=0;
    for(int i=0;i<=20;i++)
    if(num[i]%2==0)
    {
        even++;
    }
    else{
    odd++;
    }

        cout<<"even number are:"<<even<<endl;
        cout<<"odd numbers are"<<odd; }
    

int main(){
int num[20];
input(num);
processing(num);
}