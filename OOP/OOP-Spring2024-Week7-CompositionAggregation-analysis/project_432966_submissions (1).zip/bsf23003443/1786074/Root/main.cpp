// // Main function of the C++ program.

// #include <iostream>

// class Chair{
// 	private:
// 	int chair_num;
// 	public:

// 	int get_chair_num(){
// 	{
// 	return chair_num;
// 	}
// };
// class Room{
// 	private:
// 	float area;
// 	Chair *chair;
// 	public:
// 	Room(float area1)
// 	{
// 	area=area1;

// 	}
// void show_Room()
// 	{
// 	cout<<area;
// 	cout<< chair->get_chair_num();

// 	}
// };
// int main(){
// 	float area1=0.0;
// 	Room r1(area1);
// 	r1.show_Room();
// 	return 0;
// }
#include <iostream>

class Chair {
private:
    int chair_num;

public:
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) {
        area = area1;
        chair = new Chair(); // Allocate memory for the chair
    }

    void show_Room() {
        std::cout << "Area: " << area << std::endl;
        std::cout << "Chair Number: " << chair->get_chair_num() << std::endl;
    }

    ~Room() {  // Destructor to free memory allocated for the chair
        delete chair;
    }
};

int main() {
    float area1 = 10.5;  // Example area
    Room r1(area1);
    r1.show_Room();
    return 0;
}
