#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    // Constructor to set chair number
    Chair(int num) : chair_num(num) {}

    int getChairNum() const {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    // Constructor to initialize Room with area and a chair
    Room(float area1, int chairNum) : area(area1) {
        chair = new Chair(chairNum);
    }

    // Destructor to release memory allocated for chair
    ~Room() {
        delete chair;
    }

    // Function to display room information
    void showRoom() const {
        cout << "Room Area: " << area << " sq. meters" << endl;
        cout << "Chair Number: " << chair->getChairNum() << endl;
    }
};

int main() {
    float area1 = 50.0; // Example area
    int chairNum = 4;   // Example chair number

    Room r1(area1, chairNum);
    r1.showRoom();

    return 0;
}
