// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) : chair_num(num) {}

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) : area(area1) {
        chair = new Chair(5); // Example: allocating memory for chair and assigning a chair number
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }

    // Destructor to deallocate memory for chair
    ~Room() {
        delete chair;
    }
};

int main() {
    float area1 = 10.5;
    Room r1(area1);
    r1.show_Room();
    return 0;
}

