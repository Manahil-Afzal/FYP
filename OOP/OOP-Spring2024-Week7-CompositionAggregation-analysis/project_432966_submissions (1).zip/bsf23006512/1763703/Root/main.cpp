/*// Main function of the C++ program.

#include <iostream>

class Chair{
	private:
	int chair_num;
	public:

	int get_chair_num(){
	{
	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1)
	{
	area=area1;

	}
void show_Room()
	{
	cout<<area;
	cout<< chair->get_chair_num();

	}
};
int main(){
	float area1=0.0;
	Room r1(area1);
	r1.show_Room();
	return 0;
}*/
#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) {
        chair_num = num;
    }

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1, int chair_num) {
        area = area1;
        chair = new Chair(chair_num);
    }

    void show_Room() {
        cout << "Area: " << area << " Square feet" << endl;
        cout << "Chair number: " << chair->get_chair_num() << endl;
    }

    ~Room() {
        delete chair; 
    }
};

int main() {
    float area1 = 100.0;
    int chair_num = 5;
    Room r1(area1, chair_num);
    r1.show_Room();
    return 0;
}