// Main function of the C++ program.

#include<iostream>
using namespace std;

class Chair {
public:
    int chair_num;

public:
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) {
        area = area1;
        chair = new Chair();
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }

    
    void set_chair_num(int num) {
        chair->chair_num = num;
    }
};

int main() {
    float area1 = 105.5;
    Room r1(area1);
    r1.set_chair_num(10);
    r1.show_Room();
    return 0;
}

