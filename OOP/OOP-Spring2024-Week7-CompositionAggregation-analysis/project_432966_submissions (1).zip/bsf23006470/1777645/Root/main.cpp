// Main function of the C++ program.

#include <iostream>
using namespace std;
class Chair {
private:
    int chair_num;
public:
    Chair(int num) : chair_num(num) {}
    int getChairNum() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair* chair;
public:
    Room(float area1, int chair_num) : area(area1) {
        chair = new Chair(chair_num);
    }
    void showRoom() {
        cout << "Room Area: " << area << " sq.ft" << endl;
        cout << "Chair Number: " << chair->getChairNum() << endl;
    }
    ~Room() {
        delete chair;
    }
};

int main() {
    float area1 = 100.5;
    int chair_num = 4;
    Room r1(area1, chair_num);
    r1.showRoom();

    return 0;
}
