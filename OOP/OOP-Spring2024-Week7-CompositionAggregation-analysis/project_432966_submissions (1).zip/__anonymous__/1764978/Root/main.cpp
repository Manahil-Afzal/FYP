// Main function of the C++ program.

#include <iostream>
using namespace std;
class Chair{
	private:
	int chair_num;
	public:
void set_chair_num(int ch_no){
	chair_num=ch_no;
}
	int get_chair_num(){
	return chair_num;
}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1,Chair chair1)
	{
	area=area1;
    chair=&chair1;
    chair->set_chair_num(23);
	}
void show_Room()
	{
	cout<<"Area of room is : "<<area<<" m^2 "<<endl;
	cout<<"Chair Number is : "<< chair->get_chair_num();

	}
};
int main(){
	float area1=0.0;
	Chair chair2;
	Room r1(area1,chair2);
	r1.show_Room();
	return 0;
}
