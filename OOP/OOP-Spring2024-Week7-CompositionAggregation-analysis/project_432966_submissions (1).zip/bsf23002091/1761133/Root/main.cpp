// // Main function of the C++ program.

// #include <iostream>
// using namespace std;
// class Chair{
// 	private:
// 	int chair_num;
// 	public:

// 	int get_chair_num(){
// 	{
// 	return chair_num;
// 	}
// };
// class Room{
// 	private:
// 	float area;
// 	Chair *chair;
// 	public:
// 	Room(float area1)
// 	{
// 	area=area1;

// 	}
// void show_Room()
// 	{
// 	cout<<area;
// 	cout<< chair->get_chair_num();

// 	}
// };
// int main(){
// 	float area1=0.0;
// 	Room r1(area1);
// 	r1.show_Room();
// 	return 0;
// }
#include <iostream>
using namespace std;

class Chair {
private:
    int chair_num;
public:
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;
public:
    Room(float area1, int numChairs) : area(area1) {
        chair = new Chair[numChairs];
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Number of chairs: " << chair->get_chair_num() << endl;
    }

    ~Room() {
        delete[] chair;
    }
};

int main() {
    float area1 = 10.0; // Example area value
    int numChairs = 4; // Example number of chairs
    Room r1(area1, numChairs);
    r1.show_Room();
    return 0;
}

