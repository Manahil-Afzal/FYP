#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;
public:
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;
public:
    Room(float area1) {
        area = area1;
        chair = new Chair(); // Initialize the chair pointer with a new Chair object
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }

    ~Room() {
        delete chair; // Deallocate memory for the chair pointer in the destructor
    }
};

int main() {
    float area1 = 0.0; // Just an example value for area
    Room r1(area1);
    r1.show_Room();
    return 0;
}

