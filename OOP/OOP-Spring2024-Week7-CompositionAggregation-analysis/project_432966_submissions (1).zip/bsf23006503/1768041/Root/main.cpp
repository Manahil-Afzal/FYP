// Main function of the C++ program.
#include <iostream>
using namespace std;

class Chair {
private:
    int chair_num;
public:
    Chair(int num) : chair_num(num) {}  // Constructor to set chair number

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair chair;  // Composition: Room contains a Chair directly
public:
    Room(float area1, int chair_num) : area(area1), chair(chair_num) {}  // Constructor to initialize area and Chair

    void show_Room() {
        cout << "Area: " << area << " square meters" << endl;
        cout << "Chair number: " << chair.get_chair_num() << endl;
    }
};

int main() {
    float area1 = 10.5;  // Example area value
    int chair_num = 4;   // Example chair number
    Room r1(area1, chair_num);
    r1.show_Room();
    return 0;
}
