#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) : chair_num(num) {} 

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair* chair; 

public:
    Room(float area1, int chair_num) : area(area1), chair(new Chair(chair_num)) {}

    void show_Room() {
        cout << "Room Area: " << area << endl; 
        cout << "Chair Number: " << chair->get_chair_num() << endl; 
    }

    ~Room() { 
        delete chair;
    }
};

int main() {
    float area1 = 100.0;
    int chair_num = 4; 
    Room r1(area1, chair_num);
    r1.show_Room();
    return 0;
}
