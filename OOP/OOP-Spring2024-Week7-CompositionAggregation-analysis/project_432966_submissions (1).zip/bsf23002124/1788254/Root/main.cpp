#include <iostream>
using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) : chair_num(num) {}

    int getChairNum() const {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) : area(area1) {
        chair = new Chair(1); // Example initialization, replace with your logic
    }

    void showRoom() const {
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->getChairNum() << endl;
    }

    // Destructor to release memory allocated for chair
    ~Room() {
        delete chair;
    }
};

int main() {
    float area1 = 10.0; // Example area value
    Room r1(area1);
    r1.showRoom();
    return 0;
}
