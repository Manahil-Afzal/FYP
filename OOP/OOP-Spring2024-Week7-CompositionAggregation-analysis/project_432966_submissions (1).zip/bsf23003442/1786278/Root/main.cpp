#include <iostream>
using namespace std;
class Chair {
private:
    int chair_num;

public:
    // Constructor to set chair number
    Chair(int num) : chair_num(num) {}

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair* chair; // Pointer to a Chair object

public:
    Room(float area1, int chair_num) : area(area1) {
        // Create a Chair object and associate it with the room
        chair = new Chair(chair_num);
    }

    void show_Room() {
        cout << "Room Area: " << area << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }

    // Destructor to clean up memory (delete the Chair object)
    ~Room() {
        delete chair;
    }
};

int main() {
    float area1 = 100.0; // Example room area
    int chair_num = 5;   // Example chair number

    Room r1(area1, chair_num);
    r1.show_Room();

    return 0;
}
