// Main function of the C++ program.

#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    int get_chair_num() {
        return chair_num;
    }
    void set_chair_num(int num) {
        chair_num = num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) {
        area = area1;
        chair = new Chair(); // Allocate memory for one Chair object
        chair->set_chair_num(1); // Set the chair number to 1
    }

    ~Room() {
        delete chair;
    }

    void show_Room() {
        cout << area << endl;
        cout << chair->get_chair_num() << endl;
    }
};

int main() {
    float area1 = 0.0;
    Room r1(area1);
    r1.show_Room();
    return 0;
}
