#include <iostream>
using namespace std;                            // Added using namespace std;

class Chair{
	private:
	int chair_num;
	
	public:
	void set_chair_num(int num){                //Remove an extra bracket and also created a setter to set chair number.
	chair_num=num;
	}
	int get_chair_num(){return chair_num;}
};

class Room{
	private:
	float area;
	Chair *chair;
	
	public:
	Room(Chair chair1,float area1){             // Initialize the pointer chair
	area=area1;
    chair = &chair1;
    chair->set_chair_num(56);                  // Set the value of chair number
	}
void show_Room()
	{
	cout<<"Area: "<< area <<endl;
	cout<<"Chair Number: "<< chair->get_chair_num()<<endl;

	}
};
int main(){
	float area1=3.14;                           // Initialize area with a different value
	Chair chair2;
	Room r1(chair2 , area1);                    // Add chair perimeter in it.
	r1.show_Room();
	return 0;
}