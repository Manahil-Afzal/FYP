// Main function of the C++ program.

#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) {
        area = area1;
        chair = new Chair(); // Allocating memory for Chair object
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair number: " << chair->get_chair_num() << endl;
    }
    
    ~Room() {
        delete chair; // Freeing memory allocated for Chair object
    }
};

int main() {
    float area1 = 10.5; // Sample area value
    Room r1(area1);
    r1.show_Room();
    return 0;
}
