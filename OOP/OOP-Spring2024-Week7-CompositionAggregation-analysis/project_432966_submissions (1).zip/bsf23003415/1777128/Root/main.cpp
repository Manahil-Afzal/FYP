// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
private:
    int chair_num;
public:
    Chair(int num) : chair_num(num) {} // initialize chair_num in constructor
    int get_chair_num() {
        return chair_num;
    }
};

class Room{
private:
    float area;
    Chair *chair;
public:
    Room(float area1, int chair_num) : area(area1) {
        chair = new Chair(chair_num); // allocate memory for chair and initialize it
    }
    ~Room() { // destructor to deallocate memory
        delete chair;
    }
    void show_Room() {
        cout << area << ", " << chair->get_chair_num() << endl;
    }
};

int main(){
    float area1 = 10.0; // initialize area1 with a value
    Room r1(area1, 5); // create a Room object with an area and a chair
    r1.show_Room();
    return 0;
}