// Main function of the C++ program.

#include <iostream>
using namespace std;
class Chair{
	private:
	int chair_num;
	public:
	Chair(int a)
	{
	    chair_num = a;
	}
	int get_chair_num(){
	{
	return chair_num;
	}
}};
class Room{
	private:
	float area;
	Chair* chair;
	public:
	Room(float area1,Chair* ch)
	{
	area = area1;
	chair = ch;
	}
void show_Room()
	{
	cout<<"Area of room : " <<area<<" feet"<<endl;
	cout<<"Chair number : "<<chair->get_chair_num()<<" chairs";
	}
};
int main()
{
	float area1 = 12.0;
	Chair* ch1 = new Chair(6);
	Room r1(area1,ch1);
	r1.show_Room();
	delete ch1;
	return 0;
}
