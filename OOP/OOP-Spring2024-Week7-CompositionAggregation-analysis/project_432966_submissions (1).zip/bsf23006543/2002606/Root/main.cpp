#include <iostream>
using namespace std;

class Chair {
private:
    int chair_num;

public:
    // Constructor to initialize chair number
    Chair(int num) {
        chair_num = num;
    }

    // Method to get chair number
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;  // Pointer to Chair object

public:
    // Constructor to initialize room area and chair pointer
    Room(float area1, int chair_num) {
        area = area1;
        chair = new Chair(chair_num);  // Dynamically allocate Chair object
    }

    // Destructor to free allocated memory for Chair
    ~Room() {
        delete chair;
    }

    // Method to display room details
    void show_Room() {
        cout << "Room Area: " << area << " square units" << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }
};

int main() {
    float area1 = 200.5;
    int chair_num = 101;

    // Create Room object with area and chair number
    Room r1(area1, chair_num);

    // Show room details
    r1.show_Room();

    return 0;
}
