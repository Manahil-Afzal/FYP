// Main function of the C++ program.

#include<iostream>
using namespace std;

class Chair{
    protected:
        int chair_num;
    public:
        void set_chair(int c){
            chair_num=c;
        }
        int get_chair_num(){
            return chair_num;
        }
};

class Room : public Chair{
    private:
        float area;
    public:
        Room(float area1, int chair_num) : area(area1) {
            set_chair(chair_num);
        }

        void show_Room() {
            cout << "Area of the room: " << area << " square meters" << endl;
            cout << "Number of chairs in the room: " << get_chair_num() << endl;
        }
};

int main() {
    float area1 = 100.0; // Assuming area of the room
    int num_chairs = 4; // Assuming number of chairs in the room
    Room r1(area1, num_chairs);
    r1.show_Room();
    return 0;
}