#include <iostream>
using namespace std; // Added using namespace std to use cout

class Chair {
private:
    int chair_num;

public:
    int getChairNum() { // Corrected function name and syntax
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) {
        area = area1;
        chair = new Chair(); // Created a Chair object
    }

    void showRoom() { // Corrected function name and syntax
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->getChairNum() << endl; // Corrected function call
    }
};

int main() {
    float area1 = 0.0;
    Room r1(area1);
    r1.showRoom(); // Corrected function call
    return 0;
}
