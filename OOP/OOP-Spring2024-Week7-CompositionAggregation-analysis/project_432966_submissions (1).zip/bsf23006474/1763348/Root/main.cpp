// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:

	Chair(int num){
		chair_num=num;
	}
	int get_chair_num(){
		return chair_num;
	}

};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(Chair chair1,float area1)
	{
	area=area1;
	chair=&chair1;
	}
void show_Room()
	{
	cout<<area<<endl;
	cout<<"Chair number is: "<<chair->get_chair_num();

	}
};
int main(){
	float area1=0.0;
	Chair chair(5);
	Room r1(chair,area1);
	r1.show_Room();
	return 0;
}
