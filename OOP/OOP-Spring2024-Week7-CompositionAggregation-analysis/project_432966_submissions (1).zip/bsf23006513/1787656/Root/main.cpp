#include <iostream>
using namespace std;

class Room {
private:
    float area;

public:
    Room(float area1) : area(area1) {}

    void showRoom() {
        cout << "Area: " << area << endl;
    }
};

int main() {
    float area1 = 10.0;
    Room r1(area1);

    r1.showRoom();

    return 0;
}
