#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) : chair_num(num) {}

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1, int num) : area(area1), chair(new Chair(num)) {}

    ~Room() {
        delete chair; // Don't forget to deallocate memory
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Number of chairs: " << chair->get_chair_num() << endl;
    }
};

int main() {
    float area1 = 100.0;
    int num_chairs = 4; 
    Room r1(area1, num_chairs);
    r1.show_Room();
    return 0;
}

