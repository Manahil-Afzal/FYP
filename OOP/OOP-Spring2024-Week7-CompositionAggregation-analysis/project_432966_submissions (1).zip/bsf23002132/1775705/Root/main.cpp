// Main function of the C++ program.
#include <iostream>
using namespace std;
class Chair{
	private:
	string chair_num;
	public:
    void set_chair_num(string num){
        chair_num=num;
    }
	string get_chair_num(){
	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair* chair;
	public:
	Room(float area1)
	{
	area=area1;
    
	}
void show_Room()
	{
	cout<<area;

	}
};
int main(){
	float area1=2.0;
	Room r1(area1);
	r1.show_Room();
	return 0;
}
