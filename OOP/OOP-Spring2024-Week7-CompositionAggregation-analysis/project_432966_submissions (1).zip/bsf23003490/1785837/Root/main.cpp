// Main function of the C++ program.

#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) : chair_num(num) {}

    int getChairNum() const {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1, int chairNum) : area(area1), chair(new Chair(chairNum)) {}

    void showRoom() {
        cout << "Room Area: " << area << " sq. ft." << endl;
        cout << "Chair Number: " << chair->getChairNum() << endl;
    }

    ~Room() {
        delete chair;
    }
};

int main() {
    float area1 = 100.5;
    int chairNum = 5;
    Room r1(area1, chairNum);
    r1.showRoom();
    return 0;
}
