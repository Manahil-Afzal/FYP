// Main function of the C++ program.

#include <iostream>
class Chair {
private:
    int chair_num;
public:
    void set_chair_num(int num) {
        chair_num = num;
    }
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair; 
public:
    Room(float area1) {
        area = area1;
        chair = new Chair();
    }
    ~Room() {
        delete chair;
    }
    void set_chair_num(int num) {
        chair->set_chair_num(num);
    }
    void show_Room() {
        std::cout << "Area of the room: " << area << std::endl;
        std::cout << "Chair number: " << chair->get_chair_num() << std::endl;
    }
};
int main() {
    float area1 = 0.0;
    Room r1(area1);
    int chair_num = 1;
    r1.set_chair_num(chair_num);
    r1.show_Room();
    return 0;
}
