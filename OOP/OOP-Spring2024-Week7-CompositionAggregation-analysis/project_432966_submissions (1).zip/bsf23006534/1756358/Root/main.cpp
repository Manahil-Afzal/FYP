#include <iostream>
using namespace std; 

class Chair {
private:
    int chair_num;

public:
    void set_chair_num(int i) {
        chair_num = i;
    }
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair chair;

public:
    Room(float area1, const Chair& chair1) : area(area1), chair(chair1) {
        chair.set_chair_num(34);
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair number: " << chair.get_chair_num() << endl;
    }
};

int main() {
    float area1 = 10.4;
    Chair chair2; 
    Room r1(area1, chair2); 
    r1.show_Room();
    return 0;
}
