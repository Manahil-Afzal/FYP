// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:

	int get_chair_num(){
	    int ch=10;
	    chair_num=ch;
	   	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1,Chair c)
	{
		chair=&c;
		
	area=area1;
	

	}
void show_Room()
	{
	cout<<area;
	cout<< chair->get_chair_num();

	}
};
int main(){
    float area2=4.3;
    
    Chair che;
	Room r1(area2,che);
	r1.show_Room();
	return 0;
}
