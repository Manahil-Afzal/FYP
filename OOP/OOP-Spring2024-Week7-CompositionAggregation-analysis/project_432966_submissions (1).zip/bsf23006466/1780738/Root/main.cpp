// Main function of the C++ program.

#include <iostream>
using namespace std;
class Chair{
	private:
	int chair_num;
	public:
    void set_chair_numbr(int numbr){
        chair_num=numbr;
    }
	int get_chair_num()
	{
	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(Chair chair2 , float area1 )
	{
	    area=area1;
	   chair=&chair2;
	   chair->set_chair_numbr(2);
	}
void show_Room()
	{
	cout<<area<<endl;
	cout<< chair->get_chair_num()<<endl;

	}
};
int main(){
	float area1=0.0;
	Chair chair1;
	Room r1(chair1,area1);
	r1.show_Room();
	return 0;
}
