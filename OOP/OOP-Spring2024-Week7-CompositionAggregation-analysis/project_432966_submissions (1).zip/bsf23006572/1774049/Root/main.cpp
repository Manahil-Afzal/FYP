// // Main function of the C++ program.

// #include <iostream>

// class Chair{
// 	private:
// 	int chair_num;
// 	public:

// 	int get_chair_num(){
// 	{
// 	return chair_num;
// 	}
// };
// class Room{
// 	private:
// 	float area;
// 	Chair *chair;
// 	public:
// 	Room(float area1)
// 	{
// 	area=area1;

// 	}
// void show_Room()
// 	{
// 	cout<<area;
// 	cout<< chair->get_chair_num();

// 	}
// };
// int main(){
// 	float area1=0.0;
// 	Room r1(area1);
// 	r1.show_Room();
// 	return 0;
// // }
// These are the following errors in the above program 
// First include the necessrary header files 
// Second Ending prenthess 
// Third declare the chair number in the class 
// Fourth declare constructor area1 insted of float area 

#include <iostream>
using namespace std;
class Chair
{
private:
    int chair_num=234;

public:
    int get_chair_num()
    {
        return chair_num;
    }
};
class Room:public Chair
{
private:
    float area;
    Chair *chair;

public:
    Room(float area1)
    {
        area = area1;
    };
    void show_Room()
    {
        cout << area;
        cout << chair->get_chair_num();
    }
};
int main()
{
    // float area1 = 0.0;
    Room r1(43.4);
    r1.show_Room();
    return 0;
}
