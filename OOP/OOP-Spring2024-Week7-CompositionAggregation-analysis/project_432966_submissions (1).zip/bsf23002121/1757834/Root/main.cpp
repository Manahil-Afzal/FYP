// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:

	void set_chair_num(int num){
	chair_num=num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1)
	{
	area=area1;

	}
void show_Room()
	{
	cout<<area;

	}
};
int main(){
	float area1=4.0;
	Room r1(area1);
	r1.show_Room();
	return 0;
}
