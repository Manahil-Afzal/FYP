#include <iostream>

using namespace std;

class Chair {
private:
    int chair_num;

public:
    Chair(int num) : chair_num(num) {}

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair* chair;

public:
    Room(float area1, int chair_num) : area(area1), chair(new Chair(chair_num)) {}

    void show_Room() {
        cout << "Room Area: " << area << " square units." << endl;
        cout << "Number of Chairs: " << chair->get_chair_num() << endl;
    }

    // Destructor to deallocate memory
    ~Room() {
        delete chair;
    }
};

int main() {
    float area1 = 100.5; // Example area
    int num_chairs = 4;  // Example number of chairs

    Room r1(area1, num_chairs);
    r1.show_Room();

    return 0;
}