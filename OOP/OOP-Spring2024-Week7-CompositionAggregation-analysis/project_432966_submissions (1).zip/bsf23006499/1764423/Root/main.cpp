#include <iostream>
using namespace std;
class Chair {
private:
    int chair_num;
public:
    int get_chair_num() {
    return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;
public:
    Room(float area1) {
    area = area1;
    chair = new Chair();
    }
    ~Room() {
    delete chair;
    }
    void show_Room() {
    cout << "Area= " << area <<endl;
    cout << "Number of chairs= " << chair->get_chair_num() <<endl;
    }
};

int main() {
    float area1 = 0.0;
    Room r1(area1);
    r1.show_Room();
    return 0;
}
