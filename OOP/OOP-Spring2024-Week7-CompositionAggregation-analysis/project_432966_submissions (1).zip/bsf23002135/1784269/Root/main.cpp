// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:
    Chair(){
        chair_num = 112;
    }
	int get_chair_num(){
	    return chair_num;
}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1, Chair *chair)
	{
	area=area1;
    this->chair = chair;

	}
void show_Room()
	{
	cout<<area<<endl;
	cout<< chair->get_chair_num();

	}
};
int main(){
	float area1=0.0;
    Chair c;
	Room r1(area1,&c);
	r1.show_Room();
	return 0;
}
