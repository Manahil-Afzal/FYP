#include <iostream>
using namespace std;

class Chair {
	private:
		int chair_num;

	public:
		Chair(int num) : chair_num(num) {} // Constructor to set chair number
		// Method to get chair number
		int get_chair_num() {
			return chair_num;
		}
};

class Room {
	private:
		float area;
		Chair *chair;

	public:
		// Constructor to initialize Room with area
		Room(float area1, int chair_num) : area(area1) {
			chair = new Chair(chair_num);
		}

		// Destructor to deallocate memory
		~Room() {
			delete chair;
		}

		// Method to show room details
		void show_Room() {
			cout << "Area: " << area << " square units" << endl;
			cout << "Chair Number: " << chair->get_chair_num() << endl;
		}
};

int main() {
	float area1 = 100.0;
	int chair_num = 1; // Assigning a chair number
	Room r1(area1, chair_num);
	r1.show_Room();
	return 0;
}
