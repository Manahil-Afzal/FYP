// Main function of the C++ program.
#include <iostream>
using namespace std;
class Chair{
	private:
	int chair_num;
	public:
	void set_chair_num(int n){
		chair_num=n;
	}	
	int get_chair_num()
	{
	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(Chair chair1,float area1)
	{
	area=area1;
	chair=&chair1;
	chair->set_chair_num(11);
	}
    void show_Room()
	{
	cout<<area<<endl;
	cout<< chair->get_chair_num()<<endl;

	}
};
int main(){
	float area1=0.0;
	Chair c1;
	Room r1(c1,area1);
	r1.show_Room();
	return 0;
}