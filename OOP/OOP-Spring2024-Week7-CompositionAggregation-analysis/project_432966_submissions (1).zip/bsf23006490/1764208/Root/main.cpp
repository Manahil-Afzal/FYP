// Main function of the C++ program.

#include <iostream>
using namespace std;
class Chair{
	private:
	int chair_num;
	public:
    int set_chair_num(int i)
	{
	 chair_num=i;
	}
	int get_chair_num()
	{
	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1,Chair chair1)
	{
	area=area1;
    chair=&chair1;
    chair->set_chair_num(10);
	}
void show_Room()
	{
	cout<<area;
	cout<< chair->get_chair_num();

	}
};
int main(){
	float area1=0.0;
	Chair c1;
	Room r1(area1,c1);
	r1.show_Room();
	return 0;
}
