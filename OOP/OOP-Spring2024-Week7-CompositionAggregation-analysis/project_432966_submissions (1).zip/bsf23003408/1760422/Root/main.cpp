// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair {
private:
    int chair_num;
public:
    Chair(int num) : chair_num(num) {}

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;
public:
    Room(float area1, int chair_num) {
	area=area1;
	chair=new Chair(chair_num);}
    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }
  
};

int main() {
    float area1 = 100.0;
    int chair_number = 4;
    Room r1(area1, chair_number);
    r1.show_Room();
    
    return 0;
}
