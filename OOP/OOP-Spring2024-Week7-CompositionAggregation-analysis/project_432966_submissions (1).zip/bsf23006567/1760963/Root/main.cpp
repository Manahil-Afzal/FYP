// Main function of the C++ program.

#include<iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:
		Chair(int num)
		{
			chair_num=num;
			
		}

	int get_chair_num()
	{
	   return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	int chairnum;
	public:
	Room(float area1,Chair chair1)
	{
	area=area1;
	chair=&chair1;

	}
void show_Room()
	{
	cout<<area;
	cout<<chair->get_chair_num();

	}
};
int main(){
	float area1=0.09;
	Chair chair1(10);
	Room r1(area1,chair1);
	r1.show_Room();

}
