// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:
    Chair(){}
    Chair(int num){
        chair_num=num;
    }

	int get_chair_num()
	{
	return chair_num;}
	
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
    Room(){}
	Room(float area1, Chair c1)
	{
        chair=&c1;
	area=area1;

	}
    float getarea(){
        return area;
    }
void show_Room()
	{
	cout<<area<<endl;
	cout<< chair->get_chair_num();

	}
};
int main(){
	float area1=0.0;
    Chair c1(6);
	Room r1(area1,c1);
	r1.show_Room();
	return 0;
}
