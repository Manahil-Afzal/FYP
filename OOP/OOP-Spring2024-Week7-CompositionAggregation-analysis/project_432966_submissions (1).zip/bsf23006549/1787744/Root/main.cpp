// Main function of the C++ program.

#include <iostream>
using namespace std;

class Chair{
	private:
	int chair_num;
	public:
	Chair(int chairnum){
	    chair_num=chairnum;
	}
	int get_chair_num(){
	return chair_num;
	}
};
class Room{
	private:
	float area;
	Chair *chair;
	public:
	Room(float area1,Chair *chai)
	{
	chair=chai;
	area=area1;

	}
void show_Room()
	{
	cout<<"Area : "<<area<<endl;
	cout<<"Chair Num : "<<chair->get_chair_num();

	}
};
int main(){
    Chair ch(69);
	float area1=7.6;
	Room r1(area1,&ch);
	r1.show_Room();
	return 0;
}

