// Main function of the C++ program.

// 

#include <iostream>

class Chair {
private:
    int chair_num;

public:
    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(float area1) : area(area1) {
     
        chair = new Chair[5]; 
    }

    void show_Room() {
        std::cout << "Area: " << area << std::endl;
        for (int i = 0; i < 5; ++i) { 
            std::cout << "Chair " << i + 1 << " number: " << chair[i].get_chair_num() << std::endl;
        }
    }

    ~Room() {
        delete[] chair;
    }
};

int main() {
    float area1 = 10.0; 
    Room r1(area1);
    r1.show_Room();
    return 0;
}
