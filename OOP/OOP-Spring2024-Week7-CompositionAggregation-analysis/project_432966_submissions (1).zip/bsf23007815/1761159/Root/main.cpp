#include<iostream>
using namespace std;

class Chair {
private:
    int chair_num;

public:
    void set_chair_num(int num) {
        chair_num = num;
    }

    int get_chair_num() {
        return chair_num;
    }
};

class Room {
private:
    float area;
    Chair *chair;

public:
    Room(Chair chair1, float area1) {
        area = area1;
        chair = &chair1; // Assigning the address of the chair1 object
        chair->set_chair_num(111);
    }

    void show_Room() {
        cout << "Area: " << area << endl;
        cout << "Chair Number: " << chair->get_chair_num() << endl;
    }
};

int main() {
    float area1 = 12.31;
    Chair chair2;
    Room r1(chair2, area1);
    r1.show_Room();
    return 0;
}