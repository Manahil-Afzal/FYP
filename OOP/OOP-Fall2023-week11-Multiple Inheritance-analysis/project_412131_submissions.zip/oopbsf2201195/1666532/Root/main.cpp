// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected:
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
    protected:
    int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};
class C : public A, public B   
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sum();
 	 return 0;
}  
