// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setZ(int q) {
        z = q;
    }
};

class A {
private:
    int x;

public:
    void setX(int q) {
        x = q;
    }

    int getX() const {
        return x;
    }
};

class B {
protected:
    int y;

public:
    void setY(int q) {
        y = q;
    }

    int getY() const {
        return y;
    }
};

class C : public A, public B , public P {
public:
    void sum() {
        int x = getX();
        int y = getY();
        cout << "Sum = " << x + y + z << endl;
    }
};

int main() {
    C obj1;
    obj1.setZ(3);
    obj1.setX(4);
    obj1.setY(5);
    obj1.sum();
    return 0;
}
