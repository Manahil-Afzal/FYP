// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 		
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected:
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
	int y;
 	public:
 	
 	void sety(int q) // sety instead of setz
    {
 	     y=q; // y=q instead of y=z
    }
};
class C : public A, public B, public P   // public P is to be declared and secondly "," is to be used instead of ";"
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y + z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
