// Identify and correct errors ( also comment the errors).

#include<iostream>
using namespace std;

class Course
{
protected:
    int ID;
public:
    void input()
    {
        cout<<"Enter course ID (Int): ";
        cin>>ID;
    }
};

class CS : public Course
{
public:
    void display()
    {
        cout << "Course ID (CS): " << ID << endl;
    }
};

class IT : public Course
{
public:
    void display()
    {
        cout << "Course ID (IT): " << ID << endl;
    }
};

class SOS_Course : public IT, public CS
{
public:
    void displaySOS()
    {
        cout << "Course ID (SOS_Course): " << 23 << endl;
    }
};

int main()
{
    SOS_Course sosCourse;
    
    sosCourse.displaySOS();
    return 0;
}
