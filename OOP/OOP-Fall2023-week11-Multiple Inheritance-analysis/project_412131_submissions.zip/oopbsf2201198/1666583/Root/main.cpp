// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int p;
 	public:
 	
 	void setp(int q)
    {
 	     p=q;
    }
};

class A : virtual public P
{
	protected:
	int a;
 	public:
 	void seta(int q)
    {
 	     a=q;
    }

};
class B:virtual public P
{
protected:
int b;
 	public:
 	
 	void setb(int q)
    {
 	     b=q;
    }
};
class C : public A, public B 
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << p + a+b;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setp(3);
 	 obj1.seta(4);
 	 obj1.setb(5);
 	 obj1.sum();
 	 return 0;
}  
