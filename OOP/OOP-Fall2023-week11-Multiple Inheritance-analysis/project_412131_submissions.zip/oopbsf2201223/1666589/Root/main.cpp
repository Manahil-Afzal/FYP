// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     q=z;
    }
};

class A :virtual public P
{
	protected:
	int x;
 	public:
 	void setx(int q)
    {
 	     q=x;
    }

};
class B : virtual public P
{
protected:
int y;
 	public:
 	
 	void sety(int q)
    {
 	     q=y;
    }
};
class C : public A, public B   
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y;
 	}
};

int main()
{
 	 C obj1; 
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
