#include <iostream>
#include <string>

using namespace std;

// Base class: Course
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class: IT
class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class: CS
class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class: SOS_Course 
class SOS_Course : public IT, public CS {
public:
  
    void display() {
      
        IT::display();
    }
};

int main() {
    // Declare an object 
    SOS_Course sosCourse;

    // Input course ID 
    sosCourse.IT::input(); // Specify the input method from the IT class

    // Display the course ID 
    sosCourse.display();

    return 0;
}

