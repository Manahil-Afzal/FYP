#include <iostream>
#include <string>

using namespace std;

class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

class SOS_Course : public IT, public CS {
public:
  
    void display() {
      
        IT::display();
    }
};

int main() {
    SOS_Course sosCourse;

    sosCourse.IT::input(); 

    sosCourse.display();

    return 0;
}

