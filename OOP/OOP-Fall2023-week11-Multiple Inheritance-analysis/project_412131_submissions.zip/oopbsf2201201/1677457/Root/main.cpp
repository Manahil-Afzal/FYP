// Identify and correct errors ( also comment the errors).

#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
};

class A {
private:
    int x;

public:
    void setx(int q) {
        x = q;
    }

    int getx() const {
        return x;
    }
};

class B {
protected:
    int y;

public:
    void sety(int q) {
        y = q;
    }
};

class C : public A, public B, public P { // Added inheritance from P
public:
    void sum() {
        // Access x using the getx() method
        cout << "Sum = " << getx() + y + z << endl;
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.setx(4);
    obj1.sety(5);
    obj1.sum();
    return 0;
}