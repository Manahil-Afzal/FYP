// Identify and correct errors ( also comment the errors).

#include<iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected:  //here access specifier should be protected instead of private
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void sety(int q)  //here the member function name should be sety instead of setz
    {
 	     y=q;   //there shoulb be y=q intead of z=y
    }
};
class C : public A, public B, public P  //here base classes should be comma separated and the P class should also be included
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y + z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}  
