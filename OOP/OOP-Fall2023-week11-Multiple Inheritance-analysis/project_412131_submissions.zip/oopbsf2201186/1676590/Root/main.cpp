#include <iostream>
using namespace std;

class P {
protected:
    int z;

public:
    void setz(int q) {
        z = q;
    }
};

class A {
private:
    int x;

public:
    void setx(int q) {
        x = q;
    }

    int getx() const { // Added a getter function for x
        return x;
    }
};

class B {
protected:
    int y;

public:
    void sety(int q) {
        y = q;
    }
    
    int gety() const { // Added a getter function for y
        return y;
    }
};

class C : public A, public B, public P {
public:
    void sum() {
        setx(4);
        cout << "Sum = " << getx() + gety() + z << endl; // Used getx(), gety(), and z to access members from their respective classes
    }
};

int main() {
    C obj1;
    obj1.setz(3);
    obj1.sety(5);
    obj1.sum();
    return 0;
}
