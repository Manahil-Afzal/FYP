#include <iostream> 
using namespace std; 

class base 
{ 
public: 
	void print () 
	{ cout<< "print base class" <<endl; } 

}; 

class derived:public base 
{ 
public: 
virtual	void print () 
	{ cout<< "print derived class" <<endl; } 

virtual	void show () 
	{ cout<< "show derived class" <<endl; } 
}; 

int main() 
{ 
	base *bptr; 
	derived d; 
	bptr = &d; 
	bptr->print(); 
	d.show(); 

	return 0; 
}