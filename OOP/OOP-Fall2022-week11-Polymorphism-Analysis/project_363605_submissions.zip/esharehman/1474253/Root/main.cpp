
/*This code is meant to polymorphically call two methods print and show. 
Identify and correct any logical or compilation errors*/
#include<iostream> 
using namespace std; 

class Base 
{ 
public: 
    virtual void show() = 0;
}; 

class Derived: public Base 
{ 
public: 
    void show() { cout << "In Derived \n"; } 
}; 

int main() 
{ 
    Derived d;
    Base &bp = d;
    bp.show(); 
    return 0; 
}