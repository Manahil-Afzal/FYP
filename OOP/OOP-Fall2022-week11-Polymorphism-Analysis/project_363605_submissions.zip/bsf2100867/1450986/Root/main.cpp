
/*This code is meant to polymorphically call two methods print and show. 
Identify and correct any logical or compilation errors*/
#include <iostream>
using namespace std;

class Person
{ protected:
   string subject;
   
     public:
    
    void set_subject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name";
     cin>>subjectname;
     teacher.set_subject(subjectname);
     teacher.display();

     return 0;
}
