
/*This code is meant to polymorphically call two methods print and show. 
Identify and correct any logical or compilation errors*/
#include <iostream> 
using namespace std; 

class base 
{ 
public: 
//  also right virtual here.
	 virtual void print () 
	{ cout<< "print base class" <<endl; } 

}; 

class derived:public base 
{ 
public: 
virtual	void print () 
	{ cout<< "print derived class" <<endl; } 

virtual	void show () 
	{ cout<< "show derived class" <<endl; } 
}; 
void display(base *al){
	al->print();
	
}
int main() 
{ 
    base *obj1=new base;
    derived*obj2=new derived;
	base *bptr; 
	derived d; 
	bptr = &d; 
	display(obj1); 
    display(obj2); 
	d.show(); 

	return 0; 
} 
