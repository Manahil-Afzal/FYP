//class, constructor
//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
    Car(){} // constructor has no return type
    int speed(int maxSpeed);

};  //constructor was missing here


int Car::speed(int maxSpeed) {
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
