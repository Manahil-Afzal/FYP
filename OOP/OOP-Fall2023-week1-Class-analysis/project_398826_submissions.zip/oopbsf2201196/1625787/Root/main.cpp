/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/


#include <iostream>

using namespace std;

class book{
private:
    string title;
    float price ;
public:
    void getdata (){
cout<<"title:";
cin>>title;
cout<<"price:";
cin>>price;
 }
    void putdata () {
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
} ;

int main ()
{
book book1, book2, book3;
cout<<"Enter data of book1: "<<endl;
book1.getdata();
cout<<"Enter data of book2: "<<endl;
book2.getdata();
cout<<"Enter data of book3: "<<endl;
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
