//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
    // The constructor should not have a return type
    Car() {}

    // The function declaration in the class should end with a semicolon
    int speed(int maxSpeed);
};

// The scope resolution operator should be ::
int Car::speed(int maxSpeed) {
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}