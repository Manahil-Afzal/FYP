/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book
{
private: // Use access specifiers to define member visibility
    string title;
    float price;

public: // Declare member functions as public
    void getdata()
    {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putdata()
    {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main()
{
    Book book1, book2, book3; // Use 'Book' instead of 'books' for object creation
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
