/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
    public: // Access specifier
string title;
float price ;
void getdata ();
void putdata ();
} ;
void book :: getdata () // semi-colon error and class is book not books
{
cout<<"Title:"; // double quotes error
cin>>title;
cout<<"Price:"; // double quotes error
cin>>price;
 
}
void book :: putdata ()  // semi-colon error and class is book not books
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main ()
{ //curly brackets used

class book book1, book2, book3; //class is book not books
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}