//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
    Car (){} // NO return type required for constructor and constructor must have same name as class 
    int speed(int maxSpeed);

}; // semi colon mistake


int Car::speed(int maxSpeed) { // resolution operator 
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
