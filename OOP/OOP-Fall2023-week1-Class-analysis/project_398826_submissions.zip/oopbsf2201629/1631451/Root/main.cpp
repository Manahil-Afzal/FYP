#include <iostream>
using namespace std;

class Car {
  public:
    // Constructor should have the same name as the class and no return type.
    Car() {}

    // Member function declaration with a return type.
    int speed(int maxSpeed);
};

// Member function definition should include the class name.
int Car::speed(int maxSpeed) {
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
