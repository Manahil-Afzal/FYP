/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
public:
    string title;
    float price;
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore(); // Ignore any newline characters left in the input buffer
    getline(cin, title);
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;
    
    cout << "Enter details for Book 1:\n";
    book1.getData();
    
    cout << "Enter details for Book 2:\n";
    book2.getData();
    
    cout << "Enter details for Book 3:\n";
    book3.getData();
    
    cout << "Details of Book 1:\n";
    book1.putData();
    
    cout << "Details of Book 2:\n";
    book2.putData();
    
    cout << "Details of Book 3:\n";
    book3.putData();

    return 0;
}
