/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData() {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putData() {
        cout << "Title: " << title << endl;
        cout << "Price: " << price << endl;
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:" << endl;
    book1.getData();

    cout << "Enter details for Book 2:" << endl;
    book2.getData();

    cout << "Enter details for Book 3:" << endl;
    book3.getData();

    cout << endl;

    cout << "Details of Book 1:" << endl;
    book1.putData();

    cout << "Details of Book 2:" << endl;
    book2.putData();

    cout << "Details of Book 3:" << endl;
    book3.putData();

    return 0;
}
