#include <iostream>
using namespace std;

class Car {
  public:
    // Constructor (no return type)
    Car() {
        cout << "Car object is created." << endl;
    }

    int speed(int maxSpeed);
};

int Car::speed(int maxSpeed) {
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << "Max speed: " << myObj.speed(200) << " mph" << endl;
  return 0;
}
