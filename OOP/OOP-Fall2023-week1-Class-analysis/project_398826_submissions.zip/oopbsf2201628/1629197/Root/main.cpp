//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
     Car(){}            //constractor have no data type
    int speed(int maxSpeed);

};                                  //use terminator


int Car::speed(int maxSpeed) {
  return maxSpeed;
};

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
