#include <iostream>
using namespace std;

class Car {
public:
    Car() {} // This is the constructor, don't declare it as a function
    int speed(int maxSpeed); // Declare the member function here
};

int Car::speed(int maxSpeed) {
    return maxSpeed;
}

int main() {
    Car myObj;
    cout << myObj.speed(200);
    return 0;
}