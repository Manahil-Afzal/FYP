/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
private:
string title;
float price ;
public:
void getdata ();
void putdata ();
};
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata();
book2.putdata();
book3.putdata();

return 0;
}
void book::getdata()
{
    cout<<"ENTER TITLE OF BOOOK"<<endl;
    cin>>title;
    cout<<"ENTER PRICE OF BOOK:"<<endl;
    cin>>price;
}
void book::putdata()
{
    cout<<"book title:"<<title<<endl;
    cout<<"BOOK PRICE:"<<price<<endl;
}





