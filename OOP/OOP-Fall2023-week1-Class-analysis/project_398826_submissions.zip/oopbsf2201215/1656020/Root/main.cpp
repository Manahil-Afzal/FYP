//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
     Car(){}   //constructor with the same name as class
    int speed(int maxSpeed);  //function declaration
};
int Car::speed(int maxSpeed){ //function defination 
  return maxSpeed;
}
int main(){
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
