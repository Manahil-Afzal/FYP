
//class, constructor
#include <iostream>
using namespace std;

class Car {
public:
    // Constructor should not have a return type and should not have the same name as the class
    Car() {}

    // You missed a semicolon after the method declaration
    int speed(int maxSpeed);
};

// You need to specify the class name before the method name using the scope resolution operator ::
int Car::speed(int maxSpeed) {
    return maxSpeed;
}

int main() {
    Car myObj;
    cout << myObj.speed(200);
    return 0;
}