/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore(); // Clear any previous newline character in the input buffer.
    getline(cin, title); // Read the entire line as the title.
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;
    cout << "Enter data for Book 1:\n";
    book1.getData();
    cout << "Enter data for Book 2:\n";
    book2.getData();
    cout << "Enter data for Book 3:\n";
    book3.getData();

    cout << "Data for Book 1:\n";
    book1.putData();
    cout << "Data for Book 2:\n";
    book2.putData();
    cout << "Data for Book 3:\n";
    book3.putData();

    return 0;
}
