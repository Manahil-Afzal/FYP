//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
    Car() {} // Constructor with the same name as the class
    int speed(int maxSpeed); // Function declaration

};

int Car::speed(int maxSpeed) { // Function definition
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}
