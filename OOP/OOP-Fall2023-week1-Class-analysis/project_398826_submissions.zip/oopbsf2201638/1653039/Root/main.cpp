#include<iostream>
using namespace std;

class car{
	int maxSpeed;
	public:
		car(int speed){
			maxSpeed = speed; 
		}
		void show(){
			cout<<"The Car Maxspeed = "<<maxSpeed<<endl;
		}
}; 

main()
{
	car   a1(200);
	a1.show();
}