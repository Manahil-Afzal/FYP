/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
#include<string>
using namespace std;
class book
{
	private: // use access specifier 
string title;
float price ;
public:// use access specifier 
void getdata ()
{
cout<<"Title"; // double quotes error
cin>>title;
cout<<"Price:"; //double quotes error
cin>>price;
 
} // use } for data member 
void putdata ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";//ouble quotes error
}
};// class 
int main ()
{
book book1, book2, book3; // use book as class instead of books 
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
} 

