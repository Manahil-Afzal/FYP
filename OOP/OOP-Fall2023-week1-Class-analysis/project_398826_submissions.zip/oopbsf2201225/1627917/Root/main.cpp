//class, constructor
#include <iostream>
using namespace std;

class Car {
  public:
     Car(){}//NO return type required for constructer
    int speed(int maxSpeed);

};//semi colon error for class defination


int Car::speed(int maxSpeed) {//use resolution operator by function
  return maxSpeed;
}

int main() {
  Car myObj;  
  cout << myObj.speed(200); 
  return 0;
}