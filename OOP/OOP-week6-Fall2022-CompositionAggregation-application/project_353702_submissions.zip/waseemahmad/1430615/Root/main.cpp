/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>

using namespace std;

class Engine{
    public:
        int engine_number;
        
        Engine(int en){
            engine_number = en;
        }
};

class Passenger{
    public:
        string passenger_name;
};

class Car{
    public:
        Engine e1;
        Passenger *passenger;
        
        Car(int en, Passenger *p):e1(en){
            passenger = p;
        }
        
};



int main(){
    Passenger p;
    p.passenger_name = "bilal";
    Car c1(123, &p);
    cout<<"Engine number : "<<c1.e1.engine_number<<"\n";
    cout<<"Passenger Name : "<<c1.passenger->passenger_name;
    return 0;
}