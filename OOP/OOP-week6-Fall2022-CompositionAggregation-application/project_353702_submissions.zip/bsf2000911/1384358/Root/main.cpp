/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>  
using namespace std;  
class car {  
    public:  
   int x;    
     car(int engine_number)    
    {    
        this->x = engine_number;    
         
    }    
};  
class passenger    
    {    
        private:  
        car* address;  //Employee HAS-A Address   
        public:      
        string name;    
        passenger( string name, car* address)    
       {       
           this->name = name;    
           this->address = address;    
       }    
     void display()    
       {    
           cout<<"Name of passenger :"<<endl<<name<<endl<<"Engine number of car :"<<endl<<address->x<<endl;    
       }    
   };   
     int main(void) {  
    car Engine= car(1032);    
    passenger e1 = passenger("Abuzar",&Engine);    
      e1.display();   
   return 0;  
}