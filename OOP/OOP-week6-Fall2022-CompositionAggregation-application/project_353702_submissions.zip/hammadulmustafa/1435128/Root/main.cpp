/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;

class Engine
{
private:
    string eng_num;

public:
 
Engine()
{
    eng_num="337206";
}
    string get_eng_num()
    {
        return eng_num;
    }
};
class Passenger
{
private:
    string passenger_name;

public:
    void set_psg()
    {
        passenger_name = "Hammad";
    }
    string getPassengerName()
    {
        return passenger_name;
    }
};
class Car
{
private:
    Engine engine;
    Passenger *psg;

public:
    Car(Passenger p1)

    {
        psg=&p1;
      psg->set_psg();
    }
    void show_Car()
    {
        cout << "Passenger Name:" << psg->getPassengerName() << endl;
        cout << "Engine Number:" << engine.get_eng_num() << endl;
    }
};
main()
{
    Passenger psg1;
    Car c1 (psg1);
    c1.show_Car();
}