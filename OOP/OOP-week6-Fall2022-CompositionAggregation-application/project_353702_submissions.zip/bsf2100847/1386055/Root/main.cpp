/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
#include<string>
using namespace std;

class Engine
{
private:
	string Engine_num;
public:
	Engine()
	{
	}
	Engine(string i)
	{
		Engine_num = i;
	}
	string get_Engine_Num()
	{
		return Engine_num;
	}
};

class Passenger
{
private:
	string passenger_name;
public:
	Passenger()
	{
	}
	void set_passenger_name(string i)
	{
		passenger_name = i;
	}
	string get_passenger_name()
	{
		return passenger_name;
	}
};

class Car
{
private:
	Passenger* passenger;
	Engine engine;
public:
	Car()
	{

	}
	Car(Passenger* passenger1, Engine e)
	{
		passenger = passenger1;
		engine = e;
		passenger->set_passenger_name("muqadas");

	}
	void Show()
	{
		cout << passenger->get_passenger_name() << endl;
		cout << engine.get_Engine_Num();
	}


};
int main()
{
	Passenger* passenger = new Passenger();
	Engine engine("146578798905454");
	Car c1(passenger, engine);


	c1.Show();
	return 0;
}