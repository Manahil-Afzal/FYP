/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;
class Engine{
	public:
		string engine_no;
		Engine()
		{
			engine_no="111223344";
		}
		string get_engine_no()
		{
			return engine_no;
		}
};
class Passenger{
	private:
		string passenger_name;
		public:
			void set_passenger_name(string name)
			{
				passenger_name=name;
			}
			string get_passenger_name()
			{
				return passenger_name;
			}
};
class car{
	private:
		Engine engine;
		string name;
		string name1;
		Passenger*passenger;
		public:
			car(Passenger passenger1,string name2)
			{
				name1=name2;
			 passenger=&passenger1;
				passenger->set_passenger_name(name1);
			}
string show()
{
	cout<<"Car Engine Number"<<"\t"<<engine.get_engine_no()<<endl;
	cout<<"Passenger Name"<<"\t\t"<<passenger->get_passenger_name();
}
};
int main(){
string name1="Hassnain Imran";
Passenger passenger2;
car c1(passenger2,name1);
c1.show();
return 0;
}

