/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;

class Engine
{
private:
	int engine_number;
public:
	void setEngine_number(int engNo)
	{
		this->engine_number = engNo;
	}
	int getengine_number()
	{
		return engine_number;
	}
};

class Passenger
{
private:
	string passanger_name;
public:
	Passenger(string passengerName)
	{
		this->passanger_name = passengerName;
	}
	string getPassengerName()
	{
		return passanger_name;
	}
};
class Car
{
	Engine eng;
	Passenger* pasngr;
public:
	Car(int engNO, Passenger& psng)
	{
		this->eng.setEngine_number(engNO);
		pasngr = new Passenger(psng);
	}
	void display()
	{
		cout << "Engine Number: " << eng.getengine_number() << endl;
		cout << "Passanger Name: " << pasngr->getPassengerName() << endl;
	}
};

int main()
{
	int engineNumber = 550;
	string psngrName = "khan";

	Passenger psn(psngrName);
	Car ca(engineNumber, psn);
	ca.display();
	return 0;
}