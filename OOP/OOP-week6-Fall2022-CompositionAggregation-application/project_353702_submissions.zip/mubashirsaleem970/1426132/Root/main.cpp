/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
using namespace std;
class Car
{
public:
  string passenger;
  Car (string passenger_n)
  {
    passenger = passenger_n;
  };

};

class Passenger
{
public:
  Car * passenger_name;

};
class Engine
{
public:
  int engine_number;
  Car *passenger_name;
  void display (int engine_numb, Car * passenger_n)
  {
    passenger_name = passenger_n;
    engine_number = engine_numb;
    cout <<"Engine NO:"<<engine_number << endl;
    cout <<"Passenger Name:"<<passenger_name->passenger;
  }
};

int
main ()
{
  Car obj1 = Car ("Ahmad");
  Engine obj2;
  obj2.display (3344, &obj1);
}
