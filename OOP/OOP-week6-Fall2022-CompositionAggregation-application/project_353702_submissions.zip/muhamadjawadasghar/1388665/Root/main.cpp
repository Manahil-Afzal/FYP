/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
using namespace std;

class Engine
{
private:
    int engine_number;

public:
    Engine(int engineno)
    {
        engine_number = engineno;
    }
    int getEngineNo()
    {
        return engine_number;
    }
};

class Passenger
{
private:
    string passenger_name;

public:
    Passenger(string name)
    {
        passenger_name = name;
    }
    string getPassengerName()
    {
        return passenger_name;
    }
};

class Car
{
private:
    Engine engine;
    Passenger passenger;

public:
    Car(int engineno, string name) : engine(engineno), passenger(name) {}
    void displayCarDetails()
    {
        cout << "Engine number: " << engine.getEngineNo() << endl;
        cout << "Passenger name: " << passenger.getPassengerName() << endl;
    }
};

int main()
{
    int engine_number;
    string passenger_name;
    cout << "Enter engine number: ";
    cin >> engine_number;
    cout << "Enter passenger name: ";
    cin >> passenger_name;
    Car car(engine_number, passenger_name);
    car.displayCarDetails();
    return 0;
}