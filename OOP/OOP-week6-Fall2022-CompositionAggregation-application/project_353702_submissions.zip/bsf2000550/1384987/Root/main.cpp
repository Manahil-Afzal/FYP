#include <iostream>
using namespace std;

class Engine
{
private:
	int engine_number;
public:
	void setEngine_number(int engNo)
	{
		this->engine_number = engNo;
	}
	int getengine_number()
	{
		return engine_number;
	}
};

class Passenger
{
private:
	string passanger_name;
public:
	Passenger(string passengerName)
	{
		this->passanger_name = passengerName;
	}
	string getPassengerName()
	{
		return passanger_name;
	}
};
class Car
{
	Engine eng;
	Passenger* pasngr;
public:
	Car(int engNO, Passenger& psng)
	{
		this->eng.setEngine_number(engNO);
		pasngr = new Passenger(psng);
	}
	void display()
	{
		cout << "Engine Number: " << eng.getengine_number() << endl;
		cout << "Passanger Name: " << pasngr->getPassengerName() << endl;
	}
};

int main()
{
	int engineNumber = 550;
	string psngrName = "khan";

	Passenger psn(psngrName);
	Car ca(engineNumber, psn);
	ca.display();
	return 0;
}