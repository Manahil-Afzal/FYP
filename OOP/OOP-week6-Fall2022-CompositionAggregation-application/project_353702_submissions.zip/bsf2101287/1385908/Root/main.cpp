/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;


class Engine{
	string engine_number;
	public:
	Engine(){
		engine_number = "222";
	}
	string get_engine_no(){
		return engine_number;
	}
};

class Passenger{
	string passenger_name;
	public:
	void set_passenger_name(string p_name){
		this-> passenger_name = p_name;
	}
	string get_passenger_name(){
		return passenger_name;
	}
};
class Car{
	Engine engine;
	Passenger *passenger_name;
	public:
	void input(Passenger p2){
		passenger_name = &p2;
		
	}
	void check(){
	    passenger_name->set_passenger_name("Zohaib");
	}
	void display(){
		cout<<"Engine Number is : "<<engine.get_engine_no()<<endl;
		cout<<"Passenger Name is :"<<passenger_name->get_passenger_name();
	}
};

int main(){
	Car c1;
	Passenger p1;
c1.input(p1);
c1.check();
c1.display();
}