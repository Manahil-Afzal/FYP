/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine{
    private:
    string eng_number;
    public:
    Engine(){
        eng_number="BMX1122";
    }
    string getEng_Number(){
        return eng_number;
    } 
    
};
class Passenger{
    private:
    string Passenger_Name;
    public:
     void setName(string name){
         Passenger_Name=name;
     } 
     string getName(){
         return Passenger_Name;
     }
};

class Car{
  private:
  Engine engine;
  Passenger* passenger;
  public:
    Car(Passenger psngr){
     passenger=&psngr;    
     passenger->setName("Hamza");
     
 }
 
  void get(){
     cout<<"Engine Number : " <<engine.getEng_Number()<<endl;
      cout<<"Passenger Name : "<<passenger->getName()<<endl;
  }
  
  
};



int main(){
    Passenger PSNG;
    Car car(PSNG);
    car.get();
    return 0;
}