/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include<string>
using namespace std;
class Engine
{
    public:
    int number;
   
    void setnumber(int num)
    {
        number=num;
    }
    int getnumber()
    {
        return  number; 
    }
};
class Passenger {
public:
string name;
 Passenger(string name)
{ 
this->name = name;
}
};

class Car
{
public:
string carnum;
Engine engine;
 Passenger*  passenger;

Car()
{
    carnum="775";
    engine.setnumber(76);
}
string name;
Car(string name,  Passenger*  passenger)
{
this->name = name;
this-> passenger =  passenger;
}
void showcar()
{
    cout<<carnum;
    cout<<engine.getnumber();
}
void display()
{
cout<< name<< " "<< passenger->name<<endl;
}
};
int main(void) {
 Passenger p1=  Passenger("Nabga");
Car c1 = Car("Roll Royce",&p1);
Car c2;
c2.showcar();

c1.display();
return 0;
}
