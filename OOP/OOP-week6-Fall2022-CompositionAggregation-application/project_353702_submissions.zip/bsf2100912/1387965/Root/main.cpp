/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine{
	int engine_number;
	public:
		Engine(){
			engine_number=123;
		}
		int get_engine_number(){
			return engine_number;
		}
};
class Passenger{
	string passenger_name;
	public:
		void set_passenger_name(string name){
			this->passenger_name=name;
		}
		string get_passenger_name(){
			return passenger_name;
		} 
};
class Car{
	Engine engine;
	Passenger *passenger;
	public:
	Car(Passenger p1){
		passenger=&p1;}
		void check(){
		passenger->set_passenger_name("Usama");
	}
	void display(){
		cout<<"Engine number:"<<engine.get_engine_number()<<endl;
		cout<<"Passenger name:"<<passenger->get_passenger_name();	
	}
};
int main(){
	Passenger p2;
	Car obj(p2);
	obj.check();
	obj.display();
}