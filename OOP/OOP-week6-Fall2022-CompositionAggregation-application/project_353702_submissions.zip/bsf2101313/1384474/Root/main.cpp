/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
using namespace std;

class Engine{
	private:
		string engNum;
	public:
		Engine(){
		engNum = "LHR2020";
	}
	string getX(){
		return engNum;
	}
};

class Passenger{
	private:
		string passengerName;
	public:
		Passenger(){
			passengerName = "Tanveer Hussain";
		}
		string getY(){
		return passengerName;
		}	
	
};

class Car{
	private:
		Engine engine;
		Passenger *passenger;
		string name;		
	public:	
	Car(Passenger passenger1){
		passenger = &passenger1;
	}	
	
	void display(){
		cout<<"The engine number is : "<<engine.getX()<<endl;
		cout<<"The passenger name is : "<<passenger->getY();
	}
};

int main(){
	Passenger passenger2;
	Car c1(passenger2);
	c1.display();
	return 0;
}