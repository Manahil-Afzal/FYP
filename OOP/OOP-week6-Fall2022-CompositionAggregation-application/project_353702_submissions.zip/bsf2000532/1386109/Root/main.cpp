/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
#include<string>
using namespace std;

class Engine{
	private:
		string eng_num;
		
	public:
		void set_eng_num(string num)
		{
			eng_num=num;
		}
		string get_eng_num(){
			return eng_num;
		}
};

class passanger{
	private:
		string passanger_name;
		Engine engine;
	public:
		passanger(){
			passanger_name="Abdullah Tanveer";
			engine.set_eng_num("1111764056156");
		}
		void show_passanger(){
			cout<<"Passanger Name is: "<<passanger_name<<endl;
			cout<<"Engine Number is: "<<engine.get_eng_num();
		}
};

int main()
{
	passanger p1;
	p1.show_passanger();
	return 0;
}