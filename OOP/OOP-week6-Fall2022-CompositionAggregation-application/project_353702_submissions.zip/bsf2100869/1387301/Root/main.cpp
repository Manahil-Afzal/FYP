/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;
class Engine
{
	string eng_num;	
	public:
		Engine ()
		{
			eng_num="AKE4258";
		}
		
		string putengdata()
		{
			return eng_num;
		}
};

class Passenger
{
	string passenger_name;
	public:
	void getpassengerdata(string name)
	{
		passenger_name=name;
	}
	
	string putpassengerdata()
	{
		return passenger_name;
	}	
};

class Car 
{
	Engine engine;
	Passenger *passenger;
	public:
		Car (Passenger obj)
		{
			passenger=&obj;
			passenger->getpassengerdata("FAIZAN");
		}
		
		void putdata()
		{
			cout<<"Engine number is: "<<engine.putengdata()<<endl;
			cout<<"Passenger name is: "<<passenger->putpassengerdata()<<endl;
		}
};
int main()
{
	Passenger pass;
	Car c1(pass);
	c1.putdata();
	return 0;
}