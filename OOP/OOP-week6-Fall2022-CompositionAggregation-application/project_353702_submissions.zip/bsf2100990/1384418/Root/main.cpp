/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger
which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;
class Engine{
 string engine_no;
 public:
 Engine(){
 	engine_no="111";
 }
	 string get_engine_no(){
	 	return engine_no;
	 }
};
class Passenger{
	string passenger_name;
	public:
	void set_passenger_name(string p2_name){
		passenger_name=p2_name;
	}
	string get_passenger_name(){
		return passenger_name;
	}
};
class Car{
	Engine engine1;
    Passenger *passenger1;
    public:
    void input(Passenger p3){
    	passenger1=&p3;
	    passenger1->set_passenger_name("M_REHMAN");
	}
	void display(){
		cout<<"passenger name:"<<passenger1->get_passenger_name();
	    cout<<"\nengine no"<<engine1.get_engine_no();
	}
};
int main (){
	Car c1;
    Passenger p2;
	c1.input(p2);
    c1.display();
}