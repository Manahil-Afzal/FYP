/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine{
int en;
public:
Engine (){
}
Engine (int i){
en=i;
}
int showEN(){
return en;
}
};
class Passenger{
string pass_name;
public:
void setPassname(string pname){
pass_name=pname;
}
string showPassName(){
return pass_name;
}
};
class Car{
Passenger *p;
Engine e;
public:
Car(Passenger P, Engine E){
p=&P;
e=E;
}
void showCar(){
cout << "ZSB" << p->showPassName() << endl;
cout << e.showEN();
}
};
int main ()
{
Passenger pa;
Engine eng=459;
Car c(pa,eng);
c.showCar();
return 0;
}
