/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
#include<string>
using namespace std;
class Engine {
private:
	string engine_number;
public:
	Engine(string a) {
	engine_number = a;
}
	string getEngineNumber()
	{
		return this->engine_number;
	}
};
class Passenger {
private:
	string passenger_name;
public:
	Passenger(string n) {
	passenger_name = n;
 }
	string getPassengerName()
	{
		return this->passenger_name;
	}
};
class Car {
private:
	Engine* engine;
	Passenger* passenger;
public:
	Car(Engine* engine, Passenger* passenger)
	{
		this->engine = engine;
		this->passenger = passenger;
	}
	void display()
	{
		cout << "Engine Number: " << engine->getEngineNumber()<<endl;
		cout << "Passenger Name: " << passenger->getPassengerName();
	}
};
int main()
{
	Engine eng("LZX-8932");
	Passenger pass("Raza");
	Car newCar(&eng, &pass);
	newCar.display();

}

