/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/


#include<iostream>
using namespace std;
class Engine{
  public:
  string Engine_no;
  
  Engine(){
    
    Engine_no="1234AZ5678"; 
         }
   string getX(){
   return  Engine_no;
     
       }		
};

class Passenger{
private:
string Passenger_name;

public:
void set_Passenger_name(string name)
{
Passenger_name = name;
}
string get_Passenger_name(){
return Passenger_name;
}
};


class Car{
public:	
Engine obj;
string name;	
string name1;
Passenger *passenger;
public:
Car (Passenger passenger1, string name2)
{
name1=name2;
passenger=&passenger1;
passenger->set_Passenger_name(name1);

}
string display(){
	cout<<endl;
 cout<<"Your Car Engine Number : "<<"\t\t  "<<obj.getX()<<endl;
  cout<<"Your Passenger  Name : "<<"\t\t\t\3\3 " <<passenger->get_Passenger_name()<<" \3\3";
 	
}
 
};



int main (){

	
  string name1= "Ahmad Awan ";
  Passenger obj2;
  Car s1(obj2, name1);
  s1.display();
  return 0;
	
}
