/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine{
  private:
  string engine_number;
  
  public:
  Engine(){
      engine_number="LEV786";
  }
  string get (){
      return engine_number;
  }
    
};
class Passenger{
    private:
    string passenger_name;
    public:
    void input(string name){
        passenger_name=name;
        
    }
    string send(){
        return passenger_name;
    }
    
};
class Car{
  private:
  Engine engine;
  Passenger *passenger;
  
  public:
  Car(Passenger psngr){
      passenger=&psngr;
  }
  void put(){
      passenger->input("Subhan");
  }
  void display(){
      cout<<"Engine Number : "<<engine.get()<<endl;
      cout<<"Passenger Name : "<<passenger->send();
  }
    
};



int main(){
    Passenger P1;
    Car car(P1);
    car.put();
    car.display();

    return 0;

}