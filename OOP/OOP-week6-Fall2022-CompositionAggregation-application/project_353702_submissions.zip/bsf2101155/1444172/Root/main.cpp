/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
using namespace std;
class engine{
    private:
    string engineNumber;
    public:
    void set_engineNumber(string num1){
        engineNumber=num1;
    }
    string get_engineNumber(){
        return engineNumber;
    }
};
class passenger{
    private:
    string passengerName;
    public:
    void set_passengerName( string name2){
        passengerName=name2;
    }
    string get_passengerName(){
        return passengerName;
    }
};
class car{
    private:
    //string carNum;
    engine Engine;
    passenger *Passenger;
    public:
    car(){
        Engine.set_engineNumber("75543");
    }
    car(passenger passenger1)
    {
       
        Passenger=&passenger1;
        Passenger->set_passengerName("naima");}
        void get(){
            
       cout<< Passenger->get_passengerName()<<endl;
    }void display(){
        cout<<Engine.get_engineNumber()<<endl;
    }};
    int main(){
        passenger P2;
        car c1(P2);
        c1.get();
        car c2;
        c2.display();
        return 0;
    }