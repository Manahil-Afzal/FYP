/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
#include<string>
using namespace std;
class Engine{
public:
 string eng_no;
 public:
 Engine(){
 	eng_no="220990";
 	
 }	
 string get_eng_no(){
 
 	return eng_no;
 }
};
class Passengr{
	private:
		string passenger_name;
		public:
			void set_passenger(){
				passenger_name="Name";
			}
			string getpassenger_name()
			{
				return passenger_name;
			}
};
class car{
	private:
		Engine engine;
		Passengr*passenger;
		public:
			car(Passengr p)
			{
				passenger=&p;
				passenger->set_passenger();
			}
			void show_car(){
				cout<<"Passenger Name:"<<passenger->getpassenger_name()<<endl;
				cout<<"Enter Number:"<<engine.get_eng_no()<<endl;
			}
		};
		 main(){
			Passengr  p;
			car cl(p);
			cl. show_car();
			return 0;

 }		
