/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;
class Course{
	protected:
		int course_Id;
	public:
	    void input(){
	    	cout<<"Enter course ID: ";
	    	cin>>course_Id;
	    }
};
class IT : public virtual Course{
	public:
		void display(){
			cout<<"Course ID is : "<<course_Id<<endl;
		}
};
class CS : public virtual Course{
	public:
		void display(){
			cout<<"Course ID is : "<<course_Id<<endl;
		}
}; 
class SOS_Course:  public IT, CS{
	public:
		void display(){
			cout<<"Course ID is : "<<course_Id<<endl;
		}
};
int main (){
	SOS_Course obj;
	obj.input();
	obj.display();
}