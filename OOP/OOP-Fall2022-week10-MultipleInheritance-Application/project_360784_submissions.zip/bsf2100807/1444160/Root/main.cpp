/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Course{
    public:
    int CourseId;
    void input(){
        cout<<"enter course id: ";
        cin>>CourseId;
    }
};
class  IT:public virtual Course{

    public:
    int display(){
        cout<<CourseId<<endl;
        return 0;
    }
};
class CS:public virtual Course{
    public:
    int display(){
        cout<<CourseId<<endl;
        return 0;
    }
};
class SOS_course:public IT,public CS{
    public:
    int display(){
       cout<<"Course id enter by user is : "<<CourseId<<endl;
       return 0;
    }
};
int main(){
    SOS_course S1;
    S1.input();
    S1.display();
    return 0;
}