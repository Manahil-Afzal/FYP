/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;

class Course{
    public:
    int id=0;
    public:
    void input()
    {
        cout<<"enter course id :"<<endl;
        cin>>id;
        
    }
    
};
 
 class CS :public Course{
     public:
     void display()
     {
         cout<<"Course id in CS= " <<id;
         
     }
     
 };
 class IT: public Course{
     public:
      void display_1()
     {
         cout<<"Course id in IT = " <<id;
         
     }
     
 };
 
 
 class SOS_course:public IT,public CS{
     
 };
 int main()
 {
     SOS_course s1;
     CS c;
     c.input();
     s1.display();
 }
  