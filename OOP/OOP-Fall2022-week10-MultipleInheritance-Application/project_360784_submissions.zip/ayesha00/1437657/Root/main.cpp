/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course{
	protected:
		int id;
		public:
			void input(){
				cout<<"Enter the course id: "<<endl;
				cin>>id;
			}
};
class IT:virtual public course{
	public:
		void display(){
			cout<<"course ID is: "<<id<<endl;
			
		}
};
class CS: virtual public course{
	public:
		void display(){
			cout<<"course ID is: "<<id<<endl;
		}
};
class SOS_course : public IT, public CS{
	public:
	void display(){
		cout<<"course ID is:  "<< id <<endl;
	}
};
int main(){
	SOS_course s;
	s.input();
	s.display();
	return 0;
}