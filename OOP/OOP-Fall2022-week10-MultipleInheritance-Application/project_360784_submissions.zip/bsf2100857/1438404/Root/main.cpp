/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
#include<string.h>
using namespace std;
class Course {
protected:
	string courseid;
public:
	void input(string id) {
		courseid = id;
	}
	void display() {
		cout << "course id ";
		cout << courseid<<endl;
	}
};
class IT :virtual public Course {
public:
	void display() {
		cout << "course id for IT ";
		cout << courseid<<endl;
	}
};
class CS :virtual public Course {
public:
	void display() {
		cout << "course id for CS ";
		cout << courseid<<endl;
	}
};
class SOS_Course :virtual public CS,public IT {
public:
	void display() {
		cout << "course id for SOS ";
		cout << courseid;
	}
};
int main() {

	
	SOS_Course obj1;
	obj1.Course::input("bsf2100857");
	obj1.Course::display();
	obj1.CS::display();
	obj1.IT::display();
	obj1.SOS_Course::display();
}