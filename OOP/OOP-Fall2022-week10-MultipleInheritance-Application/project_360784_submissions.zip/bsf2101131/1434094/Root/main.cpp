/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;

class Course{
	protected:
		string course_id;
	public:
		void input(){
			cout<<"Enter your course id: ";
			cin>>course_id;
		}
};

class IT : virtual  public Course{
	public:
		void display1(){
			cout<<"Your course id: "<<course_id<<endl;
		}
};

class CS :virtual public Course{
	public:
		void display2(){
			cout<<"Your course id: "<<course_id<<endl;
		}
};

class SOS_Course : public IT, public CS{
	public:
		void display3(){
			cout<<"Your course id: "<<course_id<<endl;
		}
};

int main(){
	SOS_Course obj1;
	obj1.input();
	obj1. display1();
	obj1.display2();
	obj1.display3();
}