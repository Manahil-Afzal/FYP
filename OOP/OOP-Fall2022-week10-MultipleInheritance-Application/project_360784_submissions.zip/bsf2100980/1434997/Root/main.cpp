/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;
class Course{
	protected:
	int course_id;
	public:
	void input()
	{
		cout<<"Enter course id"<<endl;
		cin>>course_id;
	}
};
class IT:virtual public Course{
	public:

	void display1()
	{
		cout<<"The course id is "<<course_id;
	}
};
class CS:virtual public Course{
	public:

	void display2()
	{
		cout<<"The course id is "<<course_id;
	}
};
class SOS_course:public IT,public CS{
	
};

int main(){
	SOS_course C;
	C.input();
	C.display1();
    return 0;
}