/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Course {
    public:
    int course_id;
    void getdata(){
    cout<<"enter the course id";
    cin>>course_id;
    }
};
class IT: virtual public Course {
    void display(){
        cout<<"enter the course id";
    cin>>course_id;
        }
};
class CS: virtual public Course {
    void display(){
        cout<<"enter the course id";
    cin>>course_id;
        }
};
class SOS_Course: virtual public IT, CS {
    public:
    void display(){
        cout<<"enter the course id";
    cin>>course_id;
        }
};
int main(){
    SOS_Course s;
    s. getdata();
    s. display();
}