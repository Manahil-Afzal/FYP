/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;

class Course
{
public:
string CourseID;
public:
void input ()
  {
cout<<"Enter CourseID:";      
cin >> CourseID;
} 
void display (){
    cout << "CourseID of Course Class:"<< CourseID;
} 
};
class IT:virtual public Course{
};
class CS:virtual public Course{
};
class SOS_Course:public CS, public IT{
};
int main (){
SOS_Course obj;
obj.input ();
obj.display ();
}
