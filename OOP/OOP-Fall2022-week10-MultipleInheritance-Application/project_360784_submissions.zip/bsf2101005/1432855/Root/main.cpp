/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course{
    protected:
  int id;
  public:
  void input(){
      cout<<"enter the id"<<endl;
      cin>>id;
  }
};
class IT:public virtual course{
    public:
    int display(){
    cout<<id<<endl;
    return id;
    }
};
class CS:public  virtual course{
    public:
    int display(){
        cout<<id<<endl;
        return id;
    }
};
class sos_course:public IT, public CS{
  public:
  int display(){
      cout<<id<<endl;
      return id;
  }
};
int main(){
    sos_course S1;
    S1.input();
    S1.display();
    return 0;
}