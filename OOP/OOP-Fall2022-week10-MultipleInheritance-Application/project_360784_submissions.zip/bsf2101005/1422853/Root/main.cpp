/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Employee{
    protected:
    string name;
    int id;
    int workingHours;
    int perHourSalary;
    int salary;
    public:
    void set_name(string name1)
    {
        name=name1;
    }
    void set_id(int id1)
    {
        id=id1;
    }
    void set_workingHours(int hours)
    {
        workingHours=hours;
    }
    void set_perHourSalary(int salary)
    {
        perHourSalary=salary;
    }
};
class Adhoc_employee:public Employee
{
    public:
    int getSalary()
    {
        int salary;
        salary=workingHours*perHourSalary;
        return salary;
    }
    void display_info()
    {
        cout<<"the information of employee is"<<endl;
        cout<<name<<endl;
        cout<<id<<endl;
        cout<<workingHours<<endl;
        cout<<perHourSalary<<endl;
    }
};
int main()
{
    Adhoc_employee A1;
    A1.set_name("fiza");
    A1.set_id(747563);
    A1.set_workingHours(21);
    A1.set_perHourSalary(200);
    A1.display_info();
    cout<<"the salary is"<<A1.getSalary()<<endl;
    return 0;
}