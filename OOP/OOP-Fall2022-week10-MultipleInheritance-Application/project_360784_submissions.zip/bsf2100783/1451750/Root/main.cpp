/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Shape
{
    public: double a,b;
        void get_data ()
        {
cin>>a>>b;
        }
        virtual void display_area () = 0;
};

class Triangle:public Shape
{
    public: void display_area ()
    {
cout<<"Area of triangle: "<<0.5*a*b<<endl;
    }
};

class Rectangle:public Shape
{
    public: void display_area ()
    {
cout<<"Area of rectangle: "<<a*b<<endl;
    }
};

class Circle:public Shape
{
	public: void display_area ()
	{
		cout<<"Area of Circle:"<<3.14*a*a<<endl;
	}
};
int main()
{   
    Triangle t;
    Shape *st = &t;
cout<<"Enter Length and Width : ";
st->get_data();
st->display_area();

    Rectangle r;
    Shape *sr = &r;
cout<<"Enter Base and Height : ";
sr->get_data();
sr->display_area();   

    Circle c;
    Shape *sc =&c;
cout<<"Enter radius: ";
sc->get_data();
sc->display_area();
}
