/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course{
	protected:
	   string course_id;
	public:
		void input()
		{
			cout<<"Enter course id = ";
			cin>>course_id;
		}
};
class IT: virtual public course{
	public:
		void display1()
		{
				cout<<" \nThe course id is = ";
			cout<<course_id<<endl;
		}
		
};
class CS: virtual public course{
	public:
		void display2()
		{
			cout<<"The course id is = ";
			cout<<course_id<<endl;
		
			
		}
};
class SOS_course: public IT, public CS{
	
	public:
		void display3()
		{
			cout<<"The course id is = "<<course_id;
		
		
			
		}
};

int main (){
            SOS_course s1;
          s1.input();
            s1.display1();
            s1.display2();
            s1.display3();
          
}