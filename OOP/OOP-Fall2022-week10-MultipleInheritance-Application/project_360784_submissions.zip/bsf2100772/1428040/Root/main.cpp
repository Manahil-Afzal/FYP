/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;
class Course {
  protected:
  string course_id;
  
  public:
  void Cset(){
      cout<<"ENter the course id :"<<endl;
      cin>>course_id;
  }
    void display(){
        cout<<"Course ID : "<<course_id<<endl;
    }
    
};
class IT: virtual public Course{
  public:
  void display(){
        cout<<"Course ID : "<<course_id<<endl;
    }
  
};
class CS: virtual public Course{
    protected:
    void display(){
        cout<<"Course ID : "<<course_id<<endl;
    }
    
};

class SOS_Course:public IT, public CS{
    public:
    void display(){
        cout<<"Course ID : "<<course_id<<endl;
    }
    
    
};

int main(){
    SOS_Course SC;
    SC.Cset();
    SC.display();
    
return 0;    
}