/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
#include<string>

using namespace std;
class Employee
{
	public:
		string Name;
		int Id;
		int NumofWorkingHours;
		double perHourSalary;	
};

class Adhoc_employee:public Employee {
	public:
		double salary() {
			return NumofWorkingHours*perHourSalary;
		void displayDetails();
}

void displayDetails() {
	cout<<"Enter employee name:"<<Name<<endl;
	cout<<"Enter employee Id:"<<Id<<endl;
	cout<<"Enter Number of Working Hours of employee:"<<NumofWorkingHours<<endl;
	cout<<"Enter per hour salary for employee:"<<perHourSalary<<endl;
	cout<<"Salary:$"<<salary()<<endl; 
	}
};

int main()
{
	Adhoc_employee employee;
	employee.Name="Najam";
    employee.Id=433046;
    employee.NumofWorkingHours=14;
    employee.perHourSalary=15.50;
    employee.displayDetails();
	return 0;
}