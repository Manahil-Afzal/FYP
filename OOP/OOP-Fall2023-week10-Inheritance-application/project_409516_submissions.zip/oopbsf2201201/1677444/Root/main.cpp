/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>

class Employee {
protected:
    std::string name;
    int id;
    double hoursWorked;
    double hourlySalary;

public:
    // Constructor
    Employee(std::string n, int i, double hours, double salary)
        : name(n), id(i), hoursWorked(hours), hourlySalary(salary) {}

    // Virtual function to be overridden by derived class
    virtual double salary() const = 0;

    // Virtual function to be overridden by derived class
    virtual void display_info() const = 0;
};

class Adhoc_employee : public Employee {
public:
    // Constructor
    Adhoc_employee(std::string n, int i, double hours, double salary)
        : Employee(n, i, hours, salary) {}

    // Override the salary method
    double salary() const override {
        return hoursWorked * hourlySalary;
    }

    // Override the display_info method
    void display_info() const override {
        std::cout << "Employee Name: " << name << std::endl;
        std::cout << "Employee ID: " << id << std::endl;
        std::cout << "Hours Worked: " << hoursWorked << std::endl;
        std::cout << "Hourly Salary: $" << hourlySalary << std::endl;
        std::cout << "Total Salary: $" << salary() << std::endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee employee1("John Doe", 1234, 40, 20);

    // Display information and salary for the employee
    employee1.display_info();

    return 0;
}