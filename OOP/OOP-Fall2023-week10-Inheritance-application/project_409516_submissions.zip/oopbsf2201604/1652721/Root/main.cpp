/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee
{
protected:
    string name, ID;
    int Whours, salaryph;

public:
    void getdetails()
    {
        cout << "Enter Name of the Employee: ";
        cin >> name;
        cout << "Enter Employee ID: ";
        cin >> ID;
        cout << "Enter Working hours: ";
        cin >> Whours;
        cout << "Enter Salary per Hour: ";
        cin >> salaryph;
    }
};

class Adhoc_employee : public Employee
{
public:
    int salary()
    {
        int Total_Salary = Whours * salaryph;
        return Total_Salary;
    }

    void Display()
    {
        cout << "The details of the Employee are:" << endl;
        cout << "Name: " << name << endl;
        cout << "Employee ID: " << ID << endl;
        cout << "Working hours: " << Whours << endl;
        cout << "Salary per Hour: " << salaryph << endl;
        cout << "Total Salary: " << salary() << endl;
    }
};

int main()
{
    Adhoc_employee Employee1;
    Employee1.getdetails();
    Employee1.Display();
    return 0;
}
