/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The
display_info method displays the complete information of employee. Create an object of Adhoc_employee and display the information and salary against 
that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    double NumWorkingHours;
    double PerHourSalary;

public:
    Employee(const string& name, int id, double hours, double salary)
        : Name(name), Id(id), NumWorkingHours(hours), PerHourSalary(salary) {}

    double calculateSalary() {
        return NumWorkingHours * PerHourSalary;
    }

    void displayInfo() {
        cout << "Employee Name: " << Name << endl;
        cout << "Employee ID: " << Id << endl;
        cout << "Working Hours: " << NumWorkingHours << endl;
        cout << "Per Hour Salary: " << PerHourSalary << endl;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(const string& name, int id, double hours, double salary)
        : Employee(name, id, hours, salary) {}

    void displayInfo() {
        Employee::displayInfo();
        cout << "Salary: " << calculateSalary() << endl;
    }
};

int main() {
    // Create an object of AdhocEmployee
    AdhocEmployee employee("daniyal", 101, 40, 20.0);

    // Display information and salary for the employee
    cout << "Employee Information and Salary:" << endl;
    employee.displayInfo();

    return 0;
}