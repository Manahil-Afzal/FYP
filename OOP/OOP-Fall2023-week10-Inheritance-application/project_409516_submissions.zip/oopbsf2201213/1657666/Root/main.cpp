/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;

class Employee{
    protected:
      string name;
      int id;
      int hours;
      float salary;
};

class Adhoc_employee : public Employee{
    int total_salary;
    public:
        void setter(){
            cout<<"Enter name of the employee "<<endl;
            cin>>name;
            cout<<"Enter ID of the employee "<<endl;
            cin>>id;
            cout<<"ENter hours Employee works "<<endl;
            cin>>hours;
            cout<<"Enter per hour salary of the employee "<<endl;
            cin>>salary;
        }
        
        void salary_count(){
            total_salary = hours * salary;
        }
        
        void display_info(){
            cout<<"The name of the employee is "<<name<<endl;
            cout<<"The ID of the employee is "<<id<<endl;
            cout<<"Employee works for "<<hours<<"hours"<<endl;
             cout<<"The per hour salary of the employee is "<<salary<<endl;
            cout<<"The total salary of the employee is "<<total_salary<<endl;
        }
}; 
int main (){
    Adhoc_employee E1;
    E1.setter();
    E1.salary_count();
    E1.display_info();
}
