/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
# include<iostream>
using namespace std;
class Employee {
    protected :
    string name;
    string id;
    int work_hour;
    int hour_salary;
    
    public :
    
    void setName(string n){
        name = n;
    }
    void setId( string i)
    {
        id = i;
    }
    void set_work_hour( int w){
        work_hour = w;
    }
    void set_hour_salary( int s){
        hour_salary = s;
    }
};
class Adhoc_employee : public Employee{
    public:
    void get_detail(){
        cout<<"Name of employee:"<<name<<endl;
        cout<<"Id of employee:"<<id<<endl;
        cout<<"Work hours of employee"<<work_hour<<endl;
          }
          int get_salary(){
              int wh;
              wh= work_hour * hour_salary;
              cout<< wh <<endl;
          }
};
main(){
    Adhoc_employee Emp;
    Emp.setName("Saba");
  Emp.setId("bsf2201190");
 Emp.set_work_hour(24);
   Emp.set_hour_salary(18);
    cout<< "Information of employee is:"<<endl;
    Emp.get_detail();
    cout<< "Salary of employee is :"<<endl;
    Emp.get_salary();
}
    
