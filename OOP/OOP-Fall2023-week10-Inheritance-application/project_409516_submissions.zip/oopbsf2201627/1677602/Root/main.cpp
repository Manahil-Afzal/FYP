/*Write a C++ program that implements a class hierarchy having a base class 
named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and 
Per hour salary. The derived class implements two methods named salary and 
display_info. The salary method calculates the salary of employee by multiplying
“Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and 
display the information and salary against that instance.*/

#include<iostream>
#include<string>
using namespace std;

class Employee{
    protected:
        string Name;
        string Id;
        double Number_of_working_hours;
        double Per_hour_salary;
    public:
        Employee(string n, string id, double w_hours, double phour_salary) :
            Name(n), Id(id), Number_of_working_hours(w_hours), 
            Per_hour_salary(phour_salary) {}
};

class Adhoc_employee : public Employee{
    private:
        double salary_of_employee;
    public:
    
        Adhoc_employee(string _n, string _id, double _w_hours, double _phour_salary) :
            Employee(_n, _id, _w_hours, _phour_salary) {}
        
        void salary(){
            salary_of_employee = Number_of_working_hours * Per_hour_salary;
        }
        void display_info(){
            cout<<"Name of the employee: "<<Name<<endl
            <<"ID of the emplyee: "<<Id<<endl
            <<"Number of working hours: "<<Number_of_working_hours<<endl
            <<"Per hour salary: "<<Per_hour_salary<<endl
            <<"Salary of employee: "<<salary_of_employee<<endl;
        }
};

int main(){
    
    Adhoc_employee e1("muzamil","bsf2201627",20,100);
    e1.salary();
    e1.display_info();
    return 0;
}




