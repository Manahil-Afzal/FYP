/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
  protected:
  string name;
  int ID;
  float hours;
  float PHS;
  float sal;
};
class Adhoc_employee:public Employee{
  public:
  Adhoc_employee(){}
  Adhoc_employee(string n, int i,float h,float s){
      name=n;
      ID=i;
      hours=h;
      PHS=s;
  }
  void Salary(){
      sal=hours*PHS; 
  }
  void display(){
      cout<<name<<endl;
      cout<<ID<<endl;
      cout<<sal<<endl;}
  };
  int main(){
      Adhoc_employee e1("Taha",23445,7,500);
      e1.Salary();
      e1.display();
  }