/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int HoursWorked;
    double HourlyRate;

public:
    Employee(const std::string& name, int id, int hoursWorked, double hourlyRate)
        : Name(name), Id(id), HoursWorked(hoursWorked), HourlyRate(hourlyRate) {}

    virtual double salary() {
        return HoursWorked * HourlyRate;
    }

    void display_info() {
        std::cout << "Name: " << Name << std::endl;
        std::cout << "Employee ID: " << Id << std::endl;
        std::cout << "Hours Worked: " << HoursWorked << " hours" << std::endl;
        std::cout << "Hourly Rate: $" << HourlyRate << std::endl;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(const std::string& name, int id, int hoursWorked, double hourlyRate)
        : Employee(name, id, hoursWorked, hourlyRate) {}

    double salary() override {
        return Employee::salary();
    }

    void display_info() {
        Employee::display_info();
        std::cout << "Salary: $" << salary() << std::endl;
    }
};

int main() {
    
    AdhocEmployee employee("John Doe", 12345, 40, 15.0);


    std::cout << "Employee Information:\n";
    employee.display_info();

    return 0;
}
