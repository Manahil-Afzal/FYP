/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    Employee(const string& empName, int empId, int hours, double salary)
        : name(empName), id(empId), numWorkingHours(hours), perHourSalary(salary) {}

    virtual double salary() const {
        return numWorkingHours * perHourSalary;
    }

    virtual void displayInfo() const {
        cout << "Name: " << name << std::endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << numWorkingHours << std::endl;
        cout << "Per Hour Salary: " << perHourSalary <<endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& empName, int empId, int hours, double salary)
        : Employee(empName, empId, hours, salary) {}

    double salary() const override {
        return numWorkingHours * perHourSalary;
    }

    void displayInfo() const override {
        cout << "Adhoc Employee Information:" <<endl;
        Employee::displayInfo(); // Display base class information
        cout << "Salary: " << salary() <<endl;
    }
};

int main() {
    // Create an Adhoc_employee object
    Adhoc_employee employee("John Doe", 1234, 40, 15.5); // Example values

    // Display information and salary of the Adhoc_employee
    employee.displayInfo();

    return 0;
}
