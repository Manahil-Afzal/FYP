/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    double NumHours;
    double PerHourSalary;

public:
    Employee(const std::string& name, int id, double numHours, double perHourSalary)
        : Name(name), Id(id), NumHours(numHours), PerHourSalary(perHourSalary) {
    }

    virtual double salary() {
        return NumHours * PerHourSalary;
    }

    virtual void display_info() {
        std::cout << "Name: " << Name << "\n";
        std::cout << "Employee ID: " << Id << "\n";
        std::cout << "Number of working hours: " << NumHours << "\n";
        std::cout << "Per hour salary: $" << PerHourSalary << "\n";
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& name, int id, double numHours, double perHourSalary)
        : Employee(name, id, numHours, perHourSalary) {
    }

    void display_info() override {
        Employee::display_info();
        std::cout << "Salary: $" << salary() << "\n";
    }
};

int main() {
    Adhoc_employee adhoc("John Doe", 12345, 40, 10.5);
    
    std::cout << "Employee Information:\n";
    adhoc.display_info();

    return 0;
}
