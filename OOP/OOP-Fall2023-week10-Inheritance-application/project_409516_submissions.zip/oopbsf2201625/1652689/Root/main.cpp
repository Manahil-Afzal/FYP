/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>

using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    int PerHourSalary;

public:
    Employee(string name, int id, int workingHours, int hourlySalary) {
        Name = name;
        Id = id;
        NumWorkingHours = workingHours;
        PerHourSalary = hourlySalary;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int workingHours, int hourlySalary)
        : Employee(name, id, workingHours, hourlySalary) {
    }

    int salary() {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() {
        cout << "Name: " << Name << endl;
        cout << "Id: " << Id << endl;
        cout << "Number of working hours: " << NumWorkingHours << endl;
        cout << "Per hour salary: " << PerHourSalary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee employee("Zain Ali", 1625, 87, 24);
    employee.display_info();

    return 0;
}
