/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
# include <iostream>
using namespace std;
class Employee{
    protected:
    string name;
    int id;
    int workingHours,PerHourSalary;
    
    
};
class Adhoc_employee:public Employee{
    public:
    void get_info(){
        cout<<"Employee Name: ";
        cin>>name;
        cout<<"Employee ID: ";
        cin>>id;
        cout<<"Employee Worling hours : ";
        cin>>workingHours;
        cout<<"Employee Per Hour Salary: ";
        cin>>PerHourSalary;
    }
    
    void display_info(){
        cout<<"Employee Name: "<<name<<endl;
        cout<<"Employee ID: "<<id<<endl;
        cout<<"Employee Worling hours : "<<workingHours<<endl;
        cout<<"Employee Per Hour Salary: "<<PerHourSalary<<endl;
    }
    void calculateSalary(){
        int salary=workingHours*PerHourSalary;
        cout<<"Calculated Salary of the employee : "<<salary<<endl;
    }
    
};
main(){
    Adhoc_employee a1;
    a1.get_info();
    a1.calculateSalary();
    a1.display_info();
    
}