#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int Number_of_working_hours;
    int Per_hour_salary;

public:
    Employee(std::string Name, int Id, int Number_of_working_hours, int Per_hour_salary) :
        Name(Name), Id(Id), Number_of_working_hours(Number_of_working_hours), Per_hour_salary(Per_hour_salary) {}

    virtual void display_info() const {
        std::cout << "Name: " << Name << '\n';
        std::cout << "ID: " << Id << '\n';
        std::cout << "Number of working hours: " << Number_of_working_hours << '\n';
        std::cout << "Per hour salary: " << Per_hour_salary << '\n';
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(std::string Name, int Id, int Number_of_working_hours, int Per_hour_salary) :
        Employee(Name, Id, Number_of_working_hours, Per_hour_salary) {}

    int salary() const {
        return Number_of_working_hours * Per_hour_salary;
    }

    void display_info() const override {
        Employee::display_info();
        std::cout << "Salary: " << salary() << '\n';
    }
};

int main() {
    Adhoc_employee employee1("Abdullah aziz", 2003, 32, 90);
    employee1.display_info();
    return 0;
}