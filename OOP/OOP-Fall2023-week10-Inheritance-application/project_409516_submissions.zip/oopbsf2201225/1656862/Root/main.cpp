/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee
{
	protected:
	string emp_name;
	int	emp_Id;
	int no_of_workingHours;
	int perHour_salary;
	int salary;
	public:
		void getDetails()
		{
			cout<<"Enter Employee name: "<<endl;
			cin>>emp_name;
			cout<<"Enter Employee ID: "<<endl;
			cin>>emp_Id;
			cout<<"Enter number of working hours: "<<endl;
			cin>>no_of_workingHours;
			cout<<"Enter Per Hour salary: "<<endl;
			cin>>perHour_salary;
		
		}
		
};
class Adhoc_employee:public Employee
{
    protected: 
    int salary;
	public:
	void Salary_calculation()
	{
	salary= no_of_workingHours*	perHour_salary;
	}
	void DisplayDetails()
	{   cout<<"*******Employee Details*******"<<endl;
		cout<<"Employee Name: "<<emp_name<<endl;
		cout<<"Employee ID: "<<emp_Id<<endl;
		cout<<"Number of Working Hours: "<<no_of_workingHours<<endl;
		cout<<"Employee Salary: "<<salary<<endl;
	}
};
int main()
{
	Adhoc_employee employee1;
	employee1.getDetails();
	employee1.Salary_calculation();
	employee1.DisplayDetails();
	
	
}
