/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    float Hours;
    float PerHourSalary;
public:
    Employee(string name, int id, float hours, float perHourSalary) {
        Name = name;
        Id = id;
        Hours = hours;
        PerHourSalary = perHourSalary;
    }

    virtual float salary() {
        return Hours * PerHourSalary;
    }

    virtual void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Working Hours: " << Hours << endl;
        cout << "Per Hour Salary: $" << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, float hours, float perHourSalary)
        : Employee(name, id, hours, perHourSalary) {}

    float salary() override {
        return Employee::salary();
    }

    void display_info() override {
        Employee::display_info();
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 1001, 40, 20); // Creating an object of Adhoc_employee

    emp.display_info(); // Displaying information and salary for the employee

    return 0;
}
