/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee
{
protected:
    string name, ID;
    int num_of_w_hours, per_hour_salary;

public:
};

class Adhoc_employee : public Employee
{
    int sal;

public:
    void input_details()
    {
        cout << "Enter the number of working hours: " << endl;
        cin >> num_of_w_hours;
        cout << "Enter the per hour salary: " << endl;
        cin >> per_hour_salary;
        cout << "enter the name of the employee: " << endl;
        cin >> name;
        cout << "Enter the ID of the employee: " << endl;
        cin >> ID;
    }

    void salary()
    {
        cout << endl;
        sal = num_of_w_hours * per_hour_salary;
        cout << "salary of the employee: " << sal<<endl;
    }

    void display()
    {
        cout << endl;
        cout << "Detail about employee: " << endl;
        cout << "\nEmpolyee's name: " << name << endl;
        cout << "Employee's ID: " << ID << endl;
    }
};

int main()
{
    Adhoc_employee a;
    a.input_details();
    a.salary();
    a.display();
}