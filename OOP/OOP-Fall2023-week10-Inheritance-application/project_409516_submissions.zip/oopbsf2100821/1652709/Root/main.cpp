/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
		int salary;
		string name;
		int id;
		float working_hours;
		float salary_per_hours;
	public:
		void getdata(){
			cout<<"Enter Name :";
			cin>>name;
			cout<<"Enter id :";
			cin>>id;
			cout<<"Enter working hours:";
			cin>>working_hours;
			cout<<"Enter salary per hours:";
			cin>>salary_per_hours;
			
			
			
		}
};
class Adhoc_employee: public Employee{
	public:
		int calsalary(){
		
			salary=  working_hours*salary_per_hours;
			return salary;
		}
		void display(){
			cout<<name<<endl<<id<<endl<<salary;
		}
};
int main()
{
	Adhoc_employee Emp;
	Emp.getdata();
	Emp.calsalary();
	Emp.display();
	return 0;
}