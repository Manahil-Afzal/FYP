/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
#include <string>
using namespace std;

class Employee {
private:
    string name;
    int id;
    double working_hours;
    double perhour_salary;

public:
    Employee(string empName, int empId, double hours, double salaryPerHour){
    name=empName;
	id=empId;
	working_hours=hours;
	perhour_salary=	salaryPerHour;
	}

    double calculateSalary() {
        return perhour_salary * working_hours;
    }

    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << working_hours << endl;
        cout << "Hourly Salary: " << perhour_salary << endl;
        cout << "Total Salary: " << calculateSalary() << endl;
    }
};

int main() {
    
    Employee emp("Ahmed", 2201600, 8, 500);
    emp.displayInfo();

    return 0;
}
