/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int HoursWorked;
    double HourlySalary;

public:
    Employee(const std::string& name, int id, int hoursWorked, double hourlySalary)
        : Name(name), Id(id), HoursWorked(hoursWorked), HourlySalary(hourlySalary) {}

    double salary() {
        return HoursWorked * HourlySalary;
    }

    void display_info() {
        std::cout << "Employee Information:" << std::endl;
        std::cout << "Name: " << Name << std::endl;
        std::cout << "ID: " << Id << std::endl;
        std::cout << "Hours Worked: " << HoursWorked << std::endl;
        std::cout << "Hourly Salary: $" << HourlySalary << std::endl;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(const std::string& name, int id, int hoursWorked, double hourlySalary)
        : Employee(name, id, hoursWorked, hourlySalary) {}

    void display_info() {
        Employee::display_info();
        std::cout << "Salary: $" << salary() << std::endl;
    }
};

int main() {
    AdhocEmployee emp("John Doe", 1001, 40, 15.0); // Creating an object of AdhocEmployee
    emp.display_info(); // Displaying employee information and salary

    return 0;
}
