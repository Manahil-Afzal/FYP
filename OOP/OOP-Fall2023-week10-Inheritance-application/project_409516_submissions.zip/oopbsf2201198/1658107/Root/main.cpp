
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(string name, int id, int hours, double salary)
        : Name(name), Id(id), NumWorkingHours(hours), PerHourSalary(salary) {}

    virtual double salary() {
        return NumWorkingHours * PerHourSalary;
    }

    virtual void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of Working Hours: " << NumWorkingHours << endl;
        cout << "Per Hour Salary: $" << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    double salary() override {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() override {
        cout << "Adhoc Employee Information:" << endl;
        Employee::display_info();
        cout << "Total Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee employee("John Doe", 12345, 40, 20.5);
    employee.display_info();
    return 0;
}
