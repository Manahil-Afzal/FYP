/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    double HoursWorked;
    double PerHourSalary;

public:
    
    Employee(string name, int id, double hoursWorked, double perHourSalary)
        : Name(name), Id(id), HoursWorked(hoursWorked), PerHourSalary(perHourSalary) {}

    
    virtual ~Employee() {}

    // Virtual function to calculate salary
    virtual double calculateSalary() const = 0;

    // Virtual function to display employee information
    virtual void displayInfo() const = 0;
};

class AdhocEmployee : public Employee {
public:
   
    AdhocEmployee(string name, int id, double hoursWorked, double perHourSalary)
        : Employee(name, id, hoursWorked, perHourSalary) {}

    // Override the base class method to calculate salary
    double calculateSalary() const override {
        return HoursWorked * PerHourSalary;
    }

    // Override the base class method to display employee information
    void displayInfo() const override {
        cout << "Employee Name: " << Name <<endl;
       cout << "Employee ID: " << Id <<endl;
        cout << "Hours Worked: " << HoursWorked <<endl;
       cout << "Per Hour Salary: $" << PerHourSalary <<endl;
       cout << "Total Salary: $" << calculateSalary() <<endl;
    }
};

int main() {
    // Create an object of AdhocEmployee
    AdhocEmployee adhocEmployee("John Doe", 1001, 40.0, 15.0);

    // Display information and salary for the AdhocEmployee
    adhocEmployee.displayInfo();

    return 0;
}