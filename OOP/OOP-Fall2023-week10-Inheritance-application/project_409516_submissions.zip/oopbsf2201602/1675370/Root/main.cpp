/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee{
    private:
string name ;
int id,working_hours,per_hour_salary;
public:
Employee(string name,int id,int working_hours,int per_hour_salary){
    this->name=name;
    this->id=id;
    this->working_hours=working_hours;
    this->per_hour_salary=per_hour_salary;
}

int  calculates(){
    return working_hours*per_hour_salary;
}
void displayInfo(){
    cout<<"Name: "<<name<<endl;
    cout<<"Id: "<<id<<endl;
    cout<<"Working Hours: "<<working_hours<<endl;
    cout<<"Per Hour Salary: "<<per_hour_salary<<endl;
    
}

};

class Adhoc_employee:public Employee{
    public:
    Adhoc_employee(string name,int id,int working_hours,int per_hour_salary):Employee(name,id,working_hours,per_hour_salary){
        
    }
    void displayInfo(){
        Employee::displayInfo();
    }
    int calculates(){
        return Employee::calculates();
    }
};


int main(){
    
    Adhoc_employee a("Naeem",1,8,1000);
    a.displayInfo();

    return 0;
}