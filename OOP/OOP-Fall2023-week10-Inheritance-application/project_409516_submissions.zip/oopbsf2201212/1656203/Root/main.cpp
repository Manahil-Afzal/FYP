/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee {
protected:
    std::string Name;
    int Id;
    double NumWorkingHours;
    double PerHourSalary;

public:
    Employee(std::string name, int id, double hours, double salary)
        : Name(name), Id(id), NumWorkingHours(hours), PerHourSalary(salary) {}

    double salary() {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() {
        cout << "Employee Name: " << Name << std::endl;
        cout << "Employee ID: " << Id << std::endl;
        cout << "Number of Working Hours: " << NumWorkingHours << std::endl;
        cout << "Per Hour Salary" << PerHourSalary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(std::string name, int id, double hours, double salary)
        : Employee(name, id, hours, salary) {}

    void display_info() {
        Employee::display_info();  
        std::cout << "Salary:" << salary() << std::endl;
    }
};

int main() {
    Adhoc_employee adhoc("Ali", 12345, 40, 15.5); 
    adhoc.display_info();  

    return 0;
}
