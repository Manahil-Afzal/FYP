/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int WorkingHours;
    double PerHourSalary;

public:
    Employee(const std::string& name, int id, int hours, double perHourSalary)
        : Name(name), Id(id), WorkingHours(hours), PerHourSalary(perHourSalary) {}

    virtual double salary() const {
        return WorkingHours * PerHourSalary;
    }

    virtual void displayInfo() const {
        std::cout << "Employee Information:\n";
        std::cout << "Name: " << Name << "\n"; // Corrected case to use "Name" instead of "name"
        std::cout << "ID: " << Id << "\n";
        std::cout << "Working Hours: " << WorkingHours << "\n";
        std::cout << "Per Hour Salary: $" << PerHourSalary << "\n";
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& name, int id, int hours, double perHourSalary)
        : Employee(name, id, hours, perHourSalary) {}

    double salary() const override {
        // Bonus for Adhoc employees (for example)
        return Employee::salary() + PerHourSalary * 0.10; // Bonus is 10% of per-hour salary
    }

    void displayInfo() const override {
        Employee::displayInfo();
        std::cout << "Total Salary: $" << salary() << "\n";
    }
};

int main() {
    Adhoc_employee adhocEmployee("John Doe", 12345, 40, 15.5);

    adhocEmployee.displayInfo();

    return 0;
}
