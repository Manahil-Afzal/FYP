/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string name;
    int id;
    double hoursWorked;
    double hourlySalary;

public:
    Employee(const std::string& empName, int empId, double hours, double salary)
        : name(empName), id(empId), hoursWorked(hours), hourlySalary(salary) {}

    virtual double salary() {
        return hoursWorked * hourlySalary;
    }

    void display_info() {
        std::cout << "Employee Name: " << name << std::endl;
        std::cout << "Employee ID: " << id << std::endl;
        std::cout << "Hours Worked: " << hoursWorked << " hours" << std::endl;
        std::cout << "Hourly Salary: $" << hourlySalary << std::endl;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(const std::string& empName, int empId, double hours, double salary)
        : Employee(empName, empId, hours, salary) {}

    double salary() override {
        return Employee::salary(); // Call the base class salary method
    }
};

int main() {
    AdhocEmployee adhoc("John Doe", 12345, 40.0, 15.0); // Create an AdhocEmployee object

    std::cout << "Employee Information:" << std::endl;
    adhoc.display_info();

    std::cout << "Salary: $" << adhoc.salary() << std::endl;

    return 0;
}
