/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee {
protected:
    string Name;
    int Id;
    double WorkingHours;
    double PerHourSalary;

public:
    Employee(string name, int id, double hours, double salary) {
    	Name=name;
    	Id=id;
    	WorkingHours=hours;
    	PerHourSalary=salary;
	}
        double salary() {
        return WorkingHours * PerHourSalary;
    }

    void displayInfo() {
        cout << "Employee Name: " << Name <<endl;
        cout << "Employee ID: " << Id <<endl;
        cout << "Working Hours: " << WorkingHours <<endl;
        cout << "Per Hour Salary: " << PerHourSalary <<endl;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(string name, int id, double hours, double salary)
        : Employee(name, id, hours, salary) {}
        void displayInfo() {
        Employee::displayInfo();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    AdhocEmployee adhocEmployee("Ali", 101, 40, 15.5);
    cout << "Employee Information and Salary:" <<endl;
    adhocEmployee.displayInfo();

    return 0;
}