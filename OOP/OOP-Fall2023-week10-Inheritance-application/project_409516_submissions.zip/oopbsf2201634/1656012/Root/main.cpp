/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee {
protected:
    string name;
    int id;
    int workingHours;
    double hourlySalary;

public:
    Employee(string name, int id, int workingHours, double hourlySalary)
        : name(name), id(id), workingHours(workingHours), hourlySalary(hourlySalary) {}

    virtual double salary() const {
        return workingHours * hourlySalary;
    }

    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Hourly Salary: $" << hourlySalary << endl;
        cout << "Salary: $" << salary() << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int workingHours, double hourlySalary)
        : Employee(name, id, workingHours, hourlySalary) {}

    double salary() {
        return workingHours * hourlySalary;
    }

    void display_info() {
        cout << "Adhoc Employee Information:" << endl;
        Employee::display_info();
    }
};

int main() {
    // Creating an object of Adhoc_employee
    Adhoc_employee emp("John Doe", 12345, 40, 15.50);

    // Displaying information and salary for the Adhoc_employee instance
    emp.display_info();

    return 0;
}
