/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
class Employee {
protected:
    std::string Name;
    int Id;
    int WorkingHours;
    double HourlySalary;

public:
    Employee(const std::string& name, int id, int hours, double hourlySalary)
        : Name(name), Id(id), WorkingHours(hours), HourlySalary(hourlySalary) {}

    // Virtual function to be overridden by derived classes
    virtual double salary() {
        return WorkingHours * HourlySalary;
    }

    void display_info() {
        std::cout << "Name: " << Name << std::endl;
        std::cout << "ID: " << Id << std::endl;
        std::cout << "Working Hours: " << WorkingHours << std::endl;
        std::cout << "Hourly Salary: " << HourlySalary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& name, int id, int hours, double hourlySalary)
        : Employee(name, id, hours, hourlySalary) {}

    // Override the salary method
    double salary() override {
        return Employee::salary(); // Calculate salary based on base class method
    }

    void display_info() {
        Employee::display_info(); // Call the base class method to display common information
        std::cout << "Salary: " << salary() << std::endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee adhoc("John Doe", 101, 40, 15.5);

    // Display information and salary
    adhoc.display_info();

    return 0;
}
