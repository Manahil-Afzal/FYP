#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int NumOfWorkingHours;
    double PerHourSalary;

public:
    Employee(const std::string& name, int id, int hours, double salary)
        : Name(name), Id(id), NumOfWorkingHours(hours), PerHourSalary(salary) {}

    virtual double salary() {
        return NumOfWorkingHours * PerHourSalary;
    }

    void display_info() {
        std::cout << "Employee ID: " << Id << std::endl;
        std::cout << "Employee Name: " << Name << std::endl;
        std::cout << "Working Hours: " << NumOfWorkingHours << std::endl;
        std::cout << "Per Hour Salary: $" << PerHourSalary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    double salary() override {
        return NumOfWorkingHours * PerHourSalary;
    }
};

int main() {
    Adhoc_employee adhoc("John Doe", 101, 40, 15.5);

    std::cout << "Adhoc Employee Information:" << std::endl;
    adhoc.display_info();
    std::cout << "Salary: $" << adhoc.salary() << std::endl;

    return 0;
}

/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/