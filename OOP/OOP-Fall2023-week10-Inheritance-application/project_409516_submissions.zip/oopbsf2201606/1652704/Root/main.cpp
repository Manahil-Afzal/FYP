/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
  string name;
  int id;
  int num_working_hours;
  float per_hour_salary;

public:
  Employee(string name, int id, int num_working_hours, float per_hour_salary) {
    this->name = name;
    this->id = id;
    this->num_working_hours = num_working_hours;
    this->per_hour_salary = per_hour_salary;
  }
};

class Adhoc_employee : public Employee {
public:
  Adhoc_employee(string name, int id, int num_working_hours, float per_hour_salary) : Employee(name, id, num_working_hours, per_hour_salary) {}

  float salary() {
    return num_working_hours * per_hour_salary;
  }

  void display_info() {
    cout << "Name: " << name << endl;
    cout << "ID: " << id << endl;
    cout << "Number of working hours: " << num_working_hours << endl;
    cout << "Per hour salary: " << per_hour_salary << endl;
    cout << "Salary: " << salary() << endl;
  }
};

int main() {
  // Create an object of Adhoc_employee
  Adhoc_employee employee("Alice", 123, 40, 100);

  // Display the information and salary of the employee
  employee.display_info();

  return 0;
}