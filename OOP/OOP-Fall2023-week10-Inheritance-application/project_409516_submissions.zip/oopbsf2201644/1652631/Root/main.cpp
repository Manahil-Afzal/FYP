/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string name;
    int id;
    double hours_worked;
    double per_hour_salary;

public:
    Employee(const std::string& emp_name, int emp_id, double emp_hours, double emp_salary)
        : name(emp_name), id(emp_id), hours_worked(emp_hours), per_hour_salary(emp_salary) {}

    double salary() {
        return hours_worked * per_hour_salary;
    }

    void display_info() {
        std::cout << "Employee Name: " << name << std::endl;
        std::cout << "Employee ID: " << id << std::endl;
        std::cout << "Hours Worked: " << hours_worked << " hours" << std::endl;
        std::cout << "Per Hour Salary: $" << per_hour_salary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& emp_name, int emp_id, double emp_hours, double emp_salary)
        : Employee(emp_name, emp_id, emp_hours, emp_salary) {}
};

int main() {
    Adhoc_employee adhoc("John Doe", 101, 40, 15.0); // Creating an Adhoc_employee object

    adhoc.display_info();
    std::cout << "Salary: $" << adhoc.salary() << std::endl;

    return 0;
}
