/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
/*Write a C++ program that implements a class hierarchy having a base class
 named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, 
Number of working hours and Per hour salary. 
The derived class implements two methods
named salary and display_info. 
The salary method calculates the salary of employee by multiplying
“Number of working hours” by “Per hour salary”.
The display_info method displays
the complete information of employee. 
Create an object of Adhoc_employee and display the information and salary
 against that instance.*/
 #include<iostream>
 #include<string>
 using namespace std;
 class Employee{
    protected:
    string e_name;
    int e_Id;
    int working_hour;
    int per_h_s;
 };
 class adhoc_employee:public Employee{
    private:
    long salary;
    public:
    void E_details()
    {
        cout<<"ENTER NAME OF EMPLOYEE:"<<endl;
        getline(cin,e_name);
        cout<<"ENTER ID:"<<endl;
        cin>>e_Id;
        cout<<"Enter Working Hours:"<<endl;
        cin>>working_hour;
        cout<<"ENTER PER HOUR SALARY:"<<endl;
        cin>>per_h_s;
    }
    void display_info()
    {
        cout<<"========================="<<endl;
        cout<<"    EMPLOYEE DETAILS     "<<endl;
        cout<<"_________________________"<<endl;
        cout<<"NAME:"<<e_name<<endl;
        cout<<"Employee Id:"<<e_Id<<endl;
        cout<<"Working Hours:"<<working_hour<<endl;
        cout<<"Per Hour Salary:"<<per_h_s<<endl;
        salary=working_hour*per_h_s;
        cout<<"Employee Salary:"<<salary<<endl;
    }
 };
 int main()
 {
    adhoc_employee emp;
    emp.E_details();
    emp.display_info();
    return 0;
 }