/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumOfWorkingHours;
    double PerHourSalary;

public:
    Employee(string name, int id, int hours, double salary) {
        Name = name;
        Id = id;
        NumOfWorkingHours = hours;
        PerHourSalary = salary;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    double salary() {
        return NumOfWorkingHours * PerHourSalary;
    }

    void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of Working Hours: " << NumOfWorkingHours << endl;
        cout << "Per Hour Salary: " << PerHourSalary << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 1234, 40, 15.5);
    emp.display_info();
    cout << "Salary: " << emp.salary() << endl;

    return 0;
}