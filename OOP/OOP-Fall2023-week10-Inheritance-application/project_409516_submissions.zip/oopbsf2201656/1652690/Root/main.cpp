#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(const std::string& name, int id, int hours, double salary)
        : Name(name), Id(id), NumWorkingHours(hours), PerHourSalary(salary) {}

    double salary() {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() {
        std::cout << "Name: " << Name << std::endl;
        std::cout << "Employee ID: " << Id << std::endl;
        std::cout << "Number of Working Hours: " << NumWorkingHours << std::endl;
        std::cout << "Per Hour Salary: $" << PerHourSalary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    void display_info() {
        Employee::display_info();
        std::cout << "Salary: $" << salary() << std::endl;
    }
};

int main() {
    Adhoc_employee adhoc("John Doe", 101, 40, 15.5);
    adhoc.display_info();

    return 0;
}
