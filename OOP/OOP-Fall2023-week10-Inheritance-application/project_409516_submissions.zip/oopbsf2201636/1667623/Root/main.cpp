/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(const std::string& name, int id, int hours, double hourlySalary)
        : Name(name), Id(id), NumWorkingHours(hours), PerHourSalary(hourlySalary) {}

    virtual double salary() const = 0; // Pure virtual function
    virtual void display_info() const = 0; // Pure virtual function
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& name, int id, int hours, double hourlySalary)
        : Employee(name, id, hours, hourlySalary) {}

    double salary() const override {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() const override {
        std::cout << "Employee Name: " << Name << "\n";
        std::cout << "Employee ID: " << Id << "\n";
        std::cout << "Number of Working Hours: " << NumWorkingHours << "\n";
        std::cout << "Per Hour Salary: " << PerHourSalary << "\n";
        std::cout << "Total Salary: " << salary() << "\n";
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee employee("John Doe", 101, 40, 15.5);

    // Display information and salary
    employee.display_info();

    return 0;
}
