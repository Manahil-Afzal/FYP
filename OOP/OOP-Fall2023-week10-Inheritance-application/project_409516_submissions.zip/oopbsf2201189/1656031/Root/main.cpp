#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    double WorkingHours;
    double HourlySalary;

public:
    Employee(const std::string& name, int id, double hours, double salary)
        : Name(name), Id(id), WorkingHours(hours), HourlySalary(salary) {}

    double salary() {
        return WorkingHours * HourlySalary;
    }

    void display_info() {
        std::cout << "Name: " << Name << std::endl;
        std::cout << "Employee ID: " << Id << std::endl;
        std::cout << "Working Hours: " << WorkingHours << std::endl;
        std::cout << "Hourly Salary: $" << HourlySalary << std::endl;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(const std::string& name, int id, double hours, double salary)
        : Employee(name, id, hours, salary) {}

    void display_info() {
        Employee::display_info();
        std::cout << "Salary: $" << salary() << std::endl;
    }
};

int main() {
    AdhocEmployee employee("John Doe", 12345, 40.0, 20.0);
    employee.display_info();

    return 0;
}
