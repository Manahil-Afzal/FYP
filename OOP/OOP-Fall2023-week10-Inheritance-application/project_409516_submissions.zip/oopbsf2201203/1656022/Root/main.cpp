/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”.\
The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee{
	protected:
		string name;
		string id;
		int w_hours;
		int h_salary;
		
};
class Adhoc_employee : public Employee{
	public:
		void setter(){
			cout<<"enter your name "<<endl;
			cin>>name;
			cout<<"enter your id "<<endl;
			cin>>id;
			cout<<"enter your Working Hours "<<endl;
			cin>>w_hours;
			cout<<"enter your hourly salary "<<endl;
			cin>>h_salary;
		}
		int salary(){
			int salary;
			salary = w_hours * h_salary;
			return salary;
		}
		void display(){
				cout<<"Your name is "<<name<<endl;
				cout<<"Your id is "<<id<<endl;
				cout<<"Your work for "<<w_hours<< "hours" <<endl;
				cout<<"your hourly salary is "<<h_salary <<endl;
				cout<<"your daily salary is " <<salary()<<endl;
		}
};
int  main ()
{
	Adhoc_employee a1;
	a1.setter();
	a1.display();



}
