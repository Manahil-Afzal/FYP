/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>

using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    double NumHoursWorked;
    double PerHourSalary;

public:
    Employee(const string &name, int id, double hoursWorked, double hourlySalary)
        : Name(name), Id(id), NumHoursWorked(hoursWorked), PerHourSalary(hourlySalary) {}

    virtual double salary() {
        return NumHoursWorked * PerHourSalary;
    }

    void display_info() {
        cout << "Employee ID: " << Id << endl;
        cout << "Name: " << Name << endl;
        cout << "Number of Working Hours: " << NumHoursWorked << endl;
        cout << "Per Hour Salary: $" << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string &name, int id, double hoursWorked, double hourlySalary)
        : Employee(name, id, hoursWorked, hourlySalary) {}

    double salary() override {
        return Employee::salary();
    }
};

int main() {
    Adhoc_employee emp("John Doe", 12345, 40.0, 15.0);

    cout << "Employee Information:" << endl;
    emp.display_info();

    cout << "Salary: $" << emp.salary() << endl;

    return 0;
}