/*

C++ program to check prime number. Identify and correct error.

Prime numbers are those numbers which are divisible by itself only. Here, we will read an integer number and check whether it is Prime or Not, 
to check prime number we implemented a function isPrime() that will take integer number as argument and return 1 if it is prime else it return 0.*/

#include <iostream>
using namespace std;

int main()
{
   
	int num,i;
	 bool isprime= true;
	
	cout<<"Enter an positive integer number: ";
	cin>>num;
	if (num==0||num==1){
	    isprime=false;
	}

	for(i=2;i<=num/2;++i)
	{
		if(num%i==0){
		
			isprime=false;
			break;
		}
	}
		if(isprime)
		cout<<num<<" is a prime number"<<endl;
	else
		cout<<num<<" is not a prime number"<<endl;
		
	return 0;

}
