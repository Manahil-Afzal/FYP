/*

C++ program to check prime number. Identify and correct error.

Prime numbers are those numbers which are divisible by itself only. Here, we will read an integer number and check whether it is Prime or Not, 
to check prime number we implemented a function isPrime() that will take integer number as argument and return 1 if it is prime else it return 0.*/

#include<iostream>
using namespace std;
int main(){
    
	int arr[20];
	
	int even[20],odd[20];
	int e=0,o=0;
	cout<<"Enter  20 integer numbers"<<"\n";
	
	for(int i=0;i<20;i++)
	cin>>arr[i];
		for(int i=0;i<20;i++){
			if(arr[i]%2==0)
			even[e++]=arr[i];
			else
			odd[o++]=arr[i];
			cout<<endl;
			
		}
		cout<<"The  20 even numbers are"<<"\n";
		 for(int i=0;i<e;i++)
		 cout<<even[i]<<" ";
		 
		 		cout<<"The  20 odd numbers are"<<"\n";
         for(int i=0;i<o;i++)
         cout<<odd[i]<<" ";
         return 0;
         
		 

	
}