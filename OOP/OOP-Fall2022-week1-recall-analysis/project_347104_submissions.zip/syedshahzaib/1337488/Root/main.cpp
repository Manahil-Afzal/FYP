/*

C++ program to check prime number. Identify and correct error.

Prime numbers are those numbers which are divisible by itself only. Here, we will read an integer number and check whether it is Prime or Not, 
to check prime number we implemented a function isPrime() that will take integer number as argument and return 1 if it is prime else it return 0.*/

#include<iostream>
 
using namespace std;
  
int isPrime(int num);
 
int main() {
  int num;
  cout << "Enter a positive number:";
  cin >> num;
    
  if(isPrime(num))
      cout << num << " is a Prime Number";
  else
      cout << num <<" is not Prime Number";
        
  return 0;
}
 

int isPrime(int num){
    int i;
    
    for(i = 2; i <=(num/2); ++i) {
        if(num%i==0) {
            return 0;
        }
    }
    return 1;
}
