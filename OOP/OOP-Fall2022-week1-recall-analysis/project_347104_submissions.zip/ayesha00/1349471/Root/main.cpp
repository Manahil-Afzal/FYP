/*

C++ program to check prime number. Identify and correct error.

Prime numbers are those numbers which are divisible by itself only. Here, we will read an integer number and check whether it is Prime or Not, 
to check prime number we implemented a function isPrime() that will take integer number as argument and return 1 if it is prime else it return 0.*/

#include <iostream>
using namespace std;

bool check_prime(int);

int main() {

  int n;

  cout << "Enter a positive  integer: ";
  cin >> n;

  if (check_prime(n))
    cout << n << " is a prime number.";
  else
    cout << n << " is not a prime number.";

  return 0;
}

bool check_prime(int n) {
  bool is_prime = true;

  // 0 and 1 are not prime numbers
  if (n == 0 || n == 1) {
    is_prime = false;
  }

  for (int i = 2; i <= n / 2; ++i) {
    if (n % i == 0) {
      is_prime = false;
      break;
    }
  }

  return is_prime;
}
