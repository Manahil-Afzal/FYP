
#include <iostream>
using namespace std;

bool isPrime(int n);

int main()
{
	int num;
	
	cout<<"Enter an integer number: ";
	cin>>num;
	
	if(isPrime(num))
		cout<<num<<" is a prime number"<<endl;
	else
		cout<<num<<" is not a prime number"<<endl;
		
	return 0;
}


 bool isPrime(int n)
{
	
	bool prime= true;
	if(n == 0 || n == 1){
		prime = false;
//		break;
	}
	
	for(int i=2;i<(n-1);i++)
	{
		if(n%i==0)
		{
			prime= false;
			break;
		}
	}
	return prime;
}