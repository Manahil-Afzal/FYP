/*

C++ program to check prime number. Identify and correct error.

Prime numbers are those numbers which are divisible by itself only. Here, we will read an integer number and check whether it is Prime or Not, 
to check prime number we implemented a function isPrime() that will take integer number as argument and return 1 if it is prime else it return 0.*/

#include <iostream>
using namespace std;

int isPrime(long n);

int main()
{
	int num;
	
	cout<<"Enter an integer number: ";
	cin>>num;
	
	if(isPrime(num))
		cout<<"1"<<endl;
	else
		cout<<"0"<<endl;
		
	return 0;
}


int isPrime(long n)
{
	
	int prime=1;
	
	for(int i=2;i<(n-1);i++)
	{
		if(n%i==0)
		{
			prime=0;
			break;
		}
	}
	return prime;
}
