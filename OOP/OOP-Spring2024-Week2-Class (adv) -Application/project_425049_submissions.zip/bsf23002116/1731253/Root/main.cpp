/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*//*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill{
  private:
	string customer_name;
	string customer_address;
	int Bill_number;
	int Units_consumed;
    
 public:
 	void getDetail();
 	int calculate_Bill_Amount();
 	void putDetail();

};
int main(){
	Utility_Bill std;
	cout<<"Customer and his Bill detail is:"<<"\n";
	std.getDetail();
	std.putDetail();
}
void Utility_Bill::getDetail(){
	cout<<"Customer name is:"<<endl;
	cin>>customer_name;
	cout<<"Customer address is:"<<endl;
	cin>>customer_address;
	cout<<"Bill number is:"<<endl;
	cin>>Bill_number;
	cout<<"Units consumed are:"<<endl;
	cin>>Units_consumed;
}
 int Utility_Bill::calculate_Bill_Amount(){
  int per_unit_price;
	cout<<"calculating Bill Amount:"<<"\n";
	if(Units_consumed < 300){
		per_unit_price = 8;
	}
	else if(Units_consumed < 1000){
		per_unit_price = 5;
	}
	else{
		per_unit_price = 14;
	}
	return Units_consumed*per_unit_price;}

 void Utility_Bill::putDetail(){
	cout<<"Customer name = "<<customer_name<<endl;
	cout<<"Customer address = "<<customer_address<<endl; 
	cout<<"Bill number = "<<Bill_number <<endl;
	cout<<"Units consumed = "<<Units_consumed<<endl;
	cout<<"Bill_Amount = Rs."<<calculate_Bill_Amount();
}