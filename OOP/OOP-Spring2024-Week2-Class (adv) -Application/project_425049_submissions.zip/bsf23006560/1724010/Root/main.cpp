#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    Utility_Bill(string name, int number, int units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
    }

    void displayBill() {
        double perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed >= 300 && unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: " << billAmount << endl;
    }
};

int main() {
    string name;
    int number;
    int units;
    string address;

    cout << "Enter Customer Name: ";
    getline(cin, name);

    cout << "Enter Bill Number: ";
    cin >> number;

    cout << "Enter Units Consumed: ";
    cin >> units;

    cin.ignore();
    cout << "Enter Customer Address: ";
    getline(cin, address);

    Utility_Bill bill(name, number, units, address);
    bill.displayBill();

    return 0;
}
