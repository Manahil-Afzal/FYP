/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    Utility_Bill(string name, int number, int units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
    }

    void displayBill() {
        double perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed >= 300 && unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: " << billAmount << endl;
    }
};

int main() {
    string name;
    int number;
    int units;
    string address;

    cout << "Enter Customer Name: ";
    getline(cin, name);

    cout << "Enter Bill Number: ";
    cin >> number;

    cout << "Enter Units Consumed: ";
    cin >> units;

    cin.ignore();
    cout << "Enter Customer Address: ";
    getline(cin, address);

    Utility_Bill bill(name, number, units, address);
    bill.displayBill();

    return 0;
}

