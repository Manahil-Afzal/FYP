/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class Utility_bill{
    private:
    string name,address;
    long bill_number;
    int units,unit_price,bill;
    public:
    	void get(){
    		cout<<"enter customer name\n";
    		cin>>name;
    		cout<<"enter bill number\n";
    		cin>>bill_number;
    		cout<<"enter consumed units\n";
    		cin>>units;
    		cout<<"enter customer address\n";
    		cin>>address;
    		cout<<endl<<endl;
		}
		int calculate(){
			if(units<300){
				unit_price=8;
				bill=units*unit_price;
			}
				else if(units>=300 && units<1000){
				unit_price=5;
				bill=units*unit_price;
			}
				else{
				unit_price=14;
				bill=units*unit_price;
			}
			return bill;
		}
		void display(){
			cout<<"Name : "<<name<<endl;
			cout<<"number of units : "<<units<<endl;
			cout<<"price per unit : "<<unit_price<<endl;
			cout<<"bill amount : "<<bill<<endl;
		}
    
};
int main(){
	Utility_bill obj1;
	obj1.get();
	obj1.calculate();
	cout<<"details of bill 1\n";
	obj1.display();
	return 0;
}