/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
// If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14*/
#include <iostream>
using namespace std;
class Utility_Bill
{
private:
    string name;
    int bill_number;
    // int unit;
    int current_units;
    int privius_units;
    int consumed_units;
    string customer_address;
    int total_bill;

public:
    void setdata()
    {
        cout << "Enter the name of the customer " << endl;
        cin >> name;
        cout << "Enter the bill number " << endl;
        cin >> bill_number;
        cout << "Enter the current units " << endl;
        cin >> current_units;
        cout << "Enter the privious units " << endl;
        cin >> privius_units;
        if (current_units > privius_units)
        {
            consumed_units = current_units - privius_units;
        }
        else
        {
            cout << "The consumed units are null " << endl;
        }
        cout << "Enter the custmer address " << endl;
        cin >> customer_address;
        // system("pause");
    }
    void display()
    {
        cout << "The name of the cutmer is = " << name << endl;
        cout << "The bill number of the cutmer is = " << bill_number << endl;
        cout << "The current units of the cutmer is = " << current_units << endl;
        cout << "The previous units of the cutmer  = " << privius_units << endl;
        cout << "The consumed of the cutmer is = " << consumed_units << endl;
        cout << "The address  of the cutmer is = " << customer_address << endl;
        // system("pause");
    }
   void dispalybill()
   {
    if (consumed_units<300)
    {
        total_bill=consumed_units*8;
        cout<<"The total bill is = "<<total_bill<<endl;
        // system("pause");
    }
    else if (consumed_units>=300 || consumed_units<1000)
    {
        total_bill=consumed_units*5;
        cout<<"The total bill is = "<<total_bill<<endl;
        // system("pause");
    }
    else if (consumed_units>999)
    {
        total_bill=consumed_units*15;
        cout<<"The total bill is = "<<total_bill<<endl;
        // system("pause");
    }
    
    
   }
};
int main()
{
    Utility_Bill Custmer1;
    int choice;

    do

    {
        cout << "------- Main Menu ----------" << endl;
        cout << "Enter 1 for input data of the custmer " << endl;
        cout << "Enter 2 for display the data " << endl;
        cout<<"Enter 3 to display the total bill"<<endl;
        cout << "Enter 4 to exit the program " << endl;
        cout << "Enter any choice from the main menu " << endl;
        cin >> choice;
        switch (choice)
        {
        case 1:
            Custmer1.setdata();
            break;
        case 2:
            Custmer1.display();
            break;
        case 3:
            Custmer1.dispalybill();
            break;
            case 4:
            cout<<"Exit the program"<<endl;
            // exit(0);

        default:
            cout << "You did not enter the right choice " << endl;
            break;
        }

    } while (1);

    return 0;
}