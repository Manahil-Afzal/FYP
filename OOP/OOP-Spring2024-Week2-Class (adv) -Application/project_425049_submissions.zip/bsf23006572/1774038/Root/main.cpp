/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string.h>
using namespace std;
class Utility_Bill
{
private:
    string cust_name;
    int bill_number;
    int unit_consumed;
    char cust_address;
    int total_bill;

public:
    void get_data()
    {
        cout << "Enter the customer name = ";
        cin >> cust_name;
        cout << "Enter the bill number = ";
        cin >> bill_number;
        cout << "Enter the consumed units = ";
        cin >> unit_consumed;
        cout << "Enter the customer address = ";
        cin >> cust_address;
    }
    void display_data()
    {
        cout << "The customer name = " << cust_name << endl;
        cout << "The bill number = " << bill_number << endl;
        cout << "The units consumed = " << unit_consumed << endl;
        cout << "The customer address = " << cust_address << endl;
        if (unit_consumed < 300)
        {
            total_bill = unit_consumed * 8;
            cout << "The total bill is = " << total_bill << endl;
        }
        else if (unit_consumed > 300 && unit_consumed < 1000)
        {
            total_bill = unit_consumed * 5;
            cout << "The total bill is = " << total_bill << endl;
        }
        else if (unit_consumed >= 1000)
        {
            total_bill = unit_consumed * 14;
            cout << "The total bill is = " << total_bill << endl;
        }
        else
        {
            cout << "Enter the correct choice ! " << endl;
        }
    }
};
using namespace std;
int main()
{
    Utility_Bill my_bill;
    my_bill.get_data();
    my_bill.display_data();
    return 0;
}