/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class Bill{
	string customer_name;
	string address;
	int unit_consumed;
	int bill_number;
	int amount;
	public:
		void get(){
			cout<<"Enter the customer name:";
			cin>>customer_name;
			cout<<"Enter the bill number:";
			cin>>bill_number;
			cout<<"Enter the customer address:";
			cin>>address;
			cout<<"Enter the units consumed:";
			cin>>unit_consumed;
		}
		void allow(){
			if(unit_consumed<300){
				amount=unit_consumed*8;
			}else if(unit_consumed<1000){
				amount=unit_consumed*5;
			}else{
				amount=unit_consumed*14;
			}
		}
		void display(){
			cout<<"Customer Name= "<<customer_name<<endl;
			cout<<"Bill Number= "<<bill_number<<endl;
			cout<<"Customer Address= "<<address<<endl;
			cout<<"Units Consumed= "<<unit_consumed<<endl;
			cout<<"Bill amount= "<<amount<<endl;
		}
};
int main(){
	Bill xyz;
	xyz.get();
	xyz.allow();
	xyz.display();
}