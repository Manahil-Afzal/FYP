#include <iostream>
#include <string>

class UtilityBill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;

public:
    // Constructor to initialize customer details
    UtilityBill(const std::string& name, int billNo, int units, const std::string& address)
        : customerName(name), billNumber(billNo), unitsConsumed(units), customerAddress(address) {}

    // Calculate bill amount based on units consumed
    double calculateBillAmount() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 7.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 12.0;
        }

        return unitsConsumed * perUnitPrice;
    }

    // Display customer details and bill amount
    void displayBill() {
        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Bill Amount: Rs. " << calculateBillAmount() << std::endl;
    }
};

int main() {
    // Example usage
    UtilityBill bill("John Doe", 12345, 500, "123 Main St, City");
    bill.displayBill();

    return 0;
}
