/*Write a program that creates a class to display Utility_Bill. The class should take customer name, 
bill number, units consumed, and customer address as inputs and displays the input values and the 
amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but 
than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class info{
	public:
	 string c_name;
	 int b_number;
	 float consumed_unit;
	 string address;
};
int main(){
	
	float t_bill;
	 info u_bill;
	 cout<<"enter name of customer : ";
	 cin>>u_bill.c_name;
	 cout<<"enter the bill numer/code : ";
	 cin>>u_bill.b_number;
	 cout<<"enter the amount of consumed unit : ";
	 cin>>u_bill.consumed_unit;
	 cout<<"enter the customer address : ";
	 cin>>u_bill.address;
	 // bill calculation
	 
	 if(u_bill.consumed_unit < 300)
	 {	
	 	t_bill=u_bill.consumed_unit*8;
	 	cout<<"total bill amount : "<<t_bill;
	 }
	 else if(u_bill.consumed_unit> 999){
	 	
	 	t_bill=u_bill.consumed_unit* 14 ;
	 	cout<<"total bill amount : "<<t_bill;
	 }else if(u_bill.consumed_unit >=300 || u_bill.consumed_unit<=1000 )
	 {
	 	t_bill=u_bill.consumed_unit*5;
	 	cout<<"total bill amount : "<<t_bill;
	 }
	 
}