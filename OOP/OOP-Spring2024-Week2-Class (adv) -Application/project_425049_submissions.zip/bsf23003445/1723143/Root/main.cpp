/*Write a program that creates a class to display Utility_Bill. The class should take customer
name, bill number, units consumed, and customer address as inputs and displays the input values and
the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class bills{
	
	 private :
	 	string customer_name;
	 	int bill_id;
	 	int consumed_units;
	 	string address;
	 	int total;
	public:
	        void getinfo(){
	        	
	        	cout<<"enter the customer name : ";
	        	cin>>customer_name;
	        	cout<<"enter the bill id : ";
	        	cin>>bill_id;
	        	cout<<"enter the consumed units : ";
	        	cin>>consumed_units;
	        	cout<<"enter the customer address : ";
	        	cin>>address;
	        	
			}
			
			int billcalculation(){
				
				if(consumed_units < 300){
					
					int total;
					total=consumed_units*8;
				
				}else if (consumed_units >= 300 && consumed_units < 1000 ){
						int total;
					total=consumed_units*5;
					
				}else if(consumed_units >= 1000 ){
						int total;
					total=consumed_units*14;
				}
				
				 
			
			}
			
			void ans(){
				
				 cout<<"total bill is :" <<total;
			}	
			
};
int main(){
	
	bills obj1;
	cout<<"PLEASE ENTER THE DETAILS : "<<endl;
	obj1.getinfo();
	obj1.billcalculation();
	cout<<obj1.billcalculation();

}