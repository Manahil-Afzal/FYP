#include <iostream>
using namespace std;

class Utility_Bill{
    string name, address;
    int billNo, units;
    public:
        void input(){
            cout<<"Name: ";
            cin>>name;
            cout<<"Bill No: ";
            cin>>billNo;
            cout<<"Units Consumed: ";
            cin>>units;
        }
        void calc(){
            int billAm;
            if(units<300)
                billAm = units * 7;
            else if(units >=300 && units<1000)
                billAm= units * 5;
            else
                billAm = units * 12;
            cout<<"Bill Amount: "<<billAm;
            }
        void display(){
            cout<<"------------------------"<<endl;
            cout<<"Details are as follows: "<<endl;
            cout<<"Name: "<<name<<endl;
            cout<<"Bill No: "<<billNo<<endl;
            cout<<"Units Consumed: "<<units<<endl;
        }
};


int main(){
    cout<<"Enter the following details: "<<endl;
    Utility_Bill bill;
    bill.input();
    bill.display();
    bill.calc();

}