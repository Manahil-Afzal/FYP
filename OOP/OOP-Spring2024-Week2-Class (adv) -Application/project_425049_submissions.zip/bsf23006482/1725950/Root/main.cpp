/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class bill {
private:
    int bill_num, unit_consumed, total_bill;
    string name, address;
    void calculate();
public:
    void input();
    void output();
};

void bill::input() {
    cout << "Enter your name :";
    cin >> name;
    cout << "Enter your Bill Number :";
    cin >> bill_num;
    cout << "Enter your unit Consumption :";
    cin >> unit_consumed;
    cout << "Enter your Address :";
    cin >> address;
    calculate(); 
}

void bill::calculate() {
    if (unit_consumed < 300) {
        total_bill = unit_consumed * 8;
    } else if (unit_consumed < 1000) {
        total_bill = unit_consumed * 5;
    } else {
        total_bill = unit_consumed * 14;
    }
}

void bill::output() {
    cout <<"Dear "<< name << endl <<"Bill Number :"<< bill_num << endl;
    cout << "Your total bill is : Rs " << total_bill << endl;
}

int main() {
    bill bill1;
    int i;
    for (i=0;i==0;)
    {
    bill1.input();
    bill1.output();
    cout<<"Enter 0 to check for other user"<<endl;
    cout<<"Enter 1 to check for exit"<<endl;
    cout<<"Enter your choice [0,1] : ";
    cin>>i;
    };
    return 0;
}
