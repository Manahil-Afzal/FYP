#include<iostream>
#include <string>
using namespace std;
class UtilityBill {
private:
    string customer_name;
    string bill_number;
    int units_consumed;
    string customer_address;

public:
    UtilityBill(string name,string number, int consumed, string address)
        : customer_name(name), bill_number(number), units_consumed(consumed), customer_address(address) {}

   
    double calculateBillAmount() {
        double per_unit_price;
        if (units_consumed < 300) {
            per_unit_price = 8;
        } else if (units_consumed < 1000) {
            per_unit_price = 5;
        } else {
            per_unit_price = 14;
        }

        return units_consumed * per_unit_price;
    }
    void displayBill() {
        cout << "Customer Name: " << customer_name <<endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed <<endl;
        cout << "Customer Address: " << customer_address <<endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() <<endl;
    }
};

int main() {
    UtilityBill customer1("John Doe", "B123", 250, "123 Main Street");
    customer1.displayBill();
     UtilityBill customer2("Jane Smith", "B456", 500, "456 Oak Avenue");
    customer2.displayBill();

   
    return 0;
}