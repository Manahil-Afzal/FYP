/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class Utility_Bill
{
private:
    string customer_name;
    string bill_number;
    int units_consumed;
    string customer_address;

public:
    void setCustomerInfo(string name, string number, int units, string address)
    {
        customer_name = name;
        bill_number = number;
        units_consumed = units;
        customer_address = address;
    }

    void inputCustomerInfo()
    {
        cout << "Enter Customer Name: ";
        getline(cin, customer_name);

        cout << "Enter Bill Number: ";
        getline(cin, bill_number);

        cout << "Enter Units Consumed: ";
        cin >> units_consumed;
        cin.ignore();

        cout << "Enter Customer Address: ";
        getline(cin, customer_address);
    }

    int calculateBillAmount()
    {
        int per_unit_price;
        if (units_consumed < 300)
        {
            per_unit_price = 8;
        }
        else if (units_consumed < 1000)
        {
            per_unit_price = 5;
        }
        else
        {
            per_unit_price = 14;
        }

        return units_consumed * per_unit_price;
    }

    void display_bill_info()
    {
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;

        int bill_amount = calculateBillAmount();
        cout << "Bill Amount: Rs. " << bill_amount << endl;
    }
};

int main()
{
    Utility_Bill customer_bill;

    customer_bill.inputCustomerInfo();
    customer_bill.display_bill_info();

    return 0;
}
