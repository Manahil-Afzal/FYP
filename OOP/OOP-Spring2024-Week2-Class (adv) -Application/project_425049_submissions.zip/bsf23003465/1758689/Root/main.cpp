/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class customer{
	public:
		string name;
		string BillNumber;
		int unitConsumed;
		string address;
		float billAmount;
		void inputDetails(){
			cout<<"Enter customer name :"<<endl;
			cin>>name;
			cout<<"Enter bill number :"<<endl;
			cin>>BillNumber;
			cout<<"Enter unit consumed :"<<endl;
			cin>>unitConsumed;
			cout<<"Enter customer address :"<<endl;
			cin>>address;
		}
		void calculatebillAmount(){
		
			if(unitConsumed<300){
				billAmount=unitConsumed*8;
				cout<<billAmount;
			}else if(unitConsumed>=300 || unitConsumed<1000){
				billAmount=unitConsumed*5;
				cout<<billAmount<<endl;
		} 
		else if(unitConsumed>999){
				billAmount=unitConsumed*14;
				cout<<billAmount<<endl;
}
}
        void displayDetails(){
        	cout<<"Customer Name :"<<name<<endl;
        	cout<<"Bill Number :"<<BillNumber<<endl;
        	cout<<"unit Consumed :"<<unitConsumed<<endl;
        	cout<<"Address :"<<address<<endl;
        	cout<<"Bill Amount is :" <<billAmount<<endl;
		}
};
int main(){
	customer customer1;
	customer1.inputDetails();
	customer1.calculatebillAmount();
	customer1.displayDetails();

	return 0;
}
