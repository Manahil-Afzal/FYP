/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
  #include<iostream>
  using namespace std;
  class Bills_info {
  	private:
  		string customer_name;
  		int bill_number;
  		int consumed_units;
  		string customer_adrress;
  		int bill_amount;
  	public:
  		  	void getvalues(){
  	    cout<<"input customer name :";
  	    cin>>customer_name;
  		cout<<"input bill number:";
  		cin>>bill_number;
  		cout<<"input consumed units:";
  		cin>>consumed_units;
  		cout<<"input customer address:";
  		cin>>customer_adrress;
  	}
  		void displayvalues(){
  	  if(consumed_units<300){
  		int unit_price=8;
  		bill_amount=consumed_units*unit_price;
  		
	  }
	  else if(consumed_units>=300 && consumed_units<1000){
	  	int unit_price=5;
	  	bill_amount=consumed_units*unit_price;
	  	
	  }
	  else if(consumed_units>999){
  	 	int unit_price=14;
  	    bill_amount=consumed_units*unit_price; 	
  	  
  }
  cout<<"customer name is :"<<customer_name<<endl;
  cout<<"bill number is :"<<bill_number<<endl;
  cout<<"consumed units are:"<<consumed_units<<endl;
  cout<<"customer address is :"<<customer_adrress<<endl;
  	cout<<"bill amount is:"<<bill_amount<<endl;
}
     };
  int main(){
  	Bills_info obj;
  	cout<<"Taking inputs"<<endl;
  	obj.getvalues();
  	cout<<"displaying values"<<endl;
  	obj.displayvalues();
  	return 0;
}