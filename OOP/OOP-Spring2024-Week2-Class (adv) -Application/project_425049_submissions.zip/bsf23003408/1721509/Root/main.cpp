/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class Utillity_Bill{
    string name;
    string bill_no;
    string address;
    
    int units;
    public:
    void input();
    void display();

};
void Utillity_Bill:: input(){
 cout<<"Enter Customer name:"<<endl;
 cin>>name;
 cout<<"Enter Bill number:"<<endl;
 cin>>bill_no;
 cout<<"Enter Bill Address:"<<endl;
 cin>>address;
 cout<<"Enter Consumed Units:"<<endl;
 cin>>units;

}

void Utillity_Bill::display(){
 cout<<"User Name is : "<<name<<endl;
 cout<<"User Bill Number is: "<<bill_no<<endl;
 cout<<"User Address: "<<address<<endl;
 cout<<"Consumed Units of user: "<<units<<endl;
 int balance;
 if(units<300){
    balance=units*8;
 }else if(units>=300 && units<1000){
 balance=units*5;
 }else if(units>999){
 balance=units*14;
 }
 cout<<"Total Bill Amount of user is: "<<balance<<endl;
}


int main(){
    Utillity_Bill User1;
    User1.input();
    User1.display();

}