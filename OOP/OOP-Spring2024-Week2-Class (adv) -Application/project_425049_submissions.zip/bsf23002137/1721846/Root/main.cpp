/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class Utility_bill{

private:
string name,address;
double total_bill;
double bill_number;
double units_consumed;
public:
void  get_details(){
	cout<<"enter customer name"<<endl;
	getline (cin>>ws,name);
	cout<<"enter the address"<<endl;
	getline (cin>>ws,address);
	cout<<"enter bill number"<<endl;
	cin>>bill_number;
	cout<<"toal units consume:"<<endl;
	cin>>units_consumed;
	
}
void calculation(){
	if( units_consumed<300){
		total_bill = units_consumed*7;
		
	}
	else if( units_consumed>=300<1000){
		total_bill = units_consumed*5;
	}
	else if ( units_consumed > 999) {
		total_bill = units_consumed * 14;
	}
	
} 
void display_details(){
	cout<<" The customer name is :"<<name<<endl;
	cout<<" The Customer's address is :"<<address<<endl;
	cout<<" The customer's bill number is : "<<bill_number<<endl;
	cout<<" The no. of total units consumed are :"<<units_consumed<<endl;
	cout<<" the total bill of customer is :"<<total_bill<<endl;
}



};

int main(){
  Utility_bill bill;
  cout<<" Enter Details :"<<endl;
   bill.get_details();
   bill.calculation();
   cout<<" Your utility_bill details are :"<<endl;
   bill.display_details();	
	
	
	
	return 0;
}