/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
 using namespace std;
class bill_info{
	private: 
	string Name;
	int B_number;
	int Units;
	string Address;
	int Amount;
    public:
        void get_values(){
        	cout<<"Enter Customer Name : ";
        	cin>>Name;
        	cout<<"Enter Customer's Bill Number : ";
        	cin>>B_number;
        	cout<<"Enter Customer's Address : ";
        	cin>>Address;
        	cout<<"Enter Customer's Electricity Units Consumed : ";
        	cin>>Units;
        	Amount = bill_Amount(Units);
		}
	    int bill_Amount(int Units2){
	    	int Amount2;
	    	if(Units2<300){
	    		Amount2=Units2*8;
			}
			else if(Units2>=300 && Units2<1000 ){
			    Amount2=Units2*5;	
			}
			else if(Units2>999){
				Amount2=Units2*14;
			}
			return Amount2;
		}
		void display_details(){
		    
			cout<<"Customer Name : "<<Name<<endl;
        	cout<<"Customer's Bill Number : "<<B_number<<endl;
        	cout<<"Customer's Address : "<<Address<<endl;
        	cout<<"Customer's Electricity Units Consumed Are : "<<Units<<endl;
        	cout<<"Customer's Bill Amount : "<<Amount<<endl;
		}
			
};

int main()

{
	bill_info bill;
	cout<<"Enter Customer details : "<<endl;
	cout<<endl;
	bill.get_values();
	cout<<"Your bill details are : "<<endl;
	cout<<endl;
	bill.display_details();
	return 0;
}