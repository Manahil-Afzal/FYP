/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class bill {
private:
    string Name;
    int billNumber;
    int unitsConsumed;
    string address;

public:
    void getdetails(string name, int number, int units, string addr) {
        Name = name;
        billNumber = number;
        unitsConsumed = units;
        address = addr;
    }

    void calculateBillAmount() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;


        cout << "Customer Name: " << Name << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << address << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};
int main() {
    bill utilityBill;
    utilityBill.getdetails("Ali", 123456, 500, "Township");
    utilityBill.calculateBillAmount();

    return 0;
}