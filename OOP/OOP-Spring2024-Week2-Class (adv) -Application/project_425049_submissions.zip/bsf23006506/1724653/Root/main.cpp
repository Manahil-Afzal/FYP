/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class bill{
    public:
     string name,address;
     int billno,unitcons,bill2;
     void input();
     void display();
     void calculate();
};
void bill::input(){
      cout<<"enter the name: ";
      cin>>name;
      cout<<"enter the address: ";
      cin>>address;
      cout<<"enter the billno. : ";
      cin>>billno;
      cout<<"enter the unitcons: ";
      cin>>unitcons;
      }
      void bill::calculate(){
        if (unitcons<300)
        {
            bill2=unitcons*8;
        }
        else if (unitcons>=300 && unitcons<1000)
        {
            bill2=unitcons*5;
        }
        else(unitcons>999);
        {
            bill2=unitcons*14;
        }
   }
   void bill::display(){
    cout<<"the name is "<<"name"<<endl;
    cout<<"the address is "<<"address"<<endl;
    cout<<"the billno. is "<<billno<<endl;
    cout<<"the  units consumed are "<<unitcons<<endl;
    cout<<"the total amount is "<<bill2<<endl;
   }
   int main(){
    bill amount;
    cout<<"......Taking input from user";
    amount.input();
    amount.calculate();
    cout<<".......Displaying input of user";
    amount.display();
   }