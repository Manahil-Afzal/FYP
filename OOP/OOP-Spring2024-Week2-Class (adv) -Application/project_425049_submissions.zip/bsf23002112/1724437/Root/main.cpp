#include <iostream>
using namespace std;

class Utility_Bill{
    
    private:
      string customer_name;
      double bill_number;
      double units_consumed;
      string customer_address;
      int unit_price;
      double bill_amount;
    
    public:
      void getData();
      void calculate();
      void display();
};

int main(){
    Utility_Bill myObj;
    
    myObj.getData();
    myObj.calculate();
    myObj.display();
    
    return 0;
}

void Utility_Bill::getData(){
    
    cout << "Enter Your Name: ";
    getline (cin, customer_name) ;
    
    cout << "Enter Your Bill Number: ";
    cin >> bill_number;
    
    cout << "Enter Units You Consumed: ";
    cin >> units_consumed;
    
    cout << "Enter Your Address: ";
    cin >> customer_address;
    
};

void Utility_Bill::calculate(){
    
    if(units_consumed < 300){
        unit_price = 7;
    }
    else if(units_consumed >= 300 && units_consumed < 1000){
        unit_price = 5;
    }
    else{
        unit_price = 12;
    }
    
    bill_amount = units_consumed * unit_price;
};

void Utility_Bill::display(){
    cout << "Customer Name: " << customer_name << endl ;
    cout << "Bill Number: " << bill_number << endl ;
    cout << "Units Consumed: " << units_consumed << endl ;
    cout << "Customer Address: " << customer_address << endl ;
    cout << "Your Bill Amount is " << bill_amount << "." << endl ;
};/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/