/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class yourBill{
	private:
		string name;
		string address;
		int billNo;
		int unit;
		int bill = 0;
		
	public:
		void getDetail(){
			cout<<"  Enter name : ";
			getline(cin , name);
			cout<<"  Enter your address : ";
			getline(cin,address);
			cout<<"  Enter your bill number : ";
			cin>>billNo;
			cout<<"  Enter units consumed : ";
			cin>>unit;
		}
		void Unit(){
			if(unit>0 && unit<300){
				bill =bill + unit*8;
			}
			else if(unit>=300 && unit<1000){
				bill =bill + unit*5;
			}
			else if(unit>=1000){
				bill =bill + unit*14;
			}else{
			    cout<<"Please enter positive number ";
			}
		}
		void showInfo(){
			cout<<"Dear "<<name;
			cout<<" \nLiving in "<<address<<endl;
			cout<<"Your bill number is : "<<billNo;
			cout<<"\nYou have consumed "<<unit<<" units in this month."<<endl;
			cout<<"\n-*-*-*BILL*-*-*-"<<endl;
			cout<<"\nCurrent bill is :  Rs"<<bill;
		}
		
};

int main(){
	yourBill bill;
	cout<<"Enter Details "<<endl;
	bill.getDetail();
	bill.Unit();
	bill.showInfo();
}