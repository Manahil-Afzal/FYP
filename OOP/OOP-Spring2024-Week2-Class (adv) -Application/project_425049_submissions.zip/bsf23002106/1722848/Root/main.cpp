/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class utility_bill {
private:
	string customer_name;
	int bill_number;
	int unit_consumed;
	string customer_address;
	int bill_amount;
	
public:
	void inputdetails(){
		cout<<"enter customer name : ";
		cin>>customer_name;
		cout<<"enter customer address : ";
		cin>>customer_address;
		cout<<"enter bill number : ";
		cin>>bill_number;
		cout<<"enter unit consumed : ";
		cin>>unit_consumed;

	}
	void calculation(){
		if (unit_consumed<300){
			bill_amount = (unit_consumed*7);
		}
        else if (unit_consumed<1000){
        	bill_amount = (unit_consumed*5);
		}
		else{
			bill_amount = (unit_consumed*12);
		}
	}
	void display(){ 
	cout<<"customer name : "<<customer_name<<endl;
	cout<<"customer address : "<<customer_address<<endl;
	cout<<"customer bill number : "<<bill_number<<endl;
	cout<<"unit consumed : "<<unit_consumed<<endl;
	cout<<"total bill amount is RS."<<bill_amount;
	}
};

int main(){
	utility_bill a;
	cout<<"bill detail:"<<endl;
	a.inputdetails();
	a.calculation();
    a.display();
	}

