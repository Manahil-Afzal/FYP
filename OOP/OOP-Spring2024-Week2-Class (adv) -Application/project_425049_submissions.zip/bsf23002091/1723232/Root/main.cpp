/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;

public:
    // Constructor to initialize the object with input values
    Utility_Bill(string name, int number, int units, string address)
    
        : customerName(name), billNumber(number), unitsConsumed(units), customerAddress(address) {
    }

    // Function to calculate the bill amount based on units consumed and display the details
    void displayBill() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        // Displaying the details
       cout << "Customer Name: " << customerName << endl;
       cout << "Bill Number: " << billNumber << endl;
      cout << "Units Consumed: " << unitsConsumed << endl;
       cout << "Customer Address: " << customerAddress << endl;
       cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    // Example usage of the Utility_Bill class
    Utility_Bill utilityBill("Nimra Asghar", 12345, 500, "123 Main Street");

    // Displaying the bill details
    utilityBill.displayBill();

    return 0;
}
