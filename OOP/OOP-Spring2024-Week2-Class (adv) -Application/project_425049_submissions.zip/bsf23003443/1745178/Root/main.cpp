/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    // Constructor to initialize data members
    UtilityBill(string name, int number, int units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
    }

    // Method to calculate bill amount based on units consumed
    float calculateBillAmount() {
        float perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5;
        } else {
            perUnitPrice = 14;
        }
        return unitsConsumed * perUnitPrice;
    }

    // Method to display utility bill details
    void displayBill() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() << endl;
    }
};

int main() {
    // Example usage
    UtilityBill bill1("John Doe", 12345, 250, "123 Main St");
    UtilityBill bill2("Alice Smith", 54321, 750, "456 Elm St");

    cout << "Utility Bill 1:" << endl;
    bill1.displayBill();

    cout << "\nUtility Bill 2:" << endl;
    bill2.displayBill();

    return 0;
}
