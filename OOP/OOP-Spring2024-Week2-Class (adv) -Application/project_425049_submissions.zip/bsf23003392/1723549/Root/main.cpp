/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class Utility_Bill{
	public:
	void getdata();
	void putdata();
	private:
	string customer_name;
	int bill_number;
	int units_consumed;
	string customer_address;	
	int total_bill;
	};		
	void Utility_Bill::getdata()
	{
		cout<<"Enter customer name:";
		getline(cin,customer_name);
		cout<<"Enter bill number:";
		cin>>bill_number;
		cout<<"Enter units consumed:";
		cin>>units_consumed;
		cin.ignore();
		cout<<"Enter customer address:";
		getline(cin,customer_address);
		if(units_consumed<300)
		{                     
                total_bill=units_consumed*8;              
                              }
          else if(units_consumed>=300&&units_consumed<1000)
          {    total_bill=units_consumed*5;
               }          
               else{total_bill=units_consumed*14;}
	} 	
	void Utility_Bill::putdata()
	{
		cout<<"Customer name:"<<customer_name<<endl;
		cout<<"Bill number:"<<bill_number<<endl;
		cout<<"Units consumed:"<<units_consumed<<endl;
		cout<<"Customer address:"<<customer_address<<endl;
		cout<<"Total Bill:"<<total_bill<<endl;
		}
		int main()
		{
			Utility_Bill bill1;
			bill1.getdata();
			bill1.putdata();
			return 0;
		}
