/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill{
	private:
		string customer_name;
		string bill_number;
		int unit_consumed;
		string customer_address;
	public:
		utility_bill(string name,string number,int consumed,string address)
		{
			customer_name=name;
			bill_number=number;
			unit_consumed=consumed;
			customer_address=address;
		}
     float calculate_bill_amount(){
		float per_unit_price;
		if(unit_consumed<300){
		per_unit_price=8;
		}
		else if(unit_consumed<1000){
		per_unit_price=5;
		}
		else{
		per_unit_price=14;
		}
		return unit_consumed*per_unit_price;
	}
	void utility_bill_display(){
		cout<<"customer  name"<<customer_name<<endl;
		cout<<"bill number"<<bill_number<<endl;
		cout<<"unit consumed"<<unit_consumed<<endl;
		cout<<"customer address"<<customer_address<<endl;
		cout<<"bill amount rs="<<calculate_bill_amount()<<endl;
	}
};


int main()
{
	utility_bill customer1("ali","123445",250,"towmnship");
	customer1.utility_bill_display();
	utility_bill customer2("akbar","123ewoi45",700,"gulshan e ravi");
	customer2.utility_bill_display();
	utility_bill customer3("ahmad","AS123445",1500,"bahria town");
	customer3.utility_bill_display();
}