/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Ubill{

	string name;
	int billno;
	float unitconsumed;
	string address;
	float totelamount;
	public:
	void input(){
		cout<<"Enter custmer name:"<<endl;
		cin>>name;
		cout<<"Enter custmer bill number:"<<endl;
		cin>>billno;
		cout<<"Enter custmer adderess:"<<endl;
		cin>>address;
		cout<<"Entar the consumed units:"<<endl;
		cin>>unitconsumed;
	}
	void processing(){
		if(unitconsumed<300)
		totelamount=unitconsumed*7;
		else if(unitconsumed>300 && unitconsumed<1000)
		totelamount=unitconsumed*5;
		else if(unitconsumed>999)
		totelamount=unitconsumed*12;
	}
	void output(){
		cout<<"NAME-----------:"<<name<<endl;
		cout<<"BILL NUMBER----:"<<billno<<endl;
		cout<<"CUSTMER ADDRESS:"<<address<<endl;
		cout<<"BILL NUMBER----:"<<billno<<endl;
		cout<<"CONSUMED UNITS-:"<<unitconsumed<<endl;
		cout<<"TOTELL AMOUNT------------:"<<totelamount;}
	
	};
	int main()
	{
		Ubill obj1;
		obj1.input();
		obj1.processing();
		obj1.output();
	}
