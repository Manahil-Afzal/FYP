#include<iostream>
using namespace std;
#include<string>

class Utility{
	private:
		string name;
		int    num;
		int    unit;
		string address;
	public:
		void billAmount();
		void display();
};
void Utility::billAmount(){
	cout<<"Name of House Owner : ";
	cin>>name;
	cout<<"Bill Number : ";
	cin>>num;
	cout<<"Units Consumed : ";
	cin>>unit;
	cout<<"Customer Address : ";
	cin>>address;
}
void Utility::display(){
	cout<<"Name of House Owner : "<<name<<endl;
	cout<<"Bill Number : "<<num<<endl;
	if(unit <300)
	{unit = unit * 5;
	cout<<"Units consumed : RS"<<unit<<endl;
    }
    else if(unit >=300 || unit <1000)
	{unit = unit * 8;
     cout<<"Units consumed : RS"<<unit<<endl;
	}
	else
	{unit = unit * 14;
	cout<<"Units consumed : RS"<<unit<<endl;
	}
	cout<<"Customer address : "<<address<<endl;
}
int main()
{Utility b1;
 b1.billAmount();
 b1.display();
}/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/