/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    void getInput() {
        cout << "Enter customer name: ";
        cin.ignore(); // Ignore newline left in buffer
        getline(cin, customerName);

        cout << "Enter bill number: ";
        cin >> billNumber;

        cout << "Enter units consumed: ";
        cin >> unitsConsumed;

        cin.ignore(); // Ignore newline left in buffer
        cout << "Enter customer address: ";
        getline(cin, customerAddress);
    }

    void calculateBill() {
        double perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double totalBill = unitsConsumed * perUnitPrice;

        cout << "\nCustomer Details:\n";
        cout << "Name: " << customerName << "\n";
        cout << "Bill Number: " << billNumber << "\n";
        cout << "Address: " << customerAddress << "\n";
        cout << "Units Consumed: " << unitsConsumed << "\n";
        cout << "Bill Amount: Rs. " << totalBill << "\n";
    }
};

int main() {
    Utility_Bill bill;
    bill.getInput();
    bill.calculateBill();

    return 0;
}
