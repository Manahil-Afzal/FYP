/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utilitybill{
	char name[34];
	char address[50];
	int billnumber;
	int consumunit;
	int total;
	public:
		void input(){
			cout<<"Enter the name of custmer"<<endl;
			cin>>name;
			cout<<"Enter the address of custmer"<<endl;
			cin>>address;
			cout<<"Enter the bill number of custmer"<<endl;
			cin>>billnumber;
			cout<<"Enter the consumed unit of custmer"<<endl;
			cin>>consumunit;
		}
		void display(){
			if(consumunit<300){
				total=8*consumunit;
			}
			else if((consumunit>=300)&&(consumunit<1000)){
				total=5*consumunit;
			}
			else{
				total=14*consumunit;
			}
			cout<<"Custmer Name     :: "<<name<<endl;
			cout<<"Custmer  Address :: "<<address<<endl;
			cout<<"Bill Number      :: "<<billnumber<<endl;
			cout<<"Consum Unit      :: "<<consumunit<<endl;
			cout<<"Total bill       :: "<<total<<endl;
		}
};
int main(){
	Utilitybill b1;
	b1.input();
	b1.display();
 return 0;
}