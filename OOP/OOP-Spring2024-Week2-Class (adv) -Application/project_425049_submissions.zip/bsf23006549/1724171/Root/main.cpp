/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Bill {
	private:
		string consumeName;
		long long billNo;
		int unitConsume;
		string consumAddress;
		float billAmount;
		void billCalc(); // A function to calculate the bill Amount.
	public:
		void Set();
		void Get();
		Bill():billAmount(0.0){} // A constructor to set the billAmount=0.0
};
void Bill:: Set() { //Takes Input
	cout<<"Enter Consumer Name : "<<endl;
	getline(cin,consumeName);
	cout<<"Enter Bill Number : "<<endl;
	cin>>billNo;
	cout<<"Enter Consumed Units : "<<endl;
	cin>>unitConsume;
	cout<<"Enter Consumer Address : "<<endl;
	cin.ignore(); // It is used to clear the input buffer(\n) to avoid the skipping of getline() function as it terminates by encountering (\n) new line character.
	getline(cin,consumAddress);
	billCalc(); // Here I've just called the billCalc() function to calculate amount on basis of provided criteria.
}
void Bill::Get() { //Gives Output
/*it doesn't working here that's why I've commented it	system("cls");*/           // I've used this to make program's output aesthetic by clearing the input on Console.
	cout<<"Consumer Name : "<<consumeName<<endl;
	cout<<"Bill Number is : "<<billNo<<endl;
	cout<<"Consumed Units are : "<<unitConsume<<endl;
	cout<<"Consumer Address is : "<<consumAddress<<endl;
	cout<<"Bill Amount against Customer Id \""<<billNo<<"\" is : "<<billAmount<<endl;

}
void Bill::billCalc() {// It will store the calculated bill amount in data member "billAmount"
	float r;
	if(unitConsume<300) {
		billAmount=unitConsume*8.0;
	} else if(unitConsume>=300 && unitConsume<1000) {
		billAmount=unitConsume*5.0;
	} else {
		billAmount=unitConsume*14.0;
	}


}
int main() {
	Bill b;
	b.Set();
	b.Get();
}