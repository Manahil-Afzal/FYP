/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utilitybill
{
    private:
    string customer_name;
    string bill_number;
    int unit_consumed;
    string customer_address;
    public:
    utilitybill(string name,string number,int consumed,string address)
    {
        customer_name=name;
        bill_number=number;
        unit_consumed=consumed;
        customer_address=address;
    }
    int calculate_bill_amount(){
        int per_unit_price;
        if(unit_consumed<300)
        {
            per_unit_price=7;
        }
        else if(unit_consumed>=300&&unit_consumed<1000)
        {
            per_unit_price=9;
        }
        else{
            per_unit_price=12;
        }
      int bill_amount=unit_consumed*per_unit_price;
      return bill_amount;
    }
    void display_bill(){
        cout<<"customer name:"<<customer_name<<endl;
        cout<<"bill number:"<<bill_number<<endl;
        cout<<"unit consumed:"<<unit_consumed<<endl;
        cout<<"customer address:"<<customer_address<<endl;
        cout<<"bill amount:"<<calculate_bill_amount()<<endl;
    }
};
int main()
{
    utilitybill customer_bill("mehmood","h123",400,"567 main st");
    customer_bill.display_bill();
    return 0;
}
