/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

class UtilityBill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;
    double perUnitPrice;

public:
    // Method to take input for data members from the user
    void inputDetails() {
        std::cout << "Enter Customer Name: ";
        std::cin.ignore();  // Ignore any previous newline character
        std::getline(std::cin, customerName);

        std::cout << "Enter Bill Number: ";
        std::cin >> billNumber;

        std::cout << "Enter Units Consumed: ";
        std::cin >> unitsConsumed;

        std::cout << "Enter Customer Address: ";
        std::cin.ignore();
        std::getline(std::cin, customerAddress);
    }

    // Method to calculate per unit price based on units consumed
    void calculatePerUnitPrice() {
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed >= 300 && unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }
    }

    // Method to display utility bill details on the screen
    void displayDetails() {
        double billAmount = unitsConsumed * perUnitPrice;

        std::cout << "\nUtility Bill Details:\n";
        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Per Unit Price: Rs. " << perUnitPrice << std::endl;
        std::cout << "Total Bill Amount: Rs. " << billAmount << std::endl;
    }
};

int main() {
    // Create an object of the UtilityBill class
    UtilityBill bill;

    // Input details for the utility bill
    std::cout << "Enter Utility Bill Details:\n";
    bill.inputDetails();
    bill.calculatePerUnitPrice();

    // Display details for the utility bill
    bill.displayDetails();

    return 0;
}
