/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class ubill{
	public:
		string c_name;
		string c_adrs;
		int bill_no;
		int bill_a;
		float units_c;
		void inp(){
		cout<<"Enter the Utility Bill Details "<<endl<<endl;
		cout<<"Enter the customer's name    : ";
		cin>>c_name;
		cout<<"Enter the bill no            : ";
		cin>>bill_no;
		cout<<"Enter the units consumed     : ";
		cin>>units_c;
		cout<<"Enter the customer's address :" ;
		cin>>c_adrs;
		}
		void c_units(){
			if(units_c<300){
				bill_a=units_c*8;
			}
			else if(units_c>=300 && units_c<1000){
				bill_a=units_c*5;
			}
			else if(units_c>999){
				bill_a=units_c*14;
			}
		}
	void display(){
		cout<<endl<<"Utility Bill Details"<<endl<<endl<<"Customer Name   :"<<c_name<<endl;
		cout<<"Bill no         :"<<bill_no<<endl;
		cout<<"Units Consumed  :"<<units_c<<endl;
		cout<<"Customer Address:"<<c_adrs<<endl;
		cout<<"Bill Amount     :"<<bill_a<<endl<<endl;
	}		
	};
int main(){
		ubill bill;	
		bill.inp();
		bill.c_units();
		bill.display();
		return 0;
	}
	