/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    UtilityBill(string name, int billNum, int units,string address){
        customerName = name; 
        billNumber = billNum; 
        unitsConsumed = units; 
        customerAddress = address;
    }

    double calculateBillAmount() const {
        double perUnitPrice;
        if (unitsConsumed < 300)
            perUnitPrice = 8.0;
        else if (unitsConsumed < 1000)
            perUnitPrice = 5.0;
        else
            perUnitPrice = 14.0;

        return unitsConsumed * perUnitPrice;
    }

    void display() {
        cout << "Customer Name: " << customerName <<endl;
        cout << "Bill Number: " << billNumber <<endl;
        cout << "Units Consumed: " << unitsConsumed <<endl;
        cout << "Customer Address: " << customerAddress <<endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() <<endl;
    }
};

int main() {
    string name, address;
    int billNum, units;

    cout << "Enter Customer Name: ";
    cin >> name;
    cout << "Enter Bill Number: ";
    cin >> billNum;
    cout << "Enter Units Consumed: ";
    cin >> units;
    cout << "Enter Customer Address: ";
    cin >> address;

    UtilityBill bill(name, billNum, units, address);
    bill.display();

    return 0;
}
