/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include<iostream>
#include <string>
using namespace std;
class utility_bill
{
	private:
		string name;
		string billNumber;
		int unitsConsumed;
		string address;
		float billAmount;
	public:
			void inputDetails();
			void calculatebillAmount();
			void displaydetails();
			
};
void utility_bill::inputDetails()
			{
			cout<<"Enter customer name:"<<endl;
			cin>>name;
			cout<<" enter address:"<<endl;
			cin>>address;
			cout<<"Enter bill number:"<<endl;
			cin>>billNumber;
			cout<<"Enter unit consumed:"<<endl;
			cin>>unitsConsumed;
		
		}
	
		void utility_bill::calculatebillAmount()
		 
		{
			if(unitsConsumed<300){
				billAmount=unitsConsumed*8;
				
			}
			else if(unitsConsumed>=300 && unitsConsumed<1000){
				billAmount=unitsConsumed*5;
				
			}
			
}
void utility_bill::displaydetails(){
	cout<<"name:"<<name<<endl;
	cout<<"bill number:"<<billNumber<<endl;
	cout<<"unit Consumed:"<<unitsConsumed<<endl;
	cout<<"address:"<<address<<endl;
	cout<<"bill amount:"<<billAmount<<endl;
}

	
int main(){
	utility_bill customer1;
	customer1.inputDetails();
	customer1.calculatebillAmount();
	customer1.displaydetails();
	return 0;
}