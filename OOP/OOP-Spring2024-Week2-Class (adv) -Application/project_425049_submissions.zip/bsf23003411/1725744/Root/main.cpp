/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class utility_bill{
	public:
		string custname;
		int billno;
		string customerAddress;
		int unitsconsumed;
		int getdetails()
		{
			cout<<"Enter customers name:";
			cin>>custname;
			cout<<"Enter bill no:";
			cin>>billno;
			cout<<"Enter customers address:";
			cin>>customerAddress;
			cout<<"Enter consumed units:";
			cin>>unitsconsumed;
		}
		int billdetails()
		{
	
			float per_unit_price;
			if(unitsconsumed<300)
			per_unit_price=8.0;
			 else if(unitsconsumed<1000)
			 	per_unit_price=5.0;
			 	else 
			 	per_unit_price=14.0;
			 return unitsconsumed*per_unit_price;
		}
		void displaydetails(){
			cout<<"Customers name:"<<custname<<endl;
			cout<<"Bill no:"<<billno<<endl;
			cout<<"Customers address:"<<customerAddress<<endl;
			cout<<"Units consumed:"<<unitsconsumed<<endl;
			
			cout<<"Bill amount:"<<billdetails()<<endl;
		}
};
int main ()
{
	utility_bill Bill;
	Bill.getdetails();
	Bill.billdetails();
	cout<<"Bill details are:"<<endl;
	Bill.displaydetails();
	return 0;
}
