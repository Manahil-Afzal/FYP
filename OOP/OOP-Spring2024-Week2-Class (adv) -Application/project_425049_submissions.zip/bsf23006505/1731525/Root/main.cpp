/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs
and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5.
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utilitybill{
	private:
		string customername;
		int billno;
		//unit consumed
		int unitcon;
		string customeraddress;
		float x;
		public:
			void input(){
			cout<<"Enter Customer Name:";
			cin>>customername;
			cout<<"Enter Bill No:";
			cin>>billno;
			cout<<"Enter Unit Consumed:";
			cin>>unitcon;
			cout<<"Enter Customer Address:";
			cin>>customeraddress;
			if(unitcon<300){
				x=unitcon*8;
				cout<<"Total bill amount:"<<x<<endl;
			}
				else if(unitcon>=300 && unitcon<1000){
					x=unitcon*5;
					cout<<"Total bill amount:"<<x<<endl;	
			}
			else{
				x=unitcon*14;
				cout<<"Total bill amount:"<<x<<endl;
			}
}
void output(){
	cout<<"Customer Name:"<<customername<<endl;
	cout<<"Bill No:"<<billno<<endl;
	cout<<"Enter Customer Address:"<<customeraddress<<endl;
	cout<<"Enter Unit Consumed:"<<unitcon<<endl;
	cout<<"Total Bill Amount:"<<x<<endl;
}
};
int main(){
utilitybill obj;
obj.input();
obj.output();
return 0;
}