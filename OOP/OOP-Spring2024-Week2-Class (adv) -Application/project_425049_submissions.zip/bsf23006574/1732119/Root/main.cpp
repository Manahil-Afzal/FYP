/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill{
public:
      int billAmount;
      string name;
      int billNo;
      string address;
      int unit_con;
      
    void getInput();
    void disOutput();
    void bill_amount();
};
    void Utility_Bill::getInput(){
        cout<<"enter costumer name:";
        cin>>name;
        cout<<"enter costumer bill no:";
        cin>>billNo;
        cout<<"enter costumer address:";
        cin>>address;
        cout<<"enter unit consumed:";
        cin>>unit_con;
    }
    void Utility_Bill::bill_amount()
    {
        if(unit_con<300){
            billAmount = unit_con*8;
        }
    else if(unit_con>=300 && unit_con<1000)
    {
        billAmount=unit_con*5;
    }
    else(unit_con>999);
    {
        billAmount=unit_con*14;
    }
    }
    void Utility_Bill::disOutput(){
        cout<<"costumer name is:"<<name<<endl;
        cout<<"costumer bill number is:"<<billNo<<endl;
        cout<<"costumer address is:"<<address<<endl;
        cout<<"unit consumed are:"<<unit_con<<endl;
        cout<<"bill amount is:"<<billAmount<<endl;
    }
    int main()
    {
        Utility_Bill b1;
        b1.getInput();
        b1.bill_amount();
        b1.disOutput();
        
        return 0;
    }