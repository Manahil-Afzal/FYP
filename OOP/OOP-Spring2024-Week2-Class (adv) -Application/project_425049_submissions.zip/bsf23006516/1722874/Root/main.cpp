/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*//*Write a program that creates a class to display Utility_Bill. 
The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values 
and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8;
 if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. 
 If units consumed are greater than 999, 
 the per unit price is Rs. 14.*/
 #include<iostream>
 using namespace std;
 class Utility_Bill{
 	private:
 		string name;
 		int bill_num;
 		int consumed_units;
 		string address;
 		int pay_bill;
 	public:
    void input(){
    	cout<<"Enter Your Name: ";
    	cin>>name;
    	cout<<"Enter your Bill Number: ";
    	cin>>bill_num;
    	cout<<"Enter consumed Units: ";
    	cin>>consumed_units;
    	cout<<"Enter Your adress: ";
    	cin>>address;
    	
	}
	void calculate(){
		if(consumed_units<300){
			pay_bill=consumed_units*8;
		}
		else if((consumed_units>=300)&&(consumed_units<1000)){
			pay_bill=consumed_units*5;
		}
		else if(consumed_units>999){
			pay_bill=consumed_units*14;	
		}
	}
	void show(){
		cout<<"Name: "<<name<<endl;
		cout<<"Bill_Number: "<<bill_num<<endl;
		cout<<"Cousumed units: "<<consumed_units<<endl;
		cout<<"Address: "<<address<<endl;
		cout<<"Your Total Bill is: "<<pay_bill<<endl;
	}	
 		
	 	
 };
 int main(){
 	Utility_Bill person1;
 	person1.input();
 	person1.calculate();
 	person1.show();
 }