/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class utilityBills{
    private:
        string customerName;
        int billNumber;
        int unitConsumed;
        string customerAddress;
        double billAmount;
    public:
        void getData(){
            cout<<" Enter A Customer Name: ";
            cin>>customerName;
            
            cout<<" Enter A Bill Number: ";
            cin>>billNumber;
            
            cout<<" Enter A Unit Consumed Value: ";
            cin>>unitConsumed;
            
            cout<<" Enter a Customer Address: ";
            cin>>customerAddress;
            
            if(unitConsumed<300){
                billAmount=unitConsumed*8;
            }else if(unitConsumed==300||unitConsumed<1000||unitConsumed>300){
                billAmount=unitConsumed*5;
            }else if (unitConsumed>=999){
                billAmount=unitConsumed*12;
            }
}
            void display(){
                cout<<" The Customer Name: "<<customerName<<endl;
                cout<<" The Bill Number: "<<billNumber<<endl;
                cout<<" The Unit Consumed: "<<unitConsumed<<endl;
                cout<<" The Customer Address: "<<customerAddress<<endl;
                
                cout<<" The Bill Amount is \n "<<billAmount<<endl;
            }

};
    int main(){
        utilityBills customerNo1;
        customerNo1.getData();
        customerNo1.display();
        return 0;
    }






















