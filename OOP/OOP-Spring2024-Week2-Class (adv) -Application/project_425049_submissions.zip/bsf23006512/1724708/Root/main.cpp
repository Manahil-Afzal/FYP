/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
	class Utility_Bill
	{
		private:
			string customerName;
		    int billNumber;
		    float unitConsumed;
		    string customerAdress;
		    int total;
		public:
			void input();
			void calculateBill();
			void display();
};

int main()
{
	Utility_Bill A1,A2;
	cout<<"Enter data of Customer 1:- \n";
	A1.input();
	A1.calculateBill();
	A1.display();
	
	cout<<"\nEnter data of Customer 2:- \n";
	A2.input();        
	A2.calculateBill();
	A2.display();
}

void Utility_Bill::display()
{
	cout<<"\nCustomer Name: "<<customerName;
	cout<<"\nBill Number: "<<billNumber;
	cout<<"\nUnit Consumed: "<<unitConsumed;
	cout<<"\nCustomer Adress: "<<customerAdress;
}

void Utility_Bill::input()
{
	cout<<"Enter Customer Name: ";
	cin>>customerName;
	cout<<"Enter Bill Number: ";
	cin>>billNumber;
	cout<<"Enter Unit Consumed: ";
	cin>>unitConsumed;
	cout<<"Enter Adress: ";
	cin>>customerAdress;
}

void Utility_Bill::calculateBill()
{
	int total=0;
	if(unitConsumed<300)
	{
		int total=unitConsumed*8;
	    cout<<"\nTotal Amount: "<<total;
	}
	else if(unitConsumed>=300 or unitConsumed<1000)
	{
		int total=unitConsumed*5;
	    cout<<"\nTotal Amount: "<<total;
	}
	else if(unitConsumed>999)
	{
		int total=unitConsumed*14;
	    cout<<"\nTotal Amount: "<<total;
	}
}
