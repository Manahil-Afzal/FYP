/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address
as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price 
is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
 class Utility_bill{
     private:
     string name;
     int bill_number;
     int units;
     string address;
     int bill;
     public:
     Utility_bill(string n, int b, int u, string a){
         name=n;
         bill_number=b;
         units=u;
         address=a;
     }
     void display();
     int billamount();
     
 };
 int Utility_bill::billamount(){
         if(units<300){
             bill=units*8;
         }
         else if(units>=300&&units<1000){
             bill=units*5;
         }
         else if(units>999){
             bill=units*14;
         }
         else{
             cout<<"Invalid input"<<endl;
         }
         return bill;
     }
     
 void Utility_bill::display(){
     cout<<"Customers name: "<<name<<endl;
     cout<<"Customers Bill number: "<<bill_number<<endl;
     cout<<"Customers units consumed: "<<units<<endl;
     cout<<"Customers Address: "<<address<<endl;
     cout<<"Customers Bill: "<<bill<<endl;
 }
 int main(){
     cout<<"Please enter your name: "<<endl;
     string n,a;
    
     getline(cin,n);
     cout<<"Please enter bill number: "<<endl;
     int b;
     cin>>b;
     cout<<"Please enter units: "<<endl;
     int u;
     cin>>u;
     cout<<"Please enter address: "<<endl;
     cin.sync();
     cin.clear();
     getline(cin,a);
     cout<<"Thank you for the cooperation."<<endl;
     Utility_bill b1(n,b,u,a);
     b1.billamount();
     b1.display();
 }