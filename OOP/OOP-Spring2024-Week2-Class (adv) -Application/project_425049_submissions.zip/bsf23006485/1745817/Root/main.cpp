/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utilitybill
{
private:
string name;
string address;
int billno;
int unitsconsumed;
public:
utilitybill()
{}
void inputdetails()
{
cout << "Enter name: ";
        cin >> name;
        cout << "Enter address: ";
        cin >> address;
        cout << "Enter bill no: ";
        cin >> billno;
        cout << "Enter units consumed: ";
        cin >> unitsconsumed;
	}
	void calculatebill()
	{
	int unitprice;
	if(unitsconsumed<300)
		unitprice=8;
		else if(unitsconsumed<1000)
		unitprice=5;
		else
		unitprice=14;
	unitprice=unitsconsumed*unitprice;	
	{
	cout<<"bill amount : RS="<<unitprice;
	}
}
};
int main()
{
	utilitybill bill1;
	bill1.inputdetails();
	bill1.calculatebill();
}