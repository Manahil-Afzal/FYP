#include <iostream>
#include <string>

using namespace std;

// Function to calculate balance based on account type and profit percent
double calculateBalance(double balance, string accountType, double profitPercent) {
    if (accountType == "savings") {
        return balance + balance * (profitPercent / 100);
    } else if (accountType == "PLS") {
        return balance + balance * (profitPercent / 100);
    } else {
        return balance; // If account type is not recognized, return original balance
    }
}

int main() {
    // Variables to store account details
    string accountTitle1, accountTitle2;
    string accountType1, accountType2;
    double balance1, balance2;
    double profitPercent1, profitPercent2;

    // Taking input for account 1
    cout << "Enter details for account 1:" << endl;
    cout << "Account title: ";
    getline(cin, accountTitle1);
    cout << "Account type (savings/PLS): ";
    getline(cin, accountType1);
    cout << "Balance: ";
    cin >> balance1;
    cout << "Profit percent: ";
    cin >> profitPercent1;
    cin.ignore(); // Ignore the newline character left in the buffer

    // Taking input for account 2
    cout << "\nEnter details for account 2:" << endl;
    cout << "Account title: ";
    getline(cin, accountTitle2);
    cout << "Account type (savings/PLS): ";
    getline(cin, accountType2);
    cout << "Balance: ";
    cin >> balance2;
    cout << "Profit percent: ";
    cin >> profitPercent2;

    // Calculate balances
    balance1 = calculateBalance(balance1, accountType1, profitPercent1);
    balance2 = calculateBalance(balance2, accountType2, profitPercent2);

    // Display account details
    cout << "\nDetails of account 1:" << endl;
    cout << "Account Title: " << accountTitle1 << endl;
    cout << "Account Type: " << accountType1 << endl;
    cout << "Balance: " << balance1 << endl;
    cout << "Profit Percent: " << profitPercent1 << "%" << endl;

    cout << "\nDetails of account 2:" << endl;
    cout << "Account Title: " << accountTitle2 << endl;
    cout << "Account Type: " << accountType2 << endl;
    cout << "Balance: " << balance2 << endl;
    cout << "Profit Percent: " << profitPercent2 << "%" << endl;

    return 0;
}
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/