/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
	private:
		string name;
		int unit;
		string adress;
		int billNumber;
		int total;
		public:
			void input();
			void calculation();
			void output();
		
};
int main()
{
	bill obj;
	obj.input();
	obj.calculation();
	obj.output();
	
}
void bill::input()
{
	cout<<"enter name : ";
	cin>> name;
	cout<<"enter consume unit : ";
	cin>>unit;
	cout<<"enter your adress without any space : ";
	cin>>adress;
	cout<<"enter bill number : ";
	cin>>billNumber;	
}
void bill::calculation()
{
	if(unit<300)
	{
		total=unit*8;
	}
	if(unit>=300||unit<1000)
	{
		total=unit*5;
	}
	if(unit>999)
	{
		total=unit*14;
	}
}
void bill::output()
{
	cout<<"your total bill is : "<<total<<endl;
	cout<<"your name : "<<name<<endl;
	cout<<"adress : "<<adress<<endl;
	cout<<"consume units : "<<unit<<endl;
}