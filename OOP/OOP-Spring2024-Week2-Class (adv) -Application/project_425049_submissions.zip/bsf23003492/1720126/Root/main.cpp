/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class utilitybill{
	public:
		string name;
		int billno;
		int unitsconsumed;
		string adress;
		double totalbill;
		void getdetails();
		void calculatebill();
		void displaydetails();
};
void utilitybill::getdetails(){
	cout<<"enter customer name:";
	cin>>name;
	cout<<"enter bill number:";
	cin>>billno;
	cout<<"number of units consumed:";
	cin>>unitsconsumed;
	cout<<"enter adress:";
	cin>>adress;
}
void utilitybill::calculatebill(){
	if(unitsconsumed<300){
	totalbill=unitsconsumed*8;}
	else if(unitsconsumed>=300&&unitsconsumed<1000){
	totalbill=unitsconsumed*5;}
	else if(unitsconsumed>999){
	totalbill=unitsconsumed*14;
}
	
}
void utilitybill::displaydetails(){
		cout<<"customer name:"<<name<<endl;;
	cout<<" bill number:"<<billno<<endl;;
	cout<<"number of units consumed:"<<unitsconsumed<<endl;;
	cout<<" adress:"<<adress<<endl;
	cout<<"total bill:"<<totalbill;
}
int main(){
	utilitybill bill;
	bill.getdetails();
	bill.calculatebill();
bill.displaydetails();
}