/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class utility{
public:
	string name;
	string address;
	int bill_no;
	int units;
};
int main()
{
	int price;
	cout<<"------Required Input-------:";
	utility c1;
	cout<<endl<<"Customer Name:";
	getline(cin, c1.name);
	cout<<"Bill Number:";
	cin>>c1.bill_no;
	cin.ignore();
	cout<<"Address:";
	getline(cin, c1.address);
	cout<<"Consumed Units:";
	cin>>c1.units;
	if(c1.units<0)
	cout<<"inappropriate Input";
	else if(c1.units>0&&c1.units<300)
	price=c1.units*8;
	else if(c1.units>299&&c1.units<1000)
	price=c1.units*5;
	else if(c1.units<999)
	price=c1.units*14;
	cout<<endl<<"----OUTPUT----";	
	cout<<endl<<"Name: "<<c1.name<<endl;
	cout<<"Bill Number: "<<c1.bill_no<<endl;
	cout<<"Address: "<<c1.address<<endl;
	cout<<"Consumed Units: "<<c1.units<<endl;
	cout<<"Bill Price: "<<price<<endl;
	return 0;
}