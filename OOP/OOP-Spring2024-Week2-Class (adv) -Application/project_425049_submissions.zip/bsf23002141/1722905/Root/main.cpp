/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
#include<string.h>
using namespace std;

class UtilityBill {
private:
    string customer_name;
    int bill_number;
    int units_consumed;
    string customer_address;
    double total_bill; 

public:
    void inputdata() {
        cout << "Enter customer name :";
        cin >> customer_name;
        cout << "Enter bill number :";
        cin >> bill_number;
        cout << "Enter units consumed of customer :";
        cin >> units_consumed;
        cout << "Enter customer address :";
        cin >> customer_address;
    }

    void calculation() {
        if (units_consumed < 300) {
            total_bill = units_consumed * 8;
        }
        else if (units_consumed >= 300 && units_consumed < 1000) {
            total_bill = units_consumed * 5;
        }
        else {
            total_bill = units_consumed * 14;
        }
    }

    void getdata() {
        cout << "The customer name :" << customer_name << endl;
        cout << "The customer bill number :" << bill_number << endl;
        cout << "The customer units consumed :" << units_consumed << endl;
        cout << "The customer address :" << customer_address << endl;
        cout << "Total bill amount: Rs. " << total_bill << endl; 
    }
};

int main() {
    UtilityBill s;
    s.inputdata();
    cout<<"---------Total Details--------"<<endl;
    s.calculation();
    s.getdata();

    return 0;
}