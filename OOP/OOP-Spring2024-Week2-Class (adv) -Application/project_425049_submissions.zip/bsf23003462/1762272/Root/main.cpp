/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class Utility_Bill{
    public:
    string name;
    string address;
    int units;
    long num;
    int amount;
    void calculation(int unit){
        if(units<300)
       { amount=units*8;
        cout<<"The amount is"<<amount;}
        else if(units >=300 && units<=1000)
        {amount=units*5;
        cout<<"The amount is :"<<amount<<endl;}
        cout<<"Your Name:"<<name<<endl;
        cout<<"Your Bill Number :"<<num<<endl;
        cout<<"Your Units Are:"<<units<<endl;
        cout<<"Your Address is :"<<address<<endl;
    };
    
    };
    int main()
    {int units;
        Utility_Bill person1;
        cout<<"Enter Your Name:";
        cin>>person1.name;
        cout<<"Enter Your Address:";
        cin>>person1.address;
         cout<<"Enter Your Bill Number:";
        cin>>person1.num;
         cout<<"Enter the Units Consumed:";
        cin>>person1.units;
person1.calculation(units);
         
        
         
    }
    
    
    
    
    
