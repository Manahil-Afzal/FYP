/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>

class UtilityBill {
private:
    std::string customer_name;
    std::string bill_number;
    int units_consumed;
    std::string customer_address;

public:
    UtilityBill(std::string name, std::string number, int consumed, std::string address)
        : customer_name(name), bill_number(number), units_consumed(consumed), customer_address(address) {}

    int calculateBillAmount() {
        int per_unit_price;
        if (units_consumed < 300) {
            per_unit_price = 8;
        } else if (units_consumed >= 300 && units_consumed < 1000) {
            per_unit_price = 5;
        } else {
            per_unit_price = 14;
        }

        return units_consumed * per_unit_price;
    }

    void displayBillInfo() {
        std::cout << "Customer Name: " << customer_name << std::endl;
        std::cout << "Bill Number: " << bill_number << std::endl;
        std::cout << "Units Consumed: " << units_consumed << std::endl;
        std::cout << "Customer Address: " << customer_address << std::endl;
        std::cout << "Bill Amount: Rs. " << calculateBillAmount() << std::endl;
    }
};

int main() {
    UtilityBill customer1("John Doe", "B123456", 250, "123 Main Street");
    customer1.displayBillInfo();

    UtilityBill customer2("Jane Smith", "B789012", 500, "456 Oak Avenue");
    customer2.displayBillInfo();

    UtilityBill customer3("Bob Johnson", "B345678", 1200, "789 Pine Road");
    customer3.displayBillInfo();

    return 0;
}
