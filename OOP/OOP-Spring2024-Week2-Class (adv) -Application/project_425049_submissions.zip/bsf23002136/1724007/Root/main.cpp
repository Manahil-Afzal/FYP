#include <iostream>
#include <string>
using namespace std;

// class
class utilitybill{
private:
    string customerName;
    int billNo;
    string customerAddress;
    int unitsConsumed;
    double billAmount;  

public:

    void inputDetails() {
        cout << "Enter customerName: ";
        cin >> customerName;

        cout << "Enter billNo: ";
        cin >> billNo;

        cout << "Enter customerAddress: ";
        cin >> customerAddress;

        cout << "Enter unitsConsumed: ";
        cin >> unitsConsumed;
    }

    //perunitprice
    void billamount() {
        if (unitsConsumed < 300) {
            billAmount = unitsConsumed * 8;
        } else if (unitsConsumed < 1000) {
            billAmount = unitsConsumed * 5;
        } else {
            billAmount = unitsConsumed * 14;
        }
    }

    void displayDetails() {
        cout << "CustomerName: " << customerName << endl;
        cout << "BillNumber: " << billNo << endl;
        cout << "Customer Address: " << customerAddress << endl;
         cout << "UnitsConsumed: " << unitsConsumed << endl;
        cout << "Bill Amount: Rs " << billAmount << endl;
        
    }
};

int main() {
    utilitybill bill;
    cout << "Utility bills:" << endl;
    bill.inputDetails();
    bill.billamount();
    bill.displayDetails();

    return 0;
}
