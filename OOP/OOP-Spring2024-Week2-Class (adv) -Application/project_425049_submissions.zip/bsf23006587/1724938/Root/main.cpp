/*Write a program that creates a class to display Utility_Bill.
The class should take customer name, bill number, units consumed,
and customer address as inputs and displays the input values and
the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8;
if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class UtilityBill{
	private:
		string CustomerName;
		string BillNo;
		float UsedUnits;
		string UserAddress;
		int bill;
	public:
		void getinfo(){
            cout<<"Please Enter Customer's Info:"<<endl;
			cout<<"Name : ";
			getline(cin,CustomerName);
			cout<<"Bill Number : ";
			cin>>BillNo;
			cout<<"Consumed Units : ";
			cin>>UsedUnits;
            cin.ignore();
            cout<<"Address : ";
			getline(cin,UserAddress);
			
		}
		void totalbill(){
			if(UsedUnits<300){
				bill=UsedUnits*8;
			}
			else if(UsedUnits>=300 && UsedUnits<1000){
				bill=UsedUnits*5;
			}
			else if(UsedUnits>=1000){
				bill=UsedUnits*14;
			}
		}
		void showinfo(){
            cout<<endl;
            cout<<"Details are shown below:"<<endl;
			cout<<"Name : "<<CustomerName<<endl;
			cout<<"Bill Number : "<<BillNo<<endl;
			cout<<"Consumed Units : "<<UsedUnits<<endl;
			cout<<"Address : "<<UserAddress<<endl;
			cout<<"Total Bill : "<<bill;
		}
};
int main(){
	UtilityBill info;
	info.getinfo();
    info.totalbill();
	info.showinfo();
}