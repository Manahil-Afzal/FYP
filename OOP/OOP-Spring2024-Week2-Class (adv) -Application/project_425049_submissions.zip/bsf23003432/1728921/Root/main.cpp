/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class UtilityBill {
    string customerName;
    int billNumber;
    double unitsConsumed;
    string customerAddress;

public:
    void inputDetails() {
        cout << "Enter Customer Name: ";
        cin.ignore();
        getline(cin, customerName);

        cout << "Enter Bill Number: ";
        cin >> billNumber;

        cout << "Enter Units Consumed: ";
        cin >> unitsConsumed;

        cout << "Enter Customer Address: ";
        cin.ignore();
        getline(cin, customerAddress);
    }

    double calculateBillAmount() {
        double perUnitPrice;
        if (unitsConsumed < 300)
            perUnitPrice = 8;
        else if (unitsConsumed < 1000)
            perUnitPrice = 5;
        else
            perUnitPrice = 14;

        return unitsConsumed * perUnitPrice;
    }

    void displayBill() {
        cout << "\nCustomer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() << endl;
    }
};

int main() {
    using namespace std;

    UtilityBill bill;

    cout << "Enter Utility Bill Details:\n";
    bill.inputDetails();

    cout << "\nUtility Bill Information:\n";
    bill.displayBill();

    return 0;
}
