/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_bill
{
    private:
    	string customer_name;
    	int bill_number;
    	string customer_address;
    	int consumed_units;
    	
    public:
	void input_values()
	{
		cout<<"Enter a Customer Name :";
		cin>>customer_name;
		cout<<"Enter a Bill Number :";
		cin>>bill_number;
		cout<<"Enter a Consumed Units :";
		cin>>consumed_units;
		cout<<"Enter a Customer Address :";
		cin>>customer_address;
	}
	
	void calculate_bill()
	{
		int total_bill;
	    if(consumed_units<300)
		{
			total_bill=consumed_units*8;
		}
		else if (consumed_units>=300 || consumed_units<1000){
		
			total_bill=consumed_units*5;
	    }  
		else
		{
	        total_bill=consumed_units*14;  		
		}
		cout<<"=======Bill Display============\n";
		cout<<"Customer Name :"<<customer_name<<endl;
		cout<<"Bill Number :"<<bill_number<<endl;
		cout<<"Consumed units :"<<consumed_units<<endl;
		cout<<"Customer Address :"<<customer_address<<endl;
		cout<<"Total Bill :"<<total_bill<<endl;
    }

};
 int main()
 {
 	Utility_bill billinformation;
    billinformation.input_values();
    billinformation.calculate_bill();
    return 0;
}
 	