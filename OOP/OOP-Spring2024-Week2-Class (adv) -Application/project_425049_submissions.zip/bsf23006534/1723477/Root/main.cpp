#include<iostream>
#include<string>
using namespace std;

class utilityBills {
    private: 
        string customerName;
        int billNumber;
        int unitComsumed;
        string customerAddress;
        double billAmount;
    public: 
        void getData () {
            cout << "Enter a customer Name : ";
            cin >> customerName;
            
            cout << "Enter a Bill Number :";
            cin >> billNumber;
            
            cout << "Enter a Unit Consumed Value : ";
            cin >> unitComsumed;
        
            cout << "Enter a Customer Address : ";
            cin >> customerAddress;
            
            if (unitComsumed < 300){
                billAmount = unitComsumed * 8;
            }else if (unitComsumed == 300 || unitComsumed < 1000 || unitComsumed > 300) {
                billAmount = unitComsumed * 5;
            }else if (unitComsumed >= 999){
                billAmount = unitComsumed * 12; 
            }
        }
        
        void display () {
            cout << "The Customer Name : " << customerName << endl;
            cout << "The Bill Number : " << billNumber << endl;
            cout << "The Unit Consumed " << unitComsumed << endl;
            cout << "The Customer Address " << customerAddress << endl;
            
            cout << "The Bill Amount is \n " << billAmount << endl;
        }
};

int main () {
    utilityBills customerNo1;
    
    customerNo1.getData ();
    customerNo1.display ();
    
    return 0;
}/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/