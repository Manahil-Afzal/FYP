#include <iostream>

using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    Utility_Bill(string name, int number, int units, string address)
        : customerName(name), billNumber(number), unitsConsumed(units), customerAddress(address) {}

    void calculateBillAmount() {
        int perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5;
        } else {
            perUnitPrice = 14;
        }

        int billAmount = unitsConsumed * perUnitPrice;

        
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs." << billAmount << endl;
    }
};

int main() {
    
    Utility_Bill utilityBill("John Doe", 123456, 500, "123 Main Street");
    utilityBill.calculateBillAmount();

    return 0;
}/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/