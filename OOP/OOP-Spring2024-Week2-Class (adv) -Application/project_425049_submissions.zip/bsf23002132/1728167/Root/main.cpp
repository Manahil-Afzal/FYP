/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getdata();
    void putdata();
};

void Book::getdata() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putdata() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getdata();

    cout << "\nEnter details for Book 2:\n";
    book2.getdata();

    cout << "\nEnter details for Book 3:\n";
    book3.getdata();

    cout << "\nDetails of Books:\n";
    
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}