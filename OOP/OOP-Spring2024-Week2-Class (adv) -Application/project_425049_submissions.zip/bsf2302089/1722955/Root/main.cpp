#include <iostream>
#include <string>
using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    double perUnitPrice;

public:
    UtilityBill(string name, int number, int units, string address)
        : customerName(name), billNumber(number), unitsConsumed(units), customerAddress(address) {
        if (unitsConsumed < 300) {
            perUnitPrice = 7.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 12.0;
        }
    }

    void displayBill() {
        double billAmount = unitsConsumed * perUnitPrice;
        cout << "Customer Name: " << customerName <<endl;
        cout << "Bill Number: " << billNumber <<endl;
        cout << "Units Consumed: " << unitsConsumed <<endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Per Unit Price: Rs. " << perUnitPrice <<endl;
        cout << "Bill Amount: Rs. " << billAmount <<endl;
    }
};

int main() {
    UtilityBill myBill("Ahmad Tariq", 123456, 500, "123 Main Street");
    myBill.displayBill();

    return 0;
}
