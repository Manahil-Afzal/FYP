#include<iostream>
using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    // Constructor to initialize the object with user inputs
    UtilityBill(string name, int billNum, int units, string address)
        :customerName(name), billNumber(billNum), unitsConsumed(units), customerAddress(address) {}

    // Function to calculate and display the bill details
    void displayBill() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        // Displaying the bill details
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed <<endl;
        cout << "Customer Address: " << customerAddress <<endl;
    }
};

int main() {
    // Example usage of the UtilityBill class
    UtilityBill bill("Habiba", 12345, 250, "123 Main Street");
    bill.displayBill();


    return 0;
}
