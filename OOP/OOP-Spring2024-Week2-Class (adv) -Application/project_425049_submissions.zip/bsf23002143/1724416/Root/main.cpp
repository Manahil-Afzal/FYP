#include<iostream>
using namespace std;

class UtilityBill {
private:
    string customer_name;
    string bill_number;
    int unit_consumed;
    string customer_address;

public:
    UtilityBill(string name, string number, int consumed, string address) {
        customer_name = name;
        bill_number = number;
        unit_consumed = consumed;
        customer_address = address;
    }

    int calculate_bill_amount() {
        int per_unit_price;
        if (unit_consumed < 300) {
            per_unit_price = 7;
        } else if (unit_consumed < 1000) {
            per_unit_price = 9;  
        } else {
            per_unit_price = 12;
        }

        int bill_amount = unit_consumed * per_unit_price;
        return bill_amount;
    }

    void display_bill() {
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Unit Consumed: " << unit_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;
        cout << "Bill Amount: " << calculate_bill_amount() << endl;
    }
};

int main() {
    
    UtilityBill customer_bill("John Doe", "B123", 500, "123 Main St");
    customer_bill.display_bill();

    return 0;
}
