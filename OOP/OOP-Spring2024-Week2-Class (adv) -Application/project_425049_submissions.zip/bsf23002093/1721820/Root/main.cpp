#include <iostream>
#include <string>

class Utility_Bill {
private:
    std::string customer_name;
    int bill_number;
    int units_consumed;
    std::string customer_address;
    double per_unit_price;

public:
    Utility_Bill(std::string name, int number, int units, std::string address)
        : customer_name(name), bill_number(number), units_consumed(units), customer_address(address) {}

    void calculate_bill_amount() {
        if (units_consumed < 300) {
            per_unit_price = 7.0;
        } else if (units_consumed < 1000) {
            per_unit_price = 5.0;
        } else {
            per_unit_price = 12.0;
        }

        double bill_amount = units_consumed * per_unit_price;

        // Display details and bill amount
        std::cout << "Customer Name: " << customer_name << std::endl;
        std::cout << "Bill Number: " << bill_number << std::endl;
        std::cout << "Units Consumed: " << units_consumed << std::endl;
        std::cout << "Customer Address: " << customer_address << std::endl;
        std::cout << "Bill Amount: Rs. " << bill_amount << std::endl;
    }
};

int main() {
    std::string name, address;
    int number, units;

    std::cout << "Enter Customer Name: ";
    std::getline(std::cin, name);

    std::cout << "Enter Bill Number: ";
    std::cin >> number;

    std::cout << "Enter Units Consumed: ";
    std::cin >> units;

    std::cin.ignore(); // Ignore newline character

    std::cout << "Enter Customer Address: ";
    std::getline(std::cin, address);

    Utility_Bill bill(name, number, units, address);
    bill.calculate_bill_amount();

    return 0;
}
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/