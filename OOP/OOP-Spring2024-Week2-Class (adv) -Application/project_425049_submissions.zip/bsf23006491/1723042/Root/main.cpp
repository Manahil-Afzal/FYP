/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill{
    private:
    string customer_name,customer_address;
    long int bill_number,units_consumed,bill_amount;
    public:
    void input_details()
    {
        cout<<"Enter Customer Name:"<<endl;
        cin>>customer_name;
        cout<<"Enter Bill Number:"<<endl;
        cin>>bill_number;
        cout<<"Enter Units Consumed:"<<endl;
        cin>>units_consumed;
        cout<<"Enter Customer Address:"<<endl;
        cin>>customer_address;
    }
    void processing()
    {
        if (units_consumed<300)
        {
            bill_amount=units_consumed*8;
        }
        else if (units_consumed>=300&&units_consumed<1000)
        {
            bill_amount=units_consumed*5;
        }
        else if(units_consumed>999)
        {
            bill_amount=units_consumed*14;
        }
        
    }
    void displaying()
    {
        cout<<"Customer Name:"<<customer_name<<endl;
        cout<<"Bill Number:"<<bill_number<<endl;
        cout<<"Units Consumed:"<<units_consumed<<endl;
        cout<<"Customer Address:"<<customer_address<<endl;   
        cout<<"Total Bill amount:"<<bill_amount<<endl;
    }
};
main()
{
    Utility_Bill obj1;
    obj1.input_details();
    obj1.processing();
    obj1.displaying();
}