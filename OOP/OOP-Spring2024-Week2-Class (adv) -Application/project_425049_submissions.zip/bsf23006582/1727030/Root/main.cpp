
#include<iostream>
using namespace std;

class Utility_bills{
	private:
		string customer_name;
    	string bill_num;
    	int consumed_units;
    	string customer_add;
    	int per_unit;
    public:
    	void input();
    	void displayinput();
    	void amount();
};

void Utility_bills::input() {
	cout << "Enter the customer name: ";
	cin >> customer_name;
	cout << "Enter the customer Bill no: ";
	cin >> bill_num;
	cout << "Enter the customer address: ";
	cin >> customer_add;
	cout << "Enter the units consumed: ";
	cin >> consumed_units;
}

void Utility_bills::amount() {
	if(consumed_units < 300) {
		per_unit = consumed_units * 8;
	} else if (consumed_units >= 300 && consumed_units < 1000) {
		per_unit = consumed_units * 5;
	} else {
		per_unit = consumed_units * 14;
	}
}

void Utility_bills::displayinput() {
	cout << "Customer Name: " << customer_name << endl;
    cout << "Bill Number: " << bill_num << endl;
    cout << "Customer Address: " << customer_add << endl;
    cout << "Units Consumed: " << consumed_units << endl;
    cout << "Bill amount = " << per_unit << endl;
}

int main() {
	Utility_bills bill;
	bill.input();
	bill.amount();
	bill.displayinput();
	
	return 0;
}