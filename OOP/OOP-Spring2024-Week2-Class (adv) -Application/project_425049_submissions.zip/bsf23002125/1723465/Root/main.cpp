/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class utilityBill{
    private:
        string customerName;
        int billNumber;
        int unitComsumed;
        string customerAddress;
        int totalBill;

    public:
        void input(){
            cout << "Enter your name: ";
            cin >> customerName;
            cout << "Enter your bill number: ";
            cin >> billNumber;
            cout << "Enter your consumed units: ";
            cin >> unitComsumed;
            cout << "Enter your address: ";
            cin >> customerAddress;

        }
        
        void calculate(){
            if (unitComsumed < 300)
            {
                totalBill = unitComsumed*8;
            }
            else if (unitComsumed < 1000)
            {
                totalBill = unitComsumed*5;
            }
            else
            {
                totalBill = unitComsumed*14;
            }

            cout << "Your total bill is: "<< totalBill << endl;
        }
        
        void display(){
            cout << "Customer name is: " << customerName << endl;
            cout << "Customer's bill number is: " << billNumber << endl;
            cout << "The number of units customer consumed: " << unitComsumed << endl;
            cout << "Customer address is: " << customerAddress << endl;
            cout << "Customer bill is: " << totalBill << endl;
        }
};

int main() {

    utilityBill ubs;

    cout << "-----Enter Details-----" << endl;
    ubs.input();
    cout << "-------Your Bill-------" << endl;
    ubs.calculate();
    cout << "---------Result--------" << endl;
    ubs.display();
    return 0;
}