/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class Utility_Bill{
	public:
		int billAmount;
	string name;
	int bill_no;
	string address;
	int units_consumed;

	void getInput();
	void displayOutput();
	void bill_amount();
};
void Utility_Bill::getInput(){
	cout<<"enter the customer name: ";
	cin>>name;
	cout<<"enter the customor Bill no: ";
	cin>>bill_no;
	cout<<"enter the customer address: ";
	cin>>address;
	cout<<"enter the units consumed: ";
	cin>>units_consumed;
}
void Utility_Bill::bill_amount()
{
	if(units_consumed<300)
	{
	    billAmount=units_consumed*8;
	}
	else if(units_consumed>=300 && units_consumed<1000)
	{
		billAmount=units_consumed*5;
	}
	else(units_consumed>999);
	{
		billAmount=units_consumed*14;
	}
}
void Utility_Bill::displayOutput(){
	cout<<"The customer name is: "<<name<<endl;
	cout<<"The customer Bill no is: "<<bill_no<<endl;
	cout<<"The customer address is: "<<address<<endl;
	cout<<"The units consumed are: "<<units_consumed<<endl;
	cout<<"Bill amount is :"<<billAmount<<endl;
}
int main()
{
	Utility_Bill B1;
	B1.getInput();
	B1.bill_amount();
	B1.displayOutput();
	
	return 0;
}