

/*Write a program that creates a class to display electricity bill. The class should take customer name, bill number, units consumed as
inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If unit consumed are less than 300, the per unit price is Rs. 8; if greater than or eual to 300 but less than 1000 the per unit price is
Rs. 8. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class e_bill {
	 private:
	 		int b_no;
	 		char c_name[20];
	 		int units;
	 		double bill;
	 public:
			 void getDetails()
			 {
			 	 cout<< "-------------Enter Customer Details------------"<<endl;
						cout<< "Enter Bill number: "<<endl;
			 	 cin >> b_no;
			 	 cout<< "\nEnter customer name: ";
			 	 cin>>c_name;
			 	 cout<< "\nEnter consumed Units:";
			 	 cin>>units;
			 	 
				}
				void putDetails()
				{
						 cout<< "-------------Enter Customer Details------------"<<endl;
						cout<< "Enter Bill number: "<< b_no;
			 	 cout<< "\nmEnter customer name: "<<c_name;
			 	 cout<< "\nEnter consumed Units:"<<units;
			 	 cout<< "\nBill of customer: "<<bill;
				}
				void calc_bill()
				{
					if(units<300)
						bill=units*8;
					else if(units>=300 && units<1000)
						bill=units*5+(units-299)*5;
					else	
						bill= units*7+(units-999)*5+(units-300)*14;
				}
						
};

int main()
{
	e_bill a1;
	a1.getDetails();
	a1.calc_bill();
	a1.putDetails();
	cout<<"\n";
	return 0;
}