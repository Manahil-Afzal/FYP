/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<string>
#include<iostream> 
using namespace std;
class utility_bill
{
	private:
		string name;
		int bill_number;
		int unit_consumed;
		string address;
		int utility_bill; 
	public:
			void get()
			{
				cout<<"enter customer name: ";
				cin>>name;
				cout<<"enter bill number: ";
				cin>>bill_number;
				cout<<"enter unit consumed in month: ";
				cin>>unit_consumed;
				cout<<"enter address: ";
				cin>>address;
			}
			int calculate_bill()
			{
				if(unit_consumed<300){
					utility_bill=unit_consumed*8;
				}
					else if(unit_consumed>=300 && unit_consumed<1000) 
					{
					utility_bill=unit_consumed*5;
				}
					else{ 
					utility_bill=unit_consumed*14;
				}
				return utility_bill;
			}
			void display()
			{
				cout<<"Customer name: "<<name<<"\n";
				cout<<"Bill number: "<<bill_number<<"\n";
				cout<<"Unit consumed in month: "<<unit_consumed<<"\n";
				cout<<"Address: "<<address<<"\n";
				cout<<"Utility bill: "<<utility_bill<<"\n";
			}
};
int main()
{
	utility_bill customer1;
	customer1.get();
	customer1.calculate_bill();
	cout<<"Customer details"<<"\n";
	customer1.display();
	return 0;
}

