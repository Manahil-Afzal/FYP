#include<iostream>
using namespace std;
class utilityBill{
	private:
		string name;
		int number;
		int unitsConsumed;
		string address;
		public:
			void getinput();
			void show_bill();
};
int main(){
	utilityBill bill;
	bill.getinput();
	bill.show_bill();
	return 0;
}
void utilityBill::getinput(){
	cout<<"\t<............Information about Customer........>"<<endl;
	cout<<"Enter the name of customer: ";
	getline(cin,name);
	cout<<"Enter the address: ";
	getline(cin,address);
	cout<<"Enter the bill Number: ";
	cin>>number;
	cout<<"Enter the units consumed: ";
	cin>>unitsConsumed;
}
void utilityBill::show_bill(){
	cout<<"\t<.............Getting Bill................>"<<endl;
	cout<<"Customer Name: "<<name<<endl;
	cout<<"Address: "<<address<<endl;
	cout<<"Bill Number: "<<number<<endl;
	if(unitsConsumed<300){
		cout<<"The Total Bill on that Units: "<<unitsConsumed*5<<endl;
	}
	else if(unitsConsumed>=300||unitsConsumed<1000){
		cout<<"The Total Bill on that Units: "<<unitsConsumed*7<<endl;
	}
	else if(unitsConsumed>999){
		cout<<"The Total Bill on that "<<unitsConsumed<<" units: "<<unitsConsumed*12<<endl;

	}
}
	