#include<iostream>
using namespace std;

class utility_bill{
private:
    string customer_name;
    int bill_number;
    int units_consumed;
    string customer_address;

public:
    void putdetails(){
        cout << "Enter the customer name: ";
        cin >> customer_name;
        cout << "Enter the bill number: ";
        cin >> bill_number;
        cout << "Enter the units consumed: ";
        cin >> units_consumed;
        cout << "Enter the customer address: ";
        cin >> customer_address;
    }

    int calculate_bill_amount(){
        int per_unit_price;
        if (units_consumed < 300)
            per_unit_price = 7;
        else if (units_consumed < 1000)
            per_unit_price = 5;
        else
            per_unit_price = 12;

        return units_consumed * per_unit_price;
    }

    void display_bill(){
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;
        cout << "Bill Amount: Rs. " << calculate_bill_amount() << endl;
    }
};

int main(){
    utility_bill bill;
    bill.putdetails();
    bill.display_bill();
    return 0;
}