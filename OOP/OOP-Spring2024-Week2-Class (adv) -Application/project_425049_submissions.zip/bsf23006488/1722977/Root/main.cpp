/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/


 #include<iostream>
 using namespace std;
 class utlity_bill {
 	
 		char name[50];
 		int billNumber;
 		int unitesConsumed;
 		char address[30];
 		 float Tbill;
 	public:
 		
	 void getDetails(){
	 cout<<"Enter your name = ";
	 cin>>name;
	 cout<<"Enter your bill number = ";
	 cin>>billNumber;
	 cout<<"Enter your units consumed = ";
	 cin>>unitesConsumed;
	 cout<<"Enter your address = ";
	 cin>>address;

}
void Display(){ 	

	if(unitesConsumed<300){
	//	tbill=(unitesConsumed * 8) ;	
	}
	else if(unitesConsumed >=300 || unitesConsumed>1000 ){
		Tbill=(unitesConsumed * 5);
	}
	else {
		Tbill=(unitesConsumed * 14);
	}
	    cout<<"Name = "<<name<<endl;
	    cout<<"billNumber = "<<billNumber<<endl;
	    cout<<"Consumed Unites = "<<unitesConsumed<<endl;
	    cout<<"Address = "<<address<<endl;
	    cout<<"Your  total bill = "<<Tbill;
}
 };
 
 int main(){
 	utlity_bill b;
 	b.getDetails();
 	b.Display();
 	
 }