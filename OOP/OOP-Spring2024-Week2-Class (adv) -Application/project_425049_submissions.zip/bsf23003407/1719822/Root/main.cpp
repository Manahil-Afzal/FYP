/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14*/
#include<iostream>
#include<string.h>
using namespace std;
class UtilityBills
{
	public:
    string name;
    int billno;
    int unitsconsumed;
    string CustomerAddress;
};
int main()
{
	UtilityBills Obj;
    cout<<"Enter the name of Customer:";
    cin>>Obj.name;
    cout<<"Enter the Bill No:";
    cin>>Obj.billno;
    cout<<"Enter the Consumed Units:";
    cin>>Obj.unitsconsumed;
    cout<<"Enter the Customer Address:";
    cin>>Obj.CustomerAddress;
    int price;
    if(Obj.unitsconsumed<300)
    {
    	price=Obj.unitsconsumed*8;
    	cout<<"The Utility Bill is:"<<price<<endl;
	}
    else if(Obj.unitsconsumed>=300 && Obj.unitsconsumed<1000)
    {
    	price=Obj.unitsconsumed*5;
    	cout<<"The price of Utility Bill is:"<<price<<endl;
	 }
	 else if(Obj.unitsconsumed>999)
	{
		price=Obj.unitsconsumed*14;
		cout<<"The price of Utility Bill is:"<<price<<endl;
	}
	else
	cout<<"Invalid Units"<<endl;
}