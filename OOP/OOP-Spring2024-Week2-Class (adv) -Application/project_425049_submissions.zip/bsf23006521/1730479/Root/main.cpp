/*Write a program that creates a class to display Utility_Bill. 
The class should take customer name, bill number, units consumed, and customer address as inputs and displays
the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8;
if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5.
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill
{
	string consumer_name;
	long bill_no;
	int consumed_units;
	string customer_add;
		public:
		void input()
		{
			cout<<"INPUT SECTION:";
			cout<<endl<<endl<<"Enter name of customer :";
			getline(cin,consumer_name);
			cout<<"Enter address of customer :";
			getline(cin,customer_add);
			cout<<"Enter bill number :";
			cin>>bill_no;
			cout<<"Enter the amount of units consumed :";
			cin>>consumed_units;
		}
		long calculation()
		{
			int d;
			if(consumed_units<300)
				d=consumed_units*5;
			else if(consumed_units<1000)
				d=consumed_units*8;
			else
				d=consumed_units*14;
			return d;			
		}
		void output()
		{	
			cout<<endl<<endl<<"OUTPUT SECTION:"<<endl;
			cout<<endl<<"Name of customer :"<<consumer_name;
			cout<<endl<<"Customer address :"<<customer_add;
			cout<<endl<<"Bill number :"<<bill_no;
			cout<<endl<<"Total units consumed :"<<consumed_units;
			cout<<endl<<"Total bill amount to be paid :"<<calculation();
		}
};
int main()
{
	utility_bill con1;
	con1.input();
	con1.output();
	return 0;
}