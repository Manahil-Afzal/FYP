#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:

    Utility_Bill(string name, int number, int units, string address) {
        customerName = name;
        billNumber = number;
        unitsConsumed = units;
        customerAddress = address;
    }


    float calculateBillAmount() {
        float perUnitPrice;
        
        if (unitsConsumed < 300)
            perUnitPrice = 8.0;
        else if (unitsConsumed >= 300 && unitsConsumed < 1000)
            perUnitPrice = 5.0;
        else
            perUnitPrice = 14.0;
        
        return unitsConsumed * perUnitPrice;
    }


    void displayBill() {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() << endl;
    }
};

int main() {

    Utility_Bill bill("John Doe", 12345, 500, "123 Main Street");

  
    bill.displayBill();

    return 0;
}
