/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>

class UtilityBill {
public:
    UtilityBill(std::string customer_name, std::string bill_number, int units_consumed, std::string customer_address)
        : customer_name(customer_name), bill_number(bill_number), units_consumed(units_consumed), customer_address(customer_address) {
        per_unit_price = calculatePerUnitPrice();
        bill_amount = units_consumed * per_unit_price;
    }

    void displayBill() {
        std::cout << "Customer Name: " << customer_name << std::endl;
        std::cout << "Bill Number: " << bill_number << std::endl;
        std::cout << "Units Consumed: " << units_consumed << std::endl;
        std::cout << "Customer Address: " << customer_address << std::endl;
        std::cout << "Per Unit Price: Rs. " << per_unit_price << std::endl;
        std::cout << "Bill Amount: Rs. " << bill_amount << std::endl;
    }

private:
    std::string customer_name;
    std::string bill_number;
    int units_consumed;
    std::string customer_address;
    double per_unit_price;
    double bill_amount;

    double calculatePerUnitPrice() {
        if (units_consumed < 300) {
            return 8;
        } else if (units_consumed >= 300 && units_consumed < 1000) {
            return 5;
        } else {
            return 14;
        }
    }
};

int main() {
    UtilityBill bill("John Doe", "12345", 500, "123 Main St, City, Country");
    bill.displayBill();
    return 0;
}