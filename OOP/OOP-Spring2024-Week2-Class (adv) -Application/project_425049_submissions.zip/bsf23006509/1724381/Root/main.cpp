/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14*/ 


#include<iostream>
using namespace std;
class ubill{
	private:
		string name;
		int billno;
		float unitcon;
		string adress;
		float amount;
	public:
	    void inputdetail(){
	        	cout<<"Enter customer name:";
	    std::	cin>>name;
	    		cout<<"Enter bill number:";
	    	cin>>billno;
	    		cout<<"Enter units consumed:";
	    	cin>>unitcon;
	    		cout<<"Enter adress:";
	    	cin>>adress;
	    	
		}
	   void calculation(){
	   	if(unitcon<300)
		   {
		   	amount=unitcon*8;
		   }
		else if(unitcon<1000)  
		{
			amount=unitcon*5;
		 } 
		 else{
		 	amount=unitcon*14;
		 }
	   }
	   void myoutput(){
	   	cout<<"Name:"<<name<<endl;
	   	cout<<"Bill number:"<<billno<<endl;
	   	cout<<"Units consumed:"<<unitcon<<endl;
	   	cout<<"Adress:"<<adress<<endl;
	   	cout<<"Amout:"<<amount<<endl;
	   }	
		
};
int main()
{
	ubill obj;
	obj.inputdetail();
	obj.calculation();
	obj.myoutput();
}