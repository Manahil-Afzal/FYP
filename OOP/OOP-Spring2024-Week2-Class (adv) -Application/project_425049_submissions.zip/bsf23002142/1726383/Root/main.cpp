/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
 #include<iostream>
 using namespace std;
 class  UtilityBill{
 	private:
 		string customername;
 		float billnumber;
 		float unitconsumed;
 		string customeraddress;
 		int billammount=0;
 	public:
	 void getinput(){
	 	cout<<" enter the customer name:"<<endl;
	 	cin>>customername;
	 	cout<<" enter the bill number:"<<endl;
	 	cin>>billnumber;
	 	cout<<" enter the no of units consumed:"<<endl;
	 	cin>>unitconsumed;
	 	cout<<" enter the customer address:"<<endl;
	 	cin>>customeraddress;
	 }	
	 void calculation(){
	 	int billammount=0;
	 	if(unitconsumed<300)
	 	{ 
	 	   billammount= unitconsumed*8;
		 }
		 else if(unitconsumed>=300&&unitconsumed<1000){
		 	billammount= unitconsumed*5;
		 	
		 
		 }
		 else
		 billammount= unitconsumed*14;
	 }
 	void displayinput(){
 			cout<<" The customer name is:"<<customername<<endl;
 		   	cout<<" Bill number is:"<<billnumber<<endl;
 		    cout<<" Units consumed name are:"<<unitconsumed<<endl;
 		  	cout<<" The customer address is:"<<customeraddress<<endl;
 		  	cout<<" The bill calculated is:"<<billammount<<endl;
 		
	 }	
 };
 int main(){
 	UtilityBill house1;
 	house1.getinput();
 	house1.calculation();
 	house1.displayinput();
 	return 0;
 	
 }
 
 
 