/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;
class Bill {
	private:
		string customer_name;
		int bill_number;
		int unit_consumed;
		int unit_price;
		string address;
	public:
		void getData(){
			cout << "Enter Customer Name: ";
			cin >> customer_name;
			cout << "Enter Bill Number: ";
			cin >> bill_number;
			cout << "Enter Unit Consumed: ";
			cin >> unit_consumed;
			cout << "Enter Address: ";
			cin >> address;
		}
		void unitCal(){
			if(unit_consumed < 300){
				unit_price = unit_consumed * 7;
			} else if(unit_consumed >= 300 && unit_consumed < 1000){
				unit_price = unit_consumed * 5;
			} else if(unit_consumed > 999){
				unit_price = unit_consumed * 12;
			}
		}
		void total(){
			cout << unit_price;
		}
};

int main(){
	Bill b1;
	b1.getData();
	b1.unitCal();
	b1.total();
}