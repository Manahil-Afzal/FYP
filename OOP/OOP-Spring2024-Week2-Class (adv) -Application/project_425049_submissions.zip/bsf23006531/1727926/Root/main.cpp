#include <iostream>
#include <string>

using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    double perUnitPrice;

public:

    UtilityBill() {
        perUnitPrice = 0.0;
    }


    void inputDetails() {
        cout << "Enter Customer Name: ";
        getline(cin, customerName);

        cout << "Enter Bill Number: ";
        cin >> billNumber;

        cout << "Enter Units Consumed: ";
        cin >> unitsConsumed;

        cin.ignore(); 

        cout << "Enter Customer Address: ";
        getline(cin, customerAddress);

    
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }
    }

    void displayBillAmount() {
        double billAmount = unitsConsumed * perUnitPrice;
        cout << "\nCustomer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    UtilityBill bill;

    cout << "Enter Utility Bill Details: " << endl;
    bill.inputDetails();

    cout << "\nUtility Bill Information: " << endl;
    bill.displayBillAmount();

    return 0;
}
