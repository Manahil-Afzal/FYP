#include<iostream>
#include<string>
using namespace std;

class info{
	public:
	 string c_name;
	 int b_number;
	 float consumed_unit;
	 string address;
};
int main(){
	
	float t_bill;
	 info u_bill;
	 cout<<"enter name of customer : ";
	 cin>>u_bill.c_name;
	 cout<<"enter the bill numer/code : ";
	 cin>>u_bill.b_number;
	 cout<<"enter the amount of consumed unit : ";
	 cin>>u_bill.consumed_unit;
	 cout<<"enter the customer address : ";
	 cin>>u_bill.address;
	 // bill calculation
	 
	 if(u_bill.consumed_unit < 300)
	 {	
	 	t_bill=u_bill.consumed_unit*8;
	 	cout<<"total bill amount : "<<t_bill;
	 }
	 else if(u_bill.consumed_unit> 999){
	 	
	 	t_bill=u_bill.consumed_unit* 14 ;
	 	cout<<"total bill amount : "<<t_bill;
	 }else if(u_bill.consumed_unit >=300 || u_bill.consumed_unit<=1000 )
	 {
	 	t_bill=u_bill.consumed_unit*5;
	 	cout<<"total bill amount : "<<t_bill;
	 }
	 
}