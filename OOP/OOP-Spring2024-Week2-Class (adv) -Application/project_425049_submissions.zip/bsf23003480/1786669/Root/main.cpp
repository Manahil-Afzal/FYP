/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;

class Utility_Bill {
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    
  public:
    // Constructor to initialize the object
    Utility_Bill(string name, int billNum, int units, string address) {
        customerName = name;
        billNumber = billNum;
        unitsConsumed = units;
        customerAddress = address;
    }
    
    // Method to calculate and display the bill amount
    void displayBill() {
        double perUnitPrice;
        
        // Determine the per unit price based on units consumed
        if (unitsConsumed < 300)
            perUnitPrice = 8;
        else if (unitsConsumed < 1000)
            perUnitPrice = 5;
        else
            perUnitPrice = 14;
        
        // Calculate the total bill amount
        double billAmount = unitsConsumed * perUnitPrice;
        
        // Display the bill details
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    // Create an object of Utility_Bill and provide inputs
    Utility_Bill bill1("John Doe", 1234, 500, "123 Main St, City");
    
    // Display the bill
    bill1.displayBill();
    
    return 0;
}
