/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include<iostream>
using namespace std;
int Verify;
float Price;
class Utility_Bills{
	private:
		string Customer_Name;
		float Bill_Number;
		float Units_Consumed;
		string Customer_Address;
		public:
			void getData();
			void showData();
			
};
int main(){
	Utility_Bills bill;
	bill.getData();
	bill.showData();
	return 0;
	
}
void Utility_Bills::getData(){
	cout<<"Enter the information you want to display:"<<endl;
	cout<<"Enter your Name:";
	cin>>Customer_Name;
	cout<<"Enter Bill Number:";
	cin>>Bill_Number;
	cout<<"Enter Units Consumed:";
	cin>>Units_Consumed;
	cout<<"Enter Your Address:";
	cin>>Customer_Address;
	
}
void Utility_Bills::showData(){
	cout<<"\n Welcome"<< Customer_Name<<"!";
	cout<<"\nYour Bill Number is:"<<Bill_Number;
	cout<<"\nYour Units consumed are:"<<Units_Consumed;
	cout<<"\nYour Address is:"<<Customer_Address;
	if( Units_Consumed<300){
		Price=Units_Consumed*8;
		cout<<"Per Unit Price:8";
		cout<<"\nYour payable Bill amount is:"<<Price<<endl;
		
	}
	if(Units_Consumed>=300&&Units_Consumed<1000){
		Price=Units_Consumed*5;
		cout<<"\nPer Unit Price:5";
		cout<<"\nYour payable Bill amount is:"<<Price<<endl;
		
	}
	if (Units_Consumed>=1000){
		Price=Units_Consumed*14;
		cout<<"\nPer Unit Price:14";
		cout<<"\nYour payable Bill amount is:"<<Price<<endl;
	}
}