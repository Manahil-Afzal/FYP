/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;


class UtilityBill {
	public:
  string customerName;
  int billNumber;
  int unitsConsumed;
  string customerAddress;
  double calculatebillamount();
  void displaydetails();
};

//double calculateBillAmount(UtilityBill bill) {
double UtilityBill::calculatebillamount(){

  double perUnitPrice;

  if (unitsConsumed < 300) {
    perUnitPrice = 8;
  } else if (unitsConsumed>300&&unitsConsumed < 1000) {
    perUnitPrice = 5;
  } else {
    perUnitPrice = 14;
  }

  return unitsConsumed * perUnitPrice;
}

void UtilityBill :: displaydetails() {
  cout << "Customer Name: " << customerName << endl;
  cout << "Bill Number: " << billNumber << endl;
  cout << "Units Consumed: " << unitsConsumed << endl;
  cout << "Customer Address: " << customerAddress << endl;
  cout << "Bill Amount: " << calculatebillamount() << endl;
}

int main() {
  UtilityBill bill;

  cout << "Enter customer name: ";
  cin >> bill.customerName;

  cout << "Enter bill number: ";
  cin >> bill.billNumber;

  cout << "Enter units consumed: ";
  cin >> bill.unitsConsumed;

  cout << "Enter customer address: ";
  cin >> bill.customerAddress;
bill.calculatebillamount();
bill.displaydetails();
  //displayBillDetails(bill);

  return 0;
}
