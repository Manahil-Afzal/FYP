#include<iostream>
using namespace std;
class utility_bill{
	private:
		string customer_name,customer_address;
		int bill_number;
		int units_consumed;
		public:
			void putDetails();
			void calculateDetails();
			void getDetails();			
		
};
int main(){
	utility_bill ub;
	ub.putDetails();
	ub.calculateDetails();
	ub.getDetails();
	ub.calculateDetails();
	return 0;
	
}
void utility_bill::putDetails(){
	cout<<"Enter the customer_ details :"<<endl;
	cout<<"customer_name:";
	cin>>customer_name;
	cout<<"bill_number:";
	cin>>bill_number;
	cout<<"units_consumed:";
	cin>>units_consumed;
	cout<<"customer_address:";
	cin>>customer_address;
}
void utility_bill::calculateDetails(){
	if(units_consumed<300){
	cout<<"your units_consumed price is:"<<units_consumed*7<<endl;
	}
	else if(units_consumed>=300 and units_consumed<1000){
		cout<<"your units_consumed price is:"<<units_consumed*5<<endl;
	}
	else if(units_consumed>999){
		cout<<"your units_consumed price is:"<<units_consumed*12<<endl;
	}
	else{
		cout<<"invalid information";
	}
}
void utility_bill::getDetails(){
cout<<"Enter the customer_ details :"<<endl;
	cout<<"customer_name:"<<customer_name<<endl;
	cout<<"bill_number:"<<bill_number<<endl;
	cout<<"units_consumed:"<<units_consumed<<endl;
	cout<<"customer_address:"<<customer_address<<endl;
}