/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include <iostream>
#include <string>

class Utility_Bill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;
    double perUnitPrice;

public:
    void getInput();
    void calculateBill();
    void displayBill();
};

void Utility_Bill::getInput() {
    std::cout << "Enter Customer Name: ";
    std::getline(std::cin, customerName);

    std::cout << "Enter Bill Number: ";
    std::cin >> billNumber;

    std::cout << "Enter Units Consumed: ";
    std::cin >> unitsConsumed;
    std::cin.ignore();  // Clear the newline character from the input buffer

    std::cout << "Enter Customer Address: ";
    std::getline(std::cin, customerAddress);
}

void Utility_Bill::calculateBill() {
    if (unitsConsumed < 300) {
        perUnitPrice = 8.0;
    } else if (unitsConsumed < 1000) {
        perUnitPrice = 5.0;
    } else {
        perUnitPrice = 14.0;
    }
}

void Utility_Bill::displayBill() {
    double totalAmount = unitsConsumed * perUnitPrice;

    std::cout << "\nUtility Bill Details:\n";
    std::cout << "Customer Name: " << customerName << "\n";
    std::cout << "Bill Number: " << billNumber << "\n";
    std::cout << "Units Consumed: " << unitsConsumed << "\n";
    std::cout << "Customer Address: " << customerAddress << "\n";
    std::cout << "Per Unit Price: Rs. " << perUnitPrice << "\n";
    std::cout << "Total Amount: Rs. " << totalAmount << "\n";
}

int main() {
    Utility_Bill utilityBill;

    utilityBill.getInput();
    utilityBill.calculateBill();
    utilityBill.displayBill();

    return 0;
}
