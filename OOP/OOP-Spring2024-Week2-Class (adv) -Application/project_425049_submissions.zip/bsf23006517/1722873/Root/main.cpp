/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>

using namespace std;

class Utility{
	
	string c_name;
	int b_number;
	int u_consumed;
	string c_address;
	int b_amount;
	public:
	void getdata(){
		cout<<"Enter customer's name: ";
		cin>>c_name;
		cout<<"Enter bill number: ";
		cin>>b_number;
		cout<<"Enter units consumed: ";
		cin>>u_consumed;
		cout<<"Enter customer's address: ";
		cin>>c_address;
	}
	
	void calculations(){
		if(u_consumed<300){
			b_amount=u_consumed*8;
			cout<<"Bill Amount is: "<<b_amount;
		}
		else if(u_consumed>=300 && u_consumed<1000){
			b_amount=u_consumed*5;
			cout<<"Bill Amount is: "<<b_amount;
		}
		else if(u_consumed>999){
			b_amount=u_consumed*14;
			cout<<"Bill Amount is: "<<b_amount;
		}
		else{
			cout<<"Wrong input";
		}
	}
	
	void putdata(){
		cout<<"customer's name is: "<<c_name<<endl;
		cout<<"Bill number is: "<<b_number<<endl;
		cout<<"Enter units consumed: "<<u_consumed<<endl;
		cout<<"Customer's address is: "<<c_address<<endl;
		
	}
};

int main(){
	Utility u1;
	u1.getdata();
	u1.putdata();
	u1.calculations();
	return 0;
}