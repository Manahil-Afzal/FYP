/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class Utility_bill {
	private:
		string name;
		string address;
		double bill_number;
		int units_consumed;
		double total_bill;
		
	public:
	     void input_details(){
	     	// getting inputs from user
	     	cout<<" Enter the user name :"<<endl;
	     	cin>>name;
	     	cout<<" Enter the user address :"<<endl;
	     	cin>>address;
	     	cout<<" Enter the bill number :"<<endl;
	     	cin>>bill_number;
	     	cout<<" Enter the units consumed :"<<endl;
	     	cin>>units_consumed;
	     	
	     	
		 }	
		void bill_calculation(){
			// calculate total bill by using nested if statement 
			if(units_consumed<300){
				total_bill = units_consumed*8;
			}
             else if ( units_consumed >=300<1000){
             	total_bill = units_consumed*5;
			 }
			 else if ( units_consumed >999){
			 	total_bill = units_consumed*14;
			 }			
			
		}
		void display_details(){
			// Display Details of the user
			cout<<" The user name is :"<<name<<endl;
			cout<<" The user address is :"<<address<<endl;
			cout<<" The user bill number is :"<<bill_number<<endl;
			cout<<" The user unit consumed is :"<<units_consumed<<endl;
			cout<<" Here is total bill of user :"<<total_bill<<endl;
			
			
		}
};
        int main(){
        	Utility_bill bill;
        	cout<<" Welcome to the Utility Bill Calculator "<<endl;
        	cout<<" Please Enter Your details :"<<endl;
        	bill.input_details();
        	bill.bill_calculation();
        	bill.display_details();
        	cout<<" Here is Your Details . ThankYou!"<<endl;
        	return 0;
        	
		}