/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;
class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
public:
    void input() {
        cout << "Enter Customer Name: ";
        getline(cin, customerName);

        cout << "Enter Bill Number: ";
        cin >> billNumber;

        cout << "Enter Units Consumed: ";
        cin >> unitsConsumed;
        cin.ignore();  // Consume the newline character left in the buffer

        cout << "Enter Customer Address: ";
        getline(cin, customerAddress);
    }

    void calculateBillAmount() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        cout << "\nBill Details:\n";
        cout << "Customer Name: " << customerName << "\n";
        cout << "Bill Number: " << billNumber << "\n";
        cout << "Units Consumed: " << unitsConsumed << "\n";
        cout << "Customer Address: " << customerAddress << "\n";
        cout << "Bill Amount: Rs. " << billAmount << "\n";
    }
};

int main() {
    Utility_Bill bill;
    
    bill.input();
    bill.calculateBillAmount();

    return 0;
}