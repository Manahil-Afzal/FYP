/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

using namespace std;

class Utility_Bill {
private:
    string customer_name;
    string bill_number;
    int units_consumed;
    string customer_address;

public:
    Utility_Bill(string name, string number, int consumed, string address) {
        customer_name = name;
        bill_number = number;
        units_consumed = consumed;
        customer_address = address;
    }

    int calculate_bill_amount() {
        int per_unit_price;
        if (units_consumed < 300) {
            per_unit_price = 8;
        } else if (units_consumed < 1000) {
            per_unit_price = 5;
        } else {
            per_unit_price = 14;
        }
        return units_consumed * per_unit_price;
    }

    void display_bill_details() {
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;
        cout << "Bill Amount: Rs. " << calculate_bill_amount() << endl;
    }
};

int main() {
    Utility_Bill customer1("John Doe", "B001", 250, "123 Main Street");
    customer1.display_bill_details();

    Utility_Bill customer2("Jane Smith", "B002", 500, "456 Elm Street");
    customer2.display_bill_details();

    Utility_Bill customer3("Alice Johnson", "B003", 1200, "789 Oak Street");
    customer3.display_bill_details();

    return 0;
}

