#include<iostream>
using namespace std;
class bill{
	private:
	string name;
	string adress;
	double bill_number;
	int units_consumed;
	double total_bill;

public:
void get_details(){
	cout<<"Enter your name :"<<endl;
	cin>>name;
	cout<<"Enter the adress :"<<endl;
	cin>>adress;
	cout<<"Enter the bill_number :"<<endl;
	cin>>bill_number;
	cout<<"Enter the units consumed :"<<endl;
	cin>>units_consumed;

	
}
void bill_calculation(){
	if(units_consumed<300){
	 total_bill= units_consumed*8;
	}
		else if(units_consumed>=300<1000){
	 total_bill= units_consumed*5;
	}
	else if(units_consumed>999){
	 total_bill= units_consumed*14;
	}
}
void display_details(){
	cout<<"Your name is :"<<name<<endl;
		cout<<"Your address is :"<<adress<<endl;
			cout<<"Your bill number is :"<<bill_number<<endl;
				cout<<"Your consumed units : "<<units_consumed<<endl;
				cout<<"Your calculated bill : "<<total_bill<<endl;
	
}
};
int main(){
	bill myobj;
	cout<<"Enter your details for bill calculations "<<endl;
	myobj.get_details();
	myobj.bill_calculation();
	myobj.display_details();
	cout<<"Jazak-Allah";
	
}/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/