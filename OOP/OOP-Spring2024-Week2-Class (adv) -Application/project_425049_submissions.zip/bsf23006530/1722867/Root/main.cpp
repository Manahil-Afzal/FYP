/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class uBill{
private:
	string name;
	int billNo;
	float unitCon;
	string addr;
	float totalAmount;
public:
	void MyInput(){
		cout<<"Enter customer name: ";
		cin>>name;
		
		cout<<"Enter bill No: ";
		cin>>billNo;
		
		cout<<"Enter unit consumed: ";
		cin>>unitCon;
			
		cout<<"Enter Address: ";
		cin>>addr;
		}	
		
	void calculate(){
		if(unitCon < 300){
			totalAmount = unitCon*8;
			
		}
		else if(unitCon > 300 && unitCon < 1000){
			totalAmount = unitCon*5;
		} else if(unitCon > 999){
			totalAmount = unitCon*14;
		}
	}	
	
	void MyOutput(){
		cout<<"Customer Name: "<<name<<endl;
	    cout<<"Bill No: "<<billNo<<endl;
		cout<<"Unit Consumed: "<<unitCon<<endl;
		cout<<"Address: "<<addr<<endl;
		cout<<"Total Amount: "<<totalAmount<<endl;
		
	}
	
	
};


int main(){
	uBill obj;
	
	cout<<"Customer Details"<<endl;
	obj.MyInput();
	obj.calculate();
	cout<<"\nBill Details"<<endl;
	obj.MyOutput();
	
	return 0;
}