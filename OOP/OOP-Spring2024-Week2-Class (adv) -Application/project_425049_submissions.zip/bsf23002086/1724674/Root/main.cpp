/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class utility_Bill{
	private:
		string name;
		int num;
		int units;
		string address;
		int bill = 0;
	
	public:
	    void input(){
	    	cout<<"   Customer name : ";
	    	cin>>name;
	    	cout<<"   Enter bill num : ";
	    	cin>>num;
	    	cout<<"   Enter Address :";
	    	cin>>address;
	    	cout<<"   Enter units : ";
	    	cin>>units;
	    
		}
		void cal(){
			if(units<300){
				bill += units*8;
			}
			else if(units>=300 && units<1000){
				bill += units*5;
			}
			else if(units>999){
				bill += units*14;
			}
		}
		void display(){
			cout<<"     Customer name is "<<name<<endl;
			cout<<"     Bill No. is "<<num<<endl;
			cout<<"     Address is "<<address<<endl;
			cout<<"     Units consumed "<<units<<endl;
			cout<<"     Your bill is Rs"<<bill<<endl;
		}
};
main(){
	utility_Bill Bill;
	cout<<"Enter your Bill Details : "<<endl;
	Bill.input();
	Bill.cal();
	cout<<"Bill Details : "<<endl;
	Bill.display();
}