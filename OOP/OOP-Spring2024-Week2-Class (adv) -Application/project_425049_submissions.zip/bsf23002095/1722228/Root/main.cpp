/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number,units consumed, and customer address as inputs and
displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5.
If units consumed are greater than 999, the per unit price is Rs. 14.*/


#include<iostream>
using namespace std;
class Utility_Bill{
    private:
    
        string customer_name;
        int bill_number;
        string customer_address;
    
    public:
    
        int units_consumed;
        int units_price;
        
        void personal_detail()
		{
        cout<<" Enter customer name: ";
        cin>>customer_name;
        
        cout<<" Enter customer address: ";
        cin>>customer_address;
        
        cout<<" Enter bill number: ";
        cin>>bill_number;
        
        cout<<" Enter units consumed: ";
        cin>>units_consumed;
    	}
        
        void unit_price_cal()
        {
            if (units_consumed < 300)
            {
                units_price = units_consumed * 8;
            }
            else if (units_consumed >= 300 && units_consumed < 1000 )
            {
                units_price = units_consumed * 5;    
            }
            else if ( units_consumed > 999 )
            {
                units_price = units_consumed * 14;
            }
            cout<<" Your consumed units are "<< units_consumed << " and your bill is "<< units_price <<"." <<endl ;
            cout<<endl;
            cout<<"-------- Thank you --------";
            cout<<endl;
        }
    
};
int main()
{
    Utility_Bill details;
    cout<< " -------- Welcome -------- "<<endl;
    cout<<endl;
    details.personal_detail();
    details.unit_price_cal();
}
    