#include <iostream>
using namespace std;
int Verify;
double Price;
class Utility_Bills{
	private:
		string Name;
		double Bill;
		double Units;
		string Address;
	public:
		void getValues();
		void showValues();
};
int main(){
	Utility_Bills bil1;
	bil1.getValues();
	bil1.showValues();
	return 0;
}
void Utility_Bills :: getValues(){
	cout<<"\nHi! For any assistance please enter the following details. "<<endl<<endl;
	cout<<"Enter your Name: ";
	cin>>Name;
	cout<<"Enter Bill Number: ";
	cin>>Bill;
	cout<<"Enter Units Consumed: ";
	cin>>Units;
	cout<<"Enter Your Address: ";
	cin>>Address;
	cout<<"The dtails entered are correct? "<<endl<<"1.Yes! "<<endl<<"2.No! I made a mistake."<<endl;
	cout<<"Enter Selected Number: ";
	cin>>Verify;
	switch(Verify){
		case 1:
			cout<<"Thanku for Your Cooperation! Your required information is listed below. ";
			break;
		case 2:
			cout<<"\nOk! Enter the correct details again.";
			cout<<"\nEnter your Name: ";
			cin>>Name;
			cout<<"Enter Bill Number: ";
			cin>>Bill;
			cout<<"Enter Units Consumed: ";
			cin>>Units;
			cout<<"Enter Your Address: ";
			cin>>Address;
			break;
		default:
			cout<<"\nInvalid choice.";
			cout<<"Please Select Again:"<<endl<<"1.Yes! "<<endl<<"2.No! I made a mistake"<<endl;
			cout<<"Enter Selected Number: ";
			cin>>Verify;
			break;
			}
	
}
void Utility_Bills :: showValues(){
			cout<<"\nWelcome "<<Name;
			cout<<"\nYour Bill Number:"<<Bill;
			cout<<"\nYour Units consumed: "<<Units;
			cout<<"\nYour Address:"<<Address;

			if(Units<300){
			Price=Units * 8;
			cout<<"Per Unit Price: 8";
			cout<<"\nThe amount of Bill to be paid: "<<Price<<endl;	
			}
			if(Units>=300 && Units<1000){
			Price=Units * 5;
			cout<<"\nPer Unit Price: 5";
			cout<<"\nThe amount of Bill to be paid: "<<Price<<endl; 
			}
			if(Units>=1000){
			Price=Units * 14;
			cout<<"\nPer Unit Price: 14";
			cout<<"\nThe amount of Bill to be paid: "<<Price<<endl; 
			}
}