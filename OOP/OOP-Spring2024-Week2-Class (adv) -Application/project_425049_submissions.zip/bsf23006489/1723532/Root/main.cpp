/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std ;
class bill{
	public:
		int bill;
	string name;
	int billno;
	int consumed;
	string address;
	void getinput();
	void displayoutput();
	void calculate();
};
void bill::getinput(){
	cout<<"enter the customer name: ";
	cin>>name;
	cout<<"enter the customor Bill no: ";
	cin>>billno;
	cout<<"enter the customer address: ";
	cin>>address;
	cout<<"enter the units consumed: ";
	cin>>consumed;
}
void bill::calculate(){
	if(consumed<300){
		  bill=consumed*8;
		 
	}
	else if(consumed>=300 && consumed<1000){
		  bill=consumed*5;
	}
	else(consumed>999);{
		  bill=consumed*14;
	}
	
	
}


void bill::displayoutput(){
	cout<<"the customer name is: "<<name<<endl;
		cout<<"the customer Bill no is:  "<<billno<<endl;
			cout<<"the customer address is:  "<<address<<endl;
				cout<<"the units consumed are:  "<<consumed<<endl;
				cout<<"bill amount is :"<<bill<<endl;
}

main(){
	bill B1;
	B1.getinput();
	B1.calculate();
	B1.displayoutput();
}