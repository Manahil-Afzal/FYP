/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
 using namespace std;
 class bill{
 	public:
   string name, address;
   float number,unit, consumed;
   void display_input();
   void calculated();
   void display_output();
 };
 void bill::display_input(){
    cout<<"Enter the customer name: ";
    cin>>name;
   cout<<"Enter the customer address: ";
    cin>>address;
   cout<<"Enter the bill no: ";
   cin>>number;
	cout<<"Enter the consumed bill: ";
   cin>>consumed;
 }
   void bill::calculated(){
   if(consumed<300)
   {
   unit=consumed*8;
	}
    else if(consumed>=300 && consumed<1000)
 {
	unit=consumed*5;
 }
    else(consumed>999);
	{
		unit=consumed*14;
	}
 }
 void bill::display_output(){
    cout<<"\n The name of customer is "<<name<<endl;
    cout<<"The address of customer is "<<address<<endl;
    cout<<"The bill-no of customer is "<<number<<endl;
    cout<<"The consumed units of customer is "<<consumed<<endl;
    cout<<"The total amount of bill is "<<unit;
 }
 int main()
 {
   bill	utility_bill ;
 utility_bill.display_input();
 utility_bill.calculated();
 utility_bill.display_output();
 }