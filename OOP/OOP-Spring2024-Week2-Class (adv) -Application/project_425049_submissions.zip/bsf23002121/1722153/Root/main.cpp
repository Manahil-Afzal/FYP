/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class YourBill{
	private:
		string name;
		string address;
		int BillNum;
		int unit;
		int Bill = 0;
		
	public:
		void Input(){
			cout<<"  Enter name : ";
			getline(cin , name);
			cout<<"  Enter your address : ";
			getline(cin,address);
			cout<<"  Enter your bill number : ";
			cin>>BillNum;
			cout<<"  Enter units consumed : ";
			cin>>unit;
		}
		void Unit(){
			if(unit<300){
				Bill += unit*8;
			}
			else if(unit>=300 && unit<1000){
				Bill += unit*5;
			}
			else if(unit>=1000){
				Bill += unit*14;
			}
		}
		void Output(){
			cout<<name<<" living at '"<<address<<"'"<<endl;
			cout<<"with bill number "<<BillNum<<" has consumed "<<unit<<" units this month."<<endl;
			cout<<"\n~~~~~~~~~~~~~~~~BILL~~~~~~~~~~~~~~~~"<<endl<<endl;
			cout<<"Current bill is :  Rs"<<Bill;
		}
		
};

int main(){
	YourBill bill;
	cout<<"Enter Details "<<endl;
	bill.Input();
	bill.Unit();
	cout<<endl;
	bill.Output();
}