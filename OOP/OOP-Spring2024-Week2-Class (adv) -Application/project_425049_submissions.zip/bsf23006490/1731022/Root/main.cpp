/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
                                                     /*CODE*/
#include<iostream>
using namespace std;
class Utility_bill{
	private:
		string C_Name;
		int Bill_Number;
		int Cons_Unit;
		string C_Address;
		int Bill;
		public:
		int  C_Details();
		int	Bill_Calculate();
		int	Display_Details();
};
int Utility_bill::C_Details(){
	cout<<"Enter Customer Name:";
    cin>>C_Name;
   cout<<"Enter Bill Number:";
   cin>>Bill_Number;
   cout<<"Enter Consumed Units:";
   cin>>Cons_Unit;
   cout<<"Enter Constumer Address:";
   cin>>C_Address;
}
int Utility_bill::Bill_Calculate(){
	if(Cons_Unit<300)
	Bill=Cons_Unit*7;
	else if(Cons_Unit>=300 && Cons_Unit<1000)
	Bill=Cons_Unit*5;
	else if(Cons_Unit>=1000)
	Bill=Cons_Unit*12;

}
int Utility_bill::Display_Details(){
	cout<<"Customer Name:"<<C_Name<<endl; 
	cout<<"Customer Bill Number:"<<Bill_Number<<endl;
	cout<<"Customer Consumed Units:"<<Cons_Unit<<endl;
	cout<<"Customer Address:"<<C_Address<<endl;
	cout<<"Customer Total Bill:"<<Bill<<endl;
}
int main(){
Utility_bill Bill_1;
cout<<"Enter Bill Details:"<<endl;
  Bill_1.C_Details();
  Bill_1.Bill_Calculate();
  cout<<"Your Bill Details:"<<endl;
  Bill_1.Display_Details();
}                                                     