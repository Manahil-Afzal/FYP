/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

class Utility_Bill {
private:
    std::string customer_name;
    int bill_number;
    int units_consumed;
    std::string customer_address;

public:
    // Constructor to initialize member variables
    Utility_Bill(const std::string& name, int bill_no, int units, const std::string& address)
        : customer_name(name), bill_number(bill_no), units_consumed(units), customer_address(address) {}

    // Calculate bill amount based on units consumed
    double calculate_bill_amount() {
        double per_unit_price;
        if (units_consumed < 300) {
            per_unit_price = 8.0;
        } else if (units_consumed < 1000) {
            per_unit_price = 5.0;
        } else {
            per_unit_price = 14.0;
        }
        return units_consumed * per_unit_price;
    }

    // Display customer details and bill amount
    void display_bill() {
        std::cout << "Customer Name: " << customer_name << std::endl;
        std::cout << "Bill Number: " << bill_number << std::endl;
        std::cout << "Units Consumed: " << units_consumed << std::endl;
        std::cout << "Customer Address: " << customer_address << std::endl;
        std::cout << "Bill Amount: Rs. " << calculate_bill_amount() << std::endl;
    }
};

int main() {
    // Example usage
    Utility_Bill bill1("John Doe", 12345, 500, "123 Main St, City");
    bill1.display_bill();

    return 0;
}
