//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }

    // Post-increment operator overloading
    Time operator++(int) {
        Time temp(hr, min);
        min++;
        if (min == 60) {
            min = 0;
            hr++;
            if (hr == 24) {
                hr = 0;
            }
        }
        return temp;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Post-increment

    t1.display();

    return 0;
}
