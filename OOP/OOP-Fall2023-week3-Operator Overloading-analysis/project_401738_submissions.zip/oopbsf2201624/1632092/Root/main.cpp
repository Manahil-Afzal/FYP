//This program is meant to post-increment a time's object and display the results

#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overload the unary post-increment operator ++
    Time operator++(int) {
        Time temp(hr, min);  // Create a temporary copy of the current object
        hr++;
        min++;
        cout << "Hours and Minutes: " << hr << "'" << min << endl;
        return temp;  // Return the original value before the increment
    }
};

int main() {
    Time t1(4, 45);
    t1++;
    return 0;
}