//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void displayTime() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }

    Time operator++(int) {
        Time temp(hr, min);
        hr++;
        min++;
        return temp;
    }
};

int main() {
    Time t1(4, 45);
    t1.displayTime();

    t1++;
    t1.displayTime();

    return 0;
}