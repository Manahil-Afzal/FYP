#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "'" << min << endl;
    }

    // Overload the post-increment operator (++)
    Time operator++(int) {
        Time temp = *this; // Create a temporary copy of the current object
        hr++;
        min++;
        return temp; // Return the copy of the original object
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Post-increment t1
    t1.display(); // Display the updated time

    return 0;
}
