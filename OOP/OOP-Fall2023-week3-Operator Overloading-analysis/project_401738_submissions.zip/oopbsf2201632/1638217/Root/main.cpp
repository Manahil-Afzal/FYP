//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
int hr, min;
public:
	Time(int h, int m)
	{
	hr = h;
	min = m;	}
   Time operator++(int) 
	{
		hr++;
		min++;}
	void display(){
	    cout<<"After increment="<<hr<<":"<<min;
	}};

int main()
{
	Time t1(4, 45);
	t1++; 
	t1.display();
	return 0;
}
