//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }
    void display() {
        cout << "Hours and Minutes: " << hr << " hours " << min << " minutes" << endl;
    }
    Time operator++() {
        ++hr;
        ++min;
        return *this;
    }
};
int main() {
    Time t1(4, 45);
    t1.display();
    ++t1;
    t1.display();
    return 0;
}