//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Post-increment operator overload
    void operator++(int) {
        hr++;
        min++;

        cout << "\nHours and Minutes: " << hr << "'" << min;
    }
};

int main() {
    Time t1(4, 45);
    t1++;  // Post-increment

    return 0;
}
