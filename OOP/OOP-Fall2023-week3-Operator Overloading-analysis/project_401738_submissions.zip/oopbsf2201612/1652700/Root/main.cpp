#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void display() {
        cout << "Time: " << hr << "h " << min << "m" << endl;
    }

    Time operator++(int) {
        Time temp = *this;
        hr++;
        min++;

        return temp;
    }
};

int main() {
    Time t1(4, 45);
    t1.display();

    t1++; // Post-increment t1
    t1.display();

    return 0;
}
