//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
int hr, min;
public:
	Time(int h, int m)
	{
	hr = h;
	min = m;
	}
   int operator++(int) 
	{
		++hr;
		++min;
	}
	void display()
	{
	 
cout << "\n Hours and Minutes " << hr << "'" << min<<endl;
 }
  };
int main()
{
	Time t1(4, 45);
	cout<<"Before increament";
	t1.display();
	t1++;  
	cout<<"After the increament";
	t1.display();
	return 0;
}
