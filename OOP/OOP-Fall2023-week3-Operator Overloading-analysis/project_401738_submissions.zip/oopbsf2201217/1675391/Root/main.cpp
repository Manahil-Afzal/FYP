//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overloaded ++ operator as a member function
    Time operator++() {
        ++hr;
        ++min;
        return *this;  // Return the updated object
    }

    // Display the time
    void display() {
        cout << "Hours and Minutes: " << hr << " hours " << min << " minutes" << endl;
    }
};

int main() {
    Time t1(4, 45);

    // Use the overloaded ++ operator
    ++t1;

    // Display the updated time
    t1.display();

    return 0;
}
 