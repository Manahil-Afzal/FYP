//This program is meant to post-increment a time's object and display the results


#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overload the post-increment operator (++)
    Time operator++(int) {
        Time temp(hr, min);
        hr++;
        min++;
        return temp;
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "'" << min << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Post-increment t1
    t1.display(); // Display the result
    return 0;
}