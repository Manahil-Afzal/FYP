//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overload the post-increment operator (++)
    Time operator++(int) {
        Time temp(hr, min); // Create a temporary Time object
        hr++;
        min++;
        return temp; // Return the temporary object
    }

    void display() {
        cout << "\n Hours and Minutes " << hr << "'" << min;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Post-increment the t1 object
    t1.display(); // Display the result
    return 0;
}