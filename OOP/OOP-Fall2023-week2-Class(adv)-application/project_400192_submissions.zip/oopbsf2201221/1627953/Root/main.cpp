/*Write a program that creates a class to display Utility_Bill.
The class should take customer name, bill number, units consumed,
and customer address as inputs and displays the input values and 
the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8;
if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5.
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class ut_bill
{
string name;
int billno;
int units;
int unitprice;
string address;
int billamount;
public:
	void input();
	void calculation();
	void display();
};
int main()
{
	ut_bill user;
	user.input();
	user.calculation();
	user.display();
}
void ut_bill :: input() {
	cout<<"Enter customer name :";
	cin>>name;
	cout<<"Enter billno. :";
	cin>>billno;
	cout<<"Enter units :";
	cin>>units;
	cout<<"Enter costumer address :"<<endl;
	cin>>address;	
	}
void ut_bill :: calculation (){
if(units<300){
	billamount=units*8;
	cout<<"Bill amount :"<<billamount;

}
if(units>=300 && units<1000) {
		billamount=units*5;
		cout<<"Bill amount :"<<billamount;

}
if(units>999){
	billamount=units*14;
cout<<"Bill amount :"<<billamount<<endl;

}
}
void ut_bill :: display() {
cout<<"Name :"<<name<<endl<<"billno :"<<billno<<endl<<"units :"<<units<<endl<<"Costumer address :"<<address<<endl;
cout<<"Bill amount :"<<billamount;
}
