/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class utilitybill{
    private:
    string customername;
    int billnumber;
    int unitsconsumed;
    string customeradress;
    
    public:
    utilitybill(string name,int number,int units,string adress){
        customername = name;
        billnumber = number;
        unitsconsumed = units;
        customeradress = adress;
    }
    void displaybill(){
        double perunitprice;
        if(unitsconsumed<300)
        perunitprice = 8;
        else if(unitsconsumed<1000)
        perunitprice = 5;
        else 
        perunitprice = 14;
        
        double billamount = unitsconsumed*perunitprice;
        
        
        cout<<"custmer name"<<customername<<endl;
        cout<<"bill number"<<billnumber<<endl;
        cout<<"units consumed"<<unitsconsumed<<endl;
        cout<<"customer adress"<<customeradress<<endl;
        cout<<"per unit price"<<perunitprice<<endl;
        cout<<"bill amount"<<billamount<<endl;
    }
};


int main(){
    utilitybill bill1("azmatali",1234,275,"kot imam din");
    utilitybill bill2("asadali",5678,876,"jamia moti masjid");
    
    
    bill1.displaybill();
    bill2.displaybill();
    return 0;
}
    
        
    
    
