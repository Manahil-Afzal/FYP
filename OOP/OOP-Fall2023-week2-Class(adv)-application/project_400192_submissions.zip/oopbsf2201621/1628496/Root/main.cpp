/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

class Utility_Bill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;

public:
    // Constructor to initialize the class members
    Utility_Bill(std::string name, int number, int units, std::string address)
        : customerName(name), billNumber(number), unitsConsumed(units), customerAddress(address) {
    }

    // Calculate and display the bill amount based on units consumed and per unit price
    void displayBill() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Bill Amount: Rs. " << billAmount << std::endl;
    }
};

int main() {
    std::string name, address;
    int billNumber, unitsConsumed;

    std::cout << "Enter Customer Name: ";
    std::getline(std::cin, name);

    std::cout << "Enter Bill Number: ";
    std::cin >> billNumber;

    std::cout << "Enter Units Consumed: ";
    std::cin >> unitsConsumed;

    std::cin.ignore(); // Clear newline character from input buffer

    std::cout << "Enter Customer Address: ";
    std::getline(std::cin, address);

    // Create an instance of the Utility_Bill class
    Utility_Bill bill(name, billNumber, unitsConsumed, address);

    // Display the bill details and calculated amount
    bill.displayBill();

    return 0;
}