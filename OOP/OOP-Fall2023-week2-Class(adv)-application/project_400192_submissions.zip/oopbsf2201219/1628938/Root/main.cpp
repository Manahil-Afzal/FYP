/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class utilityBill{
	private:
		string customerName;
		int billNo;
		int unitsConsumed;
		string customerAddress;
		double perUnitPrice;
		double billAmount;
	public:
		void getDetails();
		void calculateBill();
		void displayDetails();
};

void utilityBill::getDetails()
{
	cout<<"Enter customer name:";
	cin>>customerName;
	cout<<"Enter bill number:";
	cin>>billNo;
	cout<<"Enter units consumed:";
	cin>>unitsConsumed;
	cout<<"Enter address of customer:";
	cin>>customerAddress;
}

void utilityBill::calculateBill() 
{
	if (unitsConsumed<300){
		
		perUnitPrice=8.0;
	} else if (unitsConsumed<1000){

		perUnitPrice=5.0;
	} else { (unitsConsumed>999);
	
	perUnitPrice=14.0;
	}
	billAmount=unitsConsumed*perUnitPrice;
}

void utilityBill::displayDetails()
{
	cout<<"Enter customer name:"<<customerName<<endl;
	cout<<"Enter bill number:"<<billNo<<endl;
	cout<<"Enter units consumed:"<<unitsConsumed<<endl;
	cout<<"Enter address of customer:"<<customerAddress<<endl;
	cout<<"Per Unit Price is:""Rs."<<perUnitPrice<<"/-"<<endl;
	cout<<"The bill amount is:""Rs."<<billAmount<<"/-"<<endl;						
};

int main()
{

utilityBill Bill;
	Bill.getDetails();
	Bill.calculateBill();
	Bill.displayDetails();
	
	return 0;
	
}
