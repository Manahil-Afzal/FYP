#include <iostream>
#include <string>

class Utility_Bill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;

    // Constants for per unit prices
    static const double LOW_RATE = 8.0;
    static const double MEDIUM_RATE = 5.0;
    static const double HIGH_RATE = 14.0;

public:
    Utility_Bill(const std::string& name, int number, int units, const std::string& address)
        : customerName(name), billNumber(number), customerAddress(address) {
        
        // Validate and set units consumed
        if (units < 0) {
            std::cerr << "Error: Units consumed cannot be negative. Setting to 0." << std::endl;
            unitsConsumed = 0;
        } else {
            unitsConsumed = units;
        }
    }

    void displayBill() {
        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;

        double perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = LOW_RATE;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = MEDIUM_RATE;
        } else {
            perUnitPrice = HIGH_RATE;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        std::cout << "Per Unit Price: Rs. " << perUnitPrice << std::endl;
        std::cout << "Bill Amount: Rs. " << billAmount << std::endl;
    }
};

// Initialize static constants
const double Utility_Bill::LOW_RATE;
const double Utility_Bill::MEDIUM_RATE;
const double Utility_Bill::HIGH_RATE;

int main() {
    // Example usage of the Utility_Bill class
    Utility_Bill myBill("John Doe", 123456, 500, "123 Main Street");

    // Display the utility bill details and amount
    myBill.displayBill();

    return 0;
}
