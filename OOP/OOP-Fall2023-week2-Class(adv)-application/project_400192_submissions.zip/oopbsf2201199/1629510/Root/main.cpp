/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class Bill {
private:
    string customername;
    int billnumber;
    int unitconsume;
    string customeraddress;
    int totalprice;
    int perUnitprice;

public:
    Bill() {
        totalprice = 0;
        perUnitprice = 0;
    }

    void getData() {
        cout << "Enter your name: ";
        cin >> customername;
        cout << "Enter Bill Number: ";
        cin >> billnumber;
        cout << "Enter units consumed: ";
        cin >> unitconsume;
        cout << "Enter your address: ";
        cin >> customeraddress;
    }

    void calculateBill() {
        if (unitconsume < 300) {
            perUnitprice = 8;
        }
        else if (unitconsume < 1000) {
            perUnitprice = 5;
        }
        else {
            perUnitprice = 14;
        }
        totalprice = unitconsume * perUnitprice;
    }

    void putData() {
        calculateBill();
        cout << "Customer Name: " << customername << endl;
        cout << "Bill Number: " << billnumber << endl;
        cout << "Unit Consume: " << unitconsume << endl;
        cout << "Customer Address: " << customeraddress << endl;
        cout << "Total Amount: Rs. " << totalprice << endl;
    }
};

int main() {
    Bill std;
    std.getData();
    std.putData();
    return 0;
}
