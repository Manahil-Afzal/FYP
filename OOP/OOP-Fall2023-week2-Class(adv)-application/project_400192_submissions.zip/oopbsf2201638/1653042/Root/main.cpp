/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>

class UtilityBill {
private:
    std::string customerName;
    std::string billNumber;
    int unitsConsumed;
    std::string customerAddress;

public:
    
    void inputBillDetails() {
        std::cout << "Enter Customer Name: ";
        std::cin >> customerName;
        std::cout << "Enter Bill Number: ";
        std::cin >> billNumber;
        std::cout << "Enter Units Consumed: ";
        std::cin >> unitsConsumed;
        std::cout << "Enter Customer Address: ";
        std::cin.ignore(); 
        std::getline(std::cin, customerAddress);
    }


    double calculateBillAmount() {
        double perUnitPrice;
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }
        return unitsConsumed * perUnitPrice;
    }
    void displayBillDetails() {
        std::cout << "\nCustomer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Bill Amount: Rs. " << calculateBillAmount() << std::endl;
    }
};

int main() {

    UtilityBill utilityBill;

    std::cout << "Enter Utility Bill Details:\n";
    utilityBill.inputBillDetails();

    utilityBill.displayBillDetails();

    return 0;
}
