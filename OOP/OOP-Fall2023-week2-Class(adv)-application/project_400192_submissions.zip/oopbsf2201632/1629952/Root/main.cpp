/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
    public:
    string name;
    int bill_no;
    string address;
    float units;
    float u_price;
    float bill_amount;
    public:
    void getDetails();
    void displayDetails();
    };

int main(){
    bill b1;
    b1.getDetails();
    b1.displayDetails();
}
void bill::getDetails(){
    cout<<"Enter Customer Name:"<<endl;
    cin>>name;
    cout<<"Enter Bill Number:"<<endl;
    cin>>bill_no;
    cout<<"Enter Address:"<<endl;
    cin>>address;
    cout<<"Enter the Number of Units Consumed:"<<endl;
    cin>>units;
    if(units<300){
        u_price=8;
    }else if(units>=300 && units<1000){
        u_price=5;
    }else if(units>1000){
        u_price=14;
    }else{
        cout<<"Invalid Input"<<endl;
    }
    bill_amount=units*u_price;
}
void bill::displayDetails(){
    cout<<"Customer Name:"<<name<<endl;
    cout<<"Bill Number:"<<bill_no<<endl;
    cout<<"Address:"<<address<<endl;
    cout<<"Consumed Units"<<units<<endl;
    cout<<"Bill Amount:"<<bill_amount<<endl;
}