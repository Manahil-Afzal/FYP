/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class utilitybill {
    private:
    string customername;
    int billnum;
    int units_consumed;
    string address;
    public:
    void getdata();
    int calculatedata();
    void putdata();
};
void utilitybill :: getdata()
{
    cout<< "Enter bill number :";
    cout<<" Enter customer name :";
    cin >> customername;
    cin>> billnum;
    cout<< "Enter units consumed :";
    cin>> units_consumed;
    cout<<"Enter address";
    cin>>address;
}
int utilitybill :: calculatedata(){
     if ( units_consumed < 300){
         units_consumed *= 8;
         return units_consumed;
     }else if ( units_consumed >=300 && units_consumed > 100){
         units_consumed *=5;
         return units_consumed;
     }else if (units_consumed > 999){
         units_consumed *=14;
         return units_consumed;
     }else
     {
         cout<< "invalid";
     }
}
void utilitybill :: putdata()
{
    cout<<"Enter name of customer :"<<customername<<endl;
    cout<< "Enter bill number :"<<billnum<<endl;
    cout<< "Enter units consumed :"<<units_consumed<<endl;
    cout<<"enter address :"<<address<<endl;
}
main
(){
    utilitybill c1;
    c1.getdata();
    c1.calculatedata();
    c1.putdata();
}