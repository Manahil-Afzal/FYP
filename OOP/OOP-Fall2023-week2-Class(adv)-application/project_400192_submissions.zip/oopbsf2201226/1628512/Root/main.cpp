/*Write a program that creates a class to display Utility_Bill.
The class should take customer name, bill number, units consumed,
and customer address as inputs and displays the input values and the bill amount which 
is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5.
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
#include<iomanip>
using namespace std;
class utility_bill{
    private:
    string customer_name;
    long bill_number;
    int unit_consumed;
    string customer_address;
    int  price_per_unit;
    int bill;
    public:
    ~utility_bill()
    {
        cout<<"DEAR CUSTOMER PAY YOUR  BILL IN DUE DATE OTHERWISE YOUR CONNECTION CUT OFF WITH IN 5 DAYS"<<endl;
    }
    void getdetail()
    {
        cout<<"*USERINPUT*"<<endl;
        cout<<"ENTER CUSTOMER NAME:"<<endl;
        cin.ignore();
        getline(cin,customer_name);
        cout<<"ENTER BILL NUMBER:"<<endl;
        cin>>bill_number;
        cout<<"ENTER UNIT CONSUMED:"<<endl;
        cin>>unit_consumed;
        cout<<"ENTER ADDRESS"<<endl;
        cin.ignore();
        getline(cin,customer_address);
    }
    void calculation()
    {
        if(unit_consumed<300){
            price_per_unit=5;
            bill=unit_consumed* price_per_unit;
        }else 
        if(unit_consumed <=999 ){
             price_per_unit=8;
            bill=unit_consumed* price_per_unit;
            
        }else if(unit_consumed>=1000){
             price_per_unit=14;
            bill=unit_consumed*price_per_unit;
        }
    }
    void showbill()
    {
        cout<<"**************************************"<<endl;
        cout<<"             UTILITY BILL             "<<endl;
        cout<<"**************************************"<<endl;
        cout<<"NAME:"<<setw(15)<<left<<customer_name<<endl;
        cout<<"BILL NUMBER:"<<setw(15)<<left<<bill_number<<endl;
        cout<<"UNIT CONSUMED:"<<unit_consumed<<endl;
        cout<<"CUSTOMER ADDRESS:"<<setw(50)<<left<<customer_address<<endl;
        cout<<"PER UNIT PRICE:"<< price_per_unit<<endl;
        cout<<"YOUR BILL:"<<bill<<endl;
    }
};
int main()
{
    utility_bill u_bill;
    u_bill.getdetail();
    u_bill.calculation();
    u_bill.showbill();
    return 0;
}