/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
 using namespace std;
 
class utility_bill{
	private:
		string customer_name;
		double bill_number;
		int unit_consumed;
		string customer_adress;
		float bill_amount;
	public:
		void enterdetails();
		void showdetails();
};
void utility_bill:: enterdetails(){
	cout << "enter the customer name"<<endl;
	cin >> customer_name;
	cout << "enter the bill number"<<endl;
	cin>> bill_number;
	cout << "enter the units consumed"<<endl;
	cin >> unit_consumed;
	cout << "enter the adress of the customer"<<endl;
	cin >> customer_adress;
	if (unit_consumed < 300){
		bill_amount = unit_consumed * 8;
	}
	else if(unit_consumed >= 300 && unit_consumed <1000){
		bill_amount = unit_consumed * 5;
	}
	else if (unit_consumed >999){
		bill_amount = unit_consumed * 14;
	}
	else {
		cout <<"inappropriate value"<<endl;
	}
}
void utility_bill :: showdetails(){
	cout << "the customer name is"<< " "<<customer_name<<endl;
	cout << "the bill number is"<< " "<<bill_number<<endl;
	cout << "the units which are consumed are"<< " "<< unit_consumed<<endl;
	cout << "the customer adress is"<< " "<<customer_adress <<endl;
	cout << "the amount of the bill is"<< " "<< bill_amount << endl;
}
int main(){
	utility_bill ub;
	ub.enterdetails();
	ub.showdetails();
}