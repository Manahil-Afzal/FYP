/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utilitybill{
	public:
	string customer_name;
	long bill_number;
	int unit_consumed;
	string customer_address;
	long bill_amount;
	int per_unit_price;
	void input(){
		cout<<"customer name\n";
		cin>>customer_name;
		cout<<"bill number\n";
		cin>>bill_number;
		cout<<"unit consumed\n";
		cin>>unit_consumed;
	    cout<<"per unit price\n";
		cin>>per_unit_price;
		cout<<"customer address\n";
		cin>>customer_address;
	
		
		bill_amount=unit_consumed*per_unit_price;
	}
	void display(){
		cout<<"customer_name:"<<customer_name<<endl<<"bill_number:"<<bill_number<<endl<<"customer_address"<<customer_address<<endl<<"unit_consumed:"<<unit_consumed<<
		endl<<"per_unit_price:"<<per_unit_price<<endl<<"bill_amount:"<<bill_amount<<endl;
	}
};
int main(){
	utilitybill u;
	u.input();
	u.display();
}