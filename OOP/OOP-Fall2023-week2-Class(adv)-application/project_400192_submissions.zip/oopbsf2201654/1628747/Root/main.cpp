/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, 
and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units 
consumed with per unit price.

If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;
class Utility_Bill{
    private:
    string customer_name;
    int bill_num;
    int units_consumed;
    string customer_address;
    int bill_amount;
    public:
    void getdata();     
    void showdata();     
};
void Utility_Bill::getdata(){
    cout<<"Enter Data: \n"<<"Customer Name: ";
    cin>>customer_name;
    cout<<"\n Bill Number: ";
    cin>>bill_num;
    cout<<"\n Units Consumed: ";
    cin>>units_consumed;
    cout<<"\n Customer Address: ";
    cin>>customer_address;
    
    if(units_consumed<300)
    bill_amount = units_consumed*8;
    else if(units_consumed>=300 && units_consumed<1000)
    bill_amount = units_consumed*5;
    else if(units_consumed<999)
    bill_amount = units_consumed*14;
    else
    cout<<"Invalid units entered.";
};

void Utility_Bill::showdata(){
    cout<<"\n\nBill Details: \n"<<"Customer Namer: "<<customer_name;
    cout<<"\n Bill Number: "<<bill_num<<"\n Units Consumed: "<<units_consumed;
    cout<<"\n Customer Address: "<<customer_address<<"\n Bill Amount: "<<bill_amount;
};

int main(){
    Utility_Bill bill1;
    bill1.getdata();
    bill1.showdata();
    return 0;
}