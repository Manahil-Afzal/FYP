/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class Utility_bill{
  private:
  string customer_name;
  int bill_number;
  int unit_consumed;
  string address;
  public:
  void inputData();
  int calculateData();
  void outputData();
  
};
void Utility_bill:: inputData(){
    cout<<"Customer name ";
    cin>>customer_name;
    cout<<"Customer bill number";
    cin>> bill_number;
    cout<<"unit consumed by customer";
    cin>> unit_consumed;
    cout<<"address of customer";
    cin>>address;
}
int  Utility_bill::calculateData(){
    if(unit_consumed<300){
        return unit_consumed*=8;
    }else if(unit_consumed>=300 && unit_consumed<=999){
        return unit_consumed*=5;
    }else if(unit_consumed>999){
        return unit_consumed*=14;
    }else
    return 0;
}
void Utility_bill ::outputData(){
   
    cout<<"Cutomer name"<<customer_name<<endl;
    cout<<"Cutomer  bill number"<<bill_number<<endl;
    cout<<"Cutomer  consumed unit"<<calculateData()<<endl;
    cout<<"Cutomer adress"<<address;
}
main(){
    Utility_bill b1;
    b1.inputData();
  //  b1.calculateData();
    b1.outputData();
}