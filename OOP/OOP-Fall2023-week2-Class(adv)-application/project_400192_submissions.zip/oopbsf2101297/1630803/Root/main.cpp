/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
	string c_name;
	int b_number;
	int c_units;
	string address;
	int b_amount;
	public:
		void input();
		void output();
	};
		void bill::input(){
			cout<<"enter name="<<endl;
			cin>>c_name;
			cout<<"enter number="<<endl;
			cin>>b_number;
			cout<<"enter address="<<endl;
			cin>>address;
			cout<<"enter consumed units="<<endl;
			cin>>c_units;
			if(c_units<300)
			b_amount=c_units*8;
			else if(c_units>=300&&c_units<1000)
			b_amount=c_units*5;
			else if (c_units>999)
			b_amount=c_units*14;
			
			
		}
		void bill::output(){
			cout<<"costumer name="<<c_name<<endl;
			cout<<"bill number="<<b_number<<endl;
			cout<<"consumed units="<<c_units<<endl;
	        cout<<"bill amount="<<b_amount<<endl;
			cout<<"address="<<address<<endl;
		}
		
	
int main(){
	bill a;
	a.input();
	a.output();
	return 0;
	
	
}