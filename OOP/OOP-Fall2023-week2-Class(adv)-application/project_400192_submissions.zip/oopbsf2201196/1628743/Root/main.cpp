/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed,
and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units
consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class utility_bill{
    private:
        string customer_name;
        double bill_number;
        double units_consumed;
        string customer_address;
        double per_unit_price;
        double billAmount;
        
    public:
        utility_bill(string name, double bill_no, double units, string address)
	{
	    customer_name = name;
        bill_number = bill_no;
        units_consumed = units;
        customer_address = address;
    
	    
        if(units_consumed < 300) {
            per_unit_price = 8;
        }
        else if(units_consumed >= 300 && units_consumed < 1000) {
            per_unit_price = 5;
        }
        else {
            per_unit_price = 14;
        }
        billAmount=units_consumed*per_unit_price;
    }
    void display_bill() {
        double bill_amount = units_consumed * per_unit_price;
        cout << "Customer Name: " << customer_name << endl;
        cout << "Bill Number: " << bill_number << endl;
        cout << "Units Consumed: " << units_consumed << endl;
        cout << "Customer Address: " << customer_address << endl;
        cout << "Per unit pice: Rs " << per_unit_price << endl;
        cout << "Bill Amount: Rs " << billAmount << endl;
    }
};

int main(){
     string customer_name, customer_address;
     double units_consumed, bill_number;

    cout << "Enter Customer Name: ";
    cin >> customer_name;
    cout << "Enter Bill Number: ";
    cin >> bill_number;
    cout << "Enter Units Consumed: ";
    cin >> units_consumed;
    cout << "Enter Customer Address: ";
    cin>>customer_address;
    
    utility_bill bill(customer_name, bill_number, units_consumed, customer_address);
    bill.display_bill();
}