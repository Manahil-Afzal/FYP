/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utilitybills{
    private:
    string customername;
    string customeraddress;
    int billnumber;
    int unitconsumed;
    public:
    void getdetails();
    void calculations();
    void putdetails();
};
void Utilitybills::getdetails()
{
    cout<<" enter the customer name";
cin>>customername;
cout<<"enter the customer address";
cin>>customeraddress;
cout<<"enter the bill number";
cin>>billnumber;
cout<<"enter the unit consumed";
cin>>unitconsumed;
}
void Utilitybills::calculations(){
    if ( unitconsumed<=300){
        unitconsumed*=5;
       } else if(unitconsumed>=300&&unitconsumed<=990){
           unitconsumed*=5;
       }
           else if ( unitconsumed>990){
               unitconsumed*=14;
           }
               else{
                   cout<<"invalid";
               }
               
}
void Utilitybills::putdetails(){
    cout<<"enter the customer name"<<customername;
    cout<<"enter the customer address"<<customeraddress;
    cout<<"enter the bill number"<<billnumber;
    cout<<"enter the unit consumed"<<unitconsumed;
}
main(){
Utilitybills myobject;
myobject.getdetails();
myobject.calculations();
myobject.putdetails();
}