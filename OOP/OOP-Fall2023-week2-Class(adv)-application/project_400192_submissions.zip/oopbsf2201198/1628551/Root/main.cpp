/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Bill
{
private:
string name;
int num;
int units;
string address;
int bill=0;
public:
void input();
void calculation();
void display();
	
};
void Bill::input()
{
	cout<<"Enter the name";
	cin>>name;
	cout<<"Enter the bill number";
	cin>>num;
	cout<<"Enter the units consumed";
	cin>>units;
	cout<<"Enter the customer address";
	cin>>address;
}
void Bill::calculation()
{
	if(units<300)
	{
		bill=units*8;
	}else if(units>300&&units<1000)
	{
		bill=units*5;
	}else
	bill=units*14;
	
}
void Bill::display()
{
	cout<<"Customer name="<<name<<endl;
	cout<<"Bill number="<<num<<endl;
	cout<<"Units consumed="<<units<<endl;
	cout<<"Customer addresss="<<address<<endl;
	cout<<"Total bill of customer="<<bill<<endl;
	
}
int main()
{
	Bill user1;
	user1.input();
	user1.calculation();
	user1.display();
	return 0;
}