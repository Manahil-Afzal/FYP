#include<iostream>
using namespace std;
class utility_bill{
    private:
           string customer_name;
           int consume_units;
           double bill_no;
           float bill_amount;
           string customer_adress;
    public:
           void getDetails();
           void showDetails();

};
void utility_bill::getDetails(){
    cout<<"enter the customer name : "<<endl;
    cin>>customer_name;
    cout<<"enter the consume units : "<<endl;
    cin>>consume_units;
    cout<<"enter the bill no. :"<<endl;
    cin>>bill_no;
    //cout<<"enter the bill amount : "<<endl;
    //cin>>bill_amount;
    cout<<"enter the customer adress :"<<endl;
    cin>>customer_adress;

    if(consume_units<300){
    bill_amount=consume_units*8;}

    else if(consume_units>=300){
    bill_amount=consume_units*5;}

    else if(consume_units>999){
    bill_amount=consume_units*14;}

    else{
        cout<<"Inapropriate value"<<endl;
    }

}
void utility_bill::showDetails(){
    cout<<"Customer name is : "<<customer_name<<endl;
    cout<<"Bill amount is : "<<bill_amount<<endl;
    cout<<"Consume units are : "<<consume_units<<endl;
    cout<<"Bill no. is : "<<bill_no<<endl;
    cout<<"Customr adress is : "<<customer_adress<<endl;
}
int main(){
utility_bill ub;
ub.getDetails();
ub.showDetails();
}
