/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill
{
	private:
		string customer_name;
		int bill_number;
		int units_consumed;
		string customer_address;
		int bill_amount;
		int per_unit_price;
	
	public:
	    void input();
		void calculate();
		void display();	
};

void utility_bill::input()
{
	cout << "Enter the name of customer:"<<endl;
	cin  >>  customer_name;
	cout << "Enter the bill number:"<<endl;
	cin  >>  bill_number;
	cout << "Enter the units that consumed:"<<endl;
	cin  >>  units_consumed;
	
	if(units_consumed < 300)
		per_unit_price = 8;
	
	else if((units_consumed >= 300) && (units_consumed < 1000))
		per_unit_price = 5;
	
	else if(units_consumed > 999)
		per_unit_price = 14;
		
	cout << "Enter the address of the customer:"<<endl;
	cin  >>  customer_address;
	
}

void utility_bill::calculate(){
	
	bill_amount = units_consumed*per_unit_price;
}

void utility_bill::display(){
	
	cout<<"Name of customer:"<<customer_name<<endl;
	cout<<"Bill number:"<<bill_number<<endl;
	cout<<"units that consumed:"<<units_consumed<<endl;
	cout<<"Address of the customer:"<<customer_address<<endl;
	cout<<"Amount of bill:"<<bill_amount<<endl;
}
int main()

{
	utility_bill bill;
	bill.input();
	bill.calculate();
	bill.display();
	
return 0;

}