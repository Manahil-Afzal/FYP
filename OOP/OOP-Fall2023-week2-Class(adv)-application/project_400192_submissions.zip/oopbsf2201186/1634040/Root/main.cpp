#include <iostream>
using namespace std;

class UtilityBill
{
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    UtilityBill(string name, int billNo, int units, string address)
    {
        customerName = name;
        billNumber = billNo;
        unitsConsumed = units;
        customerAddress = address;
    }

    float calculateBillAmount()
    {
        float perUnitPrice;

        if (unitsConsumed < 300)
        {
            perUnitPrice = 8.0;
        }
        else if (unitsConsumed < 1000)
        {
            perUnitPrice = 5.0;
        }
        else
        {
            perUnitPrice = 14.0;
        }

        return unitsConsumed * perUnitPrice;
    }

    void displayBill()
    {
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << calculateBillAmount() << endl;
    }
};

int main()
{
    string name, address;
    int billNo, units;

    cout << "Enter Customer Name: ";
    getline(cin, name);

    cout << "Enter Bill Number: ";
    cin >> billNo;

    cout << "Enter Units Consumed: ";
    cin >> units;

    cin.ignore(); // Clear newline character from the input buffer

    cout << "Enter Customer Address: ";
    getline(cin, address);

    UtilityBill bill(name, billNo, units, address);
    bill.displayBill();

    return 0;
}
