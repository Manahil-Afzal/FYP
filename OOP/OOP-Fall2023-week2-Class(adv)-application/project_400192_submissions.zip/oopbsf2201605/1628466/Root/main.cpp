/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include <iostream>
#include <string>

using namespace std;

class UtilityBill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    float perUnitPrice;

public:
    UtilityBill() {
        perUnitPrice = 0; // Initialize per unit price to 0
    }

    void inputBillDetails() {
        cout << "Enter Customer Name: ";
        cin.ignore(); // Clear the input buffer
        getline(cin, customerName);

        cout << "Enter Bill Number: ";
        cin >> billNumber;

        cout << "Enter Units Consumed: ";
        cin >> unitsConsumed;

        cout << "Enter Customer Address: ";
        cin.ignore(); // Clear the input buffer
        getline(cin, customerAddress);
    }

    void calculateBillAmount() {
        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed >= 300 && unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else if (unitsConsumed >= 1000) {
            perUnitPrice = 14.0;
        }
    }

    void displayBill() {
        cout << "\nBill Details:\n";
        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Per Unit Price: Rs. " << perUnitPrice << endl;

        float billAmount = unitsConsumed * perUnitPrice;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    UtilityBill bill;
    
    bill.inputBillDetails();
    bill.calculateBillAmount();
    bill.displayBill();
    
    return 0;
}