/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, 
and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with 
per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class Utility_Bill{
    private:
        string customer_name;
        long bill_number;
        int units_consumed;
        string customer_address;
        float bill_amount;
        float per_unit_price;
    public:
        void take_input(){
            cout<<"Enter customer name: ";
            cin>>customer_name;
            cout<<endl<<"Enter the bill number: ";
            cin>>bill_number;
            cout<<endl<<"How much units have consumed?"<<endl;
            cin>>units_consumed;
            cout<<"Enter the customer address: ";
            cin>>customer_address;
            
            if(units_consumed < 300){
                per_unit_price = 8;
            } else if(units_consumed >= 300 && units_consumed < 1000){
                per_unit_price = 5;
            } else {
                per_unit_price = 14;
            }
        bill_amount = units_consumed * per_unit_price;
        }
        
        void display_input(){
            cout<<"Customer name: "<<customer_name<<endl<<"Bill number: "<<bill_number<<endl<<"Units consumed: "<<units_consumed<<endl<<"Customer address: "<<customer_address<<endl<<"Per unit price: "<<per_unit_price<<endl<<"Bill Amount: "<<bill_amount<<endl;
        }
};

int main(){
    Utility_Bill b1;
    b1.take_input();
    b1.display_input();
    return 0;
}
