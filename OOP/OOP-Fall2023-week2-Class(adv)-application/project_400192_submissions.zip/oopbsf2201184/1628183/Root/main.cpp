/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class Utility_Bill
{
    private:
    string customer_name;
    int bill_number;
    int units_consumed;
    string  customer_address;
    public:
    void putdetails();
    int calculation();
    void getdetails();
};

void Utility_Bill :: putdetails()

{
    cout<<" Enter customer name :";
    cin >> customer_name;
     cout<< "Enter bill number :";
    cin>> bill_number;
    cout<< "Enter units consumed :";
    cin>> units_consumed;
    cout<<"Enter costumer address :";
    cin>>customer_address;
}

int Utility_Bill:: calculation()

{
     if ( units_consumed < 300)
     {
         units_consumed *= 8;
         return units_consumed;
     }
     
     else if ( units_consumed >=300 && units_consumed > 1000)
     
     {
         units_consumed *=5;
         return units_consumed;
     }
     
     else if (units_consumed > 999)
     {
         units_consumed *=14;
         return units_consumed;
     }
     
     else
     
     {
         cout<< "invalid";
     }
}
void Utility_Bill :: getdetails()
{
    cout<<"Enter name of customer :"<<customer_name<<endl;
    cout<< "Enter bill number :"<<bill_number<<endl;
    cout<< "Enter units consumed :"<<units_consumed<<endl;
    cout<<"Enter customer address :"<<customer_address<<endl;
}
main()
{
   Utility_Bill u1;
    u1.putdetails();
    u1.calculation();
    u1.getdetails();
}