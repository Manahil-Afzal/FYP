/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number,
units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated 
after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
private:
    int uni_price;
	string cus_nm;
    int bil_nm;
    int uni_con;
    string cus_add;
    int billamount;
    public:
   void getdetails();
   void calculation();
    void putdetails();
    
};
int main(){
    bill bill1;
    bill1.getdetails();
    bill1.calculation();
    bill1.putdetails();
    
}
void bill::getdetails(){
   
	cout<<"please enter the customer name \n";
    cin>>cus_nm;
    cout<<"plz enter  the bill number \n";
    cin>>bil_nm;
     cout<<"please enter the units consumed \n";
    cin>>uni_con;
    cout<<"plz enter  customer address \n";
    cin>>cus_add;
//cout<<"the bill of the customer is\n";
//cin>>billamount;    
    
    
}

void bill :: calculation(){
if(uni_con<300){
billamount=uni_con*8;
cout<<"bill amount :"<<billamount;
}
else if(uni_con>300 && uni_con<1000){
billamount=uni_con*14;
cout<<"bill amount ="<<billamount;
}
 else if(uni_con>1000){
	billamount=uni_price*5;
	cout<<"billamount= "<<billamount;
}
 else if (uni_con>999){
	billamount=uni_price*14;
	cout<<"billamount= "<<billamount;
}
else(uni_con=0);{
	cout<<"consumer does not use electricity";
}
}

void bill::putdetails(){

    cout<<"The name of customer is "<<cus_nm<<endl<<"The bill number is  "<<bil_nm<<endl;
	cout<<"The units consumed by the customer  are  "<<uni_con<<endl;
	cout<<"The address of customer is "<<cus_add<<endl;
    cout<<"bill amount :"<<billamount;

}
//void bill :: calculation(){
/*if(uni_con<300){
billamount=uni_con*8;
cout<<"bill amount :"<<billamount;
}
else if(uni_con>300 && uni_con<1000){
billamount=uni_con*14;
cout<<"bill amount ="<<billamount;
}
 else if(uni_con>1000){
	billamount=uni_price*5;
	cout<<"billamount= "<<billamount;
}
 else if (uni_con>999){
	billamount=uni_price*14;
	cout<<"billamount= "<<billamount;
}
else if (uni_con==0);{
	cout<<"consumer does not use electricity";
}*/


