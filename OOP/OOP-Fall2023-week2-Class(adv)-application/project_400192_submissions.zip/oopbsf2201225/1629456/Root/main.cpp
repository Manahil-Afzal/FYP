/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed,
 and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill
{
	private:
		string name;
		int billno;
		int units;
		string address;
		int bill;
		public:
			void getDetails();
			void calculate_bill();
			void showDetails();
			
		
};
void Utility_Bill :: getDetails()
{
	cout<<"Enter the customer name: "<<endl;
	cin>>name;
	cout<<"Enter bill number: "<<endl;
	cin>>billno;
	cout<<"Enter the consumed units: "<<endl;
	cin>>units;
	cout<<"Enter the customer address: "<<endl;
	cin>>address;
}
void Utility_Bill :: calculate_bill()
{
	if(units<300)
	{
		bill = units*8;
	}
	else if(units>=300 && units==999)
	{
	bill = units*5;
}
	else
	bill = units*14;
}
void Utility_Bill :: showDetails()
{
	cout<<"the customer name is: "<<name<<endl;
	cout<<"the bill number is: "<<billno<<endl;
	cout<<"the consumed units is: "<<units<<endl;
	cout<<"the customer address is: "<<address<<endl;
	cout<<"the customer bill is: "<<"RS:"<<bill<<endl;
}
int main()
{
	Utility_Bill b1;
	b1.getDetails();
	b1.calculate_bill();
	b1.showDetails();
}