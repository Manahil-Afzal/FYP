/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and 
displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5.
 If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class utility_bil{
	private:
		string name;
		string Address;
		int consum_unit;
		int bill_No;
		int bil_amount;
		public:
			void getdata();
			void putdata();
};
void utility_bil::getdata(){
	cout<<"enter your name ";
	cin>>name;
	
	cout<<"enter your bill number  ";
	cin>>bill_No;
	
	cout<<"enter your consumed units ";
	cin>>consum_unit;
	
	cout<<"enter your Address ";
	cin>>Address;
}

void utility_bil::putdata(){
	cout<<endl<<"couster name :"<<name<<endl<<"bill number is :"<<bill_No<<endl<<"consumed units:"<<consum_unit<<endl<<"Address of coustomer :"<<Address<<endl;
	if(consum_unit<300)
	{
		bil_amount =consum_unit*8;
		cout<<"bill amount is :"<<bil_amount<<endl;
	}
	else if(consum_unit>=300 && consum_unit<1000) 
	{
		bil_amount =consum_unit*5;
		cout<<"bill amount is :"<<bil_amount<<endl;	
	}else
	{
			bil_amount =consum_unit*14;
		cout<<"bill amount is :"<<bil_amount<<endl;	
	}
}

main(){
	utility_bil costomer1;
	costomer1.getdata();
	costomer1.putdata();
}