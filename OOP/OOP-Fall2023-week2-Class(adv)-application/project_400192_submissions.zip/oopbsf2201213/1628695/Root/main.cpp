/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
    string name;
    int number;
    int units;
    string address;
    float bill;
    public:
    void input();
    void display();
    void calcul();
};
int main (){
    bill user1;
    user1.input();
    user1.calcul();
    user1.display();
}
void bill::input(){
    cout<<"enter your name "<<endl;
    cin>>name;
    cout<<"enter your bill number "<<endl;
    cin>>number;
    cout<<"your consume unit "<<endl;
    cin>>units;
    cout<<"enter your address "<<endl;
    cin>>address;
}
void bill::display(){
    cout<<"your name is "<<name<<endl;
    cout<<"customer bill number is "<<number<<endl;
    cout<<"consume units is "<<units<<endl;
    cout<<"your address is "<<address <<endl;
    cout<<"customer bill is "<<bill<<endl;
}
void bill::calcul(){
    if(units<300){
        bill=units*8;
    }
    else if (units>=300 && units<1000){
        bill=units*5;
    }
    else{
        bill=units*14;
    }
}