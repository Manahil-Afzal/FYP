/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class UtilityBills {
    private:
    string coustomerName;
    string address;
    int billNumber,unitsConsumed;
    double totalBill;
    public:
    
void  getDetails()
{
    cout<< "enter the name of coustomer";
    cin>>coustomerName;
      cout<< "enter the address of coustomer";
    cin>>address;
      cout<< "enter the bill number";
    cin>>billNumber;
      cout<< "enter the units consumed";
    cin>> unitsConsumed ;
   
    if(unitsConsumed<300)
       totalBill=unitsConsumed*8;
    else if(unitsConsumed>=300 && unitsConsumed<999)
      totalBill=unitsConsumed*5;
        else if(unitsConsumed>999)
            totalBill = unitsConsumed*14;
    
}
          void displayDetails()
          {
              cout<<"coustomer name"<<coustomerName<<endl;
                 cout<< "address"<<address<<endl;
                    cout<<"bill Number"<<billNumber<<endl;
                       cout<<"units consumed"<<unitsConsumed<<endl;
                       cout<<"total bill is"<<totalBill<<endl;
          }
};
          int main()
          {
              UtilityBills std;
              std.getDetails();
              std.displayDetails();
              return 0;
          }