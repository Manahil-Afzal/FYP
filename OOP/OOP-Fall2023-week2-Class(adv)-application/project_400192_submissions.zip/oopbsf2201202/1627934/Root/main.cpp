#include <iostream>
#include <string>

using namespace std;

class Utility_Bill {
private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;

public:
    Utility_Bill(string name, int billNum, int units, string address) {
        customerName = name;
        billNumber = billNum;
        unitsConsumed = units;
        customerAddress = address;
    }

    void calculateBillAmount() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 18.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        cout << "Customer Name: " << customerName << endl;
        cout << "Bill Number: " << billNumber << endl;
        cout << "Units Consumed: " << unitsConsumed << endl;
        cout << "Customer Address: " << customerAddress << endl;
        cout << "Bill Amount: Rs. " << billAmount << endl;
    }
};

int main() {
    string name, address;
    int billNum, units;

    cout << "Enter Customer Name: ";
    getline(cin, name);

    cout << "Enter Bill Number: ";
    cin >> billNum;

    cout << "Enter Units Consumed: ";
    cin >> units;

    cin.ignore(); 
    cout << "Enter Customer Address: ";
    getline(cin, address);

    Utility_Bill bill(name, billNum, units, address);
    bill.calculateBillAmount();

    return 0;
}