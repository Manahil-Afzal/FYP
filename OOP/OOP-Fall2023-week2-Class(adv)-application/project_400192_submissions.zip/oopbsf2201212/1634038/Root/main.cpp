/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
# include<iostream>
using namespace std;
class Utility_Bill{
    private:
    string name;
    int bii_number;
    int unit_consumed;
    string adress;
    public:
    void getDetails();
    void putDetails();
};
int main(){
Utility_Bill mybill;
mybill.getDetails();
mybill.putDetails();
return 0;
}
// for taking input
void Utility_Bill::getDetails(){
    cout<<"Enter your name :";
    cin>>name;
    cout<<"Enter your unit consumed :";
    cin>>unit_consumed;
    cout<<"Enter your adress :";
    cin>>adress;
    if (unit_consumed<300){
        unit_consumed=unit_consumed*8;
    }
        else if(unit_consumed>=300||unit_consumed<1000){
            unit_consumed=unit_consumed*5;
        }
    else if (unit_consumed>999){
        unit_consumed=unit_consumed*14;
    }
}
//Displaying the values
void Utility_Bill::putDetails(){
    cout<<"coustmer Name :"<<name<<"\n";
    cout<<"Unit consumed :"<<unit_consumed<<"\n";
    cout<<"customers adress :"<<adress<<"\n";
}