/*Write a program that creates a class to display Utility_Bill. The class should take customer name,
bill number, units consumed, and customer address as inputs and displays the input values and 
the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, 
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
#include<string>
using namespace std;
class Utility_Bill{
    private:
    string customer_name;
    double bill_number;
    double units_consumed;
    string customer_address;
    float per_unit_price;
    
    public:
    Utility_Bill(string name,double number,double units,string address)
    {
        customer_name=name;
        bill_number=number;
        units_consumed=units;
        customer_address=address;
        if(units_consumed<300)
        {
            per_unit_price=8;
        }
        else if(units_consumed<1000){
        per_unit_price=5;
    }
    else
    {
        per_unit_price=14;
    }
}
void displayBill(){
    cout<<"customer name:"<<customer_name<<endl;
    cout<<"bill number:"<<bill_number<<endl;
    cout<<"units consumed:"<<units_consumed<<endl;
    cout<<"customer address:"<<customer_address<<endl;
    cout<<"per unit price:"<<per_unit_price<<endl;
    float billamount=units_consumed*per_unit_price;
    cout<<"Total bill amount:Rs"<<billamount<<endl;
}
};

int main()
{
    string name,address;
    double units,number;
    cout<<"Enter customer name:";
    getline(cin,name);
    cout<<"Enter bill_number:"<<endl;
    cin>>number;
    cout<<"Enter units_consumed:"<<endl;
    cin>>units;
    cin.ignore();
    cout<<"Enter customer_address:";
    getline(cin,address);
    Utility_Bill bill(name,number,units,address);
    bill.displayBill();
    return 0;
}
