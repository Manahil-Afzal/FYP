/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class Utility_Bill{
  string name, billNo, address;
  float units, bill;
  public:
    void input();
    void calculation();
    void display();
};

int main(){
    Utility_Bill user1;
    user1.input();
    user1.calculation();
    user1.display();
}

void Utility_Bill :: input(){
    cout<<"Enter your name: "<<endl;
    cin>>name;
    cout<<"Enter your billNo."<<endl;
    cin>>billNo;
    cout<<"Enter your address"<<endl;
    cin>>address;
    cout<<"Enter the units consumed"<<endl;
    cin>>units;
}

void Utility_Bill :: calculation(){
    if(units<300){
        bill = units * 8;
    }else if(units>=300 && units<1000){
        bill = units * 5;
    }else{
        bill = units * 14;
    }
}

void Utility_Bill :: display(){
    cout<<endl;
    cout<<"Your name is "<<name<<endl;
    cout<<"Your bill no. is "<<billNo<<endl;
    cout<<"Your address is "<<address<<endl;
    cout<<"Your bill for "<<units<<" units is PKR "<<bill<<endl;
}