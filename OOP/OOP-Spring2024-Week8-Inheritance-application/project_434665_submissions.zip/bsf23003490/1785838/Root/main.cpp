/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int working_hours;
    double per_hour_salary;

public:
    Employee(string n, int i, int wh, double phs)
        : name(n), id(i), working_hours(wh), per_hour_salary(phs) {}

    virtual double salary() {
        return working_hours * per_hour_salary;
    }

    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << working_hours << endl;
        cout << "Per Hour Salary: $" << per_hour_salary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string n, int i, int wh, double phs)
        : Employee(n, i, wh, phs) {}

    double salary() override {
        return Employee::salary(); // Calculating salary using base class method
    }

    void display_info() override {
        Employee::display_info(); // Displaying information using base class method
        cout << "Total Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 12345, 40, 25.5);
    emp.display_info();
    return 0;
}
