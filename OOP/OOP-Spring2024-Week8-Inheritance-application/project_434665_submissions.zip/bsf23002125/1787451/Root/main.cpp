/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
using namespace std;

// Base class
class Employee {
protected:
    string Name;
    int Id;
    int numWorkingHours;
    double perHourSalary;

public:
    // Constructor
    Employee(string name, int id, int totalHours, double hourlySalary)
        : Name(name), Id(id), numWorkingHours(totalHours), perHourSalary(hourlySalary) {}

    // Getter and setter methods
    void setName(string name) { Name = name; }
    string getName() const { return Name; }
    void setId(int id) { Id = id; }
    int getId() const { return Id; }
    void setNumWorkingHours(int totalHours) { numWorkingHours = totalHours; }
    int getNumWorkingHours() const { return numWorkingHours; }
    void setPerHourSalary(double hourlySalary) { perHourSalary = hourlySalary; }
    double getPerHourSalary() const { return perHourSalary; }
};

// Derived class
class Adhoc_employee : public Employee {
public:
    // Constructor
    Adhoc_employee(string name, int id, int totalHours, double hourlySalary)
        : Employee(name, id, totalHours, hourlySalary) {}

    // Method to calculate salary
    double salary() {
        return numWorkingHours * perHourSalary;
    }

    // Method to display information
    void display_info() {
        cout << "Adhoc Employee Information:" << endl;
        cout << "Name: " << getName() << endl;
        cout << "ID: " << getId() << endl;
        cout << "Number of working hours: " << getNumWorkingHours() << endl;
        cout << "Per hour salary: " << getPerHourSalary() << endl;
    }
};

int main() {
    // Creating an object of Adhoc_employee
    Adhoc_employee emp("Abdul Rehman", 7, 30, 50.0);

    // Displaying information, salary, and additional details
    emp.display_info();
    cout << "Salary: " << emp.salary() << endl;
    
    return 0;
}
