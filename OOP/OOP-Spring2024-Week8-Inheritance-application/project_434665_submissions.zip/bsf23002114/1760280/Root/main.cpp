/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    // Constructor
    Employee(string empName, int empId, int hours, double salaryPerHour) : name(empName), id(empId), numWorkingHours(hours), perHourSalary(salaryPerHour) {}

    // Virtual destructor
    virtual ~Employee() {}

    // Virtual function to calculate salary
    virtual double salary() {
        return numWorkingHours * perHourSalary;
    }

    // Virtual function to display employee info
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << numWorkingHours << endl;
        cout << "Per hour salary: " << perHourSalary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    // Constructor
    Adhoc_employee(string empName, int empId, int hours, double salaryPerHour) : Employee(empName, empId, hours, salaryPerHour) {}

    // Overridden function to calculate salary
    double salary() override {
        return numWorkingHours * perHourSalary;
    }

    // Overridden function to display employee info
    void display_info() override {
        cout << "Employee Type: Adhoc" << endl;
        Employee::display_info();
    }
};

int main() {
    string name;
    int id, hours;
    double perHourSalary;

    // Input employee details
    cout << "Enter employee name: ";
    getline(cin, name);
    cout << "Enter employee ID: ";
    cin >> id;
    cout << "Enter number of working hours: ";
    cin >> hours;
    cout << "Enter per hour salary: ";
    cin >> perHourSalary;

    // Create Adhoc_employee object
    Adhoc_employee employee(name, id, hours, perHourSalary);

    // Display employee information
    employee.display_info();

    return 0;
}
