#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    Employee(const string &name, int id, int numWorkingHours, double perHourSalary)
        : name(name), id(id), numWorkingHours(numWorkingHours), perHourSalary(perHourSalary) {}

    virtual double salary() {
        return numWorkingHours * perHourSalary;
    }

    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << numWorkingHours << endl;
        cout << "Per hour salary: " << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string &name, int id, int numWorkingHours, double perHourSalary)
        : Employee(name, id, numWorkingHours, perHourSalary) {}

    double salary() override {
        return numWorkingHours * perHourSalary;
    }

    void display_info() override {
        Employee::display_info();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("Ali", 12345, 40, 20.5);
    emp.display_info();

    return 0;
}
