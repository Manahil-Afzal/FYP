/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee
{
    public:
    string name,id;
    int hours,salary;
    void get_data()
    {
        cout<<"enter your name:"<<endl;
        cin>>name;
        cout<<"enter yout id"<<endl;
        cin>>id;
        cout<<"enter your per day salary:"<<endl;
        cin>>salary;
        cout<<"enter your working hours:"<<endl;
        cin>>hours;
    }
};
class Adhoc : public Employee
{ 
    public:
    int set_salary()
    {
        int sal;
        sal=salary*hours;
        return sal;
    }
    void show_data()
    {
        cout<<name<<endl<<id<<endl<<"your salary is:"<<set_salary()<<endl;
        
    }
};
main()
{
    Adhoc a;
    a.get_data();
    a.set_salary();
    a.show_data();
    
}