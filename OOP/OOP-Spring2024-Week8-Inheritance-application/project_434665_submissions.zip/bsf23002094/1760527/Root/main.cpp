/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected :
		string emp_name;
		string  emp_id;
		int no_of_whr;
		int per_hr_salary;
	public :
		void set_emp_details(){
			cout<<"Enter the name of Employee :"<<endl;
			getline(cin , emp_name);
			cout<<"Enter the id of Employee :"<<endl;
			getline(cin , emp_id);
			cout<<"Enter the no working hours of Employee :"<<endl;
			cin>>no_of_whr;
			cout<<"Enter the per hour salary of Employee :"<<endl;
			cin>>per_hr_salary;
			
		}
		void get_emp_details(){
			cout<<"The name of employee is :"<<endl;
			cout<<emp_name;
			cout<<"The id of employee is :"<<endl;
			cout<<emp_id;
			cout<<"The no of working hours of employee are :"<<endl;
			cout<<no_of_whr<<" hours "<<endl;
			cout<<"The salary per hour of employee is :"<<endl;
			cout<<per_hr_salary<<" Rs "<<endl;
		}
	  	
};
class Adhoc_employee:public Employee{
	protected :
		int total_salary;
	public :
	   int get_total_salary(){
	   	return no_of_whr * per_hr_salary;
	   }	
	   void display_total_salary(){
	   	cout<<"The total salary of employee is :"<<endl;
	   	cout<<get_total_salary()<<" Rs "<<endl;
	   }
	
};
int main(){
	Adhoc_employee a1;
	a1.set_emp_details();
	a1.get_emp_details();
	a1.display_total_salary();
	return 0 ;
}
