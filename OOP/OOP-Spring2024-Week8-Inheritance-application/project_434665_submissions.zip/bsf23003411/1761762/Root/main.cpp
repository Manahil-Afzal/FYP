/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee{
	protected:
	string name;
	int id;
	int no_of_hours;
	int per_hour_salary;
	public:
		void setdata(string n,int i,int hours,int phs){
			name=n;
			id=i;
			no_of_hours=hours;
			per_hour_salary=phs;
		}
		void getdata(){
			cout<<"Enter name:";
			cin>>name;
			cout<<"Enter id:";
			cin>>id;
			cout<<"Enter the working hours:";
			cin>>no_of_hours;
			cout<<"Enter  per hour salary:";
			cin>>per_hour_salary;		}	
};
  class adhoc_employee:public employee{

	public:
		int salary(){
			return per_hour_salary*no_of_hours;
		}
		void display(){
			cout<<"Displaying information of adhoc_employee:"<<endl;
			cout<<name<<endl<<id<<endl<<no_of_hours<<endl<<salary();
			
			
		}		
};
int main(){
	adhoc_employee A1;
	A1.getdata();
	A1.display();
}