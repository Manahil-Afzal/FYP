#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumOfWorkingHours;
    double PerHourSalary;

public:
    Employee(const string& name, int id, int numOfWorkingHours, double perHourSalary)
        : Name(name), Id(id), NumOfWorkingHours(numOfWorkingHours), PerHourSalary(perHourSalary) {}

    virtual double salary() const = 0; 
    virtual void display_info() const {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of Working Hours: " << NumOfWorkingHours << endl;
        cout << "Per Hour Salary: $" << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& name, int id, int numOfWorkingHours, double perHourSalary)
        : Employee(name, id, numOfWorkingHours, perHourSalary) {}

    double salary() const override {
        return NumOfWorkingHours * PerHourSalary;
    }

    void display_info() const override {
        Employee::display_info();
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee employee("Ali", 102045, 40, 25.0);
    employee.display_info();
    return 0;
}
