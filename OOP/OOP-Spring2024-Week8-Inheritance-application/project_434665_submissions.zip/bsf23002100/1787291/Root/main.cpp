#include<iostream>
using namespace std;
class Employee{
	protected:
	    string name;
	    string id;
	    int number_of_working_hours;
        int salary_per_hour;
    public:
    	void set_details(){
    		cout<<"Enter the Employee name: ";
    		getline(cin,name);
    		cout<<"Enter the Employee ID: ";
    	getline(cin,id);
    		cout<<"Enter the number of working hours of the Employee: ";
    		cin>>number_of_working_hours;
    		cout<<"Enter the salary per hour of the Employee: ";
    		cin>>salary_per_hour;
		}
		void display_details(){
			cout<<"Employee Name: ";
    		cout<<name<<endl;
    		cout<<"Employee ID: ";
    		cout<<id<<endl;
    		cout<<"Number of working hours of the Employee: ";
    		cout<<number_of_working_hours<<endl;
    		cout<<"Salary per hour of the Employee: ";
    		cout<<salary_per_hour<<endl;
			
		}
};
class AdhocEmployee : public Employee{
	protected:
		int total_salary;
		public:
			int cal_total_salary(){
				return number_of_working_hours*salary_per_hour;
			}
			void display_salary(){
				cout<<"Total salary of the Employee: ";
				cout<<cal_total_salary()<<endl;
			}
};
  
int main(){
	AdhocEmployee f2;
	f2.set_details();
	f2.display_details();
    f2.display_salary();
}