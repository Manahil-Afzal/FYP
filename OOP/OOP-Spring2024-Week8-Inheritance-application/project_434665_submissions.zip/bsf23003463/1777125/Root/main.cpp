/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;


class Employee {
protected:
    string name;
    int id;
    float numWorkingHours;
    float perHourSalary;

public:
    
    Employee(string name, int id, float numWorkingHours, float perHourSalary) : name(name), id(id), numWorkingHours(numWorkingHours), perHourSalary(perHourSalary) {}

    
    virtual float salary() = 0;

    
    virtual void display_info() = 0;
};

class Adhoc_employee : public Employee {
public:

    Adhoc_employee(string name, int id, float numWorkingHours, float perHourSalary) : Employee(name, id, numWorkingHours, perHourSalary) {}

    
    float salary() override {
        return numWorkingHours * perHourSalary;
    }

    
    void display_info() override {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << numWorkingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    
    Adhoc_employee emp("Ali", 1632, 55, 786.50);

    
    emp.display_info();

    return 0;
}