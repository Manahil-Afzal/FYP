/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

// Base class
class Employee {
protected:
    string name;
    int id;
    int numHours;
    double perHourSalary;

public:
    Employee(const string& name, int id, int numHours, double perHourSalary)
        : name(name), id(id), numHours(numHours), perHourSalary(perHourSalary) {}

    virtual double salary() const = 0;
    virtual void display_info() const = 0;
};

// Derived class
class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& name, int id, int numHours, double perHourSalary)
        : Employee(name, id, numHours, perHourSalary) {}

    double salary() const override {
        return numHours * perHourSalary;
    }

    void display_info() const override {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << numHours << endl;
        cout << "Per hour salary: $" << perHourSalary << endl;
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 12345, 40, 20.0);
    emp.display_info();

    return 0;
}