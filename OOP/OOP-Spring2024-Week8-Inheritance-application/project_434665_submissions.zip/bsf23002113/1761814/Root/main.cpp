#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int ID;
    int workingHours;
    double perHourSalary;

public:
    Employee(string n, int id, int hours, double salary) {
        name = n;
        ID = id;
        workingHours = hours;
        perHourSalary = salary;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(string n, int id, int hours, double salary) : Employee(n, id, hours, salary) {}

    double calculateSalary() {
        return workingHours * perHourSalary;
    }

    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "ID: " << ID << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
        cout << "Salary: " << calculateSalary() << endl;
    }
};

int main() {
    AdhocEmployee employee("Ahmad", 1234, 40, 15.5);
    employee.displayInfo();

    return 0;
}