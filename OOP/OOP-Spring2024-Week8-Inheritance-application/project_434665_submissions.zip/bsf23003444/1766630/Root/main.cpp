/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;

class Employee
{
private:
    string Employee_name;
    int Employee_Id;
    int Number_of_working_hours;
    int Per_hour_salary;

public:
    Employee() {}
    Employee(string name, int id, int number_of_working_hours, int per_hour_salary)
        : Employee_name(name), Employee_Id(id), Number_of_working_hours(number_of_working_hours), Per_hour_salary(per_hour_salary) {}

    int getsalary() {
        return Number_of_working_hours * Per_hour_salary;
    }

    void display_info() const {
        cout << "Name: " << Employee_name << endl;
        cout << "ID: " << Employee_Id << endl;
        cout << "Number of working hours: " << Number_of_working_hours << endl;
        cout << "Per hour salary: " << Per_hour_salary << endl;
    }
};

class Adhoc_employee : public Employee
{
public:
    Adhoc_employee(string name, int id, int number_of_working_hours, int per_hour_salary)
        : Employee(name, id, number_of_working_hours, per_hour_salary) {}

    // No need to override getsalary() method as it's already implemented in the base class.

    // Override display_info() method if needed.
};

int main() {
    Adhoc_employee employee("Shuja Jaffery", 1234, 40, 10); // Creating an object of Adhoc_employee

    cout << "Employee Information:" << endl;
    employee.display_info(); // Displaying information
    cout << "Salary: $" << employee.getsalary() << endl; // Displaying salary

    return 0;
}
