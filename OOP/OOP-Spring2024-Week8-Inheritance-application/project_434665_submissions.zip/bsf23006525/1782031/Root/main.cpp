
/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumOfWorkingHours;
    double PerHourSalary;

public:
    Employee(const string& name, int id, int hours, double salary)
        : Name(name), Id(id), NumOfWorkingHours(hours), PerHourSalary(salary) {}

    double salary() {
        return NumOfWorkingHours * PerHourSalary;
    }

    void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of working hours: " << NumOfWorkingHours << endl;
        cout << "Per hour salary: " << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    void display_info() {
        cout << "----- Employee Information -----" << endl;
        Employee::display_info();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 101, 40, 15.5);
    emp.display_info();

    return 0;
}
