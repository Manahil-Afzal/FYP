/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int num_hours;
    double per_hour_salary;

public:
    Employee(const string& n, int i, int hours, double salary) : name(n), id(i), num_hours(hours), per_hour_salary(salary) {}

    virtual double salary() const {
        return num_hours * per_hour_salary;
    }

    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << num_hours << endl;
        cout << "Per hour salary: " << per_hour_salary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& n, int i, int hours, double salary) : Employee(n, i, hours, salary) {}

    double salary() const override {
        return Employee::salary(); // Calculate salary using base class method
    }

    void display_info() const override {
        Employee::display_info(); // Call base class method to display common info
        cout << "Total Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee employee("John Doe", 12345, 40, 20.5); // Example values
    employee.display_info();

    return 0;
}
