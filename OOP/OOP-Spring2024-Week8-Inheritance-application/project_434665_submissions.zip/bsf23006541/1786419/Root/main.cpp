/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

// Base class Employee
class Employee {
protected:
    string name;
    int id;
    int hoursWorked;
    double hourlySalary;

public:
    // Constructor to initialize member variables
    Employee(string name, int id, int hoursWorked, double hourlySalary)
        : name(name), id(id), hoursWorked(hoursWorked), hourlySalary(hourlySalary) {}

    // Virtual function to calculate salary
    virtual double salary() {
        return hoursWorked * hourlySalary;
    }

    // Virtual function to display employee information
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hoursWorked << endl;
        cout << "Hourly Salary: " << hourlySalary << endl;
    }
};

// Derived class Adhoc_employee
class Adhoc_employee : public Employee {
public:
    // Constructor to initialize member variables using base class constructor
    Adhoc_employee(string name, int id, int hoursWorked, double hourlySalary)
        : Employee(name, id, hoursWorked, hourlySalary) {}

    // Override salary method to calculate salary for adhoc employee
    double salary() override {
        return hoursWorked * hourlySalary;
    }

 
    void display_info() override {
        Employee::display_info(); // Call base class method to display common information
        cout << "Salary: " << salary() << endl; // Calculate and display salary
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee emp("John Doe", 1234, 40, 20.5);

    // Display information and salary of the employee
    emp.display_info();

    return 0;
}
