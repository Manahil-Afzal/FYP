/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(const string& name, int id, int numHours, double perHourSalary)
        : Name(name), Id(id), NumWorkingHours(numHours), PerHourSalary(perHourSalary) {}

    virtual double salary() const {
        return NumWorkingHours * PerHourSalary;
    }

    virtual void display_info() const {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of Working Hours: " << NumWorkingHours << endl;
        cout << "Per Hour Salary: " << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& name, int id, int numHours, double perHourSalary)
        : Employee(name, id, numHours, perHourSalary) {}

    double salary() const override {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() const override {
        Employee::display_info();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    
    Adhoc_employee employee("John Doe", 1234, 40, 20.5); 
    cout << "Employee Information:" << endl;
    employee.display_info();

    return 0;
}
