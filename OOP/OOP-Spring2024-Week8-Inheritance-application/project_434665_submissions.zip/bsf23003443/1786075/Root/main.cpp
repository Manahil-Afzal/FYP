/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string name;
    int id;
    int hours_worked;
    double per_hour_salary;

public:
    Employee(const std::string& empName, int empId, int hoursWorked, double perHourSalary)
        : name(empName), id(empId), hours_worked(hoursWorked), per_hour_salary(perHourSalary) {}

    virtual double salary() const {
        return hours_worked * per_hour_salary;
    }

    virtual void display_info() const {
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Hours Worked: " << hours_worked << std::endl;
        std::cout << "Per Hour Salary: " << per_hour_salary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const std::string& empName, int empId, int hoursWorked, double perHourSalary)
        : Employee(empName, empId, hoursWorked, perHourSalary) {}

    double salary() const override {
        return Employee::salary();  // Calculates salary using base class method
    }

    void display_info() const override {
        Employee::display_info();  // Displays information using base class method
        std::cout << "Salary: " << salary() << std::endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 101, 40, 20.0);  // Creating an object of Adhoc_employee

    emp.display_info();  // Displaying information and salary

    return 0;
}
