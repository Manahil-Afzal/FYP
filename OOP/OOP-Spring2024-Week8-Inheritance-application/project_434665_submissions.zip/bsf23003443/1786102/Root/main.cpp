/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int workingHours;
    float perHourSalary;

public:
    Employee(const string& n, int i, int hours, float salary)
        : name(n), id(i), workingHours(hours), perHourSalary(salary) {}

    virtual float salary() const {
        return workingHours * perHourSalary;
    }

    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& n, int i, int hours, float salary)
        : Employee(n, i, hours, salary) {}

    float salary() const override {
        // Adhoc employees may have different salary calculations, so override the base class method
        return workingHours * perHourSalary * 1.2; // Assuming 20% bonus for Adhoc employees
    }

    void display_info() const override {
        cout << "Adhoc Employee Information:" << endl;
        Employee::display_info(); // Call base class display_info method
        cout << "Salary: " << salary() << endl; // Call overridden salary method
    }
};

int main() {
    Adhoc_employee adhocEmp("John Doe", 1001, 40, 20.0); // Example object
    adhocEmp.display_info();

    return 0;
}
