#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int num_working_hours;
    double per_hour_salary;

public:
    Employee( string name, int id, int num_working_hours, double per_hour_salary)
        : name(name), id(id), num_working_hours(num_working_hours), per_hour_salary(per_hour_salary) {}

    virtual double salary() = 0;

    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << num_working_hours << endl;
        cout << "Per hour salary: $" << per_hour_salary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee( string name, int id, int num_working_hours, double per_hour_salary)
        : Employee(name, id, num_working_hours, per_hour_salary) {}

    double salary(){
        return num_working_hours * per_hour_salary;
    }

    void display_info() {
        Employee::display_info();
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 1234, 40, 15.5);
    emp.display_info();
    return 0;
}
