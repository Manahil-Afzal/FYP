#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int hours_worked;
    float per_hour_salary;

public:
    Employee(string n, int i, int hw, float phs) : name(n), id(i), hours_worked(hw), per_hour_salary(phs) {}

    float salary() {
        return hours_worked * per_hour_salary;
    }

    void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hours_worked << endl;
        cout << "Per Hour Salary: " << per_hour_salary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Employee employee("John Doe", 1001, 40, 20.0);
    employee.display_info();

    return 0;
}
