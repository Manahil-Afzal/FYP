#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int workingHours;
    double perHourSalary;

public:
    Employee(string n, int i, int work, double perHour) {
        name = n;
        id = i;
        workingHours = work;
        perHourSalary = perHour;
    }

    virtual double salary() {
        return workingHours * perHourSalary;
    }

    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Per Hour Salary: $" << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int workingHours, double perHourSalary)
        : Employee(name, id, workingHours, perHourSalary) {}

    double salary() {
        return workingHours * perHourSalary;
    }

    void display_info()  {
        Employee::display_info();
        cout << "Total Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("ayesha", 12345, 40, 20.5); 
    emp.display_info(); 
    return 0;
}
