/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
 class Employee{
    protected:
    string name;
    int id;
    int no_work_hor;
    int per_hour_salr;
    public:
    void setdata(string n,int i,int hours,int phs){
			name=n;
			id=i;
			no_work_hor=hours;
			per_hour_salr=phs;
 }
    void getdata(){
    cout<<"Enter the name "<<endl;
    cin>>name;
    cout<<"Enter the id  "<<endl;
    cin>>id;
    cout<<"Enter no of working hours "<<endl;
    cin>>no_work_hor;
    cout<<"Enter per hour salary  "<<endl;
    cin>>per_hour_salr;
    }
 };
 class ad_hoc_Employee:public Employee{
    public:
		int salary(){
			return per_hour_salr*no_work_hor;
		}
		void display(){
			cout<<"Displaying information of adhoc_employee:"<<endl;
			cout<<name<<endl<<id<<endl<<no_work_hor<<endl<<salary();	
		}		
 };
int main()
{
    ad_hoc_Employee E1;
    E1.getdata();
    E1.display();
return 0;
}