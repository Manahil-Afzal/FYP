/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee{
	private :
		string name;
		int id;
		int working_hours;
		float salary;
		public :
			void get_data()
			{
				cout<< "enter name :"<<endl;
				cin>>name;
				cout<< "enter id :"<<endl;
				cin>>id;
				cout<< "enter no of working hours :"<<endl;
				cin>>working_hours;
				cout<< "enter salary per hour :"<<endl;
				cin>>salary;
		}
			string nam()
			{
				return name;
			}
			int idd()
			{
				return id;
			}
			int hours(){
				return working_hours;
			}
			float sal()
			{
				return salary;
			}
	 
			
	
};
class Adhoc_employee : public Employee{
	public :
		void cal_salary()
		{
//			int res = hours()*sal();
			cout<< "salary is :"<<hours()*sal()<<endl;
		}
		void display()
		{
			cout<< "name is :"<<nam()<<endl;
			cout<< "id is :"<<idd();
			cout<< "no of working hours :"<<hours()<<endl;
			cout<< "salary per hour is :"<<sal()<<endl;
		}
};
int main()
{
	Adhoc_employee e1;
	e1.get_data();
	e1.display();
	e1.cal_salary();
	return 0;
}