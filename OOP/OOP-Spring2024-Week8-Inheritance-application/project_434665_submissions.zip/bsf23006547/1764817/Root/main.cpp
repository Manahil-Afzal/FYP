/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
class Employee
{
	private:
		string emp_name;
		int Id;
		int work_hours;
		int per_hour_salary;
	public:
		Employee(string a,int b,int c,int d):emp_name(a),Id(b),work_hours(c),per_hour_salary(d)
		{}
		void display()
		{
		 cout<<"Employee Name : "<<emp_name<<endl;
		 cout<<"Id : "<<Id<<endl;
		 cout<<"workng Hours : "<<work_hours<<endl;
		 cout<<"Per hour salary : "<<per_hour_salary<<endl;
		}
		int salary()
		{
			return work_hours * per_hour_salary;
		}
};

class Adhoc_employee : public Employee
{
public:
	Adhoc_employee(string name,int id,int whrs,int sal):Employee(name,id,whrs,sal)
	{}
	int Ad_salary()
	{
		return Employee::salary();
	}
	void Ad_display()
	{
		Employee::display();
		cout<<"Salary : "<< Ad_salary()<<endl;
	}
};
int main()
{
	Adhoc_employee ad1("Ali",123,24,12);
	ad1.Ad_display();
}