/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee{
	protected:
		string name;
		int id;
		int workingHour;
		int salaryPerHour;
	public:
		void setData()
		{
			cout<<"Name:";
			cin>>name;
			cout<<"id:";
			cin>>id;
			cout<<"workigHour:";
			cin>>workingHour;
			cout<<"salaryPerHour:";
			cin>>salaryPerHour;
		}
		int salary(){
			return workingHour * salaryPerHour;
		}
		void displayInfo(){
		cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << workingHour << endl;
        cout << "Per Hour Salary: " << salaryPerHour << endl;
		}
};
class Adhoc_employee:public employee{
	public:
		
		int salary()
		{
			return employee::salary();
		}
		void displayInfo()
		{
			employee::displayInfo();
			cout<<"Salary:"<<salary();
		}
};
int main()
{
	Adhoc_employee emp;
	emp.setData();
	cout<<"\nEmployee Information:\n";
emp.displayInfo();
	return 0;
	
}