/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    float hoursWorked;
    float hourlySalary;

public:
    Employee(const string &name, int id, float hoursWorked, float hourlySalary)
        : name(name), id(id), hoursWorked(hoursWorked), hourlySalary(hourlySalary) {}

    float salary() {
        return hoursWorked * hourlySalary;
    }

    void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hoursWorked << endl;
        cout << "Hourly Salary: " << hourlySalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string &name, int id, float hoursWorked, float hourlySalary)
        : Employee(name, id, hoursWorked, hourlySalary) {}

    float salary()  {
        return Employee::salary();
    }

    void display_info()  {
        Employee::display_info();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 1234, 40, 20.5);
    emp.display_info();
   return 0;
}