/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class employee{
	protected:
	string name;
	int id;
	int whour;
	int salery;
	int phour;
	public:
	void input(){
		cout<<"enter name "<<endl;
		cin>>name;
		cout<<"enter id "<<endl;
		cin>>id;
		cout<<"enter whour "<<endl;
		cin>>whour;
		cout<<"per hour salery"<<endl;
		cin>>phour;
	
		
		
	}
	
};
class adhoc_employee:public employee{
	public:
	void sal(){
		salery=phour*whour;
		
	}
	
	void display(){
		cout<<"name "<<name<<endl;
			cout<<"id "<<id<<endl;
				cout<<"workin hours"<<whour<<endl;
					cout<<"salery "<<salery<<endl;
	}
	
};
main(){
	adhoc_employee s;
	s.input();
	s.sal();
	s.display();
}
