/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
#include<string>
class Employee{
	protected:
    string name;
    int id;
    int noofworkinghours;
    double perhoursalary;
    public:
    	Employee(string name,int id,int noofworkinghours,double perhoursalary ):  name(name),id(id),noofworkinghours(noofworkinghours),perhoursalary(perhoursalary)    	{
		}
		double salary(){
    	return	noofworkinghours * perhoursalary;
    	
		}
		void displayinfo()
		{
			cout<<"Employee Name : "<<name<<endl<<"Employee ID : "<<id<<endl<<"No of Working Hours :"<<noofworkinghours<<endl<<" Per Hour Salary :"<<perhoursalary<<endl<<"Total Salary :"<<salary()<<endl;
		}
    		
    		
    		   		
		};
	class Adhoc_employee:public Employee{
		public:
		Adhoc_employee(string name, int id, int noofworkinghours, double perhoursalary)
        : Employee(name, id, noofworkinghours, perhoursalary) {
		
	}
			void displayinfo(){ 
				cout<<"Adhoc Employee Deatils :"<<endl;
				Employee::displayinfo();
			}
	
    	
		};
		int main(){
			Adhoc_employee emp("Aazan",421,42,500);
			emp.displayinfo();
			return 0;
		}