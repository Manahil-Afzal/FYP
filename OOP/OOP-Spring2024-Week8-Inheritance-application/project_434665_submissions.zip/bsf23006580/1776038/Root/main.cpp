/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee
{
protected:
    string Name;
    string Id;
    int working_hours;
    double per_hour_salary;

public:
    void get_datails()
    {
        cout << "Enter the Employee Name       : ";
        cin >> Name;
        cout << "Enter the Employee Id         : ";
        cin >> Id;
        cout << "Enter the No of Working Hours : ";
        cin >> working_hours;
        cout << "Enter the Salary Per Hour     : ";
        cin >> per_hour_salary;
    }
};
class Adhoc_employee : public Employee
{
public:
    double net_salary()
    {
        return working_hours * per_hour_salary;
    }
    void display_info()
    {
        cout << endl
             << endl
             << "Emlpoyee Information" << endl
             << endl;
        cout << "Name of the Employee          :" << Name << endl;
        cout << "Id of the Employee            :" << Id << endl;
        cout << "Working hours                 :" << working_hours << endl;
        cout << "Salary Per Hour               :" << per_hour_salary << endl;
        cout << "Net Salary of the Employee    :" << net_salary() << endl;
    }
};
int main()
{
    Adhoc_employee E;
    E.get_datails();
    E.display_info();
    return 0;
}