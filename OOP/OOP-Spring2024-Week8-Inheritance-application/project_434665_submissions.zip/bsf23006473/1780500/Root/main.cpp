#include <iostream>
#include <string>

using namespace std;

class Employee
{
protected:
    string name;
    int id;
    int WorkingHours;
    double perHourSalary;

public:
    Employee(string name, int id, int WorkingHours, double perHourSalary)
    {
        this->name = name;
        this->id = id;
        this->WorkingHours = WorkingHours;
        this->perHourSalary = perHourSalary;
    }

    double salary()
    {
        return WorkingHours * perHourSalary;
    }

    void display_info()
    {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << WorkingHours << endl;
        cout << "Per hour salary: $" << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee
{
public:
    Adhoc_employee(string name, int id, int WorkingHours, double perHourSalary)
        : Employee(name, id, WorkingHours, perHourSalary) {}

    double salary()
    {
        return WorkingHours * perHourSalary;
    }
};

int main()
{
    Adhoc_employee emp("Daniyal Khalid", 1730, 50, 25.0);

    cout << "Employee Information:" << endl;
    emp.display_info();
    cout << "Salary: $" << emp.salary() << endl;

    return 0;
}


