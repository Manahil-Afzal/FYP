
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    // Parameterized constructor
    Employee(string name, int id, int numHours, double perHourSalary)
        : Name(name), Id(id), NumWorkingHours(numHours), PerHourSalary(perHourSalary) {}

    // Virtual function to calculate salary
    virtual double salary() {
        return NumWorkingHours * PerHourSalary;
    }

    // Virtual function to display information
    virtual void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of working hours: " << NumWorkingHours << endl;
        cout << "Per hour salary: $" << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    // Parameterized constructor
    Adhoc_employee(string name, int id, int numHours, double perHourSalary)
        : Employee(name, id, numHours, perHourSalary) {}

    // Override salary method
    double salary() override {
        return NumWorkingHours * PerHourSalary;
    }

    // Override display_info method
    void display_info() override {
        cout << "Adhoc Employee Information:" << endl;
        Employee::display_info(); // Call base class display_info
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee emp("John Doe", 101, 40, 20.0);

    // Display information and salary of the employee
    emp.display_info();

    return 0;
}
