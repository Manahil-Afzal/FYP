/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
class Employe{
	public:
	string name;
	int id;
	int workedhours;
	int perdaysalary;
	Employe(){
	}
	void setname(){
		cout<<"the name of employe is: ";
		cin>>name;
		cout<<"the id of emplye is: "<<endl;
		cin>>id;
		cout<<"no of worked hours: "<<endl;
		cin>>workedhours;
		cout<<"the per day salary:"<<endl;
		cin>>perdaysalary;
	}		
};
class Adhoc_employe:public Employe{
	public:
		Adhoc_employe(){
		}
		void salary(){
		cout<<"the total salary is: "<<workedhours*perdaysalary;
		}
		
		
		
		
		void display(){
			cout<<"\nNAME: "<<name<<"\nid: "<<id<<"\nper day salary: "<<perdaysalary<<"\nworked hours: "<<workedhours <<endl;
			salary();
		}
		
		
};
int main(){
	Adhoc_employe em;
	em.setname();
	em.salary();
	em.display();
}
