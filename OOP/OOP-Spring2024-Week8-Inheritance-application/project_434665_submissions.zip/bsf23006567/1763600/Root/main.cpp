/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee{
	protected:
		int id;
		string name;
		int hour;
		int salry_per_hour;
		int total_salry;
		
};
class Adhoc_employee:public employee{
	public:
		 void salry()
		 {
		 	
		 	
		 	total_salry=hour*salry_per_hour;
		 	
		 	
		 }
		 void set_data()
		 {
		 	cout<<"enter id number : ";
		 	cin>>id;
		 	cout<<"enter name : ";
		 	cin>>name;
		 	cout<<"entrer  slary per hour : ";
		 	cin>>salry_per_hour;
		 	cout<<"enter number of hour you work : ";
		 	cin>>hour;
		 	
		 }
		 void display(){
		 	
		 	cout<<" id number is : "<<id<<endl;
		 
		 	cout<<" name is : "<<name<<endl;
		 
		 
		 	cout<<"your  total salary is : ";
		 	cout<<total_salry;
		 	
		 }
};

int main()
{
	Adhoc_employee obj;
	obj.set_data();
	obj.salry();
	obj.display();
	
	
	
}