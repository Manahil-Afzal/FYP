/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int NWH;
    int PHS;

public:
    Employee(string name, int id, int NWH, int PHS)
        : name(name), id(id), NWH(NWH), PHS(PHS) {}



    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << NWH << endl;
        cout << "Per hour salary: " << PHS << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int NWH, int PHS)
        : Employee(name, id, NWH, PHS) {}

    double salary() {
        return NWH * PHS;
    }

    void display_info() {
        Employee::display_info();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("Shaheer", 103, 60, 200);
    emp.display_info();

    return 0;
}
