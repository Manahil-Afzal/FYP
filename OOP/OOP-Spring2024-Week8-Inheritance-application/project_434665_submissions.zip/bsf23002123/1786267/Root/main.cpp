/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by 
“Per hour salary”. The display_info method displaysthe complete information of employee. Create an object of Adhoc_employee and display
the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(string name, int id, int numHours, double hourlySalary)
        : Name(name), Id(id), NumWorkingHours(numHours), PerHourSalary(hourlySalary) {}

    virtual double salary(){
        return NumWorkingHours * PerHourSalary;
    }

    virtual void display_info(){
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of working hours: " << NumWorkingHours << endl;
        cout << "Per hour salary: $" << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int numHours, double hourlySalary)
        : Employee(name, id, numHours, hourlySalary) {}

    double salary()  {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info(){
        Employee::display_info();
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("farhan", 1234, 40, 20.5);
    emp.display_info();
    return 0;
}
