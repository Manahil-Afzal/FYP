/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
using namespace std;
class Employee
{
protected:
    string Name;
    int id;
    int working_hours;
    double per_hour_salary;

public:
};
class Adhoc_employee : public Employee
{
public:
    double salary()
    {
        return working_hours * per_hour_salary;
    }
    void get_info()
    {
        cout << "Please enter the Name of the employee: " << endl;
        cin >> Name;
        cout << "Please enter the ID of the employee: " << endl;
        cin >> id;
        cout << "Please enter the Working hours of the employee: " << endl;
        cin >> working_hours;
        cout << "Please enter the Per hour salary: " << endl;
        cin >> per_hour_salary;
    }
    void display_info()
    {
        cout << "Employee Name: " << Name << endl
             << "Employee ID: " << id << endl
             << "Working hours: " << working_hours << endl
             << "Per hour salary: " << per_hour_salary << endl
             << "Total Salary: " << salary() << endl;
    }
};
int main()
{
    Adhoc_employee e1;
    e1.get_info();
    e1.display_info();

    return 0;
}