/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;


class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    Employee(string name, int id, int numWorkingHours, double perHourSalary)
        : name(name), id(id), numWorkingHours(numWorkingHours), perHourSalary(perHourSalary) {}

    
    virtual ~Employee() {}

    
    virtual double salary() {
        return numWorkingHours * perHourSalary;
    }

    
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << numWorkingHours << endl;
        cout << "Per hour salary: $" << perHourSalary << endl;
    }
};


class Adhoc_employee : public Employee {
public:
    
    Adhoc_employee(string name, int id, int numWorkingHours, double perHourSalary)
        : Employee(name, id, numWorkingHours, perHourSalary) {}

    
    double salary() override {
        return numWorkingHours * perHourSalary;
    }

    
    void display_info() override {
        cout << "-----Adhoc Employee Information-----" << endl;
        Employee::display_info(); 
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    
    Adhoc_employee employee("John Doe", 1001, 40, 25.0);
    employee.display_info();

    return 0;
}