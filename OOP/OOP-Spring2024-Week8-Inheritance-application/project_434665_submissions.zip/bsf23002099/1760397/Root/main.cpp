#include <iostream>
#include <string>

using namespace std;

// Base class Employee
class Employee {
protected:
    string name;
    int id;
    int num_hours;
    double per_hour_salary;

public:
    // Constructor to initialize data members
    Employee(string n, int i, int hours, double salary)
        : name(n), id(i), num_hours(hours), per_hour_salary(salary) {}

    // Method to calculate salary
    double salary() {
        return num_hours * per_hour_salary;
    }

    // Method to display employee information
    void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << num_hours << endl;
        cout << "Per hour salary: " << per_hour_salary << endl;
    }
};

// Derived class Adhoc_employee
class Adhoc_employee : public Employee {
public:
    // Constructor to initialize base class members
    Adhoc_employee(string n, int i, int hours, double salary)
        : Employee(n, i, hours, salary) {}

    // method to calculate salary
    double salary() {
        return num_hours * per_hour_salary;
    }

    //  method to display employee information including salary
    void display_info()  {
        Employee::display_info(); // Call base class display_info method
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee employee("John Doe", 1234, 40, 15.5);
    
    // Display the information and salary of the employee
    employee.display_info();

    return 0;
}

