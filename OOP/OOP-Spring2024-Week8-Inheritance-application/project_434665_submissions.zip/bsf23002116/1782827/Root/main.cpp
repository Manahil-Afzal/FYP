/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
private:
    string name;
    int id;
    int hoursWorked;
    double hourlySalary;

public:
    Employee(string n, int i, int h, double s) : name(n), id(i), hoursWorked(h), hourlySalary(s) {}

    virtual double salary() {
        return hoursWorked * hourlySalary;
    }
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hoursWorked << endl;
        cout << "Hourly Salary: " << hourlySalary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

class Adhoc_employee : public Employee {
public:
	
    Adhoc_employee(string n, int i, int h, double s) : Employee(n, i, h, s) {}

    void display_info() override {
        cout << "Adhoc Employee Information:" << endl;
        Employee::display_info(); 
    }
};

int main() {
    Adhoc_employee emp("John Doe", 123, 40, 20.5);

    emp.display_info();

    return 0;
}
