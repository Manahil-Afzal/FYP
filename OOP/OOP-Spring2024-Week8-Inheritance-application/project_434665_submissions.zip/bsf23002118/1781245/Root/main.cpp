/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee{
  protected:
    string name;
    string id;
    int workHours;
    int hourSalary;
public:
    void setValues(){
        name="AbdulRahman";
        id="rehman123";
        workHours=8;
        hourSalary=100;
    }
};
class Adhoc_Employee: public Employee{
  public: 
  double Salary(){
      return workHours * hourSalary;
  }
            void displayInfo(){
                cout<<"Employee Name: "<<name<<endl;
                cout<<"Employee ID: "<<id<<endl;
                cout<<"Working hours: "<<workHours<<endl;
                cout<<"Total Salary: "<<Salary()<<endl;
            }
};
int main(){
    Adhoc_Employee employee;
    employee.setValues();
    employee.displayInfo();
    return 0;
}