/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee{
	protected:
	string name;
	int id;
	int working_hours;
	int per_hour_salary;
	public:
	void set(){
		cout<<"\tEnter Employee Details"<<endl;
		cout<<"Name : ";
		cin>>name;
		cout<<"Id : ";
		cin>>id;
		cout<<"Working Hours : ";
		cin>>working_hours;
		cout<<"Per Hour Salary : ";
		cin>>per_hour_salary;
	}
	string getname(){
		return name;
	}
	int getid(){
		return id;
	}
	int get_working_hours(){
		return working_hours;
	}
	int get_per_hour_salary(){
		return per_hour_salary;
	}
};
class Adhoc_employee: public Employee{
	Employee employ;
	public:
		void salary(){
		cout<<"Total Salary : "<<employ.get_working_hours()*employ.get_per_hour_salary()<<endl;
		}
		void put(){
			employ.set();
		}
		void display_info(){
			cout<<"Name  : "<<employ.getname()<<endl;
			cout<<"Id : "<<employ.getid()<<endl;
			cout<<"Working Hours : "<<employ.get_working_hours()<<endl;
			cout<<"Per Hour Salary : "<<employ.get_per_hour_salary()<<endl;
		}
};
int main()
{
	Adhoc_employee obj;
	obj.put();
	cout<<"\n\tEmployee Details  \n"<<endl;
	obj.display_info();
	obj.salary();
	return 0;
}