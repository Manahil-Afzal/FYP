/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
//****CODE****
#include<iostream>
using namespace std;
class Employee{
	protected:
	int id;
	string name;
	int num_workhours;
	int salary_ph;
	public:
	void set_id(int i){
		id=i;
	}
	int get_id(){
		return id;
	}
	void set_name(string n){
		name=n;
	}
	string get_name(){
		return name;
	}
    void set_number_workhours(int i){
		num_workhours=i;
	}
	int get_number_workhours(){
		return num_workhours;
	}
    void set_salary_perhour(int i){
		salary_ph=i;
	}
	int get_salary_perhour(){
		return salary_ph;
	}
};
class Adhoc_employee:public Employee{
	public:
	int cal_salary(){
		 return num_workhours*salary_ph;
	}
	void display_data(){
		cout<<"EMPLOYEE ID:"<<id<<endl;
		cout<<"EMPLOYEE NAME:"<<name<<endl;
		cout<<"EMPLOYEE WORKING HOURS:"<<num_workhours<<endl;
		cout<<"EMPLOYEE SALARY PER HOUR:"<<salary_ph<<endl;
	}
};
int main()
{
	Adhoc_employee E;
	E.set_id(234);
	E.set_name("Ahmad");
	E.set_number_workhours(8);
	E.set_salary_perhour(1000);
	//Display the data
	cout<<"EMPLOYEE DETAILS:"<<endl;
	E.display_data();
	cout<<"TOTAL SALARY:"<<E.cal_salary();
	return 0;
}