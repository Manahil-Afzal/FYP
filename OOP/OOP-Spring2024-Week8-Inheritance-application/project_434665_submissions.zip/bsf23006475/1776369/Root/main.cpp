/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
	int E_id;
	string E_name;
	int E_num_workhours;
	int E_salary_ph;
	public:
	void setid(int id1){
		E_id=id1;
	}
	int getid(){
		return E_id;
	}
	void setname(string name1){
		E_name=name1;
	}
	string getname(){
		return E_name;
	}
    void setnumberofworkhours(int i){
		E_num_workhours=i;
	}
	int getnumberofworkhours(){
		return E_num_workhours;
	}
    void setsalary_perhour(int i){
		E_salary_ph=i;
	}
	int getsalary_perhour(){
		return E_salary_ph;
	}
};
class Adhoc_employee:public Employee{
	public:
	int calculate_salary(){
		 return E_num_workhours*E_salary_ph;
	}
	void displaydetails(){
		cout<<"Employee Id="<<E_id<<endl;
		cout<<"Employee Name="<<E_name<<endl;
		cout<<"Employee Working Hours="<<E_num_workhours<<endl;
		cout<<"Employee Salary Per Hour="<<E_salary_ph<<endl;
	}
};
int main()
{
	Adhoc_employee Empolyee;
	Empolyee.setid(987654321);
	Empolyee.setname("Bilal");
	Empolyee.setnumberofworkhours(6);
	Empolyee.setsalary_perhour(2500);
	cout<<"Empolyee Details:"<<endl;
	Empolyee.displaydetails();
	cout<<"Total Salary:"<<Empolyee.calculate_salary();
}