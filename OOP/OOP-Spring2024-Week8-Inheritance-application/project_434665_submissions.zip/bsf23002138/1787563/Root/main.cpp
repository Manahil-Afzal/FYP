#include <iostream>
using namespace std;

class Employee{
protected:
    string name;
    int id,working_hour, perHoursal;
public:
    void input(){
        cout<<"Enter the Following information"<<endl;
        cout<<"name: ";
        cin>>name;
        cout<<"Id: ";
        cin>>id;
        cout<<"No of working hours: ";
        cin>>working_hour;
        cout<<"Per hour salary: ";
        cin>>perHoursal;
    }
};

class Adhoc_employee: public Employee{
    int sal;
public:
    void salary(){
        sal = working_hour * perHoursal;
    }
    void display_info(){
        cout<<"-------------------"<<endl;
        cout<<"Name: "<<name<<endl;
        cout<<"ID: "<<id<<endl;
        cout<<"Working hours: "<<working_hour<<endl;
        cout<<"Per Hour salary: "<<perHoursal<<endl;
        cout<<"Total salary: "<<sal<<endl;
    }

};

int main(){
    Adhoc_employee emp;
    emp.input();
    emp.salary();
    emp.display_info();
}