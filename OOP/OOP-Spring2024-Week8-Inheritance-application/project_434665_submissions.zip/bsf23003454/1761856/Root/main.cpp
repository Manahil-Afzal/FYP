/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int hoursWorked;
    double perHourSalary;

public:
    Employee(const string& name, int id, int hoursWorked, double perHourSalary)
        : name(name), id(id), hoursWorked(hoursWorked), perHourSalary(perHourSalary) {}

    virtual double salary() const {
        return hoursWorked * perHourSalary;
    }

    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hoursWorked << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& name, int id, int hoursWorked, double perHourSalary)
        : Employee(name, id, hoursWorked, perHourSalary) {}

    double salary() const override {
        return hoursWorked * perHourSalary;
    }

    void display_info() const override {
        Employee::display_info();
        cout << "Total Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 1234, 40, 25.5); 
    emp.display_info();

    return 0;
}
