#include <iostream>
#include <string>
using namespace std;
class Employee {
protected:
    string name;
    int id;
    int workhr;
    double salaryPerHr;

public:
    Employee(const string& n, int i, int hours, double salary): name(n), id(i),workhr(hours),  salaryPerHr(salary) {}

double salary() const {
        return workhr*salaryPerHr ;
    }

    void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << workhr << endl;
        cout << "Per Hour Salary: $" << salaryPerHr << endl;
        cout << "Salary: $" << salary() << endl;
    }

};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& n, int i, int hours, double salary): Employee(n, i, hours, salary) {}

};

int main() {
    Adhoc_employee emp("Ahmad", 101, 40, 20.5);
    emp.display_info();

    return 0;
}