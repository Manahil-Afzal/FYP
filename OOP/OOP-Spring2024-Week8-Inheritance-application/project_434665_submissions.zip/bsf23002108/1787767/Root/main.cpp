#include <iostream>
#include <string>

using namespace std;
class Employee {
protected:
    string name;
    int id;
    int hours_worked;
    double hourly_salary;

public:
    
    Employee(string n, int i, int hw, double hs) : name(n), id(i), hours_worked(hw), hourly_salary(hs) {}

    
    virtual double salary() {
        return hours_worked * hourly_salary;
    }

    
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hours_worked << endl;
        cout << "Hourly Salary: $" << hourly_salary << endl;
    }
};


class Adhoc_employee : public Employee {
public:
   
    Adhoc_employee(string n, int i, int hw, double hs) : Employee(n, i, hw, hs) {}

   
    double salary() override {
        return hours_worked * hourly_salary;
    }

  
    void display_info() override {
        cout << "Adhoc Employee Information:" << endl;
        Employee::display_info();
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
   
    Adhoc_employee emp("Ahmad", 1001, 40, 20.0);

   
    emp.display_info();

    return 0;
}
