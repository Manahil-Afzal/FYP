/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class employe
{
protected:
    string name;
    int id;
    int no_of_working_hours;
    int per_hour_salary;

public:
    void get_emp_details()
    {
        cout << "Enter the name of employe : " << endl;
        getline(cin, name);
        cout << "Enter the ID of employe : " << endl;
        cin >> id;
        cout << "Enter the no of working hours : " << endl;
        cin >> no_of_working_hours;
        cout << "Enter the per hour salary of employe : " << endl;
        cin >> per_hour_salary;
    }
    void display_details()
    {
        cout << "Employe name : " << name << endl;
        cout << "Employe id : " << id << endl;
        cout << "No of working hours : " << no_of_working_hours << endl;
        cout << "Per hour salary : " << per_hour_salary << endl;
    }
};
class Adhoc_employee : public employe
{
private:
    int salary;

public:
    int get_total_salary()
    {
        salary = per_hour_salary * no_of_working_hours;
        return salary;
    }
    void display_salary()
    {
        cout << "Total salary is : " << salary << "Rs" << endl;
    }
};
int main()
{

    Adhoc_employee s;
    s.get_emp_details();
    cout << "\nEmploye details are \n";
    s.display_details();
    s.get_total_salary();
    s.display_salary();

    return 0;
}