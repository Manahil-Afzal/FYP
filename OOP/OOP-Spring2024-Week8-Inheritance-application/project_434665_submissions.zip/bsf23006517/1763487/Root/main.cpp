/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by 
“Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;

class Employee{
	protected:
	string name;
	int id;
	int wHours;
	int sPh;
	public: 
		Employee(){
		cout<<"\t\t\tEmployee Info"<<endl;
		cout<<"Enter Name: ";
		cin>>name;
		cout<<"Enter Id: ";
		cin>>id;
		cout<<"Enter Working Hours: ";
		cin>>wHours;
		cout<<"Enter salary per Hour: ";
		cin>>sPh;
		}
};
class Adhoc_employee: protected Employee {

		int salaary;

public:
	void salary(){
		salaary=wHours*sPh;
	}
	void displayInfo(){
		cout<<"\t\t\tEmployee Info"<<endl;
		cout<<"Employee's Name: "<<name<<endl;
		cout<<"Employee's Id: "<<id<<endl;
		cout<<"Working Hours: "<<wHours<<endl;
		cout<<"Per Hour salary: "<<sPh<<endl;
		cout<<"Salary is: "<<salaary;
	}
	
};
int main(){
	Adhoc_employee e;
	e.salary();
	e.displayInfo();
	return 0;
	
}