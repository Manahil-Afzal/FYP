#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    float PerHourSalary;

public:
    
    Employee(const string& name, int id, int numWorkingHours, float perHourSalary) : 
        Name(name), Id(id), NumWorkingHours(numWorkingHours), PerHourSalary(perHourSalary) {}


    virtual float salary() {
        return NumWorkingHours * PerHourSalary;
    }


    virtual void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of working hours: " << NumWorkingHours << endl;
        cout << "Per hour salary: $" << PerHourSalary << endl;
    }
};


class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& name, int id, int numWorkingHours, float perHourSalary) : 
        Employee(name, id, numWorkingHours, perHourSalary) {}


    float salary() override {
        return Employee::salary(); 
    }
    void display_info() override {
        Employee::display_info();
        cout << "Salary: $" << salary() << endl; 
    }
};

int main() {

    Adhoc_employee emp("John Doe", 101, 40, 25.0f);


    cout << "Employee Information:" << endl;
    emp.display_info();

    return 0;
}
