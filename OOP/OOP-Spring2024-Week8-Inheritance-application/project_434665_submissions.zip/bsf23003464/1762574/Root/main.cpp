/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
class Employee{
    protected:
    string id;
    string name;
    int working_hours;
    int per_hour_salary;
};
class Adhoc_Employee: public Employee{
    public:
    int Salary;
    void salary(){
        cout<<"Enter your Name:";
        cin>>name;
        cout<<"Enter Your Id:";
        cin>>id;
        cout<<"Enter your wokring hours:";
        cin>>working_hours;
        cout<<"Enter your Per hour salary:";
        cin>>per_hour_salary;
        Salary=(per_hour_salary*working_hours)*30;
}
        void display_info(){
            cout<<"Your name is:"<<name<<endl;
            cout<<"Your Id is:"<<id<<endl;
            cout<<"Your Working hours are:"<<working_hours<<endl;
            cout<<"Your per hour salary is:"<<per_hour_salary<<endl;
            cout<<"Your Salary is:"<<Salary<<endl;
        }
};


    int main(){
        Adhoc_Employee person;
        person.salary();
        person.display_info();
        return 0;
    }

