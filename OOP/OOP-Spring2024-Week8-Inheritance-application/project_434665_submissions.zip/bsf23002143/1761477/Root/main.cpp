/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    // Constructor to initialize data members
    Employee(string n, int i, int hours, double salary) : name(n), id(i), numWorkingHours(hours), perHourSalary(salary) {}

    // Virtual function to calculate salary
    virtual double salary() {
        return numWorkingHours * perHourSalary;
    }

    // Virtual function to display employee information
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << numWorkingHours << endl;
        cout << "Per Hour Salary: $" << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    // Constructor to initialize base class data members
    Adhoc_employee(string n, int i, int hours, double salary) : Employee(n, i, hours, salary) {}

    // Overridden function to calculate salary
    double salary() override {
        return numWorkingHours * perHourSalary;
    }

    // Overridden function to display employee information
    void display_info() override {
        Employee::display_info();
        cout << "Total Salary: $" << salary() << endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee employee("John Doe", 1001, 40, 25.0);

    // Display the information and salary of the employee
    cout << "Employee Information:" << endl;
    employee.display_info();

    return 0;
}
