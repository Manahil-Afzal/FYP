/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee{
	protected:
		string name;
		int ID;
		int numWorkingHours;
        double perHourSalary;
    public:
	   Employee(string n, int id, int hours, double salary)   {
	   	name=n;
	   	ID=id;
	   	numWorkingHours=hours;
	   	perHourSalary=salary;
	   } 
};
class Adhoc_employee:public Employee{
	public:
		Adhoc_employee(string n, int id, int hours, double salary) :
        Employee(n, id, hours, salary) {}
		double salary(){
			return numWorkingHours * perHourSalary;
		}
		
		void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << ID << endl;
        cout << "Number of Working Hours: " << numWorkingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
        cout << "Salary is: " << salary() << endl;
    }

};
int main() {
    Adhoc_employee emp("Ali",2214, 50, 30.5);
    
    emp.display_info();
    return 0;
}