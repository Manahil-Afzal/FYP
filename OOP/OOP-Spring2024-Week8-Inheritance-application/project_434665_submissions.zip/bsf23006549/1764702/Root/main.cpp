/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
    protected: 
       string name;
       int id;
       int workingHours;
       float perHourSalary;
    public:
       void setData(){
           cout<<"Enter Name of Emloyee :";
           getline(cin,name);
           cout<<"Enter Id : ";
           cin>>id;
           cout<<"Enter Working Hours of Employee : ";
           cin>>workingHours;
           cout<<"Enter Per Hour Salary : ";
           cin>>perHourSalary;
       }
};
class Adhoc_Employee : public Employee{
    private:
       float calcSalary(){
           return workingHours*perHourSalary;
       }
    public:
       void disp(){
           cout<<"Employee's Name  : "<<id<<endl;
           cout<<"Employess's Name : "<<name<<endl;
           cout<<"Employee's Working Hours : "<<workingHours<<endl;
           cout<<"Employee' Per Hour Salary : "<<perHourSalary<<endl;
           cout<<"Employee's Salary is : "<<calcSalary()<<endl;
       }
};
int main(){
    Adhoc_Employee AE;
    AE.setData();
    AE.disp();
}