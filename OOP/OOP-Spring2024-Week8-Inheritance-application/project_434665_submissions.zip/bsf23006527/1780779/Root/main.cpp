#include <iostream>
using namespace std;

class employee
{
protected:
    string name;
    int id;
    int workingHour;
    int perHourSalary;

public:
    employee(string Name, int ID, int wh, int pH)
    {
        name = Name;
        id = ID;
        workingHour = wh;
        perHourSalary = pH;
    };

    virtual int salary (){
        return workingHour * perHourSalary;
    };

    virtual void display_info()
    {
        cout << "The name of Employee is : " << name;
        cout << "\nThe ID of Employee is : " << id;
        cout << "\nThe Working Hour of Employee is : " << workingHour;
        cout << "\nThe Per Hour Salary of Employee is : " << perHourSalary;
        cout << endl;
    };

};

class Adhoc_employee : public employee
{
private:
    int total;

public:
    Adhoc_employee(string Name, int ID, int wh, double pH) : employee(Name, ID, wh, pH){};

    int salary (){
       return employee::salary();
    };

    void display_info(){
        employee::display_info();
        cout << "The Total Salary of employee is : " << salary();
    }
};

int main()
{
    Adhoc_employee Employe("Sheraz khan", 69 , 10, 300);

    Employe.display_info();

    return 0;
}