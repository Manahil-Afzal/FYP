/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
  using namespace std;
  class employee{
  	public:
  	string name;
  	int id;
  	int hours;
  	int salary1;
  	
		  void input()
		  {
		  	cout<<"enter the employee name"<<endl;
		  	cin>>name;
		  	cout<<"enter the employee id"<<endl;
		  	cin>>id;
		  	cout<<"enter the employee working hours"<<endl;
		  	cin>>hours;
		  	cout<<"enter the employee per hour salary"<<endl;
		  	cin>>salary1;
		  	
		  }
  };
  class adhoc_employee:public employee{
  	public:
  		int salary;
  	void sal(){
  		salary=salary1*hours;
	  }
	  void display(){
	  	cout<<"employee name is "<<name<<endl;
	  	cout<<"employee id is "<<id<<endl;
	  	cout<<"employee working hours are"<<hours<<endl;
	  	cout<<"employee per hour salary  is "<<salary1<<endl;
		  cout<<"the total salary is "<<salary<<endl;	  	
	  }
  };
  int main(){
  	adhoc_employee e;
  	e.input();
    e.sal();
    e.display();
  }
  