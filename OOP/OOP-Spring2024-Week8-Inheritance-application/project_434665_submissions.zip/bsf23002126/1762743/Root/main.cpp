/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int ID;
    int workingHours;
    double perHourSalary;

public:
    Employee(string n, int id, int hours, double salary) {
        name = n;
        ID = id;
        workingHours = hours;
        perHourSalary = salary;
    }
};

class AdhocEmployee : public Employee {
public:
    AdhocEmployee(string n, int id, int hours, double salary) : Employee(n, id, hours, salary) {}

    double calculateSalary() {
        return workingHours * perHourSalary;
    }

    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "ID: " << ID << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
        cout << "Salary: " << calculateSalary() << endl;
    }
};

int main() {
    AdhocEmployee employee("John Doe", 1234, 40, 15.5);
    employee.displayInfo();

    return 0;
}