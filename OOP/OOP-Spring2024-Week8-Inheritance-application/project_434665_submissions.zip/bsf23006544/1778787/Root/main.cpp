/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string name;
    int id;
    int working_hours;
    double per_hour_salary;

public:
    // Default constructor
    Employee() : name("Unknown"), id(0), working_hours(0), per_hour_salary(0.0) {}

    // Parameterized constructor
    Employee(const std::string& name, int id, int working_hours, double per_hour_salary)
        : name(name), id(id), working_hours(working_hours), per_hour_salary(per_hour_salary) {}

    // Getters
    std::string get_name() const { return name; }
    int get_id() const { return id; }
    int get_working_hours() const { return working_hours; }
    double get_per_hour_salary() const { return per_hour_salary; }

    // Setters
    void set_name(const std::string& n) { name = n; }
    void set_id(int i) { id = i; }
    void set_working_hours(int hours) { working_hours = hours; }
    void set_per_hour_salary(double salary) { per_hour_salary = salary; }
};

class Adhoc_employee : public Employee {
public:
    // Default constructor
    Adhoc_employee() : Employee() {}

    // Parameterized constructor
    Adhoc_employee(const std::string& name, int id, int working_hours, double per_hour_salary)
        : Employee(name, id, working_hours, per_hour_salary) {}

    double salary() const {
        return working_hours * per_hour_salary;
    }

    void display_info() const {
        std::cout << "Employee Name: " << name << std::endl;
        std::cout << "Employee ID: " << id << std::endl;
        std::cout << "Working Hours: " << working_hours << std::endl;
        std::cout << "Per Hour Salary: $" << per_hour_salary << std::endl;
        std::cout << "Total Salary: $" << salary() << std::endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 123, 40, 25.0); // Create an instance of Adhoc_employee with sample data

    // Display information and calculate salary
    emp.display_info(); // Display information about the employee

    return 0; // Return statement to end the main function
}