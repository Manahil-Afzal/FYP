/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. 
The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;

class employee{
	private:
	 string name;
	 string id;
	 float working_hours;
   	 float salary;
	public:
	     void get_name(string a){
	     	name=a;
		 }
		 string print_name(){
		 	return name;
		 }
		 void get_id(string b){
		 	id=b;
		 }
		 string print_id(){
		 	return id;
		 }
		  void get_working_hours(float c){
		 	working_hours=c;
		 }
		 float print_working_hours(){
		 	return  working_hours;
		 }
		 
		  void get_salary(float d){
		 	salary=d;
		 }
		 
		 float print_salary(){
		 	return salary;
		 }
	
	 
};
class adhoc_employee : private employee{
	
	public:
		
		void print_details(){
			
			cout<<"Enter the Name : ";
			string a;
			getline(cin,a);
			cout<<"Enter the ID : ";
			string b;
			getline(cin,b);
			cout<<"Enter Working Hours : ";
			float c;
		    cin>>c;
			cout<<"Enter the salary per Hours : ";
			float d;
			cin>>d;
			get_name(a);
			get_id(b);
			get_working_hours(c);
			get_salary(d);
			cout<<endl;
			cout<<endl;
			cout<<endl;
			cout<<"DETAILS ARE FOLLOWING ";
			cout<<endl;
			
			cout<<"Name : "<<print_name()<<endl;
			cout<<"ID : "<<print_id()<<endl;
			cout<<"Working hours : "<<print_working_hours()<<endl;
			cout<<"Salary per Hours : "<<print_salary()<<endl;
			int total;
			total=print_working_hours() * print_salary();
			cout<<"Total salary : "<<total;

}


	
};

int main(){
	
adhoc_employee obj;
obj.print_details();
return 0;
	
}