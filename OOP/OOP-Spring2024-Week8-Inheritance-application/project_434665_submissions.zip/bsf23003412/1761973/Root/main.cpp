/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string>
using namespace std;
class employee{
    protected:
    string name;
    int id;
    int noofhours;
    double persalary;
    public:
    void set(string n,int ID,int hours,double Salary){
        name=n;
        id=ID;
        noofhours=hours;
        persalary=Salary;
        
    }
    void get(){
        cout<<"name"<<endl;
        cin>>name;
        cout<<"per hour salary"<<endl;
        cin>>persalary;
        cout<<"id"<<endl;
        cin>>id;
        cout<<"noofhours"<<endl;
        cin>>noofhours;
    }
};
class adhoc_employee:public employee 
{
    public:
    double getsalary(){
        return persalary*noofhours;
        
    }
   void display(){
       cout<<"name"<<name<<"id"<<id<<"per hour salary"<<persalary<<"no of hours"<<noofhours<<"salary"<<getsalary();
   } 
};
int main(){
    adhoc_employee e1;
    e1.get();
    e1.getsalary();
    e1.display();
    
}
