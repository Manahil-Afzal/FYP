/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

// Base class: Employee
class Employee {
protected:
    string name;
    int id;
    int workingHours;
    double perHourSalary;

public:
    // Constructor to initialize data members
    Employee(string empName, int empId, int hours, double salary)
        : name(empName), id(empId), workingHours(hours), perHourSalary(salary) {}

    // Calculate salary based on working hours and per hour salary
    double salary() {
        return workingHours * perHourSalary;
    }

    // Display complete information of the employee
    void display_info() {
        cout << "Employee Name: " << name << endl;
        cout << "Employee ID: " << id << endl;
        cout << "Working Hours: " << workingHours << " hours" << endl;
        cout << "Per Hour Salary: $" << perHourSalary << endl;
    }
};

// Derived class: Adhoc_employee
class Adhoc_employee : public Employee {
public:
    // Constructor to initialize base class data members
    Adhoc_employee(string empName, int empId, int hours, double salary)
        : Employee(empName, empId, hours, salary) {}
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee adhocEmp("John Doe", 101, 40, 20.0); // Example values

    // Display information and salary for the Adhoc_employee
    adhocEmp.display_info();
    cout << "Salary: $" << adhocEmp.salary() << endl;

    return 0;
}
