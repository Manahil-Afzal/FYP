/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int hours;
    float rate;

public:
    Employee(string n, int i, int h, float r) : name(n), id(i), hours(h), rate(r) {}

    virtual float salary() const {
        return hours * rate;
    }

    void display_info() const {
        cout << "Name: " << name << ", ID: " << id << ", Hours: " << hours << ", Rate: $" << rate << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string n, int i, int h, float r) : Employee(n, i, h, r) {}

    float salary() const override {
        return hours * rate * 1.5; // adhoc employees get 50% extra pay
    }
};

int main() {
    Adhoc_employee e("John Doe", 1234, 40, 20.5);
    e.display_info();
    cout << "Salary: $" << e.salary() << endl;
    return 0;
}