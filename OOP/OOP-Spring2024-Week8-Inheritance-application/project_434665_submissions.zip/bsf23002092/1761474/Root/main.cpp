/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee{
protected:
    string name;
    int id;
	int working_hour; 
	int per_Hour_salary;
public:
    void input(){
        cout<<"Enter the Following information"<<endl;
        cout<<"name: ";
        cin>>name;
        cout<<"Id: ";
        cin>>id;
        cout<<"Number of working hours: ";
        cin>>working_hour;
        cout<<"Enter the Per hour salary: ";
        cin>>per_Hour_salary;
    }
};

class Adhoc_employee: public Employee{
    int cal;
public:
    void salary(){
        cal = working_hour * per_Hour_salary;
    }
    void display_information(){
        cout<<"-------------------"<<endl;
        cout<<"Name: "<<name<<endl;
        cout<<"ID: "<<id<<endl;
        cout<<"Working hours: "<<working_hour<<endl;
        cout<<"Per Hour salary: "<<per_Hour_salary<<endl;
        cout<<"Total salary: "<<cal<<endl;
    }

};

int main(){
    Adhoc_employee emp;
    emp.input();
    emp.salary();
    emp.display_information();
}