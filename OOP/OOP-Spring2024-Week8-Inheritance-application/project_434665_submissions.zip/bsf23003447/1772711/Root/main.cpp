/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee
{
     protected:
    string name;
    int id;
    int NumOfWorkingHou;
    int PerHoSalary;
    public:
     Employee(string n, int i, int Numof, int perho) : name(n), id(i), NumOfWorkingHou(Numof), PerHoSalary(perho) {}
    
    
};
class Adhoc_employee:public Employee
{
  public:
  Adhoc_employee(string n,int id, int numOfWor, int perhou ):Employee(n, id ,numOfWor,perhou){}
  void DispDetails()
  {
      cout<<"Employee name is :"<<name<<endl;
      cout<<"Emplyee id is :"<<id<<endl;
      cout<<"Employee Number of working hours :"<<NumOfWorkingHou<<endl;
      cout<<"Employee per hour salary :"<<PerHoSalary<<endl;
  }
  void salary()
  {
      int sal=NumOfWorkingHou*PerHoSalary;
      cout<<"Employee salary per hour :"<<sal;
  }
};
int main()
{
      Adhoc_employee em1("saleem",123, 4, 1000);
   
  em1.DispDetails();
 em1.salary();
}