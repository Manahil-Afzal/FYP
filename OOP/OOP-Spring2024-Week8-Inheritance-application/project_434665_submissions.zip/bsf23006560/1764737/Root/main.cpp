
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(string name, int id, int numWorkingHours, double perHourSalary)
        : Name(name), Id(id), NumWorkingHours(numWorkingHours), PerHourSalary(perHourSalary) {}

    double salary() {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of Working Hours: " << NumWorkingHours << endl;
        cout << "Per Hour Salary: " << PerHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string name, int id, int numWorkingHours, double perHourSalary)
        : Employee(name, id, numWorkingHours, perHourSalary) {}
};

int main() {
    Adhoc_employee employee("John Doe", 1234, 40, 15.5);
    employee.display_info();
    cout << "Salary:" << employee.salary() << endl;

    return 0;
}