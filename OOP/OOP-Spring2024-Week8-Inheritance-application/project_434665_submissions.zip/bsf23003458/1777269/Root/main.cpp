/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int hours_worked;
    double hourly_salary;

public:
    Employee(const string& _name, int _id, int _hours_worked, double _hourly_salary)
        : name(_name), id(_id), hours_worked(_hours_worked), hourly_salary(_hourly_salary) {}

    virtual double salary() const {
        return hours_worked * hourly_salary;
    }

    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hours_worked << endl;
        cout << "Hourly Salary: $" << hourly_salary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& _name, int _id, int _hours_worked, double _hourly_salary)
        : Employee(_name, _id, _hours_worked, _hourly_salary) {}

    double salary() const override {
        return Employee::salary();
    }

    void display_info() const override {
        Employee::display_info();
        cout << "Salary: $" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 1001, 40, 15.50);
    emp.display_info();

    return 0;
}