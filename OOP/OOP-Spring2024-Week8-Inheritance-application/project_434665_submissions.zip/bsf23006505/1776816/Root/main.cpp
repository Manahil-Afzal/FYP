#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    Employee(const string& n, int i, int numHours, double salary):
	 name(n), id(i), numWorkingHours(numHours), perHourSalary(salary) {}

    virtual double salary() const = 0;
    virtual void display_info() const = 0; 
	};
class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& n, int i, int numHours, double salary)
        : Employee(n, i, numHours, salary) {}

    double salary() const override {
        return numWorkingHours * perHourSalary;
    }

    void display_info() const override {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << numWorkingHours << endl;
        cout << "Per hour salary: " << perHourSalary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 101, 40, 20.0);
    emp.display_info();

    return 0;
}

