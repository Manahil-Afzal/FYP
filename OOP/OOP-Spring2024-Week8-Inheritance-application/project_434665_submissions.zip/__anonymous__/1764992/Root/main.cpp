/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
		string name;
		string ID;
		int No_of_workingHours;
		int per_hour_salary;
		public:
			void get_employee_data(string n,string id,int workingHours,int perHourSa){
				name=n;
				ID=id;
				No_of_workingHours=workingHours;
				per_hour_salary=perHourSa;
			}
			void display_employee_data(){
	cout<<"Employee Name : "<<name<<"\nEmployee ID : "<<ID<<"\nEmployee Working Hours : "<<No_of_workingHours<<" Hours "<<"\nEmployee Per Hour Salary : "<<per_hour_salary<<" Rupees";
			}
};
class Adhoc_employee : public Employee{
	public:
		int calculateSalary(){
			double salary;
			 salary=No_of_workingHours*per_hour_salary;
			return salary;
		}
		void displayInfo(){
			display_employee_data();
			cout<<"\nEmployee Total Salary : "<<No_of_workingHours*per_hour_salary<<" Rupees ";
		}
};
int main(){
	Adhoc_employee AE;
	AE.get_employee_data("Ali","bsf23057",8,1000);
	AE.calculateSalary();
	AE.displayInfo();
	return 0;
}