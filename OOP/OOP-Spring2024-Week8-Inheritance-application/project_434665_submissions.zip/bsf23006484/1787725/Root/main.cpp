/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee//Base class
{   public:
    string Name,ID;
    int No_of_work_hours,per_hour_salary;
    void getdata()
    {
        cout<<"Enter Name:"<<endl;
        cin>>Name;
        cout<<"Enter ID:"<<endl;
        cin>>ID;
        cout<<"Enter Number of working hours:"<<endl;
        cin>>No_of_work_hours;
        cout<<"Enter Per hour salary:"<<endl;
        cin>>per_hour_salary;
    }
};
class Adhoc_employee:public Employee//Derived class
{   public:
       int salary_of_Employee;
    void salary()
    {
        salary_of_Employee=No_of_work_hours*per_hour_salary;
    }
    void display()
    {
        cout<<"Salary of Employee:"<<salary_of_Employee;
    }
};
int main()
{
    Adhoc_employee a;
    a.getdata();
    a.salary();
    a.display();

}
