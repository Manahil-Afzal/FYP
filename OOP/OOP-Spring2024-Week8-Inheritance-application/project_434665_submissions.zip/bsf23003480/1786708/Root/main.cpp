/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int hours_worked;
    double hourly_salary;

public:
    // Constructor to initialize Employee object
    Employee(const string& n, int i, int h, double s)
        : name(n), id(i), hours_worked(h), hourly_salary(s) {}

    // Method to calculate salary
    double salary() {
        return hours_worked * hourly_salary;
    }

    // Method to display information of employee
    void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Hours Worked: " << hours_worked << endl;
        cout << "Hourly Salary: " << hourly_salary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    // Constructor to initialize Adhoc_employee object
    Adhoc_employee(const string& n, int i, int h, double s)
        : Employee(n, i, h, s) {}
};

int main() {
    // Create an object of Adhoc_employee and display information and salary
    Adhoc_employee emp("John Doe", 1001, 40, 15.5); // Name, ID, Hours Worked, Hourly Salary
    cout << "Employee Information:" << endl;
    emp.display_info();

    return 0;
}
