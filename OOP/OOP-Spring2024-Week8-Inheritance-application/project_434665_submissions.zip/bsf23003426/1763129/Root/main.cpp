/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee
{
    public:
    string name;
    int id;
    int working_hours;
    int slaray_per_hour;
    void getdata(){
    cout<<"enter your name";
    cin>>name;
    cout<<"enter your id";
    cin>>id;
    cout<<"no oof working hours";
    cin>>working_hours;
    cout<<"enter per hour slary";
    cin>>slaray_per_hour;
}};
class adhoc_employ:public employee
{
    public:
    int salary;
    void sal()
    {
        salary=working_hours*slaray_per_hour;
        
    }
    void display()
    {
        cout<<"your name is"<<name;
        cout<<"your id is"<<id;
        cout<<"no of working hours"<<working_hours;
        cout<<"per hour salary"<<slaray_per_hour;
        cout<<"your salary is"<<salary;
    }
};
int main()
{
    
    adhoc_employ e1;
    e1.getdata();
    e1.sal();
    e1.display();
}
