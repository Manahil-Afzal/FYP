 /*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.The base class has data members of Name, Id, Number of working
hours and Per hour salary. The derived class implements two methods named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by
“Per hour salary”. The display_info method displays the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
protected:
string name;
int id;
int number_of_working_hours;
int per_hour_salary;
public:
int get_data(){
cout << "Enter the name of employee ";
cin >> name;
cout << "Enter the id of employee ";
cin >> id;
cout << "Enter the number of working hours of employee ";
cin >> number_of_working_hours;
cout << "Enter the per hour salary ";
cin >> per_hour_salary;
}
};
class Adhoc_employee:public Employee{
public:
int salary(){
int salary_cal;
cout << "The salary of employee is ";
salary_cal = number_of_working_hours * per_hour_salary;
cout << salary_cal;
}
int display_info(){
get_data();
cout << endl;
cout << "--------------------------------------------------------------------------------" << endl;
cout << "The name of employee is " << name << endl;
cout << "The id of employee is " << id << endl;
cout << "The number of working hours of employee is " << number_of_working_hours << endl;
cout << "The slary per hour is " << per_hour_salary << endl;
return salary();
}
};
int main(){
Adhoc_employee e;
e.display_info();
}