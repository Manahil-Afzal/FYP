/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/


#include <iostream>
using namespace std;

string name;

class Engine{
    int engine_no;
    public:
        Engine(){
            engine_no = 219972;
        }
        void display(){
            cout<<"Engine no: "<<engine_no<<endl;

        }

};
class Passenger{
    string pass_name;
    public:
        void setName(string name){
            pass_name = name;
        }
        void display(){
            cout<<"Passenger name: "<<pass_name<<endl;
        }
};

class Car{
    public:
        Engine en;
        Passenger *p;
        Car(Passenger *p){
            this->p = p;
            en.display();
            p->setName(name);
            p->display();
        }
};

int main(){
    cout<<"Enter the name of passenger: ";
    cin>>name;
    Passenger pn;
    Car c(&pn);


    return 0;
}