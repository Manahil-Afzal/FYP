/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/


#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int workingHours;
    double perHourSalary;

public:
    // Constructor
    Employee(string n, int i, int h, double s) : name(n), id(i), workingHours(h), perHourSalary(s) {}

    // Virtual destructor
    virtual ~Employee() {}

    // Method to calculate salary
    virtual double salary() {
        return workingHours * perHourSalary;
    }

    // Method to display information
    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    // Constructor
    Adhoc_employee(string n, int i, int h, double s) : Employee(n, i, h, s) {}

    // Method to calculate salary (overrides base class method)
    double salary() override {
        return workingHours * perHourSalary;
    }

    // Method to display information (overrides base class method)
    void display_info() override {
        Employee::display_info(); // Calling base class method to display common information
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee emp("John Doe", 12345, 40, 20.5);

    // Display information and salary
    emp.display_info();

    return 0;
}
