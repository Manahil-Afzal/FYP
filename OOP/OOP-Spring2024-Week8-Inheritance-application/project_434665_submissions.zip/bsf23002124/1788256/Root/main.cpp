#include <iostream>
#include <string>

using namespace std;

// Base class Employee
class Employee {
protected:
    string Name;
    int Id;
    int NumOfWorkingHours;
    double PerHourSalary;

public:
    // Constructor
    Employee(string name, int id, int hours, double salary)
        : Name(name), Id(id), NumOfWorkingHours(hours), PerHourSalary(salary) {}

    // Virtual destructor
    virtual ~Employee() {}

    // Virtual function to calculate salary
    virtual double calculateSalary() const {
        return NumOfWorkingHours * PerHourSalary;
    }

    // Virtual function to display information
    virtual void displayInfo() const {
        cout << "Name: " << Name << endl;
        cout << "ID: " << Id << endl;
        cout << "Number of Working Hours: " << NumOfWorkingHours << endl;
        cout << "Per Hour Salary: " << PerHourSalary << endl;
    }
};

// Derived class Adhoc_employee
class Adhoc_employee : public Employee {
public:
    // Constructor
    Adhoc_employee(string name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    // Override calculateSalary method
    double calculateSalary() const override {
        return Employee::calculateSalary(); // Simply call base class method
    }

    // Override displayInfo method
    void displayInfo() const override {
        Employee::displayInfo(); // Simply call base class method
        cout << "Salary: " << calculateSalary() << endl;
    }
};

int main() {
    // Create an object of Adhoc_employee
    Adhoc_employee employee("Ahmad Izhar", 1001, 40, 20.0);

    // Display information and salary
    cout << "Employee Information:" << endl;
    employee.displayInfo();

    return 0;
}
