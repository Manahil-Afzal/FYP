/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int num_working_hours;
    double per_hour_salary;

public:
    Employee(const string& emp_name, int emp_id, int hours, double salary_per_hour)
        : name(emp_name), id(emp_id), num_working_hours(hours), per_hour_salary(salary_per_hour) {}

    virtual double salary() const = 0;

    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << num_working_hours << endl;
        cout << "Per Hour Salary: " << per_hour_salary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(const string& emp_name, int emp_id, int hours, double salary_per_hour)
        : Employee(emp_name, emp_id, hours, salary_per_hour) {}

    double salary() const override {
        return num_working_hours * per_hour_salary;
    }

    void display_info() const override {
        Employee::display_info();
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("Daniyal", 1001, 40, 20.5);
    emp.display_info();

    return 0;
}
