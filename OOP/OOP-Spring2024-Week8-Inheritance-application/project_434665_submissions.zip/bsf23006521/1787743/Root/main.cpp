#include <iostream>
#include <string>
using namespace std;
// Base class Employee
class Employee {
protected:
    string name;
    int id;
    int hours_worked;
    double per_hour_salary;

public:
    Employee( string& n, int i, int h, double phs) : name(n), id(i), hours_worked(h), per_hour_salary(phs) {}
};

// Derived class Adhoc_employee inheriting from Employee
class Adhoc_employee : public Employee {
public:
    Adhoc_employee( string n, int i, int h, double phs): Employee(n, i, h, phs) {}
 // Method to calculate salary
    double salary() const {
        return hours_worked * per_hour_salary;
    }

    void display_info()  {
        cout << "=== Adhoc Employee Details ===" << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << hours_worked<< endl;
        cout << "Per hour salary: " << per_hour_salary << endl;
        cout << "Salary: " << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("Sameer", 1234,190, 300);
    emp.display_info();

    return 0;
}
