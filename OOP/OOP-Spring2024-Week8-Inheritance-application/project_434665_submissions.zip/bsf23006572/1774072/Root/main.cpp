/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
#include<string.h>
using namespace std;
class Employee
{
    protected:
    string emp_name="Raza Khan ";
    int emp_id= 2343;
    int working_hours= 8;
    int per_hour_salary= 200;
    int total_salary;
    

};
class Adhoc_employee:public Employee
{
public:
void  salarry()
{
    total_salary= per_hour_salary*working_hours;
}
void dispaly_details()
{
    cout<<"The name of the employee is = "<<emp_name<<endl;
    cout<<"The employee is = "<<emp_id<<endl;
    cout<<"The number of working hours = "<<working_hours<<endl;
    cout<<"The total salary of the employee = "<<total_salary<<endl;
}
   

};
int main()
{
    Adhoc_employee ep1;
    ep1.salarry();
    ep1.dispaly_details();
    return 0;
}