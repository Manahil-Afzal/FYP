/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class employee{
protected:
	string name;
	int id;
	 int num_of_work_hours;
	int per_day_salary;
	public:
		int data (string n, int id1,int nwh,int pds)
		{
			name=n;
			id=id1;
			num_of_work_hours=nwh;
			per_day_salary=pds;
		}
		  
		
};
class Ahdhoc_employee : public employee{
	private:
		int result;
	   public:
	   	
	   	int salary()
		   {
		   
	   result =	(num_of_work_hours*per_day_salary);
	   	return result;}
	   	
	   	void display()
	   	{
	   		cout<<"the name id employee is :"<<name<<endl<<"the id of employee is:"<<id<<endl<<"the number of working hoours is "<<num_of_work_hours<<endl<<"the per day salary is :"<<per_day_salary<< endl<<"the total salary is "<<result;
	   	}
	   		
};
int main()
{

	Ahdhoc_employee emp;
	emp.data("Ali  ", 1002,2,1500);
	emp.salary();
	emp.display();}