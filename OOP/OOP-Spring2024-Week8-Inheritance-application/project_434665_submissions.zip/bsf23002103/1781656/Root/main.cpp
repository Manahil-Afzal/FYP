/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;
class Employee{
  protected:
    string Name;
    string Id;
    int work_hours;
    int hour_salary;
public:
    void setValues(){
        Name="bilaaal";
        Id="bsfxyz";
        work_hours=3;
        hour_salary=500;
    }
};
class Adhoc_Employee: public Employee{
  public: 
  double Salary(){
      return work_hours * hour_salary;
  }
            void displayInfo(){
                cout<<"Employee Name: "<<Name<<endl;
                cout<<"Employee ID: "<<Id<<endl;
                cout<<"Working hours: "<<work_hours<<endl;
                cout<<"Total Salary: "<<Salary()<<endl;
            }
};
int main(){
    Adhoc_Employee employee;
    employee.setValues();
    employee.displayInfo();
    return 0;
}