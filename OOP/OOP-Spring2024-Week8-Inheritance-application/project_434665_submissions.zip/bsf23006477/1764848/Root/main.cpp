/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;

// Class definition for Engine
class Engine
{
private:
    string engineNumber;

public:
    Engine() {}

    Engine(string number)
    {
        engineNumber = number;
    }

    string getEngineNumber() const
    {
        return engineNumber;
    }
};

// Class definition for Passenger
class Passenger
{
private:
    string passengerName;

public:
    Passenger() {}
    Passenger(string name)
    {
        passengerName = name;
    }

    string getPassengerName()
    {
        return passengerName;
    }
};

// Class definition for Car
class Car
{
private:
    Engine carEngine;
    Passenger carPassenger;

public:
    Car(string engineNumber, string passengerName)
    {
        carEngine = Engine(engineNumber);
        carPassenger = Passenger(passengerName);
    }

    void displayDetails() 
    {
        cout << "Engine Number: " << carEngine.getEngineNumber() << endl;
        cout << "Passenger Name: " << carPassenger.getPassengerName() << endl;
    }
};

int main()
{
    Car myCar("123456", "Hamaad Afzal");

    cout << "Car Details:" << endl;
    myCar.displayDetails();

    return 0;
}