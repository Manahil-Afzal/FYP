/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/


 #include<iostream>
 using namespace std;
 class Employe{
 	protected:
 		string name;
 		string id;
 		int hours;
 		int perHourSalary;
 		public:
 			void input(){
			 
 			cout<<"Name:"<<endl;
 		    cin>>name;
 		    cout<<"ID:"<<endl;
 			cin>>id;
 			cout<<"Hours:"<<endl;
 			cin>>hours;
 			cout<<"Per hours salary:"<<endl;
 			cin>>perHourSalary;
 		}
 };
 class Adhoc_employee: public Employe{
 	public:
 		
 		int salare;
 		void salary(){
 			salare=hours*perHourSalary;
 			cout<<"salary="<<salare<<endl;
		}
		void display(){
			cout<<"NAME:"<<name<<endl;
			cout<<"ID:"<<id<<endl;
			cout<<"Hours:"<<hours<<endl;
			cout<<"Per Hoiurs Salary:"<<perHourSalary<<endl;
			cout<<"Total Salary:"<<salare<<endl;
		}
 };
 int main(){
 	Adhoc_employee e1;
 	e1.input();
 	e1.salary();
 	e1.display();
 	return 0;
 }