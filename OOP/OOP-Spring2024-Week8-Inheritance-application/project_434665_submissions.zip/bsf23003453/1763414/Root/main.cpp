/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
using namespace std;
class Employee{
	private :
		string name;
		int id;
		int working_hours;
		float salary;
		public :
		void get_data()
		{
			cout<< "please enter name of employee :"<<endl;
			cin>>name;
			cout<< "please enter ID of employee :"<<endl;
			cin>>id;
			cout<< "please enter number of working hours of employee :"<<endl;
			cin>>working_hours;
			cout<< "please enter salary per hour of employee :"<<endl;
			cin>>salary;
		}
		string nam()
		{
			return name;
		}
		int idd()
		{
			return id;
		}
		int hours()
		{
			return working_hours;
		}
		float sal()
		{
			return salary;
		}
		
};
class Adhoc_employee : public Employee{
	public :
	int  cal_salary()
	{
	   int res =	hours()*sal();
	   cout<< "salary is :"<<res<<endl;
	}
	void display()
	{
		cout<< "name of employee is :"<<nam()<<endl;
		cout<< "id of employee is :"<<idd()<<endl;
		cout<< "no of working hours of employee is :"<<hours()<<endl;
		cout<< "salary per hour of employee is :"<<sal()<<endl;
	}
};

int main()

{
	Adhoc_employee e1;
	cout<< "Enter details of employee :"<<endl;
	e1.get_data();
	cout<< "Details of employee"<<endl;
	e1.display();
	cout<< "Total salary of employee :"<<endl;
	e1.cal_salary();
	return 0;
}