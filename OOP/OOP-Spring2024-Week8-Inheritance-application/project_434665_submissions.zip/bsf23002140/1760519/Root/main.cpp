/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
using namespace std;

class Employee {
protected:
    string name;
    int id;
    int workingHours;
    double perHourSalary;

public:
    // Constructor
    Employee(const string& name, int id, int workingHours, double perHourSalary) 
        : name(name), id(id), workingHours(workingHours), perHourSalary(perHourSalary) {}

    // Virtual function to calculate salary
    virtual double salary() const {
        return workingHours * perHourSalary;
    }

    // Virtual function to display employee information
    virtual void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Working Hours: " << workingHours << endl;
        cout << "Per Hour Salary: " << perHourSalary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    // Constructor
    Adhoc_employee(const string& name, int id, int workingHours, double perHourSalary)
        : Employee(name, id, workingHours, perHourSalary) {}

    // Override salary calculation for ad-hoc employees
    double salary() const override {
        return Employee::salary(); // Salary calculation is same as base class
    }

    // Override display_info to add any additional information if needed
    void display_info() const override {
        Employee::display_info(); // Call base class display_info
        cout << "Total Salary: " << salary() << endl; // Display total salary
    }
};

int main() {
    // Creating an object of Adhoc_employee
    Adhoc_employee emp("Talha Khan", 101, 40, 20.5); // Name, ID, Working Hours, Per Hour Salary

    // Displaying employee information and salary
    cout << "Employee Information:" << endl;
    emp.display_info();

    return 0;
}

