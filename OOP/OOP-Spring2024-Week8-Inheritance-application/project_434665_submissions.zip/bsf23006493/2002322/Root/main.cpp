/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	public:
		string name;
		int id;
		double working_hrs;
		double salary_per_hr;
		void input(){
		cout<<"enter name "<<endl;
		cin>>name;
		cout<<"enter id "<<endl;
		cin>>id;
		cout<<"enter working per hours "<<endl;
		cin>>working_hrs;
		cout<<"per hour salery"<<endl;
		cin>>salary_per_hr;
	}
	
			
};
class Adhoc_employee:public Employee{
	public:
		
        double salary(){
		return working_hrs*salary_per_hr;
		
	}
	void displayInfo(){
		cout << "Employee Information:\n";
        cout << "Name: " << name << "\n";
        cout << "ID: " << id << "\n";
        cout << "Working Hours: " << working_hrs << "\n";
        cout << "Hourly Salary: " << salary_per_hr<< "\n";
    }
	
};
int main(){
	Adhoc_employee emp;
	emp.input();
	emp.displayInfo();
	cout << "Salary: " << emp.salary() << "\n";
	
	return 0;	
}
