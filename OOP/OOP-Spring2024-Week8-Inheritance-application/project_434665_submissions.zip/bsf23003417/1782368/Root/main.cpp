/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected: 
	string name;
	int id,no_of_hours,salaryhour;
	public:
	Employee(): name("Talha"), id(3), no_of_hours(5), salaryhour(8) {}
	int getid(){
		return id;
	}
	int getsalary(){
		return salaryhour;
	}
};
class Adho_employee : public Employee{
	public:
		int salary(){
			return (id*salaryhour);
		}
		void displayinfo(){
			cout<<"ID : "<<id<<endl<<"Name : "<<name<<endl<<"Working Hours : "<<no_of_hours<<endl<<"Salary Per Hour : "<<salaryhour<<endl<<"Total Salary : "<<salary();
		}
};
 
 int main(){
 	Adho_employee ap;
 	ap.salary();
 	ap.displayinfo();
 	
 }