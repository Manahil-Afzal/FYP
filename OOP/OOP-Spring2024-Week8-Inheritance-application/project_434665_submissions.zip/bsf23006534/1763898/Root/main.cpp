#include <iostream>
using namespace std;

class employee
{
protected:
    string name;
    int id;
    int workingHour;
    int perHourSalary;

public:
    employee(string Name, int ID, int wh, int pH)
    {
        name = Name;
        id = ID;
        workingHour = wh;
        perHourSalary = pH;
    };

    virtual int salary (){
        return workingHour * perHourSalary;
    };

    virtual void display_info()
    {
        cout << "The name of Employee is : " << name;
        cout << "\nThe ID of Employee is : " << id;
        cout << "\nThe Working Hour of Employee is : " << workingHour;
        cout << "\nThe Per Hour Salary of Employee is : " << perHourSalary;
        cout << endl;
    };

};

class Adhoc_employee : public employee
{
private:
    int total;

public:
    Adhoc_employee(string Name, int ID, int wh, double pH) : employee(Name, ID, wh, pH){};

    int salary (){
       return employee::salary();
    };

    void display_info(){
        employee::display_info();
        cout << "The Total Salary of employee is : " << salary();
    }
};

int main()
{
    Adhoc_employee Employe("Muhammad Umar", 121, 8, 200);

    Employe.display_info();

    return 0;
}

/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”.
The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
