#include <iostream>
#include <string>
using namespace std;

class Employee {
protected:
    string name;
    string ID;
    int Numofhours;
    int perhoursalary;
    int totalsalary;

public:
    void setname(string n) {
        name = n;
    }
    void setid(string i) {
        ID = i;
    }
    void sethours(int hours) {
        Numofhours = hours;
    }
    void setsalary(int salary) {
        perhoursalary = salary;
    }
};

class Adhoc_employee : public Employee {
public:
    int calculate() {
        totalsalary = Numofhours * perhoursalary;
        return totalsalary;
    }

    void displayInfo() {
        cout << "Employee name: " << name << endl;
        cout << "ID: " << ID << endl;
        cout << "Salary: $" << totalsalary << endl;
    }
};

int main() {
    Adhoc_employee E;
    E.setname("Shayan");
    E.setid("env32");
    E.sethours(25);
    E.setsalary(4500);
    E.calculate();
    E.displayInfo();

    return 0;
}
