/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee{
	protected:
		string name="ali",Id="231F";
		float WorkingHours=110, rate_hour=250;
};

class Adhoc_Employee:public Employee{
	public:
		float salary(){
			return WorkingHours*rate_hour;
		}

		void displayinfo(){
			cout<<"\n Name :"<<name;
			cout<<"\n ID :"<<Id;
			cout<<"\n Working Hours :"<<WorkingHours;
			cout<<"\n Total Salary :"<<salary();
		}
};

int main(){
	Adhoc_Employee obj;
	obj.displayinfo();

}