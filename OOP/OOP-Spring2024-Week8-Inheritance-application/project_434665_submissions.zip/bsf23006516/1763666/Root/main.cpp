/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee{
	protected:
		string name;
		int id;
		int nowh;
		int phs;
	public:
	void input()
	{
	cout<<"Enter Your Name: ";
	cin>>name;
	cout<<"Enter Your id: ";
	cin>>id;
	cout<<"Enter No.Of working Hours: ";
	cin>>nowh;
	cout<<"Enter Per.Hour Salary: ";
	cin>>phs;
	}			
};
class Adhoc_Employee:public Employee{
	public:
	void Salary(){
		cout<<"\nYour Salary huors: "<<nowh<<endl;
		cout<<"\nYour Salary Becomes: "<<nowh*phs<<" $"<<endl;
	}
	void display(){
		cout<<"\nName: "<<name;
		cout<<"\nYour ID: "<<id;
		Salary();
	}
};
int main(){
	Adhoc_Employee E1;
	E1.input();
	E1.display();
}