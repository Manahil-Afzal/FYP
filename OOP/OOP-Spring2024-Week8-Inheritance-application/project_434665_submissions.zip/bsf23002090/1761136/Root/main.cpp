#include<iostream>
using namespace std;
class employee{
	protected:
	string name;
	string id;
	int number_of_working_hours;
    int salary_per_hour;
    public:
    	void set_details(){
    		cout<<"enter the name of the employee"<<endl;
    		getline(cin,name);
    		cout<<"enter the ID of the employee"<<endl;
    	getline(cin,id);
    		cout<<"enter the  number_of_working_hours of the employee"<<endl;
    		cin>>number_of_working_hours;
    		cout<<"enter the salary_per_hour of the employee"<<endl;
    		cin>>salary_per_hour;
    		
		}
		void display_details(){
				cout<<" the name of the employee"<<endl;
    		cout<<name<<endl;
    		cout<<" the ID of the employee"<<endl;
    		cout<<id<<endl;
    		cout<<" the  number_of_working_hours of the employee"<<endl;
    		cout<<number_of_working_hours<<endl;
    		cout<<" the salary_per_hour of the employee"<<endl;
    		cout<<salary_per_hour<<endl;
			
		}
};
class Adhoc_employee : public employee{
	protected:
		int total_salary;
		public:
			int cal_total_salary(){
				return number_of_working_hours*salary_per_hour;
			}
			void display_salary(){
				cout<<"the total salary of the employee:"<<endl;
				cout<<cal_total_salary()<<endl;
			}
};
  
int main(){
	Adhoc_employee f2;
	f2.set_details();
	f2.display_details();

	f2.display_salary();

	
	
}