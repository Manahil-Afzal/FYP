/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

class Employee {
protected:
    std::string Name;
    int Id;
    int NumWorkingHours;
    double PerHourSalary;

public:
    Employee(std::string name, int id, int hours, double salary)
        : Name(name), Id(id), NumWorkingHours(hours), PerHourSalary(salary) {}

    virtual double salary() {
        return NumWorkingHours * PerHourSalary;
    }

    virtual void display_info() {
        std::cout << "Name: " << Name << std::endl;
        std::cout << "ID: " << Id << std::endl;
        std::cout << "Working Hours: " << NumWorkingHours << std::endl;
        std::cout << "Hourly Salary: " << PerHourSalary << std::endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(std::string name, int id, int hours, double salary)
        : Employee(name, id, hours, salary) {}

    double salary() override {
        return NumWorkingHours * PerHourSalary;
    }

    void display_info() override {
        Employee::display_info();
        std::cout << "Salary: " << salary() << std::endl;
    }
};

int main() {
    Adhoc_employee emp("John Doe", 12345, 40, 25.0);
    emp.display_info();

    return 0;
}