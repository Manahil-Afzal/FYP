/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
#include<string>
using namespace std;
class Employee{
	protected:
		string name;
		int id;
		float num_working_hour;
		float per_hour_salary;
	public:
		Employee(const string& n,const int& i,const float& num,const float& per) : name(n),id(i),num_working_hour(num),per_hour_salary(per){}
		virtual float salary(){
			return num_working_hour* per_hour_salary;
		}
		virtual void display(){
		cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << num_working_hour << endl;
        cout << "Per hour salary: $" << per_hour_salary << endl;
		}
};
class  Adhoc_employee:public Employee{
	public:
		 Adhoc_employee(string n,int i,float num,float per):Employee(n,i,num,per){
		 };
		 float salary() override {
        return num_working_hour * per_hour_salary;
    }
		 void display(){
		 	 cout << "Adhoc Employee Information" << endl;
        	 Employee::display();
       		 cout << "Total Salary: $" << salary() << endl;
		 }
};
int main()
{
	Adhoc_employee adhoc_empl("john",12345,40,20.6);
	adhoc_empl.display();
	return 0;
}