/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int num_hours;
    double per_hour_salary;
public:
    Employee(string n, int i, int nh, double phs) : name(n), id(i), num_hours(nh), per_hour_salary(phs) {}

    virtual double salary() {
        return num_hours * per_hour_salary;
    }

    virtual void display_info() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of working hours: " << num_hours << endl;
        cout << "Per hour salary: Rs" << per_hour_salary << endl;
    }
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string n, int i, int nh, double phs) : Employee(n, i, nh, phs) {}

    double salary() override {
        return num_hours * per_hour_salary;
    }

    void display_info() override {
        Employee::display_info();
        cout << "Salary: Rs" << salary() << endl;
    }
};

int main() {
    Adhoc_employee emp("Junaid Shaukat", 1234, 40, 15000); 
    emp.display_info();
    return 0;
}
