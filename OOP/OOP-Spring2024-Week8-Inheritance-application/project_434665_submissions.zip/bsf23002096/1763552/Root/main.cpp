/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int numWorkingHours;
    double perHourSalary;

public:
    // Constructor
    Employee(const string& name, int id, int numWorkingHours, double perHourSalary)
        : name(name), id(id), numWorkingHours(numWorkingHours), perHourSalary(perHourSalary) {}

    // Calculate salary
    double salary() const {
        return numWorkingHours * perHourSalary;
    }

    // Display information
    void display_info() const {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << numWorkingHours << endl;
        cout << "Per Hour Salary: $" << perHourSalary << endl;
        cout << "Total Salary: $" << salary() << endl;
    }
};

int main() {
    // Create an employee object
    Employee employee("John Doe", 1234, 40, 15.5);

    // Display information and salary
    cout << "Employee Information:" << endl;
    employee.display_info();

    return 0;
}