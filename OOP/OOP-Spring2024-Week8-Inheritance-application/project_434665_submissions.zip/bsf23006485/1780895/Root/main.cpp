/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee
{
	protected:
	string name;
	int id;
	int work_hours;
	int salary_per_hour;
	public :
   void	putdata()
	{
		cout<<"enter name = ";
			cin>>name;
			cout<<"enter id = ";
			cin>>id;
			cout<<"enter working hours = ";
			cin>>work_hours;
			cout<<"enter salary per hour is = ";
			cin>>salary_per_hour;	
	}
};
class Adhoc_Employee:public Employee
{
	public:
		int salary()
		{
			return work_hours*salary_per_hour;
		}
		void display()
		{
		cout<<"name = "<<name<<endl;
		cout<<"id = "<<id<<endl;
		cout<<"working hours = "<<work_hours<<endl;
		cout<<"salary per hour = "<<salary_per_hour<<endl;
		}
};
int main()
{
	Adhoc_Employee e1;
	e1.putdata();
	e1.display();
	cout<<"total salary is "<<e1.salary();
}