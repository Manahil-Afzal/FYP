/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include <iostream>
#include <string>
using namespace std;
class Employee {
protected:
 string name;
 int id;
 int workingHours;
 float perHourSalary;
public:
 // Constructor to initialize employee details
 Employee(string n, int i, int hours, float salary) : name(n), id(i), workingHours(hours), perHourSalary(salary) {}
 // Virtual function to be overridden by derived class
 virtual float salary() {
 return workingHours * perHourSalary;
 }
 // Virtual function to display employee information
 virtual void display_info() {
 cout << "Name: " << name << endl;
 cout << "ID: " << id << endl;
 cout << "Working Hours: " << workingHours << endl;
 cout << "Per Hour Salary: " << perHourSalary << endl;
 }
};
class Adhoc_employee : public Employee {
public:
 // Constructor to initialize Adhoc_employee
 Adhoc_employee(string n, int i, int hours, float salary) : Employee(n, i, hours, salary) {}
 // Overridden salary method to calculate salary for Adhoc_employee
 float salary() override {
 return workingHours * perHourSalary;
 }
 // Overridden display_info method to display complete information of Adhoc_employee
 void display_info() override {
 cout << "Employee Type: Adhoc" << endl;
 Employee::display_info(); // Call base class display_info method
 cout << "Salary: " << salary() << endl;
 }
};
int main() {
 // Create an object of Adhoc_employee
 Adhoc_employee emp("John Doe", 1001, 40, 20.0);
 // Display information and salary of the Adhoc_employee
 cout << "Employee Details:" << endl;
 emp.display_info();
 return 0;
}