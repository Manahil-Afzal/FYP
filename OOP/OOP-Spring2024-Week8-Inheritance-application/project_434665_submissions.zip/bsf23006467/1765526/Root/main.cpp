/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include <iostream>
#include <string>

using namespace std;

class Employee {
protected:
    string name;
    int id;
    int WHours;
    int PHSalary;

public:
    Employee(string nameE, int idE, int totalhoursE, int totalsalaryE){
        name = nameE;
        id = idE;
        WHours = totalhoursE;
        PHSalary = totalsalaryE;

    }
    
};

class Adhoc_employee : public Employee {
public:
    Adhoc_employee(string nameE, int idE, int totalhoursE, int totalsalaryE)
    : Employee(nameE,idE,totalhoursE,totalsalaryE){}

    int Cal() {
        int salary = WHours * PHSalary;
        return salary;
    }

    void displayInfo() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Number of Working Hours: " << WHours << endl;
        cout << "Per Hour Salary: " << Cal() <<" Rupees" << endl;
    }
};

int main() {
    Adhoc_employee adhoc_emp("Ahmed", 14, 30, 20);

    adhoc_emp.displayInfo();

    return 0;
}
