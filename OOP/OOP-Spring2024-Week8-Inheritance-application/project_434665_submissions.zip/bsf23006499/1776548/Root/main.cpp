/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/

#include<iostream>
using namespace std;
class Employee{
public:
	string name;
	int id;
	float hours;
	long salary;
public:
void getInput(){
	cout<<"Enter the name of employee: ";
	cin>>name;
	cout<<"Enter the id of employee: ";
	cin>>id;
	cout<<"Enter the number of working hours of employee: ";
	cin>>hours;
	cout<<"Enter the per-hour-salary of employee: ";
	cin>>salary;
}
};
class Adhoc_employee:public Employee{
	public:
	double net_salary(){
	return 	hours*salary;
	}
void display_info(){
	cout<<"\nThe name of employee is "<<name;
	cout<<"\nThe id of employee is "<<id;
	cout<<"\nThe working hours of employee is "<<hours<<"hours";
	cout<<"\nThe per-hour-salary of employee is "<<salary;
	cout<<"\nThe net salary of employee is "<<net_salary();
}
};
int main(){
	Adhoc_employee e1;
	e1.getInput();
	e1.display_info();
}