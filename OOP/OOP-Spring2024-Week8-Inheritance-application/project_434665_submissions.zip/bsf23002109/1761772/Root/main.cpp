/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;
class Employee {
protected:
string name;
int ID;
int workingHours;
double perHourSalary;
public:
    Employee(string n, int id, int hours, double salary) {
        name=n;
        ID=id;
        workingHours=hours;
        perHourSalary=salary;
}
};
class AdhocEmployee:
    public Employee{
        public:
            AdhocEmployee(string n, int id, int hours, double salary): Employee(n, id, hours, salary) {}
            double
  calculateSalary() {
        return workingHours*perHourSalary;
}
   void displayInfo() {
        cout<<"Name:"<<name<<endl;
        cout<<"ID"<<ID<<endl;
        cout<<"per Hour Salary:"<<perHourSalary<<endl;
        cout<<"Salary:"<<calculateSalary()<<endl;
    }
};
int main( ) {
    
           AdhocEmployee
           employee("Ali", 1234, 40 ,15.5);
           employee.displayInfo();
           return 0;
}
//In this program,the base class "Employee" has member variables for name, ID, workinghours and per hours salary.The derived class "AdhocEmployee" inherits from the base class and adds two methods: "calculateSalary()" to calculate the salary based on the wprking hours and per hour salary and "displayInfo()" to display th employee's informtion and salary.
//in the main function, an object of the "AdhocEmplo         
        
        