/*Write a C++ program that implements a class hierarchy having a base class named Employee and a derived class named Adhoc_employee.
The base class has data members of Name, Id, Number of working hours and Per hour salary. The derived class implements two methods
named salary and display_info. The salary method calculates the salary of employee by multiplying “Number of working hours” by “Per hour salary”. The display_info method displays
the complete information of employee. Create an object of Adhoc_employee and display the information and salary against that instance.*/
#include<iostream>
using namespace std;

class Employee{
    protected:
        string name;
        string id;
        float hours;
        int salary_pr;
    public:
        void Input(){
            cout<<"Enter name : ";
            getline(cin, name);
            cout<<"Enter Id : ";
            getline(cin, id);
            cout<<"Enter working hours : ";
            cin>>hours;
            cout<<"Enter salary per hour : ";
            cin>>salary_pr;
            cin.ignore();
        }
};
class Adhoc_employee : public Employee{
    private:
        int Totalsal;
    public:
        void Salary(){
            Totalsal = hours*salary_pr;
        }
        void Display_Info(){
            cout<<"Name : "<<name<<endl;
            cout<<"Id : "<<id<<endl;
            cout<<"No. of hours you worked : "<<hours<<"h"<<endl;
            cout<<"Salary per hour : "<<salary_pr<<"Rs"<<endl<<endl;
            cout<<"Your total salary today is : "<<Totalsal<<"Rs"<<endl;
        }
};

int main(){
    Adhoc_employee a;
    a.Input();
    a.Salary();
    a.Display_Info();

    return 0;
}