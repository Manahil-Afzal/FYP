#include<iostream>
using namespace std;
// class of loan 
class loan{
    private:
    // class loan attributes
    int noOfLoanCustomers;
    int loanId;
    public:
    // class loan methods
    void set_noOfLoanCustomers();
    void set_loanId();
    int get_noOfLoanCustomers();
    int get_loanId();
};