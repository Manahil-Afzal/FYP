#include<iostream>
using namespace std;

// class of account
class account{
    protected:
    // class account attributes
    int totalNoOfAccounts;
    int noOfSavingAccounts;
    int noOfCurrentAccounts;
   
    public:
    // class  account methods
    void set_totalNoOfAccounts();
    void set_noOfSavingAccounts();
    void set_noOfCurrentAccounts();
    int get_noOfSavingAccounts();
    int get_noOfCurrentAccounts();
    int get_totalNoOfAccounts();
   
};