#include"account.h"
 #include"currentAccount.h"
 #include<iostream> 
 using namespace std;

 void currentAccount::showData()
    {
        cout<<"Total number of current accounts are : "<<noOfCurrentAccounts<<endl;
        
    }
