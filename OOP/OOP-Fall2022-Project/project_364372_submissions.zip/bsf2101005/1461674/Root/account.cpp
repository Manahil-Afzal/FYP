#include"account.h"
#include<iostream>
using namespace std;
// class  account methods
    void account::set_totalNoOfAccounts()
    {   cout << "Enter total numberr Of Accounts :" << endl;
        cin >> totalNoOfAccounts;
    }
    void account::set_noOfSavingAccounts()
{
    cout << "Enter number of saving accounts :" << endl;
    cin  >> noOfSavingAccounts;
}
void account::set_noOfCurrentAccounts()
    {
    cout << "Enter number of Current accounts :" << endl;
    cin  >> noOfCurrentAccounts;
    }
   
    int account::get_noOfSavingAccounts()
{
	cout<<"the saving accounts are"<< noOfSavingAccounts<<endl;
}
int account::get_noOfCurrentAccounts()
{
    cout<<"the current accounts are"<<noOfCurrentAccounts<<endl;
}
   int account::get_totalNoOfAccounts()
    {
        return totalNoOfAccounts;
    }
    
   