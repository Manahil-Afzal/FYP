#include"transaction.h"
#include<iostream>
using namespace std;
int transaction:: get_transactionProcess()
    {
       cout << "type your Transaction Type: ";
    cin >> transactionType;
    if(transactionType=="withdraw"){
        cout << "Type withdraw amount :";
        cin>>withdrawAmount;
        cout<<"enter total balance"<<endl;
        cin>>totalBalance;
   currentBalance = totalBalance - withdrawAmount;
   cout<<"the current balance is:"<<currentBalance<<endl;
    }
    else if (transactionType=="deposit"){
         cout << "Type deposit amount :";
         cin>>depositAmount;
         cout<<"enter total balance"<<endl;
        cin>>totalBalance;
        currentBalance =totalBalance + depositAmount;
        cout<<"the current balance is:"<<currentBalance<<endl;
     
}
return 0;
}