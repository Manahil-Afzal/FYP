#include<iostream>
using namespace std;

 class savingAccounts:public account{
        public:
        	int noOfSavingAccounts;
       // class savingAccount method
        void getData();
    };