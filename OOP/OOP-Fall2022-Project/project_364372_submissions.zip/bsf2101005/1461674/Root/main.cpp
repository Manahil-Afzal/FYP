/*Group Members:
Malaika Munir      Roll no:bsf2100918
Tehreem Shahzadi   Roll no:bsf2101005
Fiza Wakeel        Roll no:bsf2100916
Nimra Mumtaz       Roll no:bsf2100842
Problem Statement:
Create a class of bank. The data members of bank include bank IBAN number. Create the class of account which keeps the
data of no total number of accounts including saving and current account. There are two types of accounts current
accounts and saving accounts. Create a class of saving account and its data members include no of customers who have
saving account in bank. Create another class of current account and its data members include no of customers who have
current account in bank. Create the class of customer and its data members include customer name, account number and
account type. Create another class of branch and its data members include branch id, branch name and address of
branch.Create class of transaction. In this class we make transaction process according to the demand of the user. 
Create another class of loan and its data members include no of customers who have taken loan from bank, loan id, loan 
type and loan amount. Create composition relationship of account, customer ,branch and transaction with the bank.
Create aggregation relationship of loan with bank. Make inheritance relationship of current and saving account with
account class. Show all specific attributes of all classes in bank class because bank is main class by using
relationship. It depends on you that you set data members yourself or you take from user.
*/
#include"account.h"
#include"customer.h"
#include"branch.h"
#include"loan.h"
#include"transaction.h"
#include"bank.h"
#include"savingAccount.h"
#include"currentAccount.h"
#include<iostream>
using namespace std;

int main()
{
	   
    bank B1;
    B1.show();
    loan loan2;
    bank B2(loan2);
     B2.get();
    savingAccounts S1;
    S1.set_noOfSavingAccounts();
    S1.get_noOfSavingAccounts();
    currentAccount C1;
    C1.set_noOfCurrentAccounts();
    C1.get_noOfCurrentAccounts();
    
    
    return 0;
}