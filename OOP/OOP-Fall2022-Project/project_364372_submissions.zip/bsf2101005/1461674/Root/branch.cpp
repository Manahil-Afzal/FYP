#include"branch.h"
 #include<iostream>
 using namespace std;
 // class branch methods
    void branch::set_branchId()
    {
       cout << "Enter branch Id :" << endl;
       cin >> branchId;
    }
    void branch::set_branchName()
    {
       cout << "Enter branch name : " << endl;
       cin >> branchName;
    }
    int branch::get_branchId()
    {
        return branchId;
    }
    string branch::get_branchName()
    {
        return branchName;
    }