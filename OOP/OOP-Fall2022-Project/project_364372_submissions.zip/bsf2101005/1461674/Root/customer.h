#include<iostream>
using namespace std;
// class of customer 
    class customer{
    private:
    // class customer attributes
    string customerName;
    long accountNumber;
    public:
    // class customer methods
    void set_customerName();
    void set_accountNumber();
    string get_customerName();
    int get_accountNumber();
	};