#include<iostream>
using namespace std;
// class of branch 
class branch{
    private:
    // class branch attributes
    int branchId;
    string branchName;
    public:
    // class branch methods
    void set_branchId();
    void set_branchName();
    int get_branchId();
    string get_branchName();
};