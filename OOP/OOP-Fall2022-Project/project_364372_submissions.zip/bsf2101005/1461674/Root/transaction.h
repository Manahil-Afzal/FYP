#include<iostream>
using namespace std;
class transaction{
    private:
    	int totalBalance;
    int withdrawAmount;
    int depositAmount;
    int currentBalance;
    string transactionType;
    public:
    int get_transactionProcess();
};