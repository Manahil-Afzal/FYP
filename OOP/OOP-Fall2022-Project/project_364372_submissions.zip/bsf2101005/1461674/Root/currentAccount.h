#include<iostream>
using namespace std;


class currentAccount:public account{
    public:
    	int noOfCurrentAccounts;
    // class currentAccount method
    void showData();
};
    