#include"loan.h"
#include<iostream>
using namespace std;

// class loan methods
    void loan::set_noOfLoanCustomers()
    { 
        cout << "Enter number of loan customers: " << endl;
        cin >> noOfLoanCustomers;
    }
    void loan::set_loanId()
    {
        cout << "Enter loan id:" << endl;
        cin >> loanId;
    }
    int loan::get_noOfLoanCustomers(){
        return noOfLoanCustomers;
    }
    int loan::get_loanId()
    {
        return loanId;
    }