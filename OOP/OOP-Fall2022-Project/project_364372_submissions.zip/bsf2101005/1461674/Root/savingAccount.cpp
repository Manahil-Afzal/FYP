#include"account.h"
#include"savingAccount.h"
#include<iostream>
using namespace std;

 void savingAccounts::getData()
        {
        
            cout<<"Total number of saving accounts are :"<<noOfSavingAccounts<<endl;
           
            
        }