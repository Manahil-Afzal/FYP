#include"customer.h"
#include<iostream>
using namespace std;
 void customer::set_customerName()
    {
        cout << "Enter customer name :" << endl;
        cin >> customerName;
    }
    void customer::set_accountNumber()
    {
        cout << "Enter account Number of customer :" << endl;
        cin >> accountNumber;
    }
    string customer::get_customerName()
    {
        return customerName;
    }
    int customer::get_accountNumber()
    {
        return accountNumber;
    }