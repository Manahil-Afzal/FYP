
#include<iostream>
using namespace std;
 class bank{
    private:
    // class bank attributes
    int IBAN;
    account Account;
    customer Customer;
    branch Branch;
    loan *Loan;
    transaction Transaction;
    public:
    bank();
    bank(loan loan1);
    void get();
    void show();
 };