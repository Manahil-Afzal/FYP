#include"account.h"
#include"customer.h"
#include"branch.h"
#include"loan.h"
#include"transaction.h"
#include"bank.h"
#include<iostream>
using namespace std;
 bank::bank(){
        cout << "Enter IBAN :";
        cin >> IBAN;
        Account.set_totalNoOfAccounts();
        Customer.set_customerName();
        Customer.set_accountNumber();
        Branch.set_branchId();
        Branch.set_branchName();
       
    }
    bank::bank(loan loan1)
    {
        Loan=&loan1;
        Loan->set_noOfLoanCustomers();
        Loan->set_loanId();
    }
        void bank::get()
        {
        cout<<"Number of loan customers are : "<<Loan->get_noOfLoanCustomers()<<endl;
        cout<<"The loan id is : "<<Loan->get_loanId()<<endl;
        }
      
    void bank::show()
    {
        cout<<"The Bank IBAN is :"<<IBAN<<endl;
        cout<<"Total no of accounts are : "<<Account.get_totalNoOfAccounts()<<endl;
        cout<<"the customer name is : "<<Customer.get_customerName()<<endl;
        cout<<"The customer account number is : "<<Customer.get_accountNumber()<<endl;
        cout<<"The branch id is : "<<Branch.get_branchId()<<endl;
        cout<<"The Branch name is : "<<Branch.get_branchName()<<endl;
        cout<<Transaction.get_transactionProcess()<<endl;
        
        
        
    }



  