#include<iostream>
#include<string>
using namespace std;
//Class of User
class user{												//user is inhertited from hostel
		public:							
		string name,address, email;								 //Variable declaration
		int id;
		double phn_no;
		
		void input();
		void output();
	    void user1();													//Constructor
		void show_Hos();
	};