#include"Allotte.h"
#include<iostream>
#include<string>
using namespace std;
//Class of Allotte
																											//Composite Relation of user with allotte
 void Allotte:: inp_type(){																						//method of input
   cout<<"Enter the data for Allocation:-"<<endl; 														
						cout<<"\n\t\tEnter the floor no: ";
			        	cin>>floor_no;
			        	cout<<"\n\t\tEnter the Room no: ";
			        	cin>>room_no;
				}
   void Allotte ::out_type(){																					//Method of output
						cout<<"\n\t\tFloor of floor no: "<<floor_no<<endl;
						cout<<"\n\t\tFloor of room no: "<<room_no<<endl;
				}
				
