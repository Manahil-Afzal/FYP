#include<iostream>
#include<string>
using namespace std;
//Class of Staff
class Staff{
	public:
		int st_id[50], n;                                                          //Variable declaration
		string st_name[50], activity[50];   
		
			void setvalues();													//input method
			void getvalues();													//Display method
		};