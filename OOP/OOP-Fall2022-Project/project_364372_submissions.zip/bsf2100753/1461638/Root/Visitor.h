#include<iostream>
#include<string>
using namespace std;
//Class of Visitor
class Visitor{
public:
    string name,cnic,V_phnno;																	//Varaible decleratiom
						
     void datavisitor();																		//input method
     void datadisplay();																		//display method
 };