#include"Authentication.h"
#include<iostream>

using namespace std;
//Class of Authentication

		void Authentication :: set_login(){                                                      //Method to input values
		     	cout<<"\n\n\t\t\t\tEnter the Login id: ";
		     	cin>>login_id;
		     	cout<<"\n\t\t\t\tEnter the password for login: ";
		     	cin>>login_pass;
		     			 }	
			 
		void Authentication :: show_student(){													//Method of Display
			 	cout<<"\n\t\tDisplaying Login Information:- "<<endl;
			 	cout<<"\t\t\tUser Login id: "<<login_id<<endl;
			 	cout<<"\t\t\tUser Login password: "<<login_pass<<endl;
			 }
