#include<iostream>
#include<string>
using namespace std;
//Class of Allotte
class Allotte{
private:							
    int room_no,floor_no;												 //Variable declaration
    public:
    	 void inp_type();												//Method of input
    	void out_type();												//Method of output

};
    
  