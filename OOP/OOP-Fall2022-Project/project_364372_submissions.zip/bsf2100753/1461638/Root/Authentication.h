#include<iostream>
#include<string>
using namespace std;
//Class of Authentication
class Authentication{
	public:
	     int login_id;
		 string login_pass;                                                  //Variable declaration
		  
		     void set_login();												//Method of input
		      void show_student();											//Method of display
		  };