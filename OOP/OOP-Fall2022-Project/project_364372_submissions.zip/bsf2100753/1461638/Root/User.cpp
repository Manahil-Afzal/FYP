#include"User.h"
#include"Allotte.h"
#include"Hostel.h"
#include<iostream>

using namespace std;
//Class of User

		Allotte allotte;										//object of allotte
		hostel h1;												//object of hostel
	
		
		void user :: input(){				     						//method of input
		                    cout<<endl;
			       			cout<<"\n\t\tEnter the name of Student: ";
			       			cin>>name;
			       			cout<<"\n\t\tEnter the address: ";
			       			cin>>address;
			       			cout<<"\n\t\tEnter the email: ";
			       			cin>>email;
			       			cout<<"\n\t\tEnter your ID: ";
			       			cin>>id;
			       			cout<<"\n\t\t Enter your phone no: ";
			       			cin>>phn_no;
			       			cout<<endl;
			       			cout<<endl;
		           			allotte.inp_type();								//Composite Relation of user with allotte
		}
		  void user:: output(){										
			     			cout<<"\n\t\tName of Student: "<<name<<endl;
			     			cout<<"\n\t\tAddress of Student: "<<address<<endl;
		         			cout<<"\n\t\tEmail of Student: "<<email<<endl;
			     			cout<<"\n\t\tID of Student :"<<id<<endl;
			     			cout<<"\n\t\tPhone number of Student :"<<phn_no<<endl;
		         			allotte.out_type();									//Composite Relation of user with allotte
		}
			
			void user :: user1(){                                         								//constructor
			h1.setname("UE GIRLS HOSTEL");
			h1.setaddress("UE Township Campus");
			
		}	
			void user :: show_Hos(){
			cout<<endl<<"\t\t\t\tName of hostel: "<<h1.getname()<<endl;
			cout<<endl<<"\t\t\t\tAddress of hostel: "<<h1.getaddress()<<endl;
		}		
	