// Name      Zainab Rafique(bsf2101359)
//Name:                AliRaza(bsf2100807)        
//Name:            DanishMehboob(bsf2100753)
//Name:           M.Abdullah(bsf2000873)
//Name:             WaqasAshraf(bsf2100981)
//Topic:           Hostel Management System Project


//For the hostel management system project:
/*●	Create a class of Login that includes its data members(Login ID ,User password). 
●	Create a class of hostel that includes its data members(Hostel name, Address of hostel)
●	Create a class of student data which includes its data members( Name ,Address, Email, ID, Phone number)
●	Create a class of Allottee (Room no. , floor).
●	Create a class of Payment( payment amount, pay date).
●	Create a class of staff member that includes its data members(No of staff members, Name of staff members, Id of staff members, Activity of staff members)
●	Create a class of Mess(time, menu).
●	Create a class of Visitor that includes its data members(Name, CNIC number, phone number)
●	Display the information of the data members of all classes
●	Create Composition relation of mess with hostel.
●	Create Composition relation of student data with allootte
●	Create Inheritance from hostel to user 
●	Create Inheritance from user to payment.*/

#include"Authentication.h"
#include"Mess.h"
#include"Hostel.h"
#include"Allotte.h"
#include"User.h"
#include"Payment.h"
#include"Staff.h"
#include"Visitor.h"
int main(){
	int a[7], x, z;
	cout<<"\n\n\t\t\t\t<Login to create an account>"<<endl;
	cout<<"\n\t\t-------------------------------------------------------"<<endl;
	
	//Getting Data from User
	
	Authentication Student;
	   cout<<"\n\t\tEnter Login data:-   "<<endl;
	   Student.set_login();
	   hostel h1;
	   h1.dis_hos();
	    user u1;
	    u1.user1();
	    u1.show_Hos();
	    cout<<"\nEnter Student data:-"<<endl;
	   u1.input();
	   payment p1;
	   cout<<"\n\tEnter Payment data:-"<<endl;
	   p1.data();
	   Allotte A1;
       Staff St;    
  	    cout<<"\n\tEnter Staff data:-"<<endl;
  	    St.setvalues();	  
  	   h1.inp_hos();
  	   Visitor V1;
  	   cout<<"\n\tEnter  Visitor data:-"<<endl;
  	   V1.datavisitor();
	cout<<"\n\t\t-------------------------------------------------------"<<endl;  	  
  	   //Displaying Information  
		
		cout<<"\n\nHow many informations you want to display enter the digit from 1-7: ";
        cin>>z;
  	    cout<<"\n\tEnter the numbers whom information you want to display:-"<<endl;
  	    
  	    cout<<"\n\tPress 1 to display Student information "<<
  	    "\n\tPress 2 to display Payment information "<<
  	    "\n\tPress 3 to display Room Allocation information "<<
  	    "\n\tPress 4 to display Visitor information "<<
  	    "\n\tPress 5 to display Staff's information "<<
        "\n\tPress 6 to display Mess information "<<
        "\n\tPress 7 to display Login information "<<endl;
        for(x=1; x<=z; x++){
  	          cout<<"\n\t\tEnter "<<x<<" number: ";
  	          cin>>a[x];
		  }	
		
		for(x=1; x<=z; x++){  
	    if(a[x]==1){
  	     u1.output();
		  }
		if(a[x]==2){
		cout<<"Name of user: "<<u1.name<<endl;
	     p1.out_data();	
		}  
		if(a[x]==3){
				A1.out_type();
		}
		if(a[x]==4){
		  V1.datadisplay();	
		}
		if(a[x]==5){
			St.getvalues();
		}
        if(a[x]==6){
        	h1.out_hos();
		}
		if(a[x]==7){
			Student.show_student();
		}
	}}