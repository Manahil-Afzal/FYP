#include<iostream>
#include<string>
using namespace std;
//Class of Payment
class payment {											//inhertited from user
	public:
	
	int  y,R;
    string	D;															 //Variable declaration
    void data();
    void out_data();
};