#include"Mess.h"
#include<iostream>

using namespace std;
//Class of Mess
		void Mess :: inp_mess(){	
 																									//Composite Relation of mess with hostel
   cout<<"Enter the data for Mess:-"<<endl; 														//Method of input
						cout<<"\n\t\tEnter the morning time: ";
			        	cin>>morningtime;
			        	cout<<"\n\t\tEnter the evening time: ";
			        	cin>>eveningtime;
			        	cout<<"\n\t\tEnter the menu: ";
			        	cin>>items;
				}
   void Mess :: out_type(){																					//Method of display
						cout<<"\n\t\tMoring Time : "<<morningtime<<endl;
						cout<<"\n\t\tEvening Time: "<<eveningtime<<endl;
						cout<<"\n\t\tMenu : "<<items;
				}   
