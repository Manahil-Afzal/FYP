#include"Visitor.h"
#include<iostream>

using namespace std;
//Class of Visitor

							
     void Visitor:: datavisitor(){				
		   cout<<endl;																			//Method to input values
			cout<<"\n\t\tEnter the name of visitor :";
			cin>>name;
			cout<<"\n\t\tEnter the CNIC NUMBER: ";
			cin>>cnic;
			cout<<"\n\t\tEnter the phone number :";
			cin>>V_phnno;
}
     void Visitor:: datadisplay(){																	//Method of output
						cout<<"\n\t\tName of visitor: "<<name<<endl;
						cout<<"\n\t\tCNIC number: "<<cnic<<endl;
						cout<<"\n\t\tEnterthe phone number: "<<V_phnno<<endl;
				}
				


