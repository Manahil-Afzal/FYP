#include"Hostel.h"
#include"Mess.h"
#include"User.h"
#include<iostream>

using namespace std;
//Class of Hostel
        Mess mess;																				//object of Mess
		void hostel :: inp_hos(){																//Composite relation
		mess.inp_mess();}
		void hostel :: out_hos(){
		mess.out_type();
	}
	void hostel :: dis_hos(){																	//Method for display																							
	cout<<"\n\t\t\t  \3\3\3 WELCOME TO UE GIRLS HOSTEL \3\3\3 "<<endl;
	cout<<"\n\t\t----------------------------------------------------------------"<<endl;}
	  void hostel :: setname(string name1){																//Paramatrized Constructor
			    	name = name1;
				}
				void hostel :: setaddress(string add){
					address = add;
				}
				string hostel:: getname(){
					return name;
				}
				string hostel :: getaddress(){
					return address;
				}
			