#include<iostream>
#include<string>
using namespace std;
//Class of Hostel
class hostel{
		public:
		string name,address;													 //Variable declaration
		
		void inp_hos();															//Method of input //composite relation of messwith hostel
		void out_hos();															//Method of output
		void dis_hos();															//Method of display
		void setname(string name1);
		void setaddress(string add);
		string getname();
		string getaddress();
	};