#include"Staff.h"
#include<iostream>

using namespace std;
//Class of staff

		void Staff:: setvalues(){                                                  //Method to input values
				cout<<"\n\n\t\t\tEnter the no. staff members: "; 
				cin>>n;
				
				for(int i=0; i<n; i++){
				cout<<"\n\t\t\tEnter the name of the staff member: ";
				cin>>st_name[i];
				cout<<"\t\t\tEnter the id of staff member: ";
				cin>>st_id[i];
				cout<<"\t\t\tEnter the activity of the staff member: ";
				cin>>activity[i];
				}
			}
			
			void Staff :: getvalues(){												//Method of output
					for(int i=0; i<n; i++){
				cout<<"\n\t\tDisplaying Staff's' Information:- "<<endl;
				cout<<"\t\t\tName of staff member: "<<st_name[i]<<endl;
				cout<<"\t\t\tID of staff member: "<<st_id[i]<<endl;
				cout<<"\t\t\tActivity of staff member: "<<activity[i]<<endl;
				}
			}
