#include"Payment.h"
#include"User.h"
#include<iostream>

using namespace std;
//Class of Payment

	user user1;																					//object of user
	
           void payment :: data(){				
		   cout<<endl;																			//Method to input values
			cout<<"\n\t\tEnter the amount of Payment :";
			cin>>y;
			cout<<"\n\t\tEnter the Date of Paying Bill: ";
			cin>>D;
}
           void payment :: out_data(){															//method for display
           		cout<<"\n\t\tThe amount you Paid :"<<y<<endl;
			cout<<"\n\t\tPaying Bill date:"<<D<<endl;
			if (y==10000){																		//if/else statement
				cout<<"\n\t\tThank you Your Payment was submitted";}	
			else{
			
			R=10000-y;
			cout<<"\n\t\tYour remaing balance is :"<<R<<endl;}
		
		}
