#include<iostream>
#include<string>
using namespace std;
//Class of Mess
class Mess{	        										 
public:
   string morningtime,eveningtime, items;													//Variable declaration											
    	
		 void d(string m,string e , string i){
   
        morningtime= m;
        eveningtime=e;
        items= i;
        
    }																							//Composite Relation of mess with hostel
 void inp_mess();																				//Method of input
 void out_type();																				//Method of display
};
 