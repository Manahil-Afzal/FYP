#ifndef LIBRARY_H
#define LIBRARY_H
#include "Student.h"
#include "catalog_user.h"
#include "HelpdeskUser.h"
#include "Librarian.h"
#include "Administrator.h"

class Library : public Student,catalog_user,HelpdeskUser,Librarian,Administrator  //Student,catalog_user,HelpdeskUser,Librarian and Administrator are inherate
{
	public:
	void catalog_User();//FOR CATALOG USER
	void help_desk_user();//FOR HELP DESK USER
	void Librarian_Fun();//FOR LIBRARIAN
	void Administrator_LIB();// FOR ADMINISTRATOR
};

#endif