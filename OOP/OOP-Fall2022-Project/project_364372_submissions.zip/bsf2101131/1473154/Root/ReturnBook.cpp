//ReturnBook class contain all the history of Return book data
#include "ReturnBook.h"
#include<iostream>
#include<fstream>
#include<stdio.h>
#include<iomanip>
using namespace std;
void ReturnBook::return_book_data(){ // return_book_data():create the record of Return books
	  string  Sid,Sname,Dep,Pro,Shift,IssueBId,Bname,Date,RetuenD,status;

	f:
			
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tRETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Student ID"<<endl;
				cin>>Sid;
				cout<<"Student Name"<<endl;
				cin>>Sname;
				cout<<"Department"<<endl;
				cin>>Dep;
				cout<<"Program"<<endl;
				cin>>Pro;
				cout<<"Shift"<<endl;
				cin>> Shift;
				cout<<"Return Book/General/Theses ID"<<endl;
				cin>>IssueBId;
				cout<<"Book/General/Theses  Name"<<endl;
				cin>>Bname;
				cout<<"Return Date (DD/MM/YYY)"<<endl;
				cin>>RetuenD;
				cout<<"Status"<<endl;
				cin>>status;
				ofstream returnbook;
				returnbook.open("Returnbook.txt",ios::app);
				returnbook<<setw(12)<<left<<Sid<<setw(20)<<left<<Sname<<setw(20)<<left<<Dep<<setw(20)<<left<<Pro<<setw(20)<<left<<Shift<<setw(20)<<left<<IssueBId<<setw(20)<<left<<Bname<<setw(20)<<left<<RetuenD<<setw(20)<<left<<status<<endl;
				returnbook.close();
				cout<<"Press 0 To Continue Inserted Fine Record "<<endl;
				cout<<"Press 2 and Enter To Show Back  Menue Stuff "<<endl;
				int h;
				cin>>h;
				if(h==0){
					goto f;
				}
			}
				void ReturnBook::view_return_book(){// view_return_book(): display all the record of Return book data;
					
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tVIEW RETURN BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				 char display[1000];
			     ifstream returnbook;
		     	returnbook.open("Returnbook.txt",ios::app);
		    	while(!returnbook.eof()){
				returnbook.getline(display,1000);
			
				cout<<display<<endl;
			}
		}
						
			
	void ReturnBook::search_return_book(){ // search_return_book():use to search specific  fine record of the student
		
		int n;
            cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    cin>>n;
   
if(n==1){

    int offset;
    std::string s_id, line;
    ifstream filee;
    filee.open("Returnbook.txt"); //file creation 
    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\nType The Student/Book ID To Rearch Record:"<<endl;
    cin >>s_id;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_id, 0))) != string::npos)
            {
            	
            	 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSTUDENT/BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"StudentID   Student Name      Department           Program              Shift            ReturnBookID           Return_Book_Name    Return Date         Status"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
    }
    
        
}
else if(n==2){
	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("IssuesBooks.txt");
    cout << "\nType The Student/Book Name To Search Record:"<<endl;
    cin >> s_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_name, 0))) != string::npos)
            {
            	 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSTUDENT/BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                 cout<<"StudentID   Student Name      Department           Program              Shift            ReturnBookID           Return_Book_Name    Return Date         Status"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        
        }
        filee.close();
       
    }
    
}


	} 