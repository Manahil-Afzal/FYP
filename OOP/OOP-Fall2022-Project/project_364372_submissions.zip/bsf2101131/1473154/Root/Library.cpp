//The library Class contain the all feature of libray.In which Student,catalog_user,HelpdeskUser,Librarian and Administrator are inherate
#include<iostream>
#include<stdio.h>
#include<fstream>
#include "Library.h"
#include "Student.h"
#include "catalog_user.h"
#include "HelpdeskUser.h"
#include "Librarian.h"
#include "Administrator.h"
	void Library ::catalog_User(){ //FOR CATALOG USER
		catalog();//This function calling from catalog_user class
	
		}
		void Library :: help_desk_user(){//FOR HELP DESK USER
			help_desk_Fun();//This function calling from HelpdeskUser class
			
		}
		void Library ::Librarian_Fun(){ //FOR LIBRARIAN
		librarian_fun();//This function calling from Librarian class
		}
		void Library::Administrator_LIB(){// FOR ADMINISTRATOR
		Administrator_fun();//This function calling from Administrator class
	}