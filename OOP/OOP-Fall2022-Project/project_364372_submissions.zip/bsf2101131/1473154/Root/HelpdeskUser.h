#ifndef HELPDESKUSER_H
#define HELPDESKUSER_H
#include "IssueBook.h"
#include "ReturnBook.h"
#include "Fines.h"

class HelpdeskUser : public IssueBook,ReturnBook,Fines
{
	public:
	void help_desk_Fun();

};

#endif