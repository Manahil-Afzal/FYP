#include "Books.h"
#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;
//the book class contain three function named insertbook(), seebook() and searching() which store ,view and search book data
 void Books::insertbook(){ //insertbook() Store book record;
	    	m1:
	    	
	    	
	    	 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	    	cout<<"HERE YOU INSERT NEW BOOK RECORD"<<endl;
	    	int no;
	    	cout<<"\t\t\t\t\tEnter Book ID:"<<endl;
	        cin>>bookid;
	    	cout<<"\t\t\t\t\tEnter Book Name:"<<endl;
	    	cin>>bookname;
	    	cout<<"\t\t\t\t\tEnter Book Author Name:"<<endl;
	    	cin>>authername;
	    	cout<<"\t\t\t\t\tEnter Book Edition:"<<endl;
	    	cin>>edition;
	    	cout<<"\t\t\t\t\tEnter  Materialtype:"<<endl;
	    	cin>>Materialtype;
	    	cout<<"\t\t\t\t\tEnter Publish Detail:"<<endl;
	    	cin>>publisher;
	    	cout<<"\t\t\t\t\tEnter Rack No.:"<<endl;
	    	cin>>RackNo;
	    	cout<<"\t\t\t\t\tEnter Book Shelf:"<<endl;
	    	cin>>shelfno;
	    	cout<<"\t\t\t\t\tNew Book Record Inserted "<<endl;

	    		ofstream file; //file hundling object for  Writing data
	    		file.open("Bookdata.txt",ios::app);//file cretion 
	    		file<<setw(10)<<left<<bookid<<setw(20)<<left<<bookname<<setw(20)<<left<<authername<<setw(20)<<left<<edition<<setw(20)<<left<<Materialtype<<setw(20)<<left<<publisher<<setw(20)<<left<<RackNo<<setw(20)<<left<<shelfno<<endl;
	    		file.close();
	    		int y;
	    		cout<<"If You Enter The Another Book Record Then Press 1 "<<endl;
	    		cout<<"Otherwise Press 2  And Enter  To Back.........."<<endl;
	    		cin>>y;
	    		if(y==1){
	    		goto m1;
	    		}
		}
		void Books::seebook(){ //seebook() display all book record
			
			 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tALL BOOK DETAIL"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			 char display[1000];
			ifstream output; //file hundling object for  Reading data
			output.open("Bookdata.txt");
			while(!output.eof()){
				output.getline(display,1000);
				cout<<display<<endl;
				 
			}
		}
void Books::searching() //searching() search the book record
{
int n;

s:
     cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH BOOK DETAIL"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"Chose one of these option"<<endl;
			cout<<"Note-: If You Enter The Wrong Choice Then You are Return On Option Again  "<<endl;
			  cout<<endl;
    cout<<"\t\t\t\t\t\t\t\t1).Search By ID"<<endl;
    cout<<endl;
    cout<<"\t\t\t\t\t\t\t\t2).Search By Name"<<endl;
    cin>>n;
if(n==1){
	
    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH BOOK DETAIL"<<endl;
			cout<<endl;
	cout<<"************************************************************************************************************************************************************************"<<endl;
	
    int offset;
    std::string book_id, line;
    ifstream filee;
    filee.open("Bookdata.txt");
    cout << "\nType The Book ID to Search Book:"<<endl;
    cin >>book_id;
    if (filee.is_open())//FOR OPENING FILE
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(book_id, 0))) != string::npos) //FOR SEARCHING RECORD FROM FILE
            {
            	cout<<"BookID           Book Name	     Author Name	Edition	             Material	         Publish Detail     Rack No	      Shelf No "<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
           
            
        }
        filee.close();//CLOSING FILE
    }

   
   
}
else if(n==2){
	
	 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH BOOK DETAIL"<<endl;
			cout<<endl;
	 cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string  book_name, line;
    ifstream filee;
    filee.open("Bookdata.txt");
    cout << "\nType The Book Name To Search Book:"<<endl;
    cin >> book_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find( book_name, 0))) != string::npos)
            {
        
         	    cout<<"BookID"<<"\t\t"<<"Book Name"<<"\t\t"<<"Author"<<"\t\t"<<"Edition"<<"\t\t"<<"Material Type"<<"\t\t"<<"Publish Detail"<<"\t\t"<<"Rack.No"<<"\t\t"<<"Shelf No"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
            
 
        }
        filee.close();
       
    }
}
else {
	
	goto s;
	
}

}
