#ifndef ISSUEBOOK_H
#define ISSUEBOOK_H
#include<string>
using namespace std;
class IssueBook
{
	   
	    public:
	    void issue_book();
	    void view_issue_book();
	    void search_Issue_book();
	
};

#endif