#ifndef STAFF_H
#define STAFF_H
class Staff
{
	
public:
void GetEmployeeData();
void viewstaff();
void searchstaff();
};

#endif