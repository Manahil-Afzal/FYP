
#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
#include "Staff.h" 
#include "Librarian_Access.h"
class Administrator : public Staff, Librarian_Access  //  staff and librain Access classes are inherated in administrator class
{
	public:
	void Administrator_fun();// For Administrator menues
};

#endif