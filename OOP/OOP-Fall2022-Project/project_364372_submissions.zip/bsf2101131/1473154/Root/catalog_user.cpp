//catalog_user class:in which catalog user Update,View,and Search Book Record
#include "catalog_user.h"
#include<iostream>
#include<stdio.h>
using namespace std;
void catalog_user:: catalog(){//contain the menues of catalog user;
		l:
			
            
		   cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tCATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		    cout<<"Please Select The Following Option:"<<endl;
		    cout<<endl;
		    cout<<"Note:-IF You Enter Wrong Choice Then Yor Are Return On The Option:"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t1).Add New Book  Record/Update"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t2).View Book/General/Theses"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t3).Search Book/General/Theses"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t4).Logout"<<endl;
		    int j;
		    cin>>j;
		    if(j==1){
		    insertbook();	//calling from Books class
			}
			else if(j==2){
            seebook();	//calling from Books class			
			}
			else if(j==3){
			searching();//calling from Books class	
			}
			else if(j==4){ // exit system code
				 
                   	
		         	
		         	cout<<"THANKS  FOR USING LIBRARY MANAGMENT SYSTEM"<<endl;
		         						
			}
			else{
				goto l;
				
			}
		   
           
			}
