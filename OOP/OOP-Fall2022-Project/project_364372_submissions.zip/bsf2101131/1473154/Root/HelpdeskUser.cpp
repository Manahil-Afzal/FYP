//HelpdeskUser class contain the responsibility of Help desk User.IssueBook,ReturnBook and Fines classes are inherate HelpdeskUse class
#include "HelpdeskUser.h"
#include "IssueBook.h"
#include "ReturnBook.h"
#include "Fines.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;
void HelpdeskUser::help_desk_Fun(){ // help_desk_Fun():cotain the menue of Help desk User
			m3:
            
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
	         cout<<"************************************************************************************************************************************************************************"<<endl;
			 cout<<"Please Select One Of The Following Option:"<<endl;
			 cout<<endl;
			 cout<<"Note:-IF You Enter Wrong Choice Then Yor Are Return On The Option:"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t1).Issue Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t2).View Issue Book List"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t3).Search Student Who Issue Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t4).Insert Return Book Record "<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t5).View Return Book Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t6).For Search Return Book Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t7).Create Fine of Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t8).View Fine of Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t9).Search Fine Book Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t10).Logout"<<endl;
			 			  int n;
			              cin>>n;
			 if(n==1){

			 	issue_book(); // this method calling from IssueBook class
			 }
			else if(n==2){
			view_issue_book();//this method calling from IssueBook class
			 }
			else if(n==3){
			search_Issue_book();//this method calling from IssueBook class
			 }
			else if(n==4){
			return_book_data();//this method calling from ReturnBook class
			 }
			else if(n==5){
				view_return_book();//this method calling from ReturnBook  class
			 }
			else if(n==6){
			search_return_book();//this method calling from ReturnBook  class
				}
			else if(n==7)
		   Fine_book_data();//this method calling from Fines  class
			else if(n==8){
			view_Fine_book_data();//this method calling from Fines  class
			}
			else if(n==9){
				 Search_Fine_Data();//this method calling from Fines  class
			}
			else if(n==10){//exist system code
				
				cout<<"Thank You For Using Library Management"<<endl;
				
			}
			else{
				goto m3;
			}
			 
		}