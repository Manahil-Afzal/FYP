//student class contain the Books record and Search specific Book in library. Books class are inherate in it;
#include "Student.h"
#include<iostream>
using namespace std;
 void Student::viewbooklist(){
 	seebook();// seebook() call from Books class
 }
 void Student::searchbook(){
 	searching();//searching() call from Books class 
 }
 