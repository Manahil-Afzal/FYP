#ifndef LIBRARIAN_H
#define LIBRARIAN_H
#include "Librarian_Access.h"

class Librarian : public Librarian_Access
{
	public:
void librarian_fun();

};

#endif