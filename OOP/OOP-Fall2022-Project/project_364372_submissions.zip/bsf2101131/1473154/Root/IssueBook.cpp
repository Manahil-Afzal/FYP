//issueBook class create the issue book ,view issue book and search issue book record in library management system;
#include "IssueBook.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<iomanip>
using namespace std;
void IssueBook::issue_book(){ // issue_book() :create issue books record
	       string Sid,Sname,Pro,Shift,IssueBId,Bname,Date,RetuenD;
	       string Dep;
			I:
			
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tCREATING ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			int no;
				cout<<"Student ID"<<endl;
			    cin>>Sid;
				cout<<"Student Name"<<endl;
				cin>>Sname;
				cout<<"Department"<<endl;
				cin>>Dep;
				cout<<"Program"<<endl;
				cin>>Pro;
				cout<<"Shift"<<endl;
			    cin>>Shift;
				cout<<"Issue Book ID"<<endl;
				cin>>IssueBId;
				cout<<"Book Name"<<endl;
				cin>>Bname;
				cout<<"Issue Date (DD/MM/YYYY)"<<endl;
				cin>>Date;
				cout<<"Return Date (DD/MM/YYYY)"<<endl;
			cin>>RetuenD;
				ofstream issuebook;
				issuebook.open("IssuesBooks.txt",ios::app);
				issuebook<<setw(18)<<left<<Sid<<setw(20)<<left<<Sname<<setw(20)<<left<<Dep<<setw(20)<<left<<Pro<<setw(20)<<left<<Shift<<setw(20)<<left<<IssueBId<<setw(20)<<left<<Bname<<setw(20)<<left<<Date<<setw(20)<<left<<RetuenD<<endl;
				issuebook.close();
			cout<<"If You Enter The Record Again Press 0 "<<endl;
			cout<<"Otherwise Press 2  And Enter  To Back.........."<<endl;
				int i;
				cin>>i;
				if(i==0){
					goto I;
				}
			}
				void IssueBook::view_issue_book(){ //view_issue_book():display all issue books record
				
				
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tVIEW ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				 char display[1000];
			     ifstream output;
		     	output.open("IssuesBooks.txt");
		    	while(!output.eof()){
				output.getline(display,1000);
			
				cout<<display<<endl;
			
			}output.close();
						
			}
void IssueBook::search_Issue_book(){ //search_Issue_book():search specific issue book record
	
	
    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    int n;
    cin>>n;
if(n==1){
    
    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("IssuesBooks.txt");
    cout << "\nType The Student/Book ID To Rearch Record:"<<endl;
    cin >>s_id;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_id, 0))) != string::npos)
            {
            	
    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSTUDENT/BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"Student ID        Student Name      Department           Program              Shift            Issue Book Id       Book Name              Issue Date         Return Date"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
         
            
        }
        filee.close();
        
    
   
         
        
    
    }
}
else if(n==2){
	   int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("IssuesBooks.txt");
    cout << "\nType The Student/Book Name To Search Record:"<<endl;
    cin >> s_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_name, 0))) != string::npos)
            {
            cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSTUDENT/BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"Student ID        Student Name      Department           Program              Shift            Issue Book Id       Book Name              Issue Date         Return Date"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
      
        
        }
        filee.close();
         
       
    }
}



	} 