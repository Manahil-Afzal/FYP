//staff class contain the records of staff in library;
#include "Staff.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<iomanip>
using namespace std;
	void Staff::GetEmployeeData(){ //GetEmployeeData():Create/update the record of the  employee
		string EmplyID,E_Name,E_Position,E_Phone,E_email,E_education;
			E:
			
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tUPDATE EMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                 cout<<"Employee ID:"<<endl;
				 cin>>EmplyID;
				 cout<<"Employee Name:"<<endl;
				 cin>>E_Name;
				 cout<<"Employee Poition:"<<endl;
				 cin>>E_Position;
				 cout<<"Employee Phone No. :"<<endl;
				 cin>>E_Phone;
				 cout<<"Employee Email:"<<endl;
				 cin>>E_email;
				 cout<<"Employee Education:"<<endl;
				 cin>>E_education;
				 ofstream staff;
				 staff.open("Staff.txt",ios::app);
				 staff<<setw(15)<<left<<EmplyID<<setw(20)<<left<<E_Name<<setw(20)<<left<<E_Position<<setw(15)<<left<<E_Phone<<setw(28)<<left<<E_email<<setw(25)<<left<<E_education<<endl;
				 int j;
				cout<<"Press 0 To Enter Employee Record"<<endl;
		        cout<<"Otherwise press 2 And Enter To Genrate Go Back staff"<<endl;
				 cin>>j;
				 if(j==0){
				 	goto E;
				 }
		}
			void Staff::viewstaff(){ //viewstaff():view all the record of the employees
		
		
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tALL EMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		char display[1000];
		ifstream staff;
		staff.open("Staff.txt",ios::app);
		while(!staff.eof()){
			staff.getline(display,1000);
			cout<<display<<endl;
			
		}
		staff.close();
		
		}
	void Staff::searchstaff(){  //searchstaff():serach the specific record of the employee
		
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH EMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		
		int n;
    cout << "\t\t\t\tSearching The Staff Record" << endl;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    cin>>n;
   
if(n==1){
	
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH EMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    int offset;
    std::string em_id,  line;
    ifstream filee;
    filee.open("Staff.txt");
    cout << "\nType The Employee ID To Search Record:"<<endl;
    cin >>em_id;
    if (filee.is_open())
    {
        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(em_id, 0))) != string::npos)
            {
            		
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tEMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"EM.ID          Employee Name       Position            Phone No.      Email                       Education"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
    }
   
}
else if(n==2){
	
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH EMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string em_name, line;
    ifstream filee;
    filee.open("Staff.txt");
    cout << "\nType The Employee Name To Search Record:"<<endl;
    cin >> em_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(em_name, 0))) != string::npos)
            {
                	
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tEMPLOYEE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"EM.ID          Employee Name       Position            Phone No.      Email                       Education"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
       
    }
    
}
}

