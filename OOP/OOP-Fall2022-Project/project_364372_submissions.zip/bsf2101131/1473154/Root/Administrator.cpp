//the administrator class cotain the feature and resposiblibty of administrator in library management system and a cotain function named: Administrator_fun() 
//staff and librarin Access classes are inherated in administrator class
#include "Administrator.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;
void Administrator::Administrator_fun(){ // Administrator menue function
	m3:
		
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME ADMINISTRATOR"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
        
			 cout<<"Please Select One Of The Following Option"<<endl;
			 cout<<endl;
			 cout<<"Note:-IF You Enter Wrong Choice Then Yor Are Return On The Option Again"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t1).Update Staff Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t2).View All Staff Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t3).Search Staff Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t4).View Issue Books Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t5).View Return Books Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t6).View Fines Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t7).Logout"<<endl;
			 			  int n;
			              cin>>n;
			 if(n==1){
          GetEmployeeData();    // GetEmployeeData() call from staff class
		 
			 	
			 }
			else if(n==2){
           viewstaff();  // viewstaff() call from staff class
			 }
			else if(n==3){
		   searchstaff();  // searchstaff() call from staff class
			
			 }
			else if(n==4){
		   view_issueBook_Record(); // view_issueBook_Record() call from  librarian Access  class 
			 }
			else if(n==5){
		   view_Return_book_Record(); //  view_Return_book_Record() call from librarian Access  class
			 }
			else if(n==6){
			 view_Fine_book_Record();   //  view_Fine_book_Record() call from librarian Access  class
				}
			else if(n==7){//exist system code
				
				cout<<"Thank You For Using Library Management"<<endl;
				
			}
			else{
				goto m3;
			}
		

}