#ifndef BOOKS_H
#define BOOKS_H
#include<string>
using namespace std;
class Books
{
		private:
		string bookid,bookname,authername,edition,Materialtype,publisher,List,RackNo,shelfno;
	public:
	    void insertbook();
	    void seebook();
	    void searching();

};

#endif