//GROUP  MEMBERS FOR PROJECT:
//SHOAIB ANWAR    BSF2101131
//AISHA UROOG     BSF2000935
//ABRAR YOUSAF    BSF2101340
/*STATEMENT: The Library Management system aimed at  processes of cataloging, book circulation, fine calculation, member details maintenance, and reports.
In this project we used 12 classes each class has specific purpose. Class named Books which is used to create ,view and search books record .
Student class are used for Student purpose in which Books class inherited, by using this class student can view and search books. 
Catalog user class in which Books class are inherited ,this class are used for catalog user. 
IssueBook class which is used for book issue purpose ,in which issue book record are inserted, view and search issue books record. 
Returnbook class are used to create return books record. Fines class which is basically used for making the fines of students in library. 
HelpdeskUser class that is used for circulation and Help Desk user, in which IssueBook, Returnbook and Fines class are inherited. 
Librarian_Access class that contain all the feature HelpdeskUser. Because librarian in library has has a acces to use system. 
Librarian class which is used for Librarian user purposed and  Librarian_Access are inherited in it. 
Staff  class that is used for creating ,displaying and searching staff record. 
Administrator  class are used for Administrator user in this project ,in which staff class inherited.
Last class that is our Grand child class in which student, Catalog user, HelpdeskUser, Librarian and Administrator are inherited in Library class.we used  inheritance.
And in main file of libraray management system create object of library class that control the Library Management system .There are 5 user that use library management 
•	Student (student can only view books list and search specific book)
•	Catalog user (Add new book record ,view book list and search books)
•	Circulation & Help Desk User(Circulate books, Create Return book record and Fines )
•	Librarian(which contain  all the Access of library except Administrator )
•	Administrator(maintain the staff Record and view reports)*/
//CATALOG USER:USERNAME:catalog@123  password:catlog0033
//HELP DESK USER: USERNAME:helpdesk@0033  PASSWORD:desk6655
//LIBRARIAN :USERNAME:librarian@1133    PASSWORD:library7788
//ADMINISTRATOR USERNAME:AD1234        PASSWORD:AD0033
#include<iostream>
#include<string.h>
#include<stdio.h>
#include<fstream>//for file handling
#include "Library.h"// from libray header file
using namespace std;
int main(){
		//for clear screen
		Library lib; //Object for library Class
			 int option;
			 m://label
			 	
			 	//for text color
			//ALL USER LIST FOR LIBRARY MANAGEMENT SYSTEM
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tLIBRARY MANAGEMENT SYSTEM"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		    cout<<"Please Select The Following Option: "<<endl;
		    cout<<endl;
		    cout<<"Note-: If You Enter The Wrong Choice Then You are Return On The Maine Option Again:  "<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t1).STUDENT"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t2).CATALOG USER"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t3).CIRCULATION & HELP DESK USER"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t4).LABRARIAN "<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t5).ADMINISTRATOR"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t6).CLOSE APPLICATION"<<endl;
		    cout<<endl;
		    cout<<endl;
		    cout<<endl;
		     cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t@ALL COPY RIGHT AND RESERVED 2022 BY S.S.L CORPORATION"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		    cin>>option;
		    switch(option){
		    case 1://FOR STUDENT USER
			s:	
		    	
		    	
		    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME STUDENT"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"Chose one of these option:"<<endl;
			cout<<endl;
			cout<<"Note-: If You Enter The Wrong Choice Then You are Return On Option Again:  "<<endl;
			cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t1).View Book List/Theses/Generals"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t2).Search You Want"<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t3).Go Back To Main Menue "<<endl;
		    cout<<endl;
		    cout<<"\t\t\t\t\t\t\t\t4).LOGOUT "<<endl;
		    cout<<endl;
		    int opt;
		    cin>>opt;
		    if(opt==1){
		    	lib.viewbooklist(); //CALLING FROM STUDENT CLASS
		    		cout<<"Press 1 to Go back"<<endl;
		    		int v;
		    		cin>>v;
		    		if(v==1){
		    			goto s;
			}
		    	}
		            else if(opt==2){
		            	lib.searchbook(); //CALLING FROM STUDENT CLASS
		    	    cout<<"Press 1 to Go back"<<endl;//FOR Go Back 
		    		int k;
		    		cin>>k;
		    		if(k==1){
		    			goto s;
					}
		    	}
		    		else if(opt==3){
		    	   goto m;//BACK TO MAIN MENUE
		    	}
		    		else if(opt==4){
		         	
		         	
		    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME STUDENT"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		         	cout<<"\t\tTHANKS STUDENTS FOR USING LIBRARY MANAGMENT SYSTEM"<<endl;
		         	cout<<"\t\t1).REUSE PLEASE PRESS "<<endl;
		         	cout<<"\t\t2).EXIT "<<endl;
		         	int r;
		         	cin>>r;
		         	if(r==1){
					
		         			goto m;
			 }
		         	else if(r==2){
		         	
		         	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME STUDENT"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		         	cout<<"\t\t\tTHANKS STUDENTS FOR USING LIBRARY MANAGMENT SYSTEM"<<endl;
		         	
					 }
					else{
					goto s;	
					 }
		    	
		    }
		    	else{
				
		    			goto s;
		    		}
		
		   case 2://FOR WELCOME CATALOG USER
		   	ba:
		   	
		   cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		    cout<<"\t\t\tPlease Select One Option:"<<endl;
		    cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t1).Login"<<endl;
		   	cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t2).Back To Maine Menue"<<endl;
		   	int a;
		   	cin>>a;
		   	if(a==1){
		   			//LOGIN PAGE
		   		
				
				login:
                
		   		cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\t WELCOME CATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		   		string us,ps;
		   	
		   		cout<<"\t\t\t\t\t\t\t\tEnter Username"<<endl;
		   		cin>>us;
		   		cout<<"\t\t\t\t\t\t\t\tEnter Password"<<endl;
		   		cin>>ps;
		   		ofstream file; //file hundling object for  Writing data
	    		file.open("Password1.txt",ios::app);//file cretion 
	    		file<<"\t\t\t"<<us<<"\t"<<ps<<endl;
	    		file.close();
		   		if(us=="catalog@123"&&ps=="catlog0033"){
		   		 b:
				lib.catalog_User(); //calling from library class
						cout<<"Press 1 To Back"<<endl;
						int x;
						cin>>x;
						if(x==1){
						goto b;
						}
				   }
				   else{
				   	//WRONG PASSWORD MESSAGE AND OPTION TO  RECOVER IT
				Rc:
				
				
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Wrong Uername OR Password"<<endl;
				cout<<endl;
				cout<<"1).Try Again"<<endl;
				cout<<endl;
				cout<<"2).If You Forget Password Then You Can Recover It"<<endl;
				int k;
				cin>>k;
				if(k==1){
					goto login;
					
				}
				else if(k==2){
				int offset;
    string username,line;
    ifstream filee;
    filee.open("Password1.txt");
    
     cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\nEnter The Username to Recover Password:"<<endl;
    cin >>username;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(username, 0))) != string::npos)
            {
            	
            	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tCATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
            	cout<<"Your Login Information is:"<<endl;
                cout<<"\t\t\t\tUsername"<<"\t"<<"Password"<<endl;
                cout << "\t\t\t\t"<<line<<endl;
                int l;
                cout<<"Press 1 To Go Login Page"<<endl;
                cin>>l;
                if(l==1){
                goto login;
				}
                break;
            }
             else{
            	
            	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CATALOG USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	cout << "Record not found"<<endl;
	cout<<"Press 1 To Login Page"<<endl;
	int p;
	cin>>p;
	if(p==1){
		goto Log;
	}
	break;
           
}	

        }
        filee.close();
    }

}
else{
	goto Rc;
}
					
					
					
					
				}
		
}
else if(a==2){
	goto m;
}
else{
	goto ba;
}
			break;
		    case 3://FOR CIRCULATION & HELP DESK USER
		    
		    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			// OPTION PAGE
		    cout<<"\t\t\tPlease Select One Option:"<<endl;
		    cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t1).Login"<<endl;
		   	cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t2).Back To Maine Menue"<<endl;
		   	int q;
		   	cin>>q;
		   	if(q==1){
		   		//LOGIN PAGE
		   		Log:
		   		
				
		   		cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		   		string us,ps;
		   		
		   		cout<<"\t\t\t\t\t\t\t\tEnter Username"<<endl;
		   		cin>>us;
		   		cout<<"\t\t\t\t\t\t\t\tEnter Password"<<endl;
		   		cin>>ps;
		   		ofstream file; //file hundling object for  Writing data
	    		file.open("Password2.txt",ios::app);//file cretion 
	    		file<<"\t\t\t"<<us<<"\t"<<ps<<endl;
	    		file.close();
		   		if(us=="helpdesk@0033"&&ps=="desk6655"){
		   		 c:
					lib.help_desk_user(); //calling from library class
					cout<<endl;
					cout<<endl;
						cout<<"Press 1 To Back"<<endl;
						int w;
						cin>>w;
						if(w==1){
							goto c;
						}
						
					
				   }
				   else{
				   		//WRONG PASSWORD MESSAGE AND OPTION TO  RECOVER IT
				Re2:
					
				
				
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Wrong Uername OR Password"<<endl;
				cout<<endl;
				cout<<"1).Try Again"<<endl;
				cout<<endl;
				cout<<"2).If You Forget Password Then You Can Recover It"<<endl;
				int k;
				cin>>k;
				if(k==1){
					goto Log;
				}
			else if(k==2){
				int offset;
    std::string username,line;
    ifstream filee;
    filee.open("Password2.txt");
    
    	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\nEnter The Username to Recover Password:"<<endl;
    cin >>username;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(username, 0))) != string::npos)
            {
            	
            	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
            	cout<<"Your Login Information is:"<<endl;
                cout<<"\t\t\t\tUsername"<<"\t"<<"Password"<<endl;
                cout << "\t\t\t\t"<<line<<endl;
                int l;
                cout<<"Press 1 To Go Login Page"<<endl;
                cin>>l;
                if(l==1){
                goto Log;
				}
                break;
            }
             else{
            	
            	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME CIRCULATION & HELP DESK USER"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	cout << "Record not found"<<endl;
	cout<<"Press 1 To Login Page"<<endl;
	int p;
	cin>>p;
	if(p==1){
		goto Log;
	}
	break;
           
}	

        }
        filee.close();
    }

}
else{
	goto Re2;
}
					
					
					
					
				}
		
}

else if(q==2){
	goto m;
}
else{
	goto ba;
}
			 break;
		    case 4://FOR  LIBRARIAN
		    bak:
             
		    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		   //OPTION PAGE
		   cout<<"\t\t\tPlease Select One Option:"<<endl;
		    cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t1).Login"<<endl;
		   	cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t2).Back To Maine Menue"<<endl;
		   	int s;
		   	cin>>s;
		   	if(s==1){
		   		  	//LOGIN PAGE
		   		Log1:
		   		
				
		   	  cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		 
			   	string us,ps;
		   		cout<<"\t\t\t\t\t\t\t\tEnter Username"<<endl;
		   		cin>>us;
		   		cout<<"\t\t\t\t\t\t\t\tEnter Password"<<endl;
		   		cin>>ps;
		   		ofstream file; //file hundling object for  Writing data
	    		file.open("Password3.txt",ios::app);//file cretion 
	    		file<<"\t\t\t"<<us<<"\t"<<ps<<endl;
	    		file.close();
		   		if(us=="librarian@1133"&&ps=="library7788"){
		   		 L:
					lib.Librarian_Fun(); //calling from library class
						cout<<"Press 1 To Back"<<endl;
						int w;
						cin>>w;
						if(w==1){
							goto L;
						}
				   }
				   else{
				Re3:
					//WRONG PASSWORD MESSAGE AND OPTION TO  RECOVER IT
				
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Wrong Uername OR Password"<<endl;
				cout<<endl;
				cout<<"1).Try Again"<<endl;
				cout<<endl;
				cout<<"2).If You Forget Password Then You Can Recover It"<<endl;
				int k;
				cin>>k;
				if(k==1){
					goto Log1 ;
					
				}
				else if(k==2){
				int offset;
    std::string username,line;
    ifstream filee;
    filee.open("Password3.txt");
    
    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\nEnter The Username to Recover Password:"<<endl;
    cin >>username;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(username, 0))) != string::npos)
            {
            	
            	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
            	cout<<"Your Login Information is:"<<endl;
                cout<<"\t\t\t\tUsername"<<"\t"<<"Password"<<endl;
                cout << "\t\t\t\t"<<line<<endl;
                int l;
                cout<<"Press 1 To Go Login Page"<<endl;
                cin>>l;
                if(l==1){
                goto Log1;
				}
                break;
            }
             else{
            	
            cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	cout << "Record not found"<<endl;
	cout<<"Press 1 To Login Page"<<endl;
	int p;
	cin>>p;
	if(p==1){
		goto Log1;
	}
	break;
           
}	

        }
        filee.close();
    }

}
else{
	goto Re3;
}
					
					
					
					
				}
		
}

else if(q==2){
	goto m;
}
else{
	goto bak;
}
		    	
		    
		    	
		    	break;
		    case 5: //FOR  ADMINISTRATOR
		    	ch:
		    	
		    cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME ADMINISTRATOR"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<endl;
			//OPTION PAGE
		    cout<<"\t\t\tPlease Select One Option:"<<endl;
		    cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t1).Login"<<endl;
		   	cout<<endl;
		   	cout<<"\t\t\t\t\t\t\t2).Back To Maine Menue"<<endl;
		   	int r;
		   	cin>>r;
		   	if(r==1){
		   		Log2:
		   			//LOGIN PAGE
		   		
				
		   	 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME ADMINISTRATOR"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		   		string us,ps;
		   		cout<<"\t\t\t\t\t\t\t\tEnter Username"<<endl;
		   		cin>>us;
		   		cout<<"\t\t\t\t\t\t\t\tEnter Password"<<endl;
		   		cin>>ps;
		   		ofstream file; //file hundling object for  Writing data
	    		file.open("password4.txt",ios::app);//file cretion 
	    		file<<"\t\t\t"<<us<<"\t"<<ps<<endl;
	    		file.close();
		   		if(us=="AD1234"&&ps=="AD0033"){
		   		 R:
					lib.Administrator_LIB(); //calling from library class
						cout<<"Press 1 To Back"<<endl;
						int w;
						cin>>w;
						if(w==1){
							goto R;
						}
				   }
				   else{
				Re4:
					//WRONG PASSWORD MESSAGE AND OPTION TO  RECOVER IT
			
            cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME ADMINISTRATOR"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"Wrong Uername OR Password"<<endl;
				cout<<endl;
				cout<<"1).Try Again"<<endl;
				cout<<endl;
				cout<<"2).If You Forget Password Then You Can Recover It"<<endl;
				int k;
				cin>>k;
				if(k==1){
					goto Log2 ;
					
				}
				else if(k==2){
				int offset;
    std::string username,line;
    ifstream filee;
    filee.open("password4.txt");
    
     cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME ADMINISTRATOR"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\nEnter The Username to Recover Password:"<<endl;
    cin >>username;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(username, 0))) != string::npos)
            {
            	cout<<"Your Login Information is:"<<endl;
                cout<<"\t\t\t\tUsername"<<"\t"<<"Password"<<endl;
                cout << "\t\t\t\t"<<line<<endl;
                int l;
                cout<<"Press 1 To Go Login Page"<<endl;
                cin>>l;
                if(l==1){
                goto Log2;
				}
                break;
            }
             else{
            	
            cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME ADMINISTRATOR"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	cout << "Record not found"<<endl;
	cout<<endl;
	cout<<"Press 1 To Login Page"<<endl;
	int p;
	cin>>p;
	if(p==1){
		goto Log1;
	}
	break;
           
}	

        }
        filee.close();
    }

}
else{
	goto Re4;
}
					
					
					
					
				}
		
}

else if(q==2){
	goto m;
}
else{
	goto ch;
}
		    	
		    	break;
		    case 6://FOR CLOSING SYSTEM
		    	    
		         	
		         	cout<<"THANKS  FOR USING LIBRARY MANAGMENT SYSTEM"<<endl;
		         	cout<<"1).REUSE PLEASE PRESS "<<endl;
		         	cout<<"2).EXIT "<<endl;
		         	int p;
		         	cin>>r;
					 
		         		if(p==1){
						
		         			goto m;
		         			 }
		         	else if(p==2){
					
		         	
		         	cout<<"THANKS  FOR USING LIBRARY MANAGMENT SYSTEM"<<endl;
		         	
				}
				else{
			
			 cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tTHANKS FOR USING"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
					cout<<"\t\tYou Enter The Wrong Choice That Is Why We Close The Application"<<endl;
					
					 }
		         
		    	default:
					goto m;
					break;
		}
		
	return 0;
}