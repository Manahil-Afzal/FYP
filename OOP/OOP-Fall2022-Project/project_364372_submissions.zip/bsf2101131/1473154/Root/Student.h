
#ifndef STUDENT_H
#define STUDENT_H
#include "Books.h"
class Student : public Books  // Books class are inherate in student class
{
	public:

void viewbooklist(); //viewbooklist():display all books record
void searchbook();//searchbook():use for search books
};

#endif