//Librarian_Acces contain all the Acccess of the library regard to Books;
#include "Librarian_Access.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<iomanip>
using namespace std;
	void Librarian_Access::Issue_book_By_Librarian(){ //FOR CREATE ISSUE BOOK RECORD
		string Sid,Sname,Dep,Pro,Shift,IssueBId,Bname,Date,RetuenD,status;
				I:
					
					
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tCREATING ISSUE BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Student ID"<<endl;
				cin>> Sid;
				cout<<"Student Name"<<endl;
				cin>> Sname;
				cout<<"Department"<<endl;
				cin>>Dep;
				cout<<"Program"<<endl;
				cin>>Pro;
				cout<<"Shift"<<endl;
				cin>> Shift;
				cout<<"Issue Book ID"<<endl;
				cin>>IssueBId;
				cout<<"Book Name"<<endl;
				cin>>Bname;
				cout<<"Date (DD/MM/YYYY)"<<endl;
				cin>>Date;
				cout<<"Return Date (DD/MM/YYYY)"<<endl;
				cin>>RetuenD;
				ofstream issuebook;
				issuebook.open("IssuesBooks.txt",ios::app);
				issuebook<<setw(18)<<left<<Sid<<setw(20)<<left<<Sname<<setw(20)<<left<<Dep<<setw(20)<<left<<Pro<<setw(20)<<left<<Shift<<setw(20)<<left<<IssueBId<<setw(20)<<left<<Bname<<setw(20)<<left<<Date<<setw(20)<<left<<RetuenD<<endl;
				issuebook.close();
				cout<<"If You Enter The Record Again Press 0 "<<endl;
				cout<<"Press 2 And Enter Key To Generate Back Menue Stuff "<<endl;
				int i;
				cin>>i;
				if(i==0){
					goto I;
				}
			}
			void Librarian_Access :: Search_IssueBooh_Record(){ // FOR SEARCH ISSUE BOOK RECORD
		
	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\t\t\t\tSearching the Record" << endl;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    int n;
    cin>>n;
if(n==1){
    
    	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("IssuesBooks.txt");
    cout << "\nType The Student/Book ID To Rearch Record:"<<endl;
    cin >>s_id;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_id, 0))) != string::npos)
            {
            		
	     	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
            cout<<"Student ID        Student Name      Department           Program              Shift            Issue Book Id       Book Name              Issue Date         Return Date"<<endl;
            cout << "\n"<<line<<endl;
            break;
            }
        }
        filee.close();
    }
}
else if(n==2){
	
		cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("IssuesBooks.txt");
    cout << "\nType The Student/Book Name To Search Record:"<<endl;
    cin >> s_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_name, 0))) != string::npos)
            {
            		
		cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH ISSUE BOOK RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                 cout<<"Student ID        Student Name      Department           Program              Shift            Issue Book Id       Book Name              Issue Date         Return Date"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
       
    }
}



	} 
void Librarian_Access::view_issueBook_Record(){ //FOR VIEW ISSUE BOOK RECORD 
	    	        
					
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tALL ISSUE BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				 char display[1000];
			     ifstream output;
		     	output.open("IssuesBooks.txt");
		    	while(!output.eof()){
				output.getline(display,1000);
				cout<<display<<endl;
			}	
			output.close();
		
	}
	
	void Librarian_Access:: Return_bookdata_ByLibrarian(){ // FOR CREATE RETURN  BOOK RECORD
		    string  Sid,Sname,Dep,Pro,Shift,IssueBId,Bname,RetuenD,status;
				f:
				
					cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\t CREATING RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Student ID"<<endl;
				cin>>Sid;
				cout<<"Student Name"<<endl;
				cin>>Sname;
				cout<<"Department"<<endl;
				cin>>Dep;
				cout<<"Program"<<endl;
				cin>>Pro;
				cout<<"Shift"<<endl;
				cin>> Shift;
				cout<<"Return Book/General/Theses ID"<<endl;
				cin>>IssueBId;
				cout<<"Book/General/Theses  Name"<<endl;
				cin>>Bname;
				cout<<"Return Date (DD/MM/YYY)"<<endl;
				cin>>RetuenD;
				cout<<"Status"<<endl;
				cin>>status;
				ofstream returnbook;
				returnbook.open("Returnbook.txt",ios::app);
				returnbook<<setw(12)<<left<<Sid<<setw(20)<<left<<Sname<<setw(20)<<left<<Dep<<setw(20)<<left<<Pro<<setw(20)<<left<<Shift<<setw(20)<<left<<IssueBId<<setw(20)<<left<<Bname<<setw(20)<<left<<RetuenD<<setw(20)<<left<<status<<endl;
				returnbook.close();
				cout<<"Press 0 To Continue Inserted Fine Record "<<endl;
				cout<<"Otherwise Press 1  And Enter  To Back.........."<<endl;
				int h;
				cin>>h;
				if(h==0){
					goto f;
				}
			}
void Librarian_Access:: Return_search_Record(){ // FOR SEARCH ISSUE BOOK RECORD
			
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		int n;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    cin>>n;
   
if(n==1){
	
	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("Returnbook.txt");
    cout << "\nType The Student/Book ID To Rearch Record:"<<endl;
    cin >>s_id;
    if (filee.is_open())
    {
        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_id, 0))) != string::npos)
            {
            	
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tRETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"StudentID   Student Name      Department           Program              Shift            ReturnBookID           Return_Book_Name    Return Date         Status"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
    }
   
}
else if(n==2){
	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH RETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("Returnbook.txt");
    cout << "\nType The Student/Book Name To Search Record:"<<endl;
    cin >> s_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_name, 0))) != string::npos)
            
            {
            	
				cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tRETURN BOOKS RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"StudentID   Student Name      Department           Program              Shift            ReturnBookID           Return_Book_Name    Return Date         Status"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
         
        }
        filee.close();
       
    }
    
}
}
	void Librarian_Access ::view_Return_book_Record(){ // FOR VIEW RETURN BOOK RECORD
					
					
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tALL RETURN BOOKS DATA"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				 char display[1000];
			     ifstream returnbook;
		     	returnbook.open("Returnbook.txt",ios::app);
		    	while(!returnbook.eof()){
				returnbook.getline(display,1000);
			
				cout<<display<<endl;
			}
		}
			void Librarian_Access::Fine_book_data_Bylib(){ // FOR CREATE FINE BOOK RECORD
		string Sid,Sname,Dep,Pro,Shift,IssueBId,Bname,RetuenD,status;
		int dues_day,TotalFine;
				fi:
				
					cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE CREATION PAGE"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Student ID"<<endl;
				cin>> Sid;
				cout<<"Student Name"<<endl;
				cin>> Sname;
				cout<<"Department"<<endl;
				cin>>Dep;
				cout<<"Program"<<endl;
				cin>>Pro;
				cout<<"Shift"<<endl;
				cin>> Shift;
				cout<<"Issue Book ID"<<endl;
				cin>>IssueBId;
				cout<<"Book Name"<<endl;
				cin>>Bname;
				cout<<"Return Date (DD/MM/YYYY)"<<endl;
				cin>>RetuenD;
			    cout<<"Enter The Number of Days After Dues Date "<<endl;
			    cin>>dues_day;
			    if(dues_day<=10){
			    	TotalFine=dues_day*50;
				}
				else if(dues_day>=20)
				{
					TotalFine=dues_day*50;
				}
				else if(dues_day=30)
				{
					TotalFine=dues_day*50;
				}
				else{
						TotalFine=490*50;
					
				}
				ofstream finebook;
				finebook.open("Finebook.txt",ios::app);
				finebook<<setw(15)<<left<<Sid<<setw(20)<<left<<Sname<<setw(20)<<left<<Dep<<setw(20)<<left<<Pro<<setw(20)<<left<<Shift<<setw(20)<<left<<IssueBId<<setw(20)<<left<<Bname<<setw(20)<<left<<RetuenD<<setw(20)<<left<<TotalFine<<endl;
				finebook.close();
				int f;
				cout<<"Press 0 to Continue Creating Fine Record"<<endl;
				cout<<"Press 2 and Enter To Create Go Back Stuff"<<endl;
				cin>>f;
				if(f==0){
					goto fi;
				}
				
			}
			void Librarian_Access::view_Fine_book_Record(){// FOR VIEW FINES BOOK RECORD
					
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tALL FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				 char display[1000];
			     ifstream finebook;
		     	finebook.open("Finebook.txt");
		    	while(!finebook.eof()){
				finebook.getline(display,1000);
				cout<<display<<endl;
			}
			finebook.close();
		}
	void Librarian_Access::Search_Fine_Record(){//FOR SEARCH FINES  BOOK RECORD
			
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		int n;
    cout << "\t\t\t\tSearching the Record" << endl;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    cin>>n;
   
if(n==1){

cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("Finebook.txt");
    cout << "\nType the Student ID to Search Record :"<<endl;
    cin >>s_id;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_id, 0))) != string::npos)
            {
            	
	        cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
            	
                cout<<"Student ID     Student Name       Department         Programe              Shift              Book ID              Book Name           Return Date        Total Fine"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
    }
}
else if(n==2){
	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string s_name, line;
    ifstream filee;
    filee.open("Finebook.txt");
    cout << "\nType The Student Name To Search Record:"<<endl;
    cin >> s_name;
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_name, 0))) != string::npos)
            
            {
            	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                 cout<<"Student ID     Student Name       Department         Programe              Shift              Book ID              Book Name           Return Date        Total Fine"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
            
     }
        filee.close();
       
    }
   

}
}
