#ifndef FINES_H
#define FINES_H
#include<string>
using namespace std;
class Fines
{
	private:
		string Sid,Sname,Dep,Pro,Shift,IssueBId,Bname,RetuenD,status;
		int dues_day,TotalFine;
	public:
	void Fine_book_data();
	void view_Fine_book_data();
	void Search_Fine_Data();
	
};

#endif