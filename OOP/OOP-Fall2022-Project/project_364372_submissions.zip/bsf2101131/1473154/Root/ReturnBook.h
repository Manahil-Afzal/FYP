#ifndef RETURNBOOK_H
#define RETURNBOOK_H
#include<string>
using namespace std;
class ReturnBook
{
	public:
	void return_book_data();
	void view_return_book();
	void search_return_book();
		

};

#endif