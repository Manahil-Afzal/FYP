//
#include "Librarian.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;
void Librarian::librarian_fun(){
		m3:
		
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tWELCOME LIBRARIAN"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
        
			 cout<<"Please Select One Of The Following Option"<<endl;
			 cout<<endl;
			 cout<<"Note:-IF You Enter Wrong Choice Then Yor Are Return On The Option"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t1).Issue Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t2).View Issue Book List"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t3).Search Student Who Issue Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t4).Insert Return Book Record "<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t5).View Return Book Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t6).For Search Return Book Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t7).Create Fine of Book"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t8).View Fine of Book"<<endl;
			 cout<<endl;
		     cout<<"\t\t\t\t\t9).Search Fine  Record"<<endl;
			 cout<<endl;
			 cout<<"\t\t\t\t\t10).Logout"<<endl;
			 			  int n;
			              cin>>n;
			 if(n==1){
           Issue_book_By_Librarian();
			 	
			 }
			else if(n==2){
           view_issueBook_Record();
			 }
			else if(n==3){
			Search_IssueBooh_Record();
			
			 }
			else if(n==4){
		Return_bookdata_ByLibrarian();
			 }
			else if(n==5){
			view_Return_book_Record();
			 }
			else if(n==6){
			 Return_search_Record();
				}
			else if(n==7){
			Fine_book_data_Bylib();
			}
			
			else if(n==8){
			view_Fine_book_Record();
			}
			else if(n==9){
			 Search_Fine_Record();

			}
		
			else if(n==10){
				
				cout<<"Thank You For Using Library Management"<<endl;
				
			}
			else{
				goto m3;
			}
		

}