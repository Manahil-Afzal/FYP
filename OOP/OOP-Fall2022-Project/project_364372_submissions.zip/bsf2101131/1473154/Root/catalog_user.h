#ifndef CATALOG_USER_H
#define CATALOG_USER_H
#include "Books.h"
class catalog_user : public Books //Books class are inherate in  catalog_user;
{
	public:
		void catalog();//contain the menue of catalog user;
	protected:
};

#endif