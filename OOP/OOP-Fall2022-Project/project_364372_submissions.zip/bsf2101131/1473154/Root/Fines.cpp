//this class contain the fine record,view  fine record and search fine record of the student
#include "Fines.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
#include<iomanip>
using namespace std;
	void Fines::Fine_book_data(){ // Fine_book_data() use to create fine record of the student
				fi:
			
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE CREATION PAGE"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				cout<<"Student ID"<<endl;
				cin>> Sid;
				cout<<"Student Name"<<endl;
				cin>> Sname;
				cout<<"Department"<<endl;
				cin>>Dep;
				cout<<"Program"<<endl;
				cin>>Pro;
				cout<<"Shift"<<endl;
				cin>> Shift;
				cout<<"Issue Book ID"<<endl;
				cin>>IssueBId;
				cout<<"Book Name"<<endl;
				cin>>Bname;
				cout<<"Return Date (DD/MM/YYYY)"<<endl;
				cin>>RetuenD;
			    cout<<"Enter The Number of Days After Dues Date "<<endl;
			    cin>>dues_day;
			    if(dues_day<=10){
			    	TotalFine=dues_day*50;
				}
				else if(dues_day>=20)
				{
					TotalFine=dues_day*50;
				}
				else if(dues_day=30)
				{
					TotalFine=dues_day*50;
				}
				else{
						TotalFine=5000;
					
				}
				ofstream finebook;
				finebook.open("Finebook.txt",ios::app);
				finebook<<setw(15)<<left<<Sid<<setw(20)<<left<<Sname<<setw(20)<<left<<Dep<<setw(20)<<left<<Pro<<setw(20)<<left<<Shift<<setw(20)<<left<<IssueBId<<setw(20)<<left<<Bname<<setw(20)<<left<<RetuenD<<setw(20)<<left<<TotalFine<<endl;
				finebook.close();
				cout<<"Press 0 to Continue Creating Fine Record"<<endl;
				cout<<"Press 2 and Enter To Create Go Back"<<endl;
				int f;
				cin>>f;
				if(f==0){
					goto fi;
				}
				
			}
			
				void Fines::view_Fine_book_data(){  //view_Fine_book_data() use to diplay all fine records
					
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE DETAIL"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
				 char display[1000];
			     ifstream finebook;
		     	finebook.open("Finebook.txt",ios::app);
		    	while(!finebook.eof()){
				finebook.getline(display,1000);
				cout<<display<<endl;
			}
			finebook.close();
		}
		void Fines:: Search_Fine_Data(){ //Search_Fine_Data() use to search  specific fine record
			
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
		int n;
    cout<<"1).Search By ID"<<endl;
    cout<<"2).Search By Name"<<endl;
    cin>>n;
   
if(n==1){

cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    int offset;
    std::string s_id, s_name, line;
    ifstream filee;
    filee.open("Finebook.txt");
    	
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
    cout << "\nType the Student ID To Search Record:"<<endl;
    cin >>s_id;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_id, 0))) != string::npos)
            {
            
			cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"Student ID     Student Name       Department         Programe              Shift              Book ID              Book Name           Return Date        Total Fine"<<endl;
                cout << "\n"<<line<<endl;
               
                break;
            }
        }
        filee.close();
    }
}
else if(n==2){
	
	cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tSEARCH FINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
	   int offset;
    std::string s_name, line;
    ifstream filee;
    filee.open("Finebook.txt");
    cout << "\nType The Student Name To Rearch Record:"<<endl;
    cin >> s_name;
     
     
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(s_name, 0))) != string::npos)
            {
            	
	        cout<<"************************************************************************************************************************************************************************"<<endl;
			cout<<"\t\t\t\t\t\t\t\tFINE RECORD"<<endl;
			cout<<endl;
			cout<<"************************************************************************************************************************************************************************"<<endl;
                cout<<"Student ID     Student Name       Department         Programe              Shift              Book ID              Book Name           Return Date        Total Fine"<<endl;
                cout << "\n"<<line<<endl;
               
                break;
            }
        }
        filee.close();
       
    }
   
}

	} 