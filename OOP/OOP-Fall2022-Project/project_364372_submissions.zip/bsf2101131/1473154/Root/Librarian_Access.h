#ifndef LIBRARIAN_ACCESS_H
#define LIBRARIAN_ACCESS_H
class Librarian_Access
{
	public:
		void Issue_book_By_Librarian();//FOR CREATE ISSUE BOOK RECORD
		void view_issueBook_Record();//FOR VIEW ISSUE BOOK RECORD 
		void Search_IssueBooh_Record();// FOR SEARCH ISSUE BOOK RECORD
		void Return_bookdata_ByLibrarian();// FOR CREATE RETURN  BOOK RECORD
    	void Return_search_Record();// FOR VIEW RETURN BOOK RECORD
    	void view_Return_book_Record();// FOR SEARCH ISSUE BOOK RECORD
        void Fine_book_data_Bylib();// FOR CREATE FINE BOOK RECORD
        void Search_Fine_Record();// FOR VIEW FINES BOOK RECORD
        void view_Fine_book_Record();//FOR SEARCH FINES  BOOK RECORD
		

};

#endif