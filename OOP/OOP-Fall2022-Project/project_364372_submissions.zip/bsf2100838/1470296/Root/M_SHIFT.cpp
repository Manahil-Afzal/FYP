#include"M_SHIFT.h"
//#include<windows.h>
#include"UE_LMS.h"


        Morning_Shift::Morning_Shift(){
     	     //	Sleep(1500);
              //	system("cls");
              //	system("COLOR F0");
    cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\t\t\t\t| MOST WELCOME TO MORNING SHIFT STUDENT PORTAL OF UNIVERSITY OF EDUCATION |"<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n";
         //PlaySound(TEXT("e_shift.wav"),NULL,SND_SYNC);
			cin.ignore();
			cout<<"\n\n Please Enter Your Deparment: ";
			getline(cin,department);
			
		//	Sleep(2000);
		//	system("cls");
		//	system("COLOR E0");
			
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
                    cout<<"\n\t\t\t\t\t   WELCOME STUDENT OF ' "<<department<<" ' DEPARTMENT"<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n";			
			
				
			cout<<"\n\n\t\t\t We are offering the following degrees:"<<endl;
			cout<<"\n\n";
			cout<<"\t\t\t (1 : BS"<<endl;
			cout<<"\t\t\t (2 : MS"<<endl;
			cout<<"\t\t\t (3 : M.Phil"<<endl;
			
	cout<<"\n\t\t\t*********************************************************************************************"<<endl;
	cout<<"\n\n";
			cout<<"\n\t\t\t(1 For opening BS portal press 'BS'"<<endl;
			cout<<"\n\t\t\t(2 For opening MS portal press 'MS'"<<endl;
			cout<<"\n\t\t\t(3 For opening M.Phil portal press 'MP'"<<endl;
			cout<<"\n\t\t\t(4 To go Back Press '1'"<<endl;
			cout<<"\n\t\t\t(5 Your Choice: ";
			cin>>choice2;
		 	if(choice2=="BS"||choice2=="bs" ){
		//	  system("cls");
				//HERE I AM MANAGING BS CLASS 
	         // system("COLOR 20");
cout<<"\n\n\t\t\t*******************************************************************************************************************"<<endl;				
                    cout<<"\n\t\t\t\t\t  WELCOME BS STUDENT OF UNIVERSITY OF EDUCATION "<<endl;
cout<<"\n\n\t\t\t*******************************************************************************************************************"<<endl;				
cout<<"\n\n";			
         // PlaySound(TEXT("BS.wav"),NULL,SND_SYNC);
				cout<<"\n\n\t\t\tDEAR STUDENT HERE YOU CAN CALCULATE  ";
				cout<<"\n\n";
				cout<<"\t\t\t1) Mid GPA"<<endl;
				cout<<"\t\t\t2) Final GPA"<<endl;
				cout<<"\t\t\t3) Final CGPA"<<endl;
				cout<<"\n\n";
				
	cout<<"\n\t\t\t*********************************************************************************************"<<endl;
				
				cout<<"\n\t\t\t1: For calculating Mid GPA enter 'M':"<<endl;
				cout<<"\n\t\t\t2: For calculating Final GPA enter 'F':"<<endl;
				cout<<"\n\t\t\t3: For calculating CGPA enter 'C':"<<endl;
				cout<<"\n\t\t\t4: To go Back Press '1'"<<endl;
				cout<<"\n\t\t\t5: Your Choice: ";
				cin>>choice3;
	cout<<"\n\n\t\t\t*********************************************************************************************"<<endl;			
				
				
					if(choice3=='M'||choice3=='m'||choice3=='F'||choice3=='f'){
						
					//	system("cls");
					//	system("COLOR E0");
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
                    cout<<"\n\t\t\t\t\t\t WELCOME TO GPA PORTAL  OF UNIVERSITY OF EDUCATION "<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n";    
				//PlaySound(TEXT("gpa.wav"),NULL,SND_SYNC);
						   cout<<"\n\n\t\t\t\t\t Please Enter the Number of Subjects of last Semester:";
						   cin>>Var1;
						   cin.ignore();
						    for(int i=0;i<Var1;i++){
						
						      cout<<"\n Enter the Name of Subject  "<<i+1<< ": ";
						      getline(cin,name);
						
						      cout<<"\n Enter the Total Marks of ~ "<<name<<": ";
						      cin>>tmarks;
						      cout<<"\n Enter the Obtaine Marks of ~ "<<name<<": ";
						      cin>>omarks;
						      cout<<"\n Enter the Credit hours of ~ "<<name<<": ";
						      cin>>credit_hours;
						      
						     // system("cls");
	                          cout<<"\n\t\t\t\t\t YOUR RECOR OF ' " <<name<<" ' SUBJECT ";
	                         // PlaySound(TEXT("Result.wav"),NULL,SND_SYNC);
	cout<<"\n\n\t\t\t*******************************************************************************************************************"<<endl;						    
						      percentage= (omarks/tmarks)*100;
						      cin.ignore();
						      
						        if(percentage>=90&&percentage<=100){
								  
						      		grade="A+";
						      		grade_point=4;
						      		
												  }	        
								    else if(percentage>=80&&percentage<=89){
						      		         grade="A";
						      		         float sub=percentage-80;
						      		         float multiple=sub*0.05;
											 grade_point=3.50+multiple;	
						      		
							                   }
							   else if(percentage>=70&&percentage<=79){
						      		grade="B";
						      		float sub=percentage-70;
						      	    float multiple=sub*0.05;
								    grade_point=3.00+multiple;	
						      		
							  }
							 else if(percentage>=60&&percentage<=69){
						      	grade="C";
						      	float sub=percentage-60;
						      	float multiple=sub*0.05;
								grade_point=2.50+multiple;	
						      									  }
							 else if(percentage>=50&&percentage<=59){
						      		 	grade="D";
										float sub=percentage-50;
						      		        float multiple=sub*0.05;
											grade_point=2.00+multiple;
											
										
						      		     }
							  
							  else if(percentage<50){
							  	 	grade="F";
							  	 	grade_point=0.00;
							  	 	
							  }
							  
							 else
							  cout<<"\n\t\tYou are not Eligible to study";
							 //here else if end;
							 
								



                                  //here declare two variables grade_point_sum,C_sum
                                        
								     	    float grade_point_1=grade_point * credit_hours;  //here multiply
								     	    float sum1 = sum1+grade_point_1;     //sum of all grade_point and credit_hours
								     	    float sum2=sum2+ credit_hours;   // sum of all credit_hours require for division in gpa
									         
									         
									     	    gpa=sum1/sum2;
									    
										    

							       
							
						
							  
						      cout<<"\n\n\n";
		cout<< "\n\t\t\t"<<left<<"  "
      //  << setw(20)
        <<"Subject_Name"
        << left
       // << setw(18)
        << "Total_Marks"
        << left
       // << setw(18)
        << "Obtained_Marks"
        << left
      //  << setw(18)
        << "Credit_Hours"
        <<left
       // <<setw(18)
        <<"Percentage"
        <<left
       // <<setw(15)
        <<"Grade"
        <<left
        //<<setw(0)
        <<"Grade_point"
        << endl;
        
    cout<<"\n\t\t\t";
    
    cout<< left<<"  "
           // << setw(23)
            << name
            << left
           // << setw(20)
            << tmarks
            << left
           // << setw(20)
            << omarks
            << left
           // << setw(15)
            << credit_hours
            <<left
           // <<setw(0)
            <<percentage
            <<left
           // <<setw(14)
            <<"%";
            
            cout<<left
           // <<setw(17)
            <<grade
            <<left
           // <<setw(0)
            <<grade_point<<endl<<"\n\n"<<endl;
            
            if(percentage<50){
							
		 	cout<<"\t\t YOU WILL REPEATE THIS SUBJECT:"<<name<<endl;
		 	 
							  }
            
cout<<"\7\n\n\t\t\t*******************************************************************************************************************"<<endl;						 
				    
	}	
	  // cout<<"\n\n\t\t\t YOUR 'GPA' IN THIS SEMENTER IS :"<<fixed<<setprecision(2)<< gpa<<endl;
	   if (gpa<1.7)
	   {
	   	   cout<<"\n\t\t 'BE ALERT!' YOU ARE DROPPED IN THIS  SEMESTER ";
       }
		                
	  else if(gpa>=1.7&&gpa<2.0)
	  {
	  	 cout<<"\n\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER"<<endl;
	   	 cout<<" \n\t\t 'BE ALERT!'YOU ARE PROMOTED TO NEXT SEMESTER WITH 'PROBATION'"; 
	   }
		   
	    else 
	   {
	   	cout<<"\n\n\n\t\t\t\t****** CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER ******";
	   	//	PlaySound(TEXT("cong.wav"),NULL,SND_SYNC);
	    }
      
	   cout<<"\n\nEnter '1'To go Back:";
	   cin>>no;
	   if(no==1)
	// system("cls");
	 UE_LMS obj;
	 
	 
		}
		
		
	else if(choice3=='C'||choice3=='c')
	{
		 //system("cls");
		 //system("COLOR 4F");
		float sum_t_gpa=0;		
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
                    cout<<"\n\t\t\t\t  WELCOME TO CGPA PORTAL  OF UNIVERSITY OF EDUCATION "<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n"; 

      // PlaySound(TEXT("cgpa.wav"),NULL,SND_SYNC);

	     cout<<"\n\n\t\tPlease Enter The  'NO' Of Semester For Calculate 'CGPA : ";
	     cin>>no_of_semester;
		 	for(int i=0;i<no_of_semester;i++)
			 {
		 	cout<<"\n Please Enter your  'GPA' in  "<<i+1<<"  Semester : ";
		    cin>>t_gpa[i];
		    
		    sum_t_gpa=sum_t_gpa+t_gpa[i];
		    cgpa=  sum_t_gpa/no_of_semester;
		
            
	       }
	
	
cout<<"\n\n\t\t\t*********************************************************************************************"<<endl;
	
	  
		
      	//cout<<"\n\t\t\t\t\t  Your  CGPA Of "<<no_of_semester<<"  Semester : "<<fixed<<setprecision(2)<<cgpa<<endl;
	   if(cgpa>=2.0){
	   	
	     cout<<"\n\n\n\n\t\t\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER"<<endl<<endl;
	     // 	PlaySound(TEXT("cong.wav"),NULL,SND_SYNC);
		  //Sleep(6000);
	     // system("cls");
		  UE_LMS obj;
	   }
	   else{
	   	
	   	    cout<<"\n\n\t\t BE ALERT! YOU ARE NOT PROMOTED TO NEXT SEMESTER";
	   	   // Sleep(6000);
	      //system("cls");
		  UE_LMS obj;
	      }
	   
	 }

//INNER ELSE
	else
	    {
	    	//system("cls");
		   UE_LMS obj;
	    
		}
           
 		
	   
}
	 
	 
	 
	
	//here BS  if conditon finish
	
	
	//HERE ENDS BS LOGIC
//________________________________________________________________________
				//here all logic of MS/MP

			  if(choice2=="MS"||choice2=="ms"||choice2=="MP"||choice2=="mp"){
			  	//system("cls");
			  //	system("COLOR 3E");
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
                    cout<<"\n\t\t\t\tWELCOME TO MS/M.PHIL STUDENT OF UNIVERSITY OF EDUCATION "<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n";		//	PlaySound(TEXT("MS.wav"),NULL,SND_SYNC);
								
				cout<<"\n\n\t\t\tDEAR STUDENT HERE YOU CAN CALCULATE  ";
				cout<<"\n\n";
				cout<<"\t\t\t1) Mid GPA"<<endl;
				cout<<"\t\t\t2) Final GPA"<<endl;
				cout<<"\t\t\t3) Final CGPA"<<endl;
				cout<<"\n\n";
				
	cout<<"\n\t\t\t*********************************************************************************************"<<endl;
				
				cout<<"\n\t\t\t1: For calculating Mid GPA enter 'M':"<<endl;
				cout<<"\n\t\t\t2: For calculating Final GPA enter 'F':"<<endl;
				cout<<"\n\t\t\t3: For calculating CGPA enter 'C':"<<endl;
				cout<<"\n\t\t\t4: To go Back Press '1'"<<endl;
				cout<<"\n\t\t\t5: Your Choice: ";
				cin>>choice3;
	cout<<"\n\n\t\t\t*********************************************************************************************"<<endl;			
				
// Mid logic for MS Degree
				  if(choice3=='M'||choice3=='m'||choice3=='F'||choice3=='f'){
				  //	system("cls");
				  //	system("COLOR B5");
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
                    cout<<"\n\t\t\t\t\t\t WELCOME TO GPA PORTAL  OF UNIVERSITY OF EDUCATION "<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n"; 
   //PlaySound(TEXT("gpa.wav"),NULL,SND_SYNC);
					cout<<"\n\n\t\t\t\tPlease Enter What is Your Current Semester :";
					cin>>semester;
					if(semester<=2){
					cout<<"\n\n\t\t Please Enter the Number of Subjects of last Semester :";
				    cin>>Var1;
					cin.ignore();
					 for(int i=0;i<Var1;i++){
						
						      cout<<"\n Enter the Name of Subject  "<<i+1<< ": ";
						      getline(cin,name);
						
						      cout<<"\n Enter the Total Marks of ~ "<<name<<": ";
						      cin>>tmarks;
						      cout<<"\n Enter the Obtaine Marks of ~ "<<name<<": ";
						      cin>>omarks;
						      cout<<"\n Enter the Credit hours of ~ "<<name<<": ";
						      cin>>credit_hours;
						      
		                   //    system("cls");
	                          cout<<"\n\t\t\t\t\t YOUR RECOR OF ' " <<name<<" ' SUBJECT ";
	                            // PlaySound(TEXT("Result.wav"),NULL,SND_SYNC);
	cout<<"\7\n\n\t\t\t*******************************************************************************************************************"<<endl;                         
	                         
						    
						      percentage= (omarks/tmarks)*100;
						      cin.ignore();
						      
						        if(percentage>=90&&percentage<=100){
								  
						      		grade="A+";
						      		grade_point=4;
						      		
												  }	        
								else if(percentage>=80&&percentage<=89){
						      		         grade="A";
						      		         float sub=percentage-80;
						      		         float multiple=sub*0.05;
											 grade_point=3.50+multiple;	
						      		
							                   }
							   else if(percentage>=70&&percentage<=79){
						      		grade="B";
						      		float sub=percentage-70;
						      	    float multiple=sub*0.05;
								    grade_point=3.00+multiple;	
						      		
							  }
							 else if(percentage>=60&&percentage<=69){
						      	grade="C";
						      	float sub=percentage-60;
						      	float multiple=sub*0.05;
								grade_point=2.50+multiple;	
						      									  }
							 else if(percentage>=50&&percentage<=59){
						      		 	grade="D";
										float sub=percentage-50;
						      		        float multiple=sub*0.05;
											grade_point=2.00+multiple;
											
										
						      		     }
							  
							  else if(percentage<50){
							  	 	grade="F";
							  	 	grade_point=0.00;
							  	 	
							  }
								  
							else
							cout<<"You are not Eligible to study";
							 //here  if end;
							 
								



                                  //here declare two variables grade_point_sum,C_sum
                                        
								     	    float grade_point_1=grade_point * credit_hours;  //here multiply
								     	    float sum1 = sum1+grade_point_1;     //sum of all grade_point and credit_hours
								     	    float sum2=sum2+ credit_hours;   // sum of all credit_hours require for division in gpa
									         
									         
									     	    gpa=sum1/sum2;
									    
										  						  
						      cout<<"\n\n\n";
		cout<<"\n\t\t\t"<< left<<"  "
        //<< setw(20)
        <<"Subject_Name"
        << left
       // << setw(18)
        << "Total_Marks"
        << left
       // << setw(18)
        << "Obtained_Marks"
        << left
      //  << setw(18)
        << "Credit_Hours"
        <<left
       // <<setw(18)
        <<"Percentage"
        <<left
       // <<setw(15)
        <<"Grade"
        <<left
       // <<setw(0)
        <<"Grade_point"
        << endl;
        
    cout<<"\n";
    
    cout<<"\n\t\t\t"<<left<<"  "
          //  << setw(23)
            << name
            << left
          //  << setw(20)
            << tmarks
            << left
          //  << setw(20)
            << omarks
            << left
          //  << setw(15)
            << credit_hours
            <<left
           // <<setw(0)
            <<percentage
            <<left
           // <<setw(14)
            <<"%";
            
            cout<<left
         //   <<setw(17)
            <<grade
            <<left
           // <<setw(0)
            <<grade_point<<endl<<"\n\n"<<endl;
            
            if(percentage<50){
							
							  	 	cout<<"\t YOU WILL REPEATE THIS SUBJECT:"<<name<<endl;
							  }
            
		cout<<"\n\n\t\t\t*******************************************************************************************************************"<<endl;				    
	}
	  // cout<<"\n\n\t\t\tYOUR 'GPA' IN THIS SEMENTER IS :"<<fixed<<setprecision(2)<< gpa<<endl;
	   if (gpa<1.7){
	   	   cout<<"\n\t'BE ALERT!' YOU ARE DROPPED IN THIS  SEMESTER ";
         // exit(0);
		               }
		else{
		   	cout<<endl;
		                }
		                
	  if(gpa>=1.7&&gpa<2.0){
	  	 cout<<"\n\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER"<<endl;
	   	 cout<<"\n \n\t 'BE ALERT!'YOU ARE PROMOTED TO NEXT SEMESTER WITH 'PROBATION'";
	   }
		   
	
	   else {
	   	cout<<"\n\t\t\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER";
	   }
	   
	   
	   
	   
	   
	  	  	   
	   
}

else if(semester>2)
{
	//system("COLOR 2A");
	cout<<"\nPlease Enter The Total Marks Of Research In Semester "<<semester<<":";
    cin>>R_marks;
	cout<<"\nPlease Enter Obtained  Marks Of Research In Semester  "<<semester<<":";
	 cin>>omarks;
	 cout<<"\nPlease Enter Credit Hours Of Research In Semester "<<semester<<":";
	 cin>>credit_hours;
	cout<<"\n\t\t\tYou Result of this Semester ~ "<<semester<<": "<<endl;
    percentage= (omarks/R_marks)*100;

						      
						        if(percentage>=90&&percentage<=100){
								  
						      		grade="A+";
						      		grade_point=4;
						      		
												  }	        
								    else if(percentage>=80&&percentage<=89){
						      		         grade="A";
						      		         float sub=percentage-80;
						      		         float multiple=sub*0.05;
											 grade_point=3.50+multiple;	
						      		
							                   }
							   else if(percentage>=70&&percentage<=79){
						      		grade="B";
						      		float sub=percentage-70;
						      	    float multiple=sub*0.05;
								    grade_point=3.00+multiple;	
						      		
							  }
							 else if(percentage>=60&&percentage<=69){
						      	grade="C";
						      	float sub=percentage-60;
						      	float multiple=sub*0.05;
								grade_point=2.50+multiple;	
						      									  }
							 else if(percentage>=50&&percentage<=59){
						      		 	grade="D";
										float sub=percentage-50;
						      		        float multiple=sub*0.05;
											grade_point=2.00+multiple;
											
										
						      		     }
							  
							  else if(percentage<50){
							  	 	grade="F";
							  	 	grade_point=0.00;
							  	 	
							  }
							  
			
							 
								



                                  //here declare two variables grade_point_sum,C_sum
                                        
								     	    float grade_point_1=grade_point * credit_hours;  //here multiply
								     	    float sum1 = sum1+grade_point_1;     //sum of all grade_point and credit_hours
								     	    float sum2=sum2+ credit_hours;   // sum of all credit_hours require for division in gpa
									         
									         
									     	    gpa=sum1/sum2;
									    
										    
	                          
cout<<"\n\n\t\t***************************************************************************************************************************"<<endl;
							       
							
						
							  
		cout<<"\n\n\n";
		cout<<"\n\t\t"<< left<<"  "
       // << setw(26)
        <<"Research_Total_Marks "
        << left
       // << setw(28)
        << "Research_Obtained_Marks "
        << left
      //  << setw(27)
        << "Reserch_Credit_Hours"
        <<left
      //  <<setw(18)
        <<"Percentage"
        <<left
       // <<setw(16)
        <<"Grade"
        <<left
      //  <<setw(0)
        <<"Grade_point"
        << endl;
        
    cout<<"\n ";
    
    cout<< "\n\t\t\t"<<left<<"  "
          //  << setw(25)
            << R_marks
            << left
           // << setw(26)
            << omarks
            << left
          //  << setw(25)
            <<credit_hours
            <<left
        //    <<setw(0)
            <<percentage
            <<left
         //   <<setw(14)
            <<"%";
            
            cout<<left
         //   <<setw(17)
            <<grade
            <<left
            //<<setw(0)
            <<grade_point<<endl<<"\n\n"<<endl;
            
            if(percentage<50){
							
							  	 	cout<<"\t\t YOU WILL REPEATE THIS SUBJECT:"<<name<<endl;
							  }
            	      
	                          
cout<<"\7\n\n\t\t****************************************************************************************************************************"<<endl;
				    
		
	  // cout<<"\n\n\t\tYOUR 'GPA' IN THIS SEMENTER IS :"<<fixed<<setprecision(2)<< gpa<<endl;
	   if (gpa<1.7){
	   	   cout<<"\n\t 'BE ALERT!' YOU ARE DROPPED IN THIS  SEMESTER ";
         // exit(0);
		               }
		else{
		   	cout<<endl;
		                }
		                
	  if(gpa>=1.7&&gpa<2.0){
	  	 cout<<"\n\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER"<<endl;
	   	 cout<<" \n\t 'BE ALERT!'YOU ARE PROMOTED TO NEXT SEMESTER WITH 'PROBATION'";
	   }
		   
		    
	   else {
	   	cout<<"\n\n\n\t\t\t\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER";
	   	//	PlaySound(TEXT("cong.wav"),NULL,SND_SYNC);
	   }

	   
	   	
	
}



}

} // HERE MS if CONDITION END 

//else{
	
//}
// HERE MS else CONDITION END 

  if(choice3=='C'||choice3=='c'){
     	//system("cls");
     //	system("COLOR 4B");
     	int no_of_semester;
		float sum_t_gpa=0;
		
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
                    cout<<"\n\t\t\t\t WELCOME TO CGPA PORTAL  OF UNIVERSITY OF EDUCATION "<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n"; 

  // PlaySound(TEXT("cgpa.wav"),NULL,SND_SYNC);
	     cout<<"\n\n\t\tPlease Enter The  'NO' Of Semester For Calculate 'CGPA : ";
	     cin>>no_of_semester;
		 	for(int i=0;i<no_of_semester;i++){
		 	cout<<"\n Please Enter your  'GPA' in  "<<i+1<<"  Semester : ";
		    cin>>t_gpa[i];
		    
		    sum_t_gpa=sum_t_gpa+t_gpa[i];
		    cgpa=  sum_t_gpa/no_of_semester;
		
            
	}
	
	
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n"; 
	
	  
	   //cout<<"\n\n\t\t\t  Your  CGPA Of "<<no_of_semester<<"  Semester : "<<fixed<<setprecision(2)<<cgpa;
	   if(cgpa>=2.0){
	     cout<<"\n\n\t\t CONGRATULATIO! YOU ARE PROMOTED TO NEXT SEMESTER";
	     //	PlaySound(TEXT("cong.wav"),NULL,SND_SYNC);
	   }
	   else{
	   	    cout<<"\n\t\t BE ALERT! YOU ARE NOT PROMOTED TO NEXT SEMESTER";
	   }
     	
	 }
							  
    cout<<"\n\n Enter '1' To Go back :";
    cin>>no;
    if(no==1){
    //	system("cls");
    	UE_LMS obj;
	}







							  
							  
							  
							  
	

       
	   
	   
	   
	   



								

			
			//___//here all ends logic of MS/MP___________________________________________________________________
			

}


	



	