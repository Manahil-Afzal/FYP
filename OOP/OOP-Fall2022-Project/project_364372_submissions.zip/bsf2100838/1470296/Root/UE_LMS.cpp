#include"UE_LMS.h"
#include"Student.h"	
#include"Staff.h"
//#include<windows.h>	
//#include<mmsystem.h>		
UE_LMS::UE_LMS(){
	
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\t\t\t\t\t| MOST WELCOME TO LEARNING MANAGEMENT SYSTEM OF UNIVERSITY OF EDUCATION |"<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n";	
//system("COLOR F2");
      //  PlaySound(TEXT("most_welcome.wav"),NULL,SND_SYNC);
        //Sleep(1200);
         //PlaySound(TEXT("boss.wav"),NULL,SND_SYNC);
			cout<<"\n\t\t\t\t Are you student or faculty member?"<<endl;
			cout<<"\n\t\t 1:  For STUDENT press 'A'"<<endl;
			cout<<"\n\t\t 2:  For STAFF press 'B'"<<endl;
			cout<<"\n\t\t 3:  Your Choice: ";
			cin>>choice;
			if(choice=='A' || choice=='a' ){
				
		//		system("cls");
		//		system("COLOR 4F");
			     Student std;
			
			   
			}
			else if(choice=='B' || choice=='b'){
		//	system("COLOR 1F");	
		//		system("cls");
				Staff std;	
				
			}
		


}
