#include"Student.h"
#include"E_SHIFT.h"
#include"M_SHIFT.h"
#include"UE_LMS.h"
//#include<windows.h>	
//#include<mmsystem.h>

	Student::Student(){
   
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\t\t\t\t\t| MOST WELCOME TO STUDENT PORTAL OF UNIVERSITY OF EDUCATION |"<<endl;
cout<<"\n\t\t\t**********************************************************************************************"<<endl;
cout<<"\n\n";	
           // PlaySound(TEXT("student.wav"),NULL,SND_SYNC);
			cout<<"\n\t\t\t\t\t In which shift you are studting?"<<endl;
			cout<<"\n\t\t1 :  For Morning press 'M'"<<endl;
			cout<<"\n\t\t2 :  For Evening press 'E'"<<endl;
			cout<<"\n\t\t3 :  To go Back Enter '1'"<<endl;
			cout<<"\n\t\t4 : Your Choice: ";
			cin>>choice1;
			
cout<<"\n\n\t\t\t**********************************************************************************************"<<endl;			
			
			if(choice1=='M' || choice1=='m'){
				
				
		     	Morning_Shift mor;
				cin.ignore();
				
			}
			else if(choice1=='E' || choice1=='e'){
				
				Evening_Shift eve;
				cin.ignore();
		
			}
			
			else{
			//	system("cls");
				
			}
		}
		
			 
		
		
		

