//main class: There is "has-a" relationship with class "Doctor".
//It take data from user using  member functions and assigne certain necesserties to the patient
 #include"doctor.h"
  #include"patient.h"
   #include<iostream>
void patient:: get_data1()

    {
        doctor d1;
        cout<<"Enter patient Record"<<endl;
        cout<<"enter your name"<<endl;
        cin>>name;
        cout<<"enter your last name"<<endl;
       cin>>lastname;
        cout<<"enter you gender"<<endl;
        cin>>gender;
          cout<<"enter your age"<<endl;
        cin>>age;
        cout<<"enter your address"<<endl;
        cin>>address;
        cout<<"enter your contact number"<<endl;
        cin>>cnumber;
        cout<<"enter YES if you have already registered otherwise NO"<<endl;
        cin>>pre_record;
        cout<<"enter your blood group"<<endl;
        cin>>bloodgroup;
    cout<<"patient name:"<<name<<endl;

        d1.doctor1();
    }
      void patient ::get_data2()
    {
doctor d2;
        cout<<"* patient Record:**"<<endl;
        cout<<"Enter your name:"<<endl;
        cin>>name;
        cout<<"Enter your last name:"<<endl;
       cin>>lastname;
        cout<<"Enter you gender:"<<endl;
        cin>>gender;
          cout<<"Enter your age:"<<endl;
        cin>>age;
        cout<<"Enter your address:"<<endl;
        cin>>address;
        cout<<"Enter your contact number:"<<endl;
        cin>>cnumber;
        cout<<"Enter YES if you have already registered otherwise NO"<<endl;
        cin>>pre_record;
        cout<<"Enter your blood group:"<<endl;
        cin>>bloodgroup;
        cout<<"patient name:"<<name<<endl;
        d2.doctor2();
    }
      void patient:: get_data3()
    {
        doctor d3;
        cout<<"Enter patient Record"<<endl;
        cout<<"Enter your name"<<endl;
        cin>>name;
        cout<<"Enter your last name"<<endl;
       cin>>lastname;
        cout<<"Enter you gender"<<endl;
        cin>>gender;
          cout<<"Enter your age"<<endl;
        cin>>age;
        cout<<"Enter your address"<<endl;
        cin>>address;
        cout<<"Enter your contact number"<<endl;
        cin>>cnumber;
        cout<<"Enter YES if you have already registered otherwise NO"<<endl;
        cin>>pre_record;
        cout<<"Enter your blood group"<<endl;
        cin>>bloodgroup;
        d3.doctor3();
    }
 