//muqadass iqbal(bsf2100847)
//maheen mueed (bsf2101188)
//maham shahid (bsf2101121)
//areeba raees (bsf2100972)
//atyia ali (bsf2100903)

//Write a program that has main class named as Hospital, Hospital has two departments.
//In each  department we take the data from Patient and Doctors and assign wards to the patient.
//Department named as class Cardiology and Orthopedics. Both departments has it’s own user-defined classes named as Doctor, Patient, wards.
//Each Doctor has it’s ID, name, phone-number, specialization. And each Patient has ID, name, phone-number, disease, and wards has w-no, type.
//In these user-defined classes you take the data from Patient and Doctor and gives appointment of  Doctor to Patients in a member function.
#include"cardiology.h"
#include"orthopedic.h"
#include"hospital.h"
#include"bill.h"
#include"nurse.h"
#include"ward.h"
#include"doctor.h"
#include"patient.h"
#include<iostream>
using namespace std;
int main() {
  hospital h1;
  doctor d1;
  bill b;
 h1.put_data();
  h1.sot();
  patient p;
  p.get_data1();
  b.bill1();
    h1.put_data();
   h1.sot();
   p.get_data2();
   b.bill2();
    h1.put_data();
   h1.sot();
p.get_data3();
b.bill3();
return 0;
}
