//main class: There is "has-a" relationship with two classes(orthopedics and cardiology). 
//There is already assigned data about hospital and it alaso take data from user.

#include<iostream>

 using namespace std;
class hospital{
      public:
    /*double contactnumber;
    string no_department;*/
    int department;

    int ID;
    string password;
    public:
    void put_data();
    void sot();
};