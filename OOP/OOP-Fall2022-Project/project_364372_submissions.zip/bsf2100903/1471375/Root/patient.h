//main class: There is "has-a" relationship with class "Doctor".
//It take data from user using  member functions and assigne certain necesserties to the patient
#include<iostream>
 using namespace std;
 class patient{
    public:
    string name;
    string lastname;
    string gender;
    int age;
    string address;
    int cnumber;
    string email;
    string pre_record;
    string bloodgroup;
   
    public:
    void get_data1();
      void get_data2();
        void get_data3();
 };