 //composite class: There is "has-a" relationship with class "Doctor".
 //It has  assigned data about nurses using some member functions.
  #include"nurse.h"
 #include<iostream>

  
  void nurse:: nurse1(){
        id1=11;
        cout<<"Name of nurse is areeba"<<endl;
        cout<<"Id of nurse id:"<<id1<<endl;
    }
      void  nurse::nurse2(){
        id2=21;
        cout<<"Name of nurse is maheen"<<endl;
        cout<<"Id of nurse id:"<<id2<<endl;
    }
      void nurse :: nurse3(){
        id3=31;
        cout<<"Name of nurse is muqadass"<<endl;
        cout<<"Id of nurse id:"<<id3<<endl;
    }
