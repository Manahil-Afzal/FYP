//main class: There is "has-a" relationship with two classes(ward and nurse).
//It has assigned data about doctors using member functions.
//composite class: There is "has-a" relationship with class (pateint)
 #include"doctor.h"
 #include"cardiology.h"
 #include"orthopedic.h"
 #include"ward.h"
 #include"nurse.h"
 
 #include<iostream>
  void doctor::  doctor1(){
          ward w1;
     nurse n1;
      id1=111;
      cout<<"Name of doctor is dr.uzma:"<<endl;
      cout<<"Id of doctor is:"<<id1<<endl;
      cout<<"Your stay timing in doctor's room is 15 mints"<<endl;
      w1.ward1();
      n1.nurse1();
  }
    void doctor:: doctor2(){
          ward w2;
    nurse n2; 
      id2=112;
      cout<<"Name of doctor is dr.atyia:"<<endl;
      cout<<"Id of doctor is:"<<id2<<endl;
      cout<<"Your stay timing in doctor's room is 10 mints"<<endl;
      w2.ward2();
      n2.nurse2();
  }
    void doctor ::  doctor3(){
          ward w3;
    nurse n3; 
      id3=113;
      cout<<"Name of doctor is dr.maham:"<<endl;
      cout<<"Id of doctor is:"<<id3<<endl;
      cout<<"Your stay timing in doctor's room is 5 mints"<<endl;
      w3.ward3();
      n3.nurse3();
  }
