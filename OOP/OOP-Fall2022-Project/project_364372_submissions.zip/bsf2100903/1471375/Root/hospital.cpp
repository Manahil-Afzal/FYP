//main class: There is "has-a" relationship with two classes(orthopedics and cardiology).
//There is already assigned data about hospital and it alaso take data from user.

 #include"hospital.h"
 #include"cardiology.h"
 #include"orthopedic.h"
 #include<iostream>
 void hospital :: put_data()
{
    cout<<"**\e UE CARE HOSPITAL \e***"<<endl;
    cout<<"**AT 241Q block,faisal town lahore** "<<endl;
    cout<<"  Help line is : 2424  "<<endl;
    cout<<"Enter your login ID :"<<endl;
    cin>>ID;
    cout<<"Enter your  Login Password:"<<endl;
    cin>>password;
    cout<<" **You are successfully login :)**"<<endl;
    cout<<"NO of department in hospital is 2"<<endl;
     cout<<"Enter 1 if you want to enter in cardiology\n Enter 2 if you want to enter orthopedics"<<endl;
    cin>>department;

}
void  hospital::sot()
{
    cardiology c1;
orthopedic r1;
    if(department==1){
        cout<<"\e** You are in cardiology department **\e"<<endl;
      c1.value_assign();
        
    }
   else if(department==2){
        cout<<"\e You are in orthopedics department* \e"<<endl;
         r1.data_assign();
        
    }
    else{
        cout<<"Enter valid number"<<endl;
    }
    
    }
    