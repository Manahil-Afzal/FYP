//simple class: This class calculate bill of patient
#include<iostream>
 using namespace std;
class bill{
    public:
    int wfee1;
    int nfee1;
    int dfee1;
    int bfee1;
    int totalcharges1;
      int wfee2;
    int nfee2;
    int dfee2;
    int bfee2;
    int totalcharges2;
      int wfee3;
    int nfee3;
    int dfee3;
    int bfee3;
    int totalcharges3;
  void  bill1();
  void  bill2();
  void  bill3();
};