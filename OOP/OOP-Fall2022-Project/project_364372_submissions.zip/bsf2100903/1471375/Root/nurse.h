 //composite class: There is "has-a" relationship with class "Doctor".
 //It has  assigned data about nurses using some member functions.
#include<iostream>
 using namespace std;
class nurse{
    public:
    string name;
    int id1;
    int id2;
    int id3;
    public:
    void nurse1();
    void nurse2();
    void nurse3();
};