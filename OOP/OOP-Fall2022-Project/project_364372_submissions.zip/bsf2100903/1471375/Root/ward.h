    //composite class: There is "has-a" relationship with class "Doctor".
    //It has  assigned data about wards using some member functions
#include<iostream>
 using namespace std;
class ward{
  public:
    int wn1;
    int nob1;
      int wn2;
    int nob2;
    int wn3;
    int nob3;
    public:
   
    void ward1();
 void ward2() ;
 void ward3();
};