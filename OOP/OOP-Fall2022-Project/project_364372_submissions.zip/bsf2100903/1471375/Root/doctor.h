//main class: There is "has-a" relationship with two classes(ward and nurse).
//It has assigned data about doctors using member functions.
//composite class: There is "has-a" relationship with class (pateint)
#include<iostream>
 using namespace std;
class doctor{
    public:
    string name;
    int id1;

     int id2;
  
     int id3;

    string timing;
    public:
  void  doctor1();
    void  doctor2();
      void  doctor3();
};
  