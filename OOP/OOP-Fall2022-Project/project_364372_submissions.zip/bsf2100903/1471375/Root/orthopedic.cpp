//composite class: There is "has-a" relationship with class "Hospital".
//It has data about orthopedics department and take data from user as well
 #include"orthopedic.h"
 #include<iostream>

  
 orthopedic::orthopedic(){
        NOR=5;
        QOD=3;
    }
void orthopedic::data_assign()
     {
         cout<<"Number of rooms in orthopedics department: "<<NOR<<endl;
        cout<<"quantity of doctor in orthopedics department: "<<QOD<<endl;
        cout<<"1:enter 1 for checkup \n 2: enter 2 for emergency \n  3: enter 3 for medical report  "<<endl;
        cin>>catagory;
        if(catagory==1){
            cout<<"GO TO ROOM NO 133"<<endl;}
            else if(catagory==2){
                cout<<"GO TO EMERGENCY ROOM NO 156"<<endl;
            }
        else if(catagory==3){
            cout<<"GO TO LAB ROOM NO 132"<<endl;
        }
        else{
            cout<<"enter a valid number"<<endl;
        }
        
}

