
//composite class: There is "has-a" relationship with class "Hospital".
//It has data about cardiology department and take data from user as well
 #include"cardiology.h"
 #include<iostream>
  cardiology:: cardiology(){
        NOR1=5;
        QOD1=3;
    }
 void cardiology::  value_assign()
  
     {
  cout<<"Number of rooms in cardiology department is : "<<NOR1<<endl;
        cout<<"quantity of doctor in cardiology department: "<<QOD1<<endl;
        cout<<"1:enter 1 for checkup \n 2:enter 2 for emergency \n 3:enter 3 for medical report  "<<endl;
        cin>>catagory1;
        if(catagory1==1){
            cout<<"GO TO ROOM NO 143"<<endl;}
            else if(catagory1==2){
                cout<<"GO TO EMERGENCY ROOM NO 165"<<endl;
            }
        else if(catagory1==3){
            cout<<"GO TO LAB ROOM NO 124"<<endl;
        }
        else{
            cout<<"enter a valid number"<<endl;
        }
        
}
