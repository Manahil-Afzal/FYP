//composite class: There is "has-a" relationship with class "Hospital".
//It has data about orthopedics department and take data from user as well
#include<iostream>
 using namespace std;
class orthopedic{
 public:
    int NOR;
    int QOD;
    int catagory;
    public:
    orthopedic();
    void data_assign();
};