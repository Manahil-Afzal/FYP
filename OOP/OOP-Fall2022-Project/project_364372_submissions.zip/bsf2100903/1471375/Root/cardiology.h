
//composite class: There is "has-a" relationship with class "Hospital"
//.It has data about cardiology department and take data from user as well
#include<iostream>
 using namespace std;
 class cardiology{
 public:
    int NOR1;
    int QOD1;
    int catagory1;
    public:
    cardiology();
    void value_assign();
};