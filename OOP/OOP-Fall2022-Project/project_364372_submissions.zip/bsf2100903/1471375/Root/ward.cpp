    //composite class: There is "has-a" relationship with class "Doctor".
    //It has  assigned data about wards using some member functions
  #include"ward.h"
 #include<iostream>
  void ward:: ward1(){
    
        wn1=101;
        nob1=3;
        cout<<"Ward number is:"<<wn1<<endl;
        cout<<"Ward type is GENERAL"<<endl;
        cout<<"Number of beds is:"<<nob1<<endl;
    }
        void ward:: ward2(){
        wn2=102;
        nob2=4;
        cout<<"Ward number is:"<<wn2<<endl;
        cout<<"Ward type is emergency"<<endl;
        cout<<"Number of beds is:"<<nob2<<endl;
    }
        void ward :: ward3(){
        wn3=103;
        nob3=5;
        cout<<"Ward number is:"<<wn3<<endl;
        cout<<"Ward type is SPECIAL"<<endl;
        cout<<"Number of beds is:"<<nob3<<endl;
    }
