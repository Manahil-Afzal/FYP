//simple class: This class calculate bill of patient
 #include"bill.h"
 #include<iostream>

  
void  bill::  bill1(){
        wfee1=2000;
        nfee1=1000;
        dfee1=3000;
        bfee1=500;
        totalcharges1=wfee1+nfee1+dfee1+bfee1;
        cout<<"your total charges is:"<<totalcharges1<<endl;
        cout<<"**THANK YOU :)***"<<endl;
        
    }
     void bill:: bill2(){
        wfee2=3000;
        nfee2=1500;
        dfee2=5000;
        bfee2=800;
        totalcharges2=wfee2+nfee2+dfee2+bfee2;
        cout<<"your total charges is:"<<totalcharges2<<endl;
        cout<<"**THANK YOU :)***"<<endl;
        
    }
     void bill::bill3(){
        wfee3=4000;
        nfee3=500;
        dfee3=4000;
        bfee3=600;
        totalcharges3=wfee2+nfee2+dfee2+bfee2;
        cout<<"your total charges is:"<<totalcharges3<<endl;
        cout<<"**THANK YOU :)***"<<endl;
        
    }
    
    
