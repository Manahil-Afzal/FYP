// In this Project we are find and update information about students and class arrangements.
// Teachers have the same problems as administrators when they use a manual system,
//like not being able to keep track of students grades, attendance, and so on

#include<iostream>
using namespace std;

class School{                //school class for storing the information of school
	public:
		char name[20];
		char add[20];
		char status[10];
		void put();
		void display();
};

void School::display(){                      // Shows data on the console
	//system("cls");
	cout << "\n***********************************************School Details:********************************************************\n\n";	
	cout <<"Name of the School is :"<<name<<endl;
	cout<<"Address of School is :"<<add<<endl;
	cout<<"Status of School is :"<<status<<endl;
}
void School::put(){                        // Get data of school from the user or administration
	//system("cls");
	cout << "\n***********************************************School Details:********************************************************\n\n";	
	cout <<"Name of the School is :"<<endl;
	cin>>name;
	cout<<"Address of School is :"<<endl;
	cin>>add;
	cout<<"Status of School is :"<<endl;
	cin>>status;
}

class student {	            // This is base class of parent class 
protected:					//Student class for storing Records in the student file
	char name[30];
	int rollNo;
	char fatherName[30];
	char motherName[30];
	char rel[10];
	char address[80];
	public:                    //Student having three methods
		void control_panel();
		void STD_getDetails();
		void STD_printDetails();	};
void student :: control_panel()              // main method that is displays very frist on screen
{   //system("cls");
    cout<<"------------------------------------------------------------------------------------------------------------------------------------------------------------------------"<<endl;
    cout<<"\n\n\t\t\t\t\t\t\t\t  Welcome To School Management System "<<endl;
	cout<<"\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------"<<endl;
	cout<<"\n 1. School: ";	
	cout<<"\n 2. Student:";
    cout<<"\n 3. Course:";
    cout<<"\n 4. Class Rooms:";
    cout<<"\n 5. Grade Book:";
    cout<<"\n 6. Parents:";
    cout<<"\n 7. Fees:";
    cout<<"\n 8. Employee:";
    cout<<"\n 9. Attendance:";
    cout<<"\n 10.Exit";
	cout<<"\n Enter Your Choice : ";
}	
	
void student::STD_getDetails(){    // Get details of the students by user
	//system("cls");
	cout << "\n***********************************************Student details:********************************************************\n\n";
	cout << "Enter your name: " ;
	cin >> name;
	cout << "Enter your Roll No: ";
	cin >> rollNo;
	cout << "Enter your Father's Name: ";
    cin>>fatherName;
    cout << "Enter your Mother's Name: ";
    cin>> motherName;
    cout << "Enter your Address: " ;
    cin>>address;
}
void student::STD_printDetails(){  // Displays data  which get from users
	cout << "\n\n\t\tStudent details:\n";
	cout << "Name:"<< name << endl ;
	cout << "RollNo:" << rollNo<<endl;
	cout << "Father's Name:" << fatherName<<endl;
	cout << "Mother's Name:" << motherName<<endl;
	cout << "Address:" << address;
}
class parent:public student{    // this is child class of student (parent class)
	public:		
void getdata();
void printdata();
};
void parent::getdata(){       // method to get data of student's parents
//	system("cls");	
	cout<<"\n\n\tInsert Details:"<<endl;
	cout << "RollNo:" ;
	cin>> rollNo;
	cout << "Father's Name:";
	cin>> fatherName;
	cout << "Mother's Name:" ;
	cin>> motherName;
	cout << "Relationship:";
	cin>>rel;
	}
void parent::printdata()       // use to display data get by the detdata method
{
	cout << "\n\n\t\tParent Details:\n";
	cout << "RollNo:" << rollNo<<endl;
	cout << "Father's Name:" << fatherName<<endl;
	cout << "Mother's Name:" << motherName<<endl;
}
class gradebook{          // gradebook class for storing the grading score of students
	public:
	int rollno;
	char stdname[20];
	int p_marks,c_marks, m_marks,e_marks,cs_marks;;
	void getdata();
	void showdata();
};	
void gradebook::getdata()   // geting data of grading
{   //system("cls");
	cout << "\n*********************************************Class Rooms Details:*******************************************************\n\n";
	cout<<"\nEnter The roll number of student ";
	cin>>rollno;
	cout<<"\n\nEnter The Name of student ";
	cin>>stdname;
	cout<<"\nEnter The marks in physics out of 100 : ";
	cin>>p_marks;
	cout<<"\nEnter The marks in chemistry out of 100 : ";
	cin>>c_marks;
	cout<<"\nEnter The marks in maths out of 100 : ";
	cin>>m_marks;
	cout<<"\nEnter The marks in english out of 100 : ";
	cin>>e_marks;
	cout<<"\nEnter The marks in computer science out of 100 : ";
	cin>>cs_marks;
}
void gradebook::showdata()                // displays data store in getdata
{   cout << "\n\n\t\tGrade Book of Student:\n";
	cout<<"\nRoll number of student : "<<rollno;
	cout<<"\nName of student : "<<stdname;
	cout<<"\nMarks in Physics : "<<p_marks;
	cout<<"\nMarks in Chemistry : "<<c_marks;
	cout<<"\nMarks in Maths : "<<m_marks;
	cout<<"\nMarks in English : "<<e_marks;	
	cout<<"\nMarks in Computer Science :"<<cs_marks;}
class employee {     // employee class for storing the information of employees
    private:
    char Name[15];
    char des[15];
    int ID,age ;
    public:
    void func_input();
    void func_output();
};
void employee :: func_input(){            // method to get data of employee
	//system("cls");
	cout<<"\n\n---------------------------------------------Insert Details-------------------------------------------------------------\n\n";
    cout<<"Enter employee's name:"<<endl ;
    cin>>Name ;
    cout<<"Enter employee's ID:"<<endl ;
    cin>>ID;
    cout<<"Enter employee's age:"<<endl ;
    cin>>age ;
    cout<<"Enter employee's designation:"<<endl ;
    cin>>des;
} 
void employee ::func_output(){     // displays employees information
//	system("cls");
	cout << "\n***********************************************Employee Details:********************************************************\n\n";
    cout<<"Employee's name:"<<Name<<endl ;
    cout<<"Employee's ID:"<<ID<<endl ;
    cout<<"Employee's Age:"<<age<<endl ;
    cout<<"Employee's Designation:"<<des<<endl ;   }
class fees{           // fees class for storing the information of student's fees
	public:
	char name[15];
	char pname[15];
	int rollno;
	int tfees;
	int pfees;
	int rfees;
	void get_data();
	void display_data();		
};	
void fees::get_data(){          // get details of student fees 
//	system("cls");
	cout << "\n***********************************************Insert Fees details:********************************************************\n\n";
	cout<<"Enter your Roll No:";
	cin>>rollno;
	cout<<"Enter Student Name:";
	cin>>name;
	cout<<"Enter Guardien Name:"<<endl;
	cin>>pname;
	cout<<"Enter your Total Fees:";
	cin>>tfees;
	cout<<"Enter Paid Fees:";
	cin>>pfees;
	rfees=tfees-pfees ;	}
void fees::display_data(){          // calculated & displays fees information 
	cout << "\n*************************************************Fees details:********************************************************\n\n";
	cout<<"Roll No:"<<rollno<<endl;
	cout<<"Student Name:"<<name<<endl;
	cout<<"Guardien Name:"<<pname<<endl;
	cout<<"Total Fees:"<<tfees<<endl;
	cout<<"Paid Fees:"<<pfees<<endl;
	cout<<"Remaining Fees:"<<rfees<<endl;	}
class Course          // this is base course class
{
    public:
    char classs[10];	
    char name[10];
    int Id;
void input();
};
class IT:virtual public Course  // child class
{
    public:
    void display();
};
class CS:virtual public Course   // child class
{    public:
    void display();
   
};

class SOSCourse:public IT,public CS   // child class
{
    public:
    void display();
   
};
void Course::input()        // get course details
    { //  system("cls");
        cout << "\n***********************************************Course details:********************************************************\n\n";
        cout<<"\nEnter the course Id:";
        cin>>Id;
        cout<<"Enter the course name:";
        cin>>name;
        cout<<"In which class do you read:";
        cin>>classs;     
    }
void CS::display()          // displays course details
        {  // system("cls");
        cout<<"The course Id : "<<Id<<endl;
        cout<<"Course Name:"<<name;      }
        
void IT::display(){  
    	//system("cls");
        cout<<"The Course Id: "<<Id<<endl;
        cout<<"Course Name:"<<name;   
    }
		
void SOSCourse::display()    
	 {   //system("cls");
        cout << "\n***********************************************Course details:********************************************************\n\n";
		cout<<"This is Secondary Class: "<<endl;
        cout<<"The Course Id : "<<Id<<endl;
        cout<<"Course name:"<<name<<endl;      
    }
class classroom{      // //classroom class for storing the information of classrooms in school
	public:
	char tname[10];
	int id;	
	int amount;
	void put_detail();
	void display_detail();
};
void classroom :: put_detail(){ 
   // system("cls");
   	cout << "\n*********************************************Class Rooms Details:*******************************************************\n\n";
	cout<<"Enter your class incharge name";
	cin>>tname;
	cout<<"Enter your Class Id:";
	cin>>id;
	cout<<"How many student have in this class:";
	cin>>amount;	}
void classroom :: display_detail(){
    cout << "\n\n\t\tClass Rooms details:\n";
	cout<<"Incharge name :"<<tname<<endl;
	cout<<"Class Id :"<<id<<endl;
	cout<<"Amount of Students :"<<amount;	}
class attendance{             // attendance class 
	public:
	int roll;
	int id;
	char day[10];
	char sname[15];
	char a;
	void student();
	void teacher();	
};
void attendance::student(){      // method to store student attendance
//	system("cls");
	cout << "\n***********************************************Mark Your Attendance:********************************************************\n\n";
	cout<<"What is day today :";
	cin>>day;
	cout<<"Enter your name :";
	cin>>sname;
	cout<<"Enter your Roll No Or ID :";
	cin>>id;
	cout<<"Mark Your Attendance :";
	cin>>a;

	cout << "\n***********************************************Attendance Deatils As a Student: :**************************************************\n\n";
	cout<<"What is day today :"<<day<<endl;
	cout<<"Your name :"<<sname<<endl;
	cout<<"Your Roll No \n\t\t or ID :"<<id<<endl;
	cout<<"Your Attendance :"<<a;	
}
void attendance::teacher(){        // method to store teacher attendance
//	system("cls");
	cout << "\n***********************************************Mark Your Attendance:********************************************************\n\n";
	cout<<"What is day today :";
	cin>>day;
	cout<<"Enter your name :";
	cin>>sname;
	cout<<"Enter your Roll No or ID :";
	cin>>id;
	cout<<"Mark Your Attendance :";
	cin>>a;
	cout << "\n***********************************************Attendance Deatils Of teachers: :********************************************************\n\n";
	cout<<"What is day today :"<<day<<endl;
	cout<<"Your name :"<<sname<<endl;
	cout<<"Your Roll No \n\t\t or ID :"<<id<<endl;
	cout<<"Your Attendance :"<<a;	
}

int main()   // main function to call all classes
{   student std;
    SOSCourse sc;
    School sh;
    classroom cr;
    gradebook gb;
	int choice;
//	system("cls");
	char x;
	std.control_panel();
	cin>>choice;
	switch(choice)     // choice a desire option to get and put details
	{
		case 1:
			do      
			{ int i;
            sh.put();      // school class
            sh.display();
			i++;
			cin>>x;
		    }while(x == 'y');
			break;
		case 2:
	  		std.STD_getDetails();    // students information
	    	std.STD_printDetails();
			break;	
		case 3:
			sc.input();        // Course Class
			sc.display();	
			break;
		case 4:
			cr.put_detail();     // classroom class
			cr.display_detail();	
			break;	
		case 5:	
		char ch;
		do	{
		//system("cls");
		cout<<"\n\n--------------------------------------------------MAIN MENU-------------------------------------------------------------";
		cout<<"\n\n\t01.  ENTRY/EDIT MENU";
		cout<<"\n\n\t02.  SHOW RESULT MENU";
		cout<<"\n\n\t03. EXIT";
		cout<<"\n\n\tPlease Select Your Option: ";
		cin>>ch;
		switch(ch)
		{
			case '1': gb.getdata();  // Result Details
				break;
			case '2':  //system ("cls") ;
			gb.showdata();
				break;
			case '3':
				break;
			default :cout<<"\a";
		}
        }while(ch!='3')  ;
	    case 6: // to hide the parent class
		/*parent par;
		par.getdata();
		par.printdata();	
		break;*/   	
		case 7:     // Students Fees details
		fees fe;
		fe.get_data();
		fe.display_data();			
		break;
				
		case 8:        // Working Staff Details
		employee emp;
		
		do	{
		char ch;
	//	system("cls");
		cout<<"\n\n--------------------------------------------------MAIN MENU-------------------------------------------------------------";
		cout<<"\n\n\t01. Insert Information";
		cout<<"\n\n\t02. Display Information";
		cout<<"\n\n\t03. EXIT";
		cout<<"\n\n\tPlease Select Your Option: ";
		cin>>ch;
		switch(ch)             // working staff information
		{
			case '1': 
		    emp.func_input(); 
			break;
			case '2': 
			emp.func_output();
			break;
			case '3':
				break;
			default :cout<<"\a";
		}
        }while(ch!='3')  ;
	break;
		case 9:
		attendance att;	
		do	{
		char ch;    // attendance class called
	//	system("cls");
		cout<<"\n\n--------------------------------------------------MAIN MENU-------------------------------------------------------------";
		cout<<"\n\n\t01. Students";
		cout<<"\n\n\t02. Teachers";
		cout<<"\n\n\t03. EXIT";
		cout<<"\n\n\tPlease Select Your Option: ";
		cin>>ch;
		switch(ch)
		{
			case '1': // get all students attendance
		    att.student(); 
			break;
			case '2': 
			att.teacher();      // get all teachers attendance
			break;
			case '3':
				break;
			default :cout<<"\a";
		}
        }while(ch!='3')  ;
	break;	
	//	case 10:	
		//	exit(0);        // default class calls
		default:
			cout<<"\n\n Invalid Value...Please Try Again...";
	}
return 0;
}