
//Management of Rent a Car System
class Management
{
protected:
	//Available Driver's Details Declaration 
    string drivername1 = "Ali", drivername2 = "Ahmed", drivername3 = "Fahad";
    int id1 = 25, id2 = 30, id3 = 35;
    int experience1 = 3, experience2 = 6, experience3 = 9;
public:
    //Home Page
	void frontpage()
    {
        cout << "===============================================================================" << endl;
        cout << "|                                                                             |" << endl;
        cout << "|                          WELCOME TO OUR RENTAL SYSTEM                       |" << endl;
        cout << "|                                                                             |" << endl;
        cout << "===============================================================================" << endl;
        //system("Pause");

        cout << "\n\n      CREATED BY:           BSIT (E)" << endl << endl;
        cout << "                         Hassan Sheikh (0815)" << endl;
        cout << "                         Sajeel Sarwar (0845)" << endl;
        cout << "                         Areeba Hameed (0937)" << endl;

        //system("Pause");
    }
    //Driver's Information
    void available_drivers()
    {
        cout << "We have the following finest drivers available" << endl;
    }
    void show_driver1_info()
    {
        cout << "Driver 1: " << endl;
        cout << "Name: " << drivername1 << endl;
        cout << "Id: " << id1 << endl;
        cout << "Experience: " << experience1 << " years" << endl;
    }
    void show_driver2_info()
    {
        cout << "------------------------------------------------------------------------------" << endl;
        cout << "Driver 2: " << endl;
        cout << "Name: " << drivername2 << endl;
        cout << "Id: " << id2 << endl;
        cout << "Experience: " << experience2 << " years" << endl;
    }
    void show_driver3_info()
    {
        cout << "------------------------------------------------------------------------------" << endl;
        cout << "Driver 3: " << endl;
        cout << "Name: " << drivername3 << endl;
        cout << "Id: " << id3 << endl;
        cout << "Experience: " << experience3 << " years" << endl;
        cout << "------------------------------------------------------------------------------" << endl;

    }
    //Supervisor's Details
    void supervisor_info()
    {

        cout << "The information about trip supervisor:" << endl;
        cout << "Name is: Fawad" << endl;
        cout << "Experience is: 12 years" << endl;
        cout << "Supervising trips knowing the best routes since 2010" << endl;
    }
};