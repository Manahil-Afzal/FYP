#include"ClassManagement.h"
#include"ClassDriver.h"
#include"ClassCustomer.h"
#include"ClassTrip.h"
#include"ClassCar.h"
#include"ClassRent.h"
#include"ClassVSedanRent.h"
#include"ClassVTruckRent.h"
#include"ClassVSUVRent.h"
#include"ClassVHatchbackRent.h"
#include"ClassRSedanRent.h"
#include"ClassRTruckRent.h"
#include"ClassRHatchbackRent.h"
void start()
{
    int totalrent;
    driver obj1;	  //Object of Driver class created
    obj1.frontpage(); //Prints Front Page 
    //system("cls");
    obj1.supervisor_info();  //Prints Supervisor Details
    //system("Pause");
    //system("cls");
    obj1.available_drivers();  //Print Drivers that are available
    obj1.show_driver1_info();  //Print Driver 1 details
    obj1.show_driver2_info();  //Print Driver 2 details
    obj1.show_driver3_info();  //Print Driver 3 details
    obj1.choose_driver();	   //Driver Selection
    //system("Pause");
    //system("cls");
    trip obj5;				   //Object of Trip class created
    obj5.dates();			   //Date function called
    int custplan; 			   //Plan Selection
    cout << "Choose Plan:" << endl;
    cout << "1) Regular" << endl;
    cout << "2) Vip" << endl;
    cin >> custplan;
    Car obj;

    if (custplan == 1)  //If Regular Plan is selected
        obj.regularchoose_car();
    switch (obj.Rdecision)
    {
    case 1:
        RSedanRent obj6; //Regular Sedan
        obj6.CalcRent();
        totalrent = obj6.total_rent;
        break;
    case 2:
        RTruckRent obj7; //Regular Truck
        obj7.CalcTruckRent();
        totalrent = obj7.total_rent;
        break;
    case 3:
        RSUVRent obj8; //Regular SUV
        obj8.CalcSuvRent();
        totalrent = obj8.total_rent;
        break;
    case 4:
        RHatchbackRent obj9; //Regular Hatchback
        obj9.CalcHatchbackRent();
        totalrent = obj9.total_rent;
        break;

    //default:
        //cout << "Wrong Option..." << endl;
    }
    if (custplan == 2) //If VIP Plan is selected
        obj.vipchoose_car();
    switch (obj.Vdecision)
    {
    case 1:
        VSedanRent obj10; //VIP Sedan
        obj10.CalcRent();
        totalrent = obj10.total_rent;
        break;
    case 2:
        VTruckRent obj11; //VIP Truck
        obj11.CalcTruckRent();
        totalrent = obj11.total_rent;
        break;
    case 3:
        VSUVRent obj12; //VIP SUV
        obj12.CalcSuvRent();
        totalrent = obj12.total_rent;
        break;
    case 4:
        VHatchbackRent obj13; //VIP Hatchback
        obj13.CalcHatchbackRent();
        totalrent = obj13.total_rent;
        break;
    case 5:
        LuxuryRent obj14; //VIP Luxury
        obj14.CalcLuxuryRent();
        totalrent = obj14.total_rent;

    //default:
        //cout << "Wrong Option..." << endl;

    }




    //RECIEPT

    cout << "\n\n===========================================================================" << endl;
    cout << "|                                                                         |" << endl;
    cout << "|                                  RECIEPT                                |" << endl;
    cout << "|                                                                         |" << endl;
    cout << "===========================================================================" << endl;
	//Showing Customer's Details
    cout << "\nCustomer Name= " << obj5.custom1.fcustomer << " " << obj5.custom1.lcustomer << endl;
    cout << "Age= " << obj5.custom1.customer_age << endl;
    cout << "Gender= " << obj5.custom1.gender << endl;
    cout << "CNIC= " << obj5.custom1.cnic << endl;
    cout << "Contact Number= " << obj5.custom1.cell_number << endl;
    cout << endl;
    cout << "------------------------------------------------------------------------------" << endl;
    //Showing Trip Details
    cout << "\n                       Starting date= " << obj5.starting_date << "/" << obj5.starting_month << "/" << obj5.starting_year << endl;
    cout << "                         Ending date= " << obj5.ending_date << "/" << obj5.ending_month << "/" << obj5.ending_year << endl;
    cout << endl;
    cout << "------------------------------------------------------------------------------" << endl;
    //Showing Driver's Information
    cout << "Driver's Information:" << endl;
    if (obj1.driver_id == 25)
        obj1.show_driver1_info();
    if (obj1.driver_id == 30)
        obj1.show_driver2_info();
    if (obj1.driver_id == 35)
        obj1.show_driver3_info();
    //Showing Category Selected     
    cout << "Vehicle Category: ";
    if (obj.Rdecision == 1)
        cout << "SEDAN";
    if (obj.Vdecision == 1)
        cout << " VIP SEDAN ";
    if (obj.Rdecision == 2)
        cout << "TRUCK";
    if (obj.Vdecision == 2)
        cout << " VIP TRUCK ";
    if (obj.Rdecision == 3)
        cout << "SUV";
    if (obj.Vdecision == 3)
        cout << " VIP SUV ";
    if (obj.Rdecision == 4)
        cout << "HATCHBACK";
    if (obj.Vdecision == 4)
        cout << " VIP HATCHBACK ";
    if (obj.Vdecision == 5)
        cout << "LUXURY";

	//Showing Rent
    cout << endl;
    cout << "------------------------------------------------------------------------------" << endl;
    cout << "Total Rent= " << totalrent << endl;
    //system("cls");
}
