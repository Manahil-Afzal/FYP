//Driver Selection
class driver : public Management
{
public:
    int driver_id;
    //Management obj8;
    void choose_driver()
    {

        cout << "Choose your Driver's id out of the above options: ";
        cin >> driver_id;
        switch (driver_id)
        {
        case 25:
            cout << "Driver no.1 is selected" << endl;
            break;

        case 30:
            cout << "Driver no.2 is selected" << endl;
            break;

        case 35:
            cout << "Driver no.3 is selected" << endl;
            break;
        default:
            cout << "Wrong option" << endl;
            cout << "Enter again:" << endl;
            cin >> driver_id;
        }
    }
};