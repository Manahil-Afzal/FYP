class Rent
{
protected:
    int Roption, Voption;
    int totalnumber_of_days;
    int per_day_rent;
};
class LuxuryRent :public Rent //Rent of Luxury Category
{
public:
    int total_rent;
    void CalcLuxuryRent()
    {
        cout << "Enter option of the Luxury Car to find rent: ";
        cin >> Voption;
        if (Voption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 40000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of BMW i8 is: " << total_rent;
        }
        if (Voption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            {   per_day_rent = 60000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Lamborghini Aventador is: " << total_rent;
            }
        }
        if (Voption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            {   per_day_rent = 80000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Rolls Royce Ghost is: " << total_rent;
            }
        }
    }
};





