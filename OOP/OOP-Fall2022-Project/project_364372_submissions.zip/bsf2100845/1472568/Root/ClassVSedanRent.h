class VSedanRent :public Rent  //Rent of VIP Sedan Category 
{
public:
    int total_rent;
    void CalcRent()
    {
        cout << "Enter option of the Sedan Car to find rent: ";
        cin >> Voption;
        if (Voption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 10000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Mark X is: " << total_rent;
        }
        if (Voption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            {   per_day_rent = 20000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Crown RS Turbo is: " << total_rent;
            }
        }
        if (Voption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            {   per_day_rent = 30000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Mercedez Benz is: " << total_rent;
            }
        }
    }
};