
class RSedanRent :public Rent  //Rent of Regular Sedan Category
{
public:
    int total_rent;
    void CalcRent()
    {
        cout << "Enter option of the Sedan Car to find rent: ";
        cin >> Roption;
        if (Roption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 1000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of civic is: " << total_rent;
        }
        if (Roption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            {   per_day_rent = 2000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of HyundaiElantra is: " << total_rent;
            }
        }
        if (Roption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            {   per_day_rent = 3000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Toyota Grande is: " << total_rent;
            }
        }
    }
};