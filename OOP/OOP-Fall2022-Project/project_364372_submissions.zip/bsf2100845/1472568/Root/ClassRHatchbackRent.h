class RHatchbackRent :public Rent  //Rent of Regular Hatchback Category
{
public:
    int total_rent;
    void CalcHatchbackRent()
    {
        cout << "Enter option of the Hatchback to find rent: ";
        cin >> Roption;
        if (Roption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 3000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of KIA Sportage is: " << total_rent;
        }

        if (Roption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 6000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Hyundai Tucson is: " << total_rent;
            }
        }
        if (Roption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 8000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of MG HS is: " << total_rent;
            }
        }
    }
};
