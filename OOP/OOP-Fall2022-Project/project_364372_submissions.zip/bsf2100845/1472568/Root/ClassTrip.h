//Trip Details
class trip {
public:
    Customer custom1;
    int starting_date, ending_date;
    string starting_month, ending_month;
    int starting_year, ending_year;
    void dates()
    {
        cout << "Enter starting date of the trip in this format (DD MM YYYY): ";
        cin >> starting_date >> starting_month >> starting_year;
        cout << "Enter ending date of the trip in this format (DD MM YYYY): ";
        cin >> ending_date >> ending_month >> ending_year;
        custom1.get_data();

    }
};