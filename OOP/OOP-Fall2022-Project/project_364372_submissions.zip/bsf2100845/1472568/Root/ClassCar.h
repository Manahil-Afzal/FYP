class Car {

public:
    int Rdecision, Vdecision; //Plans available
    void regularchoose_car()  //Regular Plan
    {
        cout << "Our Regular Plan has the following categories:" << endl;
        cout << "Press 1 for Sedan" << endl;
        cout << "Press 2 for Truck" << endl;
        cout << "Press 3 for SUV" << endl;
        cout << "Press 4 for Hatchback" << endl;
        cin >> Rdecision;
        if (Rdecision == 1)
        {
            cout << "Sedan is selected category,we have the following ones available:" << endl;
            cout << "1) Honda Civic with a rent of 1000/day?" << endl;
            cout << "2) Hyundai Elantra with a rent of 2000/day?" << endl;
            cout << "3) Toyota Grande with a rent of 3000/day?" << endl;
        }
        if (Rdecision == 2)
        {
            cout << "Truck is the selected category,we have the following ones avaiable:" << endl;
            cout << "1) Box truck with a rent of 2000/day" << endl;
            cout << "2) Cab truck with a rent of 4000/day?" << endl;
            cout << "3) Flatbed truck with a rent of 6000/day?" << endl;
        }

        if (Rdecision == 3)
        {
            cout << "SUV is the selected category,we have the following ones avaiable:" << endl;
            cout << "1) Toyota Fortuner with a rent of 2500/day?" << endl;
            cout << "2) Prado TX with a rent of 5000/day?" << endl;
            cout << "3) Lexus LX 600 with a rent of 7000/day?" << endl;
        }

        if (Rdecision == 4)
        {
            cout << "Hatchback is the selected category,we have the following ones available:" << endl;
            cout << "1) KIA Sportage with a rent of 3000/day?" << endl;
            cout << "2) Hyundai Tucson with a rent of 6000/day?" << endl;
            cout << "3) MG HS with a rent of 8000/day?" << endl;
        }
    }

    void vipchoose_car()  //VIP Plan
    {
        cout << "Press 1 for Sedan" << endl;
        cout << "Press 2 for Truck" << endl;
        cout << "Press 3 for SUV" << endl;
        cout << "Press 4 for Hatchback" << endl;
        cout << "Our VIP Plan has luxury category as well" << endl;
        cout << "Press 5 for Luxury" << endl;
        cin >> Vdecision;
        if (Vdecision == 1)
        {
            cout << "Sedan is selected category,we have the following ones available:" << endl;
            cout << "1) Mark X with a rent of 10000/day?" << endl;
            cout << "2) Crown RS Turbo with a rent of 20000/day?" << endl;
            cout << "3) Mercedes Benz with a rent of 30000/day?" << endl;
        }
        if (Vdecision == 2)
        {
            cout << "Truck is the selected category,we have the following ones avaiable:" << endl;
            cout << "1) Box truck with a rent of 2000/day" << endl;
            cout << "2) Cab truck with a rent of 4000/day?" << endl;
            cout << "3) Flatbed truck with a rent of 6000/day?" << endl;
        }

        if (Vdecision == 3)
        {
            cout << "SUV is the selected category,we have the following ones avaiable:" << endl;
            cout << "1) Land Cruiser V8 with a rent of 25000/day?" << endl;
            cout << "2) Range Rover Auto-Biography with a rent of 50000/day?" << endl;
            cout << "3) GMC with a rent of 70000/day?" << endl;
        }

        if (Vdecision == 4)
        {
            cout << "Hatchback is the selected category,we have the following ones available:" << endl;
            cout << "1) KIA Sorento with a rent of 3000/day?" << endl;
            cout << "2) Raptor FORD with a rent of 6000/day?" << endl;
            cout << "3) Carnival with a rent of 8000/day?" << endl;
        }
        if (Vdecision == 5)
        {
            cout << "Luxury is the selected category,we have the following ones available:" << endl;
            cout << "1) BMW i8 with a rent of 40000/day " << endl;
            cout << "2) Lamborghini Aventador with a rent of 60000/day" << endl;
            cout << "3) Rolls Royce Ghost with a rent of 80000/day" << endl;
        }
    }

};