class VTruckRent :public Rent  //Rent of VIP Truck Category
{
public:
    int total_rent;
    void CalcTruckRent()
    {
        cout << "Enter option of the Truck to find rent: ";
        cin >> Voption;
        if (Voption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 2000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Box Truck is: " << total_rent;
        }

        if (Voption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 4000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Cab Truck is: " << total_rent;
            }
        }
        if (Voption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 6000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Flatbed Truck is: " << total_rent;
            }

        }
    }
};