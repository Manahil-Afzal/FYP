class RTruckRent :public Rent  //Rent of Regular Truck Category
{
public:
    int total_rent;
    void CalcTruckRent()
    {
        cout << "Enter option of the Truck to find rent: ";
        cin >> Roption;
        if (Roption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 2000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Box Truck is: " << total_rent;
        }

        if (Roption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 4000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Cab Truck is: " << total_rent;
            }
        }
        if (Roption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 6000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Flatbed Truck is: " << total_rent;
            }

        }
    }
};
class RSUVRent :public Rent  //Rent of Regular SUV Category
{
public:
    int total_rent;
    void CalcSuvRent()
    {
        cout << "Enter option of the Suv to find rent: ";
        cin >> Roption;
        if (Roption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 2500;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Toyota Fortuner is: " << total_rent;
        }

        if (Roption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 5000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Prado TX is: " << total_rent;
            }
        }
        if (Roption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 7000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Lexus LX 600 is: " << total_rent;
            }

        }
    }
};