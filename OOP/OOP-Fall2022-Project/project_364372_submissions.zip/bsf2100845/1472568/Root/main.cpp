#include<iostream>
using namespace std;
#include"StartFunction.h"
int main()
{
	//Trip Confirmation
    int choice;
    cout << "===============================================================================" << endl;
    cout << "|                                                                             |" << endl;
    cout << "|                          Press 1 to Continue the Trip                       |" << endl;
    cout << "|                                 Press 0 to Exit                             |" << endl;
    cout << "|                                                                             |" << endl;
    cout << "===============================================================================" << endl;

    cin >> choice;

    switch (choice)
    {
    case 1:
        start();

        break;
    case 0:
        cout << "Thank you";
        break;
    default:
        cout << "Invalid Command" << endl;
    }

}