class VHatchbackRent :public Rent  //Rent of VIP Hatchback Category
{
public:
    int total_rent;
    void CalcHatchbackRent()
    {
        cout << "Enter option of the Hatchback to find rent: ";
        cin >> Voption;
        if (Voption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 3000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of KIA Sorento is: " << total_rent;
        }

        if (Voption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 6000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Raptor FORD is: " << total_rent;
            }
        }
        if (Voption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 8000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Carnival is: " << total_rent;
            }
        }
    }
};