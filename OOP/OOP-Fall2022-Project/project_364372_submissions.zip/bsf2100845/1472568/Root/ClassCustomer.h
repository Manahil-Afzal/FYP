//Customer's Detail
class Customer
{
public:
    string fcustomer, lcustomer;
    int customer_age;
    string gender;
    long long int cnic;
    long long int cell_number;

    void get_data()
    {
        cout << "Enter your full name: ";
        cin >> fcustomer >> lcustomer;
        cout << "Enter your age: ";
        cin >> customer_age;
        cout << "Enter your gender: ";
        cin >> gender;
        cout << "Enter your cnic: ";
        cin >> cnic;
        cout << "Enter your cell number: ";
        cin >> cell_number;
    }
    void set_data()
    {
        cout << "Your name is: " << fcustomer << lcustomer << endl;
        cout << "Your age is: " << customer_age << endl;
        cout << "Your gender is: " << gender << endl;
        cout << "Your cnic is: " << cnic << endl;
        cout << "Your cell number is: " << cell_number << endl;
    }
};