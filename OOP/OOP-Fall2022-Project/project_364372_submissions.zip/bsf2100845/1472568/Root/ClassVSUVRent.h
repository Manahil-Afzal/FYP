class VSUVRent :public Rent  //Rent of VIP SUV Category
{
public:
    int total_rent;
    void CalcSuvRent()
    {
        cout << "Enter option of the Suv to find rent: ";
        cin >> Voption;
        if (Voption == 1)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;

            per_day_rent = 25000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Land Cruiser V8 is: " << total_rent;
        }

        if (Voption == 2)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 50000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of Range Rover Auto-Biography is: " << total_rent;
            }
        }
        if (Voption == 3)
        {
            cout << "Enter total number of days you want to rent it for: ";
            cin >> totalnumber_of_days;
            {   per_day_rent = 70000;
            total_rent = totalnumber_of_days * per_day_rent;
            cout << "Rent of GMC is: " << total_rent;
            }

        }
    }
};