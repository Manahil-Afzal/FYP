#ifndef FAST_FOOD_H
#define FAST_FOOD_H

#include "bill.h"

#include <cstring>
#include <string>

class fast_food:public bill{        //fast-food class inherited by bill class
	public:  //data members
		char additional;
	void all_display();
		void calculate_bill();              //method to calculate bill of fast food purchased by customer
		
};

#endif