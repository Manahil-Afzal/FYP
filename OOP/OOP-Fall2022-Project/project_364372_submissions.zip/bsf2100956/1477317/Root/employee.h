#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "bakery.h"


class employee : public bakery{      //employee class inherited by bakery class
	public:
		bakery obj1;              //data members
		void employee_info();                          //employee display method
	
};

#endif