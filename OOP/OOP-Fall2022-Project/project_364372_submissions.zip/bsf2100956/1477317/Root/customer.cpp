#include "customer.h"
#include <iostream>
#include <cstring>
#include <string>
using namespace std;

 void customer::get_data()          //method to take information from customer
    {
        cout<<"Enter your name:"<<endl;
        getline(cin,customer_name);
        cout<<"Enter your cnic:"<<endl;
        cin>>cnic;
        cout<<"Enter your cell number:"<<endl;
        cin>>number;
    }
    void customer::set_data()        //method to display the information taken as input
    {
        cout<<"Your name is:"<<customer_name<<endl;
        cout<<"Your cnic is:"<<cnic<<endl;
        cout<<"Your cell number is:"<<number<<endl;
    }