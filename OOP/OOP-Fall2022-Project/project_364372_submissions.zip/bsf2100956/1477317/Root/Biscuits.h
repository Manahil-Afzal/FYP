#ifndef BISCUITS_H
#define BISCUITS_H

#include "bill.h"

class biscuits:public bill{  //Biscuit class inherited by bill class
	public:
		
		void calculate_bill();         //method to calculate bill of biscuits purchased by customer
		
};
#endif