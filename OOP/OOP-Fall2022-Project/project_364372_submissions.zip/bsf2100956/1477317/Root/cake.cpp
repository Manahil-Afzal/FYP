#include "cake.h"
#include <iostream>
using namespace std;
	void cakes::calculate_bill()	{      //method to calculate bill of cake purchased by customer
			cout<<"enter list no from counter:";
			cin>>list_no;             //allows to choose the list number available in variety of particular category
			
			cout<<"Enter quantity of selected product from list:";
			cin>>quantity;
			if(list_no==1)
			{
				product_price=850;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==2)
			{
				product_price=450;                 //conditional calculation 
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==3)
			{
				product_price=550;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==4)
			{
				product_price=1000;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==5)
			{
				product_price=1500;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
		}