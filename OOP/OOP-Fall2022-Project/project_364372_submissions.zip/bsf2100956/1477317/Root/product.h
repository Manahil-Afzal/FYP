#ifndef PRODUCT_H
#define PRODUCT_H

#include <cstring>
#include <string>

class product{               //Product class that is also a stand-alone class
	public:
	int total;       
	int select;                 //Data members of product class
	int list_no;
	char additional;
	int total_bill;

	void choose_product();          //method which allows customer to choose the category of the product among given
	
};

#endif