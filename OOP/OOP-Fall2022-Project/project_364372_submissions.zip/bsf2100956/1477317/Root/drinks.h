#ifndef DRINKS_H
#define DRINKS_H

#include "bill.h"

class drink:public bill{      //drink class inherited by bill class      
	public:
		
		void calculate_bill();       //method to calculate bill of drinks purchased by customer
			
};

#endif