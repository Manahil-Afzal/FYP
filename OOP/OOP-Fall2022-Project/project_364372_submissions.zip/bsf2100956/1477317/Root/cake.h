#ifndef CAKE_H
#define CAKE_H

#include "bill.h"

class cakes:public bill{            //cakes class inherited by bill
	public:
		
		void calculate_bill();      //method to calculate bill of cake purchased by customer
	
		
		
};

#endif