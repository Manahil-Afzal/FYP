#include "bakery.h"
#include <iostream>
using namespace std;

void bakery::bakery_info(){
			cout<<name<<endl;
			cout<<address<<endl;
			cout<<contact<<endl;
}