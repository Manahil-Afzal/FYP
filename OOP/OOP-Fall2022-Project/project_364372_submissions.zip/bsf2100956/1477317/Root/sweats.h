#ifndef SWEATS_H
#define SWEATS_H

#include "bill.h"

class sweets:public bill{                //sweats class inherited by bill class
	public:
		
		void calculate_bill();        //method to calculate bill of sweats purchased by customer
		
};


#endif