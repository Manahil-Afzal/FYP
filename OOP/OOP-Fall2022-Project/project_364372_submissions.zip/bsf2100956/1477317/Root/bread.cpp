#include "bread.h"
#include <iostream>
using namespace std;

	void bread:: calculate_bill() {       //method to calculate bill of bread purchased by customer
			cout<<"enter list no from counter:";
			cin>>list_no;
			
			cout<<"Enter quantity of selected product from list:";
			cin>>quantity;
			if(list_no==1)	{
				product_price=100;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==2){
				product_price=150;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==3){                 //conditional arithmetics
				product_price=90;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==4)	{
				product_price=200;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==5)	{
				product_price=100;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
		}
		