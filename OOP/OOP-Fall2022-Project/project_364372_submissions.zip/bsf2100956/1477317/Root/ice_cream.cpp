#include "ice_cream.h"
#include <iostream>
using namespace std;
	void ice_cream:: calculate_bill()         //method to calculate bill of ice-cream purchased by customer
		{
			cout<<"enter list no from counter:";
			cin>>list_no;
			
			cout<<"Enter quantity of selected product from list:";
			cin>>quantity;
			if(list_no==1)
			{
				product_price=375;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==2)               //conditional calculation
			{
				product_price=450;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==3)
			{
				product_price=400;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==4)
			{
				product_price=500;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==5)
			{
				product_price=300;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
		}