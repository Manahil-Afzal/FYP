#ifndef BAKERY_H
#define BAKERY_H
#include <string>
#include <iostream>
using namespace std;

class bakery
{
	protected:                                        //initialized Data members
	string name="AL-Madina Sweets & Bakers",
	address="University of Education College Road Township Block C Phase 1, Lahore",
	contact="04299262231";
	public:
		void bakery_info();           //method to display bakery info
		
};

#endif