/*      Ameer Hamza  ,Rafy Rohan, Muhammad Saqlain Faizan Asif*/
#include <iostream>
#include "fast_food.h"
#include "product.h"
#include "string"

using namespace std;
int main()          //main
{
	fast_food set;   //object of fast-food
	set.all_display();          //all display method is called
	
	return 0;
}
         //The END