#include "product.h"
#include <iostream>
using namespace std;
	void product:: choose_product()           //method which allows customer to choose the category of the product among given
	{
		cout<<"Following are counters in our bakery: "<<endl;
			cout<<"Press 1 for sweets:"<<endl;
			cout<<"Press 2 for cakes:"<<endl;
			cout<<"Press 3 for biscuits:"<<endl;
			cout<<"Press 4 for icecream:"<<endl;
			cout<<"Press 5 for drinks:"<<endl;
			cout<<"Press 6 for breads:"<<endl;
			cout<<"Press 7 for fastfood:"<<endl;
			cout<<"Enter counter number for products list: "<<endl;
			cin>>select;
			if (select == 1){                              //Sweet category
            cout<<"Sweets is selected counter:"<<endl;
            cout<<"Here are some products list from sweets counter1:"<<endl;
            cout<<"1- rasgulla (price = 400?)"<<endl;
            cout<<"2- burfi (price = 450?)"<<endl;
            cout<<"3- kalakand (price = 550?)"<<endl;
            cout<<"4- halwa (price = 650?)"<<endl;
            cout<<"5- gulab jamun (price = 350?)"<<endl;
        }
        if (select == 2){                                    //Cake category
            cout<<"Cakes is selected counter:"<<endl;
            cout<<"Here are some products list from cakes counter2:"<<endl;
            cout<<"1- chocolate-cake (price = 850?)"<<endl;
            cout<<"2- cream-cake (price = 450?)"<<endl;
            cout<<"3- dry-fruit cake(price = 550?)"<<endl;
            cout<<"4- lava-cake (price = 1000?)"<<endl;
            cout<<"5- brownie-crunch-cake (price = 1500?)"<<endl;
        }
        if (select == 3){                                      //Biscuits Category
            cout<<"Biscuits is selected counter:"<<endl;
            cout<<"Here are some products list from biscuits counter3:"<<endl;
            cout<<"1- butter-scotch (price = 150?)"<<endl;
            cout<<"2- sooper (price = 50?)"<<endl;
            cout<<"3- oatmeal (price = 100?)"<<endl;
            cout<<"4- chocolato (price = 80?)"<<endl;
            cout<<"5- peanut-pick (price = 40?)"<<endl;
        }
        if (select == 4){                                      //Ice-cream category
            cout<<"Ice-cream is selected counter:"<<endl;
            cout<<"Here are some products list from ice-cream counter4:"<<endl;
            cout<<"1- chocolate flavour (price = 375?)"<<endl;
            cout<<"2- strawberry flavour (price = 450?)"<<endl;
            cout<<"3- mango flavour (price = 400?)"<<endl;
            cout<<"4- vanilla flavour (price = 500?)"<<endl;
            cout<<"5- pistachio flavour (price = 300?)"<<endl;
        }
         if (select == 5){                                     //Drinks category
            cout<<"Cold drinks is selected counter:"<<endl;
            cout<<"Here are some products list from cold drinks counter5:"<<endl;
            cout<<"1- water bottle (price = 100?)"<<endl;
            cout<<"2- coca cola (price = 130?)"<<endl;
            cout<<"3- sprite (price = 120?)"<<endl;
            cout<<"4- marinda (price = 150?)"<<endl;
            cout<<"5- Fruita-vitals juice (price = 250?)"<<endl;
        }
         if (select == 6){                                      //Breads Category
            cout<<"Breads is selected counter:"<<endl;
            cout<<"Here are some products list from breads counter6:"<<endl;
            cout<<"1- white bread (price = 100?)"<<endl;
            cout<<"2- whole grain bread (price = 150?)"<<endl;
            cout<<"3- brown braed (price = 90?)"<<endl;
            cout<<"4- italian bread (price = 200?)"<<endl;
            cout<<"5- wheat bread (price = 100?)"<<endl;
        }
         if (select == 7){                                       //Fast food category
            cout<<"Fast-food is selected counter:"<<endl;
            cout<<"Here are some products list from fast-food counter7:"<<endl;
            cout<<"1- Pizza (price = 1000?)"<<endl;
            cout<<"2- patty (price = 100?)"<<endl;
            cout<<"3- sandwich (price = 150?)"<<endl;
            cout<<"4- nugget (price = 250?)"<<endl;
            cout<<"5- noodle (price = 450?)"<<endl;
        }
	}