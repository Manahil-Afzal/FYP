#include "sweats.h"
#include <iostream>
using namespace std;
		
		void sweets:: calculate_bill()         //method to calculate bill of sweats purchased by customer
		{
			cout<<"enter list no from counter:";
			cin>>list_no;           //allows to choose the list number available in variety of particular category
			
			cout<<"Enter quantity of selected product from list:";
			cin>>quantity;              //takes the input from user about the quantity of chosen product                                    
			if(list_no==1){
				product_price=400;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==2){
				product_price=450;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;        //conditional selection
			}
			if(list_no==3){
				product_price=550;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==4)	{
				product_price=650;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==5)	{
				product_price=350;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
				//total bill will be generated according to the list chosen by customer
			}
		}