#ifndef CUSTOMER_H
#define CUSTOMER_H
#include <cstring>
#include <string>
using namespace std;
class customer{       //customer class that is stand-alone
	public:
	string customer_name;     //data members of customer class
    string cnic;
    string number;
    void get_data();          //method to take information from customer
    void set_data();        //method to display the information taken as input
};

#endif