#ifndef BREAD_H
#define BREAD_H

#include "bill.h"

class bread:public bill{                  //bread class inherited by bill class
	public:
		
		void calculate_bill();        //method to calculate bill of bread purchased by customer
};

#endif