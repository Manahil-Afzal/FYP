#include "Biscuits.h"
#include <iostream>
using namespace std;

	void biscuits::calculate_bill()         //method to calculate bill of biscuits purchased by customer
		{
			cout<<"enter list no from counter:";
			cin>>list_no;
			
			cout<<"Enter quantity of selected product from list:";
			cin>>quantity;
			if(list_no==1)
			{
				product_price=150;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==2)
			{
				product_price=50;
				total_bill=product_price*quantity;  //conditional calculation
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==3)
			{
				product_price=100;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==4)
			{
				product_price=80;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==5)
			{
				product_price=40;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
		}