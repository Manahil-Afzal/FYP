#include "fast_food.h"
#include <iostream>
#include "employee.h"
#include "customer.h"
#include "sweats.h"
#include "cake.h"
#include "Biscuits.h"
#include "ice_cream.h"
#include "bill.h"
#include "drinks.h"
#include "bread.h"
#include "product.h"
#include <cstring>
#include <string>

using namespace std;
void fast_food::calculate_bill()               //method to calculate bill of fast food purchased by customer
		{
			cout<<"enter list no from counter:";
			cin>>list_no;
			
			cout<<"Enter quantity of selected product from list:";
			cin>>quantity;
			if(list_no==1)
			{
				product_price=1000;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==2)        //conditional arithmetics
			{
				product_price=100;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==3)
			{
				product_price=150;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==4)
			{
				product_price=250;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
			if(list_no==5)
			{
				product_price=450;
				total_bill=product_price*quantity;
				cout<<"Total: "<<total_bill<<endl;
			}
		}
		
	void fast_food :: all_display()    //method to display all the procedure of the program 
	{
		employee e;
	e.bakery_info();
	e.employee_info();
	customer c3;
	c3.get_data();
	product p1,p2,p3,p4,p5,p6,p7;  //7 multiple products can be choosed 
	p1.choose_product();  //first product

	switch(p1.select)
	{                           //switch statement to conditionally select product and calculate its bill 
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p1.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p1.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p1.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p1.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p1.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p1.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p1.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
	cout<<"DO YOU WANT SOMETHING ELSE? (Y/N)"<<endl;   //as customer is given multiple options, he/she can either 
	                                                     //select another or just break on the number
	cin>>additional;
	if(additional=='y'){                                           //Second Item 
		p2.choose_product();
	switch(p2.select)
	{
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p2.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p2.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p2.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p2.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p2.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p2.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p2.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
		cout<<"DO YOU WANT SOMETHING ELSE? (Y/N)"<<endl;
	cin>>additional;
	if(additional=='y'){                                           //Third Item 
		p3.choose_product();
	switch(p3.select)
	{
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p3.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p3.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p3.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p3.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p3.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p3.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p3.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
	 	cout<<"DO YOU WANT SOMETHING ELSE? (Y/N)"<<endl;
	cin>>additional;
	if(additional=='y'){                                           //Fourth Item 
		p4.choose_product();
	switch(p4.select)
	{
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p4.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p4.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p4.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p4.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p4.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p4.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p4.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
	 	cout<<"DO YOU WANT SOMETHING ELSE? (Y/N)"<<endl;
	cin>>additional;
	if(additional=='y'){                                           //Fifth Item 
		p5.choose_product();
	switch(p5.select)
	{
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p5.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p5.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p5.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p5.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p5.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p5.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p5.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
	 	cout<<"DO YOU WANT SOMETHING ELSE? (Y/N)"<<endl;
	cin>>additional;
	if(additional=='y'){                                           //Sixth Item 
		p6.choose_product();
	switch(p6.select)
	{
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p6.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p6.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p6.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p6.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p6.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p6.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p6.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
	 	cout<<"DO YOU WANT SOMETHING ELSE? (Y/N)"<<endl;
	cin>>additional;
	if(additional=='y'){                                           //Seventh Item 
		p7.choose_product();
	switch(p7.select)
	{
		case 1:
			sweets obj1;
			obj1.calculate_bill();
			p7.total=obj1.total_bill;
			break;
		case 2:
			cakes obj2;
			obj2.calculate_bill();
			p7.total=obj2.total_bill;
			break;
		case 3:
			biscuits obj3;
			obj3.calculate_bill();
			p7.total=obj3.total_bill;
			break;
		case 4:
			ice_cream obj4;
			obj4.calculate_bill();
			p7.total=obj4.total_bill;
			break;
		case 5:
			drink obj5;
			obj5.calculate_bill();
			p7.total=obj5.total_bill;
			break;
		case 6:
			bread obj6;
			obj6.calculate_bill();
			p7.total=obj6.total_bill;
			break;
		case 7:
			fast_food obj7;
			obj7.calculate_bill();
			p7.total=obj7.total_bill;
			break;
		default:
			cout<<"wrong option"<<endl;
	}
	
	}
		else{
			p7.total=0;
		cout<<"Thank you for visiting"<<endl;	
	}
	
	}
		else{
			p6.total=0;
			p7.total=0;
		cout<<"Thank you for visiting"<<endl;	
	}
	
	}
		else{
			p5.total=0;
			p6.total=0;
			p7.total=0;
		cout<<"Thank you for visiting"<<endl;	
	}
	
	}
		else{
			p4.total=0;
			p5.total=0;
			p6.total=0;
			p7.total=0;
		cout<<"Thank you for visiting"<<endl;	
	}
	
	}
		else{
			p3.total=0;
			p4.total=0;
			p5.total=0;
			p6.total=0;
			p7.total=0;
		cout<<"Thank you for visiting"<<endl;	
	}
	
	}
		else{
			p2.total=0;
			p3.total=0;
			p4.total=0;
			p5.total=0;
			p6.total=0;
			p7.total=0;
		cout<<"Thank you for visiting"<<endl;	
	}
				//--------------------------------------Reciept Generation-----------------------------------------//
	cout<<"\n------------------------------------"<<endl;
	cout<<"\n <<<<<<<<<<<< Reciept >>>>>>>>>>"<<endl;
	cout<<"\n------------------------------------"<<endl;
	e.bakery_info();
	cout<<"\n------------------------------------"<<endl;
	cout<<"\tCustomer Information"<<endl;
	c3.set_data();
	cout<<"\n------------------------------------"<<endl;
	cout << "\tSelected product:" << endl;            //selected products are enlisted here
    if (p1.select == 1 ){
    	cout << "1. Sweets";
    	if(p1.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p1.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p1.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p1.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per    "<<endl;
		}
	}     
    if (p1.select == 2){
    	 cout << "2. Cakes";
    	 if(p1.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per    "<<endl;
		 }
		 if(p1.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per    "<<endl;
		 }
		 if(p1.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per    "<<endl;
		 }	 
	}    
    if (p1.select == 3){
    	        cout << "3. Biscuits"<<endl;
	 if(p1.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per    "<<endl;
		 }
		 if(p1.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p1.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p1.select == 4){
    	cout << "4. Ice-Cream"<<endl;
    	 if(p1.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p1.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p1.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}                                 
    if (p1.select == 5){
        cout << "5. Drinks"<<endl;
         if(p1.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p1.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p1.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per    "<<endl;
		 }
    }
    if (p1.select == 6){
        cout << "6. Breads"<<endl;
         if(p1.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p1.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p1.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p1.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p1.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p1.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p1.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }
     if (p2.select == 1 ){
    	cout << "1. Sweets";
    	if(p2.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p2.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p2.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p2.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per    "<<endl;
    	
		}
	}
    if (p2.select == 2){
    	 cout << "2. Cakes";
    	 if(p2.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per    "<<endl;
		 }
		 if(p2.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per    "<<endl;
		 }
		 if(p2.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per    "<<endl;
		 }
		 if(p2.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per    "<<endl;
		 }	 
	}
    if (p2.select == 3){
    	        cout << "3. Biscuits"<<endl;
	 if(p2.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per    "<<endl;
		 }
		 if(p2.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p2.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p2.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p2.select == 4){
    	cout << "4. Ice-Cream"<<endl;
    	 if(p2.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p2.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p2.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p2.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}
    if (p2.select == 5){
        cout << "5. Drinks"<<endl;
         if(p2.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p2.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p2.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p2.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per    "<<endl;
		 }
    }
    if (p2.select == 6){
        cout << "6. Breads"<<endl;
         if(p2.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p2.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p2.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p2.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p2.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p2.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p2.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p2.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p2.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }    
    if (p3.select == 1 ){
    	cout << "1. Sweets";
    	if(p3.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p3.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p3.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p3.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per    "<<endl;
    	
		}	
	}
    if (p3.select == 2){
    	 cout << "2. Cakes";
    	 if(p3.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per    "<<endl;
		 }
		 if(p3.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per    "<<endl;
		 }
		 if(p3.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per    "<<endl;
		 }
		 if(p3.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per    "<<endl;
		 }	 
	}    
    if (p3.select == 3){
    	        cout << "3. Biscuits"<<endl;
	 if(p3.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per    "<<endl;
		 }
		 if(p3.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p3.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p3.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p3.select == 4){
    	cout << "4. Ice-Cream"<<endl;

    	 if(p3.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p3.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p3.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p3.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}
    if (p3.select == 5){
        cout << "5. Drinks"<<endl;
         if(p3.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p3.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p1.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p3.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per    "<<endl;
		 }
    }
    if (p3.select == 6){
        cout << "6. Breads"<<endl;
         if(p3.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p3.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p3.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p3.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p1.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p3.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p3.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p3.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p3.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }  
	 if (p4.select == 1 ){
    	cout << "1. Sweets";
    	if(p4.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p4.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p4.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p4.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per    "<<endl;
		}
	}     
    if (p4.select == 2){
    	 cout << "2. Cakes";
    	 if(p4.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per    "<<endl;
		 }
		 if(p4.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per    "<<endl;
		 }
		 if(p4.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per    "<<endl;
		 }
		 if(p4.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per    "<<endl;
		 }
	}
    if (p4.select == 3){
    	        cout << "3. Biscuits"<<endl;
	 if(p4.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per    "<<endl;
		 }
		 if(p4.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p4.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p4.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p4.select == 4){
    	cout << "4. Ice-Cream"<<endl;

    	 if(p4.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p4.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p4.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p4.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}
    if (p4.select == 5){
        cout << "5. Drinks"<<endl;
         if(p4.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p4.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p4.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p4.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per    "<<endl;
		 }
    }
    if (p4.select == 6){
        cout << "6. Breads"<<endl;
         if(p4.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p4.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p4.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p4.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p4.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p4.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p4.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p4.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p4.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }
    	 if (p5.select == 1 ){
    	cout << "1. Sweets";
    	if(p5.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p5.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p5.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p5.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per    "<<endl;
		}
	} 
    if (p5.select == 2){
    	 cout << "2. Cakes";
    	 if(p5.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per    "<<endl;
		 }
		 if(p5.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per    "<<endl;
		 }
		 if(p5.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per    "<<endl;
		 }
		 if(p5.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per    "<<endl;
		 }
	} 
    if (p5.select == 3){
    	        cout << "3. Biscuits"<<endl;
	 if(p5.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per    "<<endl;
		 }
		 if(p5.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p5.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p5.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p5.select == 4){
    	cout << "4. Ice-Cream"<<endl;
    	 if(p5.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p5.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p5.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p5.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}
    if (p5.select == 5){
        cout << "5. Drinks"<<endl;
         if(p5.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p5.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p5.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p5.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per    "<<endl;
		 }
    }
    if (p5.select == 6){
        cout << "6. Breads"<<endl;
         if(p5.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p5.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p5.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p5.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p5.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p5.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p5.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p5.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p5.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }
    if (p6.select == 1 ){
    	cout << "1. Sweets";
    	if(p6.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p6.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p6.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p6.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per    "<<endl;
		}
	}  
    if (p6.select == 2){
    	 cout << "2. Cakes";
    	 if(p6.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per    "<<endl;
		 }
		 if(p6.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per    "<<endl;
		 }
		 if(p6.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per    "<<endl;
		 }
		 if(p6.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per    "<<endl;
		 } 
	}  
    if (p6.select == 3){
    	        cout << "3. Biscuits"<<endl;
	 if(p6.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per    "<<endl;
		 }
		 if(p6.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p6.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p6.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p6.select == 4){
    	cout << "4. Ice-Cream"<<endl;

    	 if(p6.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p6.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p6.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p6.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}
    if (p6.select == 5){
        cout << "5. Drinks"<<endl;
         if(p6.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p6.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p6.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p6.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per    "<<endl;
		 }
    }
    if (p6.select == 6){
        cout << "6. Breads"<<endl;
         if(p6.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p6.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p6.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p6.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p6.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p6.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p6.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p6.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p6.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }  	
 if (p7.select == 1 ){
    	cout << "1. Sweets";
    	if(p7.list_no==1){
    		cout<<"(Rasgulla)"<<"    400/per    "<<endl;
		}
		else if(p7.list_no==2){
			cout<<"(Burfi)"<<"    450/per    "<<endl;
		}
		else if( p7.list_no==3){
				cout<<"(Kalakand)"<<"    550/per    "<<endl;
		}
		else if(p7.list_no==4){
				cout<<"(Halwa)"<<"    650/per    "<<endl;
		}
		else{
				cout<<"(Gulab Jamun)"<<"    350/per"<<endl;
		}
	}
    if (p7.select == 2){
    	 cout << "2. Cakes";
    	 if(p7.list_no==1 ){
    	 	cout<<"(Chocolate Cake)"<<"    850/per"<<endl;
		 }
		 if(p7.list_no==2 ){
    	 	cout<<"(Cream Cake)"<<"    450/per"<<endl;
		 }
		 if(p7.list_no==3 ){
    	 	cout<<"(Dry Fruit Cake)"<<"    550/per"<<endl;
		 }
		 if(p7.list_no==4 ){
    	 	cout<<"(Lave Cake)"<<"    1000/per"<<endl;
		 }
		 else{
    	 	cout<<"(Brownie Crunch Cake)"<<"    1500/per"<<endl;
		 }	 
	}
    if (p7.select == 3){
    		cout << "3. Biscuits"<<endl;
	 if(p7.list_no==1 ){
    	 	cout<<"(Butter Scotch)"<<"    150/per"<<endl;
		 }
		 if(p7.list_no==2 ){
    	 	cout<<"(Sooper)"<<"    50/per    "<<endl;
		 }
		 if(p7.list_no==3 ){
    	 	cout<<"(OatMeal)"<<"    100/per    "<<endl;
		 }
		 if(p7.list_no==4 ){
    	 	cout<<"(Chocolato)"<<"    80/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Peanut Pick)"<<"    40/per    "<<endl;
		 }	
	}
    if (p7.select == 4){
    	cout << "4. Ice-Cream"<<endl;
    	 if(p7.list_no==1 ){
    	 	cout<<"(Chocolate flavor)"<<"    375/per    "<<endl;
		 }
		 if(p7.list_no==2 ){
    	 	cout<<"(Strawbery flavor)"<<"    450/per    "<<endl;
		 }
		 if(p7.list_no==3 ){
    	 	cout<<"(Mango flavor)"<<"    400/per    "<<endl;
		 }
		 if(p7.list_no==4 ){
    	 	cout<<"(Vanilla flavor)"<<"    500/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Pistachio flavor)"<<"    300/per    "<<endl;
		 }
	}
    if (p7.select == 5){
        cout << "5. Drinks"<<endl;
         if(p7.list_no==1 ){
    	 	cout<<"(Water Bottle)"<<"    100/per    "<<endl;
		 }
		 if(p7.list_no==2 ){
    	 	cout<<"(Coca Cola)"<<"    130/per    "<<endl;
		 }
		 if(p7.list_no==3 ){
    	 	cout<<"(Sprite)"<<"    120/per    "<<endl;
		 }
		 if(p7.list_no==4 ){
    	 	cout<<"(Marinda)"<<"    150/per"<<endl;
		 }
		 else{
    	 	cout<<"(Fruita Vitals Juice)"<<"    250/per"<<endl;
		 }
    }
    if (p7.select == 6){
        cout << "6. Breads"<<endl;
         if(p7.list_no==1 ){
    	 	cout<<"(White Bread)"<<"    100/per    "<<endl;
		 }
		 if(p7.list_no==2 ){
    	 	cout<<"(Whole Grain)"<<"    150/per    "<<endl;
		 }
		 if(p7.list_no==3 ){
    	 	cout<<"(Brown Bread)"<<"    90/per    "<<endl;
		 }
		 if(p7.list_no==4 ){
    	 	cout<<"(Italian Bread)"<<"    200/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Wheat Bread)"<<"    100/per    "<<endl;
		 }
    }
    if (p7.select == 7){
        cout << "7. Fast-Food"<<endl;
         if(p7.list_no==1 ){
    	 	cout<<"(Pizza)"<<"    1000/per    "<<endl;
		 }
		 if(p7.list_no==2 ){
    	 	cout<<"(Patty)"<<"    100/per    "<<endl;
		 }
		 if(p7.list_no==3 ){
    	 	cout<<"(Sandwich)"<<"    150/per    "<<endl;
		 }
		 if(p7.list_no==4 ){
    	 	cout<<"(Nugget)"<<"    250/per    "<<endl;
		 }
		 else{
    	 	cout<<"(Noodle)"<<"    450/per    "<<endl;
		 }
    }       
    cout<<"\n------------------------------------"<<endl;         //Total payable amount is displayed here
    
    cout<<"Total Amount |	  Rs. " << p1.total+p2.total+p3.total+p4.total+p5.total+p6.total+p7.total<<"/-" << " 	| "<<endl; 
    cout<<"------------------------------------"<<endl;
		}	