#ifndef BILL_H
#define BILL_H

#include "product.h"

class bill:public product             //Bill class inherited by product class
{
	protected:
		int quantity;
		int product_price;          //bill class data members
};


#endif