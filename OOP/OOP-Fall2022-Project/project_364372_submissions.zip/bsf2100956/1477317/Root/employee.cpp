#include "employee.h"
#include <iostream>
using namespace std;
void employee::employee_info()                            //employee display method
		{
			cout<<"We have following staff for your service: "<<endl;
			cout<<"1. Rafique Khan ( Cashier )"<<endl;
			cout<<"a) Hamza. b) Saqlain. c) Faizan. d) Rafy."<<endl;
			cout<<"e) Noman. f) Asad. g) Ali."<<endl;
		}