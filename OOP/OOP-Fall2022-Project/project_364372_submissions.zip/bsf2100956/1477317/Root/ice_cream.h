#ifndef ICE_CREAM_H
#define ICE_CREAM_H

#include "bill.h"

class ice_cream:public bill{   //ice-cream class inherited by bill class
	public:
		
		void calculate_bill();         //method to calculate bill of ice-cream purchased by customer
		
};


#endif