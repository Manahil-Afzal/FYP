#include<iostream>
using namespace std;
class Seats
{
	public:
	int seatno;
			void input_data();
			void output_data();
			};
