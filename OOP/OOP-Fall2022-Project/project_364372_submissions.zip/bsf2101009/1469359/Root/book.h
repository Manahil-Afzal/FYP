#include<iostream>
using namespace std;
	class book:public Bus{         
		public:                   
	              
		string name5, CNIC,route,total_seats;
		int seat_no,time;
		    Bus B1;
		void book_data();
		void dis_values();
		
			};