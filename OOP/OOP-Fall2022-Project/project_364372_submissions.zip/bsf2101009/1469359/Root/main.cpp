#include<iostream>
using namespace std;
#include "bus.h"
#include "pass.h"
#include "seat.h"
#include "cnd.h"
#include "driver.h"
#include "book.h"
#include "stop.h"
#include "fare.h"



int main(){
    	Bus B1;
	
	B1.setname("asdf");
	B1.setnumber(10);
	B1.getname();
	B1.getnumber();
	
		
	passenger P1;
	P1.pass_data();
	P1. pass_output();  
	
	

		
	Seats S1;
    S1.input_data();  
   	S1.output_data();
	
	
	 conductor C1;
   	  C1.input();
   	  C1.output();
   	  
   	  
   	   	  driver obj2;
  	    obj2.setvalues();
  	   	obj2.getvalues();
  	   	
  	   		book obj3;
  	   	obj3. book_data(); 
  	    obj3.dis_values();
  	    
  	    	    
  	   	busstop obj4;
  	   	obj4.stop_data();
  	   	obj4.stop_output();
  	   	
  	   	
  	   		 Fare F1;
  	   	 F1.calc_fare();
	return 0;
}