#include"stop.h"
#include<iostream>
using namespace std;
	void busstop::stop_data(){
		cout<<"\n\n\t\t\tEnter the number of stop: ";
		cin>>stop_no;
		cout<<"\n\n\t\t\tEnter time of arrival of bus:  " ;
		cin>>arrival;
		cout<<"\n\n\t\t\tEnter time of departure of bus: " ;
		cin>>departure;
	}
	void busstop::stop_output(){
		cout<<"\n\n\t\t\tThe number of stop is :"<<stop_no<<endl<<"\n\n\t\t\tThe time of arrival of Bus: "<<arrival<<endl
		<<"\n\n\t\t\tThe time of departure of Bus: "<<departure<<endl;
	};