#include"cnd.h"
#include<iostream>
using namespace std;
//	string conductor_name,address,email,mobile_no;
		//	int id;
				void conductor:: input(){                         //method to input values
		   cout<<"\n\n\t\t\t\tEnter the name of conductor: " ;cin.ignore();
		    getline(cin,conductor_name);                
    	 cout<<"\n\n\t\t\t\tEnter the address of conductor: " ;cin.ignore();
		    getline(cin,address);  
		    cout<<"\n\n\t\t\t\tEnter the email of conductor: " ;cin.ignore();
		   cin>>email;  
		    cout<<"\n\n\t\t\t\tEnter the mobile_no of conductor: " ;
		   cin>>mobile_no; 
		   cout<<"\n\n\t\t\t\tEnter the id of conductor: " ;
		   cin>>id;   
	}
	void conductor:: output(){
		cout<<"\n\n\t\t\t\tNAME of conductor is : "<<conductor_name<<endl
		<<"\n\n\t\t\t\tAddress of conductor is: "<<address<<endl<<"\n\n\t\t\t\tEmail of conductor is:"<<email<<endl
		<<"\n\n\t\t\t\tMobile_no of conductor is: "<<mobile_no<<endl<<"\n\n\t\t\t\tId of conductor is: "<<id<<endl;
	}
	  

