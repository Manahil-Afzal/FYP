#include"seat.h"
#include<iostream>
using namespace std;
//calling of methods
		void Seats:: input_data(){                  //method to input values
		    cout<<"\n\n\t\t\t\t Enter Seat number: " ;
		    cin>>seatno;
		}
		void Seats:: output_data(){
		 cout<<"\n\n\t\t\t\tTotal number of seats are: "<<seatno<<endl;   
		}