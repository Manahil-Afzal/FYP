#include<iostream>
using namespace std;
#include"pass.h"
passenger::passenger(){
		    //B1.setname("DAEWOO BUS");
			//B1.setnumber(756);
		}
	void passenger::pass_data(){                         //method to input values
		   cout<<"\n\n\t\t\t\tEnter the name of passenger: " ;
		   getline(cin,name);                 
    	 cout<<"\n\n\t\t\t\tEnter the city of passenger: " ;
		    getline(cin,city);  
		    cout<<"\n\n\t\t\t\tEnter the mobile_no of passenger: " ;cin.ignore(); 
		   cin>>mobilenumber;  
		    cout<<"\n\n\t\t\t\tEnter the address of passenger: " ;cin.ignore();
	       getline(cin,address)	   ;  
		    cout<<"\n\n\t\t\t\tEnter the email of passenger: " ;
		   cin>>email;  
	}
	void passenger ::pass_output(){
		cout<<"\n\n\t\t\t\tNAME of Passenger is: "<<name<<endl<<"\n\n\t\t\t\tCity of Passenger is: "<<city<<endl
		<<"\n\n\t\t\t\tMobile_no of Passenger is:"<<mobilenumber<<endl
		<<"\n\n\t\t\t\tAddress of Passenger is: "<<address<<endl<<"\n\n\t\t\t\temail of customer: "<<email<<endl;
	}