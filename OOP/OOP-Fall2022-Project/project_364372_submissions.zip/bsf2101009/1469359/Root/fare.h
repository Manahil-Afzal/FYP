#include<iostream>
using namespace std;
	class Fare{                  
	public:
    int dist;
    void calc_fare();
    
};