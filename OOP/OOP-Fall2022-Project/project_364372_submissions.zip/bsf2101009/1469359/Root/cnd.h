#include<iostream>
using namespace std;
class conductor
{
	public:
			string conductor_name,address,email,mobile_no;
			int id;
			
		void input();
		void output();
};