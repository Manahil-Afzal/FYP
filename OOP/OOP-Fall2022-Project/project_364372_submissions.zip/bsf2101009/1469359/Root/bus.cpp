#include"bus.h"
#include<iostream>
using namespace std;

		void show_bus(){                                                                          
	cout<<"\n\n\t\t\t\3\3  Welcome To DAEWOO BUS SYSTEM  \3\3"<<endl;
	cout<<"\n\t\t---------------------------------------------------------"<<endl;
		}
			
			void Bus::setname(string name2){
				name1=name2;
			}
			void Bus:: setnumber(int num){
				number=num;
			}
			string Bus:: getname(){
				return name1;
			}
			int Bus:: getnumber(){
				return number;
			}