#include"driver.h"
#include<iostream>
using namespace std;

	void driver::setvalues(){
					cout<<"\n\n\t\t\tEnter the name of driver: " ;cin.ignore();
					getline(cin,name4); 
                     cout<<"\n\n\t\t\tEnter the id of driver: " ;
					cin>>driver_id;
					cout<<"\n\n\t\t\tEnter the number of driver: " ;
					cin>>n;
					cout<<"\n\n\t\t\tEnter the address of driver: " ;cin.ignore();
					getline(cin,address); 
					cout<<"\n\n\t\t\tEnter the email of driver: " ;
					cin>>email;
				}
		void driver::getvalues(){
			cout<<"\n\n\t\t\tThe name of driver is: "<<name4<<endl <<"\n\n\t\t\tThe Id of driver is: "<<driver_id<<endl<<"\n\n\t\t\tThe number of driver is: "<<n<<endl
			<<"\n\n\t\t\tThe address of driver is : "<<address<<endl<<"\n\n\t\t\tThe email of driver is: "<<email<<endl;
		}
	