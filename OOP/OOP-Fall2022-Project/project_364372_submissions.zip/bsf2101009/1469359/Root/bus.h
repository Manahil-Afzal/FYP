//name:muqadas noor
//name:ayeha umer
//name:laiba masood
//name:farwa ramzan
#include<iostream>
using namespace std;
class Bus
{
	public:
	string name1;                     
	int number;
			
			void setname(string name2);
	    	void setnumber(int num);
         	string getname();
        	int getnumber();
};