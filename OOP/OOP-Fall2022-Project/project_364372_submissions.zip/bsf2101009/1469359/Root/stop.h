#include<iostream>
using namespace std;
class busstop{
	public:
	int stop_no;
	string departure, arrival;
	void stop_data();
	void stop_output();

};