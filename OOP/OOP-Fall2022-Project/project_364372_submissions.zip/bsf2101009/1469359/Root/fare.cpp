#include"fare.h"
#include<iostream>
using namespace std;
 void Fare::calc_fare(){
    cout<<"\n\n\t\t\tWhat distance will you travel? ";
    cin>>dist;
    if(dist<=5){
        cout<<"\n\n\t\t\tFare is: Rs."<<10;
    }
    else if(dist>5 && dist<10){
        cout<<"\n\n\t\t\tFare is: Rs."<<20;
    }
    else if(dist>=10 && dist<30){
        cout<<"\n\n\t\t\tFare is: Rs."<<50;
    }
    else if(dist>=30 && dist<50){
        cout<<"\n\n\t\t\tFare is: Rs."<<100;
    }
    else if(dist>=50 && dist<80){
        cout<<"\n\n\t\t\tFare is: Rs."<<150;
    }
    else if(dist>=80 && dist<=100){
		  cout<<"\n\n\t\t\tFare is: Rs."<<250;
	}
    else
     {
		   cout<<"\n\n\t\t\tGet out of the bus";
	} 
};
