#include"bus.h"
#include "book.h"
#include<iostream>
using namespace std;
//      	string name5, CNIC,route,total_seats,time;   
//		int seat_no;
		void book :: book_data(){
					cout<<"\n\n\t\t\tEnter the name of passenger: " ;cin.ignore();
					getline(cin,name5); 
					cout<<"\n\n\t\t\tEnter the CNIC of passenger: " ;
					cin>>CNIC;
					cout<<"\n\n\t\t\tEnter the seat_no of passenger: " ;
					cin>>seat_no;
					cout<<"\n\n\t\t\tEnter the route of bus: " ;cin.ignore();
					getline(cin,route); 
					cout<<"\n\n\t\t\tEnter the total seats passenger is booking: " ;
					cin>>total_seats;
					cout<<"\n\n\t\t\tEnter the time of departure: " ;
					cin>>time;
							
				}
			void book ::  dis_values(){
		cout<<"\n\n\t\t\tThe name of passenger is: "<<name5<<endl<<"\n\n\t\t\tThe CNIC of passenger is: "<<CNIC<<endl
			<<"\n\n\t\t\tThe seat_no of passenger is: "<<seat_no<<endl<<"\n\n\t\t\tThe route of bus is: "<<route<<endl
			<<"\n\n\t\t\tThe total number of seats passenger is booking is: "<<total_seats<<endl<<"\n\n\t\t\tThe time of departure is: "<<time<<endl
			<<"\n\n\t\t\tNumber of the bus: "<<B1.getnumber()<<endl;
		}
			
	