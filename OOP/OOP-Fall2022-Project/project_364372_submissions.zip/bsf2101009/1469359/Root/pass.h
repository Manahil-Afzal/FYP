#include<iostream>
//#include"bus.h"
using namespace std;
class passenger
{
	public:
	string name,city,mobilenumber, address,email;  
			
//    Bus B1;                                                      
		 void pass_data(); 
     	void pass_output();                                               
	passenger();
   
};