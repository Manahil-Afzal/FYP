#include <iostream>
#include <string>
#include <cstdio>
using namespace std;

// function prototypes
void checkBalance(double balance);
void withdrawMoney(double &balance, double &withdraw);
void depositMoney(double &balance, double &deposit);

int main()
{
double balance = 5000; // starting balance
double withdraw = 1000; // amount to withdraw
double deposit = 500; // amount to deposit

// main menu loop
while (true)
{
    cout << "Welcome to the ATM. Please select an option:" << endl;
    cout << "1. Check balance" << endl;
    cout << "2. Withdraw money" << endl;
    cout << "3. Deposit money" << endl;
    cout << "4. Exit" << endl;
    int choice;
    cin >> choice;

    if (choice == 1)
    {
        checkBalance(balance);
    }
    else if (choice == 2)
    {
        cout << "Enter the amount you would like to withdraw: ";
        cin >> withdraw;
        withdrawMoney(balance, withdraw);
    }
    else if (choice == 3)
    {
        cout << "Enter the amount you would like to deposit: ";
        cin >> deposit;
        depositMoney(balance, deposit);
    }
    else if (choice == 4)
    {
        break;
    }
    else
    {
        cout << "Invalid option. Please try again." << endl;
    }
}

return 0;
}

// function definitions
void checkBalance(double balance)
{
cout << "Your current balance is: $" << balance << endl;
}

void withdrawMoney(double &balance, double &withdraw)
{
if (withdraw > balance)
{
cout << "Insufficient funds. Please try a different amount." << endl;
}
else
{
balance -= withdraw;
cout << "You have withdrawn $" << withdraw << ". Your new balance is: $" << balance << endl;
}
}

void depositMoney(double &balance, double &deposit)
{
balance += deposit;
cout << "You have deposited $" << deposit << ". Your new balance is: $" << balance << endl;
}
