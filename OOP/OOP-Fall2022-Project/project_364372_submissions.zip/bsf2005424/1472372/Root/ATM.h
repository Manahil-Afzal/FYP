#ifndef ATM_H
#define ATM_H
#include <string>
class ATM
{
public:
    ATM(std::string bank_name, int id);
    void deposit(int account_number, double amount);
    void withdraw(int account_number, double amount);
    double check_balance(int account_number);
private:
    std::string bank_name_;
    int id_;
};

