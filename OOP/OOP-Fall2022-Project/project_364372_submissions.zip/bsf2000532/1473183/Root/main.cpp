
//    Group Members:
//                Abdullah Tanveer       bsf2000532
//                Shahzaib Younas        bsf2101316
//                Muhammad Bilal         bsf2101113
//                Salmaan Maan           bsf2000845
//------------------------------------------------------------------------------------------------------------
// Write a C++ program for "Store Management System" that can control information of employees and
// communicate with the employees. Store has a 'manager' that control the information and detail
// of employees. Manager has its details (name,cnic,address,phone, etc). Manager has ability to
// perform following actions:
// 1. Add Employee Details
// 2. Control and check employees's details
// 3. Send Messages to Special Employee  etc
// 
// Employees are two types:
//          (1) Local Employee     (2) Special Employee
// "Local Employees" are those that has not profile. "Special Employees" are those that has a profile.
// "Special Employees" are further divided into some catagories such as Cashier, Productor and Special guard.
// "Special Employees" has its own profile and perform some actions such as see own detail, 
// communicate with manager as well as other special employees etc.
//------------------------------------------------------------------------------------------------------------


#include<iostream>
#include<string>
using namespace std;


class BASIC_INFORMATION
{
    protected:
    string id;
    long long cnic;
    string address;
    long long phone;
    string password;

    public:
    string name;
    string user_name;
};

class MESSAGE
{
    protected:
    string messages[100];
    string sender_name[100];
    int total_message=0;

    public:
    void send_message_fuction(string sender, string m);
    void delete_messages_function();
    void view_message();
    
};
void MESSAGE::send_message_fuction(string sender, string m)
{
    messages[total_message]=m;
    sender_name[total_message]=sender;
    total_message=total_message+1;
}

void MESSAGE::delete_messages_function()
{
    total_message=0;
    cout<<"All messages are deleted!"<<endl;
}

void MESSAGE::view_message()
{
    if(total_message>=1)
    {
        cout<<"Your total message="<<total_message<<endl<<endl;
        for(int a=0; a<total_message; a++)
        {
            cout<<a+1<<". Message send from '"<<sender_name[a]<<"'= "<<messages[a]<<endl<<endl;
        }    
    }
    else
    {
        cout<<"************Empty***********"<<endl;
    }
}
//------------------------------------------------------------------------------------------------------------
class WORKER
{
    protected:
    string id;
    int cnic;
    string address;
    double phone;

    public:
    char name[20];
};
class MANAGER:public BASIC_INFORMATION, public MESSAGE
{
    public:
    MANAGER(string i,long long c,string a,long long ph,string u,string p)
    {
        //name[20]='Abdullah';
        name="Abdullah";
        id=i;
        cnic=c;
        address=a;
        phone=ph;
        user_name=u;
        password=p;
    }
};

class EMPLOYEE:public BASIC_INFORMATION, public MESSAGE
{
    private:
    int salary;
    string rank;

    public:
    int attendence[365];
    string work_type;
    void input_details();
    void display_details();
    bool check_id(string a);
    void change_password();
    
    static bool check_employee_login(EMPLOYEE array[],int size,string n, string p)
    {
        bool ans=false;
        for(int a=0; a<=size; a++)
        {
            if(n==array[a].user_name && p==array[a].password)
            {
                ans=true;
            }
        }
        return ans;
    }

    static void rank_order(EMPLOYEE array[],int total)
    {
        EMPLOYEE temprory;
        for(int a=0; a<=total; a++)
        {
            for(int b=a+1; b<=total; b++)
            {
                if(array[a].rank<array[b].rank)
                {
                    temprory=array[a];
                    array[a]=array[b];
                    array[b]=temprory;
                }
            }
        }
        
        for(int a=0; a<=total; a++)
        {
            cout<<endl;
            cout<<"Name="<<array[a].name<<endl;
            cout<<"ID="<<array[a].id<<endl;
            cout<<"Rank="<<array[a].rank<<endl;
            cout<<endl;
        }
        
    }
};
void EMPLOYEE::input_details()
{
    cout<<"Name=";
    cin>>name;
    cout<<"CNIC=";
    cin>>cnic;
    cout<<"ID=";
    cin>>id;
    cout<<"Address=";
    cin>>address;
    cout<<"Phone number=";
    cin>>phone;
    cout<<"What type of work(Cashier/Productor)=";
    cin>>work_type;
    cout<<"Salary=";
    cin>>salary;
    cout<<"Rank=";
    cin>>rank;
    cout<<"User Name of profile=";
    cin>>user_name;
    cout<<"Password=";
    cin>>password;
}

void EMPLOYEE::display_details()
{
    cout<<"Name="<<name<<endl;
    cout<<"CNIC="<<cnic<<endl;
    cout<<"ID="<<id<<endl;
    cout<<"Address="<<address<<endl;
    cout<<"Phone number="<<phone<<endl;
    cout<<"Type of work="<<work_type<<endl;
    cout<<"Salary="<<salary<<endl;
    cout<<"Rank="<<rank<<endl;
    cout<<"User Name="<<user_name<<endl;
    cout<<"Password="<<password<<endl;
}

bool EMPLOYEE::check_id(string a)
{
    bool flag=false;
    if(a==user_name)
    {
        flag=true;
    }
    return flag;
}

void EMPLOYEE::change_password()
{
    cout<<"Write a new password=";
    cin>>password;
}
//-----------------------------------------------------------------------------
class LOCAL_EMPLOYEE:protected WORKER
{
    private:
    int age;
    int salary;
    string work_type;

    public:
    void input_details();
    void display_details();
    bool check_id(string a);
};
void LOCAL_EMPLOYEE::input_details()
{
    cout<<"Name=";
    cin>>name;
    cout<<"CNIC=";
    cin>>cnic;
    cout<<"ID=";
    cin>>id;
    cout<<"Address=";
    cin>>address;
    cout<<"Phone number=";
    cin>>phone;
    cout<<"What type of work----=";
    cin>>work_type;
    cout<<"Salary=";
    cin>>salary;
    cout<<"Age=";
    cin>>age;
}
void LOCAL_EMPLOYEE::display_details()
{
    cout<<"Name="<<name<<endl;
    cout<<"CNIC="<<cnic<<endl;
    cout<<"ID="<<id<<endl;
    cout<<"Address="<<address<<endl;
    cout<<"Phone number="<<phone<<endl;
    cout<<"Type of work="<<work_type<<endl;
    cout<<"Salary="<<salary<<endl;
    cout<<"Age="<<age<<endl;
}
bool LOCAL_EMPLOYEE::check_id(string a)
{
    bool flag=false;
    if(a==id)
    {
        flag=true;
    }
    return flag;
}
//--------------------------------------------------------------------------------

class SECURITY_GUARD:public BASIC_INFORMATION, public MESSAGE
{
    private:
    int salary;
    string rank;
    public:
    void input_details();
    void display_details();

    static bool check_login(SECURITY_GUARD array[],int size, string n, string p)
    {
        bool ans=false;
        for(int a=0; a<=size; a++)
        {
            if(n==array[a].user_name && p==array[a].password)
            {
                ans=true;
            }
        }
        return ans;

    }
    bool check_id(string a);

    static void rank_order(SECURITY_GUARD array[],int total)
    {
        SECURITY_GUARD temprory;
        for(int a=0; a<=total; a++)
        {
            for(int b=a+1; b<=total; b++)
            {
                if(array[a].rank<array[b].rank)
                {
                    temprory=array[a];
                    array[a]=array[b];
                    array[b]=temprory;
                }
            }
        }
        
        for(int a=0; a<=total; a++)
        {
            cout<<endl;
            cout<<"Name="<<array[a].name<<endl;
            cout<<"ID="<<array[a].id<<endl;
            cout<<"Rank="<<array[a].rank<<endl;
            cout<<endl;
        }
        
    }
    void change_password();
};
void SECURITY_GUARD::input_details()
{
    cout<<"Name=";
    cin>>name;
    cout<<"CNIC=";
    cin>>cnic;
    cout<<"ID=";
    cin>>id;
    cout<<"Address=";
    cin>>address;
    cout<<"Phone number=";
    cin>>phone;
    cout<<"Salary=";
    cin>>salary;
    cout<<"Rank=";
    cin>>rank;
    cout<<"User Name of profile=";
    cin>>user_name;
    cout<<"Password=";
    cin>>password;
}

void SECURITY_GUARD::display_details()
{
    cout<<"Name="<<name<<endl;
    cout<<"CNIC="<<cnic<<endl;
    cout<<"ID="<<id<<endl;
    cout<<"Address="<<address<<endl;
    cout<<"Phone number="<<phone<<endl;
    cout<<"Salary="<<salary<<endl;
    cout<<"User Name of profile="<<user_name<<endl;
    cout<<"Password="<<password<<endl;
}
bool SECURITY_GUARD::check_id(string a)
{
    bool flag=false;
    if(a==id)
    {
        flag=true;
    }
    return flag;
}
void SECURITY_GUARD::change_password()
{
    cout<<"Write a new password=";
    cin>>password;
}
//-----------------------------------------------------------------------------------------------------------
class CUSTOMER
{
    private:
    int bill;
    long long phone;

    public:
    char name[20];
    int no_of_products;

    void input_details();
    void display_details(int a);
    bool edit_customer(long long p);

    static void earning_details(int a)
    {
      
        cout<<"********************************************************"<<endl;
        cout<<"                   Earning Details"<<endl;
        cout<<"********************************************************"<<endl;
        cout<<endl;
        cout<<endl;
        cout<<endl;
        cout<<"Total number of customers="<<a+3<<endl;
        cout<<"Total number of products that sold=21"<<endl;
        cout<<"Total Earning=3400"<<endl;
    }
};

void CUSTOMER::input_details()
{
  
    cout<<"*************************Enter Customer Details************************"<<endl;
    cout<<endl<<"Name=";
    cin>>name;
    cout<<"Phone Number=";
    cin>>phone;
    cout<<endl<<"Number of products that he/she buy=";
    cin>>no_of_products;
    cout<<endl<<"Total bill=";
    cin>>bill;
}
void CUSTOMER::display_details(int a)
{
    cout<<endl<<"************ '"<<a+1<<"' Customer Details************"<<endl;
    cout<<"Name="<<name<<endl;
    cout<<"Phone Number="<<phone<<endl;
    cout<<"Number of products buy="<<no_of_products<<endl;
    cout<<"Total bill="<<bill<<endl;
}
bool CUSTOMER::edit_customer(long long p)
{
    bool flag=false;
    if(p==phone)
    {
        flag=true;
    }
    return flag;
}
//----------------------------------------------------------------------------------------------
class PRODUCTS
{
    public:
    string type;
    string flavour;
    int price;
    string brand;

    PRODUCTS(string f,int p, string b)
    {
        flavour=f;
        price=p;
        brand=b;
    }
    static void function_of_product_details()
    {
      
        PRODUCTS products_0("Olive",500,"Dalda");
        PRODUCTS products_1("Soybean",550,"Sufi");
        PRODUCTS products_2("peanut",450,"Shan");
        PRODUCTS products_10("Chocolate",40,"Sooper");
        PRODUCTS products_11("Coconut",40,"Prince");
        PRODUCTS products_12("Strobery",40,"Rio");
        cout<<"**************************************************************"<<endl;
        cout<<"                   Available Products Details"<<endl;
        cout<<"**************************************************************"<<endl<<endl;

        cout<<"******************* <Oil Products> *******************"<<endl;
        cout<<"1.";
        products_0.product_details();
        cout<<"2.";
        products_1.product_details();
        cout<<"3.";
        products_2.product_details();
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"******************* <Chocolate Products> *******************"<<endl;
        cout<<"1.";
        products_10.product_details();
        cout<<"2.";
        products_11.product_details();
        cout<<"3.";
        products_12.product_details();
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"..."<<endl;
        cout<<"..."<<endl;
       
    }

    void product_details()
    {
        cout<<endl<<"Product Flavour="<<flavour<<endl;
        cout<<"Product Brand="<<brand<<endl;
        cout<<"Price of Product="<<price<<endl;
        cout<<endl;
    }
};
//-------------------------------------------------------------------------------------------------------

class BRANCH
{
    private:
    string source_code="ab125";
    public:
    string name="Any Name";
    string branch_no="aa12";
    string address="Lahore";
    void display()
    {
        cout<<"********************************************************************"<<endl;
        cout<<"**********************Branch Details*********************"<<endl;
        cout<<"********************************************************************"<<endl;
        cout<<endl;
        cout<<endl;
        cout<<endl;
        cout<<"Company Name="<<name;
        cout<<"Branch No.="<<branch_no;
        cout<<"Address="<<address;
        cout<<"Souce Code="<<source_code;
    }
};


int main()
{
    string login_user_name,login_password;
    bool manager_answer, employee_answer,guard_answer;
    int total_employee=-1,total_local_employee=-1,total_guard=-1,total_customer=-1,total_products=2;

    BRANCH branch_3;
    MANAGER manager("111",7655454767,"Dharampura",9230914620,"bhai123","bhai123");
    EMPLOYEE employee[100];
    LOCAL_EMPLOYEE local_employee[100];
    SECURITY_GUARD special_guard[10];
    CUSTOMER customer[100];
                        

    while(true)
    {
        int manager_value=-1;

      
        cout<<"**********************************************************"<<endl;
        cout<<"        Company Managment and Comunication System"<<endl;
        cout<<"**********************************************************"<<endl;
        cout<<endl;
        cout<<endl;
        cout<<endl;
        cout<<"                      __Main Menu__"<<endl<<endl;
        cout<<"Enter your User_Name=";
        cin>>login_user_name;
        cout<<"Enter your Password=";
        cin>>login_password;


        //--------------------------Manager Section----------------------------------
        
        if(login_user_name=="bhai123" && login_password=="bhai123")
        {
            while(manager_value!=0)
            {
              
                cout<<"**********************************************************"<<endl;
                cout<<"                Welcome Admin"<<endl;
                cout<<"**********************************************************"<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<"* Enter '1' to Employee Section"<<endl;
                cout<<"* Enter '2' to Special security Guard Section"<<endl;
                cout<<"* Enter '3' to View Income details"<<endl;
                cout<<"* Enter '4' to View Product details"<<endl;
                cout<<"* Enter '5' to View Messages"<<endl;
                cout<<"* Enter '6' to Delete all Messages"<<endl;
                cout<<"* Enter '7' to view branch details"<<endl;
                cout<<"* Enter '0' to Logout"<<endl;
                //cout<<"-------6. Maintaince group Section---------"<<endl;
                cout<<endl;
                cout<<endl;
                cout<<endl;
                cout<<"Enter your value=";
                cin>>manager_value;


                switch (manager_value)
                {
                    // Special  Employee  Section
                    case 1:
                    while(manager_value!=0)
                    {
                      
                        cout<<"**********************************************************"<<endl;
                        cout<<"                Employees Section"<<endl;
                        cout<<"**********************************************************"<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"* Enter '1' to Special Employees"<<endl;
                        cout<<"* Enter '2' to Local Employees"<<endl;
                        cout<<"* Enter '0' to return back"<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"Enter your value=";
                        cin>>manager_value;

                        switch (manager_value)
                        {
                            case 1:
                            while(manager_value!=0)
                            {
                              
                                cout<<"**********************************************************"<<endl;
                                cout<<"                Special Employees Section"<<endl;
                                cout<<"**********************************************************"<<endl;
                                cout<<endl;
                                cout<<endl;
                                cout<<endl;
                                cout<<"* Enter '1' to add employees's details"<<endl;
                                cout<<"* Enter '2' to view all employees's details"<<endl;
                                cout<<"* Enter '3' to view someone employees's details"<<endl;
                                cout<<"* Enter '4' to view employees's details in ranking"<<endl;
                                cout<<"* Enter '5' to send message to all employees"<<endl;
                                cout<<"* Enter '6' to send message to someone employees"<<endl;
                                cout<<"* Enter '0' to return back"<<endl;
                                cout<<endl;
                                cout<<endl;
                                cout<<"Enter your value=";
                                cin>>manager_value;

                                // Variables Declare from outside the switch 
                                // (lykin switch k andr declare krny sy error aa jata hai??)
                                string i;
                                EMPLOYEE temporary_array[100];
                                //string m,sender="manager";
                                string m,n,sender="Admin";
                                int index=-5;
                                bool jwab=true;

                                switch (manager_value)
                                {
                                    case 1:
                                  
                                    total_employee=total_employee+1;
                                    cout<<"***************** Enter Employee's Details ******************"<<endl<<endl;
                                    employee[total_employee].input_details();
                                    manager_value=-1;
                                    break;

                                    case 2:
                                  
                                    for(int a=0; a<=total_employee; a++)
                                    {
                                        cout<<"******************** Details of '"<<a+1<<"' employee *****************"<<endl;
                                        employee[a].display_details();
                                        cout<<endl;
                                        cout<<endl;
                                    }
                                    cout<<"press any key to continue...";
                                   
                                    manager_value=-1;
                                    break;

                                    case 3:
                                  
                                    
                                    //bool jwab=false;
                                    //int index;
                                    cout<<"Enter User Name=";
                                    cin>>i;
                                    for(int a=0; a<=total_employee; a++)
                                    {
                                        if(i==employee[a].user_name)
                                        {
                                            employee[a].display_details();
                                            jwab=false;
                                            break;
                                        }
                                        // ans=employee[a].check_id(i);
                                        // if(ans)
                                        // {
                                        //     employee[a].display_details();
                                        //     break;
                                        // }
                                    }
                                    if(jwab)
                                    {
                                        cout<<"You enter invalid User Name!!"<<endl;
                                    }
                                    cout<<endl<<"press any key to continue...";
                                   
                                    manager_value=-1;
                                    break;
                                    
                                    case 4:
                                  
                                    for(int a=0; a<=total_employee; a++)
                                    {
                                        temporary_array[a]=employee[a];
                                    }
                                    cout<<"***************** Employee's Details in Ranking Order ******************"<<endl;
                                    cout<<endl;
                                    EMPLOYEE::rank_order(temporary_array,total_employee);
                                    cout<<"press any key to continue...";
                                   
                                    manager_value=-1;
                                    break;

                                    case 5:
                                  
                                    cout<<"Write a message=";
                                    cin>>m;
                                    for(int a=0; a<=total_employee; a++)
                                    {
                                        employee[a].send_message_fuction(sender, m);
                                    }
                                    cout<<endl;
                                    cout<<"Succesfully send message to all Employees!!";
                                   
                                    manager_value=-1;
                                    break;

                                    case 6:
                                  
                                    cout<<"Write a message=";
                                    cin>>m;
                                    cout<<"Write a User Name=";
                                    cin>>n;
                                    for(int a=0; a<=total_employee; a++)
                                    {
                                        if(n==employee[a].user_name)
                                        {
                                            index=a;
                                        }
                                    }
                                    if(index>-1)
                                    {
                                        employee[index].send_message_fuction(sender, m);
                                        cout<<endl<<"Send message succesfully!!";
                                       
                                    }
                                    else
                                    {
                                        cout<<endl<<"You enter invalide User_Name!!";
                                       
                                    }
                                    manager_value=-1;
                                    break;
                                    
                                    case 7:
                                        /* code for delete employee */
                                    manager_value=-1;
                                    break;

                                    case 0:
                                    break;
                                    
                                    default:
                                    cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                                    cout<<"       **Try again**"<<endl;
                                   
                                    break;
                                }
                            }
                            manager_value=-1;
                            break;

                            case 2:
                            while(manager_value!=0)
                            {
                              
                                cout<<"**********************************************************"<<endl;
                                cout<<"                Local Employees Section"<<endl;
                                cout<<"**********************************************************"<<endl;
                                cout<<endl;
                                cout<<endl;
                                cout<<endl;
                                cout<<"* Enter '1' to add employees's details"<<endl;
                                cout<<"* Enter '2' to view all employees's details"<<endl;
                                cout<<"* Enter '3' to view someone employees's details"<<endl;
                                cout<<"* Enter '0' to return back"<<endl;
                                cout<<endl;
                                cout<<endl;
                                cout<<"Enter your value=";
                                cin>>manager_value;

                                // Variables Declare from outside the switch 
                                // (lykin switch k andr declare krny sy error aa jata hai??)
                                string i;
                                int index;
                                switch(manager_value)
                                {
                                    case 1:
                                  
                                    total_local_employee=total_local_employee+1;
                                    cout<<"***************** Enter Local Employee's Details ******************"<<endl;
                                    cout<<endl;
                                    local_employee[total_local_employee].input_details();
                                    break;

                                    case 2:
                                  
                                    for(int a=0; a<=total_local_employee; a++)
                                    {
                                        cout<<"************ Details of '"<<a+1<<"' Local Employee ************"<<endl;
                                        local_employee[a].display_details();
                                        cout<<endl;
                                        cout<<endl;
                                    }
                                    cout<<"press any key to continue...";
                                   
                                    manager_value=-1;
                                    break;

                                    case 3:
                                  
                                    bool ans;
                                    cout<<"Enter ID=";
                                    cin>>i;
                                    for(int a=0; a<=total_local_employee; a++)
                                    {
                                        ans=local_employee[a].check_id(i);
                                        if(ans)
                                        {
                                            index=a;
                                            break;
                                        }
                                    }
                                    if(ans)
                                    {
                                        local_employee[index].display_details();
                                    }
                                    else
                                    {
                                        cout<<endl<<"You enter Invalide ID!!";
                                        
                                    }
                                   
                                    manager_value=-1;
                                    break;

                                    case 4:
                                        /* code for delete local_employee*/
                                    manager_value=-1;
                                    break;

                                    case 0:
                                        /* code */
                                    break;
                                    
                                    default:
                                    cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                                    cout<<"       **Try again**"<<endl;
                                   
                                    break;
                                }
                            }
                            manager_value=-1;
                            break;

                            case 0:
                            break;
                            
                            default:
                            cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                            cout<<"       **Try again**"<<endl;
                           
                            break;
                        }
                    }
                    manager_value=-1;
                    break;

                    //Special security Guard Section
                    case 2:
                    while(manager_value!=0)
                    {
                        SECURITY_GUARD temporary_array[10];
                      
                        cout<<"**********************************************************"<<endl;
                        cout<<"                Special security Guard Section"<<endl;
                        cout<<"**********************************************************"<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"* Enter '1' to add guard's details"<<endl;
                        cout<<"* Enter '2' to view all guard's details"<<endl;
                        cout<<"* Enter '3' to view someone guard's details"<<endl;
                        cout<<"* Enter '4' to view guard's details in ranking"<<endl;
                        cout<<"* Enter '5' to send message to all guards"<<endl;
                        cout<<"* Enter '6' to send message to someone guards"<<endl;
                        cout<<"* Enter '0' to return back"<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"Enter your value=";
                        cin>>manager_value;

                        // Variables Declare from outside the switch 
                        // (lykin switch k andr declare krny sy error aa jata hai??)
                        string i,m,sender="Admin",n;
                        bool ans=true;
                        int index=-5;

                        switch (manager_value)
                        {
                        case 1:
                      
                        total_guard=total_guard+1;
                        cout<<"***************** Enter Employee's Details ******************"<<endl<<endl;
                        special_guard[total_guard].input_details();
                        break;

                        case 2:
                      
                        for(int a=0; a<=total_guard; a++)
                        {
                            cout<<"******************** Details of '"<<a+1<<"' Guard *****************"<<endl;
                            special_guard[a].display_details();
                            cout<<endl;
                            cout<<endl;
                        }
                        cout<<"press any key to continue...";
                       
                        break;

                        case 3:
                      
                        cout<<"Enter User Name=";
                        cin>>i;
                        for(int a=0; a<=total_guard; a++)
                        {
                            if(special_guard[a].user_name==i)
                            {
                                special_guard[a].display_details();
                                ans=false;
                                break;
                            }
                            // ans=special_guard[a].check_id(i);
                            // if(ans)
                            // {
                            //     special_guard[a].display_details();
                            //     break;
                            // }
                        }
                        if(ans)
                        {
                            cout<<"You enter invalide User Name!!"<<endl;
                        }
                       
                        break;

                        case 4:
                      
                        for(int a=0; a<=total_guard; a++)
                        {
                            temporary_array[a]=special_guard[a];
                        }
                        cout<<"***************** Employee's Details in Ranking Order ******************"<<endl;
                        cout<<endl;
                        SECURITY_GUARD::rank_order(temporary_array,total_guard);
                        cout<<"press any key to continue...";
                       
                        break;

                        case 5:
                      
                        cout<<"Write a message=";
                        cin>>m;
                        for(int a=0; a<=total_guard; a++)
                        {
                            special_guard[a].send_message_fuction(sender, m);
                        }
                        cout<<endl;
                        cout<<"Succesfully send message to all Guards!!";
                       
                        break;

                        case 6:
                      
                        cout<<"Write a message=";
                        cin>>m;
                        cout<<"Write a User Name=";
                        cin>>n;
                        for(int a=0; a<=total_guard; a++)
                        {
                            if(n==special_guard[a].user_name)
                            {
                                index=a;
                            }
                        }
                        if(index>-1)
                        {
                            special_guard[index].send_message_fuction(sender, m);
                            cout<<endl<<"Send message succesfully!!";
                           
                        }
                        else
                        {
                            cout<<endl<<"You enter invalide User_Name!!";
                           
                        }
                        break;

                        case 7:
                            /* code for delete Object(Guard's detail)*/
                        break;

                        case 0:
                        break;
                        
                        default:
                        cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                        cout<<"       **Try again**"<<endl;
                       
                        break;
                        }
                    }
                    manager_value=-1;
                    break;

                    case 3:
                  
                    CUSTOMER::earning_details(total_customer);
                   
                    break;

                    case 4:
                    PRODUCTS::function_of_product_details();
                    break;

                    case 5:
                  
                    manager.view_message();
                    cout<<"press any key to continue...";
                   
                    manager_value=-1;
                    break;

                    case 6:
                  
                    manager.delete_messages_function();
                    cout<<"press any key to continue...";
                   
                    manager_value=-1;
                    break;

                    case 7:
                    branch_3.display();
                    break;

                    case 0:
                        /* code */
                    break;
                    
                    default:
                    cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                    cout<<"       **Try again**"<<endl;
                   
                    break;
                }
            }// manager_value!=0
        }// Manager Section

        else
        {
            employee_answer=EMPLOYEE::check_employee_login(employee,total_employee,login_user_name,login_password);    
            if(employee_answer)
            {
                string login_employee=login_user_name;
                string man;
                string line_1,line_2;
                int login_index=0,employee_value=-1;

                for(int a=0; a<=total_employee; a++)
                {
                    if(employee[a].user_name==login_employee)
                    {
                        login_index=a;
                    }
                }
                if(employee[login_index].work_type=="cashier" || employee[login_index].work_type=="Cashier")
                {
                    man="Cashier";
                    line_1="* Enter '7' to Cashier Section";
                    line_2="* Enter '8' to view earning details";
                }
                else
                {
                    man="Productor";
                    line_1="* Enter '7' to view available products";
                    line_2="";
                }
                while(employee_value!=0)
                {
                  
                    cout<<"**********************************************************"<<endl;
                    cout<<"                Welcome '"<<login_employee<<"' ("<<man<<")"<<endl;
                    cout<<"**********************************************************"<<endl;
                    cout<<endl;
                    cout<<endl;
                    cout<<endl;
                    cout<<"* Enter '1' to  view own details"<<endl;
                    cout<<"* Enter '2' to change password"<<endl;
                    cout<<"* Enter '3' to send Message to someone"<<endl;
                    cout<<"* Enter '4' to view Messages"<<endl;
                    cout<<"* Enter '5' to delete all Messages"<<endl;
                    cout<<"* Enter '6' to view other employee's user name"<<endl;
                    cout<<line_1<<endl;
                    cout<<line_2<<endl;
                    cout<<"* Enter '0' to Logout"<<endl;
                    cout<<endl;
                    cout<<endl;
                    cout<<"Enter your value=";
                    cin>>employee_value;

                    // Variables Declare from outside the switch 
                    // (lykin switch k andr declare krny sy error aa jata hai??)
                    string m,n,sender=login_employee;
                    int index;
                    bool jwab=true;

                    switch (employee_value)
                    {
                        case 1:
                      
                        employee[login_index].display_details();
                        cout<<"press any key to continue...";
                       
                        break;

                        case 2:
                      
                        employee[login_index].change_password();
                        cout<<endl;
                        cout<<"Change password successfully!";
                       
                        break;

                        case 3:
                      
                        cout<<"Write a message=";
                        cin>>m;
                        cout<<"Write a User Name=";
                        cin>>n;
                        for(int a=0; a<=total_employee; a++)
                        {
                            if(n==employee[a].user_name)
                            {
                                jwab=false;
                                employee[a].send_message_fuction(sender, m);
                                cout<<"Send message succesfully!!";
                                break;
                            }
                        }
                        if(n=="manager")
                        {
                            manager.send_message_fuction(sender, m);
                            cout<<"Send message succesfully!!";
                            jwab=false;
                            break;
                        }
                        if(jwab)
                        {
                            cout<<"******* You Enter invalid User_Name ***********"<<endl;
                        }
                       
                        break;

                        case 4:
                      
                        employee[login_index].view_message();
                        cout<<"press any key to continue...";
                       
                        break;
                        
                        case 5:
                      
                        employee[login_index].delete_messages_function();
                        cout<<"press any key to continue...";
                       
                        break;

                        case 6:
                      
                        for(int a=0; a<=total_employee; a++)
                        {
                            cout<<a+1<<". Employee="<<employee[a].user_name<<endl;
                        }
                           
                        break;

                        case 7:
                      
                        if(man=="Cashier")
                        {
                            while(employee_value!=0)
                            {
                              
                                cout<<"**************** Customer Section *****************"<<endl<<endl;
                                cout<<"* Enter '1' to add customer details"<<endl;
                                cout<<"* Enter '2' to view customer details"<<endl;
                                cout<<"* Enter '3' to edit customer details"<<endl;
                                cout<<"* Enter '0' to return back"<<endl;
                                cout<<endl<<endl<<endl;
                                cout<<"Enter your value=";
                                cin>>employee_value;

                                switch (employee_value)
                                {
                                    case 1:
                                    total_customer=total_customer+1;
                                    customer[total_customer].input_details();
                                    break;

                                    case 2:
                                    for(int a=0; a<=total_customer; a++)
                                    {
                                        customer[a].display_details(a);
                                    }
                                   
                                    break;

                                    case 3:
                                    long long p;
                                    
                                    cout<<"Enter phone number=";
                                    cin>>p;
                                    for(int a=0; a<=total_customer; a++)
                                    {
                                        bool ans=customer[a].edit_customer(p);
                                        if(ans)
                                        {
                                            cout<<"           ****** Recent details ******"<<endl;
                                            customer[a].display_details(a);
                                            cout<<"----------------------------------------------<<endl<<endl<<endl";
                                            cout<<"           ****** Add New Details ******"<<endl;
                                            customer[a].input_details();
                                            break;
                                        }
                                    }
                                    break;

                                    case 0:
                                    break;
                                    
                                    default:
                                    cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                                    cout<<"       **Try again**"<<endl;
                                   
                                    break;
                                }
                            }
                        }
                        else
                        {
                            PRODUCTS::function_of_product_details();
                        }
                        employee_value=-1;
                        break;

                        case 8:
                        if(man=="cashier" || man=="Cashier")
                        {
                            CUSTOMER::earning_details(total_customer);
                           
                        }
                        break;

                        case 0:
                        break;

                        default:
                        cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                        cout<<"       **Try again**"<<endl;
                       
                        break;
                    }
                }
                employee_value=-1;
            }//Teacher Section
            else
            {
                guard_answer=SECURITY_GUARD::check_login(special_guard,total_guard,login_user_name,login_password); 
                if(guard_answer)
                {
                    string login_guard=login_user_name;
                    int login_index,guard_value=-1;
                    for(int a=0; a<=total_guard; a++)
                    {
                        if(login_guard==special_guard[a].name)
                        {
                            login_index=a;
                            break;
                        }
                    }
                    while(guard_value!=0)
                    {
                      
                        cout<<"**********************************************************"<<endl;
                        cout<<"                Welcome To '"<<login_guard<<"'"<<endl;
                        cout<<"**********************************************************"<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"* Press '1' to view own details"<<endl;
                        cout<<"* Press '2' to change password"<<endl;
                        cout<<"* Press '3' to send Message to someone"<<endl;
                        cout<<"* Press '4' to view Messages"<<endl;
                        cout<<"* Press '5' to delete all Messages"<<endl;
                        cout<<"* Press '0' to Logout"<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"Enter your value=";
                        cin>>guard_value;

                        string m,n,sender=login_guard;
                        int index;
                        bool jwab=true;

                        switch (guard_value)
                        {
                            case 1:
                          
                            special_guard[login_index].display_details();
                            cout<<"press any key to continue...";
                           
                            break;

                            case 2:
                          
                            special_guard[login_index].change_password();
                            cout<<endl;
                            cout<<"Change password successfully!";
                           
                            break;

                            case 3:
                          
                            cout<<"Write a message=";
                            cin>>m;
                            cout<<"Write a User Name=";
                            cin>>n;
                            for(int a=0; a<=total_guard; a++)
                            {
                                if(n==special_guard[a].user_name)
                                {
                                    jwab=false;
                                    special_guard[a].send_message_fuction(sender, m);
                                    cout<<"Send message succesfully!!";
                                    break;
                                }
                            }    
                            if(n=="manager")
                            {
                                manager.send_message_fuction(sender, m);
                                cout<<"Send message succesfully!!";
                                jwab=false;
                            }
                            if(jwab)
                            {
                                cout<<"******* You Enter invalid User_Name ***********"<<endl;
                            }
                           
                            break;

                            case 4:
                          
                            special_guard[login_index].view_message();
                            cout<<"press any key to continue...";
                           
                            break;

                            case 5:
                          
                            special_guard[login_index].delete_messages_function();
                            cout<<"press any key to continue...";
                           
                            break;
                            case 0:
                            break;
                            
                            default:
                            cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                            cout<<"       **Try again**"<<endl;
                           
                            break;
                        }

                    }
                    guard_value=-1;
                }//Guard Section
                else
                {
                    cout<<endl<<endl<<endl<<"***** Invalid your values *****"<<endl;
                    cout<<"       **Try again**"<<endl;
                   
                }
            }
        }
        



    }//while(true)    
    return 0;
}//int main
