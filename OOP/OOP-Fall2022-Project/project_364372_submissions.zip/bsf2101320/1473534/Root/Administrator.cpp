//Administrator class inherits Staff, Deletion and Account class
#include "Administrator.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;
void Administrator::Administrator_fun(){
	m3:       //Label
			cout<<"\n\n\n\t\t\t\t\t\t============================================================\n";
			cout<<"\n\t\t\t\t\t\t\t\t::WELCOME ADMINISTRATOR::"<<endl;
			cout<<"\n\t\t\t\t\t\t============================================================\n"<<endl;
			cout<<endl;
			cout<<"\t\t\t\t\t\t\t\t1).EMPLOYEE RECRUITMENT"<<endl;
			cout<<"\t\t\t\t\t\t\t\t2).VIEW ALL STAFF RECORD"<<endl;
			cout<<"\t\t\t\t\t\t\t\t3).SEARCH STAFF RECORD"<<endl;
			cout<<"\t\t\t\t\t\t\t\t4).SEARCH ACCOUNT NUMBER"<<endl;
			cout<<"\t\t\t\t\t\t\t\t5).ACCOUNT HOLDERS LIST"<<endl;	
			cout<<"\t\t\t\t\t\t\t\t6).DELETE COMPLETE CUSTOMER RECORD"<<endl;
			cout<<"\t\t\t\t\t\t\t\t7).CLOSE APPLICATION"<<endl;
            cout<<endl;
            cout<<"\n\t\t\t\t\t\t\t\tPLEASE SELECT ONE OPTION(1-7)"<<endl;
			int n;
			cin>>n;
			 if(n==1){      //Employee recruiting 
          GetEmployeeData();     
			 	
			 }
			else if(n==2){     //Staff list
           viewstaff();
			 }
			else if(n==3){       //Search Staff member
		   searchstaff();
			
		}
			 else if(n==6){       //Delete Complete Customer record
			deleting(); 	
		}
		    else if(n==5){        //Account Holder list 
		
					cout<<"\n\t\t\t\t\t\t\t\t\t::Account Holder List::\n\t\t\t\t"<<endl;
		    	acc_Holder_List();
			}
			else if(n==4){        //search specific account holder
		
					cout<<"\n\t\t\t\t\t\t\t\t\t::Acc Holder Searching Page::\n\t\t\t\t"<<endl;
				searching();
			}
			else if(n==7){        //logged out of system
	
					cout<<"\n\n\t\t\t\t\t\t\t\t::LOGGED OUT::"<<endl;
			
			}
			else{
		
				cout<<"\n\t\t\t\t\t\t\t\t\t::You Entered Wrong Number::"<<endl;
			}
			cout<<"\nPress 2 To Go Administrator Page:"<<endl;
					int b;
					cin>>b;
					if(b==2){
						goto m3;
					}
					else{
						cout<<"\n\t\t\t\t\t\t\t\t\tYou Have Entered The Wrong Number"<<endl;
					}
}