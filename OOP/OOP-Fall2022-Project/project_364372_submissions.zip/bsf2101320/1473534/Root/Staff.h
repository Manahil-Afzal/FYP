//Staff Class
#ifndef STAFF_H
#define STAFF_H
#include <string>
using namespace std;
class Staff
{
	protected:
	    string id, name, position, email, phone, education;	
	public:
		void GetEmployeeData();
        void viewstaff();
        void searchstaff();
};

#endif