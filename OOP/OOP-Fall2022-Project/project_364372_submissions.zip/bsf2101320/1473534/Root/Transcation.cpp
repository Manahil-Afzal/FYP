//Transaction class inherits both withdraw and deposite class
#include "Transcation.h"
#include<fstream>
#include<stdio.h>
void Transcation::Transcation_withdraw(){
	withdraw_amount();
	
}
void Transcation::Transcation_deposit(){
	deposite_amount();
	
	
}
void Transcation::showDopsite(){
	display_deposit();
}
void Transcation::show_Withdraw(){
	showdata_withdraw();
}