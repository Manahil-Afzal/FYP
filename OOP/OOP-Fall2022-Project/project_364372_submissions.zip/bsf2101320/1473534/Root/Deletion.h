//Deletion Class
#ifndef DELETION_H
#define DELETION_H

class Deletion
{
	public:
	void deleting();
};

#endif