//Transaction Class
#ifndef TRANSCATION_H
#define TRANSCATION_H
#include "withdraw.h"
#include "deposit.h"

class Transcation : public withdraw,deposit
{
	public:
		void Transcation_withdraw();
		void Transcation_deposit();
		void showDopsite();
		void show_Withdraw();
};

#endif