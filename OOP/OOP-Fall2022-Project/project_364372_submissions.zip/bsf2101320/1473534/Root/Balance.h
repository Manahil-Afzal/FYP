//Balance Class
#ifndef BALANCE_H
#define BALANCE_H
#include <string>
using namespace std;

class Balance
{
	protected:
	public:
		void balance_enquiry();
    
};

#endif
