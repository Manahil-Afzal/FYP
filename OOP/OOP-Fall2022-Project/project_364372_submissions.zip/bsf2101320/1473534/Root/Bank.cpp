//Bank Class Inherits Accounts, Modify and Balance class
#include "Bank.h"
#include<fstream>
#include<stdio.h>
using namespace std;
void Bank::Account_Func(){
	create_account();
	showdetail();
}
void Bank::Modification_Func(){
	modify_acc();
}
void Bank::Check_balance(){
	balance_enquiry();
}