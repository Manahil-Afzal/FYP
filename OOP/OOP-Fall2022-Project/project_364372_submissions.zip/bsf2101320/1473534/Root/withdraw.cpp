//Withdraw class performs the amount withdraw from account
#include "withdraw.h"
#include <iostream>
#include<fstream>
#include<stdio.h>
using namespace std;
void withdraw::withdraw_amount(){
    float Grandtotal=10000;
	    	cout<<"\n\t\t\t\t\t\t\t\t::WITHDRAW AMOUNT PAGE::"<<endl;
			cout<<"\n\t\t\t\t\t\t\t\tEnter Your Account Number:";
			cin>>accno;
			cout<<"\n\t\t\t\t\t\t\t\tEnter Your Pin Code:";
			cin>>pin;
			cout<<"\n\t\t\t\t\t\t\t\tAccount Type (C/S):";
			cin>>accountType;
			cout<<"\n\t\t\t\t\t\t\t\tEnter the Amount You Want to Withdraw:";
			cin>>amount;
			Total=Grandtotal-amount;
			cout<<"\n";
			cout<<"\n\t\t\t\t************************************::Withdraw Detail::************************************"<<endl;
			}
			void withdraw::showdata_withdraw(){
			cout<<"\n\t\t\t\t\t\t\t\tAccount Number:"<<accno;
			cout<<"\n\t\t\t\t\t\t\t\tAccount Type:"<<accountType;
			cout<<"\n\t\t\t\t\t\t\t\tYour Amount:"<<amount;
			cout<<"\n\t\t\t\t\t\t\t\tYour Remaining Balance is:"<<Total;
			cout<<endl;
			ofstream wfile;
			wfile.open("Withdraw.txt",ios::app);
			wfile<<accno<<"\t"<<pin<<"\t"<<accountType<<"\t"<<amount<<"\t"<<Total<<endl;
			wfile.close();
			cout<<"\n";
	}
