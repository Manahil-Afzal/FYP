//Modify Class
#ifndef MODIFY_H
#define MODIFY_H
#include<string>
using namespace std;

class Modify
{
	protected:
	string accountType, name, accno, address;
	int x, y;
	public:
	void modify_acc();
};

#endif