//Modify class performs the modification of an account  
#include "Modify.h"
#include <iostream>
#include<fstream>
#include<stdio.h>
using namespace std;
void Modify::modify_acc(){
	cout<<"\n\t\t\t\t\t\t\t\tAccount No. : ";
	cin>>accno;
	cout<<"\n\t\t\t\t\t\t\t\tEnter Your Old Pin:";
	cin>>x;
	cout<<"\n\t\t\t\t\t\t\t\tModify Account Holder Name : ";
	cin>>name;
	cout<<"\n\t\t\t\t\t\t\t\tModify Type of Account (C/S) : ";
	cin>>accountType;
	cout<<"\n\t\t\t\t\t\t\t\tModify Address : ";
	cin>>address;
	cout<<"\n\t\t\t\t\t\t\t\tModify Pin : ";
	cin>>y;
	cout<<"\n";
	cout<<"\n\t\t\t\t******************************::Your Account is Updated::***********************************";
	cout<<"\n";
}