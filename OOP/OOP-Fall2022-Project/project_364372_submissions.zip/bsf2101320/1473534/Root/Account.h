//Account Class
#ifndef ACCOUNT_H
#define ACCOUNT_H
#include<string>
using namespace std;
class Account
{
	protected:
		string accno, name, type, amount ; 
		public:
		void create_account();
		void showdetail();
		void acc_Holder_List();
		void searching();
};

#endif