//Account Class performs account creation, account holder list and searching specific account
#include "Account.h"
#include <iostream>
#include<fstream> //For File Handling
#include<stdio.h>
#include <string>
using namespace std;

void Account::create_account(){ //Account Creation Information
	cout<<"\n\t\t\t\t\t\t\t\t::Account Creation PAGE::"<<endl;
	cout<<"\n\t\t\t\t\t\t\t\tEnter the Account No. : ";
	cin>>accno;
	cout<<"\n\t\t\t\t\t\t\t\tEnter the Name of the Account Holder : ";
	cin>>name;
	cout<<"\n\t\t\t\t\t\t\t\tEnter Type of the Account (C/S) : ";
	cin>>type;
	cout<<"\n\t\t\t\t\t\t\t\tEnter The Initial Amount : ";
	cin>>amount;
	cout<<"\n\t\t\t\t************************************::Account Created::************************************"<<endl;
	}
void Account::showdetail(){
	cout<<"\n\t\t\t\t\t\t\t\tAccount Number:"<<accno<<"\n\t\t\t\t\t\t\t\t"<<"Account Holder Name:"<<name<<"\n\t\t\t\t\t\t\t\t"<<"Account Type:"<<type<<"\n\t\t\t\t\t\t\t\t"<<"Your Balance:"<<amount<<"\n";
	ofstream wfile;
			wfile.open("Account.txt",ios::app);//File Opening
			wfile<<accno<<"\t\t"<<name<<"\t\t"<<type<<"\t\t"<<amount<<endl;
			wfile.close();
	}
void Account::acc_Holder_List(){ //Account Holder list
	ifstream output;
	output.open("Account.txt");
	while (!output.eof()){
		char display[1000];
	output.getline(display,1000);
	cout<<display<<endl;
	}
	
}
void Account::searching()  //To search an account
{

    int offset;
    std::string Account_Number, line;
    ifstream filee;
    filee.open("Account.txt");
    cout << "\n\t\t\t\t\t\t\t\tType the Account Number to Search:"<<endl;
    cin >>Account_Number;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(Account_Number, 0))) != string::npos)
            {
                cout<<"\nAcc No.          Name         Type             Amount"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
    }
       
     
    cout<<"\n";  
}