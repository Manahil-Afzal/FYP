//Balance class performs the balance checking of an account 
#include "Balance.h"
#include <iostream>
#include<fstream>
#include<stdio.h>
using namespace std;

void Balance::balance_enquiry()
{
    int offset;
    std::string Account_Number, line;
    ifstream filee;
    filee.open("Account.txt");
    cout << "\n\t\t\t\t\t\t\t\tEnter the Account Number to Check Balance:"<<endl;
    cin >>Account_Number;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(Account_Number, 0))) != string::npos)
            {
                cout<<"\nAcc No.          Name         Type             Amount"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        
           
        }
        filee.close();
    }
    cout<<"\n";
   
}