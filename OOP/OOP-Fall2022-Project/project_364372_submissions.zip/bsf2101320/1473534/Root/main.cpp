/* Group Members Name For Project:
 M.Ahmad Awan (BSF2101320)
 Hassnain Imran (BSF2101092) 
 M.Husnain (BSF2101105)
 Furqan Majeed (BSF2101089)
 M.Awais (BSF2100760)
 
   Project Name: BANK MANAGEMENT SYSTEM
    ::Statement::
       Bank Management System is based on a concept of recording customer�s, employees data and account details.
	Here the user can perform all the tasks like creating an account, deposit amount, withdraw amount, check balance
	and modify an account.On the Other hand,the admin can also performs various tasks like recruiting employees, view all
	employees record, search an employee id, view all customers list, search specific employee and delete complete customer
	record. There�s no login system for this project.All the main features for banking system are set in this project.
	
	    A class named as Account is created in which user can create an account by providing the name of the account
	holder, account number, select account type whether its saving account or current account and providing an initial
	amount. Then the other class named as Transaction is create in which user can also deposit and withdraw money just by
	providing his/her account number and pin. Transaction class inherits both withdraw and deposite class. Another class 
	Balance is created, for certain purpose a user can also check for the balance inquiry which displays the account 
	holder's name, account type and account number and balance. Another class named as Modify is created in which a user 
	can also modify their account detail. Bank class inherits Account class, Modify class and Balance class. 
        Another, Staff class is created in which Admin can recruit employees by providing them id and by taking their
	name, phone, email, education. Another Administrator class is created in which Staff class, Deletion class and Account 
	class is inherited. Admin can also search an specific employee and customer by providing their id and account number.
	Admin can also view all staff and customers record. It can also delete all customers record.
                   
 */
 
#include <iostream>
#include <stdio.h>
#include "Transcation.h"
#include "Bank.h"
#include "Administrator.h"

using namespace std;
int main(){
	// Creating object of classes
	Administrator A;
	Transcation T;
	Bank B;

    m:  //Label
				cout<<"\n"<<endl;    
			cout<<"\n\n\n\t\t\t\t\t\t============================================================\n";
			cout<<"\n\t\t\t\t\t\t\t\t::BANK MANAGEMENT SYSTEM::"<<endl;
			cout<<"\n\t\t\t\t\t\t============================================================\n";
			cout<<"\n\t\t\t\t\t\t\t\t::MAIN MENU::"<<endl;
			cout<<"\n\n\t\t\t\t\t\t\t\t1).ACCOUNT CREATION"<<endl;
			cout<<"\t\t\t\t\t\t\t\t2).DEPOSITE"<<endl;
			cout<<"\t\t\t\t\t\t\t\t3).WITHDRAW"<<endl;
			cout<<"\t\t\t\t\t\t\t\t4).BALANCE ENQUIRY"<<endl;
			cout<<"\t\t\t\t\t\t\t\t5).ACCOUNT MODIFICATION"<<endl;
			cout<<"\t\t\t\t\t\t\t\t6).ADMINISTRATOR"<<endl;
			cout<<"\t\t\t\t\t\t\t\t7).CLOSE APPLICATION"<<endl;
			cout<<"\n\t\t\t\t\t\t\t\tPLEASE SELECT ONE OPTIONS (1-7)"<<endl;
			int n;
			cin>>n;
			switch(n){
				case 1:
			

					cout<<"\n\t\t\t\t\t\t\t\t::ACCOUNT CREATION PAGE::"<<endl;
                   B.Account_Func();
                   cout<<"Press 1 To Go To Main Menu:"<<endl;
					int k;
					cin>>k;
					if(k==1){
						goto m;
					}
					break;
				case 2:
			

					cout<<"\n\t\t\t\t\t\t\t\t::DEPOSITE AMOUNT PAGE::"<<endl;
					  T.Transcation_deposit();
					  T.showDopsite();
					cout<<"Press 1 To Go To Main Menu:"<<endl;
					int x;
					cin>>x;
					if(x==1){
						goto m;
					}
				    break;
				case 3:
				

					cout<<"\n\t\t\t\t\t\t\t\t::WITHDRAW AMOUNT PAGE::\n\t\t\t\t"<<endl;
					  T.Transcation_withdraw();
					  T.show_Withdraw();
					  cout<<"Press 1 To Go To Main Menu:"<<endl;
					int l;
					cin>>l;
					if(l==1){
						goto m;
					}
					break;
				case 4:
			

					cout<<"\n\t\t\t\t\t\t\t\t\t::BALANCE ENQUIRY PAGE::\n\t\t\t\t"<<endl;
					B.Check_balance();
					cout<<"Press 1 To Go To Main Menu:"<<endl;
					int z;
					cin>>z;
					if(z==1){
						goto m;
					}
				break;	
				case 5:
				

					cout<<"\n\t\t\t\t\t\t\t\t::ACCOUNT MODIFICATION PAGE::\n\t\t\t\t"<<endl;
					B.Modification_Func();
					cout<<"Press 1 To Go To Main Menu:"<<endl;
					int p;
					cin>>p;
					if(p==1){
						goto m;
					}
					break;
				case 6:
			

					cout<<"\n\t\t\t\t\t\t\t\t\t::ADMINISTRATOR PAGE::\n\t\t\t\t"<<endl;
				    A.Administrator_fun();
					cout<<"Press 1 To Go To Main Menu:"<<endl;
					int t;
					cin>>t;
					if(t==1){
						goto m;
					}
				break;	
				case 7:
			
					cout<<"\n\t\t\t\t\t\t\t\t::Thank You For Using Bank Management System::"<<endl;
					break;	
			}
			int b;
			if(b<=7){
			
				cout<<"\n\t\t\t\t\t\t\t\t\t::You Entered Wrong Number::"<<endl;
			}
			cout<<"Press 1 To Go To Main Menu:"<<endl;
					int r;
					cin>>r;
					if(r==1){
						goto m;     //Go back to main menu
						
					}
	
	return 0;
}

