//Deposite class performs deposite of amount in account
#include "deposit.h"
#include <iostream>
#include<fstream>
#include<stdio.h>
using namespace std;
void deposit::deposite_amount(){
    	float Grandtotal=10000;
	    	cout<<"\n\t\t\t\t\t\t\t\t::Deposite AMOUNT PAGE::"<<endl;
			cout<<"\n\t\t\t\t\t\t\t\tEnter Your Account Number:";
			cin>>accno;
			cout<<"\n\t\t\t\t\t\t\t\tEnter Your Pin Code:";
			cin>>pin;
			cout<<"\n\t\t\t\t\t\t\t\tAccount Type (C/S):";
			cin>>accountType;
			cout<<"\n\t\t\t\t\t\t\t\tEnter the Amount You Want to Deposite:";
			cin>>amount;
			Total=Grandtotal+amount;
			cout<<"\n";
			cout<<"\n\t\t\t\t************************************::Deposite Detail::************************************"<<endl;
			}
void deposit::display_deposit(){
			cout<<"\n\t\t\t\t\t\t\t\tAccount Number:"<<accno;
			cout<<"\n\t\t\t\t\t\t\t\tAccount Type:"<<accountType;
			cout<<"\n\t\t\t\t\t\t\t\tYour Amount:"<<amount;
			cout<<"\n\t\t\t\t\t\t\t\tYour Remaining Balance is:"<<Total;
			cout<<endl;
			ofstream wfile;
			wfile.open("Deposite.txt",ios::app);
			wfile<<accno<<"\t"<<pin<<"\t"<<accountType<<"\t"<<amount<<"\t"<<Total<<endl;
			wfile.close();
			
			
	}