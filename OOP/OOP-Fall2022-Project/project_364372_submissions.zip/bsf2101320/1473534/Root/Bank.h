//Bank Class
#ifndef BANK_H
#define BANK_H
#include "Account.h"
#include "Modify.h"
#include "Balance.h"

class Bank : public Account, Modify, Balance
{
	public:
	void Account_Func();
	void Modification_Func();
	void Check_balance();
};

#endif