//Administrator class
#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
#include "Staff.h"
#include "Deletion.h"
#include "Account.h"

class Administrator : public Staff, Deletion, Account
{
	public:
	void Administrator_fun();
	
};

#endif
