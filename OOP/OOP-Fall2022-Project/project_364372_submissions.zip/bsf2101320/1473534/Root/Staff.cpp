//Staff class performs the employees recruitment, searching staff member and all staff record 
#include "Staff.h"
#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;
	void Staff::GetEmployeeData(){      //Get Employee Information

		
			     cout<<"\n\t\t\t\t\t\t\t\t::New Employee Profile::"<<endl;
                 cout<<"\n\t\t\t\t\t\t\t\tEmployee ID:";
				 cin>>id;
				 cout<<"\n\t\t\t\t\t\t\t\tEmployee Name:";
				 cin>>name;
				 cout<<"\n\t\t\t\t\t\t\t\tEmployee Position:";
				 cin>>position;
				 cout<<"\n\t\t\t\t\t\t\t\tEmployee Phone No. :";
				 cin>>phone;
				 cout<<"\n\t\t\t\t\t\t\t\tEmployee Email:";
				 cin>>email;
				 cout<<"\n\t\t\t\t\t\t\t\tEmployee Education:";
				 cin>>education;
				 cout<<"\n\n\t\t\t\t************************************::Employee Data Saved Successfully::************************************";
				 ofstream staff;
				 staff.open("Staff.txt",ios::app);      //Opening Staff File
				 staff<<id<<"\t\t"<<name<<"\t\t"<<position<<"\t\t"<<phone<<"\t\t"<<email<<"\t\t"<<education<<endl;
		}
			void Staff::viewstaff(){
		char display[1000];
		ifstream staff;
		staff.open("Staff.txt",ios::app);
		cout<<"\n\t\t\t\t\t\t\t\t::STAFF LIST::"<<endl;
		while(!staff.eof()){
			staff.getline(display,1000);
			cout<<display<<endl;
			
		}
		staff.close();
		}
		
	void Staff::searchstaff(){       //Search specific employe	
    int offset;
    std::string Employee_ID, line;
    ifstream filee;
    filee.open("Staff.txt");
    cout<<"\n\t\t\t\t\t\t\t\t::STAFF SEARCH PAGE::";
    cout<<endl;
    cout << "\n\t\t\t\t\t\t\t\tType the Employee ID to Search:"<<endl;
    cin >>Employee_ID;
    if (filee.is_open())
    {

        while (!filee.eof())
        {
            getline(filee, line);
            if (((offset = line.find(Employee_ID, 0))) != string::npos)
            {
                cout<<"\n ID             Name          Position           Phone No.                 E-mail                   Education"<<endl;
                cout << "\n"<<line<<endl;
                break;
            }
        }
        filee.close();
    }
    
     
    cout<<"\n";  
}