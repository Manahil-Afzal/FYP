//Deletion class performs the deletion of complete account file
#include "Deletion.h"
#include <iostream>
#include<fstream>
#include<stdio.h>
using namespace std;

void Deletion::deleting()
{
  string accno;	
  string line;
  ifstream myfile;
  ofstream temp;
  myfile.open("Account.txt");     //File to be Deleted
  while (getline(myfile, line))
  {
    if (line != accno)
      temp << line << endl;
  }
  cout << "\n\n\t\t\t\t**************************::Your Existing Customer File Has Been Deleted::**************************" << endl;
  cout<<endl;
  myfile.close();
  remove("Account.txt");      //Account File delete
}
