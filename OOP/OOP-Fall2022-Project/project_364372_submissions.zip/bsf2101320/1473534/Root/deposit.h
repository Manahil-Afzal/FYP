//Deposite Class
#ifndef DEPOSIT_H
#define DEPOSIT_H
#include <string>
using namespace std;
class deposit
{
	protected:
		string pin,accountType, accno;
		int amount, Total;
	
	public:
	 void   deposite_amount();
	 void   display_deposit();
};

#endif
