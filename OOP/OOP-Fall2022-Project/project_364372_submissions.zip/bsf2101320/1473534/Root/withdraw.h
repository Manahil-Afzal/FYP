//Withdraw Class
#ifndef WITHDRAW_H
#define WITHDRAW_H
#include <string>
using namespace std;
class withdraw
{
	protected:
	string pin,accountType, accno;
	int amount, Total;
	
    
	public:
    void withdraw_amount();
    void showdata_withdraw();
};

#endif
