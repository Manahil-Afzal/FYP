#include"Customer.h"
#include<iostream>
#include<cstring>
#include<string>
void Customer::set_customer_details(){
	cin.ignore();
	cout<<"\nEnter your id:";
	getline(cin,customer_id);
	cout<<"Enter your name:";
	getline(cin,customer_name);
} 