#include"Customer.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class hotel{ //hotel class:used to show or edit the details of hotel. It also contains Customer class i.e, composition relation.
	private:
		string h_name="Roosevelt";
		string h_address="St#2 D Block California";
		int no_of_employees=10;
		Customer customer_obj; //object of customer class created
	public:	
        hotel();	
	    hotel(int h);  //parametrized constructor inside of which Customer class is accessed.
		void set_hotel_details();  //to change hotel details by Employer only.
	    void get_hotel_details();  //to display the hotel details
		};