#include"Employees.h"
#include"Chefs.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;
   
void Chefs::default_chefs_detail(){
	cout<<"\n\tChefs Detail\n";
	for(int i=0;i<5;i++){
	   	cout<<"ID : "<<c_id_default[i]<<"\tName : "<<c_name_default[i]<<"\tSalary : "<<c_salary_default[i]<<endl;
	   }
}    
    
void Chefs::edit_chefs_detail(){
	cout<<"\nEnter Chef's ID:";
	cin>>e_id;
	cin.ignore();
	cout<<"Enter Chef's name:";
	getline(cin,e_name);
	cout<<"Enter Chef's salary:";
	getline(cin,salary);
		}
void Chefs::show_chefs_detail(){
	cout<<"\nChef ID : "<<e_id<<endl;
	cout<<"Chef Name : "<<e_name<<endl;
	cout<<"Chef Salary : "<<salary<<endl;
}
void Chefs::prepare_order(){
	cout<<"\n\tChef has prepared your order.";
}	
	
