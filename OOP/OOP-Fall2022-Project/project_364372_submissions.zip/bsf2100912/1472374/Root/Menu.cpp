#include"Menu.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

void Menu::show_menu(){
	   cout<<"\nSelect desired order:\n";
	   for(int i=0;i<8;i++){
	   	cout<<"\t"<<item_id[i]<<" :"<<item_name[i]<<"\tPrice:"<<item_price[i]<<endl;
	   }
}  

