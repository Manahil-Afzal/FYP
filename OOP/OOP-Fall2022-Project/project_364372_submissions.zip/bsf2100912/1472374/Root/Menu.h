#ifndef MENU_H
#define MENU_H
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Menu {   //Menu class: used to show menu to the customer. Menu class is also inheriting its data members to Order & Bill classes.
  	public:
  		string item_id[8]={"1","2","3","4","5","6","7","8"};
  	    string item_name[8]={"Pizza","Burger","Fish ","Biryani","Coffee","Mutton","Sandwich","Tea  "};
       	int item_price[8]={799,170,1200,250,120,1099,175,100};   	
       	void show_menu();   //Method to show the above details in form of menu to customer
  
  };
#endif