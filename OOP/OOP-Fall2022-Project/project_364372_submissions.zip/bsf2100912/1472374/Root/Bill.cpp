#include"Menu.h"
#include"Bill.h"
#include"Order.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

 Bill::Bill(){
 }

 void Bill::set_bill_id(int g){         
     
	        f=g;
}

void Bill::bill_id1(){
	cout<<" Your bill is Rs."<<f*item_price[0]<<".\n";
}
void Bill::bill_id2(){
	cout<<" Your bill is Rs."<<f*item_price[1]<<".\n";
}
void Bill::bill_id3(){
	cout<<" Your bill is Rs."<<f*item_price[2]<<".\n";
}
void Bill::bill_id4(){
	cout<<" Your bill is Rs."<<f*item_price[3]<<".\n";
}
void Bill::bill_id5(){
	cout<<" Your bill is Rs."<<f*item_price[4]<<".\n";
}
void Bill::bill_id6(){
	cout<<" Your bill is Rs."<<f*item_price[5]<<".\n";
}
void Bill::bill_id7(){
	cout<<" Your bill is Rs."<<f*item_price[6]<<".\n";
}
void Bill::bill_id8(){
	cout<<" Your bill is Rs."<<f*item_price[7]<<".\n";
}


