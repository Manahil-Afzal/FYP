#include"Payment.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

void Payment_method::display_payment_method(){
	cout<<" Please select payment method:\n\t 1-Cash Payment\n\t 2-Via ATM\n\t 3-Jazzcash\n\t 4-Easypaysa"<<endl;
}
