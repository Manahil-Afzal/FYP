#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Payment_method{ //Payment_method is an independent class used to ask the payment method from customer.
	public:
		void display_payment_method();
};
