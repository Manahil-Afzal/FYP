#include"Menu.h"
#include"Order.h"
#include"Bill.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

Order::Order(int i){ 
	h=i;
	bill_obj.set_bill_id(i);  //bill id selected according to order id.
}; 

    //Different behaviours according to different order id's.
    
void Order::order_id1(){
	cout<<"You have selected item id "<<item_id[0]<<" and ordered "<<h<<" piece/s of "<<item_name[0]<<".\n";
	bill_obj.bill_id1();
}
void Order::order_id2(){
	cout<<"You have selected item id "<<item_id[1]<<" and ordered "<<h<<" piece/s of "<<item_name[1]<<".\n";
	bill_obj.bill_id2();
}
void Order::order_id3(){
	cout<<"You have selected item id "<<item_id[2]<<" and ordered "<<h<<" piece/s of "<<item_name[2]<<".\n";
	bill_obj.bill_id3();
}
void Order::order_id4(){
	cout<<"You have selected item id "<<item_id[3]<<" and ordered "<<h<<" piece/s of "<<item_name[3]<<".\n";
	bill_obj.bill_id4();
}
void Order::order_id5(){
	cout<<"You have selected item id "<<item_id[4]<<" and ordered "<<h<<" piece/s of "<<item_name[4]<<".\n";
	bill_obj.bill_id5();
}
void Order::order_id6(){
	cout<<"You have selected item id "<<item_id[5]<<" and ordered "<<h<<" piece/s of "<<item_name[5]<<".\n";
	bill_obj.bill_id6();
}
void Order::order_id7(){
	cout<<"You have selected item id "<<item_id[6]<<" and ordered "<<h<<" piece/s of "<<item_name[6]<<".\n";
	bill_obj.bill_id7();
}
void Order::order_id8(){
	cout<<"You have selected item id "<<item_id[7]<<" and ordered "<<h<<" piece/s of "<<item_name[7]<<".\n";
	bill_obj.bill_id8();
}


