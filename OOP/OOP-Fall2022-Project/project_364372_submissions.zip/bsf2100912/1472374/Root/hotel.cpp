#include"hotel.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

hotel::hotel(){
}		
		
hotel::hotel(int h){
	customer_obj.set_customer_details();
}				
	
void hotel::set_hotel_details(){
	    cin.ignore();
	    cout<<"Enter Hotel's name:";
	    getline(cin,h_name);
	    cout<<"Enter Hotel's Address:";
	    getline(cin,h_address);
	    cout<<"Enter no. of Employees:";
	    cin>>no_of_employees;
		  }		  
void hotel::get_hotel_details(){
		  	cout<<"Name of hotel : "<<h_name<<endl;
		  	cout<<"Hotel Address : "<<h_address<<endl;
		  	cout<<"Number of employees :"<<no_of_employees<<endl;
		  }
