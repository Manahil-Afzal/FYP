#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Waiters:public Employees{ //Waiters class inherited from Employees class.
	private:
		//Specific attributes of Waiters class to be used.
	 	string w_id_default[5]={"1","2","3","4","5"};
  	 	string w_name_default[5]={"Mr.Khalid","Ali Riaz ","Mr. Boota","Mr.Kaleem","Mr.Raheem"};
  		string w_salary_default[5]={"30,000","32,000","35,000","31,000","35,000"};	
	public:
		void default_waiters_detail();  //To show the original waiters detail.
		void edit_waiters_detail();     //To edit the waiters detail by employer only.
		void show_waiters_detail();     //To display the edited details of waiters by employer only.
		void serve_order();             //To serve the order of customer.
	};
	