#include"Menu.h"
#include"Bill.h"
#include<iostream>
#include<cstring>
#include<string>

class Order:public Menu {  //Order class: used to select the order id selected by a customer. It inherits data members from Menu class.
	public:
		int h; //variable for order id in this class.
		Order(int i);  //Parametrized constructor to receive order id.
		void order_id1();
		void order_id2();
		void order_id3();
		void order_id4();
		void order_id5();
		void order_id6();
		void order_id7();
		void order_id8();
		
		Bill bill_obj;     //Order class also contains Bill class to make the bill according to selected order i.e, composition relation. 
};

