#include"Employees.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

Employees::Employees(){
	
}