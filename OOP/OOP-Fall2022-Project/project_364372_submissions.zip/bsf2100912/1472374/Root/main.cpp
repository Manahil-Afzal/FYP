// Main function of the C++ program.

/*    Group members:

       Muhammad Subhan         (bsf2100772)
       Usama Razzaq            (bsf2100912)
       Samama Babar            (bsf2101178)
       Zohaib-ul-Hassan        (bsf2101287)

Statement:-
       Develop a hotel management system that keeps the information of hotel as well as its employees i.e, waiters and chefs. It should provide Employer a manual 
to view or edit the information about hotel, chefs and waiters (this service should be restriced only for Employer of the hotel i.e, password based). It should 
also provides a menu  to the customers from which they can choose an order. Then bill of the selected order should also be shown to Customers. Customers should 
be given different methods of paying the bills, according to their ease. The waiter then takes orders and forwards to the chefs. Chefs then prepare the order and
waiters serve order to customers.


 */
 
 
 
 
  //All class files headers are included:
#include"Customer.h"
#include"hotel.h"
#include"Employees.h"
#include"Waiters.h"
#include"Chefs.h"
#include"Menu.h"
#include"Bill.h"
#include"Order.h"
#include"Payment.h"
#include"Table.h"
 
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

int main(){
	hotel hotel_obj; // object of class hotel is created.
	int choice;    //choice: Whether to open Employer manual or customer manual.
	cout<<"Choose option:\n  "<<"1-Employer\t"<<"2-Customer\n";
	cin>>choice;
	if(choice==1){
		int password=1489;   //password required to open Employer manual.
		cout<<"Enter password:";
		cin>>password;
		if(password!=1489)
		cout<<"Wrong password!";
		else if(password==1489){
		cout<<"\nWelcome to Employer Manual"<<endl;	
		int choice_2;  //choice: Whether to see details or Edit details.
		cout<<"\nEnter\n \t1-Show Details\n \t2-Edit Details"<<endl;
		cin>>choice_2;
		if(choice_2==1){
			cout<<"\n\n\tHotel Details\n\n";
			hotel_obj.get_hotel_details();
			Waiters waiters; //object of Waiters class is created
			waiters.default_waiters_detail();
			Chefs chefs;     //object of Chefs class is created
			chefs.default_chefs_detail();
		}
		else if(choice_2==2){
		int details; //choice: Whether to edit hotel details,waiters details or Chefs details.
		cout<<"Enter\n \t1- Edit Hotel Details\n \t2- Edit Waiters Detail\n \t3- Edit Chef Details"<<endl;
		cin>>details;
		if(details==1){
		hotel_obj.set_hotel_details();
		hotel_obj.get_hotel_details();	
		}
		else if(details==2){
			int k;  //No. of waiters
			cout<<"Enter total no. of waiters:";
			cin>>k; 
			Waiters waiters_obj[k];  //array objects of Waiters created.
			cout<<"\n\t Edit Waiters' Detail \n";
			for(int i=0;i<k;i++){
			waiters_obj[i].edit_waiters_detail();}
			cout<<"\n\t Waiters' Details Displayed \n";
			for(int i=0;i<k;i++){	
			waiters_obj[i].show_waiters_detail();}
		}
		else if(details==3){
			int l;  //No. of Chefs
            cout<<"Enter total no. of chefs:";
			cin>>l; 			
			Chefs chefs_obj[l];    //array objects of Chefs created.
			for(int i=0;i<l;i++){
			chefs_obj[i].edit_chefs_detail();}
			for(int i=0;i<l;i++){
			chefs_obj[i].show_chefs_detail();}	
		}
		else
		    cout<<"Select correct option!";	
		}
		else
		cout<<"Enter the correct option!";
	}
	return 0;
}
    else if(choice==2){
    	cout<<"\nWelcome to Customer Manual"<<endl;
    	hotel hotel(1);    //parametrized object of hotel is created, as well as parametrized constructor of hotel class is called, in which we are accessing customer class.
    	Table table_obj;   //Object of table class is created 
    	table_obj.show_table_status();
    	int table=table_obj.get_table_no(); //to initialize the table no. entered by customer.
		 //to check whether the selected table is occupied or available
		   if(table == 1 ||table == 3||table == 5||table == 8 ||table==9 ) {
			table_obj.available_table();
        Menu obj_m;   //object of Menu class is created to show the menu.
    	obj_m.show_menu();
    	int order_id; //to input order id selected by customer.
    	cin>>order_id;
    	
    	//to proceed according to the order id entered by customer.
    	if(order_id==1||order_id==2||order_id==3||order_id==4||order_id==5||order_id==6||order_id==7||order_id==8){
    	int y;   //to input the number of paricular dishes customer wants to order.
    	cout<<"Enter number of dishes:";  
    	cin>>y;
    	Order order_obj(y);  /*parametrized object of Order class is created as well as parametrized constructor of Order
		 class is called. The number of dishes are passed to Order class and  Bill class through parametrized constructor 
		 of Order  class.  */
		 
    	if(order_id==1){
    	order_obj.order_id1();
    	
    }
    	else if(order_id==2){
    	order_obj.order_id2();
    }
    	else if(order_id==3){
    	order_obj.order_id3();
    }
    	else if(order_id==4){
    	order_obj.order_id4();
    }
    	else if(order_id==5){
    	order_obj.order_id5();
    }
    else if(order_id==6){
    	order_obj.order_id6();
    }
    else if(order_id==7){
    	order_obj.order_id7();
    }
    else if(order_id==8){
    	order_obj.order_id8();
    }
    
    	Payment_method payment_obj;  //object of Payment_method class is created.
    	payment_obj.display_payment_method();
    	int x; //to input payment method entered by customer.
    	cin>>x;
    	
    	//to proceed according to the payment method customer selected.
    	if(x==1||x==2||x==3||x==4){
    		Chefs chefs_obj;
			Waiters waiters_obj;
    		chefs_obj.prepare_order();
    		waiters_obj.serve_order();
		}
		else
		cout<<" Please select the correct payment method.";
	}
	else
	 cout<<"Enter correct order id";  	
}
	else 
			table_obj.occupied_table();}

   else
   cout<<"Select the correct option!"; 
   return 0;
}