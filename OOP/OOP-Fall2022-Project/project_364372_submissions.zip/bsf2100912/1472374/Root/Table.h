#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Table {     /*The class "Table" is an independent class which contains two data members and a method which display the
status of a table no. (occupied or available) which  is entered by the customer.*/

	private:
		int total_tables=10;
		int table_no; 
	public:
	    void show_table_status(); //occupied or available
	    int get_table_no();	 //to input the table no. from customer.
	    void occupied_table();  //method called when customer select occupied table.
	    void available_table(); //method called when customer select available table.
};

