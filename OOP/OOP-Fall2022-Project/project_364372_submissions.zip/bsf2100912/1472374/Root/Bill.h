#ifndef BILL_H
#define BILL_H
#include"Menu.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Bill: public Menu {    // Bill class is inherited from Menu class to get the prices of respective order. Bill class is also contained by Order class i.e, composition relation. 
	public:
		int f;       //Variable to get the id of bill with respect to order.
		Bill ();   
		void set_bill_id(int g);  //To set the bill id from order class.
		void bill_id1();
		void bill_id2();
		void bill_id3();
		void bill_id4();
		void bill_id5();
		void bill_id6();
		void bill_id7();
		void bill_id8();
};
#endif
