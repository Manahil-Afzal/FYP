#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Chefs:public Employees{    //Chefs class inherited from Employees class.
	private:
		//Specific attributes of Chef class to be used.
		string c_id_default[5]={"1","2","3","4","5"};       
  	 	string c_name_default[5]={"Salt Bae   ","Ali Khan   ","Yannick Alleno","Mr.Khubaib","Mr.Ashraf"};
  		string c_salary_default[5]={"90,000","85,000","99,000","89,000","90,000"};
	public:
		void default_chefs_detail(); //To show the original chefs detail.
		void edit_chefs_detail();    //To edit the chefs detail by employer only.
		void show_chefs_detail();    //To display the edited details of chefs by employer only.
		void prepare_order();        //To prepare the order of customer.
    };
