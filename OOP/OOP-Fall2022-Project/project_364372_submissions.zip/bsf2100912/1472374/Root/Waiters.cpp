#include"Employees.h"
#include"Waiters.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;


void Waiters::default_waiters_detail(){
	cout<<"\n\tWaiters Detail\n";
	for(int i=0;i<5;i++){
	   	cout<<"ID : "<<w_id_default[i]<<"\tName : "<<w_name_default[i]<<"\tSalary : "<<w_salary_default[i]<<endl;
	   }	
	}
	
		
void Waiters::edit_waiters_detail(){
	cout<<"\nEnter Waiter's ID:";
	cin>>e_id;
	cin.ignore();
	cout<<"Enter Waiter's name:";
	getline(cin,e_name);
	cout<<"Enter Waiter's salary:";
	getline(cin,salary);
		}
void Waiters::show_waiters_detail(){
	cout<<"\nWaiter ID : "<<e_id<<endl;
	cout<<"Waiter Name : "<<e_name<<endl;
	cout<<"Waiter Salary : "<<salary<<endl;
}
void Waiters::serve_order(){
	cout<<"\n\n\tWaiter: Here is your order Sir/Ma'am.\n\n\tPlease enjoy the meal.";
}


