#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Employees {     //Employees class: It is inheriting its data members to Chefs and Waiters class
	public:
		Employees();
		string e_id;        //ID of employee(waiter or chef)
  		string e_name;      //Name of employee(waiter or chef)
  		string salary;      //Salary of employee(waiter or chef)
	};