#include"Table.h"
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

void Table::show_table_status() {
		cout<<"\nEnter the no. of table between 1 - 10 "<<endl;
		cout<<"Table 2,4,6,7,10 = Occupied"<<endl;
		cout<<"Table 1,3,5,8,9 = Available"<<endl;
		cin>>table_no;
		}
int Table::get_table_no(){
	return table_no;	
}
void Table::occupied_table(){
	cout<<"Table is occupied."<<endl;
}		
void Table::available_table(){
	cout<<"Table is selected."<<endl;
}		 


