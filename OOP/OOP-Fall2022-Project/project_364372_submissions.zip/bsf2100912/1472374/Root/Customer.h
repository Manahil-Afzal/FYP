#ifndef CUSTOMER_H
#define CUSTOMER_H
#include<iostream>
#include<cstring>
#include<string>
using namespace std;

class Customer{ //Customer class, used to get the details of customer. It is contained by hotel class i.e,composition relation.
    private:
  		string customer_id;
  	    string customer_name;
  	public:    
  	    void set_customer_details();
};
#endif