#include"Book.h"
#include"Reader.h"
#include"Library.h"
#include<iostream>
using namespace std;

//Method declaration of class Book
     
    	Library L1;                                                                            //Object of Library  
		Reader R1;                                                                             //Object of Reader 
	void Book::input(){                                                                        //Method to input values
	
			cout<<"\n\t\t\tEnter the ID of the book: ";
			cin>>book_id;         
			cout<<"\t\t\tEnter the title of book: ";
			cin>>title;
			cout<<"\t\t\tEnter the edition of book: ";
			cin>>edition;
			cout<<"\t\t\tEnter description of book: ";
			cin>>description;
			R1.inp_type();                                                                    /*Composite Relation of Book with Reader
			                                                                                  (that input values)*/
		}
		
	void Book::output(){                                                                       //Method to output values
	
			cout<<"\n\t\tDisplaying Book Information:- "<<endl;
			cout<<"\t\t\tID of book: "<<book_id<<endl;
			cout<<"\t\t\tTitle of book: "<<title<<endl;
			cout<<"\t\t\tEdition of book: "<<edition<<endl;
			cout<<"\t\t\tDescription of book: "<<description<<endl;
			R1.out_type();                                                                    /*Composite Relation of Book with Reader
			                                                                                  (that output values)*/
		}
		
	Book::Book(){                                                                               /*Constructor of Book setting the name and
		                                                                                         address of Library*/
			L1.setname("Central Library");
			L1.setaddress("UE Township Campus");
		}
		
	void Book::show_Lib(){                                                                    //Method to output values
		
			cout<<endl<<"\t\t\t\tName of Library: "<<L1.getname()<<endl;
			cout<<endl<<"\t\t\t\tAddress of Library: "<<L1.getaddress()<<endl;
		}