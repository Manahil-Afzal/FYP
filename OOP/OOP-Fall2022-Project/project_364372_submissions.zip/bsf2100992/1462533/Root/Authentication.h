#include<iostream>
using namespace std;

//Class of Authentication
class Authentication{
	public:
		
	//Variable declaration
	     int login_id;                                                                 
		 string login_pass;   
		 
		 void set_login();                                                          //Method to input values             
		 
		 void show_auth();                                                          //Method to output values                
		 
};