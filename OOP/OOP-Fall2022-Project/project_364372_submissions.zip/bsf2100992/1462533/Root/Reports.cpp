#include<iostream>
#include"Reports.h"
using namespace std;

//Method declaration of class Reports

       void Reports::set_rep(){                                                                             //Method to input values
	     	cout<<"\n\n\t\t\tEnter the date of book issued: ";
	     	cin>>issue_date;
	     	cout<<"\t\t\tEnter the date of book returned: ";
	     	cin>>return_date;
	     	cout<<"\t\t\tEnter the registration number of reader: ";
	     	cin>>reg_no;
		 }
		 
		void Reports::show_rep(){                                                                            //Method to output values
		 	cout<<"\n\t\tDisplaying Report's Information:- "<<endl;
		 	cout<<"\t\t\tDate of Book issued: "<<issue_date<<endl;
		 	cout<<"\t\t\tDate of Book returned: "<<return_date<<endl;
		 	cout<<"\t\t\tRegistration number of Reader: "<<reg_no<<endl;
		 }