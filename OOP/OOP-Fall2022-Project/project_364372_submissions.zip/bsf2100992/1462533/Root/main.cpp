
                             
//                                    ---------< LIBRARY MANAGEMENT SYSTEM PROJECT >---------

/*      --> Names of Group Members:-

                                    
                               Name: __________Zainab Rasheed__________________
                               Roll no. : ________Bsf2100992___________________
                               
                               Name: __________Laiba Akram_____________________
                               Roll no. : ________Bsf2101276___________________
                               
                               Name: ________Muhammad Umar Khan________________
                               Roll no. : ________Bsf2101082___________________
                               
                               Name: ____________Saman Fatima__________________
                               Roll no. : _________Bsf2100856__________________
 
 
        --> Statement for Library Management System:-
        
                Write a program that defines eight classes: Library, Book, Author, Publisher, Report, Reader, Authentication system, Staff.
				The class library should have data members for Name and address. The class Book should have data members for Id, Title,
				Edition, Type, and description. In class Book takes Id, Title, Edition, Type, and description from the user by using a method.
				The book has a composite relation with library class. Author and Publisher are inherited from class books. The class Author
				should have data members for Name, Qualification and Subject, it should take input from the user. The class Publisher must
				have data members for Name, ID, Year of publish and address, it should also take input from the user. The class reader has
				a composite relation with Book. The class reader should have data members for name, email, password, Id, and address. Each
				Reader comes into the library to read books , so the Class reader has a composite relation with Book. The Class Authentication
				system should have data members for login and Password. The class Report must have data members for Registration number, book
				issue date and book return date. The class staff should have data members for no. of staff and should take no. of staff from
				the user and should enter each staff name, id, and activity of staff. Write the setters to set the inputs of all data members
				of classes and getters to display on screen. Each class must have their input methods to take input from the user and they 
				should have their own display method to display the values of data members and information of each class. It should take input
				from the user, what information he/she wants to display on screen.    
*/

#include<iostream>
#include<string>
#include"Library.h"
#include"Authentication.h"
#include"Reader.h"
#include"Book.h"
#include"Author.h"
#include"Publisher.h"
#include"Staff.h"
#include"Reports.h"
using namespace std;


//main of the program
int main(){                                                                                          //Body of the main
	int a[7], x, z;
	cout<<"\n\n\t\t\t\t<Login to create an account>"<<endl;
	cout<<"\n\t\t-------------------------------------------------------"<<endl;
	
	//Getting Data from User
	
	Authentication Auth;                                                                             //Object of Authentication
	   cout<<"\n\t\tEnter Login data:-   "<<endl;
	   Auth.set_login();
	Library obj;                                                                                     //Object of Library
	    obj.dis_lib();
	Book B1;                                                                                         //Object of Book
	    B1.show_Lib();
	    cout<<"\n\t\t---------------------------------------------------------"<<endl;
	
	Reader obj1;                                                                                      //Object of Reader
	    cout<<"\n\tEnter Reader data:- "<<endl;
	    obj1.read_input();
	    
    	cout<<"\n\tEnter Book data:- "<<endl;
  	    B1.input();
  	    
  	Author obj2;                                                                                      //Object of Author
  	    cout<<"\n\tEnter data of Author of the Book:- "<<endl;
  	    obj2.author_data();
  	    
  	Staff St;                                                                                         //Object of Staff
  	    cout<<"\n\tEnter Staff data:-"<<endl;
  	    St.setvalues();
  	    
  	Publisher Pub;                                                                                    //Object of 	Publisher
  	    cout<<"\n\tEnter data of Publisher of the Book:- "<<endl;
  	    Pub.pub_data();
  	    

  	Reports Rep;                                                                                      //Object of Reports
	    cout<<"\n\tEnter Reports Data:-"<<endl;
		Rep.set_rep(); 
		
		cout<<"\n\t\t---------------------------------------------------------"<<endl; 
		  
	//Displaying Information  
		
		cout<<"\n\nHow many informations you want to display enter the digit from 1-7: ";
        cin>>z;
  	    cout<<"\n\tEnter the numbers whom information you want to display:-"<<endl;
  	    
  	    cout<<"\n\tPress 1 to display Reader's information "<<
  	    "\n\tPress 2 to display Book information "<<
  	    "\n\tPress 3 to display Author's information "<<
  	    "\n\tPress 4 to display Publisher's information "<<
  	    "\n\tPress 5 to display Staff's information "<<
        "\n\tPress 6 to display Reports's information "<<
        "\n\tPress 7 to display Login information "<<endl;
        
  	    for(x=1; x<=z; x++){                                                                            //for loop
  	          cout<<"\n\t\tEnter "<<x<<" number: ";
  	          cin>>a[x];
		  }	
		
		for(x=1; x<=z; x++){                                                                            //for loop
	    if(a[x]==1){
  	    	obj1.display();
		  }
		if(a[x]==2){
			B1.output();
		}  
		if(a[x]==3){
			obj2.author_display();
		    cout<<"\t\t\tTitle of book: "<<B1.title<<endl;	
		}
		if(a[x]==4){
			Pub.pub_display();
			cout<<"\t\t\tTitle of book: "<<B1.title<<endl;
		}
		if(a[x]==5){
			St.getvalues();
		}
        if(a[x]==6){
        	Rep.show_rep();
		}
		if(a[x]==7){
			Auth.show_auth();
		}
	}
	    cout<<"\n\t\t---------------------------------------------------------"<<endl;
}
