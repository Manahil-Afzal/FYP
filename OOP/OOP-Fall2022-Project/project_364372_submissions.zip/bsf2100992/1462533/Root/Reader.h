#include<iostream>
using namespace std;

//Class of Reader
class Reader{
	public:
		
	  //Variable declaration
		string read_name, address, email, type;                                              
		int read_id;
		
		void read_input();                                                                    //Method to input values
		
		int display();                                                                       //Method to output values
		
		void inp_type();                                                                     //Method to input book type
		
		void out_type();                                                                     //Method to output book type
		
};