#include<iostream>
using namespace std;

//Class of Staff
class Staff{
	public:
		
	 //Variable declaration
	    int st_id[50], n;                                                                      
		string st_name[50], activity[50];   
		
			void setvalues();                                                                  //Method to input values
			
			void getvalues();                                                                  //Method to output values
			
};
	