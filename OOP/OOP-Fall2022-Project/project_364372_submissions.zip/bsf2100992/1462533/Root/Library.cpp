#include<iostream>
#include"Library.h"
#include"Book.h"
using namespace std;

//Method declaration of class Library

        void Library::dis_lib(){                                                                          
            	cout<<"\n\n\t\t\3\3  Welcome To Central Library of UE Township Campus  \3\3"<<endl;
            	cout<<"\n\t\t---------------------------------------------------------"<<endl;
	     	}   
			                             
	    void Library::setname(string name1){                                                 //Method to set name of library
			    	name = name1;
				}
				
		void Library::setaddress(string add){                                                //Method to set address of library
					address = add;
				}
				
		string Library::getname(){                                                           //Method to get name of library
					return name;
				}
				
		string Library::getaddress(){                                                        //Method to get address of library
					return address;
				}
