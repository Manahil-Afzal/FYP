#include<iostream>
#include"Staff.h"
using namespace std;

//Method declaration of class Staff

    	void Staff::setvalues(){                                                                   //Method to input values
				cout<<"\n\n\t\t\tEnter the no. staff members: "; 
				cin>>n;
				
				for(int i=1; i<=n; i++){                                                          //for loop
				cout<<"\n\t\t\tEnter the name of the staff member "<<i<<": ";
				cin>>st_name[i];
				cout<<"\t\t\tEnter the id of staff member "<<i<<": ";
				cin>>st_id[i];
				cout<<"\t\t\tEnter the activity of the staff member "<<i<<": ";
				cin>>activity[i];
				}
			}
			
		void Staff::getvalues(){                                                                    //Method to output values
					for(int i=1; i<=n; i++){
				cout<<"\n\t\tDisplaying Staff's Information:- "<<endl;
				cout<<"\t\t\tName of staff member "<<i<<": "<<st_name[i]<<endl;
				cout<<"\t\t\tID of staff member "<<i<<": "<<st_id[i]<<endl;
				cout<<"\t\t\tActivity of staff member "<<i<<": "<<activity[i]<<endl;
				}
			}