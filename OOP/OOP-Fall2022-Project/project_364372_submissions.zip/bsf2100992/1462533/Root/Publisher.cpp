#include<iostream>
#include"Publisher.h"
#include"Book.h"
using namespace std;

//Method declaration of class Publisher

		  void Publisher::pub_data(){                                                                        //Method to input values
		    	cout<<"\n\n\t\t\tEnter the name of Publisher: ";
		    	cin>>name4;
		    	cout<<"\t\t\tEnter the year of publish of book: ";
		    	cin>>year_of_pub;
			}
			
		  void Publisher::pub_display(){                                                                      //Method to output values
				cout<<"\n\t\tDisplaying Publisher's Information:- "<<endl;
				cout<<"\t\t\tName of Publisher: "<<name4<<endl;
				cout<<"\t\t\tYear of Publish of Book: "<<year_of_pub<<endl;
			}