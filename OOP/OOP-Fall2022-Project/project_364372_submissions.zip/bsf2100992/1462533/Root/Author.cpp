#include<iostream>
#include"Author.h"
#include"Book.h"
using namespace std;

//Method declaration of class Author

       	void Author::author_data(){                                                                   //Method to input values
				cout<<"\n\n\t\t\tEnter the name of the Author of book: ";
				cin>>name3;
				cout<<"\t\t\tEnter the qualification of the Author: ";
				cin>>qualification;
				cout<<"\t\t\tEnter the subject of book: ";
				cin>>subject;
			}
			 
		void Author::author_display(){                                                                 //Method to output values
				cout<<"\n\t\tDisplaying Author's Information:- "<<endl;
				cout<<"\t\t\tName of Author: "<<name3<<endl;
				cout<<"\t\t\tQualification of Author: "<<qualification<<endl;
				cout<<"\t\t\tSubject of book: "<<subject<<endl;
			}
