#include<iostream>
using namespace std;

//Class of Library
class Library{
		public:
			
	 //Variable declaration		
		string name, address;                                                            
	
	    void dis_lib();
	    
	    void setname(string name1);                                                       //Method to set name of library
	    
	    void setaddress(string add);                                                      //Method to set address of library
	    
	    string getname();                                                                 //Method to get name of library
	    
	    string getaddress();                                                              //Method to get address of library
};

