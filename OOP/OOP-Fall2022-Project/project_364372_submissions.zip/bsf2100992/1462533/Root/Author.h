#include<iostream>
using namespace std;

//Class of Author
class Author{                                                                       
    public:
    	
    	//Variable declaration
		    string name3, qualification, subject;      
			
		    void author_data();                                                                   //Method to input values
			
			void author_display();                                                                //Method to output values	 
			
};
