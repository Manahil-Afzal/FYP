#include<iostream>
using namespace std;

//Class of Book
class Book{
		public:
			
	//Variable declaration		
		int book_id, edition;                                                                
		string title, description, type; 
		
	
		                                                
		void input();                                                                        //Method to input values
		
		void output();                                                                       //Method to output values
		
		Book();                                                                              /*Constructor of Book setting the name and
		                                                                                         address of Library*/
		                                                                                         
		void show_Lib();                                                                     //Method to output values       
		
};