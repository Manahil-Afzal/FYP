#include<iostream>
using namespace std;

//Class of Reports
class Reports{
	public:
		
		//Variable declaration
	  	   int issue_date, return_date, reg_no;                                                        
	  	 
	     void set_rep();                                                                             //Method to input values
	     
	     void show_rep();                                                                            //Method to output values
	     
};