#include<iostream>
using namespace std;

//Class of Publisher
class Publisher{                                                                      
	public:                                                                  
	
    	 //Variable declaration
	    	string name4;                                                                              
	    	int year_of_pub;
	    	
	    void pub_data();                                                                           //Method to input values	
	    
	    void pub_display();                                                                        //Method to output values
	 	
};
	