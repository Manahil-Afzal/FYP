#include<iostream>
#include"Reader.h"
#include"Book.h"
using namespace std;

//Method declaration of class Reader

   void Reader::read_input(){                                                                    //Method to input values
			cout<<"\n\n\t\t\tEnter Reader Name: "; 
			cin>>read_name;
			cout<<"\t\t\tEnter  Reader ID: ";
			cin>>read_id;
			cout<<"\t\t\tEnter  Reader Address: ";
			cin>>address;
			cout<<"\t\t\tEnter  Reader Email: ";
			cin>>email;
		}
		
	int Reader::display(){                                                                       //Method to output values
			cout<<"\n\t\tDisplaying Reader's Information:- "<<endl;
			cout<<"\t\t\tThe Reader Name: "<<read_name<<endl;
			cout<<"\t\t\tThe Reader Address: "<<address<<endl;
			cout<<"\t\t\tThe Reader Email: "<<email<<endl;
			cout<<"\t\t\tThe Reader ID: "<<read_id<<endl;
		}
		
	void Reader::inp_type(){                                                                     //Method to input book type
					cout<<"\t\t\tEnter type of book: ";    
			        cin>>type;
				}
	void Reader::out_type(){                                                                     //Method to output book type
					cout<<"\t\t\tType of Book: "<<type<<endl;
				}
				
				