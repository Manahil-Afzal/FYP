//BSIT 2021-2025
//OOP Project
//
//Submitted to:         Miss Uzma Omer 
//Group Members:    
//
//o	Name:            Muhammad Abdullah (bsf2101371)
//o	Name:            Uzair Ahmad (bsf2100962)        
//o	Name:           Ali Bashir (bsf2000673)
//o	Name:            Rija Shahzad (bsf2100866)
//Topic:           Car Management System Project
//Shift:             Morning
//Semester:	  3rd



#include <iostream>
using namespace std;


//---------------------------------------------------------Class For Car Company--------------------------------------------------




class Car {

private:
string make;
string model;
int year;

public:
// Constructor
Car(string make, string model, int year) 
{


}


// Getters
string getMake() const {
return make;
}

string getModel() const {
return model;
}


};

 
//---------------------------------------------------------Class For Engine--------------------------------------------------

class Engine {
private:
int horsepower;
string fuel_type;

public:
// Constructor

Engine(int horsepower, string fuel_type){
}

// Getters
int getHorsepower() const {
return horsepower;
}
string getFuelType() const {
return fuel_type;
}
};



//---------------------------------------------------------Class For Transmission--------------------------------------------------

class Transmission {
private:
int no_of_gears;

public:
// Constructor

Transmission(int no_of_gears){
}

// Getters
int getno_of_gears() const {
return no_of_gears;
}

};

//---------------------------------------------------------Class For Brakes--------------------------------------------------



class Brakes  {

private:
string material;
public:
// Constructor

Brakes(string material) {
}
// Getter
string getMaterial() const {
return material;
}

};

//---------------------------------------------------------Class For Tires--------------------------------------------------
class Tires {

private:
int width;
int aspect_ratio;
int diameter;
string tread_type;

public:
// Constructor
Tires(int width, int aspect_ratio, int diameter, string tread_type) 
{
}

// Getters
int getWidth() const {
return width;
}
int getAspectRatio() const {
return aspect_ratio;
}
int getDiameter() const {
return diameter;
}
string getTreadType() const {
return tread_type;
}

};


//---------------------------------------------------------Class For Body--------------------------------------------------



class Body {

private:
string color;
string shape;

public:
// Constructor
Body(string color, string shape)
{
	
	
	
}

// Getters
string getColor() const {
return color;
}
string getShape() const {
return shape;
}

};

//---------------------------------------------------------Class For Car Type such as Sedan--------------------------------------------------



class Sedan : public Car {
private:
  int numSeats;

public:
  Sedan(string make, string model, int year, int numSeats) :
      Car(make, model, year), numSeats(numSeats) {}

  int getNumSeats() const {
    return numSeats;
  }
};

//---------------------------------------------------------Class For Seats Cover--------------------------------------------------

//
//class Cover {
//
//private:
//string seat_cover_type;
//
//public:
//// Constructor
//
//Engine( string fuel_type){
//}
//
//// Getters
//string getFuelType() const {
//return fuel_type;
//}
//};



//---------------------Main function---------------------------------

int main(){
	
	
//	==============Introduction===================
	
	cout<<"\n\n\t\t\t\t\t  OOP TERM PROJECT";
		cout<<"\n\n\t\t\t\t\t ";
	cout<<"\n\n\t\t\t  Project Name :";
	cout<<"\n\n\t\t\t\t\t Car Managment System";

	cout<<"\n\n\t\t\t MADE BY :";
	cout<<"\n\n\t\t\t\t\t Muhammad Abdullah BSF2010371";
	cout<<"\n\n\t\t\t\t\t Uzair Ahmad BSF2100962";
	cout<<"\n\n\t\t\t\t\t Ali Bashir BSF2100673";
	cout<<"\n\n\t\t\t\t\t Rija Shahzaad BSF2100866";

	cout<<"\n\n\t\t\t Submitted To :";
	cout<<"\n\n\t\t\t\t\t Ma'am Ozma Omer";

	cout<<"\n\n\t\t\t Institite :";
	cout<<"\n\n\t\t\t\t\t University Of Education";


	cout<<"\n\n\n\n\t\t\t\t\t\t\t\tPress Enter To Continue";
	cin.get();
	
	
	
//--------------------------------------------------------- Get user input for Car Company, MOdel, Yeatr--------------------------------------------------
string make;
string model;
int year;
int make_option;

cout << "Select the Car make: "<< endl;
cout << "1: Mercedes" << endl;
cout << "2: Honda" << endl;
cout << "3: Suzuki" << endl;
cout << "4: Toyota" << endl;
cout << "5: KIA" << endl;
cout << "6: Jaguar" << endl;
cout << "7: Jeep" << endl;
cout << "8: Lexus" << endl;
cin >> make_option;

switch (make_option) {
case 1:
make = "Mercedes";
break;
case 2:
make = "Honda";
break;
case 3:
make = "Suzuki";
break;
case 4:
make = "Toyota";
break;
case 5:
make = "KIA";
break;
case 6:
make = "Jaguar";
break;
case 7:
make = "Jeep";
break;
case 8:
make = "Lexus";
break;
default:
cout << "Invalid option." << endl;
break;
return 0;
}
cout << "\nEnter model: ";
cin >> model;
cout << "\nEnter year: ";
cin >> year;


	
	
	
	
	
//--------------------------------------------------------- Get user input for Engine--------------------------------------------------

int input;
int horsepower;
string fuel_type;
cout << "\nEnter horsepower: ";
cin >> horsepower;
cout << "\nSelect fuel type: "<< endl;
cout << "1. Gasoline" << endl;
cout << "2. Diesel Fuel" << endl;
cout << "3. Bio-diesel" << endl;
cout << "4. Ethanol" << endl;
int fuel_type_option;
cin >> fuel_type_option;

                                                // string fuel_type;
switch(fuel_type_option) {
case 1:
fuel_type = "Gasoline";
break;
case 2:
fuel_type = "Diesel Fuel";
break;
case 3:
fuel_type = "Bio-diesel";
break;
case 4:
fuel_type = "Ethanol";
break;
default:
cout << "Invalid option" << endl;
return 0;
}



//--------------------------------------------------------- Get user input for Transmissions--------------------------------------------------


int no_of_gears;
cout << "\nEnter no_of_gears: ";
cin >> no_of_gears;


//--------------------------------------------------------- Get user input for Brakes--------------------------------------------------


string material;
int material_type;
cout << "\nEnter the brakes material: "<< endl;
cout << "1: Organic "<< endl;
cout << "2: Ceramic" << endl;
cout << "3: semi-metallic " << endl;
cin >> material_type;
switch (material_type) {
case 1:
material = "Organic";
break;
case 2:
material = "Ceramic";
break;
case 3:
material = "semi-metallic";
break;
default:
cout << "Invalid input." << endl;
}

Brakes brakes(material);

//--------------------------------------------------------- Get user input for Tires--------------------------------------------------

int width, aspect_ratio, diameter;
string tread_type;
int tread_type_option;
cout << "\nEnter tire width (mm): ";
cin >> width;
cout << "\nEnter aspect ratio (%): ";
cin >> aspect_ratio;
cout << "\nEnter diameter (in): ";
cin >> diameter;
cout << "\nEnter tread type: "<< endl;
cout << "1: Symmetric Tread Pattern" << endl;
cout << "2: Asymmetric Tread Pattern" << endl;
cout << "3: Directional Tread Pattern" << endl;
cin >> tread_type_option;

switch (tread_type_option) {
  case 1:
    tread_type = "Symmetric Tread Pattern";
    break;
  case 2:
    tread_type = "Asymmetric Tread Pattern";
    break;
  case 3:
    tread_type = "Directional Tread Pattern";
    break;
  default:
    cout << "Invalid tread type. Please enter a valid option." << endl;
}

Tires tires(width, aspect_ratio, diameter, tread_type);


//--------------------------------------------------------- Get user input for Body--------------------------------------------------

string color, shape;
cout << "\nEnter color: ";
cin >> color;
cout << "\nEnter shape: (e.g. Hatchback, Sedan, SUV, MUV, Coupe, Convertible, Pickup, Truck"<<endl;

cin >> shape;
Body body(color, shape);

//---------------------------------------------------------  input for car type --------------------------------------------------


Sedan mySedan("Mercedes", "E-Class", 2020, 5);







//============================OUTPUTS======================


cout << "************************************************************************************************"<< endl;
cout << "************************************************************************************************"<< endl;
cout << "\nEnter 1 to display car details or 2 to cancel: " <<  endl;

cin >> input;
switch (input) {
case 1:
cout << "************************************************************************************************"<< endl;
cout << "##################################<Entered Car Details in System>##################################"<< endl;




//----------------------------Output For Car----------------------------

cout << "\nCompany of car: " << make << endl;
cout << "\nModel of car: " << model << endl;
cout << "\nYear of car: " << year << endl;





;
//----------------------------Output For Engine----------------------------

cout << "\nHorsepower: " << horsepower << endl;
cout << "\nFuel type: " << fuel_type << endl;


//----------------------------Output For Transmission----------------------------



cout << "\nNumber of Gears : " << no_of_gears << endl;



//----------------------------Output For Brakes----------------------------
cout << "\nMaterial/Types of Brakes: " << material << endl;


//----------------------------Output For Tires----------------------------
cout << "\nWidth of tyres: " << width << endl;
cout << "\nAspect ratio (%) of tyres: " << aspect_ratio << endl;
cout << "\nDiameter of tyres : " << diameter << endl;
cout << "\nTread Type of tyres : " << tread_type << endl;

//----------------------------Output For Body----------------------------
cout << "\nColor of car: " << color << endl;
cout << "\nShape of Car: " << shape << endl;


//----------------------------Output For car type ----------------------------


cout << mySedan.getMake() << endl;  // Outputs "Mercedes"
cout << mySedan.getModel() << endl;  // Outputs "E-Class"
cout << mySedan.getNumSeats() << endl;  // Outputs 5




break;
case 2:
cout << "Action canceled. " << endl;
break;
default:
cout << "Invalid input. " << endl;
}
cout<<"*************************************Program Run Successfully***********************************************************";



return 0; }