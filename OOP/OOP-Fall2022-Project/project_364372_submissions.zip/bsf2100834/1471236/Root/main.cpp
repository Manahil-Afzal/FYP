/*Write a c++ program which explain the hospital management has a classes hospital ,doctor, patient, libatory,
financial sytem, cardiology department,nerology department,pharmacy,pharmacy doctors.Hospital has name,id,
description,address,financial system.Doctor has name,id,specialist,email.Patient has name,id,address,
blood group.Finacial system has patient fee,doctors salary,security guard salary,patient tests income,
pharmacy income.Cardiology department has number of cardia,number of cardiologists,diseases,inter cardiology,
surgery.Neurological department has neurologists,diseases,H.medicines,intervention neuroradiology.Labortory
has number of patients,physicians,patients,medical tests,features.Pharmacy Doctor has patient id, patient name,
patient specialist.Pharmacy has pharmists,medicines number,drugs,medicines,pharmacy counter,care plan.The whole
program uses the constructers,methods, functions,aggregation,composition and inheritance.

Submitted By
Irsa Tehreem         BSF2101175
Nabgha Bano          BSF2101184
Ayesha Batool        BSF2100834
Rukhshanda Perveen   BSF2100954
Submitted To
Dr Uzma Umer*/

#include"hs.h"
#include"lab.h"
#include"crd.h"
#include"nr.h"
#include"doc.h"
#include"pat.h"
#include"fin.h"
#include"p.h"
#include<iostream>
using namespace std;
int main()
{
	hospital h;
	 h.showdata();
	 pharmacy p2;
	 p2.med_management();
	 p2.patient_councling();
	p2.display();
	 return 0;
}