//composition of the patient with the doctor
#include <iostream>
using namespace std;
 class patient{
      public:
      int p_id;
      string p_name;
      string p_address;
      string p_blood_group;
      public:
      	//enter the detail of the patient which are put  by user
      	
      void putdata();
       void showdata();
   };