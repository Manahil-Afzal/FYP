#include"fin.h"
#include<iostream>
using namespace std;
void finencial_system::patient_data()
 			{
 				cout<<"enter the total income pay by the patient "<<endl;
 				cin>>patient_fee;
 				cout<<"enter the total lab test income pay by each patient"<<endl;
 				cin>>pa_tests_income;
			 }
			 void finencial_system::doctors_data()
			 {
			 	cout<<"enter the total payment give to each dostor"<<endl;
			 	cin>>doctors_salary;
			 	cout<<"deduct money from salary on the expenduries on doctor "<<endl;
			 	cin>>doctors_salary;
			 }
			 void finencial_system::security()
			 {
			 	cout<<"enter the pay of all security gaurds "<<endl;
			 	cin>>securitygaurds_salary;
			 }
			 void finencial_system:: pharmacy()
			 {
			 	cout<<"enter the total cost of all medicines"<<endl;
			 	cin>>pharmacy_income;
			 	
			 }
			 void finencial_system::display()
			 {
			cout<<"patient_fee is:" <<patient_fee<<endl;
			cout<<"pa_tests_income is:"<<pa_tests_income<<endl;
			cout<<"doctors_salary is :"<<doctors_salary<<endl;
			cout<<"doctors_salary is:"<<doctors_salary<<endl;
			cout<<"securitygaurds_salary is :"<<securitygaurds_salary<<endl;
			cout<<"pharmacy_income is: "<<pharmacy_income<<endl;
			 	
			 }