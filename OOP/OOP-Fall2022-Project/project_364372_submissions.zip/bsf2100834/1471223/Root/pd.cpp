#include"pd.h"
#include<iostream>
using namespace std;

 void pharmacy_doctors:: p_data(int i,string n,string p){   //parametrized p_data method:
            p_id=i;
     p_name=n;
 p_specialist=p;
       }
            //display method:
       
       void pharmacy_doctors::ph_data(){
           
             cout<<"pharmists id"<<p_id<<endl;
            cout<<"pharmists name"<<p_name<<endl;
             cout<<"pharmists  spesialist"<<p_specialist<<endl;
              
       }