#include"p.h"
#include"pd.h"
#include<iostream>
using namespace std;
//methods of pharmacy class:
   		void pharmacy::med_management()
   		{
   			cout<<"enter the total no of pharmists in pharmacy"<<endl;
   			cin>>pharmists;
   			cout<<"enter the total no of medicines in pharmacy"<<endl;
   			cin>>medicines_no;
   		
   			cout<<"pharmists provide manages,prepare,and dispensing of:"<<endl;//medicine
   			cin>>medicines;
   			cout<<"duty of pharmists is to provide the"<<endl;
   			//drgs info
   			cin>>drugs;
   			
		   }
		   void pharmacy::patient_councling()
		   {
		   	cout<<"pharmist will do councelling wih patient and give:"<<endl;//medicines according to this
		   	cin>>p_counc;
		   	cout<<"formulate the pharmaceutical plan for patient"<<endl;
		   	cin>>care_plan;
		   	
		   	
		   }
		   void pharmacy::display(){
		   	cout<<"total no of pharmists in pharmacy" <<pharmists<<endl;
		   	cout<<"total no of medicines in pharmacy" <<medicines_no<<endl;
		   
		   cout<<"pharmists provide manages,prepare,and dispensing of:" <<medicines<<endl;
		   
		   cout<<"duty of pharmists is to provide the" <<drugs<<endl;
		   cout<<"pharmist will do councelling wih patient and give:"<<p_counc<<endl;
		   cout<<"formulate the pharmaceutical plan for patient"<<care_plan<<endl;
		   	//object of pharmists:
		   pharmacy_doctors Pharmist; 
		    Pharmist. p_data(6,"ali","b_pharmacy");
   Pharmist.ph_data();
		   
		   
		   }