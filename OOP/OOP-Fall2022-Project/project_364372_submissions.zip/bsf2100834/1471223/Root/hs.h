#include<iostream>
using namespace std;
class hospital
{
    public:
    	//data member of the hospitsl  class
   
    
   int hospital_id;
   string h_name;
   string h_address;
  string h_discription;
 hospital();
 void showdata();
};