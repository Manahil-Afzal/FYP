#include <iostream>
using namespace std;
 class doctor{
    public:
    int d_id;
    string d_name;
    string d_specialist;
      string d_email;
      public:
      	//enter the detail of the doctor
    
       void putdata();
       void showdata();
   };