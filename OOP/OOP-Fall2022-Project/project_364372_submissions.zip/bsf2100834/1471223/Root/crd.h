#include <iostream>
using namespace std;
/*cardiology is the department of hospital.
 cardiology department is inherited from hospital class.*/
class cardiology_dep
{
	// data members :
	public:
	int no_of_cardia;
	int no_of_cardiologists;
	string diseases;
	string surgery;
	string inter_cardiology;
	public:
		//methods of class:
		void setdata(int n,int c);
			void getdata();
			void heart_diseases();
			void services();
			void display();
		};