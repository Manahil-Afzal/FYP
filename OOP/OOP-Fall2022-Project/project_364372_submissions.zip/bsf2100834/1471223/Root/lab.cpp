#include"lab.h"
#include<iostream>
using namespace std;
void labortory:: put()
   		 	{
   		 		cout<<"enter the patient "<<endl;
   		 	cin>>patients;
   		 	cout<<"enter the physican;"<<endl;
   		 		cin>>physicans;
				}
   		 	void labortory::lab_features()
   		 	{
   		 		cout<<"inpatient and out patients of lab"<<endl;
   		 		cin>>no_of_patients;
   		 		cout<<"manage patient check in"<<endl;
   		 		cin>>no_of_patients;
   		 		cout<<"outpatient medical testing like hematology,chemistry,imunology and microbiology";
   		 		cin>>med_test;
   		 		cout<<"enter the features like result enter,order entry and patient demographics"<<endl;
   		 		cin>>features;
   		 		
				}
   	