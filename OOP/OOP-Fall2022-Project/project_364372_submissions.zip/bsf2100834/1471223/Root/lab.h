#include<iostream>
using namespace std;
class labortory
   {
   	//data members of labortory:
   	public:
   		int no_of_patients;
   		int physicans;
   		int patients;
   		string med_test;
   		string features;
   		 public:
   		 	//methods of labotory:
   		 	void put();
   		 	void lab_features();
   		 };