#include"doc.h"
#include<iostream>
 void doctor:: putdata(){
            cout<<"enter the doctor id is:"<<endl;
           cin>>d_id;
           cout<<"enter the doctor name is:"<<endl;
           cin>>d_name;
            cout<<"enter the doctor  ispecialists:"<<endl;
           cin>>d_specialist;
            cout<<"enter the doctor email is:"<<endl;
           cin>>d_email;
       }
            //output of the doctor
       
       void doctor::showdata(){
           cout<<"doctor id: "<<d_id<<endl;
            cout<<"doctor name: "<<d_name<<endl;
             cout<<"doctor  spesialist: "<<d_specialist<<endl;
              cout<<"docto email: "<< d_email<<endl;          
       }