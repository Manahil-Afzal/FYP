#include"pat.h"
#include<iostream>
using namespace std;
void patient::putdata(){
          cout<<"\n\n\nenter the patient id  :";
          cin>>p_id;
          cout<<"enter the patient name :";
          cin>>p_name;
          cout<<"enter the patient address :";
          cin>>p_address;
          cout<<"enter the patient blood group :";
          cin>>p_blood_group;
      }
      //output of the patient
      void patient:: showdata(){
          cout<<"\n\npatient id:"<<p_id<<endl;
          cout<<"patient name:"<<p_name<<endl;
          cout<<"patient adderss:"<<p_address<<endl;
          cout<<"patient blood group:"<<p_blood_group<<endl;
          
      }