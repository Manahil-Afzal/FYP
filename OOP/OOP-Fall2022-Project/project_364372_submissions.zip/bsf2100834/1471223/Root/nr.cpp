#include"nr.h"
#include<iostream>
using namespace std;
	void Neurological_dep::n_diseases()
	{
		cout<<"if patient has headache then he will have"<<endl; // cancer
		cin>>diseases;
		cout<<"if patient face sleeplessness+headache+eyes pain then "<<endl; //brain tumors
		cin>>diseases;
		
	}
	void Neurological_dep:: treatments()
	{
		cout<<"if patient has headache then he will use"<<endl;
		cin>>H_medicines;
		cout<<"if patient has brain tumor or cancer then "<<endl;
		cin>>intervention_neuroradiology;
	}
	void Neurological_dep::display(){
		
		cout<<"diseases is:"<<diseases<<endl;
		cout<<"diseases is:"<<diseases<<endl;
		cout<<"H_medicines is:"<<H_medicines<<endl;
		cout<<"intervention_neuroradiology is:"<<intervention_neuroradiology<<endl;
		
	}