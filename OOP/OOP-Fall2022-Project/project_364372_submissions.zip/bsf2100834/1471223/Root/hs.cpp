#include"hs.h"
#include"lab.h"
#include"crd.h"
#include"nr.h"
#include"doc.h"
#include"pat.h"
#include"fin.h"
#include<iostream>
using namespace std;
hospital:: hospital()
 //assigning the values of data member of the hospital
 {
 	hospital_id  =8768;
 	h_name  ="dhq";
 	h_address  ="lhr";
 	h_discription  ="this is about heart";
 //output of the hospital which have a composition relationship with the doctor
 //and patient
 }
  void  hospital::showdata()
  {
      cout<<"hospital id"<<hospital_id<<endl;
       cout<<"hospital name"<<h_name<<endl;
        cout<<"hospital address"<<h_address<<endl;
         cout<<"hospital discription"<<h_discription<<endl;
         //object of the doctor class which defined in hospital class
         doctor d;
         d.putdata();
         d.showdata();
         //object of the patient class
         //which is defined in hopspital class 
         //with the composite relation relationship
            patient p;
              p.putdata();    
              p.showdata();
              finencial_system f1;
             f1.patient_data() ;
              f1.doctors_data();
              f1.pharmacy();
              f1.security();
              f1.display();
              cardiology_dep c1;
            
	 c1.setdata(3,4);
	 c1.getdata();
	 
	 c1.heart_diseases();
	 c1.services();
	 c1.display();
	
	 Neurological_dep n1;
	 n1.n_diseases();
	 n1.treatments();
	 n1.display();
	 labortory l1;
	 l1.put();
	 l1.lab_features();
        
  }
