#include <iostream>
using namespace std;
/*neurological  is the department of hospital.
 neurological department is inherited from hospital class.*/
class Neurological_dep
{
	//data members:
	public:
	string neurologists;
	string diseases;
	string H_medicines;
	string intervention_neuroradiology;
	//methods of class:
	void n_diseases();
		void treatments();
			void display();
			};