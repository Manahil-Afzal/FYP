#include <iostream>
using namespace std;
class 	finencial_system
 {
 	//data members of finencial class:
 	public:
 	int	patient_fee;
 	int	doctors_salary;
 	int	securitygaurds_salary;
	int	pa_tests_income;
 	int	pharmacy_income;
 		public:
 			//methods of finencial class:
 			void patient_data();
 			void doctors_data();
 			void security();
 			void pharmacy();
 			void display();
 		};