// Main function of the C++ program.

#include"hs.h"
#include"lab.h"
#include"crd.h"
#include"nr.h"
#include"doc.h"
#include"pat.h"
#include"fin.h"
#include"p.h"
#include<iostream>
using namespace std;
int main()
{
	hospital h;
	 h.showdata();
	 pharmacy p2;
	 p2.med_management();
	 p2.patient_councling();
	p2.display();
	 return 0;
}