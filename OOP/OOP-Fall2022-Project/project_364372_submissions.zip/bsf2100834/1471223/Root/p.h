#include<iostream>
using namespace std;
//main class pharmacy:
class pharmacy
   {
   	//Data members of pharmacy:
   	private:
   		int pharmists;
   		int medicines_no;
   	string drugs;
   	string medicines;
   	string p_counc;
   	string care_plan;
   	public:
   		//object of pharmists:
   	
   	
   
   	   
   	//methods of pharmacy class:
   		void med_management();
   		 void patient_councling();
   		 void display();
   	};