#include<iostream>
using namespace std;
 /*pharmacy has pharmists:
 pharmacy class has composition relationship with pharmists.*/
 class pharmacy_doctors{
 	//data members of pharmists:
    private:
    int p_id;
    string p_name;
    string p_specialist;
      public:
    //methods of class:
    
       void p_data(int i,string n,string p);
       void ph_data();
       };