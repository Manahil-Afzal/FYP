#include"crd.h"
#include<iostream>
using namespace std;
void cardiology_dep::setdata(int n,int c)
	{
			n=no_of_cardia;
			c=no_of_cardiologists;
		}
		void cardiology_dep::getdata()
		{
			cout<<no_of_cardiologists<<" "<<no_of_cardia<<" ";
		}
		
		void cardiology_dep::heart_diseases()
		{
			cout<<"Enter the type of heart diseases either acute or suspected"<<endl;
			cin>>diseases;
		}
		void cardiology_dep::services()
		{
			cout<<"enter the cardiac or cardiac vascular surgery"<<endl;
			cin>>surgery;
			cout<<"enter the no of interventional cardiology"<<endl; // treatment through radiations.
			cin>>inter_cardiology;
			
		}
		void cardiology_dep::display(){
			cout<<"diseases are :"<<diseases<<endl;
			cout<<"surgery :"<<surgery<<endl;
			cout<<"inter_cardiology :"<<inter_cardiology<<endl;
		
		}