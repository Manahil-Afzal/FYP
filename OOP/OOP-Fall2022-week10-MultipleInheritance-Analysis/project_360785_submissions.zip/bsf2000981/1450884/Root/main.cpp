#include <iostream>
using namespace std;

class P
{
	protected:
	int z;
 	public:
 	
 	void setz(int q)
    {
 	     z=q;
    }
};

class A
{
	protected://As private member cannot be assessed therefore change access specifier from private to protected
	int x;
 	public:
 	void setx(int q)
    {
 	     x=q;
    }

};
class B
{
protected:
int y;
 	public:
 	
 	void sety(int q)//Here we change the name of setter as we are setting the value of y
    {
 	     y=q;//change of variables
    }
};
class C : public A, public B,public P   //Class P is not inherited
{
 	public:
 	void sum()
 	{
 	    cout << "Sum = " << x + y+z;
 	}
};

int main()
{
 	 C obj1; 
     obj1.setz(3);
 	 obj1.setx(4);
 	 obj1.sety(5);
 	 obj1.sum();
 	 return 0;
}

