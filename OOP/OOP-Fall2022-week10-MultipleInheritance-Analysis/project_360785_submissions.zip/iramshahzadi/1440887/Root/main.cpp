// Identify and correct errors ( also comment the errors).

#include<iostream>
using namespace std;
class Course{
protected:
int id;
public:
void input(){
	cout<<"Enter the course id:"<<endl;
cin>>id;
}
};
class IT: virtual public Course {
public:
void display(){
cout<<"course id:"<<id<<endl;
}
};
class CS : virtual public Course{
 public:
void display(){
cout<<"course id:"<<id<<endl;
}
};
class SOS_Course: public IT, public CS{
public:
 void display(){
cout<<"course id:"<<id<<endl;
}
};
int main(){
SOS_Course co;
 co.input();
co.display();
return 0; 
}