#include <iostream>
using namespace std;

class Employee {
    int Id;
    char name[6]; // Increase size to store names up to 5 characters
    int Age;
    long Salary;

public:
    void GetData() {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin >> name; // Correct the member name

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData() {
        cout << "\n" << Id << "\t" << name << "\t" << Age << "\t" << Salary; // Correct the member name
    }
};

int main() {
    Employee E[5];
    int i;

    for (i = 0; i <=4; i++) { // Fix loop condition and use correct function call
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData();
    }

    cout << "\nDetails of Employees";
    for (i = 0; i <=4; i++) // Use correct array indexing and function call
        E[i].PutData();

    return 0;
}