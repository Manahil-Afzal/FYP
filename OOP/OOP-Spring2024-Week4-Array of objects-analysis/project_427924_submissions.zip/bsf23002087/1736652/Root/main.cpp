// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include<iostream>
using namespace std;
       class Employee
       {
              int Id;
              string name;
              int Age;
              int Salary;

              public:
              void GetData()           
              {
                    cout<<"\n\tEnter Employee Id : ";
                    cin>>Id;

                    cout<<"\n\tEnter Employee Name : ";
                    cin.clear();
                    cin.sync();
					getline(cin,name);

                    cout<<"\n\tEnter Employee Age : ";
                    cin>>Age;

                    cout<<"\n\tEnter Employee Salary : ";
                    cin>>Salary;
              }

              void PutData()           
              {
                    cout<<"\n"<<Id<<"\t"<<name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


       int main()
       {

              Employee E[5];           

              for(int i=0;i<5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee";
                    E[i].GetData();
              }

              cout<<"\nDetails of Employees";
              for(int i=0;i<5;i++){
			  
              E[i].PutData();
          }
       }
