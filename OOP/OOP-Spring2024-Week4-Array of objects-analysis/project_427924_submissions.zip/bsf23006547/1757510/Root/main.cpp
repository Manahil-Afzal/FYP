// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include<iostream>
using namespace std;
       class Employee
       {
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              void GetData()           
              {
                    cout<<"Enter Employee Id :";
                    cin>>Id;

                    cout<<"Enter Employee Name :";
                    cin>>name;

                    cout<<"Enter Employee Age :";
                    cin>>Age;

                    cout<<"Enter Employee Salary :";
                    cin>>Salary;
              }

              void PutData()           
              {
                    cout<<"\n"<<Id<<"\t"<<name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


       int main()
       {

              Employee E[5];           

              for(int i=0;i<5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee"<<endl;
                    E[i].GetData();
              }

              cout<<"\nDetails of Employees";
              for(int i=0;i<5;i++)
              E[i].PutData();
       }