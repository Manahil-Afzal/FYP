// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

  #include <iostream>
using namespace std;

class Employee
{
    int Id;
    char Name[25]; // Changed to Name instead of name
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin >> Name; // Changed to Name instead of name

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData() // Removed Employee:: from PutData() declaration
    {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() // Changed void to int for main() function
{
    Employee E[5];

    for (int i = 0; i < 5; i++) // Corrected the loop condition and added missing int declaration for i
    {
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData(); // Changed E(i) to E[i]
    }

    cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) // Corrected the loop condition and added missing int declaration for i
        E[i].PutData(); // Changed E(i) to E[i]

    return 0; // Added return 0 at the end of main() function
}
