#include <iostream>
#include <cstring>
using namespace std;

class Employee {
    int Id;
    char name[25];
    int Age;
    long Salary;

public:
    // Method to input employee data
    void GetData() {
        cout << "\n\tEnter Employee Id: ";
        cin >> Id;

        cout << "\n\tEnter Employee Name: ";
        cin.ignore();  // To clear the buffer before reading the name
        cin.getline(name, 25);  // Reading the full name, including spaces

        cout << "\n\tEnter Employee Age: ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary: ";
        cin >> Salary;
    }

    // Method to display employee data
    void PutData() const {
        cout << "\n" << Id << "\t" << name << "\t" << Age << "\t" << Salary;
    }
};

int main() {
    Employee E[5]; // Array of 5 Employee objects

    // Input data for each employee
    for (int i = 0; i < 5; i++) {
        cout << "\nEnter details of Employee " << i + 1;
        E[i].GetData();
    }

    // Display details of all employees
    cout << "\nDetails of Employees:\n";
    cout << "ID\tName\t\tAge\tSalary\n";
    for (int i = 0; i < 5; i++) {
        E[i].PutData();
    }

    return 0;
}
