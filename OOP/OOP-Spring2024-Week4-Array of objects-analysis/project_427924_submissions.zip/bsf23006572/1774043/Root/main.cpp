

// // This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

//       class Employee
//       {
//               int Id;
//               char name[25];
//               int Age;
//               long Salary;

//               public:
//               void GetData()           
//               {
//                     cout<<"\n\tEnter Employee Id : ";
//                     cin>>Id;

//                     cout<<"\n\tEnter Employee Name : ";
//                     cin>>Name;

//                     cout<<"\n\tEnter Employee Age : ";
//                     cin>>Age;

//                     cout<<"\n\tEnter Employee Salary : ";
//                     cin>>Salary;
//               }

//               void Employee::PutData()           
//               {
//                     cout<<"\n"<<Id<<"\t"<<Name<<"\t"<<Age<<"\t"<<Salary;
//               }

//       };


//       void main()
//       {

//               Employee E[5];           

//               for(i=0;i<=5,i++)
//               {
//                     cout<<"\nEnter details of "<<i+1<<" Employee";
//                     i.GetData();
//               }

//               cout<<"\nDetails of Employees";
//               for(i=0;i<=5;i++)
//               E(i).PutData();

//       }
    //   These are the following errors int he above program :
    //   First include necessry header files 
    //   Second name of the data member must be same everywhere 
    //   Third the i must be declared as integer data to start the for loop 
    //   Fourth the to input data the class name must be followed by [i]
    //   Fifth  putdata function must be declared inside the class 
       #include <iostream>
using namespace std;

class Employee
{
    int Id;
    char name[25];
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin >> name;

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }
    void PutData();

};

    void Employee::PutData()
    {
        cout << "\n"
             << Id << "\t" << name << "\t" << Age << "\t" << Salary;
    }
int main()
{

    Employee E[2];
    int i;
    for (i = 0; i <= 2; i++)
    {
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData();
    }

    cout << "\nDetails of Employees";
    for (i = 0; i <= 5; i++)
        E[i].PutData();
}