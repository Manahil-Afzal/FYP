// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include<iostream>
using namespace std;
       class Employee
       {
              int Id;
              char Name[25];
              int Age;
              long Salary;

              public:
              void putData()           
              {
                    cout<<"\n\tEnter Employee Id : ";
                    cin>>Id;

                    cout<<"\n\tEnter Employee Name : ";
                    cin>>Name;

                    cout<<"\n\tEnter Employee Age : ";
                    cin>>Age;

                    cout<<"\n\tEnter Employee Salary : ";
                    cin>>Salary;
              }

              void getData()           
              {
                    cout<<"\n"<<Id<<"\t"<<Name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


       int main()
       {

              Employee E[5];           

              for(int i=0;i<5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee";
                    E[i].putData();
              }

              cout<<"\nDetails of Employees";
              for(int i=0;i<5;i++)
              {
              	    E[i].getData();
              	
			  }
          

       }
