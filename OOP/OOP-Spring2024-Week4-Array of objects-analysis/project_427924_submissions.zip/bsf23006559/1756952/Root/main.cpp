// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

       #include<iostream>
       using namespace std;
	   class Employee
       {
              int Id;
              string name;
              int Age;
              long Salary;

              public:
              	 void PutData()           
              {
              	cout<<"Enter id "<<endl;
              	cin>>Id;
              	cout<<"Enter name "<<endl;
              	cin>>name;
              	cout<<"Enter Age "<<endl;
              	cin>>Age;
              	cout<<"Enter Salary "<<endl;
              	cin>>Salary;
              }
              void GetData()           
              {
                    cout<<" Employee Id is: "<<Id<<endl;
                    cout<<" Employee Name is: "<<name<<endl;
                    cout<<" Employee Age is: "<<Age<<endl;
                    cout<<" Employee Salary is: "<<Salary<<endl;
              }
       };
       int  main()
       {

              Employee E[5];           

            
              cout<<"Enter Details of Employees"<<endl;
              for(int i=0;i<5;i++){
              	   	  cout<<" Details of "<<" Employee  "<< i+  1<<endl;
              	 E[i].PutData();
			  }
             
               for(int i=0;i<5;i++)
              {
                    cout<<" details of "<<i+1<<" Employee"<<endl;
                   E[i].GetData();
              }
            return 0;
       }
