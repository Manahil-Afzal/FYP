// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

      // This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

      #include<iostream>
      using namespace std;
	   class Employee
       {
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              void GetData()           
              {
                    cout<<"Enter Employee Id : "<<endl;
                    cin>>Id;

                    cout<<"Enter Employee Name : "<<endl;
                    cin>>name;

                    cout<<"Enter Employee Age : "<<endl;
                    cin>>Age;

                    cout<<"Enter Employee Salary : "<<endl;
                    cin>>Salary;
              }

              void PutData()           
              {
                    cout<<Id<<name<<Age<<Salary;
              }

       };


       int main()
       {

              Employee E[5];           

              for(int i=0;i<=5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee";
                    E[i].GetData();
              }

              
              for(int i=0;i<=5;i++){
			  cout<<"Details of Employees"<<endl;
              E[i].PutData();
          }

       }
