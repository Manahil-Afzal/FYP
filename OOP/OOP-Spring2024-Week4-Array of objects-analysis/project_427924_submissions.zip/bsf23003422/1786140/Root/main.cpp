// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

       #include<iostream>
using namespace std;

class Employee
       {
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              Employee getData()           
              {
                    cout<<"Enter Employee Id : "<<endl;
                    cin>>Id;

                    cout<<"Enter Employee Name : "<<endl;
                    cin>>name;

                    cout<<"Enter Employee Age : "<<endl;
                    cin>>Age;

                    cout<<"Enter Employee Salary : "<<endl;
                    cin>>Salary;
              }

              Employee putData()           
              {
                    cout<<"\n"<<"Your ID: "<<Id<<"\n" <<"Your Name: "<<name<<"\n"<<"Your Age: "<<Age<<"\n"<<"Your Salary: "<<Salary<<endl;
              }

       };


       int main()
       {

              Employee E;   
              
              for(int i=0;i<=5;i++)
              {
                    cout<<"\nEnter details of Employee"<<" "<<i+1<<endl;
                    E.getData();
              }

              cout<<"\nDetails of Employees";
              for(int i=0;i<=5;i++){
              E.putData();
          }

   }
