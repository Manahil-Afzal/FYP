// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

#include<iostream>
using namespace std;

class Employee{
private:
    int Id;
    char Name[25];
    int Age;
    long Salary;
public:
    void GetData(){
        cout << "\nEnter Employee Id: ";
        cin >> Id;
        cout << "Enter Employee Name: ";
        cin.ignore();
        cin.getline(Name, 25);
        cout << "Enter Employee Age: ";
        cin >> Age;
        cout << "Enter Employee Salary: ";
        cin >> Salary;
    }
    void PutData(){
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};
int main(){
    Employee E[5];
    for (int i = 0; i < 5; i++) {
        cout << "\nEnter details of Employee " << i + 1 << ":";
        E[i].GetData();
    }
    cout << "\n\nDetails of Employees\nID\tName\tAge\tSalary";
    for (int i = 0; i < 5; i++)
        E[i].PutData();
    return 0;
}
