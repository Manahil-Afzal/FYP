#include <iostream>
using namespace std;

class Employee {
    int Id;
    char Name[25]; // Corrected capitalization of 'name' to 'Name'
    int Age;
    long Salary;

  public:
    void GetData() {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin.ignore(); // To clear the newline character from the input buffer
        cin.getline(Name, 25); // Using getline to read names with spaces

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData() {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() { // Changed void main() to int main()
    Employee E[5];
    int i; // Declare i here

    for (i = 0; i < 5; i++) { // Corrected the loop condition and syntax
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData(); // Corrected the syntax for calling GetData()
    }

    cout << "\nDetails of Employees";
    for (i = 0; i < 5; i++) // Corrected the loop condition
        E[i].PutData(); // Corrected the syntax for calling PutData()

    return 0; // Added return statement to main
}
