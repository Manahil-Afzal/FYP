#include <iostream>
using namespace std;

class Employee
{
private:
    int Id;
    char Name[25]; // Corrected capitalization of 'Name'
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id: ";
        cin >> Id;

        cout << "\n\tEnter Employee Name: ";
        cin >> Name; // Corrected capitalization of 'Name'

        cout << "\n\tEnter Employee Age: ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary: ";
        cin >> Salary;
    }

    void PutData()
    {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() // Corrected 'void' to 'int' for the main function
{
    Employee E[5];

    for (int i = 0; i < 5; i++) // Corrected loop condition
    {
        cout << "\nEnter details of Employee " << i + 1;
        E[i].GetData(); // Corrected access to the 'GetData' method
    }

    cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) // Corrected loop condition
    {
        E[i].PutData(); // Corrected access to the 'PutData' method
    }

    return 0; // Added return statement
}