// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

 
#include<iostream>
using namespace std;



       class Employee
       {
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              void GetData()           
              {
                    cout<<"Enter Employee Id : "<<endl;
                    cin>>Id;

                    cout<<"Enter Employee Name : "<<endl;
                    cin>>name;

                    cout<<"Enter Employee Age : "<<endl;
                    cin>>Age;

                    cout<<"Enter Employee Salary : "<<endl;
                    cin>>Salary;
              }
              void Putdata();

            

       };
         void Employee::Putdata()           
              {
              	cout<<"ID is"<<Id<<endl;
              		cout<<"name is"<<name<<endl;
              			cout<<"age is"<<Age<<endl;
              				cout<<"salary is"<<Salary<<endl;
              				
                   
              }


       int main()
       {

              Employee E[5];           

              for(int i=0;i<=5;i++)
              {
                    cout<<"Enter details of "<<i+1<<" Employee"<<endl;
                    E[i].GetData();
              }

              cout<<"Details of Employees"<<endl;
              for(int i=0;i<=5;i++)
              E[i].Putdata();

       }
