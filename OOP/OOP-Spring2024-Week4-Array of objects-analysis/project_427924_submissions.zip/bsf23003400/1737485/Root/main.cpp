// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include<iostream>
using namespace std;
       class Employee
       {
              int Id;
              char Name[25];// Changed 'name' to 'Name' to match case sensitivity in GetData
              int Age;
              long Salary;

              public:
              void GetData()           
              {
                    cout << "\nEnter Employee Id : ";
                    cin >> Id;

                    cout << "\nEnter Employee Name : ";
                    cin.ignore(); // To clear the newline character from the buffer
                    cin.getline(Name, 25);
    
                    cout << "\nEnter Employee Age : ";
                    cin >> Age;

                    cout << "\nEnter Employee Salary : ";
                    cin >> Salary;
              }

              void PutData()    // Removed 'Employee::'       
              {
                    cout<<"\n"<<Id<<"\t"<<Name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


       int main() // Changed return type from 'void' to 'int' for main function
       {

              Employee E[5]; 
              int i;// Declare 'i' before using it in the loop

              for(i=0;i<5;i++)// Corrected loop condition; it should be 'i < 5'
              {
                    cout<<"Enter details of "<<i+1<<" Employee";
                    E[i].GetData(); // Corrected method call to use object from array
              }

              cout<<"Details of Employees";
              for(i=0;i<5;i++){// Again, corrected the loop condition
              E[i].PutData();// Corrected method call 
              }
              
              return 0; // Since main is of type int, a return value is expected
       }
       
