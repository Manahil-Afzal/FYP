// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

 #include<iostream>                                          //Header files missing
using namespace std;
class Employee
{
 int Id;
 char name[5];
 int Age;
 long Salary;
public:
void GetData()           
 {
  cout<<"\n\tEnter Employee Id : ";
  cin>>Id;
  cout<<"\n\tEnter Employee Name : ";                      //Wrong variable name
  cin>>name;
  cout<<"\n\tEnter Employee Age : ";
  cin>>Age;
  cout<<"\n\tEnter Employee Salary : ";
  cin>>Salary;
 }
void PutData()                                             //Inside class scope resolution operator is not used        
 {
  cout<<"\n"<<Id<<"\t"<<name<<"\t"<<Age<<"\t"<<Salary;
 }
};
int main()                                                 //int main should by passed instead of void main
{
 Employee E[5];           
 for(int i=0;i<5;i++)                                      //Wrong condition 
 {
  cout<<"\nEnter details of "<<i+1<<" Employee";
  E[i].GetData();                                          //Array is passed instead of a single variable 
 }
 cout<<"\nDetails of Employees";
 for(int i=0;i<5;i++)                                      //Wrong condition 
 E[i].PutData();                                           //Wrong parenthesis
}

