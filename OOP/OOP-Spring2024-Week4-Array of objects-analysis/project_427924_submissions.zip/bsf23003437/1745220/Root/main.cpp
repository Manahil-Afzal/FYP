// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

      #include <iostream>
using namespace std;

class Employee {
    int Id;
    char Name[25]; // Fixed variable name
    int Age;
    long Salary;

public:
    void GetData() {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin >> Name;

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData() { // Removed class qualification
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() { // Changed void to int for main
    Employee E[5];
    int i; // Declare i here

    for (i = 0; i < 5; i++) { // Fixed loop condition and comma to semicolon
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData(); // Fixed accessing array element and method
    }

    cout << "\nDetails of Employees";
    for (i = 0; i < 5; i++) // Fixed loop condition
        E[i].PutData(); // Fixed accessing array element and method

    return 0; // Added return statement
}
