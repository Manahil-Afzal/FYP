#include<iostream>
using namespace std;

class Employee
{
    int Id;
    char Name[25]; // Corrected variable name to match declaration
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin.ignore(); // Ignore the newline character in the buffer
        cin.getline(Name, 25); // Use getline to read the entire name, including spaces

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData()
    {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() // Corrected return type of main function
{
    Employee E[5];

    for (int i = 0; i < 5; i++) // Corrected loop condition
    {
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData();
    }

    cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) // Corrected loop condition
        E[i].PutData();

    return 0; // Added return statement
}
