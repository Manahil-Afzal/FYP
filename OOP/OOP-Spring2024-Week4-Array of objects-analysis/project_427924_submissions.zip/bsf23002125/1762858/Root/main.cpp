// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
// Add iostream and namespace std
#include <iostream>
using namespace std;

// Correct the indentation
class Employee{
    private:
        int Id;
        string name;       // adding simple string for name. 
        int Age;
        long Salary;
    public:
        void GetData(){

            // Removing extra tabs and new lines.
            cout<<"\nEnter Employee Id : ";
            cin>>Id;
            cout<<"Enter Employee Name : ";
            cin >> name;
            cout<<"Enter Employee Age : ";
            cin>>Age;
            cout<<"Enter Employee Salary : ";
            cin>>Salary;
        }
        // The function is in class, remove class name and ::
        void PutData(){

            // Add name, id, age and salary in "".
            cout<<"\nId: "<<Id<<"\t Name: "<<name<<"\tAge: "<<Age<<"\tSalary: "<<Salary;        // correct the variable name
        }

};
int main(){
    
    Employee E[5];  
    
    // Declare "i" and remove equal to sign, otherwise it will repeat 6 times.         
    for(int i=0;i<5;i++){       // Add semi colon instead of comma.
        cout<<"\nEnter details of "<<i+1<<" Employee";

        // Add Object name (E)
        E[i].GetData();
    }

    cout<<"\nDetails of Employees";

    // Again declaring "i" and remove equal to sign. 
    for(int i=0;i<5;i++){
        
        // i will be written in square brackets
        E[i].PutData();
    }
    
    return 0;
}
