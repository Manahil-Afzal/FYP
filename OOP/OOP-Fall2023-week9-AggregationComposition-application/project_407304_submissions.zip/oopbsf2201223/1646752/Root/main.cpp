/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;

class Engine {
public:
    int engine_number;
    Engine(int number) { engine_number = number; }
};

class Passenger {
public:
    string passenger_name;
    Passenger(string name) { passenger_name = name; }
};

class Car {
public:
    Engine car_engine;
    Passenger car_passenger;
    Car(int engine_number, string passenger_name) : car_engine(engine_number), car_passenger(passenger_name) {}
    void displayInfo() {
        cout << "Engine: " << car_engine.engine_number << endl;
        cout << "Passenger: " << car_passenger.passenger_name << endl;
    }
};

int main() {
    Car myCar(1234, "John");
    myCar.displayInfo();
    return 0;
}
