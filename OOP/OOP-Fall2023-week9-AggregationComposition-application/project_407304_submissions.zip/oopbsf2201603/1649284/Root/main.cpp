/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>
using namespace std; 

class Engine {
public:
    Engine(int engine_number) : engine_number(engine_number) {
    }

    int getEngineNumber() const {
        return engine_number;
    }

private:
    int engine_number;
};

class Passenger {
public:
    Passenger(const string& passenger_name) : passenger_name(passenger_name) {
    }

    string getPassengerName() const {
        return passenger_name;
    }

private:
    string passenger_name;
};

class Car {
public:
    Car(const Engine& engine, const Passenger& passenger) : car_engine(engine), car_passenger(passenger) {
    }

    void displayCarInfo() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }

private:
    Engine car_engine;
    Passenger car_passenger;
};

int main() {
    // Create an Engine object and a Passenger object
    Engine carEngine(12345);
    Passenger carPassenger("ALI");

    // Create a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display car information
    myCar.displayCarInfo();

    return 0;
}
