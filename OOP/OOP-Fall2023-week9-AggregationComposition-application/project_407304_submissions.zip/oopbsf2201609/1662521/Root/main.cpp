/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

class Engine {
private:
    std::string engine_number;

public:
    Engine(const std::string& engineNum) : engine_number(engineNum) {}

    void displayEngineNumber() {
        std::cout << "Engine Number: " << engine_number << std::endl;
    }
};

class Passenger {
private:
    std::string passenger_name;

public:
    Passenger(const std::string& name) : passenger_name(name) {}

    void displayPassengerName() {
        std::cout << "Passenger Name: " << passenger_name << std::endl;
    }
};

class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
    Car(const std::string& engineNum, const std::string& passengerName)
        : car_engine(engineNum), car_passenger(passengerName) {}

    void displayCarDetails() {
        car_engine.displayEngineNumber();
        car_passenger.displayPassengerName();
    }
};

int main() {
    // Create a Car object with an Engine and Passenger
    Car myCar("AB1234", "John Doe");

    // Display the Car details
    myCar.displayCarDetails();

    return 0;
}
