/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
using namespace std;

class Engine{
    private:
    string eng_num;
    public:
     Engine(const string& num) : eng_num(num) {}
    
    void setdata(string num)
    {
        eng_num=num;
    }
    
    string getdata()
    {
      return eng_num;
    }
};
class Passenger{
    private:
    string passenger_name;
    public:
    
    Passenger(const string& name) : passenger_name(name) {}
    
    void setdata(string name)
    {
        passenger_name=name;
    }
    
    string getdata()
    {
        return passenger_name;
    }
};
class Car{
    private:
    Engine      engine;
    Passenger   passenger;
    
    public:
    
    Car(const string& engine_number, const string& passenger_name) : engine(engine_number), passenger(passenger_name) {}

    
    void showcar()
    {
        cout<<"Engine info: "<<engine.getdata();
        cout<<"\n passenger name "<<passenger.getdata() <<endl;
        
    }
    
    
};

int main()
{
    Car myCar("13CC", "Areeba");
    myCar.showcar();
}
