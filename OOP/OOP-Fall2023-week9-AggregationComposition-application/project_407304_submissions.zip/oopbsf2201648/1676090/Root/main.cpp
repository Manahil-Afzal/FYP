/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
using namespace std;
class Engine{
	private:
		string eng_num;
	public:
		void set_eng_num(string num){
			eng_num=num;
		}
		string get_eng_num(){
			return eng_num;
		}
};
class Passenger{
	private:
		string passenger_name;
	public:
		void set_passenger_name(string name){
			passenger_name=name;
		}
		string get_passenger_name(){
			return passenger_name;
		}
};
class Car{
	Passenger passenger;
	Engine engine;
	public:
		Car(){
			passenger.set_passenger_name("Asif Malik");
			engine.set_eng_num("222");
		}
		void show_car(){
			cout<<passenger.get_passenger_name()<<endl;
			cout<<engine.get_eng_num();
		}
};
main()
{
	Car c1;
	c1.show_car();
}