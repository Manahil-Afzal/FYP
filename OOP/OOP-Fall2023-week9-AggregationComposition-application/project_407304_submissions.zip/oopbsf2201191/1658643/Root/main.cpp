/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine
{
private:
	string engine_no;

public:
	Engine()
	{
		engine_no = "12k2";
	}
	string get_engine_no()
	{
		return engine_no;
	}
};
class Passenger
{
private:
	string p_name;

public:
	Passenger()
	{
		p_name = "Abdullah Ansari";
	}
	string get_p_name()
	{
		return p_name;
	}
};
class car
{
	Engine engine_num;
	Passenger *passenger_name;
	string car_num;

public:
	car(Passenger p1)
	{
		passenger_name = &p1;
		car_num = "122121";
	}
	void display()
	{
		cout << "Engine name :" << engine_num.get_engine_no() << endl;
		cout << "car number: " << car_num << endl;
		cout << "passenger name: " << passenger_name->get_p_name();
	}
};
int main()
{
	Passenger p_2;
	car c1(p_2);
	c1.display();
	return 0;
}