/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
class Engine {
public:
    Engine(int engineNumber) : engineNumber(engineNumber) {}
    int getEngineNumber() { return engineNumber; }

private:
    int engineNumber;
};

// Define the Passenger class
class Passenger {
public:
    Passenger(const std::string& passengerName) : passengerName(passengerName) {}
    std::string getPassengerName() { return passengerName; }

private:
    std::string passengerName;
};

// Define the Car class with aggregation of Engine and Passenger
class Car {
public:
    Car(int engineNumber, const std::string& passengerName) : engine(engineNumber), passenger(passengerName) {}

    void displayCarInfo() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    // Create a Car object with an Engine and Passenger
    Car car(12345, "Waqas");

    // Display the engine number and passenger name
    car.displayCarInfo();

    return 0;
}