/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
#include <string>

using namespace std;


class Engine {

    private:
        int engine_number;
    public:
        
        Engine(){}
        Engine(int number){
            engine_number=number;
        }

    
        int getEngineNumber()  {
            return engine_number;
        }


};


class Passenger {
    private:
        string passenger_name;
    public:
        
        Passenger(string name) {
            passenger_name=name;
        }

        
        string getPassengerName()  {
            return passenger_name;
        }


};


class Car {
    private:
        
        Engine carEngine;

       
        Passenger *carPassenger;
    public:
        
        Car(Engine engineNumber, Passenger passengerName){
            carEngine = engineNumber;
            carPassenger = &passengerName;
        }

        
        void displayInfo()  {
            cout << "Engine Number: " << carEngine.getEngineNumber() << endl;
            cout << "Passenger Name: " << carPassenger->getPassengerName() << endl;
        }


};

int main() {
    Engine e1(123);
    Passenger p1("Muzamil");
    
    Car myCar( e1 , p1);

    
    myCar.displayInfo();

    return 0;
}