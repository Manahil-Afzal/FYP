/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
#include<string>
using namespace std;

class Engine{
    private: 
        int engine_number;
    public:
        Engine(int en){
            engine_number = en;
        }
        
        int get_engine_number(){
            return engine_number;
        }
            
};

class Passenger{
    private:
        string passenger_name;
    public:
        Passenger(string n){
            passenger_name = n;
        }
        string get_passenger_name(){
            return passenger_name;
        }
};

class Car{
    private: 
        Engine E1;
        Passenger *P1;
    public:
        Car(int a, string n) : E1(a), P1(new Passenger(n)){}
        
        void get_info(){
            cout<<"Engine Number: "<<E1.get_engine_number()<<endl;
            cout<<"Passenger name: "<<P1->get_passenger_name()<<endl;
        }
        
        ~Car(){
            delete P1;
        }
};

int main(){
    
    Car c1(45,"muzamil");
    c1.get_info();
    return 0;
}