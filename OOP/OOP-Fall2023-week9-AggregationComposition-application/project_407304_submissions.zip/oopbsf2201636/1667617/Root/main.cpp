/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

class Engine {
public:
    int engine_number;

    // Constructor to set the engine number
    Engine(int number) : engine_number(number) {}
};

class Passenger {
public:
    std::string passenger_name;

    // Constructor to set the passenger name
    Passenger(const std::string& name) : passenger_name(name) {}
};

class Car {
public:
    Engine carEngine; // Aggregation relationship with Engine class
    Passenger carPassenger; // Aggregation relationship with Passenger class

    // Constructor to initialize Car object with Engine and Passenger objects
    Car(int engineNumber, const std::string& passengerName)
        : carEngine(engineNumber), carPassenger(passengerName) {}

    // Function to display engine number and passenger name
    void displayDetails() const {
        std::cout << "Engine Number: " << carEngine.engine_number << "\n";
        std::cout << "Passenger Name: " << carPassenger.passenger_name << "\n";
    }
};

int main() {
    // Create a Car object with specific engine number and passenger name
    Car myCar(12345, "John Doe");

    // Display details of the Car
    myCar.displayDetails();

    return 0;
}
