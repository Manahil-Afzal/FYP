/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
using namespace std;
class Engine{
    private:
    int engine_number;
    public:
    void getdata(){
        cout<<"Enter engine number of vehicle: ";
        cin>>engine_number;
    }
    int putdata(){
        return engine_number;
    }
};
class Passanger{
    private:
    string name;
    public:
    void getdata(){
        cout<<"Enter passanger name:";
        cin>>name;
    }
    string putdata(){
        return name;
    }
};
class Car{
    private:
    Passanger *p1;
    Engine *e1;
    public:
    Car(Passanger *p2,Engine *e2){
        p1=p2;
        e1=e2;
        p1->getdata();
        e1->getdata();
    }
    void showdata(){
        cout<<p1->putdata()<<endl;
        cout<<e1->putdata();
    }
};

int main(){
    Passanger p1;
    Engine e1;
    Car c1(&p1,&e1);
    c1.showdata();
    
}