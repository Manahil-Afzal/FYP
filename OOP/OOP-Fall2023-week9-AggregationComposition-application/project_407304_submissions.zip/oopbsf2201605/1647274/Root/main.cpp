/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine {
public:
    Engine(int engineNumber) : engine_number(engineNumber) {}

    int getEngineNumber() {
        return engine_number;
    }
private:
    int engine_number;
};

class Passenger {
public:
    Passenger(const std::string& name) : passenger_name(name) {}

    std::string getPassengerName() {
        return passenger_name;
    }

private:
    std::string passenger_name;
};

class Car {
public:
    Car(int engineNumber, const std::string& passengerName)
        : engine(engineNumber), passenger(passengerName) {}

    void displayCarInfo() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }
private:
    Engine engine;
    Passenger passenger;
};

int main() {
    int engineNumber = 12345;
    std::string passengerName = "John Doe";

    Car car(engineNumber, passengerName);

    car.displayCarInfo();

    return 0;
}
