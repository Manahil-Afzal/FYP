/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

// Engine class definition
class Engine {
public:
    Engine(int engine_number) : engine_number(engine_number) {}

    int getEngineNumber() const {
        return engine_number;
    }

private:
    int engine_number;
};

// Passenger class definition
class Passenger {
public:
    Passenger(const std::string& passenger_name) : passenger_name(passenger_name) {}

    const std::string& getPassengerName() const {
        return passenger_name;
    }

private:
    std::string passenger_name;
};

// Car class definition with aggregation relationship
class Car {
public:
    Car(int engine_number, const std::string& passenger_name) : engine(engine_number), passenger(passenger_name) {}

    void displayInfo() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    Car myCar(12345, "John Doe");
    myCar.displayInfo();
    return 0;
}