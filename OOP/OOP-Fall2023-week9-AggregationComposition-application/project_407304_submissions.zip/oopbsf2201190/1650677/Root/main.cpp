#include <iostream>
using namespace std;
class Engine {
public:
  
   void set_EngineNumber(int e)
   {
   	engine_number=e;
   }
    int get_EngineNumber()
    {
        return engine_number; 
    }

private:
    int engine_number;
};

class Passenger {
public:
   // Passenger(const string& passengerName) : passenger_name(passengerName) {}
   void set_PassengerName(string p)
   {
   	passenger_name=p;
   }
    string get_PassengerName() { 
        return passenger_name;
        }

private:
    string passenger_name;
};

class Car {
	Engine engine;
	Passenger passenger;
public:
	Car(){
engine.set_EngineNumber(345);
passenger.set_PassengerName("saba");
}
    void displayInfo() {
        cout << "Engine Number: " << engine.get_EngineNumber() << endl;
        cout << "Passenger Name: " << passenger.get_PassengerName() << endl;
    }
};

int main() {
    Car car;

    car.displayInfo();

    return 0;
}
