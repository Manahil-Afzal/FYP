/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
#include <string>

class Engine {
public:
    std::string engine_number;

    // Constructor to set the engine number
    Engine(const std::string& number) : engine_number(number) {}
};

class Passenger {
public:
    std::string passenger_name;

    // Constructor to set the passenger name
    Passenger(const std::string& name) : passenger_name(name) {}
};

class Car {
public:
    Engine carEngine;
    Passenger carPassenger;

    // Constructor to initialize the Engine and Passenger objects
    Car(const std::string& engineNumber, const std::string& passengerName) : carEngine(engineNumber), carPassenger(passengerName) {}

    // Display the engine number and passenger name
    void displayInfo() {
        std::cout << "Engine Number: " << carEngine.engine_number << std::endl;
        std::cout << "Passenger Name: " << carPassenger.passenger_name << std::endl;
    }
};

int main() {
    // Create a Car object with an Engine and a Passenger
    Car myCar("12345", "John Doe");

    // Display the engine number and passenger name
    myCar.displayInfo();

    return 0;
}
