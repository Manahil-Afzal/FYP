/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/ #include <iostream>
using namespace std;
class Engine{
 private:
 string  engine_number;
 public:
 Engine(){
 engine_number="XX";
 }
 void set_engine_number(string e){engine_number=e;}
 string get_engine_number(){
     return engine_number;
 }
};
class Passenger{
  private:
  string name;
  public:
  void set_name(string n){
      name=n;
  }
  string get_name(){
      return name;
  }
};
class Car{
    private:
    Engine eng;
    Passenger *pen;
    Passenger p;
    public:
    Car(){
        Engine();
     //eng.set_engine_number("XXX");
    pen=&p;
    pen->set_name("ali");
    }
    void show(){
        cout<<"Engine number of the car :";
        cout<<eng.get_engine_number()<<endl;
        cout<<"Passenger name of that car: ";
        cout<<pen->get_name();
    }
};
main(){
    Car C1;
    C1.show();
}
