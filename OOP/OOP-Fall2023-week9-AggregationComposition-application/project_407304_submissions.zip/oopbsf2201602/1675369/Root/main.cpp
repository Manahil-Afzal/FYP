/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;

class Engine {
  private:
    int engine_number;

  public:
    Engine(){
        engine_number = 0;
    }
    Engine(int engine_number) {
      this->engine_number = engine_number;
    }

    int getEngineNumber() {
      return engine_number;
    }
};

class Passenger {
  private:
    string passenger_name;

  public:
    Passenger(){
        passenger_name = "";
    }
    Passenger(string name) {
      this->passenger_name = name;
    }

    string getPassengerName() {
      return passenger_name;
    }
};

class Car {
    private:
        Engine engine;
        Passenger passenger;
    
    public:
    Car(){
        
    }
        Car(Engine engine, Passenger passenger) {
        this->engine = engine;
        this->passenger = passenger;
        }
    
        void display() {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
        }
    };


int main() {
  Passenger passenger("John Doe");
  Engine engine(1234);

  Car car(engine, passenger);

  car.display();

  return 0;
}
