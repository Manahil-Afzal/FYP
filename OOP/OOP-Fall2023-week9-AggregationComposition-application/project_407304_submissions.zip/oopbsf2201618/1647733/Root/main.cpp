/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
#include <string>
using namespace std;
class Engine {
public:
    Engine(int engineNumber) : engine_number(engineNumber) {
    }
    int getEngineNumber() const {
        return engine_number;
    }
private:
    int engine_number;
};
class Passenger {
public:
    Passenger(const string& passengerName) : passenger_name(passengerName) {
    }
    string getPassengerName() const {
        return passenger_name;
    }
private:
    string passenger_name;
};
class Car {
public:
    Car(int engineNumber, const std::string& passengerName) : engine(engineNumber), passenger(passengerName) {
    }
    void displayCarDetails() {
        cout << "Engine Number: " << engine.getEngineNumber() <<endl;
        cout << "Passenger Name: " << passenger.getPassengerName() <<endl;
    }
private:
    Engine engine;
    Passenger passenger;
};
int main() {
    Car myCar(12345, "John Doe");
    myCar.displayCarDetails();

    return 0;
}
