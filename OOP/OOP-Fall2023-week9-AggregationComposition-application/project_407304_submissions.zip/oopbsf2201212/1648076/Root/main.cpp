/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

class Engine {
public:
    std::string engine_number;

    Engine(const std::string& number) : engine_number(number) {}
};

class Passenger {
public:
    std::string passenger_name;

    Passenger(const std::string& name) : passenger_name(name) {}
};

class Car {
public:
    Engine car_engine;
    Passenger car_passenger;

    Car(const std::string& engineNumber, const std::string& passengerName)
        : car_engine(engineNumber), car_passenger(passengerName) {}
    
    void displayInfo() {
        std::cout << "Engine Number: " << car_engine.engine_number << std::endl;
        std::cout << "Passenger Name: " << car_passenger.passenger_name << std::endl;
    }
};

int main() {
       Engine carEngine("ABC123");
    Passenger carPassenger("John Smith");
    
    Car myCar(carEngine.engine_number, carPassenger.passenger_name);

    myCar.displayInfo();

    return 0;
}
