/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/ 


#include <iostream>
#include <string>

// Engine class
class Engine {
public:
    Engine(int engineNumber) : engine_number(engineNumber) {}

    int getEngineNumber() {
        return engine_number;
    }

private:
    int engine_number;
};

// Passenger class
class Passenger {
public:
    Passenger(const std::string& name) : passenger_name(name) {}

    std::string getPassengerName() {
        return passenger_name;
    }

private:
    std::string passenger_name;
};

// Car class
class Car {
public:
    Car(int engineNumber, const std::string& passengerName) : engine(engineNumber), passenger(passengerName) {}

    void displayCarDetails() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    // Create a Car object with an Engine and Passenger
    Car car(12345, "John Doe");

    // Display car details
    car.displayCarDetails();

    return 0;
}
