/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
using namespace std;

class Engine
{
	private:
		string engine_num;
	public:
		void set_engine_num(string num)
		{
			engine_num=num;
		}
		string get_engine_num(){
			return engine_num;
		}
};

class Passenger
{
	private:
		string passenger_name;
	public:
		void set_passenger_name(string name)
		{
			passenger_name=name;
		}
		string get_passenger_name(){
			return passenger_name;
		}
};

class Car
{
	private:
		Engine engine;
		Passenger passenger;
	public:
		Car(){
			engine.set_engine_num("Yamaha_3310");
			passenger.set_passenger_name("Murtaza");
		}
		void show_Car(){
			cout<<engine.get_engine_num()<<endl;
			cout<<passenger.get_passenger_name();
		}		
};

main(){
	Car c1;
	c1.show_Car();
}