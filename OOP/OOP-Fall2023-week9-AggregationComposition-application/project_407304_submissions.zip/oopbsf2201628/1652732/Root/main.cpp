/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
#include <string>

// Define the Engine class
class Engine {
public:
    // Constructor to set the engine number
    Engine(int engineNumber) : engine_number(engineNumber) {}

    // Function to get the engine number
    int getEngineNumber() {
        return engine_number;
    }

private:
    int engine_number;
};

// Define the Passenger class
class Passenger {
public:
    // Constructor to set the passenger name
    Passenger(const std::string& passengerName) : passenger_name(passengerName) {}

    // Function to get the passenger name
    std::string getPassengerName() {
        return passenger_name;
    }

private:
    std::string passenger_name;
};

// Define the Car class with aggregation relationships
class Car {
public:
    // Constructor to initialize the Engine and Passenger objects
    Car(int engineNumber, const std::string& passengerName) : engine(engineNumber), passenger(passengerName) {}

    // Function to display engine number and passenger name
    void displayCarInfo() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    // Create a Car object with an Engine and a Passenger
    Car car(12345, "John Doe");

    // Display car information
    car.displayCarInfo();

    return 0;
}
