/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
#include <string>

using namespace std;

class Engine {
public:
    Engine(int number) : engine_number(number) {}

    int getEngineNumber() const {
        return engine_number;
    }

private:
    int engine_number;
};

class Passenger {
public:
    Passenger(const string& name) : passenger_name(name) {}

    const string& getPassengerName() const {
        return passenger_name;
    }

private:
    string passenger_name;
};

class Car {
public:
    Car(int engineNumber, const string& passengerName)
        : carEngine(engineNumber), carPassenger(passengerName) {}

    void displayInfo() const {
        cout << "Engine Number: " << carEngine.getEngineNumber() << '\n';
        cout << "Passenger Name: " << carPassenger.getPassengerName() << '\n';
    }

private:
    Engine carEngine;
    Passenger carPassenger;
};

int main() {
    Car myCar(007, "ALI");
    myCar.displayInfo();

    return 0;
}
