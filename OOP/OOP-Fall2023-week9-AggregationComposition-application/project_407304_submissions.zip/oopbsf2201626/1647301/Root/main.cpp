/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>

class Engine {
public:
    Engine(int engineNumber) : engineNumber(engineNumber) {}

    int getEngineNumber() const {
        return engineNumber;
    }

private:
    int engineNumber;
};

class Passenger {
public:
    Passenger(const char* passengerName) : passengerName(passengerName) {}

    const char* getPassengerName() const {
        return passengerName;
    }

private:
    const char* passengerName;
};

class Car {
public:
    Car(int engineNumber, const char* passengerName) : engine(engineNumber), passenger(passengerName) {}

    void displayCarDetails() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    int engineNumber = 12345;
    const char* passengerName = "zain ali";

    Car car(engineNumber, passengerName);
    car.displayCarDetails();

    return 0;
}
 