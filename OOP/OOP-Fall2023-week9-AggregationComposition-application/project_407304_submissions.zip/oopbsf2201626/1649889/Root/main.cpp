/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine {
public:
    Engine(int engine_number) {
        this->engine_number = engine_number;
    }

    int getEngineNumber() {
        return engine_number;
    }

private:
    int engine_number;
};

class Passenger {
public:
    Passenger(const char* passenger_name) {
        this->passenger_name = passenger_name;
    }

    const char* getPassengerName() {
        return passenger_name;
    }

private:
    const char* passenger_name;
};

class Car {
public:
    Car(int engine_number, const char* passenger_name) : engine(engine_number), passenger(passenger_name) {}

    void displayInfo() {
        cout << "Engine Number: " << engine.getEngineNumber() <<endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {

    Car car(12345, "John Doe");
    car.displayInfo();

    return 0;
}