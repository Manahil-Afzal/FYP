#include <iostream>
#include <string>

class Engine {
public:
    Engine(int number) : engine_number(number) {}

    int getEngineNumber() const {
        return engine_number;
    }

private:
    int engine_number;
};

class Passenger {
public:
    Passenger(const std::string& name) : passenger_name(name) {}

    const std::string& getPassengerName() const {
        return passenger_name;
    }

private:
    std::string passenger_name;
};

class Car {
public:
    Car(int engineNumber, const std::string& passengerName)
        : engine(engineNumber), passenger(passengerName) {}

    void displayInfo() const {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }

private:
    Engine engine;       
    Passenger passenger;  
};

int main() {
    
    Car myCar(12345, "John Doe");

    // Display engine number and passenger name
    myCar.displayInfo();

    return 0;
}
