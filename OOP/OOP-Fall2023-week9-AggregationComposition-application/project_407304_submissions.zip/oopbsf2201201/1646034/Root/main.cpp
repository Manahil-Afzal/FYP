/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>
using namespace std;

class Engine {
public:
    Engine(int engineNumber) : engineNumber(engineNumber) {}

    int getEngineNumber() {
        return engineNumber;
    }

private:
    int engineNumber;
};


class Passenger {
public:
    Passenger(const string& name) : passengerName(name) {}

    string getPassengerName() {
        return passengerName;
    }

private:
    string passengerName;
};

class Car {
public:
    Car(int engineNumber, const string& passengerName)
        : carEngine(engineNumber), carPassenger(passengerName) {}

    void displayCarInfo() {
        std::cout << "Engine Number: " << carEngine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << carPassenger.getPassengerName() << std::endl;
    }

private:
    Engine carEngine;
    Passenger carPassenger;
};

int main() {
    
    Car myCar(12345, "John Doe");

    
    myCar.displayCarInfo();

    return 0;
}