/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

class Engine {
private:
    std::string engine_number;

public:
    Engine(const std::string &number) : engine_number(number) {}

    std::string getEngineNumber() const {
        return engine_number;
    }
};

class Passenger {
private:
    std::string passenger_name;

public:
    Passenger(const std::string &name) : passenger_name(name) {}

    std::string getPassengerName() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine carEngine;
    Passenger carPassenger;

public:
    Car(const std::string &engineNumber, const std::string &passengerName) : carEngine(engineNumber), carPassenger(passengerName) {}

    void displayCarInfo() {
        std::cout << "Engine Number: " << carEngine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << carPassenger.getPassengerName() << std::endl;
    }
};

int main() {
    
    Car myCar("ABC12345", "John Doe");

    
    myCar.displayCarInfo();

    return 0;
}
