/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;


class Engine {
private:
   string engine_number;

public:
    Engine(string engineNumber) : engine_number(engineNumber) {}

    
    string getEngineNumber() const {
        return engine_number;
    }
};


class Passenger {
private:
   string passenger_name;

public:
    
    Passenger(string passengerName) : passenger_name(passengerName) {}

   
   string getPassengerName() const {
        return passenger_name;
    }
};


class Car {
private:
    Engine carEngine;
    Passenger carPassenger;

public:
    
    Car(string engineNumber,string passengerName)
        : carEngine(engineNumber), carPassenger(passengerName) {}

    
    void displayInfo() const {
       cout << "Engine Number: " << carEngine.getEngineNumber() <<endl;
        cout << "Passenger Name: " << carPassenger.getPassengerName() <<endl;
    }
};

int main() {
    
    Car myCar("XYZ123", "John Doe");

   
    myCar.displayInfo();

    return 0;
}