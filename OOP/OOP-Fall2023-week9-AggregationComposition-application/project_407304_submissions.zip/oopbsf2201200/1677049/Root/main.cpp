/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

// Define the Engine class
class Engine {
private:
    std::string engine_number;

public:
    // Constructor to set the engine number
    Engine(const std::string& number) : engine_number(number) {}

    // Getter function to retrieve the engine number
    std::string getEngineNumber() const {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    std::string passenger_name;

public:
    // Constructor to set the passenger name
    Passenger(const std::string& name) : passenger_name(name) {}

    // Getter function to retrieve the passenger name
    std::string getPassengerName() const {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine carEngine; // Aggregation relationship
    Passenger carPassenger; // Aggregation relationship

public:
    // Constructor to initialize Car with Engine and Passenger objects
    Car(const Engine& engine, const Passenger& passenger)
        : carEngine(engine), carPassenger(passenger) {}

    // Function to display engine number and passenger name
    void displayInfo() const {
        std::cout << "Engine Number: " << carEngine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << carPassenger.getPassengerName() << std::endl;
    }
};

int main() {
    // Create Engine object with engine number
    Engine carEngine("ABC123");

    // Create Passenger object with passenger name
    Passenger carPassenger("John Doe");

    // Create Car object with Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display information about the car
    myCar.displayInfo();

    return 0;
}
