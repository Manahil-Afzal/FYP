/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;

class Engine{
private:
    int engine_number;
public:
    Engine(int engine_num)   {engine_number=engine_num;
    }

    int getEngineNumber() {
        return engine_number;
    }


};

class Passenger {
public:
     Passenger(string n){
    passenger_name=n;}

    string getPassengerName() {
        return passenger_name;
    }

private:
    string passenger_name;
};

class Car {
public:
    Car(Engine number, Passenger name) : engine(number), passenger(&name) {
        // Use initializer list to initialize engine and passenger.
    }
    void displayInfo() {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger->getPassengerName() << std::endl;
    }

private:
    Engine engine;
    Passenger *passenger;
};

int main() {
    // Create a Car object with engine number and passenger name
    Engine e1(12345);
    Passenger p1("Ali");
    Car myCar(e1,p1);

    // Display the information
    myCar.displayInfo();

    return 0;
}