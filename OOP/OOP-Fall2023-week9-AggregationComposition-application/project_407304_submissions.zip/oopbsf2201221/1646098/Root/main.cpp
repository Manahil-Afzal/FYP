/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;
class Engine{
private:
int eng_num;
public:
void set_eng_num(int num)
{
eng_num = num;
}
int get_eng_num(){
return eng_num;}
};
class Passenger{
private:
string passenger_name;
Engine engine;
public:
Passenger(){
passenger_name="Junaid";
engine.set_eng_num(10);
}
void show_Car(){
    cout<<"Car  : Ferrari Evo X Model ,"<<endl;
cout<<"Passenger name: "<<passenger_name<<"   / ";
cout<<"Engine number: "<<engine.get_eng_num()<<".";
}
};
main(){
Passenger c1;
c1.show_Car();
}