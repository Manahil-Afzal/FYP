/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting it to 1." << std::endl;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational &other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    void input() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;
        std::cout << "Enter denominator (non-zero): ";
        std::cin >> denominator;
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting it to 1." << std::endl;
            denominator = 1;
        }
    }

    void display() const {
        std::cout << numerator << "/" << denominator;
    }

    static int getCount() {
        return count;
    }

    Rational operator*(const Rational &other) const {
        Rational result(numerator * other.numerator, denominator * other.denominator);
        return result;
    }

    Rational operator/(const Rational &other) const {
        Rational result(numerator * other.denominator, denominator * other.numerator);
        return result;
    }

    ~Rational() {
        count--;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2 = r1; // Copy constructor used
    Rational r3;

    r3.input();

    std::cout << "Multiplication: ";
    r1.display();
    std::cout << " * ";
    r2.display();
    std::cout << " = ";
    (r1 * r2).display();
    std::cout << std::endl;

    std::cout << "Division: ";
    r1.display();
    std::cout << " / ";
    r3.display();
    std::cout << " = ";
    (r1 / r3).display();
    std::cout << std::endl;

    std::cout << "Total Rational objects created: " << Rational::getCount() << std::endl;

    return 0;
}