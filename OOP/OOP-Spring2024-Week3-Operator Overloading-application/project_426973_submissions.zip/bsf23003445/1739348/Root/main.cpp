/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;
class real {
private:
    int numerator;
    int denominator;
    static int Count;

public:
    // Parameterized Constructor
    real(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cerr << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        Count++; // Increment object count upon creation
    }

    // Copy Constructor
    real(const real& other) : numerator(other.numerator), denominator(other.denominator) {
       Count++; // Increment object count upon creation
    }

    // Method to take inputs
    void input() {
     cout << "Enter numerator: ";
     cin >> numerator;
     cout << "Enter denominator (non-zero): ";
     cin >> denominator;
        if (denominator == 0) {
        cerr << "Error: Denominator cannot be zero. Setting denominator to 1." <<endl;
            denominator = 1;
        }
    }

    // Overloaded * operator for multiplication
    real operator*(const real other) const {
        return real(numerator * other.numerator, denominator * other.denominator);
    }

    // Overloaded / operator for division
    real operator/(const real other) const {
        if (other.numerator == 0) {
            cerr << "Error: Division by zero. Returning default rational number." <<endl;
            return real();
        }
        return real(numerator * other.denominator, denominator * other.numerator);
    }

    // Display the rational number
    void display() const {
       cout << numerator << "/" << denominator;
    }

    // Static member to keep track of object count
    static int getObjectCount() {
        return Count;
    }
};

// Initializing static member outside the class
int real::Count = 0;

int main() {
    real a(3, 4);
    real b;
    
   cout << "Object count: " << real::getObjectCount() << endl;
    
    b.input();

    cout << "Object count: " <<real::getObjectCount() <<endl;
    
   real c = a * b;
    real d = a / b;

   cout << "Multiplication: ";
    c.display();
    cout <<endl;

    cout << "Division: ";
    d.display();
    cout << endl;

    return 0;
}