/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

using namespace std;

class RationalNumber {
public:
   RationalNumber(int num, int den) : numerator(num), denominator(den) {
       ++count;
   }

   RationalNumber(const RationalNumber& other) : numerator(other.numerator), denominator(other.denominator) {
       ++count;
   }

   void input() {
       cout << "Enter the numerator: ";
       cin >> numerator;
       cout << "Enter the denominator: ";
       cin >> denominator;
   }

   RationalNumber operator*(const RationalNumber& other) {
       int new_num = numerator * other.numerator;
       int new_den = denominator * other.denominator;
       return RationalNumber(new_num, new_den);
   }

   RationalNumber operator/(const RationalNumber& other) {
       int new_num = numerator * other.denominator;
       int new_den = denominator * other.numerator;
       return RationalNumber(new_num, new_den);
   }

   void display() {
       cout << numerator << "/" << denominator << endl;
   }

   static int getCount() {
       return count;
   }

private:
   int numerator;
   int denominator;
   static int count;

   void checkDenominator() {
       if (denominator == 0) {
           cerr << "Error: Denominator cannot be zero." << endl;
           
       }
   }
};

int RationalNumber::count = 0;

int main() {
   RationalNumber r1(3, 4);
   RationalNumber r2(5, 6);

   cout << "First rational number: ";
   r1.display();

   cout << "Second rational number: ";
   r2.display();

   RationalNumber r3 = r1 * r2;
   cout << "Product of r1 and r2: ";
   r3.display();

   RationalNumber r4 = r1 / r2;
   cout << "Quotient of r1 and r2: ";
   r4.display();

   cout << "Number of objects created: " << RationalNumber::getCount() << endl;

   return 0;
}