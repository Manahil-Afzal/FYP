/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;
class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) {
        numerator = num;
        denominator = den;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational& rati) {
        numerator = rati.numerator;
        denominator = rati.denominator;
        count++;
    }
    void getValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    Rational operator*(const Rational &rati) {
        return Rational(numerator * rati.numerator, denominator * rati.denominator);
    }

    Rational operator/(const Rational &rati) {
        if (rati.numerator == 0) {
            cout << "Error: Division by zero." << endl;
            return Rational();
        }
        return Rational(numerator * rati.denominator, denominator * rati.numerator);
    }

    static int getCount() {
        return count;
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r1, r2;
    cout << "Enter values for the first rational number:"<<endl;
    r1.getValues();
    cout << "Enter values for the second rational number:"<<endl;
    r2.getValues();

    Rational r3 = r1 * r2;
    cout << "Multiplication:"<<endl;
    r3.display();

    Rational r4 = r1 / r2;
    cout << "Division:"<<endl;
    r4.display();
    cout << "Number of rational objects created: " << Rational::getCount() << endl;
    return 0;
}