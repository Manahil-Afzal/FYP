/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) {
        numerator = num;
        if (den != 0) {
            denominator = den;
        } else {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    // Copy constructor
    Rational(const Rational &r) {
        numerator = r.numerator;
        denominator = r.denominator;
        count++;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (not zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Static member to keep the count of objects
    static int getCount() {
        return count;
    }

    Rational operator*(const Rational &r) {
        Rational result;
        result.numerator = numerator * r.numerator;
        result.denominator = denominator * r.denominator;
        return result;
    }

    Rational operator/(const Rational &r) {
        Rational result;
        result.numerator = numerator * r.denominator;
        result.denominator = denominator * r.numerator;
        return result;
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }

    ~Rational() {
        count--; // Decrement count of objects
    }
};

int Rational::count = 0; // Initializing static member count

int main() {
    Rational r1(3, 4); 
    Rational r2 = r1;  
    Rational r3;

    r3.input(); 

    Rational multiply = r1 * r2; 
    cout << "Multiplication ";
    multiply.display();

    Rational divide = r1 / r2;
    cout << "Division ";
    divide.display();

    cout << "Number of Rational objects created: " << Rational::getCount() << endl;

    return 0;
}