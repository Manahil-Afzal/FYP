/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class Rational{
    float numerator,denominator;
    public:
    	static int objcount;// static variable to keep track numbers of objects
        Rational(float num,float den);// parametrized constructor to initalize the numerator & denominator
        Rational(Rational &obj);//A copy constructor
        Rational();//A default constructor
        void getValue();// A method to input values
        void operator *(const Rational &obj); // Multiplication "*" operator overloading
        void operator /(const Rational &obj); // Divison "/" operator overloading
        void Display();
};  
Rational::Rational(float num,float den){
    numerator=num;
    while(den==0){
        cout<<"Denominator can't be zero,,,Enter valid number : "<<endl;
        cin>>den;
    }
    denominator=den;
    objcount++;
}
Rational::Rational(Rational &obj){
    numerator=obj.numerator;
    denominator=obj.denominator;
    objcount++;
}
Rational::Rational(){ // Default Constructor
    objcount++;
    numerator=denominator=1;// Default values if no values are entered by the user
}
void Rational::getValue(){ //A input method to enter values 
    cout<<"Enter Value for Numerator : "<<endl;
    cin>>numerator;
    cout<<"Enter Value for Denominator : "<<endl;
    cin>>denominator;
    while(denominator==0){
        cout<<"Denominator can't be zero,,,Enter valid number : "<<endl;
        cin>>denominator;
    }
}
void Rational::operator  *(const Rational &obj){  // Multiplication "*" operator overloading
        numerator*=obj.numerator;
        denominator*=obj.denominator;
        numerator=numerator/denominator;
    }
void Rational::operator /(const Rational &obj){   // Divison "/" operator overloading
        numerator*=obj.denominator;
        denominator*=obj.numerator;
        numerator=numerator/denominator;
    }
void Rational::Display(){
	cout<<numerator*denominator<<"/"<<denominator<<" = "<<numerator<<endl;
}
int Rational::objcount=0;
int main(){
    Rational r1(4,7),r3;
    Rational r2=r1;
    r2*r1;
    cout<<"Result of Multiplication is : "<<endl;
	r2.Display();
    Rational r4(4,5);
    r3.getValue();
    r3/r4;
    cout<<"Result of Division is : "<<endl;
    r3.Display();
    cout<<"There are "<<Rational::objcount<<" objects created";
}