#include<iostream>

using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;

public:
    RationalNumber(int num = 0, int den = 1): numerator(num), denominator(den) {
        if(denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    RationalNumber(const RationalNumber &obj): numerator(obj.numerator), denominator(obj.denominator) {
        count++;
    }

    static int getCount() {
        return count;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (not zero): ";
        cin >> denominator;
        if(denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        }
    }

    RationalNumber operator*(const RationalNumber &obj) {
        RationalNumber result;
        result.numerator = this->numerator * obj.numerator;
        result.denominator = this->denominator * obj.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber &obj) {
        RationalNumber result;
        result.numerator = this->numerator * obj.denominator;
        result.denominator = this->denominator * obj.numerator;
        return result;
    }

    void display() {
        cout << "Resultant Rational Number: " << numerator << "/" << denominator << endl;
    }

    ~RationalNumber() {
        count--;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber obj1(3, 4);
    RationalNumber obj2 = obj1; // Copy constructor used to initialize obj2 from obj1

    RationalNumber::getCount(); // to get the count of objects created

    cout << "Enter values for second rational number:" << endl;
    RationalNumber obj3;
    obj3.input();

    RationalNumber multiplyResult = obj1 * obj3;
    cout << "Multiplication: ";
    multiplyResult.display();

    RationalNumber divideResult = obj1 / obj3;
    cout << "Division: ";
    divideResult.display();

    return 0;
}/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/