/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count; 

public:
    
    RationalNumber(int num = 1, int denom = 1) {
        numerator = num;
        if (denom != 0)
            denominator = denom;
        else {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++; 
    }

    
    RationalNumber(const RationalNumber &obj) {
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++; 
    }

    ~RationalNumber() {
        count--;
    }

    void inputValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    RationalNumber operator*(const RationalNumber &obj) {
        RationalNumber result;
        result.numerator = numerator * obj.numerator;
        result.denominator = denominator * obj.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber &obj) {
        RationalNumber result;
        result.numerator = numerator * obj.denominator;
        result.denominator = denominator * obj.numerator;
        return result;
    }

    void display() {
        cout << numerator << "/" << denominator;
    }

    static int getCount() {
        return count;
    }
};

int RationalNumber::count = 0; 

int main() {
    RationalNumber r1(4, 5); 
    RationalNumber r2(r1);   

    cout << "Number of objects created: " << RationalNumber::getCount() << endl;

    RationalNumber r3, r4;
    r3.inputValues(); 
    r4.inputValues(); 

    cout << "Multiplication: ";
    r3.display();
    cout << " * ";
    r4.display();
    cout << " = ";
    (r3 * r4).display(); 
    cout << endl;

    cout << "Division: ";
    r3.display();
    cout << " / ";
    r4.display();
    cout << " = ";
    (r3 / r4).display(); 
    cout << endl;

    cout << "Number of objects after operations: " << RationalNumber::getCount() << endl;

    return 0;
}
