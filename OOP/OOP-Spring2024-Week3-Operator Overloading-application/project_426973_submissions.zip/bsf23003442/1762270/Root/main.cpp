/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int den;
    int num;
    static int count;

public:
    Rational(int n = 0, int i = 0) {
        den = i;
        num = n;
        count++;
    }

    static int getCount() {
        return count;
    }

    void getValues() {
        cout << "Enter the value of Numerator: ";
        cin >> num;
        cout << "Enter the value of Denominator: ";
        cin >> den;
        if (den == 0) {
            cout << "Denominator can't be zero! Setting value to 1." << endl;
            den = 1;
        }
    }

    Rational operator*(Rational &obj) {
        Rational res;
        res.den = den * obj.den;
        res.num = num * obj.num;
        return res;
    }

    Rational operator/(Rational &obj) {
        Rational res1;
        res1.num = this->num / obj.num;
        res1.den = this->den / obj.den;
        return res1;
    }

    void display() {
        cout << "Product of Rational numbers is: " << num << " / " << den << endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r(3, 4);
    Rational r1 = r;
    r1.getValues();
    Rational r2 = r * r1;
    Rational r3 = r / r1;
    r3.display();
    r2.display();
    cout << "Objects created: " << Rational::getCount() << endl;
}
