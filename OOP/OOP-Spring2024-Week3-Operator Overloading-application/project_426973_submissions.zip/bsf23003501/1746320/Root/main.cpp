#include <iostream>
using namespace std;

class Rational {
    int numerator, denominator;
    static int count;

public:
    Rational(int num, int den);
    Rational(const Rational& obj);

    void input();
    void multiply(const Rational& obj);
    void divide(const Rational& obj);
    void display();

    static int getCount();
};

int Rational::count = 0;

Rational::Rational(int num, int den) : numerator(num), denominator(den)
{
    count++;
}

Rational::Rational(const Rational& obj) : numerator(obj.numerator), denominator(obj.denominator)
{
    count++;
}

void Rational::input()
{
    cout << "Enter numerator: ";
    cin >> numerator;

    do {
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
    } while (denominator == 0);
}

void Rational::multiply(const Rational& obj)
{
    numerator *= obj.numerator;
    denominator *= obj.denominator;
}

void Rational::divide(const Rational& obj)
{
    if (obj.numerator != 0) {
        numerator *= obj.denominator;
        denominator *= obj.numerator;
    } else {
        cout << "Division by zero not allowed." << endl;
    }
}

void Rational::display()
{
    cout << "Result: " << numerator << " / " << denominator << endl;
}

int Rational::getCount()
{
    return count;
}

int main()
{
    Rational r1(2, 3);
    Rational r2 = r1;

    cout << "Objects created: " << Rational::getCount() << endl;

    r1.input();
    r2.input();

    r1.multiply(r2);
    cout << "After multiplication: ";
    r1.display();

    r1.divide(r2);
    cout << "After division: ";
    r1.display();

    return 0;
}
