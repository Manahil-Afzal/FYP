#include<iostream>
using namespace std;
class rational{
	float num;
	float den;
	public:
		static int no;
	rational(){
		no++;
	}
	rational(int x,int y){
		num=x;
		den=y;
	}
	rational(rational &obj){
		num=obj.num;
		den=obj.den;
	}
	void getdata(){
		cout<<"Enter the value of numerator and denominator"<<endl;
		cin>>num>>den;
	}
	void display(){
		cout<<"The numerator is"<<num<<endl<<"The denominator is"<<den<<endl;
	}
	rational operator * (rational &obj1){
		rational res;
		res.num=num*obj1.num;
		res.den=den*obj1.den;
        return res;	
	}
	rational operator / (rational &obj2){
		rational res1;
		res1.num=num/obj2.num;
		res1.den=den/obj2.den;
		return res1;
		}
};
int rational::no=0;
int main()
{
	rational r1(2,3);
	rational r2(r1);
	rational r3,r4,r5;
	r3.getdata();
    r4=r2*r3;
    cout<<"the value of n and d after multiplication"<<endl;
    r4.display();
    r5=r2/r3;
    cout<<"the value of n and d after division"<<endl;
    r5.display();
    cout<<"The total obj created is"<<rational::no<<endl;


 return 0;
}