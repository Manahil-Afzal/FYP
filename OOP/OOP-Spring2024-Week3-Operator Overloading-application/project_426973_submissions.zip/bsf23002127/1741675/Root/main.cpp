/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class RationalNumber{
    private:
    int numerator;
    int denominator;
    static int objectCount;
public:
//parameterized constructor
RationalNumber(int num =0 ,int den = 1):numerator(num),denominator(den){
    if(denominator == 0){
        cout<<"Error:Denominator cannot be zero.Setting denominator to 1."<<endl;
        denominator = 1;
    }
    objectCount++;
}
// copy constructor
RationalNumber(const RationalNumber& other):numerator(other.numerator), denominator(other.denominator){
    objectCount++;
}
void getInput(){
    cout<<"Enter numerator:";
    cin>>numerator;
    do{
        cout<<"Enter denominator(not zero):";
        cin>>denominator;
        if(denominator == 0){
            cout<<"Error:Denominator cannot be zero.Please enter a non-zero value."<<endl;
        }
    }while(denominator == 0);
}
RationalNumber multiply(const RationalNumber&other){
    int newNum= numerator* other.numerator;
    int newDen=denominator* other.denominator;
    return RationalNumber(newNum, newDen);
}
RationalNumber divide(const RationalNumber& other){
    if(other.numerator == 0){
        cout<<"Error: Division by zero is undefined. setting result to 0/1."<<endl;
        return RationalNumber();
    }
    int newNum= numerator* other.denominator;
    int newDen=denominator* other.numerator;
    return RationalNumber(newNum, newDen);
}
static int getObjectCount(){
    return objectCount;
}
// Dectructor to decrement object count when an object is destroyed
~RationalNumber(){
    objectCount--;
}
};
//initializing static member 
int RationalNumber::objectCount = 0;
int main(){
RationalNumber num1 , num2;
cout<<"Enter values for the first rational number:"<<endl;
num1.getInput();
RationalNumber num3 = num1;
cout<<"Enter values for the second rational number:"<<endl;
num2.getInput();
cout<<"Number of rational number objects created:"<<RationalNumber::getObjectCount()<<endl;
RationalNumber resultMul = num1.multiply(num2);
RationalNumber resultDiv = num1.divide(num2);
cout<<"Multiplication result:"<<resultMul.getObjectCount()<<"/"<<RationalNumber::getObjectCount()<<endl;
cout<<"Division result:"<<resultDiv.getObjectCount()<<"/"<<RationalNumber::getObjectCount()<<endl;
    return 0;
}/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/