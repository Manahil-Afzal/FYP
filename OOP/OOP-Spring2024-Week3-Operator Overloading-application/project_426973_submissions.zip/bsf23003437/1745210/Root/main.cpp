/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational &other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    void setValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        while (denominator == 0) {
            cout << "Denominator cannot be zero. Enter again: ";
            cin >> denominator;
        }
    }

    void display() const {
        cout << "Numerator: " << numerator << ", Denominator: " << denominator << endl;
    }

    Rational operator*(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    static int getCount() {
        return count;
    }

    ~Rational() {
        count--;
    }
};

int Rational::count = 0;

int main() {
    Rational r1, r2;
    cout << "Enter values for first rational number:\n";
    r1.setValues();
    cout << "Enter values for second rational number:\n";
    r2.setValues();

    Rational multiplied = r1 * r2;
    Rational divided = r1 / r2;

    cout << "Multiplication result:\n";
    multiplied.display();
    cout << "Division result:\n";
    divided.display();

    cout << "Total number of rational numbers: " << Rational::getCount() << endl;

    return 0;
}
