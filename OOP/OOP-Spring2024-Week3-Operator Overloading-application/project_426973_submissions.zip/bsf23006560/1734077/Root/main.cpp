
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) {
        numerator = num;
        denominator = den;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero!" << endl;
            
        }
        count++;
    }

    Rational(const Rational& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    static int getCount() {
        return count;
    }

    void getInputs() {
        cout << "Enter the numerator: ";
        cin >> numerator;
        cout << "Enter the denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero!" << endl;
            
        }
    }

    Rational operator*(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2 = r1;
    Rational r3;

    r3.getInputs();

    Rational multiplication = r1 * r3;
    Rational division = r1 / r3;

    multiplication.display();
    division.display();

    cout << "Total Rational objects: " << Rational::getCount() << endl;

    return 0;
}