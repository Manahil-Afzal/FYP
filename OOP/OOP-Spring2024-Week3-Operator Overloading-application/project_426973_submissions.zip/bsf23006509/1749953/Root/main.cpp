/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;

class Rational{
    int Nom;
    int Denom;
    static int count;
    
public:
    
    Rational(int n, int d) : Nom(n), Denom(d) {
        count++;
    }
    
    
    Rational() : Nom(0), Denom(1) {
        count++;
    }
    
    void input(){
        cout<<"Enter Numerator: ";
        cin>>Nom;
        do {
            cout<<"Enter Denominator (Should be Greater than 0): ";
            cin>>Denom;
        } while (Denom <= 0);
    }  
    
    Rational operator*(const Rational& other) const {
        Rational res(Nom * other.Nom, Denom * other.Denom);
        return res;
    }
    
    Rational operator/(const Rational& other) const {
        Rational res(Nom * other.Denom, Denom * other.Nom);
        return res;
    }
    
    void output(){
        cout<<"Result Rational Number: "<<Nom<<"/"<<Denom<<endl;
    }
    
   
    static int getCount() {
        return count;
    }
};


int Rational::count = 0;

int main(){
    Rational r1;
    cout<<"Rational Number 1: ";
    r1.input();
    r1.output();
    
    Rational r2 = r1;
    cout<<"Rational Number 2: ";
    r2.input();
    r2.output();
    
	cout<<"\nNumber of Objects: "<<Rational::getCount()<<endl;
    
    Rational res_mult = r1 * r2;
    cout<<"\nMultiplication Result: ";
    res_mult.output();
    
    Rational res_div = r1 / r2;
    cout<<"Division Result: ";
    res_div.output();
    
    return 0;
}
