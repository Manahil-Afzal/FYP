/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
 #include<iostream>
using namespace std;
class rational{
	int nominator;
	int denominator;
	public:
		rational(int n=0,int d=0){
			nominator=n;
	       denominator=d;
		}
		rational operator *(rational mul){
			rational res;
			res.nominator=nominator*mul.nominator;
			res.denominator=denominator*mul.denominator;
			return res;
		}
		rational operator /(rational div){
			rational result;
				result.nominator=nominator/div.nominator;
			result.denominator=denominator/div .denominator;
				return result;
			
		}
		void show(){
			cout<<nominator<<"/"<<denominator<<"i"<<endl;
		}
};
int main(){
	rational d1(16,8),d2(4,4);
	rational d3=d1*d2;
	cout<<"The Nominator and denominator after the multiplication"<<endl;
	d3.show();
	rational d4=d1/d2;
	cout<<"The Nominator and denominator after the division"<<endl;
	d4.show();

	return 0;
}