/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class Rational
{
private:
    int numerator;
    int denominator;
    static int objcount;

public:
    Rational(int n = 0, int d = 1) 
    {
        if (denominator == 0)
        {
            cout << "Denominator cannot be zero" << endl;
            
        }
        objcount++; 
    }

    Rational(const Rational &r) 
    {
        objcount++; 
    }

    
    void input()
    {
        cout << "Enter Numerator: ";
        cin >> numerator;
        cout << "Enter Denominator: ";
        cin >> denominator;
        if (denominator == 0)
        {
            cout << "Denominator cannot be zero." << endl;
            
        }
    }

    
    Rational operator*( Rational &r)
    {
        Rational result;
        result.numerator = numerator * r.numerator;
        result.denominator = denominator * r.denominator;
        return result;
    }
    
    Rational operator/( Rational &r)
    {
        Rational result;
        result.numerator = numerator * r.denominator;
        result.denominator = denominator * r.numerator;
        return result;
    }
   
    void Display()
    {
        cout << "Rational Number: " << numerator << "/" << denominator << endl;
    }

    static int getCount()
    {
        return objcount;
    }
};

int Rational::objcount = 0;

int main()
{
    Rational Num1, Num2;
    cout << "Enter details for Num1:" << endl;
    Num1.input();
    cout << "Enter details for Num2:" << endl;
    Num2.input();

    Rational Num3 = Num1 * Num2; 
    Rational Num4 = Num1 / Num2; 

    
    cout << "Multiplication Result:" << endl;
    Num3.Display();
    cout << "Division Result:" << endl;
    Num4.Display();
    
    cout << "Total objects created: " << Rational::getCount() << endl;

    return 0;
}