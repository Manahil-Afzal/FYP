/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rational{
	float num;
	float den;
	public:
		static int no;
	rational(){
		no++;
	}
	rational(int x,int y){
		num=x;
		if(y!=0){
		den=y;}
		else {
		cout<<"denominator does not =0 so we set denominator is equal to 1"<<endl;
		den=1;}
	}
	rational(rational &obj){
		num=obj.num;
		den=obj.den;
	}
	void getdata(){
		cout<<"Enter the value of numerator and denominator"<<endl;
		cin>>num>>den;
		if(den==0){
		cout<<"denominator does not =0 so we set denominator is equal to 1"<<endl;
		den=1;
		}
	}
	void display(){
		cout<<"The numerator is"<<num<<"/"<<den<<endl;
	}
	rational operator * (rational &obj1){
		rational res;
		res.num=num*obj1.num;
		res.den=den*obj1.den;
        return res;	
	}
	rational operator / (rational &obj2){
		rational res1;
		res1.num=num*obj2.den;
		res1.den=den*obj2.num;
		return res1;
		}
};
int rational::no=0;
int main()
{
	rational r1(2,3);
	rational r2(r1);
	rational r3,r4,r5;
	r3.getdata();
    r4=r2*r3;
    cout<<"the value of n and d after multiplication"<<endl;
    r4.display();
    r5=r2/r3;
    cout<<"the value of n and d after division"<<endl;
    r5.display();
    cout<<"The total obj created is"<<rational::no<<endl;


 return 0;
}