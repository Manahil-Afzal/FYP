/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num = 1, int den = 1) {
        numerator = num;
        if (den != 0)
            denominator = den;
        else {
            cout << "Error: Denominator cannot be zero. Setting it to 1.\n";
            denominator = 1;
        }
        count++; // Increment count when object is created
    }

    // Copy constructor
    Rational(const Rational &obj) {
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++; // Increment count when object is created
    }

    // Method to take inputs of denominator and numerator from the user
    void getValues() {
        cout << "Enter the numerator: ";
        cin >> numerator;
        cout << "Enter the denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting it to 1.\n";
            denominator = 1;
        }
    }

    // Method to multiply two rational numbers
    Rational operator*(const Rational &obj) {
        Rational result;
        result.numerator = numerator * obj.numerator;
        result.denominator = denominator * obj.denominator;
        return result;
    }

    // Method to divide two rational numbers
    Rational operator/(const Rational &obj) {
        Rational result;
        result.numerator = numerator * obj.denominator;
        result.denominator = denominator * obj.numerator;
        return result;
    }

    // Static member function to get count of objects
    static int getCount() {
        return count;
    }

    // Method to display the rational number
    void display() {
        cout << numerator << "/" << denominator;
    }
};

int Rational::count = 0; // Initializing static member

int main() {
    Rational r1, r2;
    cout << "Enter values for first rational number:\n";
    r1.getValues();
    cout << "Enter values for second rational number:\n";
    r2 = r1; // Using copy constructor to initialize r2
    cout << "\nNumber of rational objects created: " << Rational::getCount() << endl;

    // Perform multiplication
    Rational result_mult = r1 * r2;
    cout << "Multiplication result: ";
    result_mult.display();
    cout << endl;

    // Perform division
    Rational result_div = r1 / r2;
    cout << "Division result: ";
    result_div.display();
    cout << endl;

    return 0;
}