/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int objectCount;

public:
    // Parameterized constructor
    Rational(int num, int den) {
        if (den == 0) {
            cout << "Denominator cannot be zero. Setting to 1 by default.\n";
            den = 1;
        }
        numerator = num;
        denominator = den;
        objectCount++;
    }

    // Copy constructor
    Rational(const Rational &obj) {
        numerator = obj.numerator;
        denominator = obj.denominator;
        objectCount++;
    }

    // Method to input rational number
    void input() {
        cout << "Enter Numerator: ";
        cin >> numerator;
        do {
            cout << "Enter Denominator (not 0): ";
            cin >> denominator;
            if (denominator == 0) {
                cout << "Error: Denominator cannot be zero!\n";
            }
        } while (denominator == 0);
        objectCount++;
    }

    // Operator overloading for multiplication
    Rational operator*(const Rational &r) const {
        return Rational(numerator * r.numerator, denominator * r.denominator);
    }

    // Operator overloading for division
    Rational operator/(const Rational &r) const {
        if (r.numerator == 0) {
            cout << "Error: Division by zero rational number!\n";
            return Rational(0, 1);  // default safe result
        }
        return Rational(numerator * r.denominator, denominator * r.numerator);
    }

    // Method to display rational number
    void display() const {
        cout << numerator << "/" << denominator << endl;
    }

    // Static method to show object count
    static void showObjectCount() {
        cout << "Total Rational objects created: " << objectCount << endl;
    }
};

// Initialize static member
int Rational::objectCount = 0;

int main() {
    Rational r1(2, 5);           // parameterized constructor
    Rational r2 = r1;            // copy constructor

    Rational r3(1, 1);           // temp object to receive input
    r3.input();                  // user-defined input

    Rational product = r1 * r3;
    Rational division = r1 / r3;

    cout << "\nRational 1: ";
    r1.display();

    cout << "Rational 3 (user input): ";
    r3.display();

    cout << "\nMultiplication (r1 * r3): ";
    product.display();

    cout << "Division (r1 / r3): ";
    division.display();

    Rational::showObjectCount();

    return 0;
}
