/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;
class Rational {
private:
    int numerator;
    int denominator;
    static int count; // static member to keep count of objects

public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    void inputValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    void display() const {
        cout << numerator << "/" << denominator;
    }

    Rational multiply(const Rational& other) const {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational divide(const Rational& other) const {
        if (other.numerator == 0) {
            cout << "Error: Division by zero. Returning default value." << endl;
            return Rational();
        }
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    static int getCount() {
        return count;
    }
};

int Rational::count = 0;

int main() {
    Rational obj1(3, 4);
    Rational obj2 = obj1;

    cout << "Objects count: " << Rational::getCount() << endl;

    Rational obj3;
    obj3.inputValues();

    cout << "Object 1: ";
    obj1.display();
    cout << endl;

    cout << "Object 2: ";
    obj2.display();
    cout << endl;

    cout << "Object 3: ";
    obj3.display();
    cout << endl;

    Rational result_multiply = obj1.multiply(obj2);
    Rational result_divide = obj1.divide(obj2);

    cout << "Multiplication Result: ";
    result_multiply.display();
    cout << endl;

    cout << "Division Result: ";
    result_divide.display();
    cout << endl;

    return 0;
}