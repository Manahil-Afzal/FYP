#include<iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count;  // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            std::cout << "Error: Denominator cannot be zero. Setting denominator to 1." << std::endl;
            denominator = 1;
        }
        count++;  // Increment the count of objects
    }

    // Copy constructor
    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;  // Increment the count of objects
    }

    // Method to take inputs from the user
    void getInputs() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;
        do {
            std::cout << "Enter denominator (non-zero): ";
            std::cin >> denominator;
            if (denominator == 0) {
                std::cout << "Error: Denominator cannot be zero. Please enter a non-zero value." << std::endl;
            }
        } while (denominator == 0);
    }

    // Method to display the rational number
    void display() const {
        std::cout << numerator << "/" << denominator;
    }

    // Method to perform multiplication
    Rational multiply(const Rational& other) const {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    // Method to perform division
    Rational divide(const Rational& other) const {
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    // Static method to get the count of objects
    static int getCount() {
        return count;
    }
};

// Initializing the static member
int Rational::count = 0;

int main() {
    Rational r1(2, 3);  // Parameterized constructor
    Rational r2 = r1;   // Copy constructor

    std::cout << "Number of rational objects: " << Rational::getCount() << std::endl;

    std::cout << "Enter details for a new rational number:\n";
    Rational r3;
    r3.getInputs();

    std::cout << "Multiplication: ";
    r1.display();
    std::cout << " * ";
    r3.display();
    std::cout << " = ";
    Rational resultMultiply = r1.multiply(r3);
    resultMultiply.display();
    std::cout << std::endl;

    std::cout << "Division: ";
    r1.display();
    std::cout << " / ";
    r3.display();
    std::cout << " = ";
    Rational resultDivide = r1.divide(r3);
    resultDivide.display();
    std::cout << std::endl;

    return 0;
}
