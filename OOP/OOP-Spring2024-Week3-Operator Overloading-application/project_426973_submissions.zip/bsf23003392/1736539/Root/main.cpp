/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int objectCount;

    // Private function to calculate the greatest common divisor
    int gcd(int a, int b) {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

public:
    RationalNumber(int num = 0, int denom = 1) {
        numerator = num;
        denominator = denom;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        objectCount++;
    }

    RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        objectCount++;
    }

    void input() {
        RationalNumber temp;
        cout << "Enter numerator: ";
        cin >> temp.numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> temp.denominator;
        if (temp.denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            temp.denominator = 1;
        }
        *this = temp;
    }

    void display() {
        cout << numerator << "/" << denominator;
    }

    RationalNumber operator*(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber& other) {
        RationalNumber result;

        if (other.numerator == 0) {
            cout << "Error: Cannot divide by zero. Setting result to 0/1." << endl;
            result.numerator = 0;
            result.denominator = 1;
        } else {
            result.numerator = numerator * other.denominator;
            result.denominator = denominator * other.numerator;
            
            // Simplify the result by dividing both numerator and denominator by their GCD
            int commonDivisor = gcd(result.numerator, result.denominator);
            result.numerator /= commonDivisor;
            result.denominator /= commonDivisor;
        }

        return result;
    }

    static int getObjectCount() {
        return objectCount;
    }
};

int RationalNumber::objectCount = 0;

int main() {
    RationalNumber r1(8, 4);
    RationalNumber r2(6, 3);

    RationalNumber product = r1 * r2;
    RationalNumber quotient = r1 / r2;

    cout << "Product: ";
    product.display();
    cout << endl;

    cout << "Quotient: ";
    quotient.display();
    cout << endl;

    cout << "Total number of RationalNumber objects created: " << RationalNumber::getObjectCount() << endl;

    return 0;
}
