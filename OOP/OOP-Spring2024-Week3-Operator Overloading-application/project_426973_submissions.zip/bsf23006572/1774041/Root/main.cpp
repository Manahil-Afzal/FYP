/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // static member to keep count of objects

public:
    // Constructor to initialize numerator and denominator
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
        count++; // increment count when object is created
    }

    // Copy constructor
    Rational(const Rational &other) : numerator(other.numerator), denominator(other.denominator) {
        count++; // increment count when object is copied
    }

    // Destructor
    ~Rational() {
        count--; // decrement count when object is destroyed
    }

    // Method to input numerator and denominator from user
    void input() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;
        std::cout << "Enter denominator: ";
        std::cin >> denominator;
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
    }

    // Method to perform multiplication
    Rational multiply(const Rational &other) const {
        Rational result(numerator * other.numerator, denominator * other.denominator);
        return result;
    }

    // Method to perform division
    Rational divide(const Rational &other) const {
        if (other.numerator == 0) {
            std::cerr << "Error: Division by zero.\n";
            return Rational(); // return default-constructed Rational object
        }
        Rational result(numerator * other.denominator, denominator * other.numerator);
        return result;
    }

    // Static method to get the count of objects
    static int getCount() {
        return count;
    }

    // Method to display the rational number
    void display() const {
        std::cout << numerator << "/" << denominator;
    }
};

// Initializing static member outside the class
int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2;
    
    r2.input();

    std::cout << "Multiplication result: ";
    Rational multResult = r1.multiply(r2);
    multResult.display();
    std::cout << std::endl;

    std::cout << "Division result: ";
    Rational divResult = r1.divide(r2);
    divResult.display();
    std::cout << std::endl;

    std::cout << "Total Rational objects created: " << Rational::getCount() << std::endl;

    return 0;
}
