/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/


#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int objectCount; // Static member to keep track of object count

public:
    // Parameterized constructor
    RationalNumber(int num, int denom) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        objectCount++; // Increment object count
    }

    // Copy constructor
    RationalNumber(const RationalNumber& other) : numerator(other.numerator), denominator(other.denominator) {
        objectCount++; // Increment object count
    }

    // Operator overloading for multiplication
    RationalNumber operator*(const RationalNumber& other) const {
        return RationalNumber(numerator * other.numerator, denominator * other.denominator);
    }

    // Operator overloading for division
    RationalNumber operator/(const RationalNumber& other) const {
        return RationalNumber(numerator * other.denominator, denominator * other.numerator);
    }

    // Display the rational number
    void display() const {
        cout << numerator << "/" << denominator << endl;
    }

    // Static method to get object count
    static int getObjectCount() {
        return objectCount;
    }
};

// Initialize static member
int RationalNumber::objectCount = 0;

int main() {
    RationalNumber num1(3, 4);
    RationalNumber num2(15, 7);

    // Perform multiplication
    RationalNumber product = num1 * num2;
    cout << "Multiplication result: ";
    product.display();

    // Perform division
    RationalNumber quotient = num1 / num2;
    cout << "Division result: ";
    quotient.display();

    // Display total object count
    cout << "Total objects created: " << RationalNumber::getObjectCount() << endl;

    return 0;
}