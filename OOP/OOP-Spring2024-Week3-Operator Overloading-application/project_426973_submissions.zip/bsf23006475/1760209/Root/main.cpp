/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
#include<limits.h>
using namespace std;
int gcd(int a,int b) {
	if(b==0)
		return a;
	gcd(b,a%b);
}
class Rational {
	private:
		int numerator;
		int denominator;
	public:
		static int objCount;
		Rational(int x) { //For temps
			cout<<"Extra";
		}
		Rational(){ //Default
			objCount++;
		}
		Rational(int nume,int deno) { //Parametrized
			numerator=nume;
			while(deno==0) {
				cout<<"Denominator can't be \"Zero\". Please Enter Valid Value: "<<endl;
				cin>>deno;
			}
			denominator=deno;
			objCount++;
		}

		Rational(const Rational &other) { //Copy
			cout<<"Copy"<<endl;
			numerator=other.numerator;
			denominator=other.denominator;
			objCount++;
		}
		void setData(int nume,int deno) {
			numerator=nume;
			while(deno==0 or !(deno<INT_MAX) or !(deno>INT_MIN)) {
				cout<<"Denominator can't be \"Zero\". Please Enter Valid Value: "<<endl;
				cin>>deno;
			}
			denominator=deno;
			return;
		}
		Rational operator*(const Rational &other) {
			Rational temp(-1);
			temp.numerator=numerator*other.numerator;
			temp.denominator=denominator*other.denominator;
			int g=gcd(temp.numerator,temp.denominator);
			temp.numerator/=g;
			temp.denominator/=g;
			return temp;
		}
		Rational operator/(const Rational &other) {
			Rational temp(-1);
			temp.numerator=numerator*other.denominator;
			temp.denominator=denominator*other.numerator;
			int g=gcd(temp.numerator,temp.denominator);
			temp.numerator/=g;
			temp.denominator/=g;
			return temp;
		}
		void disp() {
			cout<<numerator<<" / "<<denominator<<endl;
		}
};
int Rational::objCount=0;
int main() {
	Rational R1,R2;
	R2.setData(4,9);
	Rational R3=R2;
	Rational res;
	res=R1/R2;
	cout<<"Result of Division is : ";
	res.disp();
	cout<<"Total Object Count is : ";
	cout<<Rational::objCount;
}