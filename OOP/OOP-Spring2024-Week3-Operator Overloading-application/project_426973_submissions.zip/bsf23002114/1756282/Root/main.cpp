/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // static member to keep count of objects

public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    ~Rational() {
        count--;
    }

    void setValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    static int getCount() {
        return count;
    }

    Rational operator*(const Rational& other) const {
        Rational result;
        result.numerator = this->numerator * other.numerator;
        result.denominator = this->denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational& other) const {
        Rational result;
        result.numerator = this->numerator * other.denominator;
        result.denominator = this->denominator * other.numerator;
        return result;
    }

    void display() const {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4); // Example initialization using parameterized constructor
    Rational r2;
    r2.setValues(); // Take input from user for second rational number

    cout << "Objects count: " << Rational::getCount() << endl;

    Rational multiplicationResult = r1 * r2;
    cout << "Multiplication: ";
    multiplicationResult.display();

    Rational divisionResult = r1 / r2;
    cout << "Division: ";
    divisionResult.display();

    return 0;
}
