/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class myclass {
private:
    int num;
    int den;
    int rationalNumber;

public:
    static int objectCount;
    myclass(int a, int b);
    myclass(const myclass &obj); 
    myclass();
    myclass operator*(const myclass &obj);
    myclass operator/(const myclass &obj); 
    void getdata()
    {
    	cout<<rationalNumber<<endl;
	}
};


int myclass::objectCount = 0;

myclass::myclass(int a, int b) {
    num = a;
    den = b;
    objectCount++;
    rationalNumber = num / den;
}

myclass::myclass(const myclass &obj) {
    num = obj.num;
    den = obj.den;
    objectCount++;
    rationalNumber = obj.rationalNumber;
}

myclass::myclass() {
    num = 0;
    den = 0;
    rationalNumber = 0;
    objectCount++;
}

myclass myclass::operator*(const myclass &obj) { 
    myclass rev1;
    rev1.rationalNumber = rationalNumber * obj.rationalNumber;
    return rev1;
}

myclass myclass::operator/(const myclass &obj) { 
    myclass rev2;
    rev2.rationalNumber = rationalNumber / obj.rationalNumber;
    return rev2;
}

int main() {
    myclass obj1(20, 10);
    myclass obj2 = obj1;
    myclass obj3 = obj1 * obj2;
    myclass obj4 = obj1 / obj2;
    obj3.getdata();
    obj4.getdata();
    cout<<myclass::objectCount;
    
}