/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects
    
public:
    // Parameterized constructor
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++; // Increment count of objects
    }

    // Copy constructor
    Rational(const Rational &obj) : numerator(obj.numerator), denominator(obj.denominator) {
        count++; // Increment count of objects
    }

    // Destructor
    ~Rational() {
        count--; // Decrement count of objects
    }

    // Method to input numerator and denominator from user
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Method to perform multiplication
    Rational operator*(const Rational &obj) const {
        Rational result;
        result.numerator = numerator * obj.numerator;
        result.denominator = denominator * obj.denominator;
        return result;
    }

    // Method to perform division
    Rational operator/(const Rational &obj) const {
        Rational result;
        result.numerator = numerator * obj.denominator;
        result.denominator = denominator * obj.numerator;
        return result;
    }

    // Method to display the rational number
    void display() const {
        cout << numerator << "/" << denominator;
    }

    // Static method to get count of objects
    static int getCount() {
        return count;
    }
};

int Rational::count = 0; // Initializing static member count

int main() {
    Rational r1(3, 4); // Creating object using parameterized constructor
    Rational r2(r1); // Creating object using copy constructor
    Rational r3, r4; // Creating objects to input values

    r3.input(); // Input values for r3
    r4.input(); // Input values for r4

    Rational result_mult = r1 * r2;
    Rational result_div = r3 / r4;

    cout << "Multiplication Result: ";
    result_mult.display();
    cout << endl;

    cout << "Division Result: ";
    result_div.display();
    cout << endl;

    cout << "Total Rational objects created: " << Rational::getCount() << endl;

    return 0;
}
