/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;
public:
    Rational(int nume = 0, int deno = 1) {
        numerator = nume;
        denominator = deno;
        if (denominator == 0) {
            cout << "Error! Denominator can't be zero !! Setting it to 1" << endl;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational &other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }
    
    void input() {
        cout << "Enter numerator : ";
        cin >> numerator;
        cout << "Enter denominator : ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error! Denominator can't be zero !! Setting it to 1" << endl;
            denominator = 1;
        }
    }

    void display() {
        cout << numerator << "/" << denominator;
    }

    Rational operator * (const Rational &other) {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational operator / (const Rational &other) {
        if (other.numerator == 0) {
            cout << "Error! Division by zero." << endl;
            return Rational();
        }
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    static int getcount() {
        return count;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(10, 5);
    Rational r2 = r1;
    cout << "Enter values for first rational number  " << endl;
    r1.input();
    cout << "Enter values for second rational number  " << endl;
    r2.input();
    cout << "Multiplication of rational numbers  ";
    Rational mul_res = r1 * r2;
    mul_res.display();
    cout << endl << "Division of rational numbers  ";
    Rational div_res = r1 / r2;
    div_res.display();
    cout << endl << "Total number of objects created  =  " << Rational::getcount();
    return 0;
}
