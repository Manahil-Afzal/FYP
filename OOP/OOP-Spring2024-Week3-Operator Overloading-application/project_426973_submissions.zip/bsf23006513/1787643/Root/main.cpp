#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational &other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    ~Rational() {
        count--;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    void display() const {
        cout << numerator << "/" << denominator;
    }

    static int getCount() {
        return count;
    }

    Rational operator*(const Rational &other) const {
        Rational result(numerator * other.numerator, denominator * other.denominator);
        return result;
    }

    Rational operator/(const Rational &other) const {
        Rational result(numerator * other.denominator, denominator * other.numerator);
        return result;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(2, 3);
    Rational r2(r1);

    cout << Rational::getCount() << endl;

    r1.display();
    cout << " and ";
    r2.display();
    cout << endl;

    Rational result_mul = r1 * r2;
    Rational result_div = r1 / r2;

    result_mul.display();
    cout << endl;

    result_div.display();
    cout << endl;

    return 0;
}
