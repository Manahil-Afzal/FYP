/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count; 

public:
    
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
        count++; 
    }

    
    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++; 
    }

    
    void input() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;
        std::cout << "Enter denominator (cannot be zero): ";
        std::cin >> denominator;
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
    }

    
    static int getCount() {
        return count;
    }

    
    Rational operator*(const Rational& other) const {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    
    Rational operator/(const Rational& other) const {
        if (other.numerator == 0) {
            std::cerr << "Error: Division by zero is not allowed.\n";
            return Rational(); 
        }
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    
    void display() const {
        std::cout << numerator << "/" << denominator << std::endl;
    }

};

int Rational::count = 0;

int main() {
    Rational r1(2, 3); 
    Rational r2 = r1; 

    std::cout << "Total rational numbers: " << Rational::getCount() << std::endl;

    
    std::cout << "Multiplication: ";
    Rational result_mult = r1 * r2;
    result_mult.display();

    
    std::cout << "Division: ";
    Rational result_div = r1 / r2;
    result_div.display();

    return 0;
}
