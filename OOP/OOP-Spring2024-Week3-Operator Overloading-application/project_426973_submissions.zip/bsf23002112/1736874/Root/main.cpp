/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class Rational{
	private:
		int num;
		int den;
	public:
		static int count;
		
	
		Rational(int n=0, int d=0){
			num=n;
			den=d;
			count++;
		}
		Rational(Rational &r){
			num=r.num;
			den=r.den;
			count++;
		}
		
		void setternum(int n){
		    num=n;
		}
		void setterden(int d){
		    den=d;
		}
		void operator*(Rational &r){
			num=num*r.num;
			den=den*r.den;
		}
		
		void operator/(Rational &r){
			num=num*r.den;
			den=den*r.num;
		}
		void display(){
			cout<<"The number of objects created: "<<count<<endl;
			cout<<"The result after operation: "<<num<<"/"<<den<<endl;
		}
	
};

int Rational::count=0;
int main(){
Rational r1(5,7);
Rational r2=r1;
	int n,d;
	cout<<"Enter First Numerator: ";
	cin>>n;
	
	cout<<"Enter First Denominator: ";
	cin>>d;
	if(d==0){
		cout<<"You have entered the denominator as a zero the program is going to terminate."<<endl;
		return 0;
	}
	r1.setternum(n);
	r1.setterden(d);
	cout<<"Enter Second Numerator: ";
	cin>>n;
	cout<<"Enter Second denominator: ";
    cin>>d;
    if(d==0){
        cout<<"You have entered the denominator as a zero the program will terminate."<<endl;
        return 0;
    }
    r2.setternum(n);
    r2.setterden(d);
    
cout<<"Enter Operator(* or /): ";
char oper;
cin>>oper;
if(oper=='*'){
	r1*r2;
}
else if(oper=='/'){
	r1/r2;
}
else{
	cout<<"You didnot enter a valid operation the program is going to terminate.";
	return 0;
}
r1.display();
	
	
	
	
	return 0;
}