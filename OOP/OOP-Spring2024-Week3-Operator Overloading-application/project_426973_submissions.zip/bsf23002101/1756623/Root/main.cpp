#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; 

public:
    
    Rational(int num, int den) {
        numerator = num;
        denominator = den;
        count++;
    }
    Rational(const Rational &obj) {
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        do {
            cout << "Enter denominator (non-zero): ";
            cin >> denominator;
        } while (denominator == 0);
    }

    Rational operator*(const Rational &obj) {
        Rational result(0, 1);
        result.numerator = numerator * obj.numerator;
        result.denominator = denominator * obj.denominator;
        return result;
    }
    Rational operator/(const Rational &obj) {
        Rational result(0, 1);
        result.numerator = numerator * obj.denominator;
        result.denominator = denominator * obj.numerator;
        return result;
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
    static int getCount() {
        return count;
    }
};
int Rational::count = 0;

int main() {
    Rational num1(2, 3); 
    Rational num2 = num1;
    num2.input(); 
    Rational result_mult = num1 * num2;
    Rational result_div = num1 / num2;
    cout << "Multiplication: ";
    result_mult.display();
    cout << "Division: ";
    result_div.display();
    cout << "Total Rational objects: " << Rational::getCount() << endl;

    return 0;
}