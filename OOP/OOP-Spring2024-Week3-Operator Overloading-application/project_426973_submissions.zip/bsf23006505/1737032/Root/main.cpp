/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class RationalNumber{
	private:
	int numerator;
	int denominator;
	static int count;
	public:
		RationalNumber(int num=0,int denom=1){
			numerator=num;
			if(denom!=0)
			denominator=denom;
			else{
				cerr<<"Denominator cannot be zero. Setting denominator to 1." <<endl;
            denominator = 1;
			}
			count++;
		}
		RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
};void input() {
cout << "Enter numerator: ";
cin >> numerator;
cout << "Enter denominator:";
cin >> denominator;
        if (denominator == 0) {
 cerr<<"Denominator cannot be zero. Setting denominator to 1." <<endl;
            denominator = 1;
        }
    }
    void display() {
cout << numerator << "/" << denominator <<endl;
    }
    RationalNumber operator*(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }
    RationalNumber operator/(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
}
    static int getCount() {
        return count;
    }
};
int RationalNumber::count = 0;

int main() {
    RationalNumber num1(3, 4);
    RationalNumber num2(num1);
    RationalNumber num3;

    num3.input();

    cout << "Multiplication: ";
    RationalNumber product = num1 * num2;
    product.display();

    cout << "Division: ";
    RationalNumber division = num1 / num3;
    division.display();

    cout << "Total RationalNumber objects created: " << RationalNumber::getCount()<<endl;

    return 0;
}
