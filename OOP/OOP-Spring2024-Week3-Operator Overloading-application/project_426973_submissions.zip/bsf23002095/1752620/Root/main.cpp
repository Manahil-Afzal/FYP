/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;
class RationalNumber {
public:
    int numerator, denominator;
    static int objectCount;
    RationalNumber(int num = 0, int den = 1) {
        if (den == 0) {
            cout << "Error: Division by zero is not allowed.\n";
        }
        numerator = num;
        denominator = den;
        objectCount++;
    }
    RationalNumber(const RationalNumber& r) {
        numerator = r.numerator;
        denominator = r.denominator;
        objectCount++;
    }
    void getInput() {
        cout << "Enter the numerator: ";
        cin >> numerator;
        cout << "Enter the denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Division by zero is not allowed.\n";
        }
    }
    RationalNumber operator*(const RationalNumber& r) const {
        int num = numerator * r.numerator;
        int den = denominator * r.denominator;
        return RationalNumber(num, den);
    }
    RationalNumber operator/(const RationalNumber& r) const {
        int num = numerator * r.denominator;
        int den = denominator * r.numerator;
        return RationalNumber(num, den);
    }
    void display() const {
        cout << "Rational number: " << numerator << "/" << denominator << "\n";
    }
};
int RationalNumber::objectCount = 0;
int main() {
    RationalNumber r1(3, 4), r2(5, 6);
    r1.display();
    r2.display();
    RationalNumber r3 = r1 * r2;
    r3.display();
    RationalNumber r4 = r1 / r2;
    r4.display();
    RationalNumber r5;
    cout << "Enter the numerator and denominator for the third rational number: ";
    r5.getInput();
    r5.display();
    cout << "Total number of objects: " << RationalNumber::objectCount << "\n";
    return 0;
}