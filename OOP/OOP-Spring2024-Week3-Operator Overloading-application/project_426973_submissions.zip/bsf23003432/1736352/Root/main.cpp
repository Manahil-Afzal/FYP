/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class Rational {
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1);
    Rational(const Rational& other);
    void inputValues();
    void displayResult();

    Rational operator*(const Rational& other);
    Rational operator/(const Rational& other);

    static int getCount() {
        return count;
    }
};

int Rational::count = 0;

Rational::Rational(int num, int den) {
    numerator = num;
    denominator = (den != 0) ? den : 1;
    count++;
}

Rational::Rational(const Rational& other) {
    numerator = other.numerator;
    denominator = other.denominator;
    count++;
}

void Rational::inputValues() {
    cout << "Enter Numerator: ";
    cin >> numerator;

    do {
        cout << "Enter Denominator (should not be zero): ";
        cin >> denominator;
    } while (denominator == 0);
}

void Rational::displayResult() {
    cout << "Result: " << numerator << "/" << denominator << endl;
}

Rational Rational::operator*(const Rational& other) {
    Rational result;
    result.numerator = numerator * other.numerator;
    result.denominator = denominator * other.denominator;
    return result;
}

Rational Rational::operator/(const Rational& other) {
    Rational result;
    result.numerator = numerator * other.denominator;
    result.denominator = denominator * other.numerator;
    return result;
}

int main() {
    using namespace std;

    Rational num1, num2, resultMultiply, resultDivide;

    cout << "Enter values for the first rational number:\n";
    num1.inputValues();

    cout << "\nEnter values for the second rational number (copy constructor will be used):\n";
    Rational num3 = num1;  // Copy constructor is called here

    cout << "\nEnter values for the third rational number:\n";
    num2.inputValues();

    resultMultiply = num1 * num2;
    resultDivide = num1 / num2;

    cout << "\nMultiplication:\n";
    resultMultiply.displayResult();

    cout << "\nDivision:\n";
    resultDivide.displayResult();

    cout << "\nTotal count of rational numbers: " << Rational::getCount() << endl;

    return 0;
}
