/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    Rational(int num = 1, int denom = 1) {
        if (denom == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        } else {
            numerator = num;
            denominator = denom;
        }
        count++;
    }

    Rational(const Rational &r) {
        numerator = r.numerator;
        denominator = r.denominator;
        count++;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    Rational operator*(const Rational &r) {
        Rational result;
        result.numerator = numerator * r.numerator;
        result.denominator = denominator * r.denominator;
        return result;
    }

    Rational operator/(const Rational &r) {
        Rational result;
        result.numerator = numerator * r.denominator;
        result.denominator = denominator * r.numerator;
        return result;
    }

    static int getCount() {
        return count;
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r1, r2;
    cout << "Enter details for the first rational number:" << endl;
    r1.input();

    cout << "Enter details for the second rational number (copying from the first one):" << endl;
    r2 = r1;

    cout << "Multiplication:" << endl;
    Rational result_mult = r1 * r2;
    result_mult.display();

    cout << "Division:" << endl;
    Rational result_div = r1 / r2;
    result_div.display();

    cout << "Total objects created: " << Rational::getCount() << endl;

    return 0;
}
