/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count; 

public:

    RationalNumber(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++; 
    }

    // Copy constructor
    RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }


    ~RationalNumber() {
        count--;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }


    void display() const {
        cout << numerator << "/" << denominator;
    }

    static int getCount() {
        return count;
    }


    RationalNumber operator*(const RationalNumber& other) const {
        RationalNumber result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }


    RationalNumber operator/(const RationalNumber& other) const {
        RationalNumber result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1(3, 4);
    RationalNumber num2;
    num2.input();

    cout << "Number of rational number objects: " << RationalNumber::getCount() << endl;

    
    RationalNumber mul_result = num1 * num2;
    cout << "Multiplication: ";
    mul_result.display();
    cout << endl;

    
    RationalNumber div_result = num1 / num2;
    cout << "Division: ";
    div_result.display();
    cout << endl;

    return 0;
}
