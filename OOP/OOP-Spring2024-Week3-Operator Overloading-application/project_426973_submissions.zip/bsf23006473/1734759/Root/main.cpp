#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;

public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            denominator = 1; 
        }
    }

    Rational(const Rational &other) : numerator(other.numerator), denominator(other.denominator) {}

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            denominator = 1; 
        }
    }

    void display() const {
        cout << numerator << "/" << denominator;
    }

    Rational operator*(const Rational &other) const {
        Rational result; // Initialize with default constructor
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational &other) const {
        Rational result; // Initialize with default constructor
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }
};

int main() {
    Rational r1;

    cout << "Enter details for rational number r1:" << endl;
    r1.input();

 
    cout << "r1 = ";
    r1.display();
    cout << endl;

   

    return 0;
}

/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/