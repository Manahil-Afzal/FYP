/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            cout<<"Error: Denominator cannot be zero. Setting denominator to 1.\n"; 
            denominator = 1;
        }
        count++; 
    }
 
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout<< "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
    }

    
    static int getCount() {
        return count;
    }


    Rational operator*(Rational &other) {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational operator/( Rational &other) {
        return Rational(numerator / other.denominator, denominator / other.numerator);
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator <<endl;
    }
};
int Rational::count = 0;

int main() {
    Rational r1, r2;
    r1.input();
    r2 = r1; 
    cout<< "Total Rational objects: " << Rational::getCount() <<endl;

    Rational result_mul = r1 * r2;
    cout << "Multiplication: ";
    result_mul.display();

    Rational result_div = r1 / r2;
    cout << "Division: ";
    result_div.display();
}