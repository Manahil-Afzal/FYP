#include <iostream>
using namespace std;

class Rational {
    int numerator, denominator;

public:
    static int objcount;
    Rational(int num, int den);
    Rational(const Rational &obj);
    Rational();
    void getValue();
    void operator*(const Rational &obj);
    void operator/(const Rational &obj);
    void Display();
    int gcd(int a, int b);
};

Rational::Rational(int num, int den) {
    numerator = num;
    while (den == 0) {
        cout << "Denominator cannot be zero. Please enter a valid denominator: ";
        cin >> den;
    }
    denominator = den;
    objcount++;
}

Rational::Rational(const Rational &obj) {
    numerator = obj.numerator;
    denominator = obj.denominator;
    objcount++;
}

Rational::Rational() {
    objcount++;
    numerator = denominator = 1;
}

void Rational::getValue() {
    cin >> numerator >> denominator;
    while (denominator == 0) {
        cout << "Denominator cannot be zero. Please enter a valid denominator: ";
        cin >> denominator;
    }
}

void Rational::operator*(const Rational &obj) {
    numerator *= obj.numerator;
    denominator *= obj.denominator;
    int common_divisor = gcd(numerator, denominator);
    numerator /= common_divisor;
    denominator /= common_divisor;
}

void Rational::operator/(const Rational &obj) {
    numerator *= obj.denominator;
    denominator *= obj.numerator;
    int common_divisor = gcd(numerator, denominator);
    numerator /= common_divisor;
    denominator /= common_divisor;
}

void Rational::Display() {
    cout << numerator << "/" << denominator << endl;
}

int Rational::objcount = 0;

int Rational::gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main() {
    Rational r1(4, 7), r3;
    Rational r2 = r1;
    r2 * r1;
    cout << "Result of Multiplication is: ";
    r2.Display();
    Rational r4(4, 5);
    r3.getValue();
    r3 / r4;
    cout << "Result of Division is: ";
    r3.Display();
    cout << "There are " << Rational::objcount << " objects created";
    return 0;
}
