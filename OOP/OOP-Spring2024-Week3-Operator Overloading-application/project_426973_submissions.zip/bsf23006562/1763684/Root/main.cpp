/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero*/
#include<iostream>
using namespace std;
class relational{
    private:
        int denominator;
        int numerator;
        static int count;
    public:
        relational(int d,int n){
            if(d !=0){
            denominator = d;}
            else 
            {
                cout<<"Error: Denominator cannot be zero. Setting to 1." << endl;
                denominator =1;
            }
            numerator=n;
            count++;
        }
    relational(const relational& r){
        denominator=r.denominator;
        numerator = r.numerator;
        count++;
    }
    void getdata(){
        cout<<"enter the denominator"<<endl;
        cin>>denominator;
        if(denominator ==0){
            denominator =1;
        }
        cout<<"enter the numerator"<<endl;
        cin>>numerator;
    }
    void display(){
        cout<<numerator<<"/"<<denominator;
    }
    relational operator *(const relational& r){
        relational result(numerator*r.numerator,denominator*r.denominator);
        return result;
    }
     relational operator /(const relational& r){
        relational result(numerator*r.denominator,denominator*r.numerator);
        return result;
    }
    static int objectcount(){
    return count;
    }
};
int relational :: count =0;
int main()
{
    relational r1(3,4);
    relational r2=r1;
    relational r3 (1,2);
    cout<<"count of an object :"<<relational :: objectcount()<<endl;
    cout<<"multiplication";
    relational mult=r1*r3;
    mult.display();
    cout<<endl;
    cout<<"division";
    relational div=r1/r3;
    div.display();
    cout<<endl;
    return 0;
}