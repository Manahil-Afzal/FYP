/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rationalnumber{
	private:
		int nomi;
		int denomi;
		static int count;
	public:
	rationalnumber():nomi(0),denomi(0){
	count++;	
	}
	rationalnumber(rationalnumber &obj1){
		nomi=obj1.nomi;
		denomi=obj1.denomi;
	}
	void input(){
		cout<<"Enter Nminator:  ";
		cin>>nomi;
		cout<<"Enter De-Nominator: ";
		cin>>denomi;
	}
	void operator/(rationalnumber &obj){
		rationalnumber res;
		res.nomi=nomi*obj.denomi;
		res.denomi=denomi*obj.nomi;
		cout<<res.nomi<<"/"<<res.denomi<<endl;
	}
	void operator*(rationalnumber &obj){
		rationalnumber res;
		res.nomi=nomi*obj.nomi;
		res.denomi=denomi*obj.denomi;
		cout<<res.nomi<<"/"<<res.denomi<<endl;
	}
	void show(){
	cout<<nomi<<"/"<<denomi<<endl;
	}
	static int countre(){
		return count;
	}
};
int rationalnumber::count=0;
int main(){
	rationalnumber r1;
	r1.input();
	rationalnumber r2(r1);
	cout<<"product: "<<endl;
	r1*r2;
    cout<<"\nDivision: "<<endl;
    r1/r2;
    cout<<"You have created  "<<r1.countre();cout<<" objects"<<endl;
	
}