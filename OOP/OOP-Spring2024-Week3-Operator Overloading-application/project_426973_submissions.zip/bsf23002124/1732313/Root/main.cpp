#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int objectCount; // Static member to keep track of object count

public:
    // Parameterized constructor
    RationalNumber(int num, int denom) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        objectCount++; // Increment object count
    }

    // Copy constructor
    RationalNumber(const RationalNumber& other) : numerator(other.numerator), denominator(other.denominator) {
        objectCount++; // Increment object count
    }

    // Operator overloading for multiplication
    RationalNumber operator*(const RationalNumber& other) const {
        return RationalNumber(numerator * other.numerator, denominator * other.denominator);
    }

    // Operator overloading for division
    RationalNumber operator/(const RationalNumber& other) const {
        return RationalNumber(numerator * other.denominator, denominator * other.numerator);
    }

    // Display the rational number
    void display() const {
        cout << numerator << "/" << denominator << endl;
    }

    // Static method to get object count
    static int getObjectCount() {
        return objectCount;
    }
};

// Initialize static member
int RationalNumber::objectCount = 0;

int main() {
    RationalNumber num1(3, 4);
    RationalNumber num2(15, 7);

    // Perform multiplication
    RationalNumber product = num1 * num2;
    cout << "Multiplication result: ";
    product.display();

    // Perform division
    RationalNumber quotient = num1 / num2;
    cout << "Division result: ";
    quotient.display();

    // Display total object count
    cout << "Total objects created: " << RationalNumber::getObjectCount() << endl;

    return 0;
}
