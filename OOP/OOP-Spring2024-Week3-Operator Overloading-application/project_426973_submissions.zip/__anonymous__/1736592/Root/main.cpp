/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rationalNumber{
		private:
	int numerator;
	int denominator;
//	static int count;
		public:
				static int count;
			rationalNumber(){
				numerator=0;  denominator=1;
				count++;
			}
			rationalNumber(int nom,int den){
				numerator=nom;
				denominator=den;
				count++;
			}
			rationalNumber(const rationalNumber &R1){
			numerator=R1.numerator;
			denominator=R1.denominator;	
			count++;
			}
			int getX(){
			return numerator;
			}
				int getY(){
			return denominator;
			}
			void getData(){
				cout<<"Enter numerator:" <<endl;
				cin>>numerator;
					cout<<"Enter denominator:"<<endl;
				cin>>denominator;
			}
			int operator * (const rationalNumber &R1){
				int result1;
				result1=numerator*R1.numerator;
				return result1;
			}
					int operator / (const rationalNumber &R1){
				int result2;
				result2=numerator/R1.numerator;
				return result2;
			}
			void displayResult(){
				cout<<"Product is : "<< (numerator*denominator) <<endl;
				cout<<"Quotient is : "<< (numerator/denominator)<<endl;
			}	
			static int getCount(){
				 return count;
			}
};
int rationalNumber :: count=0;
int main(){
	rationalNumber R1(5,8);
	rationalNumber R2=R1;
	R1.getData();
		R2.getData();
	R1.displayResult();
	R2.displayResult();
	cout<<"Total objects are : "<<rationalNumber::count<<endl;
	return 0;
}