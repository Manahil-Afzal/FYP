/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class rat {
    int num;
    int den;
    static int counter;

public:
    rat() { 
        cout << "Default constructor" << endl;
    }

    rat(int x, int y) { 
        num = x;
        if (y != 0) {
            den = y;
        } else {
            cout << "Error Denominator cannot be zero, Setting denominator to 1." << endl;
            den = 1;
        }
        counter++;
    }

    rat(const rat &a) { 
        num = a.num;
        den = a.den;
        counter++;
    }

    rat operator*(const rat &r) const { 
        rat res;
        res.num = num * r.num;
        res.den = den * r.den;
        return res;
    }

    rat operator/(const rat &r) const { 
        rat res;
        res.num = num * r.den;
        res.den = den * r.num;
        return res;
    }

    void getdata() {
        cout << "Enter a numerator: ";
        cin >> num;
        cout << "Enter a denominator: ";
        cin >> den;
        if (den == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            den = 1;
        }
    }

    void dis() const {
        cout << num << "/" << den << endl;
    }

    static int getcount() {
        return counter;
    }
};

int rat::counter = 0;

int main() {
    rat r(3, 4);
    rat r1;
    r1.getdata();
    rat r2 = r * r1;
    rat r3 = r / r1;
    r2.dis();
    r3.dis();
    cout << "Number of rational objects created: " << rat::getcount() << endl;
    return 0;
}
