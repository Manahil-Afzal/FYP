/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
#include <string>
using namespace std;
class RationalNumber {
private:
 int numerator;
 int denominator;
 static int count; // Static member to keep count of objects
public:
 // Parameterized constructor
 RationalNumber(int num, int den) : numerator(num), denominator(den) {
 if (denominator == 0) {
 cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
 denominator = 1;
 }
 count++; // Increment count when object is created
 }
 // Default constructor
 RationalNumber() : RationalNumber(1, 1) {} // Delegates to parameterized constructor with default values
 // Copy constructor
 RationalNumber(const RationalNumber &obj) {
 numerator = obj.numerator;
 denominator = obj.denominator;
 count++; // Increment count when object is created
 }
 // Method to take inputs from user
 void getInput() {
 do {
 cout << "Enter numerator: ";
 cin >> numerator;
 cout << "Enter denominator (should not be zero): ";
 cin >> denominator;
 if (denominator == 0)
 cout << "Error: Denominator cannot be zero. Please try again." << endl;
 } while (denominator == 0);
 }
 // Method to perform multiplication
 RationalNumber operator*(const RationalNumber &obj) {
 RationalNumber result(numerator * obj.numerator, denominator * obj.denominator);
 return result;
 }
 // Method to perform division
 RationalNumber operator/(const RationalNumber &obj) {
 RationalNumber result(numerator * obj.denominator, denominator * obj.numerator);
 return result;
 }
 // Static method to display count of objects
 static void displayCount() {
 cout << "Total RationalNumber objects created: " << count << endl;
 }
 // Method to display the rational number
 void display() {
 cout << "Numerator: " << numerator << ", Denominator: " << denominator << endl;
 }
};
int RationalNumber::count = 0; // Initializing static member outside the class
int main() {
 RationalNumber::displayCount(); // Initially, no objects created
 RationalNumber num1(3, 4);
 RationalNumber num2(num1); // Creating object using copy constructor
 RationalNumber::displayCount(); // Two objects created
 cout << "Enter details for a new Rational Number:\n";
 RationalNumber num3;
 num3.getInput();
 // Perform multiplication and division
 RationalNumber result_mult = num1 * num3;
 cout << "Multiplication Result:\n";
 result_mult.display();
 RationalNumber result_div = num1 / num3;
 cout << "Division Result:\n";
 result_div.display();
 return 0;
}
