/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int num;
    int den;
    static int count;

public:
    Rational(int n = 0, int d = 1) : num(n), den(d) {
        count++;
    }

    Rational(const Rational& r) : num(r.num), den(r.den) {
        count++;
    }

    Rational& operator=(const Rational& r) {
        if (this != &r) {
            num = r.num;
            den = r.den;
        }
        return *this;
    }

    Rational operator*(const Rational& r) {
        return Rational(num * r.num, den * r.den);
    }

    Rational operator/(const Rational& r) {
        return Rational(num * r.den, den * r.num);
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> num;
        cout << "Enter denominator: ";
        cin >> den;
        if (den == 0) {
            cerr << "Error: Denominator cannot be zero." << endl;
            
        }
    }

    void display() {
        cout << num << "/" << den << " ";
    }

    static int getCount() {
        return count;
    }

    ~Rational() {
        count--;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2(5, 6);

    cout << "r1 = ";
    r1.display();

    cout << "r2 = ";
    r2.display();

    Rational r3 = r1 * r2;
    cout << "r1 * r2 = ";
    r3.display();

    Rational r4 = r1 / r2;
    cout << "r1 / r2 = ";
    r4.display();

    cout << "Number of Rational objects created: " << Rational::getCount() << endl;

    return 0;
}