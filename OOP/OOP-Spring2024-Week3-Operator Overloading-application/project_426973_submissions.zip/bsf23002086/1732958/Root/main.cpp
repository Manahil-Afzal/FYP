/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;
class Rational{
	private:
		int numerator;
		int denominator;
		static int count;
	public:
		Rational(int num=0,int den=1) : numerator(num), denominator(den)
{
		  if(den==0){
		  	cout<<" Denominator can not be zero.Set den to 1."<<endl;
		  	denominator=1;
		  }
		count++;  
		}
	Rational(const Rational& r){
		numerator=r.numerator;
		denominator=r.denominator;
		count++;	
	}
	~Rational() {
        count--;
    }
    void getInput(){
    	cout<<" Enter Numerator: ";
    	cin>>numerator;
    	cout<<" Enter Denominator: ";
    	cin>>denominator;
    	if(denominator==0){
		  	cout<<" Denominator can not be zero.Set den to 1."<<endl;
		  	denominator=1;
		  }
	}
	Rational operator*(const Rational& r){
		Rational res;
		res.numerator=numerator*r.numerator;
		res.denominator=denominator*r.denominator;
		return res;
	}
	Rational operator/(const Rational& r){
		Rational res;
		res.numerator=numerator*r.denominator;
		res.denominator=denominator*r.numerator;
		return res;
	}
	static int getCount() {
        return count;
    }
    void display(){
    	cout<<numerator<<"/"<<denominator<<endl;
	}
	
	
};
int Rational::count = 0;
int main(){
	Rational r1(3,4);
	Rational r2(r1);
	cout << "Number of Rational objects: " << Rational::getCount() << endl;
	Rational r3,r4;
	r3.getInput();
	r4.getInput();
	Rational multiplication = r3*r4;
    Rational division = r3 / r4;
    cout << "Multiplication result: ";
    multiplication.display();
    cout << "Division result: ";
    division.display();
	return 0; 
}
