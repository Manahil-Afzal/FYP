/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rat{
int num;
int den;
static int count;
public:
	rat(){
		
		count++;
	}
	rat(int a, int b){
		num=a;
		if(b==0){
			cout<<"error den cannt be zero.."<<endl;
			den=1;
		}else{
			den=b;
		}count++;
		}
		rat(const rat &r){
			num=r.num;
			den=r.den;
			count++;
		}
		void get(){
			cout<<"enter a number"<<endl;
			cin>>num;
			cout<<"enter a number"<<endl;
			cin>>den;
		}
		rat operator *(const rat &r){
			rat res;
			res.num=num*r.num;
			res.den=den*r.den;
			return res;
		}
		rat operator /(const rat &r){
			rat res;
			res.num=num*r.den;
			res.den=den*r.num;
			return res;
		}
		
		void display()
		{
			cout<<num<<"/"<<den<<endl;
		}
	 static int getcount() {
        return count;
    }
};
int  rat::count=0;
int main(){
	rat r(3,4);
	rat r1;
	r1.get();
	rat r2=r*r1;
	rat r3=r/r1;
	r2.display();
	r3.display();
	cout<<"the total object are created:"<<rat::getcount();
	return 0;
}