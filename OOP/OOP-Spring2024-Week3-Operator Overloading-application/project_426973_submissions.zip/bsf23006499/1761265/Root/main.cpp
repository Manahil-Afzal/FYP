/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/


#include<iostream>
using namespace std;
class Rational{
private:
    int numerator;
    int denominator;
    static int count;
public:
   Rational(int n=0, int d=1){
    numerator=n;
    denominator=d;
    if(denominator== 0){
    cout<<"Error! Denominator can't be zero"<<endl;
    denominator= 1;
    }
    count++;
    }

   Rational(const Rational &other){
    numerator=other.numerator;
    denominator=other.denominator;
    count++;
 } 
   void getInput(){
    cout<<"Enter the numerator : ";
    cin>>numerator;
    cout<<"Enter the denominator : ";
    cin>>denominator;
    if (denominator == 0) {
    cout<<"Error! Denominator can't be zero"<<endl;
    denominator=1;
    }
  }

    void displayOutput(){
    cout<<numerator<<"/"<<denominator;
    }
    Rational operator * (const Rational &other) {
    return Rational(numerator * other.numerator, denominator * other.denominator);
    }
    Rational operator / (const Rational &other){
    return Rational(numerator * other.denominator, denominator * other.numerator);
    }     
    static int getcount(){
        return count;
    }
};
int Rational::count = 0;
int main(){
    Rational r1(10, 5);
    Rational r2 = r1;
    cout<<"Enter digits for the first rational number  "<<endl;
    r1.getInput();
    cout<<"Enter digits for the second rational number  "<<endl;
    r2.getInput();
    cout<<"Multiplication of rational numbers = ";
    Rational multiplication = r1 * r2;
    multiplication.displayOutput();
    cout<<endl<<"Division of rational numbers  = ";
    Rational division = r1 / r2;
    division.displayOutput();
    cout<<endl<<"Total number of objects created  =  "<<Rational::getcount();
}