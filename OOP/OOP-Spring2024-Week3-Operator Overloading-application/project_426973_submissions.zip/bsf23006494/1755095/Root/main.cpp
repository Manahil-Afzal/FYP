/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;
class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero" << endl;
            numerator = 0;
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    static int getCount() {
        return count;
    }

    void inputValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (not zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero" << endl;
            numerator = 0;
            denominator = 1;
        }
    }

    Rational multiply(const Rational& other) const {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return Rational(num, den);
    }

    Rational divide(const Rational& other) const {
        if (other.numerator == 0) {
           cout << "Error: Cannot divide by zero" <<endl;
            return Rational(); 
        }
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return Rational(num, den);
    }

    friend ostream& operator<<(ostream& os, const Rational& r) {
        os << r.numerator << "/" << r.denominator;
        return os;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2;
    r2.inputValues();

    cout << "Count of rational numbers: " << Rational::getCount() << endl;

    Rational resultMultiply = r1.multiply(r2);
    Rational resultDivide = r1.divide(r2);

    cout << "Multiplication: " << resultMultiply << endl;
    cout << "Division: " << resultDivide << endl;

    return 0;
}


