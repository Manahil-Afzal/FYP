#include <iostream>
using namespace std;

class Calc{
    int num;
    int den;
    static int n;
    public:
        Calc(){
            num = 0;
            den = 0;
            n++;
        }
        Calc(int a, int b){
            num = a;
            den = b;
            n++;
        }
        Calc(const Calc &v){
            num = v.num;
            den = v.den;
        }
        void input(){
            cout<<"Enter the value of numinator: ";
            cin>>num;
            do{  //implement the check for denominator zero
            cout<<"Enter the value of denominator: "<<num<<"/";
            cin>>den;
            }while(den==0);
        }
        Calc operator *(Calc &m){
            Calc res;
            res.num = num * m.num;
            res.den = den * m.den;
            return res;
        }
        Calc operator /(Calc &d){
            Calc res;
            res.num = num * d.den;
            res.den = den  * d.num;
            return res;
        }
        void show(){
            for(int i=20;i>=1;i--){
                if(num%i==0&&den%i==0){
                    num = num/i;
                    den = den/i;
                    }                    
            }      
            if(den==0)
                cout<<"Please enter the non-zero value of numinator in second rational no for accurate division!!!"<<endl;
            else{
                cout<<num<<"/"<<den<<endl;
                cout<<"Objects created so far: "<<n<<endl;
            }
        }
};
int Calc :: n=0;

int main(){
    Calc r1,r2(4,10);
    r1 = r2;
    cout<<"Default value of first rational no: ";
    r1.show();
    cout<<"Default value of second rational no: ";
    r2.show();
    r1.input();
    r2.input();
    Calc r3 = r1 * r2;
    cout<<"Multiplication = ";
    r3.show();
    Calc r4 = r1/r2;
    cout<<"Division = ";
    r4.show();
}

