/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;

class Rational{
    int num;
    int denum;
    static int count;
    
public:
    
    Rational(int n, int d) : num(n), denum(d) {
        count++;
    }
    
    
    Rational() : num(0), denum(1) {
        count++;
    }
    
    void input(){
        cout<<"Enter Numerator: ";
        cin>>num;
        do {
            cout<<"Enter Denominator (Should be Greater than 0): ";
            cin>>denum;
        } while (denum <= 0);
    }  
    
    Rational operator*(const Rational& other) const {
        Rational res(num * other.num, denum * other.denum);
        return res;
    }
    
    Rational operator/(const Rational& other) const {
        Rational res(num * other.denum, denum * other.num);
        return res;
    }
    
    void output(){
        cout<<"Result Rational Number: "<<num<<"/"<<denum<<endl;
    }
    
   
    static int getCount() {
        return count;
    }
};


int Rational::count = 0;

int main(){
    Rational R1;
    cout<<"Rational Number 1: ";
    R1.input();
    R1.output();
    
    Rational R2 = R2;
    cout<<"Rational Number 2: ";
    R2.input();
    R2.output();
    
	cout<<"\nNumber of Objects: "<<Rational::getCount()<<endl;
    
    Rational res_mult = R1 * R2;
    cout<<"\nMultiplication Result: ";
    res_mult.output();
    
    Rational res_div = R1 / R2;
    cout<<"Division Result: ";
    res_div.output();
    
    return 0;
}
