/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class Rational
{
private:
    int numerator;
    int denominator;
    static int objectCount;

public:
    Rational(int num = 0, int den = 1)
    {
        if (den == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            numerator = num;
            denominator = 1;
        } else {
            numerator = num;
            denominator = den;
        }
        objectCount++;
    }

        Rational(const Rational &r) {
        numerator = r.numerator;
        denominator = r.denominator;
        objectCount++;
    }

    void getInput() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

      Rational operator * ( Rational &r) {
        Rational result;
        result.numerator = numerator * r.numerator;
        result.denominator = denominator * r.denominator;
        return result;
    }

    Rational operator / ( Rational &r) {
        Rational result;
        result.numerator = numerator * r.denominator;
        result.denominator = denominator * r.numerator;
        return result;
    }

 void displayData() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }

    static int getObjectCount() {
        return objectCount;
    }
};

int Rational::objectCount = 0;

int main() {
    Rational r1, r2;
    cout << "Enter data for first rational number:" << endl;
    r1.getInput();
    cout << "Enter data for second rational number:" << endl;
    r2.getInput();

    Rational multiplyResult = r1 * r2;
    Rational divideResult = r1 / r2;

    cout << "Multiplication: ";
    multiplyResult.displayData();
    cout << "Division: ";
    divideResult.displayData();

    cout << "Total Rational Objects Created: " << Rational::getObjectCount() << endl;

    return 0;
}
