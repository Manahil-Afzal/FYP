#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; 

public:
    Rational(int num = 0, int den = 1) {
        numerator = num;
        denominator = den;
        count++; 
    }

    Rational(const Rational &other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++; 
    }


    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;


        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Please re-enter: ";
            cin >> denominator;
        }
    }


    void display() {
        cout << numerator << "/" << denominator;
    }


    static int getCount() {
        return count;
    }


    Rational operator*(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational &other) {
        Rational result;
        if (other.numerator != 0) {
            result.numerator = numerator * other.denominator;
            result.denominator = denominator * other.numerator;
        } else {
            cout << "Division by zero is undefined. Returning default value.\n";
            result.numerator = 0;
            result.denominator = 1;
        }
        return result;
    }
};


int Rational::count = 0;

int main() {
    Rational num1(2, 3);
    Rational num2 = num1;
    Rational num3;

    num3.input();

    Rational multiplyResult = num2 * num3;
    Rational divideResult = num2 / num3;

    cout << "Multiplication: ";
    multiplyResult.display();
    cout << endl;

    cout << "Division: ";
    divideResult.display();
    cout << endl;
cout << "Total Rational Numbers created: " << Rational::getCount() << endl;

    return 0;
}