#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; 

public:
  
    Rational(int num = 0, int den = 1) {
        numerator = num;
        denominator = den != 0 ? den : 1; 
        count++; 
    }

    Rational(const Rational &other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++; 
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (should not be zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
    }

    void display() {
        cout << numerator << "/" << denominator << endl;
    }

    static int getCount() {
        return count;
    }

    Rational operator*(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }
};

int Rational::count = 0;

int main() {
    Rational num1(2, 3);
    Rational num2 = num1; 
    Rational num3; 

    num3.input(); 

    Rational multiplyResult = num2 * num3; 
    Rational divideResult = num2 / num3;   

    cout << "Multiplication Result: ";
    multiplyResult.display();

    cout << "Division Result: ";
    divideResult.display(); 

    cout << "Total Rational Numbers created: " << Rational::getCount() << endl; 

    return 0;
}
