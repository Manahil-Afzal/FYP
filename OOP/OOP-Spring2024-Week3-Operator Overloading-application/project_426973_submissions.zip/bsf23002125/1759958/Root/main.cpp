/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rationalNumber{
	private:
		int num;
		int den;
	public:
		static int count;
		rationalNumber(int up=0, int down=0){
			num=up;
			den=down;
			count++;
		}
		rationalNumber(rationalNumber &r){
			num=r.num;
			den=r.den;
			count++;
		}
		void setternum(int up){
		    num=up;
		}
		void setterden(int d){
		    den=d;
		}
		void operator*(rationalNumber &r){
			num=num*r.num;
			den=den*r.den;
		}
		void operator/(rationalNumber &r){
			num=num*r.den;
			den=den*r.num;
		}
		void display(){
			cout << "Result: " << num << "/" << den << endl;
            cout << "The number of objects created: " << count << endl;
		}
};

int rationalNumber::count=0;
int main(){
    rationalNumber r1(5,7);
    rationalNumber r2=r1;
	int up,down;
	cout<<"Enter the numerator of first fraction : ";
	cin>>up;
	
	cout<<"Enter the denominator of first fraction: ";
	cin>>down;
	if(down==0){
		cout<<"Denominator cannot be zero. The program is going to terminate." << endl;
		return 0;
	}
	r1.setternum(up);
	r1.setterden(down);
	cout<<"Enter the numerator of the second fraction: ";
	cin>>up;
	cout<<"Enter the denominator of the second fraction: ";
    cin>>down;
    if(down==0){
        cout<<"Denominator cannot be zero. The program will terminate." << endl;
        return 1;
    }
    r2.setternum(up);
    r2.setterden(down);
    
    cout<<"Please enter the operation that you wish to perform (* or /): "<<endl;
    char oper;
    cin>>oper;
    if(oper=='*'){
        r1*r2;
        r1.display();
    }
    else if(oper=='/'){
        r1/r2;
        r1.display();
    }
    else{
    	cout<<"You didnot enter a valid operation the program is going to terminate."<<endl;
    	return 0;
    }

	return 0;
}