/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;

public:
    Rational(int num = 0, int denom = 1) {
        if (denom == 0) {
            cout << "Error: Denominator cannot be zero. Setting it to 1." << endl;
            denom = 1;
        }
        numerator = num;
        denominator = denom;
    }

    Rational(const Rational& other) {
        numerator = other.numerator;
        denominator = other.denominator;
    }

    void setValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        }
    }
    void display() {
        cout << numerator << "/" << denominator;
    }


    Rational operator*(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational operator/(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }
};

int main() {
    Rational rat1(3, 4); 
    Rational rat2; 
    rat2.setValues(); 

    Rational rat3 = rat1 * rat2;
    Rational rat4 = rat1 / rat2;

    cout << "Result of multiplication: ";
    rat3.display();
    cout << endl;

    cout << "Result of division: ";
    rat4.display();
    cout << endl;

    return 0;
}