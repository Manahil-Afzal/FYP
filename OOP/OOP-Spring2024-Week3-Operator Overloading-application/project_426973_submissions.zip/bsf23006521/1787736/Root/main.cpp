/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/


#include <iostream>

using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    

public:
static int count;
    Rational(int num = 0, int den = 1) {
        numerator = num;
        denominator = den;
        if (denominator == 0) {
            cerr << "Error: Denominator cannot be zero. Setting it to 1.\n";
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational &copy) {
        numerator = copy.numerator;
        denominator = copy.denominator;
        count++;
    }

    // Multiplication operator overload
    Rational operator*(Rational &other) {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    // Division operator overload
    Rational operator/(Rational &other) {
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cerr << "Error: Denominator cannot be zero. Setting it to 1.\n";
            denominator = 1;
        }
    }

    void print() {
        cout << numerator << "/" << denominator;
    }

    // Static member to keep count of objects
    static int getCount() {
        return count;
    }
};

// Initialize static member variable count
int Rational::count = 0;

int main() {
    // Take input for the first object
    cout << "Enter the numerator and denominator for the first rational number:\n";
    int num1, den1;
    cout << "Numerator: ";
    cin >> num1;
    cout << "Denominator (non-zero): ";
    cin >> den1;

    // Create the first object
    Rational r1(num1, den1);
    Rational r2(r1);

    cout << "\nFirst rational number: ";
    r1.print();
    cout << endl;
    cout << "Second rational number (copied from the first): ";
    r2.print();
    cout << endl;

    // Perform multiplication
    Rational result_mult = r1 * r2;
    cout << "\nMultiplication Result: ";
    result_mult.print();
    cout << endl;

    // Perform division
    Rational result_div = r1 / r2;
    cout << "Division Result: ";
    result_div.print();
    cout << endl;
    cout << "Total rational number: " << Rational::getCount() << endl;

    return 0;
}
