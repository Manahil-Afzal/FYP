/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // static member to keep count of objects

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++; // increment count when an object is created
    }

    // Copy constructor
    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++; // increment count when an object is copied
    }

    // Destructor to decrement count when an object is destroyed
    ~Rational() {
        count--;
    }

    // Method to take inputs of denominator and numerator from user
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Method to display rational number
    void display() const {
        cout << numerator << "/" << denominator;
    }

    // Operator overloading for multiplication
    Rational operator*(const Rational& other) const {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    // Operator overloading for division
    Rational operator/(const Rational& other) const {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    // Static member function to get count of objects
    static int getCount() {
        return count;
    }
};

// Initializing static member outside class definition
int Rational::count = 0;

int main() {
    Rational r1(3, 4); // Using parameterized constructor to initialize values
    Rational r2; // Using default constructor

    cout << "Enter the values for the second rational number:" << endl;
    r2.input();

    cout << "First rational number: ";
    r1.display();
    cout << endl;

    cout << "Second rational number: ";
    r2.display();
    cout << endl;

    // Perform multiplication and division
    Rational multiply = r1 * r2;
    Rational divide = r1 / r2;

    cout << "Multiplication result: ";
    multiply.display();
    cout << endl;

    cout << "Division result: ";
    divide.display();
    cout << endl;

    cout << "Total rational numbers created: " << Rational::getCount() << endl;

    return 0;
}
