/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/


#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count; 

public:
    RationalNumber(int num = 0, int denom = 1) {
        if (denom == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denom = 1;
        }
        numerator = num;
        denominator = denom;
        count++;
    }

    RationalNumber(const RationalNumber &obj) {
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++;
    }

    void getInput() {
        cout << "Enter Numerator: ";
        cin >> numerator;
        cout << "Enter Denominator (non-zero): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    RationalNumber operator*(const RationalNumber &obj) {
        RationalNumber result;
        result.numerator = numerator * obj.numerator;
        result.denominator = denominator * obj.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber &obj) {
        RationalNumber result;
        result.numerator = numerator * obj.denominator;
        result.denominator = denominator * obj.numerator;
        return result;
    }

    static int getCount() {
        return count;
    }

    void display() {
        cout << numerator << "/" << denominator;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1, num2, result_mul, result_div;

    cout << "Enter details for Rational Number 1:" << endl;
    num1.getInput();

    cout << "\nEnter details for Rational Number 2 (copied from Rational Number 1):" << endl;
    num2 = num1;

    cout << "\nMultiplication:" << endl;
    result_mul = num1 * num2; 
    num1.display();
    cout << " * ";
    num2.display();
    cout << " = ";
    result_mul.display();
    cout << endl;

    cout << "\nDivision:" << endl;
    result_div = num1 / num2; 
    num1.display();
    cout << " / ";
    num2.display();
    cout << " = ";
    result_div.display();
    cout << endl;

    cout << "\nTotal Rational Number objects created: " << RationalNumber::getCount() << endl;

    return 0;
}
