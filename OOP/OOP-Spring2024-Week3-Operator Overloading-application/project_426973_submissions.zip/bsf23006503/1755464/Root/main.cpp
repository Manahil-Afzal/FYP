/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero*/
#include <iostream>
using namespace std;
class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;

public:
    RationalNumber(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
        count++;
    }

    RationalNumber(const RationalNumber &other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    static int getCount() {
        return count;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
    }

    RationalNumber operator*(const RationalNumber &other) const {
        return RationalNumber(numerator * other.numerator, denominator * other.denominator);
    }

    RationalNumber operator/(const RationalNumber &other) const {
        if (other.numerator == 0) {
            cerr << "Error: Division by zero. Returning the first rational number.\n";
            return *this;
        }
        return RationalNumber(numerator * other.denominator, denominator * other.numerator);
    }

    void display() const {
        cout << numerator << "/" << denominator <<endl;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1(2, 3);
    RationalNumber num2(num1);
    RationalNumber num3;

    num3.input();

    cout << "Multiplication result: ";
    RationalNumber result_mul = num1 * num2;
    result_mul.display();

    cout << "Division result: ";
    RationalNumber result_div = num1 / num3;
    result_div.display();

    cout << "Total Rational Numbers: " << RationalNumber::getCount() << endl;
    return 0;
}
