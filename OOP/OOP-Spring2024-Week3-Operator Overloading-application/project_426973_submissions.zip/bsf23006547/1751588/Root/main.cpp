/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;
class Calculator{
private:
	int numerator;
	int denominator;
	static int count;
public:
	Calculator()
	{count++;
	}
	Calculator(int n,int d) 
	{
	 numerator = n;
	 denominator = d;
	 count++;
	}
     Calculator(const Calculator& cal1)
	{
	   numerator = cal1.numerator;
	   denominator = cal1.denominator;
	   count++;
	}
	void GetInput()
	{
		cout<<"Enter numerator :";
		cin>>numerator;
		cout<<"Enter denominator :";
		cin>>denominator;
		while(denominator==0)
		{
			cout<<"Error denominator can't be zero."<<endl<<"Enter denominator again:";
			cin>>denominator;	
		}
		cout<<numerator<<" / " << denominator <<endl;
	}
	Calculator operator * (Calculator& cal1)
	{

		Calculator helper;
		helper.numerator = this->numerator * cal1.numerator;
		helper.denominator = this->denominator * cal1.denominator;
		cout<< "Result of multiplication: "<<helper.numerator <<" / "<<helper.denominator<<endl;
		float a = helper.numerator *1.0  / helper.denominator;
 	    cout<< "Result of multiplication: "<< a <<endl;
		
		return helper;
		
	}
	Calculator operator / (Calculator& cal1)
	{

		Calculator cop;
		cop.numerator = this->numerator * cal1.denominator;
		cop.denominator = this->denominator *cal1.numerator; 
		cout<< "Result of Division: "<<cop.numerator <<" / "<<cop.denominator<<endl;
		float a = cop.numerator *1.0 / cop.denominator;
 	    cout<< "Result of Division: "<< a <<endl;
		
		return cop;
		
	}
	static int getCount()
	{
		return count;
	}
};
int Calculator::count = 0;
int main()
{	Calculator cal1(2,4);
 	Calculator cal2 = cal1;
 	Calculator mul= cal2 * cal1;
 	Calculator div= cal2 / cal1;
 	Calculator cal3;
 	cal3.GetInput();
 	cout<<"object count : "<<Calculator::getCount();
 }