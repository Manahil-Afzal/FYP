//Ma'am The program is running perfectly on Vs Code(my personal IDE)
//but on codeboard the count is showing 3 instead of 2
// so its the issue of the codeboard ide not the code, Thank you.



#include<iostream>
using namespace std;
class rational{
	private:
		int num;
		int den;
	public:
		static int count;
		
	
		rational(int n=0, int d=0){
			num=n;
			den=d;
			count++;
		}
		rational(rational &r){
			num=r.num;
			den=r.den;
			count++;
		}
		
		void setternum(int n){
		    num=n;
		}
		void setterden(int d){
		    den=d;
		}
		void operator*(rational &r){
			num=num*r.num;
			den=den*r.den;
		}
		
		void operator/(rational &r){
			num=num*r.den;
			den=den*r.num;
		}
		void display(){
			cout<<"The number of objects created: "<<count<<endl;
			cout<<"The result after operation: "<<num<<"/"<<den<<endl;
		}
	
};

int rational::count=0;
int main(){
rational r1(5,7);
rational r2=r1;
	int n,d;
	cout<<"Please enter the numerator of first fraction : "<<endl;
	cin>>n;
	
	cout<<"Please enter the denominator of first fraction: "<<endl;
	cin>>d;
	if(d==0){
		cout<<"You have entered the denominator as a zero the program is going to terminate."<<endl;
		return 0;
	}
	r1.setternum(n);
	r1.setterden(d);
	cout<<"Please enter the numerator of the second fraction: "<<endl;
	cin>>n;
	cout<<"Please enter the denominator of the second fraction: "<<endl;
    cin>>d;
    if(d==0){
        cout<<"You have entered the denominator as a zero the program will terminate."<<endl;
        return 0;
    }
    r2.setternum(n);
    r2.setterden(d);
    
cout<<"Please enter the operation that you wish to perform (* or /): "<<endl;
char oper;
cin>>oper;
if(oper=='*'){
	r1*r2;
}
else if(oper=='/'){
	r1/r2;
}
else{
	cout<<"You did not enter a valid operation the program is going to terminate."<<endl;
	return 0;
}
r1.display();
	
	
	
	
	return 0;
}