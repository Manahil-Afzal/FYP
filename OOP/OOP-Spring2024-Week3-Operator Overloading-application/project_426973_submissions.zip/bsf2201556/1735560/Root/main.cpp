/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    ~Rational() {
        count--;
    }

    static int getCount() {
        return count;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        do {
            cout << "Enter denominator (non-zero): ";
            cin >> denominator;
        } while (denominator == 0);
    }

    Rational operator*(const Rational& other) const {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational operator/(const Rational& other) const {
        if (other.numerator == 0) {
            cerr << "Error: Division by zero.\n";
            return Rational();
        }
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    void display() const {
        cout << "Result: " << numerator << "/" << denominator << std::endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r1, r2;
    r1.input();
    r2 = r1;

    Rational result_mul = r1 * r2;
    Rational result_div = r1 / r2;

    cout << "Multiplication: ";
    result_mul.display();
    cout << "Division: ";
    result_div.display();

    cout << "Total Rational objects created: " << Rational::getCount() << std::endl;

    return 0;
}