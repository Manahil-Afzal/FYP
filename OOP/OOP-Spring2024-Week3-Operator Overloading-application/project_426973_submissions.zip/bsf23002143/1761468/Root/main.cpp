/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++; // Increment count for each object creation
    }

    // Copy constructor
    Rational(const Rational &other) : numerator(other.numerator), denominator(other.denominator) {
        count++; // Increment count for each object creation
    }

    // Method to take inputs of denominator and numerator from user
    void input() {
        cout << "Enter the numerator: ";
        cin >> numerator;
        cout << "Enter the denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Method to perform multiplication
    Rational operator*(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    // Method to perform division
    Rational operator/(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    // Static method to get count of objects
    static int getCount() {
        return count;
    }

    // Method to display rational number
    void display() {
        cout << numerator << "/" << denominator;
    }
};

// Initializing static member outside class definition
int Rational::count = 0;

int main() {
    Rational r1, r2, multiplyResult, divideResult;

    cout << "Enter details for first rational number:" << endl;
    r1.input();

    cout << "\nEnter details for second rational number (copy of first):" << endl;
    r2 = r1; // Using assignment operator to invoke copy constructor

    cout << "\nPerforming multiplication..." << endl;
    multiplyResult = r1 * r2;
    cout << "Multiplication result: ";
    multiplyResult.display();
    cout << endl;

    cout << "\nPerforming division..." << endl;
    divideResult = r1 / r2;
    cout << "Division result: ";
    divideResult.display();
    cout << endl;

    cout << "\nTotal objects of rational numbers created: " << Rational::getCount() << endl;

    return 0;
}
