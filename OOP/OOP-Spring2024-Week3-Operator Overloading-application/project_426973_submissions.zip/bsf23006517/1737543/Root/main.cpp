/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;

class demo {
private:
    float numerator;
    float denominator;
    static int c;
public:
    demo(float num = 0, float den = 1) {
        numerator = num;
        if (den <= 0) {
            cerr << "Error: Denominator must be greater than 0. Setting denominator to 1." << endl;
            denominator = 1;
        } else {
            denominator = den;
        }
        c++;
    }

    demo(const demo &z) {
        numerator = z.numerator;
        denominator = z.denominator;
    }

    void getdata() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (must be greater than 0): ";
        cin >> denominator;
        if (denominator <= 0) {
            cerr << "Error: Denominator must be greater than 0. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    demo operator*(const demo &bb) {
        demo cc;
        cc.numerator = numerator * bb.numerator;
        cc.denominator = denominator * bb.denominator;
        return cc;
    }

    demo operator/(const demo &bb) {
        demo cc;
        cc.numerator = numerator / bb.denominator;
        cc.denominator = denominator / bb.numerator;
        return cc;
    }

    void display() {
        cout << numerator << "/" << denominator;
    }

    static int getCount() {
        return c;
    }
};

int demo::c = 0;

int main() {
    demo cc;
    demo qq;
    qq.getdata();
    demo aa(qq);
    demo bb(aa);

    cc = aa * bb;
    cout << "Multiplication: ";
    cc.display();
    cout << endl;

    cc = aa / bb;
    cout << "Division: ";
    cc.display();
    cout << endl;

    cout << "Total objects created: " << demo::getCount() << endl;

    return 0;
}
