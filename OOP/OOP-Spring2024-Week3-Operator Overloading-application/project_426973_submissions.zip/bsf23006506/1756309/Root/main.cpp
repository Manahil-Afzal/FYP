/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;

class operation {
private: 
    int num;
    int den;
public:
    static int objectcount;
    operation() {
        objectcount++;
    }
    
    operation(int x, int y=0) {
        num = x;
        den = y;
        if(den == 0) {
            cout << "ERROR!!(denominator cannot be zero)";
        }
    }
    
    operation(const operation &obj) {
        num = obj.num;
        den = obj.den;
    }
    
    operation operator*(const operation &mul) {
        operation res;
        res.num = num * mul.num;
        res.den = den * mul.den;
        return res;
    }
    
    operation operator/(const operation &div) {
        operation res;
        res.num = num * div.den;
        res.den = den * div.num;
        return res;
    }
    
    void input() {
        cout << "Enter the value of numerator: ";
        cin >> num;
        cout << "Enter the value of denominator: ";
        cin >> den;
        if(den == 0) {
            cout << "ERROR!! (denominator cannot be zero)" << endl;

    }
}
    
    void display() {
    	
        cout << num << "/" << den << endl;

    }
};

int operation::objectcount = 0;

int main() {
    operation obj1, obj2;
    cout << "Enter the values of first object:" << endl;
    obj1.input();
    cout << "Enter the values of second object:" << endl;
    obj2.input();
    cout << ".......multiplication...." << endl;
    operation mul_result = obj1 * obj2;
    mul_result.display();
    cout << ".......division...." << endl;
    operation div_result = obj1 / obj2;
    div_result.display();
    cout << "Total rational numbers: " << operation::objectcount << endl;
    return 0;
}