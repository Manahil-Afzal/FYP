/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
#include <string> // Include the string header for using string type
using namespace std;

class Book {
    string title;
    float price;

  public:
    void getData(); // Declaration of getData method
    void putData(); // Declaration of putData method
};

void Book::getData() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    // Getting data for each book
    cout << "Enter data for Book 1:\n";
    book1.getData();

    cout << "Enter data for Book 2:\n";
    book2.getData();

    cout << "Enter data for Book 3:\n";
    book3.getData();

    // Displaying data for each book
    cout << "\nData for Book 1:\n";
    book1.putData();

    cout << "\nData for Book 2:\n";
    book2.putData();

    cout << "\nData for Book 3:\n";
    book3.putData();

    return 0;
}
