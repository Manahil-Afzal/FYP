/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std; 

class Rational
{
	int denominator;
	int numerator;


public:
	static int count;
	Rational(int n = 0, int d = 1) 
	{
		numerator=n;
		denominator=d;
		if (denominator == 0)
		{
			cout << "Denominator cannot be zero. Setting it to 1." << endl;
			denominator = 1;
		}
		count++;
	}



	Rational(const Rational& obj) 
	{
		numerator=obj.numerator;
		denominator=obj.denominator;
		count++;
	}

	void input()
	{
		cout << "Enter the Numerator: ";
		cin >> numerator;

		do {
			cout << "Enter the denominator (non-zero): ";
			cin >> denominator;
			if (denominator == 0)
			{
				cout << "Denominator cannot be zero. Please enter again." << endl;
			}
		} while (denominator == 0);
	}

	void display() const {
		cout << numerator << "/" << denominator;
	}

	Rational operator* ( Rational &obj)
	{
		int num = numerator * obj.numerator;
		int deno = denominator * obj.denominator;
		return Rational(num, deno);
	}

	Rational operator / (const Rational& obj)const
	{
		int num = numerator * obj.denominator;
		int deno = denominator * obj.numerator;
		return Rational(num, deno);
	}

	
};

int Rational::count = 0;

int main()
{
	Rational r1, r2;

	cout << "Enter details for first rational number:" << endl;
	r1.input();
	cout << "Enter details for second rational number:" << endl;
	r2.input();

	Rational result = r1 * r2;

	cout << "Multiplication: ";
	result.display();
	cout << endl;

	Rational result2 = r1 / r2;

	cout << "Division: ";
	result2.display();
	cout << endl;
	cout << "Total Rational Objects: " << Rational::count << endl;

}