/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rational{
    float denominator;
    float numerator;
    public:
    static int count;
    rational(){
        count++;
    }
    rational(float d,float n)
    {
        denominator=d;
        numerator=n;
        count++;
    }
    rational(const rational& other){
        denominator=other.denominator;
       numerator= other.numerator;
       count++;
    }
       
     void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
       
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting denominator to 1.\n";
            denominator = 1;
            
        }
         
     }
    rational operator *(const rational &obj){
        rational result;
        result.denominator=denominator*obj.denominator;
        result.numerator=numerator*obj.numerator;
        return result;
    }
    void show(){
        cout<<"Numerator is: "<<numerator<<"\nDenominaor is: "<<denominator<<endl;
    }
    rational operator /(rational &obj){
        rational result;
        result.denominator=denominator/obj.denominator;
        result.numerator=numerator/obj.numerator;
        return result;
}};
int rational::count=0;
int main(){
    rational r1(3,4);
    rational r2=r1;
    cout<<"Object count is:"<<rational::count<<endl;
    rational r3,r4;
    r3.input();
    r4.input();
    cout<<"Multiplication is:"<<endl;
    rational r5=r3*r4;
    r5.show();
    cout<<"Divison is:"<<endl;
    rational r6=r3/r4;
    r6.show();
    return 0;
}