/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/#include <iostream>
using namespace std;

class rational {
private:
    int num, den;

public:
    static int count;
    rational(int n = 0, int d = 1) : num(n), den(d) {
        count++;
    }
    rational(const rational &other) : num(other.num), den(other.den) {
        count++;
    }
    void getData() {
        cout << "Enter Numerator value: ";
        cin >> num;
        cout << "Enter Denominator value: ";
        cin >> den;
        if (den == 0) {
            cout << "Denominator Should not be 0! Enter Number Again" << endl;
            cin >> den;
        }
    }
    rational operator*(const rational &other) {
        rational res;
        res.num = num * other.num;
        res.den = den * other.den;
        return res;
    }
    rational operator/(const rational &other) {
        rational res;
        res.num = num * other.den;
        res.den = den * other.num;
        return res;
    }
    void display() {
        cout << "The result after operation is: " << num << "/" << den << endl;
    }
    static void showObjects() {
        cout << "Number of objects created= " << count << endl;
    }
};

int rational::count = 0;

int main() {
    rational cal1(1, 2);
    rational cal2 = cal1;
    cal1.getData();
    cal2.getData();

    char oper;
    cout << "Please enter the operation that you want to perform? * or / : " << endl;
    cin >> oper;

    rational result;
    if (oper == '*') {
        result = cal1 * cal2;
    } else if (oper == '/') {
        result = cal1 / cal2;
    } else {
        cout << "Invalid operation entered" << endl;
        return 1;
    }

    result.display();
    rational::showObjects();

    return 0;
}