/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std; 

class RationalNum
{
	int denominator;
	int numerator;
	static int no_of_obj;

public:
	// Parametrized Constructor
	RationalNum(int n = 0, int d = 1) : numerator(n), denominator(d)
	{
		if (denominator == 0)
		{
			cout << "Denominator cannot be zero." << endl;
			
			denominator = 1;
		}
		no_of_obj++;
	}

	// Copy constructor

	RationalNum(const RationalNum& obj) : numerator(obj.numerator), denominator(obj.denominator)
	{
		no_of_obj++;
	}

	// Input & Output Method

	void input()
	{
		cout << "Enter the Numerator: ";
		cin >> numerator;

		do {
			cout << "Enter the denominator (not_zero): ";
			cin >> denominator;
			if (denominator == 0)
			{
				cout << "Denominator cannot be zero. Please enter again." << endl;
			}
		} while (denominator == 0);
	}

	void display() const {
		cout << numerator << "/" << denominator;
	}

	RationalNum operator* (const RationalNum &obj)const
	{
		int num = numerator * obj.numerator;
		int deno = denominator * obj.denominator;
		return RationalNum(num, deno);
	}

	RationalNum operator / (const RationalNum& obj)const
	{
		int nume = numerator * obj.denominator;
		int deno = denominator * obj.numerator;
		return RationalNum(nume, deno);
	}

	static int get_num_of_objects_count()
	{
		return no_of_obj;
	}
};

int RationalNum::no_of_obj = 0;

int main()
{
	RationalNum r1, r2;

	cout << "Enter details for first rational number:" << endl;
	r1.input();
	cout << "Enter details for second rational number:" << endl;
	r2.input();

	RationalNum result = r1 * r2;

	cout << "Multiplication: ";
	result.display();
	cout << endl;

	RationalNum result2 = r1 / r2;

	cout << "Division: ";
	result2.display();
	cout << endl;
	cout << "Total Rational Objects: " << RationalNum::get_num_of_objects_count() << endl;

}