#include<iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            denominator = 1;
        }
        count++; // Increment count when object is created
    }

    

    // Method to take inputs from user
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
           
            denominator = 1;
        }
    }

    // Method to display the rational number
    void display()  {
       cout << numerator << "/" << denominator;
    }

    // Static method to get count of objects
    static int getCount() {
        return count;
    }

    // Overloading multiplication operator
    Rational operator*( Rational& other)  {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    // Overloading division operator
    Rational operator/( Rational& other)  {
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    // Destructor to decrement count when object is destroyed
    ~Rational() {
        count--; 	 	 	
    }
};

// Initialize static member
int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2;
    
   cout << "Enter values for the second rational number:" << std::endl;
    r2.input();
    
    cout << "Multiplication result: ";
    Rational multiplication = r1 * r2;
    multiplication.display();
    cout << endl;

   cout << "Division result: ";
    Rational division = r1 / r2;
    division.display();
   cout << endl;

    cout << "Total number of Rational objects: " << Rational::getCount() <<endl;

    return 0;
}
