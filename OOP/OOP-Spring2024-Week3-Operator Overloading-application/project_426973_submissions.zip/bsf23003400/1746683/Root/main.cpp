/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num = 1, int denom = 1){
        cout << "Parameterized Constructor called." << endl;
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting to 1 by default." << endl;
            denominator = 1;
        }
        count++;
    }

    // Copy constructor
    Rational(const Rational &obj) {
        cout << "Copy Constructor called." << endl;
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++;
    }

    // Method to take inputs
    void getInput() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (cannot be 0): ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting to 1 by default." << endl;
            denominator = 1;
        }
    }

    Rational operator*(Rational &obj) {
        // Rational(numerator * obj.numerator, denominator * obj.denominator);
        Rational mul;
        mul.numerator=numerator*obj.numerator;
        mul.denominator=denominator*obj.denominator;
        return mul;
    }
    
  Rational operator/(Rational &obj) {
        //return Rational(numerator * obj.denominator, denominator * obj.numerator);
        Rational dev;
        dev.numerator=numerator*obj.denominator;
        dev.denominator=denominator*obj.numerator;
        return dev;
    }

    void display() const {
        cout << numerator << "/" << denominator << endl;
    }

    static void displayCount() {
        cout << "Total Rational objects created: " << count << endl;
    }
};

int Rational::count = 0;
int main() {
    Rational r1;
    r1.getInput();

    Rational r2 = r1;
    r2.display();

    Rational r3; 
    r3.getInput();

    Rational resultMul = r2 * r3; 
    Rational resultDiv = r2 / r3; 

    cout << "Multiplication Result: ";
    resultMul.display();

    cout << "Division Result: ";
    resultDiv.display();

    Rational::displayCount();

    return 0;
}
