/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/



#include<iostream>
using namespace std;
class myclass{
	public:
        	static int objcount;
			myclass()
			{
				objcount++;
			}
		float numerator;
		float denomerator;
		myclass(int n,int d){
			numerator=n;
        	denomerator=d;
        
		}
		void input(){
			cout<<"Enter the numerator:";
			cin>>numerator;
			cout<<"Enter the denomerator:";
			cin>>denomerator;
		}
		
		myclass operator*(myclass &m){
			myclass ans(0,0);
			ans.numerator=numerator  * m.numerator;
			ans.denomerator=denomerator * m.denomerator;
		return ans;
		}
		myclass operator/(myclass &m){
			myclass ans(0,0);
			ans.numerator=numerator  / m.numerator;
			ans.denomerator=denomerator / m.denomerator;
		return ans;
		}
		
};
int myclass::objcount=0;
int main()
{
	cout<<"..........multiplaction operater.........."<<endl;
myclass m1(0,0),m2(0,0);
m1.input();
m2.input();
myclass m3=m1*m2;
cout<<"multiplaction of two objects::"<<endl;
cout<<m3.numerator<<" "<<m3.denomerator<<endl;
             
     cout<<"...........division opertater..........."<<endl;
myclass d1,d2;
d1.input();
d2.input();
myclass d3=d1/d2;
cout<<"division of two objects::"<<endl;
cout<<d3.numerator<<" "<<d3.denomerator;
return 0;
}