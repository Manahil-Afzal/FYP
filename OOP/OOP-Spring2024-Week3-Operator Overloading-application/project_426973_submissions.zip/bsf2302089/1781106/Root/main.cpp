/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
#include<cstdlib>
using namespace std;

#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;
public:
    // Parameterized constructor
    Rational(int num, int den){
        numerator = num;
        if (den == 0) {
            cout << "Error: Denominator cannot be zero." << endl;
            exit(1);
        }
        denominator = den;
        count++;
    }
    // Copy constructor
    Rational(const Rational &obj){
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++;
    }
    // Method to take inputs
    void inputValues(){
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero." << endl;
            exit(1);
        }
    }
    // Multiplication operator overloading
    Rational operator*(const Rational &obj){
        Rational temp(1, 1);
        temp.numerator = numerator * obj.numerator;
        temp.denominator = denominator * obj.denominator;
        return temp;
    }
    // Division operator overloading
    Rational operator/(const Rational &obj){
        Rational temp(1, 1);
        temp.numerator = numerator * obj.denominator;
        temp.denominator = denominator * obj.numerator;
        return temp;
    }
    // Display method
    void display(){
        cout << "Numerator: " << numerator << endl;
        cout << "Denominator: " << denominator << endl;
    }
    // Static member to count objects
    static void displayCount(){
        cout << "Total objects created: " << count << endl;
    }
};
int Rational::count = 0;
int main() {
    Rational r1(3, 4);
    Rational r2(r1);
    Rational r3(2, 5);
    Rational resultMultiply = r1 * r3;
    Rational resultDivide = r1 / r3;
    cout << "Multiplication Result:" << endl;
    resultMultiply.display();
    cout << "\nDivision Result:" << endl;
    resultDivide.display();
    Rational::displayCount();
    return 0;
}
