/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational{
	private:
		int numerator;
		int denominator;
	public:
		static int count;
		
		//Parameterized Constructor
		Rational(int num=0, int denom=0){
			numerator=num;
			denominator=denom;
			count++;
		}
		//Copy Constructor
		Rational(Rational &r1){
			numerator=r1.numerator;
			denominator=r1.denominator;
			count++;
		}
		void SetNumerator(int n){
			numerator=n;
		}
		void SetDenominator(int d){
			denominator=d;
		}
		void operator*(Rational&r1){
			numerator=numerator*r1.numerator;
			denominator=denominator*r1.denominator;
		}
		void operator/(Rational&r1){
			numerator=numerator*r1.denominator;
			denominator=denominator*r1.numerator;
		}
		void Display(){
			cout<<"Answer is : "<<numerator<<"/"<<denominator<<endl;
			cout<<"Total objects generated : "<<count<<endl;
		}
};

int Rational::count=0;

int main(){
	Rational r1(5,7);
	Rational r2=r1;
	
	int n,d;
	cout<<"First fraction numerator : ";
	cin>>n;
	cout<<"First fraction denominator : ";
	cin>>d;
	if(d==0){
		cout<<"You did not enter 0 in denominator"<<endl;
		return 0;
	}
	r1.SetNumerator(n);
	r1.SetDenominator(d);
	
	cout<<"Second fraction numerator : ";
	cin>>n;
	cout<<"Second fraction denominator : ";
	cin>>d;
	if(d==0){
		cout<<"You did not enter 0 in denominator"<<endl;
		return 0;
	}
	r2.SetNumerator(n);
	r2.SetDenominator(d);
	
	cout<<"Enter operator (* or /)"<<endl;
	char oper;
	cin>>oper;
	switch(oper){
		case '*':
			r1*r2;
			break;
		case '/':
			r1/r2;
			break;
		default:
			cout<<"ERROR!!"<<endl;
			cout<<"Enter valid operator."<<endl;
	}
	r1.Display();
	
	return 0;
}