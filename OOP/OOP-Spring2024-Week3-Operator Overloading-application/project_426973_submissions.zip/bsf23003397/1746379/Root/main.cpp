/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero." << std::endl;
            
        }
        count++;
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    // Method to take inputs from the user
    void input() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;
        std::cout << "Enter denominator: ";
        std::cin >> denominator;
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero." << std::endl;
        
        }
    }
    Rational operator*(const Rational& other) const {
        Rational result;
        result.numerator = this->numerator * other.numerator;
        result.denominator = this->denominator * other.denominator;
        return result;
    }
    Rational operator/(const Rational& other) const {
        Rational result;
        result.numerator = this->numerator * other.denominator;
        result.denominator = this->denominator * other.numerator;
        return result;
    }

    static int getCount() {
        return count;
    }

    ~Rational() {
        count--;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(2, 3);
    Rational r2;

    
    r2.input();

    Rational product = r1 * r2;
    std::cout << "Multiplication: " << product.getCount() << "/" << Rational::getCount() << std::endl;

    Rational division = r1 / r2;
    std::cout << "Division: " << division.getCount() << "/" << Rational::getCount() << std::endl;

    return 0;
}

