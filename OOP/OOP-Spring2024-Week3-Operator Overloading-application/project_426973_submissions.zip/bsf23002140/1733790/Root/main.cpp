  
  /*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

  
   #include<iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    // Parameterized constructor
    Rational(int num, int denom) {
        numerator = num;
        if (denom != 0) {
            denominator = denom;
        } else {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    // Copy constructor
    Rational(const Rational &obj) {
        numerator = obj.numerator;
        denominator = obj.denominator;
        count++;
    }

    // Method to take inputs from the user
    void inputValues() {
        cout << "Enter numerator: ";
        cin >> numerator;

        cout << "Enter denominator: ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Static member to keep count of objects
    static int getCount() {
        return count;
    }

    // Method to display the rational number
    void display() {
        cout << "Rational Number: " << numerator << "/" << denominator << endl;
    }

    // Overloading multiplication operator
    Rational operator*(const Rational &obj) {
        Rational result(numerator * obj.numerator, denominator * obj.denominator);
        return result;
    }

    // Overloading division operator
    Rational operator/(const Rational &obj) {
        Rational result(numerator * obj.denominator, denominator * obj.numerator);
        return result;
    }
};

// Initializing static member
int Rational::count = 0;

int main() {
    Rational num1(3, 4); // Using parameterized constructor
    Rational num2 = num1; // Using copy constructor

    cout << "Number of Rational objects created: " << Rational::getCount() << endl;

    Rational result_multiply = num1 * num2;
    Rational result_divide = num1 / num2;

    cout << "Result of multiplication: ";
    result_multiply.display();

    cout << "Result of division: ";
    result_divide.display();

    return 0;
}

   
   
   
   
   
   
   
   
   
   
   
   
