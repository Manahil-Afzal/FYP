/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;
class Rational {
private:
    int numerator;
    int denominator;
    static int count; 

public:
    Rational(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) { 
            cout << "Error: Denominator cannot be zero." << endl;
            
        }
        count++;
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }
    void setValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (must be non-zero): ";
        cin >> denominator;
        if (denominator == 0) { 
            cout << "Error: Denominator cannot be zero." << endl;
            }}
    Rational operator*(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }
    Rational operator/(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    static int getCount() {
        return count;
    }
    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
};
int Rational::count = 0;

int main() {
    Rational r1, r2;
    r1.setValues(); 
    r2 = r1; 
    Rational r3 = r1 * r2; 
    Rational r4 = r1 / r2; 
    r3.display(); 
    r4.display(); 
    cout << "Total objects of Rational: " << Rational::getCount() << endl; 
    return 0;
}
