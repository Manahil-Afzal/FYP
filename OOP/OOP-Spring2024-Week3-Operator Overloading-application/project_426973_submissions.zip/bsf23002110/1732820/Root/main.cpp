#include<iostream>
using namespace std;
class Rational{
	private:
		int num;
		int den;
	public:
		static int count;
		Rational(int n=0, int d=0){
			num=n;
			den=d;
			count++;
		}
		Rational(Rational &r){
			num=r.num;
			den=r.den;
			count++;
		}
		
		void setterNum(int n){
		    num=n;
		}
		void setterDen(int d){
		    den=d;
		}
		void operator*(Rational &r){
			num=num*r.num;
			den=den*r.den;
		}
		
		void operator/(Rational &r){
			num=num*r.den;
			den=den*r.num;
		}
		void display(){
			cout<<"Number of objects created: "<<count<<endl;
			cout<<"Result after operation: "<<num<<"/"<<den<<endl;
		}
	
};

int Rational::count=0;
int main(){
Rational r1(5,7);
Rational r2=r1;
	int n,d;
	cout<<"Enter first Numerator : "<<endl;
	cin>>n;
	
	cout<<"Enter first Denominator: "<<endl;
	cin>>d;
	switch(d){
	    case 0:
	    cout<<"Denominator should not be zero. Restart the program "<<endl;
		return 0;
	}
	r1.setterNum(n);
	r1.setterDen(d);
	cout<<"Enter second Numerator: "<<endl;
	cin>>n;
	cout<<"Enter second Denominator: "<<endl;
    cin>>d;
    switch(d){
        case 0:
        cout<<"Denominator should not be zero. Restart the program "<<endl;
        break;
    }
    r2.setterNum(n);
    r2.setterDen(d);
    
cout<<"Which operation you want to perform (* or /): "<<endl;
char oper;
cin>>oper;
switch(oper){
    case '*':
	r1*r2;
	break;
	case '/':
	r1/r2;
	break;
	default:
	cout<<"Enter a valid entry, please!"<<endl;
	break;
}
r1.display();
	return 0;
}
