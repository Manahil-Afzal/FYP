/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class Rati{
    private:
    int nume;
    int deno;
    static int count; //declaration 
    public:
   
    //default constuctor
    Rati(){
        cout<<"Default Constructor"<<endl;
        count++;
    }

    //parameterized constucter
    Rati(int x1,int x2){
        nume=x1;
        if(x2!=0){
            deno=x2;
        }else{
            cout<<"Error:Denominator cannot be zero.setting denominator to 1."<<endl;
            deno=1;
        }
        count++;
    }
    
    //copy constructor
    Rati (const Rati &x){   
        nume=x.nume;
        deno=x.deno;
        count++;
    }

    //( * )opreator overloading
    Rati operator*(const Rati&s)const{
        Rati res;
        res.nume=nume*s.nume;
        res.deno=deno*s.deno;
        return res;
    }

    //( / )opreator overloading
    Rati operator/(const Rati&s)const{
        Rati res;
        res.nume=nume*s.deno;
        res.deno=deno*s.nume;
        return res;
        
    }
  
   void  getData(){
        cout<<"enter numerator of a rational number "<<endl;
        cin>>nume;
        cout<<"enter denominator of a rational number "<<endl;
        cin>>deno;
        if(deno==0){
            cout<<"Error:Denominator cannot be zero.setting denominator to 1."<<endl;
            deno=1;
         }
    }
    void display()const{
        cout<<nume<<"/"<<deno<<endl;
    }
//static object function
    static int getcount(){
        return count;

    }
};

//static object intializing 
int Rati::count=0;

int main()
{
    Rati num1(3,4);
    Rati num2;
    num2.getData();
    Rati num3=num1 * num2;
    Rati num4=num1 / num2;
    num3.display();
    num4.display();
    cout<<"numbers of rational objects created : "<<Rati::getcount()<<endl; 
return 0;
}