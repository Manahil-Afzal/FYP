/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
class Rational {
private:
    int numerator;
    int denominator;
    static int count;
public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting it to 1.\n";
            denominator = 1;
        }
        count++;
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }

    static int getCount() {
        return count;
    }

    void getInputs() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;
        std::cout << "Enter denominator (non-zero): ";
        std::cin >> denominator;
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting it to 1.\n";
            denominator = 1;
        }
    }

    Rational operator*(const Rational& other) const {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational operator/(const Rational& other) const {
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }

    void display() const {
        std::cout << "Result: " << numerator << "/" << denominator << std::endl;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(2, 3);
    Rational r2;
    r2.getInputs();

    Rational multiplication = r1 * r2;
    Rational division = r1 / r2;

    multiplication.display();
    division.display();

    std::cout << "Total number of Rational objects created: " << Rational::getCount() << std::endl;

    return 0;
}
