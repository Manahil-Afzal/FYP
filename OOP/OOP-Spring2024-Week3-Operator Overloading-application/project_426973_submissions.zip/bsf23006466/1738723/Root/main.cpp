/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class demo{
     float numerator;
     float denominator;
     float result;
    
     public:
            static int objCount ;
            demo(float nom , float denom){
                numerator=nom;
                while(denom==0){
                      cout<<"Enter valid denominator: it can't be 0 "<<endl;
                      cin>>denom;   
            }
            denominator=denom;
            objCount++;
   }
   
            demo(demo &obj0){
            numerator=obj0.numerator;        
            denominator=obj0.denominator;
            objCount++;   
            }
            
            void operator * (demo& obj){
                numerator*=obj.numerator;
                denominator*=obj.denominator;           
                result=numerator* denominator;
            }
            
            void show(){
                cout<<"Numerator : "<<numerator<<endl;
                cout<<"Denomerator : "<<denominator<<endl;
                cout<<"Result : "<<result<<endl;
            }
            
            void putdata(){
                cout<<"Enter nomerator : ";
                cin>>numerator;
                cout<<"Enter Denominator (can't be a 0) : ";
                cin>>denominator;
                while(denominator==0){
                      cout<<"Enter valid denominator: it can't be 0 "<<endl;
                      cin>>denominator;
                      
                 }
            }    
            demo(){
                objCount++;
                cout<<"default constractor is executed "<<endl;
                }  
                
            void operator / (demo& obj){
                
                numerator*= obj.numerator;
                denominator*=obj.denominator;           
                result=(numerator/denominator);
            }  
            void objnumbr(){
                cout<<"objects are "<<objCount;
            }
   };
             
                   
   int demo::objCount=0;
   int main(){
       demo obj1(2,2);
       demo obj2=obj1;
       obj2*obj1;
       cout<<"Result after multiplication with the other object of same values "<<endl;
       obj2.show();
       demo obj3;
       obj3.putdata();
       demo obj4=obj3;
       obj4/obj3;
       cout<<"result will be given after the multiplication with the other object of same values"<<endl;
       obj4.show();
       obj4.objnumbr();
       
       return 0;
       }