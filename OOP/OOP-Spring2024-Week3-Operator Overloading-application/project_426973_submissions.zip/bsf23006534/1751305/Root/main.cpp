/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count;

public:
    Rational(int num = 0, int denom = 1) {
        numerator = num;
        if (denom == 0) {
            cerr << "Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        } else {
            denominator = denom;
        }
        count++;
    }

    Rational(const Rational& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    void getInput() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cerr << "Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        }
    }

    void display() const {
        cout << numerator << "/" << denominator;
    }

    static int getCount() {
        return count;
    }

    Rational operator*(const Rational& other) const {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational operator/(const Rational& other) const {
        if (other.numerator == 0) {
            cerr << "Cannot divide by zero. Returning 0/1." << endl;
            return Rational(0, 1);
        }
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    Rational r2(r1);

    Rational r3;
    r3.getInput();

    cout << "Count of Rational objects: " << Rational::getCount() << endl;

    cout << "Multiplication: ";
    r1.display();
    cout << " * ";
    r2.display();
    cout << " = ";
    (r1 * r2).display();
    cout << endl;

    cout << "Division: ";
    r1.display();
    cout << " / ";
    r3.display();
    cout << " = ";
    (r1 / r3).display();
    cout << endl;

    return 0;
}
