/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    int count; 

public:
    Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom), count(1) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator), count(1) {}

    ~Rational() {}

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    Rational multiply(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    Rational divide(const Rational& other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    int getCount() const {
        return count;
    }

    void display() {
        cout << "Result: " << numerator << "/" << denominator << endl;
    }
};

int main() {
    Rational r1, r2(3, 4);
    r1.input();
    Rational r3 = r1.multiply(r2);
    Rational r4 = r1.divide(r2);

    cout << "Multiplication:" << endl;
    r3.display();

    cout << "Division:" << endl;
    r4.display();

    cout << "Total Rational objects created: " << r1.getCount() << endl;

    return 0;
}