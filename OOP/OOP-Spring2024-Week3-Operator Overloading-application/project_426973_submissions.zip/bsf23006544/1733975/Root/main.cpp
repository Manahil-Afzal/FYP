/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    RationalNumber(int num = 0, int denom = 1): numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++; // Increment count when a new object is created
    }

    // Copy constructor
    RationalNumber(const RationalNumber &other): numerator(other.numerator), denominator(other.denominator) {
        count++; // Increment count when a new object is created
    }

    // Method to take input of numerator and denominator from the user
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Method to display the rational number
    void display() const {
        cout << numerator << "/" << denominator;
    }

    // Static method to get the count of objects
    static int getCount() {
        return count;
    }

    // Overloading multiplication operator
    RationalNumber operator*(const RationalNumber &other) const {
        RationalNumber result;
        result.numerator = this->numerator * other.numerator;
        result.denominator = this->denominator * other.denominator;
        return result;
    }

    // Overloading division operator
    RationalNumber operator/(const RationalNumber &other) const {
        RationalNumber result;
        result.numerator = this->numerator * other.denominator;
        result.denominator = this->denominator * other.numerator;
        return result;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1, num2;
    num1.input();

    // Use copy constructor to initialize num2 from num1
    RationalNumber num3 = num1;

    cout << "Enter values for the second rational number:" << endl;
    num2.input();

    // Display count of objects
    cout << "Number of rational number objects created: " << RationalNumber::getCount() << endl;

    // Perform multiplication and division
    RationalNumber product = num1 * num2;
    RationalNumber quotient = num1 / num2;

    // Display results
    cout << "Multiplication result: ";
    product.display();
    cout << endl;

    cout << "Division result: ";
    quotient.display();
    cout << endl;

    return 0;
}