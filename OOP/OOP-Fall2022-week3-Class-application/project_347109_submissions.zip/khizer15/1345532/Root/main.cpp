#include <iostream>
using namespace std;

class Utility_bill
{   public:
	string name;
	int bill_no;
	int units;
	string address;
	
		void input_func()
		{
			cout<<"enter your name:"<<endl;
					cin>>name;
			cout<<"enter your bill number:"<<endl;
					cin>>bill_no;
			cout<<"enter consumed units:"<<endl;
					cin>>units;
			cout<<"enter your current address:"<<endl;
					cin>>address;
		}
		
		
		void output_func()
	{
			int total;
			if (units<300)
		{
			
				 total=units*8;
					cout<<"your bill is:"<<total<<endl;
					cout<<"your name is:"<<name<<endl;
					cout<<"your bill number is:"<<bill_no<<endl;
					cout<<"your consumed units are:"<<units<<endl;
					cout<<"your current address is:"<<address;
				
		}
			else if ( units>=300 && units<1000 )
		{
		
				total=units*5;
					cout<<"your bill is:"<<total<<endl;
					cout<<"your name is:"<<name<<endl;
					cout<<"your bill number is:"<<bill_no<<endl;
					cout<<"your consumed units are:"<<units<<endl;
					cout<<"your current address is:"<<address;
		}
			else if (units>999)
		{
			
				total=units*14;
					cout<<"your bill is:"<<total<<endl;
					cout<<"your name is:"<<name<<endl;
					cout<<"your bill number is:"<<bill_no<<endl;
					cout<<"your consumed units are:"<<units<<endl;
					cout<<"your current address is:"<<address;
		}
	}
};

int main ()
{
	Utility_bill obj;
	obj.input_func();
	obj.output_func();
	return 0;
}