/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill
{
	public:
		string customer_name;
		int bill_number;
		int units,unit_price,total_amount;
		
		void getdetails();
		void putdetails();
};

void utility_bill :: getdetails()
{
	cout<<"enter customer name : "<<endl;
	cin>>customer_name;
	cout<<"enter bill number : "<<endl;
	cin>>bill_number;
	cout<<"enter units consumed in month : "<<endl;
	cin>>units;
	
	if (units < 300)
	unit_price=8;
	else if( units >= 300 && units < 1000 )
	unit_price=5;
	else if ( units > 999 )
	unit_price=14;
	total_amount=units*unit_price;
}

void utility_bill :: putdetails()
{
	cout<<"customer name : "<<customer_name<<endl;
	cout<<"bill number : "<<bill_number<<endl;
	cout<<"units : "<<units<<endl;
	cout<<"total amount : "<<total_amount<<endl;
	
}
int main ()
{
	utility_bill elecbill;
	elecbill.getdetails();
	elecbill.putdetails();
	
	return 0;
}