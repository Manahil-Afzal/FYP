/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14*/



#include<iostream>
#include<string.h>
using namespace std;
class utilitybill{
    public:
    string customernme,customeradress;
    double billno,unitconsume,totalbill;
     void getinfo(){
        cout<<"Please Enter Customer Name:"<<endl;
        cin>>customernme;
         cout<<"Please Enter Bill No.:"<<endl;
        cin>>billno;
         cout<<"Please Enter Unit Consumes:"<<endl;
        cin>>unitconsume;
         cout<<"Please Enter Customer Adress:"<<endl;
        cin>>customeradress; 
    }
     void calculate(){
         if(unitconsume<300)
        {
            totalbill=unitconsume*8;
            cout<<"BILL DETAIL:"<<endl;
            cout<<"Coustomer Name:"<<customernme<<endl;
            cout<<"Customer Adress:"<<customeradress<<endl;
            cout<<"Bill No:"<<billno<<endl;
            cout<<"YOUR TOTAL BILL PRICE WITH "<<unitconsume<<" UNIT IS RS. "<<totalbill<<endl;
        }
        else if(unitconsume>=300&&unitconsume<1000){
                totalbill=unitconsume*5;
            cout<<"BILL DETAIL:"<<endl;
            cout<<"Coustomer Name:"<<customernme<<endl;
            cout<<"Customer Adress:"<<customeradress<<endl;
            cout<<"Bill No:"<<billno<<endl;
            cout<<"YOUR TOTAL BILL PRICE WITH  "<<unitconsume<<" UNIT IS RS. "<<totalbill<<endl;
        }
        else if(unitconsume>999){
                totalbill=unitconsume*14;
            cout<<"BILL DETAIL:"<<endl;
            cout<<"Coustomer Name:"<<customernme<<endl;
            cout<<"Customer Adress:"<<customeradress<<endl;
            cout<<"Bill No:"<<billno<<endl;
            cout<<"YOUR TOTAL BILL PRICE WITH  : "<<unitconsume<<" UNIT IS RS. "<<totalbill<<endl;
    }
     else
        cout<<"Invalid Information";




     }

};
int main(){
    utilitybill obj;
    obj.getinfo();
    obj.calculate();
    return 0;
}