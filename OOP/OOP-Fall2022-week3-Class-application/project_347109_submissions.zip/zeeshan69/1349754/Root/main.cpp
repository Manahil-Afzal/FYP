/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
#include<string>
using namespace std;

class utility_bill
{
     private:
     	 char cusName[25];
         int billNo;
         int units;
         double bill;
         string cusAdd;
   
    public:
        void get()
        {
                 cout<<"Enter Details of Customer Below: \n" <<endl;
                 cout<<"Enter Customer Name = ";
                 cin>>cusName;
                 cout<<"Enter Bill No = ";
                 cin>>billNo;
                 cout<<"Enter Number of Units used = ";
                 cin>>units;
                 cout<<"Enter Customer Address = ";
                 cin>>cusAdd;
         }

        void put()
         {
                cout<<"\nDetails of Customer are : " <<endl;
                cout<<"\nCustomer Name is : "<<cusName;
                cout<<"\nBill No is : "<<billNo;
                cout<<"\nNumber of Units Consumed : "<<units;
                cout<<"\nTotal Bill of Customer is : "<<bill;
                cout<<"\nCustomer Address is : "<<cusAdd;
         }

        void calc_bill()
        {
                if(units<300)
                       bill=units*8;
               else if(units>=300,units<=999)
                       bill=units*5;
               else
                       bill=units*14;
         }
};

int main()
{
    utility_bill b1;
    b1.get();
    b1.calc_bill();
    b1.put();

    cout<<"\n";

    return 0;
}