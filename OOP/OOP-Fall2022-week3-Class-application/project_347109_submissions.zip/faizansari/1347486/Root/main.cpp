/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class UB{
	public:
		string C_name;
		int B_number;
		int U_consumed;
		string C_address;
		
	void input_function(){
		cout<<"Name: ";
		cin>>C_name;
		cout<<"Bill number: ";
		cin>>B_number;
		cout<<"Units consumed: ";
		cin>>U_consumed;
		cout<<"Customer address: ";
		cin>>C_address;
		
	};
	void output_function(){
		int T_Bill;
		if(U_consumed<300){
			T_Bill = U_consumed * 8;
			cout<<"Customer Name: "<<C_name<<endl;
			cout<<"Bill_number: "<<B_number<<endl;
			cout<<"Units Consumed: "<<U_consumed<<endl;
			cout<<"Customer Address: "<<C_address<<endl;
			cout<<"Total Bill is: "<<T_Bill<<endl;
		}
		else if(U_consumed>=300 && U_consumed<1000){	
			T_Bill = U_consumed * 5;
			cout<<"Customer Name: "<<C_name<<endl;
			cout<<"Bill_number: "<<B_number<<endl;
			cout<<"Units Consumed: "<<U_consumed<<endl;
			cout<<"Customer Address: "<<C_address<<endl;
			cout<<"Total Bill is: "<<T_Bill<<endl;
		}
		else if(U_consumed>999){	
			T_Bill = U_consumed * 14;
			cout<<"Customer Name: "<<C_name<<endl;
			cout<<"Bill_number: "<<B_number<<endl;
			cout<<"Units Consumed: "<<U_consumed<<endl;
			cout<<"Customer Address: "<<C_address<<endl;
			cout<<"Total Bill is: "<<T_Bill<<endl;
		}
		
	};
};
int main(){
	UB myobj;
	myobj.input_function();
	myobj.output_function();
}