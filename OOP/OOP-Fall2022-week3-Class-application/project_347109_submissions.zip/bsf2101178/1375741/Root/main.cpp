/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class Utility_Bill{
    string customer_name;
    int bill_no;
    int unit_consumed;
    string customer_address;
    int bill_amount;
    int unit_price;
    public:
    void getDetails();
    void putDetails();
};

int main() {
    Utility_Bill billCal;
    billCal.getDetails();
    billCal.putDetails();
}

void Utility_Bill :: getDetails() {
    cout<<"Enter the customer name !"<<endl;
    cin>>customer_name;
    cout<<"Enter the Bill Number !"<<endl;
    cin>>bill_no;
    cout<<"Enter the No. of Units that are consumed !"<<endl;
    cin>>unit_consumed;
    cout<<"Enter the Customer Address: "<<endl;
    cin>>customer_address;
    if(unit_consumed < 300)
        unit_price = 8;
    else if(unit_consumed >=300 && unit_consumed < 1000)
      unit_price = 5;
    else
      unit_price = 14;
    
    bill_amount = (int) unit_consumed * unit_price;
}

void Utility_Bill :: putDetails() {
    cout<<"\t" "\t" "\t" "Bill Deatils are: " <<endl;
    cout<<"Customer Name is: "<<customer_name<<endl;
    cout<<"Bill No. is: "<<bill_no<<endl;
    cout<<"No. of units consumed :"<<unit_consumed<<endl;
    cout<<"Customer Adderss is: "<<customer_address<<endl;
    cout<<"Bill Amount is: "<<bill_amount<<endl;
}