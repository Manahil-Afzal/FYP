/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utilitybill
{
private:
int bill;
char custname;
int billnum;
int unitconsume;
public:
void get()
{
    cout<<"Enter Detail Of Customer:";
    cout<<"Enter Customer Name:";
    cin>>custname;
    cout<<"Enter Bill Number:" ;
    cin>>billnum;
    cout<<"Enter Units Consume:";
    cin>>unitconsume;
}
void printdata()
{
    cout<<"Bill No Is:"<<billnum;
    cout<<"Customer Name Is:"<<custname;
    cout<<"Unit Consume Are:"<<unitconsume;
    cout<<"Bill:"<<bill;
}
void calcbill()
{
    if (unitconsume<300 )
    bill=unitconsume*8;
    else if (unitconsume>=300 && unitconsume<100)
    bill=unitconsume*5;
    else if (unitconsume>999)
    bill=unitconsume*14;
}
};
int main ()
{
    utilitybill b1;
    b1.get();
    b1.printdata();
    b1.calcbill();
    return 0;
}