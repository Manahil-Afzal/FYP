
/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include<string>
using namespace std;
class utilityBills {
private:
	string customername;
	long BillNo;
	int UnitConsumed;
	string customerAddress;
	int billamount;
public:
	void takeInput();
	void calculate();
	void Display();
	utilityBills()
	{
		customername = "";
		BillNo = 0;
		UnitConsumed = 0;
		customerAddress = "";
		billamount=0;
	}
};
void utilityBills::takeInput() {
	cout << "enter customer name : ";
	
	getline(cin, customername);
	cout << "enter Bill No : ";
	cin >> BillNo;
	cout << "enter unit consumed : ";
	cin >> UnitConsumed;
	cout << "enter customer address : ";
	cin.ignore();
	getline(cin, customerAddress);

 }
void utilityBills::calculate() {

	if (UnitConsumed < 300) {
		billamount = UnitConsumed * 8;

	}
	else if (UnitConsumed >= 300 && UnitConsumed < 1000) {
		billamount = UnitConsumed * 5;
	}
	else {
		billamount = UnitConsumed * 14;


	}
}
	void utilityBills::Display() 
	{
		cout << "customer name is : " << customername << endl;
		cout << " Bill No  is : ";
		cout << BillNo << endl;
		cout << "unit consumed are : ";
		cout << UnitConsumed << endl;
		cout << "customer address : ";
		cout << customerAddress << endl;
		cout << "Bill is : " << billamount;
	}

int main(){
	utilityBills obj;
	obj.takeInput();
	obj.calculate();
	obj.Display();
}
