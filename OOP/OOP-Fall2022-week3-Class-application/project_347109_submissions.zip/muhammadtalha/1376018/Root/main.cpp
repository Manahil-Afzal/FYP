/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;

class hmm{
	public:
	string customer_name;
	int    bill_number;
	int    units_consumed;
	string customer_address;
	


void get(){
	cout<<"enter   you name    :";
	cin>>customer_name;
	
	cout<<"enter bill nob      : ";
	cin>>bill_number;
	
	cout<<"enter consumed unit :";
	cin>>units_consumed;
	
	cout<<"customer adress     :";
	cin>>customer_address;
	

	cout<<endl;
	
}

void showdata(){
	cout<<endl;
	cout<<"name is            : "<<customer_name<<endl;
	cout<<"bill number is     : "<<bill_number<<endl;
	cout<<"consumed units are : "<<units_consumed<<endl;
	cout<<"customer adress    : "<<customer_address<<endl;
		if(units_consumed<300)
	cout<<"totall bill : "<<units_consumed * 8;
	
	if(units_consumed>=300 && units_consumed<100)
	cout<<"totall bill  : "<<units_consumed * 5;
	if( units_consumed>=100)
	cout<<"totall bill  : "<<units_consumed * 14;
	
	         
}
};

int main(){
	hmm o;
	o.get();
	o.showdata();
	
	return 0;
}