/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class Bill
{
private:
	string Name;
	int BillNumber;
	int units;
	int Totalamount;

public:
	void getDetails();
	void putDetails();

};
void Bill::putDetails()
{
	cout << "Electricity Bill Details: " << endl;
	cout << "Name: " << Name << endl << "Bill Number: " << BillNumber << endl << "Units: " << units << endl;

	if (units < 300)
	{
		Totalamount = units * 4;
	}
	else if (units >= 300 && units < 1000)
	{
		Totalamount = units * 5;
	}
	else
		Totalamount = units * 7;
	cout << "Amount:" << Totalamount << endl;
}
void Bill::getDetails()
{
	cout<<"Enter name: ";
	cin>>Name;
	cout<<"Enter bill number: ";
	cin>>BillNumber;
	cout<<"Enter total units consumed: ";
	cin>>units;
}

int main()
{
	Bill user;	
	user.getDetails();
	user.putDetails();
	return 0;
}