/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string.h>
using namespace std;
class EleBill
{
private:
    int cur_Unit,pre_Unit,amt,unit;

public:
    void get();
    void printAmt();
};
void EleBill::get()
{
    cout << "Enter previous unit:" << endl;
    cin>>pre_Unit;
     cout << "Enter current unit:" << endl;
    cin>>cur_Unit;
}
/*1  -  100  = 1
101  -  200  = 2
201  -  300  = 3
above  300  -  5*/

void EleBill::printAmt() 
{
    unit=cur_Unit-pre_Unit;
    if(unit>0 && unit<=100)
    {
        amt=unit*1;
    }
    if(unit>100 && unit<=200)
    {
        amt=unit*2;
    }
    if(unit>200 && unit<=300)
    {
        amt=unit*3;
    }
    if(unit>300)
    {
        amt=unit*5;
    }
    cout << "Bill charge: " <<amt <<endl;

}

int main()
{
    EleBill o;

    o.get();
    o.printAmt();

    
}
