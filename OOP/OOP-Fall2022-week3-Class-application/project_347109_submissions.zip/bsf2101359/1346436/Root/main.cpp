/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer 
address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class Utility_bill{
	public: 
	     string cust_name, cust_add;
	     int bill_no, unit_cons, bill_amount, perunit; 
};
int main (){
	 Utility_bill obj; 
	cout<<"Enter customer name: "<<endl; 
	cin>> obj.cust_name; 
	cout<< "Enter bill no: "<<endl; 
	cin>>obj.bill_no;
	cout<<"Enter unit consumed: "<<endl;
	cin>>obj.unit_cons; 
	cout<<"Enter customer address: "<<endl;
	cin>>obj.cust_add; 
	    
	    if(obj.unit_cons<300){ 
	    obj.perunit =8;
	    cout<<"per unit price is 8" ;
	    
		}
		if(obj.unit_cons>=300 && obj.unit_cons<1000){
			obj.perunit =5;
			cout<< "per unit price is 5";
			
		}
		if(obj.unit_cons>999){
			obj.perunit =14;
		}
		obj.bill_amount=obj.unit_cons*obj.perunit;
		
		
		cout<<endl<<"Displying information:"<<endl;
		cout<<"Customer name: "<<obj.cust_name<<endl;
		cout<<"Bill NO: "<<obj.bill_no<<endl;
		cout<<"Unit Consumed:"<<obj.unit_cons<<endl;
		cout<<"Per unit: "<<obj.perunit<<endl;
		cout<<"Total bill amount:"<<obj.bill_amount<<endl;
}