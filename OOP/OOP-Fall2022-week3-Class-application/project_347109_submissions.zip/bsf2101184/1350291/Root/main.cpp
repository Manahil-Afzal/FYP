/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays 
the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are
greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
#include<string>
using namespace std;
class utility_bill
{
    public:
    string  name;
    int number;
    int units ;
    string  address;
    float amount;
};
int main()
{
    
utility_bill obj;
cout<< "Enter the customer name:";
cin>>obj.name;
cout<< "Enter the bill number:";
cin>>obj.number;
cout<< "Enter the units consumed:";
cin>>obj.units;
int units=300;
if( units<300){
    cout<<"unit price is 8";}
    else
    if( units>=300)
    {cout<<"unit price is 5";}
    if( units>999)
   { cout<<"unit price is 14";
}
cout<< "Enter the customer address:";
cin>>obj.address;
int price;
 float amount=units*price;
cout<< "the total amount of bill is:"<<obj.amount;
return 0;
}