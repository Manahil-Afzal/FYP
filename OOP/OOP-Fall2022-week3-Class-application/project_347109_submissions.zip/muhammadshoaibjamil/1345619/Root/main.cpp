/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class Utility_Bill{
	private:
		string name;
		int number;
		string address;
		int units;
	
	public:
		void getData();
		void putData();
};

void Utility_Bill::getData(){
	cout<<"Enter customer name:";
	cin>>name;
	cout<<"Enter the customer number:";
	cin>>number;
	cout<<"Enter the customer address:";
	cin>>address;
	cout<<"Enter your consumed units:";
	cin>>units;
}

void Utility_Bill::putData(){
	int price;
	cout<<"Customer name:"<<name<<endl;
	cout<<"customer number:"<<number<<endl;
	cout<<"customer address:"<<address<<endl;
	if(units < 300){
		price = units * 8;
		cout<<"The Bill is RS."<<price;
	}
	else if(units >= 300 or units <1000){
		price = units * 5;
		cout<<"The Bill is RS."<<price;
	}
	else{
		price = units * 14;
		cout<<"The Bill is RS."<<price;
	}
}

int main(){
	Utility_Bill myObj;
	myObj.getData();
	myObj.putData();
	return 0;
}