/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class utilitybill 
{
    public:
    string name;
    string billno;
    float uc;
    string address;
};


float bill (float ta)
{
    utilitybill customer;
    float tb;
    cout << "Enter customer's name : ";
    getline (cin, customer.name);
    cout << "Enter bill number : ";
    getline (cin, customer.billno);
    cout << "Enter consumed units : ";
    cin >> customer.uc;
    cout << "Enter address : ";
    cin >> customer.address;
    if (customer.uc < 300)
    tb = customer.uc * 8;
    else if (customer.uc > 300 && customer.uc < 1000)
    tb = customer.uc * 5;
    else
    tb = customer.uc * 14;
    return tb;
}

int main()
{
    float ta;
    ta = bill(ta);
    cout << "Total amount to be paid : " << ta << endl;
    return 0;
}
