/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class  bill{
	private:
	char name[20];
	int number;
	int consumed;
	int price;
	char address[50];
	public:
	int unit(){
		cout << "enter your name: "<<endl;
		cin.getline(name, 20);
		cout << "enter your address: "<<endl;
		cin.getline(address, 50);
		cout<<"enter your bill number: "<<endl;
		cin>> number;
		cout << "enter your consuemd units: "<<endl;
		cin>> consumed;
		
		
	}	
	int display(){
		cout << "your name: "<<name<<endl;
		cout <<"your bill number: "<< number<<endl;
		cout <<"your address: "<< address<<endl;
		cout <<"your consumed units: "<<consumed<<endl;
		
		price==0;
		if (consumed<300){
		
		     price=consumed*8;
	}
		     else if (consumed>=300 && consumed <1000){
			 
		     price=consumed*5;
		 }
			 else{
			 
		     price=consumed *14;
		 }
		     cout <<"your total bill is : "<< price;
		 }
	
		
	};
	int main(){
		bill x;
		x.unit();
		x.display();
		return 0;
	}
	
	
	