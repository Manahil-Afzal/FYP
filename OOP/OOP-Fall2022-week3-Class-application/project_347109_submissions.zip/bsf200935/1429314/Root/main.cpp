/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class Utility_Bill{
	private:
		string cust_name;
		int bill_num;
		int units_cons;
		char cust_address[255];
		int amount;
	
	public:
		void getData()
		{
			cout << "Enter your name : ";
			cin >> cust_name;
			cout << endl << "Enter Bill Number : ";
			cin >> bill_num;
			cout << endl << "Enter units consumed : ";
			cin >> units_cons;
			cout << endl << "Enter your address ; ";
			cin >> cust_address;
		}
		void putData()
		{
			cout << "Customer Info : " <<endl;
			cout << "Name : " << cust_name << endl;
			cout << "Bill Number : " << bill_num << endl;
			cout << "Address : " << cust_address << endl;
			if(units_cons < 300)
				cout << "Amount : " << (amount = units_cons * 8) << endl;
			else if(units_cons >= 300 && units_cons < 1000)
				cout << "Amount : " << (amount = units_cons * 5)<< endl;
			else if(units_cons > 999)
				cout << "Amount : " << (amount = units_cons * 14)<< endl;	
		}
};
int main()
{
	Utility_Bill b1;
	b1.getData();
	b1.putData();
	return 0;
}