/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14
 */
 #include <iostream>

using namespace std;

class Cal_E_bill{
int cus_Id;
char cus_Name[50];
int units;
double bill_Bal;

public:
    void get()
    {
        cout << "Please enter detail of customer below: \n" << endl;
        cout << "Enter customer id: " << endl;
        cin>>cus_Id;
        cout << "Enter customer Name: " << endl;
        cin>>cus_Name;
         cout << "Enter the number of units consumed: " << endl;
        cin>>units;
    }
    void put()
    {
        cout << "\nCustomer details \n" << endl;
        cout << "\nCustomer id is: " <<cus_Id<< endl;
        cout << "\nCustomer Name is: " << cus_Name<<endl;
         cout << "\nNumber of units consumed: " << bill_Bal<<endl;
        cin>>units;
    }
    
	 void calc_Amt(){
	 
    
        if(units<300)
            bill_Bal=units*4;
        else if(units<1000)
            bill_Bal=units*5;
            else
            bill_Bal=units*7;
}
};

int main()
{
    cout << "Here your output\n\n" << endl;
    Cal_E_bill b;
    b.get();
    b.calc_Amt();
    b.put();


    return 0;
}