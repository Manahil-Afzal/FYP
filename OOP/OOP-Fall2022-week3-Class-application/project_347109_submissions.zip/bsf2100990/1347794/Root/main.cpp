/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utilitybills{
	private:
	string name;
	int bill_number;
	int unit_consumed;
	int perunit_price;
	int bill_amount;
	string customer_address;
	public:
	void customerinput(){
		cout<<"enter name:";
		cin>>name;
		cout<<"enter bill number:";
		cin>>bill_number;
		cout<<"enter unit consumed:";
		cin>>unit_consumed;
		cout<<"enter address of the customer ";
		cin>>customer_address;
		
	}
	int billamount(){
		if(unit_consumed<300){
			perunit_price=8;
			bill_amount=unit_consumed*perunit_price;
		}
		else if(unit_consumed>=300&&unit_consumed<1000)
		{
			perunit_price=5;
			bill_amount=unit_consumed*perunit_price;
		}
		else if(unit_consumed>999){
			perunit_price=14;
			bill_amount=unit_consumed*perunit_price;
		}
	}
	int display(){
		cout<<"\nname of the customer is:"<<name<<"\nbill number of the customer is:"<<bill_number<<"\nunit consumed by customer is:"
		<<unit_consumed<<"\naddress of customer is:"<<customer_address<<"\ntotal bill amount of the customer is:"<<bill_amount;
	}
	
};
int main (){
	utilitybills customer1;
	customer1.customerinput();
	customer1.billamount();
	customer1.display();
}