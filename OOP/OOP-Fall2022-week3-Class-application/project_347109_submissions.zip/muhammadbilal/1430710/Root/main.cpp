/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string>
using namespace std;

class Utility_bill{
    private:
    int bill_Number;
    string address;
    string customer_Name;
    int bill_Units;
    double bill;
    
    public: 
    void getData()
    {
        cout<<"Enter Customer's name: "<<endl;
        getline(cin, customer_Name);
        cout<<"Enter Bill Number: "<<endl;
        cin>>bill_Number;
        cout<<"Enter number of units consumed: "<<endl;
        cin>>bill_Units;
        cout<<"Enter the address: "<<endl;
        cin>>address;
    }
    void calculate(){
        if(bill_Units<300)
        bill = bill_Units*8;
        else if (bill_Units<1000)
        bill = bill_Units*5;
        else
        bill = bill_Units*14;
        
        cout<<"\nCustomer Name: "<<customer_Name<<endl;
        cout<<"Bill Number: "<<bill_Number<<endl;
        cout<<"Address: "<<address<<endl;
        cout<<"Units consumed: "<<bill_Units<<endl;
        cout<<"Total bill is: "<<bill;
    }
};
int main()
{
    Utility_bill ub1;
    ub1.getData();
    ub1.calculate();
    return 0;
}