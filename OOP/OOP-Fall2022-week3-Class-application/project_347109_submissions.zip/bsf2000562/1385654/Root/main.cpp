/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class Bill
{
	string customerName;
	string billNo;
	int unitsConsumed;
	string address;
	//char address[100];
	int billAmount;
	public:
	void getDetails();
	void putDetails();
};
void Bill::getDetails()
{
	cout<<"Enter customer name : ";
	getline(cin,customerName);
	cout<<"Enter the address:";
     	getline(cin,address);
	
	cout<<"Enter bill number : ";
	cin>>billNo;
	
     	//cin.getline(address,50);
	cout<<"Enter consumed units : ";
    cin>>unitsConsumed;
	if(unitsConsumed<300)
	billAmount=unitsConsumed*8;
	else if(unitsConsumed>=300 && unitsConsumed<1000)
	billAmount=unitsConsumed*5;
	else if(unitsConsumed>999)
	billAmount=unitsConsumed*14;
}
void Bill::putDetails()
{
	cout<<"\nCustomer name : "<<customerName<<endl;
	cout<<"Bill no. : "<<billNo<<endl;
	cout<<"Consumed units : "<<unitsConsumed<<endl;
	cout<<"Address:"<<address<<endl;
	cout<<"Bill amount : "<<billAmount<<endl;	
}
int main()
{
	Bill std;
	std.getDetails();
	std.putDetails();
	return 0;
}