/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;

class utility_bill{
    private: 
    
    string customer_name;
    string customer_address;
    int bill_no, units_consumed;
    int unit_price;
    long bill_cal;
    
    public:
    void get()
    {
        cout<<"Enter you name here: "<<endl;
        getline(cin,customer_name);
        cout<<"Enter your address here: "<<endl;
        getline(cin,customer_address);
        cout<<"Enter your bill no here: "<<endl;
        cin>>bill_no;
        cout<<"Enter your units consumed here: "<<endl;
        cin>>units_consumed;
        cout<<"Your entered name is: "<<customer_name<<endl;
        cout<<"Your entered address is: "<<customer_address<<endl;
        cout<<"Your entered bill number is: "<<bill_no<<endl;
        cout<<"You have consumed "<<units_consumed<<" units"<<endl;
        if(units_consumed<300)
        {
        unit_price=8;
        }
        else if(units_consumed>=300 && units_consumed<1000)
        {
        unit_price=5;
        }
        else if(units_consumed>999)
        {
        unit_price=14;
        }
        else
        cout<<"You have entered a wrong value"<<endl;
        bill_cal=units_consumed*unit_price;
        cout<<"Your total payable bill is:"<<bill_cal;
    }
};

int main()
{
    utility_bill data;
    data.get();
    
    return 0;
}
