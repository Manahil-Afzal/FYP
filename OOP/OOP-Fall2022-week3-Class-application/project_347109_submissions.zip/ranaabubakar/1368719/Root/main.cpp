/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill{
public:
//	data members
	string name;
	int bill_no;
	int unit;
	float bill; 
	string customer_address;
//  functions
 void in(){
  cout<<"Enter Details"<<endl;
  cout<<"Enter Name of customer:"<<endl;
		getline(cin,name);
   cout<<"Enter bill number of customer:"<<endl;
	cin>>bill_no;
	cout<<"Enter units"<<endl;
		cin>>unit;
 cout<<"Enter adress of customer:"<<endl;
		getline(cin,customer_address);
	cin.ignore(); 
}
 void out(){
  	cout<<"the  details of customer is "<<endl;
				cout<<" Name of customer is :"<<name<<endl;
				cout<<" bill number of customer is:"<<bill_no<<endl;
				cout<<" adress of customer is:"<<customer_address<<endl;
					cout<<"units consumed:"<<unit<<endl;
                 cout<<"Bill of Customer is Rs: "<<bill<<endl; 

 }
     void calc() 
         { 
                 if(unit<=300) 
                        bill=unit*8; 
                else if(unit>300 & unit<1000) 
                        bill=unit*5; 
                else if(unit>1000) 
                        bill=unit*14; 
          } 
};
int main(){
   utility_bill obj1;
   obj1.in();
   obj1.calc();
   obj1.out();
}