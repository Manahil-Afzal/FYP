/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class Utility_bill{
	public:
		string customer_name;
		int bill_number;
		int units_consumed;
		string customer_address;
		
	void input_function(){
		cout<<"NOTE: Use _ to give space in name."<<endl;
		cout<<"Enter customer name: ";
		cin>>customer_name;
		cout<<"Enter your bill number: ";
		cin>>bill_number;
		cout<<"Enter unit consumed: ";
		cin>>units_consumed;
		cout<<"Enter customer address: ";
		cin>>customer_address;
		
	};
	void output_function(){
		int Total_bill;
		if(units_consumed<300){
			Total_bill = units_consumed * 8;
			cout<<"Customer Name: "<<customer_name<<endl;
			cout<<"Bill_number: "<<bill_number<<endl;
			cout<<"Units Consumed: "<<units_consumed<<endl;
			cout<<"Customer Address: "<<customer_address<<endl;
			cout<<"Total Bill is: "<<Total_bill<<endl;
		}
		else if(units_consumed>=300 && units_consumed<1000){	
			Total_bill = units_consumed * 5;
			cout<<"Customer Name: "<<customer_name<<endl;
			cout<<"Bill_number: "<<bill_number<<endl;
			cout<<"Units Consumed: "<<units_consumed<<endl;
			cout<<"Customer Address: "<<customer_address<<endl;
			cout<<"Total Bill is: "<<Total_bill<<endl;
		}
		else if(units_consumed>999){	
			Total_bill = units_consumed * 14;
			cout<<"Customer Name: "<<customer_name<<endl;
			cout<<"Bill_number: "<<bill_number<<endl;
			cout<<"Units Consumed: "<<units_consumed<<endl;
			cout<<"Customer Address: "<<customer_address<<endl;
			cout<<"Total Bill is: "<<Total_bill<<endl;
		}
		
	};
};
int main(){
	Utility_bill myobj;
	myobj.input_function();
	myobj.output_function();
}