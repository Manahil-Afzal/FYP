/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as 
inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price 
is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
 #include<iostream>
 using namespace std;
 class utilitybill
 {
 	private:
 		char name[10];
 		int billnum;
 		int unit;
 		string  address;
 		
 			public:	
 	void data()
	 {
	 	
			
 		 cout <<"enter name of customer";
 		 cin>>name;
 		  cout<<"enter bill num";
 		 cin>>billnum;
 		  cout<<"enter unit consume";
 		 cin>>unit;
 		 cout<<"enter customer address";
 		 cin>>address;
 			} 
 	
 		void calculate()
 		{
 	 		int amount;
 	 		
			  if(unit<=300)	
 			{
 			amount =unit*8;
			 }
		 
 		  if(unit<300,unit>=1000)	
 			{
 			amount =unit*5;
			 }
		 if(unit>=1000)	
 			{
 			amount =unit*14;
			 }
				cout<<"customer bill ammount"<<amount<<endl; 
		 }
void getdata()
{
	cout<<"customer name"<<name<<endl;
	cout<<"bill num "<<billnum<<endl;
	cout<<"unit consume"<<unit<<endl;
	cout<<"customer  address"<<address<<endl;
	
	 	 	
}

 };
 
 int main(){
 	utilitybill a;
 	a.data();
 	a.calculate();
 	a.getdata();
 	
 	return 0;
 	
 }