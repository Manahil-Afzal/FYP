/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class utality
{
    private:
    char cus_name[20];
    int number;
    int units;
    char address[50];
    int bill;
    public:
   void getdata()
     {
    cout<<"Enter customer name:";
    cin.getline(cus_name, 20);
    cout<<"Enter bill number:";
    cin>>number;
    cout<<"Enter unit comsumed:";
    cin>>units;
    cout<<"Enter customer address:";
    cin>>address;
     }
void putdata()
     {
    cout<<"Your name:"<<cus_name<<endl;
    cout<<"your bill number:"<<number<<endl;
    cout<<"your unit consumed:"<<units<<endl;
    cout<<"your address:"<<address<<endl;
     
        if(units<300)
        {
            bill=units*8;
     }
	    else if (units>=300 && units<1000){
		
            bill=units*5;
        }
		else
		{
		
            bill=units*14;
    
	 } 
     cout<<"your total bill is:"<<bill;
}
};   
int main()
{
utality obj;
    obj.getdata();
    obj.putdata();
    return 0;
}/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/