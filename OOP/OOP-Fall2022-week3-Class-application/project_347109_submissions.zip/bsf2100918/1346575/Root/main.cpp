/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
# include<iostream>
using namespace std;
class uBill{
    private:
    string customerName;
    int billNumber;
    int unitsConsumed;
    double bill;
    public:
    
        void get()
        {
            cout<<"enter customer name"<<endl;
            cin>>customerName;
            cout<<"enter bill number"<<endl;
            cin>>billNumber;
            cout<<"enter units consumed"<<endl;
            cin>>unitsConsumed;
        }
        void put()
        {
            cout<<"the customer name is"<<customerName<<endl;
            cout<<"the bill number is"<<billNumber<<endl;
            cout<<"the units consumed are"<<unitsConsumed<<endl;
        }
        void calc()
        {
            int perUnitPrice;
            if(unitsConsumed<300){
             bill=unitsConsumed*8;
             cout<<"the bill is"<<bill<<endl;}
             else if(unitsConsumed<=300&&unitsConsumed<1000){
             bill=unitsConsumed*5;
             cout<<"the bill is"<<bill<<endl;}
             else if(unitsConsumed>999){
             bill=unitsConsumed*14;
             cout<<"the bill is"<<bill<<endl;}
             else
             cout<<" "; }
}; 
    int main()
    {
       uBill p1;
       p1.get();
       p1.put();
       p1.calc();
    }

