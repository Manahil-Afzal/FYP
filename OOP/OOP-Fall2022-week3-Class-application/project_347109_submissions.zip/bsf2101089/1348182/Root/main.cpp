/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
	private:
		string name;
		int bill_number;
		int units_consumed;
		int price_per_unit;
		string customer_adress;
		int bill_value;
	public:
		void input(){
			cout<<"Enter customer name:"<<endl;
			cin>>name;
			cout<<"Enter bill number:"<<endl;
			cin>>bill_number;
			cout<<"Enter units consumer consumed:"<<endl;
			cin>>units_consumed;
			cout<<"Enter customer adress:"<<endl;
			cin>>customer_adress;
		}
		void display(){
		   
			if(units_consumed<300){
				price_per_unit=5;
				
			}
			else if(units_consumed<1000){
				price_per_unit=8;
			
			}
			else{
			price_per_unit=14;
			}
			 bill_value=units_consumed*price_per_unit;
			cout<<"Total bill is:"<<bill_value<<endl;
		}

		
		
};
int main()
{
	bill number1;
	number1.input();

	number1.display();
	return 0;
}