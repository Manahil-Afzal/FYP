/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class Bill
{
	string customerName;
	string billNo;
	int unitsConsumed;
	string address;
	int billAmount;
	public:
	void getDetails();
	void putDetails();
};
void Bill::getDetails()
{
	cout<<"Enter Customer Name: ";
	getline(cin,customerName);
	cout<<"Enter Customer Address: ";
 	getline(cin,address);
	cout<<"Enter Customer Bill No.: ";
	cin>>billNo;
    cout<<"Enter Consumed Units: ";
    cin>>unitsConsumed;
	if(unitsConsumed<300)
	billAmount=unitsConsumed*8;
	else if(unitsConsumed>=300 && unitsConsumed<1000)
	billAmount=unitsConsumed*5;
	else if(unitsConsumed>999)
	billAmount=unitsConsumed*14;
}
void Bill::putDetails()
{
	cout<<"\nCustomer Name: "<<customerName<<endl;
	cout<<"Address: "<<address<<endl;
	cout<<"Bill No.: "<<billNo<<endl;
	cout<<"Consumed Units: "<<unitsConsumed<<endl;
	cout<<"Total Bill Amount: "<<billAmount<<endl;	
}
int main()
{
	Bill obj;
	obj.getDetails();
	obj.putDetails();
	return 0;
}