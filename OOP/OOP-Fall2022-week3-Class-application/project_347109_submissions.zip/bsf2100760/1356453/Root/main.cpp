/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address
as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. 
If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class Utility_Bill{
  private:
  string customer_name;
  long int bill_nmbr;
  int units_consumed;
  string customer_address;
  float price_per_unit;
  float Total_Bill;
  
  public:
  void input();
  void display();
};
void Utility_Bill::input(){
    cout<<"Enter customer name "<<endl;
    cin>>customer_name;
    cout<<"Enter Bill Number "<<endl;
    cin>>bill_nmbr;
    cout<<"Enter Units Consumed "<<endl;
    cin>>units_consumed;
    cout<<"Enter customer's Address "<<endl;
    cin>>customer_address;
    if(units_consumed<300){
        price_per_unit=8;
    }
     else if(units_consumed>=300 && units_consumed<1000){
        price_per_unit=5;
    }
    else{
        price_per_unit=14;
    }
    Total_Bill=units_consumed*price_per_unit;
   
    
}


void Utility_Bill::display(){
     cout<<"Customer name : "<<customer_name<<"                         Bill Number : "<<bill_nmbr<<endl;
      cout<<"Units Consumed : "<<units_consumed<<"                        Address : "<<customer_address<<endl;
      cout<<"Total Bill :        "<<Total_Bill;
    
}
int main(){
    Utility_Bill UB;
    UB.input();
    UB.display();
    
    return 0;
}