/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class bill{
    private:
    string name;
    int bill_number;
    int units_consumed;
    string customer_adress;
    int bill_value;
    public:
    void input(){
        cout<<"enter customer name"<<endl;
        cin>>name;
        cout<<"enter bill number"<<endl;
        cin>>bill_number;
        cout<<"enter units consumed"<<endl;
        cin>>units_consumed;
        cout<<"enter customer adress"<<endl;
        cin>>customer_adress;
    }
    void processing(){
        if(units_consumed<300){
            bill_value=units_consumed*8;
            cout<<bill_value;
        }
        else if(units_consumed<1000){
            bill_value=units_consumed*5;
            cout<<bill_value;
        }
        else{
            bill_value=units_consumed*14;
            cout<<bill_value;
        }
    }
    int display(){
        cout<<"bill value is"<<bill_value<<endl;
        return bill_value;
    }
};
int main()
{
    bill number1;
    number1.input();
    number1.processing();
    number1.display();
    return 0;
}