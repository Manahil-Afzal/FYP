/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill{
	private:
	string customerName;
	string billno;
	int unitsConsumed;
	string customerAddress;
	int billamount;
	public:
	void getDetails();
	void putDetails();	
	
};
void Utility_Bill::getDetails()
{

	cout<<"Enter customer name : ";
	cin>>customerName;
	cout<<"Enter bill number : ";
	cin>>billno;
	cout<<"Enter consumed units : ";
	cin>>unitsConsumed;
	cout<<"Enter Customer address : ";
	cin>>customerAddress;
	if(unitsConsumed<300)
	billamount=unitsConsumed*8;
	else if(unitsConsumed>=300 && unitsConsumed<1000)
	billamount=unitsConsumed*5;
	else if(unitsConsumed>999)
	billamount=unitsConsumed*14;
}
void Utility_Bill::putDetails()
{
	cout<<"\nCustomer name : "<<customerName<<endl;
	cout<<"Bill no. : "<<billno<<endl;
	cout<<"Consumed units : "<<unitsConsumed<<endl;
	cout<<"Bill amount : "<<billamount<<endl;
	cout<<"Customer Address : "<<customerAddress;	
}
int main(){
	Utility_Bill std;
	std.getDetails();
	std.putDetails();
	return 0;
	
}