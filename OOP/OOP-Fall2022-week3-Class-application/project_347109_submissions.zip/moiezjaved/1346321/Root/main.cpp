/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;

class UtilityBill
{
public:
string name;
int billNo;
int units;
string address;
	
int input()
{
cout<<"enter name:"<<endl;
cin>>name;
cout<<"enter bill number:"<<endl;
cin>>billNo;
cout<<"enter consumed units:"<<endl;
cin>>units;
cout<<"enter current address:"<<endl;
cin>>address;
}
		
		
int output()
{
int totalBill;
if (units<300)
{
			
totalBill=units*8;
cout<<"===============your entered data=============="<<endl;
cout<<"your name:"<<name<<endl;
cout<<"your bill number:"<<billNo<<endl;
cout<<"your units:"<<units<<endl;
cout<<"your address:"<<address<<endl;
cout<<"your current bill:"<<totalBill<<endl;
				
}	
else if ( units>=300 && units<1000 )
{
totalBill=units*5;
cout<<"===============your entered data=============="<<endl;
cout<<"your name:"<<name<<endl;
cout<<"your bill number:"<<billNo<<endl;
cout<<"your units:"<<units<<endl;
cout<<"your address:"<<address<<endl;
cout<<"your current bill:"<<totalBill<<endl;
}
else if (units>999)
{
			
totalBill=units*14;
cout<<"===============your entered data=============="<<endl;
cout<<"your name:"<<name<<endl;
cout<<"your bill number:"<<billNo<<endl;
cout<<"your units:"<<units<<endl;
cout<<"your address:"<<address<<endl;
cout<<"your current bill:"<<totalBill<<endl;
}
}
};

int main ()
{
	UtilityBill bill;
	bill.input();
	bill.output();
	return 0;
}