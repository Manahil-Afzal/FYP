/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class utility_bill{
    string customer_name;
    int bill_number;
    int units_consumed;
    string address;
    int total_bill;
     
     public:
     void get_data()
     {
         cout<<"Enter customer name " <<endl;
         cin>>customer_name;
         cout<<"Enter bill number " <<endl;
         cin>>bill_number;
         cout<<"Enter total units consumed " <<endl;
         cin>>units_consumed;
         cout<<"Enter customer address " <<endl;
         cin>>address;
         
         
     }
     void calculate_bill(){
          if (units_consumed<300)
          {
              total_bill=units_consumed*8;
          }
          else if(units_consumed>300 || units_consumed<1000)
          {
              total_bill=units_consumed*5;
          }
          else
          total_bill=units_consumed*14;
     }
     void print_bill()
     {
         cout<<"Customer Name "<<customer_name<<endl;
         cout<<"Customer Address "<<address<<endl;
         cout<<"bill number "<<bill_number<<endl;
         cout<<"Units Consumed "<<units_consumed<<endl;
         cout<<"Total Bill "<<total_bill<<endl;
         
     }
     };
     int main()
     {
         utility_bill bill_1;
         bill_1.get_data();
          bill_1.calculate_bill();
           bill_1.print_bill();
         
     }