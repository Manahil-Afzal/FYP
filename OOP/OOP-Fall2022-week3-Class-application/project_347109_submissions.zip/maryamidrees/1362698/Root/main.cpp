/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;

class e_bill
{
     private:
         int c_no;
         char c_name[20];
         int units;
         double bill;
     public:
        void get()
        {
                 cout<<"Enter Details of Customer Below :: \n" <<endl;
                 cout<<"Enter Customer No. :: ";
                 cin>>c_no;
                 cout<<"\nEnter Customer Name :: ";
                 cin>>c_name;
                 cout<<"\nEnter No. of Units used :: ";
                 cin>>units;
         }

        void put()
         {
                cout<<"\nEntered Details of Customer are :: " <<endl;
                cout<<"\nCustomer No. is : "<<c_no;
                cout<<"\n\nCustomer Name is : "<<c_name;
                cout<<"\n\nNumber of Units Consumed : "<<units;
                cout<<"\n\nBill of Customer : "<<bill;
         }

        void calc_bill()
        {
                if(units<=100)
                       bill=units*1.20;
               else if(units<=300)
                       bill=100*1.20+(units-100)*2;
               else
                       bill=100*1.20+200*2+(units-300)*3;
         }
};

int main()
{
    e_bill b1;
    b1.get();
    b1.calc_bill();
    b1.put();

    cout<<"\n";

    return 0;
}