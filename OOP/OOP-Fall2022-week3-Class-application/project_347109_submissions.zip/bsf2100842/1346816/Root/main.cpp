/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class utilityBill{
    public:
    string customerName;
    int billNumber;
    int unitsConsumed;
    string customerAddress;
    int billAmount;
};
    int main()
    {
       int perUnitPrice;
       utilityBill obj;
       cout <<"Enter customer name : "<< endl;
       cin >> obj.customerName;
       cout << "Enter bill number : " << endl;
       cin >> obj.billNumber;
       cout << "Enter units consumed:"<< endl;
       cin >> obj.unitsConsumed;
       cout << "Enter customer address : "<< endl;
       cin >> obj.customerAddress;
       if( obj.unitsConsumed < 300){
         perUnitPrice=8;
       }
       else if(obj.unitsConsumed >= 300 && obj.unitsConsumed <1000){
                  perUnitPrice=5;
       }
       else if(obj.unitsConsumed > 999){
                 perUnitPrice =14;
       }
       obj.billAmount = obj.unitsConsumed * perUnitPrice;
       
      cout<<"The customer name is:"<<obj.customerName<<endl;
      cout<<"The bill number is :"<<obj.billNumber<<endl;
      cout<<"The units consumed are :"<<obj.unitsConsumed<<endl;
      cout<<"The customer address is :"<<obj.customerAddress<<endl;
      cout<<"The bill amount is :"<< obj.billAmount<<endl;
        return 0;
    }
