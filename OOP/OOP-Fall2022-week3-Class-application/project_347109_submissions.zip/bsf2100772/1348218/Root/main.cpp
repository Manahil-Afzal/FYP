/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class Utility_Bill{
  private:
  string customer_name;
  int bill_nmbr;
  int units_consumed;
  string customer_address;
  int price_per_unit;
  int total_bill;
  public:
  void input(){
      cout<<"Enter customer name,bill number,units consumed and customer address respectively"<<endl;
      cin>>customer_name>>bill_nmbr>>units_consumed>>customer_address;
      if(units_consumed<300){
          price_per_unit=8;
      }
       else if(units_consumed>=300 && units_consumed<1000){
          price_per_unit=5;
      }
       else{
          price_per_unit=15;
      }
      total_bill=units_consumed*price_per_unit;
  }
  void display(){
      cout<<"Customer Name : "<<customer_name<<"          "<<"Bill Number : "<<bill_nmbr<<endl;
      cout<<"Units : "<<units_consumed<<"          "<<"Totsl Bill : "<<total_bill<<endl;
      cout<<"           Address :"<<customer_address<<endl;
      
  }
};

int main(){
    Utility_Bill bill;
    bill.input();
    bill.display();
    
    return 0;
}