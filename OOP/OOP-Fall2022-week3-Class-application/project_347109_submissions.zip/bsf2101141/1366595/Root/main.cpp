/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class U_bill
{
     private:
         
         char c_name[20];
         int units;
         double bill;
         char c_address[40];
     public:
        void get()
        {
                 cout<<"Enter Details of Customer Below : \n" <<endl;
                 cout<<"Enter Customer Name : ";
                 cin>>c_name;
                 cout<<"\nEnter No. of Units used : ";
                 cin>>units;
                 cout<<"\nEnter Address of Customer : ";
                 cin>>c_address; 
                 
         }
         void put()
         {
                cout<<"\nEntered Details of Customer are : " <<endl;
                cout<<"\nCustomer Name is : "<<c_name;
                cout<<"\nNumber of Units Consumed : "<<units;
                cout<<"\nBill of Customer is : "<<bill;
                cout<<"\nAddress of Customer : "<<c_address;
         }

        void calc_bill()
        {
                if(units<=300)
                       bill=units*4;
               else if(units>=300>=1000)
                       bill=units*5;
               else
                       bill=units*7;
         }
};

int main()
{
    U_bill b1;
    b1.get();
    b1.calc_bill();
    b1.put();
    cout<<"\n";

    return 0;
}