/*Write a program that creates a class to display Utility_Bill. The class should take customer name, 
bill number, units consumed, and customer address as inputs and displays the input values and the bill
amount which is calculated after multiplying the units consumed with per unit price. If units consumed
are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, 
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include <iostream>
using namespace std;
class Utility_Bill{
    private:
    string customer_name;
    string bill_number;
    int units_consumed;
    string customer_address;
    float bill_amount;
    float price_per_unit;
    public:
    void input(){
        cout<<"Enter the customer name"<<endl;
        //cin>>customer_name;
        getline(cin,customer_name);
        cout<<"Enter the Bill Number"<<endl;
        // cin>>bill_number;
        getline(cin,bill_number);
        cout<<"Enter the Units Consumed"<<endl;
         cin>>units_consumed;
         cout<<"Enter the CUstomer's Address"<<endl;
         //cin>>customer_address;
         cin.ignore();
          getline(cin,customer_address);
         
         if(units_consumed<300){
             price_per_unit=8;
         }
         else if(units_consumed>=300 && units_consumed<1000 ){
             price_per_unit=5;
         }
         else{
             price_per_unit=14;
         }
          bill_amount=units_consumed*price_per_unit;
         
    }
    void display(){
        cout<<"Name : "<<customer_name<<endl;
        cout<<"Bill Number : "<<bill_number<<endl;
        cout<<"Units Consumed: "<<units_consumed<<endl;
        // cout<<"Price per unit: "<<units_consumed<<endl;
       cout<<"Customer Address : "<<customer_address<<endl;
       cout<<"Total Bill Amount : "<<bill_amount<<endl;
        
    }
};
int main(){
    Utility_Bill B1;
    B1.input();
    B1.display();
    
    
    return 0;
}