/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
using namespace std;
class Bill {
    private:
       string name;
       int billnmbr;
       int units;
       string address;
       int billamount;
    public:
       void getdata();
       void putdata();
};
void Bill::getdata(){
    cout<<"Enter the customer name:";
    cin>>name;
    cout<<"Enter the bill number:";
    cin>>billnmbr;
    cout<<"Enter the units consumed:";
    cin>>units;
    cout<<"Write customer address(without spacing):";
    cin>>address;
}
void Bill::putdata(){
    cout<<"Customer Name:"<<name<<endl;
    cout<<"Bill Number:"<<billnmbr<<endl;
    cout<<"Units Consumed:"<<units<<endl;
    cout<<"Customer address:"<<address<<endl;
    if (units<300)
     billamount=units*8;
    else if (units>=300 && units<1000)
     billamount=units*5;
    else if (units>999)
     billamount=units*14;
    cout<<"Bill Amount is:"<<billamount; 
}
int main(){
    Bill myObject;
    myObject.getdata();
    myObject.putdata();
    return 0;
}