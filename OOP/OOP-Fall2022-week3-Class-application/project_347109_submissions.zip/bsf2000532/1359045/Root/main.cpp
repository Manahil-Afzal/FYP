/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/


#include<iostream>
#include<string>
using namespace std;

class bill {
    public:
    string customer_name ;
    string bill_number ; 
    int units_consumed;
    string customer_address;  
};

int main(){
	
	int lowbill,normalbill,highbill;
	
	cout<<"*********************************************"<<endl;
    cout<<"            Electric Bill System             "<<endl;
	cout<<"*********************************************"<<endl;
	cout<<endl;
	cout<<endl;
	cout<<endl;
	
	bill work;
    
	cout<<"Enter your Name= ";
    cin>>work.customer_name;
    cout<<"Enter bill Number= ";
    cin>>work.bill_number;
    cout<<"Enter Units consumed= ";
    cin>>work.units_consumed;
    cout<<"Enter your address= ";
    cin>>work.customer_address;
     
     cout<<endl;
	cout<<endl;
	cout<<endl;
     cout<<"Customer Name= "<<work.customer_name<<endl;
	 cout<<"Bill Number= "<<work.bill_number<<endl;
	 cout<<"Units Consumed= "<<work.units_consumed<<endl;
	 cout<<"Units Consumed= "<<work.customer_address<<endl;
     
     
     
	cout<<endl;
	cout<<endl;
	 if( work.units_consumed >= 0 && work.units_consumed < 300){
     	
		 lowbill=8*work.units_consumed;
		cout<<"Total Bill Amount= "<<lowbill;
	 }
	 
	 else if(work.units_consumed >= 300 && work.units_consumed < 1000){
     	
		normalbill=5*work.units_consumed;
		cout<<"Total Bill Amount= "<<normalbill;
	 }
	 
	 else if(work.units_consumed > 999){
	 	
	 	highbill=14*work.units_consumed;
     	cout<<"Total Bill Amount= "<<highbill;
	 }
	 else{
	 	cout<<"Invalid Your Value"<<endl;
	 }
     

    return 0;
    
    
}