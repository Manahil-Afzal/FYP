/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>
using namespace std;
class Utility_Bill{
	private:
	string customer_name;
	int bill_no;
	float unit_consumed,perunitprice,bill_amount;
	
	public:
	void getdetail();
	void calcdetail();
};

main()
{
Utility_Bill std;
std.getdetail();
std.calcdetail();
return 0;
	
}
void Utility_Bill::getdetail()
{
	cout<<"Enter customer name:";
	cin>>customer_name;
	cout<<"Enter bill no:";
	cin>>bill_no;
	cout<<"Enter units consumed :";
	cin>>unit_consumed;
	cout<<"Enter per unit price: ";
	cin>>perunitprice;
	cout<<"Enter detail of Utility_Bill:"<<endl;
	cout<<"Customer name: "<<customer_name<<endl;
	cout<<"Bill no: "<<bill_no<<endl;
	cout<<"Units consumed: "<<unit_consumed<<endl;
	cout<<"Per unit price: "<<perunitprice<<endl;
	
}
void Utility_Bill::calcdetail()
{
	if(unit_consumed<300)
	{
		cout<<"per unit price is 8"<<endl;
		
	}
	if(unit_consumed>=300 && unit_consumed<1000)
	{
		cout<<"per unit price is 5"<<endl;
	
	}
	if(unit_consumed>999)
	{
		cout<<"per unit price is 14"<<endl;
		
	}
	bill_amount=unit_consumed*perunitprice;
	cout<<"The bill amount is: "<<bill_amount;
}