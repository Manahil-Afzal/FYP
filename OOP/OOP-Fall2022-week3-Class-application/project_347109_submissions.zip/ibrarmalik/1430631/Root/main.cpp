/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include <iostream>
#include <string.h>
using namespace std;
class Utility_Bill
{
private:
    string CusName, CusAddress;
    int BillNo,amt,unit;

public:
    void get();
    void printAmt();
};

void Utility_Bill::get()
{
    cout << "Enter Customer Name: " << endl;
    cin>>CusName;
             cout << "Enter Customer Address: " << endl;
    cin>>CusAddress;
     cout << "Enter Bill Number: " << endl;
    cin>>BillNo;
         cout << "Enter Units that you Consumed: " << endl;
    cin>>unit;
}

void Utility_Bill::printAmt() 
{
    if(unit>0 && unit<300)
    {
        amt=unit*8;
    }
    else if(unit>=300 && unit<1000)
    {
        amt=unit*5;
    }
    else if(unit>900)
    {
        amt=unit*14;
    }
    cout << "Bill charge: " <<amt <<endl;

}

int main()
{
    Utility_Bill obj;

    obj.get();
    obj.printAmt();

    
}