#include<iostream>
using namespace std;
class detail {
public:
string customer_name;
 int bill_no,units;
};
 int main()
 {
    detail obj;
    cout<<"Enter your name :"<<endl;
    cin>>obj.customer_name;
    cout<<"Enter bill number:"<<endl;
    cin>>obj.bill_no;
    cout<<"Enter the unit consumed :"<<endl;
    cin>>obj.units;
    if(obj.units<900)
    {
    cout<<"Amount of bill:"<<obj.units*14;}
    if(obj.units>=300 && obj.units<1000)
    {
    cout<<"Amount of bill:"<<obj.units*5;}
    if(obj.units>999)
    {
        cout<<"Amount of bill:"<<obj.units*5;
    }
    return 0;
 }