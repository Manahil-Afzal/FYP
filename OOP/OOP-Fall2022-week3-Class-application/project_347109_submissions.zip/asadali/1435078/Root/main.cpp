/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/

#include<iostream>

using namespace std;

class Utility_Bill{
  private:
    string name;
    int billNo;
    int unitsConsumed;
    string address;
  public:
    void getInput(){
        cout<<"Enter name = ";
        getline(cin, name);
        cout<<"\n";
        cout<<"Enter address = ";
        getline(cin, address);
        cout<<"\n";
        cout<<"Enter bill number = ";
        cin>> billNo;
        cout<<"\n";
        
         cout<<"Enter units consumed = ";
        cin>> unitsConsumed;
        cout<<"\n";
    }
    
    void displayData(){
        cout<<"Name = "<<name<<"\n";
        cout<<"Bill no = "<<billNo<<"\n";
        cout<<"units consumed = "<<unitsConsumed<<"\n";
        cout<<"address = "<<address<<"\n";
    }
    
    void calcBill(){
        int bill = 0;
        if(unitsConsumed <300){
            bill = unitsConsumed * 8;
            
        }else if(unitsConsumed >= 300 && unitsConsumed< 1000){
            bill = unitsConsumed * 5;
        }else if(unitsConsumed > 999){
            bill = unitsConsumed * 14;
            
        }
        cout<<"\n\n";
        cout<<bill;
    }
    
    
};

int main(){
    
    Utility_Bill b1;
    b1.getInput();
    b1.displayData();
    b1.calcBill();
    
    return 0;
}
