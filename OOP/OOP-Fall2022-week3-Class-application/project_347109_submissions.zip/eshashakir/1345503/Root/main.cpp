/*Write a program that creates a class to display Utility_Bill. The class should take customer name, 
bill number, units consumed, and customer address as inputs and displays the input values and the bill
amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 
but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;

class Utility_Bill{
	char cus_Name[50];
	int bill_no;
	int units_consumed;
	string address;
	
	public:
		int input()
		{   cout<<"-------------------------------"<<endl;
			cout<<"Enter Details of Customer Below:"<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"NAME:";
			cin>>cus_Name;
			cout<<"BILL NUMBER:";
			cin>>bill_no;
			cout<<"UNIT_CONSUMED:";
			cin>>units_consumed;
			cout<<"ADDRESS:";
			cin>>address;
		}
		int output()
		{
			if(units_consumed<300)
			{
				int total=units_consumed*8;
				cout<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"Entered Details of Customer are :"<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"NAME:"<<cus_Name<<endl;
			cout<<"BILL_NUMBER:"<<bill_no<<endl;
			cout<<"CONSUMED_UNITS:"<<units_consumed<<endl;
			cout<<"ADDRESS:"<<address<<endl;
	     	cout<<"THE AMOUNT OF BILL IS:"<<total<<endl;  
			}
			else if(units_consumed && units_consumed<1000)
			{
			   int total=units_consumed*5;
	        cout<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"Entered Details of Customer are :"<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"NAME:"<<cus_Name<<endl;
			cout<<"BILL_NUMBER:"<<bill_no<<endl;
			cout<<"CONSUMED_UNITS:"<<units_consumed<<endl;
			cout<<"ADDRESS:"<<address<<endl;
	     	cout<<"THE AMOUNT OF BILL IS:"<<total; 
			}
			else if(units_consumed>999)
			{
				int total=units_consumed*14;
				cout<<endl;
			cout<<"THE AMOUNT OF BILL IS:"<<total<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"Entered Details of Customer are :"<<endl;
			cout<<"-------------------------------"<<endl;
			cout<<"NAME:"<<cus_Name<<endl;
			cout<<"BILL_NUMBER:"<<bill_no<<endl;
			cout<<"CONSUMED_UNITS:"<<units_consumed<<endl;
			cout<<"ADDRESS:"<<address<<endl;
	     	cout<<"THE AMOUNT OF BILL IS:"<<total<<endl; 
				
			}
		}
};
int main()
{
Utility_Bill obj;
obj.input();
obj.output();
return 0;	
}
