/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{

public:
string book_title;
float book_price ;
void getdata ();
void putdata ();
} ;
void book :: getdata()
{

cout<<"Enter the Book Title : ";
cin>>book_title;
cout<<"Enter the prize of book : ";
cin>>book_price;
 
}
void book :: putdata ()
{
cout<<"Book Title : "<<book_title<< "\n";
cout<<"Prize of book : "<<book_price<< "\n";
}
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
