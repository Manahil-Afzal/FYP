/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, 
units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units
consumed with per unit price.If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000,
the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class Utility_Bill{
    string name;
    int billno;
    int units_consumed;
    string address;
    public:
    int input(){
        cout<<"enter your name=";
        cin>>name;
        cout<<"enter your bill no=";
        cin>>billno;
        cout<<"enter your units-consumed=";
        cin>>units_consumed;
        cout<<"enter your address=";
        cin>>address;
        
    }
    int output(){
        if(units_consumed<300){
            int total=units_consumed*8;
            cout<<"the amount of bill is="<<total;
        }
        else if(units_consumed>=300 && units_consumed<1000){
            int total=units_consumed*5;
            cout<<"the amount of bill is="<<total;
        }
       else if(units_consumed>999){
            int total=units_consumed*14;
            cout<<"the amount of bill is="<<total;
        }
    }
};
 int main(){
     Utility_Bill obj;
     obj.input();
     obj.output();
     return 0;
 }
