/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/#include <iostream>
using namespace std;

class UtilityBill
{
public:
string name;
int bill;
int units;
string address;
	
int input()
{
cout<<"Enter Coustumer Name:"<<endl;
cin>>name;
cout<<"Enter Coustumer Bill Number:"<<endl;
cin>>bill;
cout<<"Consumed Units:"<<endl;
cin>>units;
cout<<"Current Address:"<<endl;
cin>>address;
}
		
int output()
{
int total;
if (units<300)
{
			
total=units*8;
cout<<"Coustumer name:"<<name<<endl;
cout<<"Coustumer bill number:"<<bill<<endl;
cout<<"Units Consumed:"<<units<<endl;
cout<<"Current address:"<<address<<endl;
cout<<"your current bill:"<<total<<endl;
				
}	
else if ( units>=300 && units<1000 )
{
total=units*5;
cout<<"Coustumer name:"<<name<<endl;
cout<<"Coustumer bill number:"<<bill<<endl;
cout<<"Units Consumed:"<<units<<endl;
cout<<"Current address:"<<address<<endl;
cout<<"your current bill:"<<total<<endl;
}
else if (units>999)
{
			
total=units*14;
cout<<"Coustumer name:"<<name<<endl;
cout<<"Costumer bill number:"<<bill<<endl;
cout<<"Units Consumed:"<<units<<endl;
cout<<"Current address:"<<address<<endl;
cout<<"your current bill:"<<total<<endl;
}
}
};

int main ()
{
	UtilityBill bill;
	bill.input();
	bill.output();
	return 0;
}