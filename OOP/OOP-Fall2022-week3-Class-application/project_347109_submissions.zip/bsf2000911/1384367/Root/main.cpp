/*Write a program that creates a class to display Utility_Bill. The class should take customer name, bill number, units consumed, and customer address as inputs and displays the input values and the bill amount which is calculated after multiplying the units consumed with per unit price.
If units consumed are less than 300, the per unit price is Rs. 8; if greater than or equal to 300 but less than 1000, the per unit price is Rs. 5. If units consumed are greater than 999, the per unit price is Rs. 14.*/
#include<iostream>
using namespace std;
class detail {
	public:
		string customer_name;
		int bill_no,units;
};
int main()
{
	detail obj;
	cout<<"Enter your name:"<<endl;
	cin>>obj.customer_name;
	cout<<"Enter Bill Number"<<endl;
	cin>>obj.bill_no;
	cout<<"Enter the unit (Consumed)"<<endl ;
	cin>>obj.units;
	if(obj.units<300){
		cout<<"Amount of Bill : "<<obj.units*8;}
	if(obj.units>=300 && obj.units<1000) {
		cout<<"Amount of Bill : "<<obj.units*5;}
	if(obj.units>999){
		cout<<"Amount of Bill : "<<obj.units*14;
	
	}
return 0;
}