/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;
class book
{
char title [10];
float price ;
public:
void getdata ();
void putdata ();
};
void book::getdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
}
void book::putdata ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main ()
{
book Book [3];
for(int i=0;i<3;i++)
{
cout<<"Enter details o£ book "<<(i+1)<<"\n";
Book[i].getdata();
}
for(int i=0;i<3;i++)
{
cout<<"\nBook "<<(i+1)<<"\n";
Book[i].putdata();
}
return 0;
}
