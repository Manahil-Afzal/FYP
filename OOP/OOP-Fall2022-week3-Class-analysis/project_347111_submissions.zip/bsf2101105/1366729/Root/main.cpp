/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
    private:
string title;
float price;
    public:
void getdetail();
void putdetail();
} ;
void book::getdetail ()
{
 cout<<"Title:"<<endl;
 cin>>title;
 cout<<"Price:"<<endl;
 cin>>price;
 
}
void book::putdetail ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main()
{
book book1, book2, book3;
book1.getdetail();
book2.getdetail();
book3.getdetail();
book1.putdetail() ;
book2.putdetail() ;
book3.putdetail() ;

return 0;
}
