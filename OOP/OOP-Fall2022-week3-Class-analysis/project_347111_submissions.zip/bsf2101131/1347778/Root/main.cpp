/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>

using namespace std;

class book
{
//Access specifier used in start;
public:
string title;
float price ;
void getdata ();
void putdata ();
}; // Semi colon  missing
void book :: getdata () //correct class name and colon 
{
cout<<"Title:";//correct closing quote
cin>>title;
cout<<"Price:";//correct closing quote 
cin>>price;
 
}
void book :: putdata () //correct class name and colon 
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";//correct closing quote 
}
int main ()
{
book book1, book2, book3; //correct class name
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata();
book2.putdata();
book3.putdata();

return 0;
}
