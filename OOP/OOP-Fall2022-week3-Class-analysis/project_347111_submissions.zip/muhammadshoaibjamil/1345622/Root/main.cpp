/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include<iostream>
using namespace std;

//Changing the class name
class books
{
//	Adding private access specifier and also removing void getdata ();
	private:
	string title;
	float price ;

	public:
	void getdata ();
	void putdata ();
} ;
//Correcting scope resolution ::
void books::getdata ()
{
//	Changing the ” into "
cout<<"Title:";
cin>>title;
//	Changing the ” into "
cout<<"Price:";
cin>>price;
 
}
//Correcting scope resolution ::
//also adding closing tag as }
void books::putdata ()
{
	//	Changing the ” into "
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main ()
{
books book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
