
#include <iostream>
//string is not a built feature therefore we have for include it.
#include<string>
using namespace std;

class book
{
string title;
float price ;
//Function definition is not allowed in private access specifier
//void getdata ();
public:
void getdata ();
void putdata ();
} ;
// the syntax of calling of access specifier is incorrect
void book::getdata()
{
	//The notation is not correct
cout<<"Title:";
cin>>title;
//The notation is not correct
cout<<"Price:";
cin>>price;
 
}
// the syntax of calling of access specifier is incorrect
void book::putdata ()
{
cout<<"Title:"<<title<< "\n";
//The notation is not correct
cout<<"Price:"<<price<< "\n";
//closing bracket missing
}
int main ()
{ 
//the name member is not correct
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
 }