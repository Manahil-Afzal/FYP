/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include<iostream>
using namespace std;
class bill{
    private:
    string name;
    int bill_number;
    int units_consumed;
    string customer_adress;
    int bill_value;
    public:
    void input(){
        cout<<"enter customer name"<<endl;
        cin>>name;
        cout<<"enter bill number"<<endl;
        cin>>bill_number;
        cout<<"enter units consumed"<<endl;
        cin>>units_consumed;
        cout<<"enter customer adress"<<endl;
        cin>>customer_adress;
    }
    void processing(){
        if(units_consumed<300){
            bill_value=units_consumed*8;
            cout<<bill_value;
        }
        else if(units_consumed<1000){
            bill_value=units_consumed*5;
            cout<<bill_value;
        }
        else{
            bill_value=units_consumed*14;
            cout<<bill_value;
        }
    }
    int display(){
        cout<<"bill value is"<<bill_value<<endl;
        return bill_value;
    }
};
int main()
{
    bill number1;
    number1.input();
    number1.processing();
    number1.display();
    return 0;
}