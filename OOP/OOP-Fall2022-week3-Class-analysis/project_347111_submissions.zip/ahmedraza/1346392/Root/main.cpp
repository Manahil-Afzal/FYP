/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class Book
{
    private:
string title;
float price ;
public:
void getdata ();
void putdata ();
} ;
void Book :: getdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
 
}
void Book :: putdata ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main ()
{
Book book1;
book1.getdata();
book1.putdata();
Book book2;
book2.getdata();
book2.putdata();
Book book3;
book3.getdata();
book3.putdata();

return 0;
}
