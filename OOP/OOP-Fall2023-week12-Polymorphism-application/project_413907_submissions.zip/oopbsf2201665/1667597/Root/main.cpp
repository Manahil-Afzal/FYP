#include <iostream>
#include <cmath>
using namespace std;

class Shape {
public:
    virtual void area() {
        cout << "Area of the Shape" << endl;
    }
};

class Triangle : public Shape {
private:
    double base, height;

public:
    Triangle(double b, double h) : base(b), height(h) {}

    void area() override {
        cout << "Area of Triangle: " << (base * height) / 2.0 << endl;
    }
};

class Rectangle : public Shape {
private:
    double length, width;

public:
    Rectangle(double l, double w) : length(l), width(w) {}

    void area() override {
        cout << "Area of Rectangle: " << length * width << endl;
    }
};

class Circle : public Shape {
private:
    double radius;

public:
    Circle(double r) : radius(r) {}

    void area() override {
        cout << "Area of Circle: " << 3.1415 * pow(radius, 2) << endl;
    }
};

int main() {
    Triangle triangle(4.0, 5.0);
    Rectangle rectangle(3.0, 6.0);
    Circle circle(2.5);

    Shape* shapes[] = {&triangle, &rectangle, &circle};

    for (int i = 0; i < 3; ++i) {
        shapes[i]->area();
    }

    return 0;
}
