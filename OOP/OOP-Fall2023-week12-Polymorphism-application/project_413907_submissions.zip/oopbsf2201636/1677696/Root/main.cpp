/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
#include <cmath> // For using the power function
using namespace std;

class Shape {
public:
    virtual void area() const {
        cout << "Area of the Shape (Base class)" << endl;
    }
};

class Triangle : public Shape {
private:
    double base;
    double height;

public:
    Triangle(double b, double h) : base(b), height(h) {}

    void area() const override {
        double triangleArea = (base * height) / 2;
        cout << "Area of the Triangle: " << triangleArea << endl;
    }
};

class Rectangle : public Shape {
private:
    double length;
    double width;

public:
    Rectangle(double l, double w) : length(l), width(w) {}

    void area() const override {
        double rectangleArea = length * width;
        cout << "Area of the Rectangle: " << rectangleArea << endl;
    }
};

class Circle : public Shape {
private:
    double radius;

public:
    Circle(double r) : radius(r) {}

    void area() const override {
        double circleArea = 3.1415 * pow(radius, 2);
        cout << "Area of the Circle: " << circleArea << endl;
    }
};

int main() {
    Shape* shapes[3]; // Array of base class pointers

    // Creating objects of derived classes
    Triangle triangle(5.0, 8.0);
    Rectangle rectangle(4.0, 6.0);
    Circle circle(3.0);

    // Assigning the addresses of derived class objects to base class pointers
    shapes[0] = &triangle;
    shapes[1] = &rectangle;
    shapes[2] = &circle;

    // Calling the area() method using polymorphism
    for (int i = 0; i < 3; ++i) {
        shapes[i]->area();
    }

    return 0;
}
