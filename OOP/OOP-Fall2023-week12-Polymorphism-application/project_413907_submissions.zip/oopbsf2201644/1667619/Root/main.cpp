/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class Shape {
public:
    virtual float area() const = 0; // Pure virtual function
};

class Triangle : public Shape {
private:
    float base;
    float height;

public:
    Triangle(float b, float h) : base(b), height(h) {}

    float area() const override {
        return (base * height) / 2;
    }
};

class Rectangle : public Shape {
private:
    float length;
    float width;

public:
    Rectangle(float l, float w) : length(l), width(w) {}

    float area() const override {
        return length * width;
    }
};

class Circle : public Shape {
private:
    float radius;

public:
    Circle(float r) : radius(r) {}

    float area() const override {
        return 3.1415 * (radius * radius);
    }
};

int main() {
    Triangle tri(5, 8);
    Rectangle rect(4, 6);
    Circle circ(3);

    Shape* shapes[] = { &tri, &rect, &circ };

    /*for (Shape* s : shapes) {
       {
           cout << "Area: " <<s-> area() << endl;
    }}*/

    return 0;
}