/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class Shape
{
    public:
        virtual void area()
        {
            cout<<"Area of Shape"<<endl;
        }
};
class Triangle:public Shape
{
    public:
        void area()
        {
            int base,height;
            cout<<"Enter Base and Height of Triangle"<<endl;
            cin>>base>>height;
            cout<<"Area of Triangle is "<<(base*height)/2<<endl;
        }
};
class Rectangle:public Shape
{
    public:
        void area()
        {
            int length,width;
            cout<<"Enter Length and Width of Rectangle"<<endl;
            cin>>length>>width;
            cout<<"Area of Rectangle is "<<length*width<<endl;
        }
};
class Circle:public Shape
{
    public:
        void area()
        {
            int radius;
            cout<<"Enter Radius of Circle"<<endl;
            cin>>radius;
            cout<<"Area of Circle is "<<3.1415*(radius*radius)<<endl;
        }
};
int main()
{
    Shape *s;
    Triangle t;
    Rectangle r;
    Circle c;
    s=&t;
    s->area();
    s=&r;
    s->area();
    s=&c;
    s->area();
    return 0;
}