/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class shape{
    virtual void Area(){
        cout<<"function";
    }
};
class Triangle: public shape{
    public:
    void Area(){
        cout<<"Area of Triangle: "<< 2*5/2<<endl;
    }
};
class Circle : public shape{
    public:
    void Area(){
        cout<<"Area of Circle: "<< 3.14*(4*4)<<endl;
    }
};
class Rectangle: public shape{
    public:
    void Area(){
        cout<<"Area of Rectangle: "<<  2*10<<endl;
    }
};
int main(){ 
    Circle c;
    Rectangle r;
    Triangle t;
    
    Circle *obj1 = &c;
    Rectangle *obj2= &r;
    Triangle *obj3= &t;
    
    obj1->Area();
    obj2->Area();
    obj3->Area();
    
    return 0;
    
}

