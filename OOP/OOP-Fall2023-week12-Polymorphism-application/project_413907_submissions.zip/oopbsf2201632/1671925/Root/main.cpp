/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class Shape{
protected:
string name;
	public:
    Shape(string n){
    name=n;
    }
		virtual void Area(){}
};class Triangle: public Shape{
private:
	float base;
	float height;
	public:
		Triangle(string n, float b, float h):Shape(n){
			base=b;
			height=h;
		}
		void Area(){
        double area;
			area=base*height;
            cout<<"Name:"<<name<<endl;
			cout<<"Area:"<<area<<endl;
		}};
    class Circle: public Shape {
     	float radius;
     	public:
     		Circle(string n, float r):Shape(n){
     			radius=r;
			 }
    void Area(){
    double area;
     		area=3.1415*radius;
             cout<<"Name:"<<name<<endl;
			cout<<"Area:"<<area<<endl;
		 }	
	 };
	class Rectangle: public Shape{
		float len;
		float width;
		public:
			Rectangle(string n,float l,float w): Shape(n){
				len=l;
                width=w;
			}
	 void Area(){
    double area;
	 	area=len*width;
         cout<<"Name:"<<name<<endl;
			cout<<"Area:"<<area<<endl;
	 }
	};
  int main(){
  	Rectangle r1("Rectangle",3.7,4);
      Circle c1("Circle",3.8);
      Triangle t1("Triangle",3,7);
      Shape *obj[3];
      obj[0]=&r1;
      obj[1]=&c1;
      obj[2]=&t1;
      obj[0]->Area();
      obj[1]->Area();
      obj[2]->Area();
       
  }