/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;

class Shape {
public:
    virtual void area() {
        cout << "This is the area method of the Shape class." << endl;
    }
};

class Triangle : public Shape {
private:
    double base, height;
public:
    Triangle(double b, double h) {
        base = b;
        height = h;
    }
    void area() {
        double triangleArea = (base * height) / 2;
        cout << "The area of the triangle is: " << triangleArea << endl;
    }
};

class Rectangle : public Shape {
private:
    double length, width;
public:
    Rectangle(double l, double w) {
        length = l;
        width = w;
    }
    void area() {
        double rectangleArea = length * width;
        cout << "The area of the rectangle is: " << rectangleArea << endl;
    }
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) {
        radius = r;
    }
    void area() {
        double circleArea = 3.1415 * (radius * radius);
        cout << "The area of the circle is: " << circleArea << endl;
    }
};

int main() {
    Shape* shapes[3];
    shapes[0] = new Triangle(5, 8);
    shapes[1] = new Rectangle(4, 6);
    shapes[2] = new Circle(3);

    for (int i = 0; i < 3; i++) {
        shapes[i]->area();
    }

    return 0;
}