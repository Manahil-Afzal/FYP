/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class Shape {
public:
 virtual void area() {
 cout << "Area of Shape" << endl;
 }
};
class Triangle : public Shape {
private:
 float base, height;
public:
 Triangle(float b, float h) : base(b), height(h) {}
virtual void area() override {
 cout << "Area of Triangle: " << (base * height) / 2 << endl;
 }
};
class Rectangle : public Shape {
private:
 float length, width;
public:
 Rectangle(float l, float w) : length(l), width(w) {}
 virtual void area() override {
 cout << "Area of Rectangle: " << length * width << endl;
 }
};
class Circle : public Shape {
private:
 float radius;
public:
 Circle(float r) : radius(r) {}
 virtual void area() override {
 cout << "Area of Circle: " << 3.1415 * (radius, 2) << endl;
 }
};
int main() {
 Shape *shapes[3];
 shapes[0] = new Triangle(5, 8);
 shapes[1] = new Rectangle(4, 6);
 shapes[2] = new Circle(3);
 for (int i = 0; i < 3; ++i) {
 shapes[i]->area();
 }
 return 0;
}
