/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>

using namespace std;

class Shape {
public:
    virtual void area() const {
        cout << "Area of the shape\n";
    }
};

class Triangle : public Shape {
private:
    double base, height;

public:
    Triangle(double b, double h) : base(b), height(h) {}

    void area() const override {
        double triangleArea = 0.5 * base * height;
        cout << "Area of Triangle: " << triangleArea << endl;
    }
};

class Rectangle : public Shape {
private:
    double length, width;

public:
    Rectangle(double l, double w) : length(l), width(w) {}

    void area() const override {
        double rectangleArea = length * width;
        cout << "Area of Rectangle: " << rectangleArea << endl;
    }
};

class Circle : public Shape {
private:
    double radius;

public:
    Circle(double r) : radius(r) {}

    void area() const override {
        double circleArea = 3.1415 * radius * radius;
        cout << "Area of Circle: " << circleArea << endl;
    }
};

int main() {
    Triangle triangle(5, 8);
    Rectangle rectangle(4, 6);
    Circle circle(3);

    triangle.area();
    rectangle.area();
    circle.area();

    return 0;
}