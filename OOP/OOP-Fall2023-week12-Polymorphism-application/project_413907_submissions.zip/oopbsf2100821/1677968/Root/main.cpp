/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class Shape{
	public:
 virtual  void area(){
  }};
class Triangle: public Shape{
	public:
    void area(){
		cout<<"base and height";
		int base;
		float height, ar;
		cin>>base>>height;
		ar=base*base;
		cout<<ar;
	}
};
class circle : public Shape{
	public:
		void area(){
			cout<<"enter radius";
			int radius;
			float ar;
			cin>>radius;
			ar=3.14*radius*radius;
			cout<<ar;
		}
};
class rectangle : public Shape{
	public:
		void area(){
			cout<<"enter length and width";
			float lenght, width,ar;
			cin>>lenght>>width;
			ar= lenght* width;
			cout<<ar;
		}
};
void interfun(Shape *s){
	s->area();
}

int main(){
Shape *obj1= new Shape;
Shape *obj2= new Triangle;
Shape *obj3= new circle;
Shape *obj4 = new rectangle;
interfun(obj1);
interfun(obj2);
interfun(obj3);
interfun(obj4);
}