/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
#include<cmath>

class Shape {
public:
    virtual void area() {
        std::cout << "Area of shape (base class)" << std::endl;
    }
};

class Triangle : public Shape {
private:
    double base, height;
public:
    Triangle(double b, double h) : base(b), height(h) {}

    void area() override {
        double triangleArea = (base * height) / 2;
        std::cout << "Area of triangle: " << triangleArea << std::endl;
    }
};

class Rectangle : public Shape {
private:
    double length, width;
public:
    Rectangle(double l, double w) : length(l), width(w) {}

    void area() override {
        double rectangleArea = length * width;
        std::cout << "Area of rectangle: " << rectangleArea << std::endl;
    }
};

class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}

    void area() override {
        double circleArea = 3.1415 * pow(radius, 2);
        std::cout << "Area of circle: " << circleArea << std::endl;
    }
};

int main() {
    // Creating objects of each class
    Triangle triangle(5, 8);
    Rectangle rectangle(4, 6);
    Circle circle(3);

    // Using polymorphism to call the area method
    Shape* shape1 = &triangle;
    Shape* shape2 = &rectangle;
    Shape* shape3 = &circle;

    shape1->area();
    shape2->area();
    shape3->area();

    return 0;
}