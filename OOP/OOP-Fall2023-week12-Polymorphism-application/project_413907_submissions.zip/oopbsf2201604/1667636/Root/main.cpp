/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
class Shape {
public:
    virtual void area() {
        std::cout << "Area of the shape is undefined." << std::endl;
    }
};
class Triangle : public Shape {
private:
    double base;
    double height;
public:
    Triangle(double b, double h) : base(b), height(h) {}

    void area() override {
        double triangleArea = (base * height) / 2;
        std::cout << "Area of Triangle: " << triangleArea << std::endl;
    }
};
class Rectangle : public Shape {
private:
    double length;
    double width;
public:
    Rectangle(double l, double w) : length(l), width(w) {}

    void area() override {
        double rectangleArea = length * width;
        std::cout << "Area of Rectangle: " << rectangleArea << std::endl;
    }
};
class Circle : public Shape {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}

    void area() override {
        double circleArea = 3.1415 * radius * radius;
        std::cout << "Area of Circle: " << circleArea << std::endl;
    }
};

int main() {
    Shape* shapes[3];
    Triangle triangle(5, 8);
    Rectangle rectangle(4, 6);
    Circle circle(3);
    shapes[0] = &triangle;
    shapes[1] = &rectangle;
    shapes[2] = &circle;

    for (int i = 0; i < 3; ++i) {
        shapes[i]->area();
    }

    return 0;
}
