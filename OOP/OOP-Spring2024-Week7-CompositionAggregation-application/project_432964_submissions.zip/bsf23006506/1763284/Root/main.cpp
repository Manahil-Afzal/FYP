/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include<iostream>
using namespace std;
class engine{
	string eng_no;
	public:
	
		void seteng(string num){
			eng_no=num;
		}
		string geteng(){
			return eng_no;
		}
};
class passenger{
	string name;
	public:
		void setName(string n1){
			name=n1;
		}
		string getName(){
			return name;
		}
};
class car{
	string eng_no;
	engine e1;
	passenger *p1;
	public:
		car(passenger *p,string eng){
			e1.seteng("345");
			p1=p;
			p1->setName("Ali");
		}
		void display(){
			cout<<"the engine number is "<<e1.geteng()<<endl;
			cout<<"the passenger name is "<<p1->getName()<<endl;
		}
};
int main(){
	passenger p2;
	car c1(&p2,"345");
	c1.display();
}