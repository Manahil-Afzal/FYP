#include<iostream>
using namespace std;
class Engine{
	private:
		string engine_number;
		public:
			Engine(string num):engine_number(num){}
			string get_engine_number(){
				return engine_number;
			}
};
class Passenger{
	private:
		string passenger_name;
		public:
			Passenger(string name):passenger_name(name){}
				string get_passenger_name(){
					return passenger_name;
				}
};
class Car{
	private:
		Engine *engine_ptr;
		Passenger *passenger_ptr;
		public:
			Car(Engine *eng_ptr,Passenger *pass_ptr):engine_ptr(eng_ptr),passenger_ptr(pass_ptr){}
			void display(){
				cout<<"Engine Number : "<<engine_ptr->get_engine_number()<<endl;
                cout<<"Passenger Name : "<<passenger_ptr->get_passenger_name()<<endl;			
			}
};

int main(){
Engine engine("123456");
Passenger passenger("John Doe");
Car car(&engine,&passenger);
car.display();	
}