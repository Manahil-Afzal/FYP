#include <iostream>
using namespace std;


class engn {
private:
    string engine_num;
    public:
    	engn(string num)
    	{
    		engine_num=num;
		}
    string getData(){
    return engine_num;
	}
};

class Passenger {
private:
    string passenger_name;
    public:
    	Passenger(string name)
   {
        passenger_name=name;
     }
    string getData(){
    return passenger_name;
	}
};

class Car {
private:
    engn *engine;
    Passenger *passenger;
    public:
    Car(engn engine1, Passenger passenger1)
	{
	engine=&engine1;
	passenger=&passenger1;
}

    void displayDetails() {
        std::cout << "Engine Number: " << engine->getData()<<endl;
        std::cout << "Passenger Name: " << passenger->getData()<<endl;
    }
};

int main() {
	engn engine("786");
	Passenger passenger("knz");
    Car c(engine, passenger);

    c.displayDetails();

    return 0;
}