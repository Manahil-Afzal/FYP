// Main function of the C++ program.
#include<iostream>
#include<string>
using namespace std;
class Engine
{
private:
	string engine_number;
public:
	Engine(string a="")
	{
		engine_number = a;
	}
	string get_engine_number()
	{
		return engine_number;
	}
};

class Passenger
{
private:
	string passenge_name;
public:
	Passenger(string name)
	{
		passenge_name = name;
	}
	string get_passenge_name()
	{
		return passenge_name;
	}
};

class Car
{
private:
	Engine engine;
	Passenger* pass;
public:
	Car(Engine en,Passenger* pa)
	{
		engine = en;
		pass = pa;
	}
	void display()
	{
		cout<<"Engine number : "<<engine.get_engine_number()<<endl;
		cout<<"Passenger name : "<<pass->get_passenge_name();
	}
};

int main()
{
	Engine en1("LEU112");
	Passenger* pa1 = new Passenger("Ali");
	Car c1(en1,pa1);
	c1.display();
	delete pa1;
}
