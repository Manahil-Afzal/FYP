#include<iostream>
using namespace std;
class engine{
	int eng_num;
	public:
		engine(int en){
			eng_num=en;
		}
	void display(){
		cout<<"Engine number: "<<eng_num;
}
};
class passenger{
	string name;
	public:
	void setdata(){
		cout<<"Enter the Passenger's name: ";
		cin>>name;
	}
	void getdata(){
	cout<<"Passenger's name: "<<name<<endl;	
	}};
	class car{
		engine eng=112;
		passenger *pass;
		public:
		car(passenger &p1)
		{
			pass=&p1;
			pass->setdata();
		}
		void show(){
			pass->getdata();
			eng.display();
		}	
	};
	int main(){
		passenger p2;
		car c1(p2);
		c1.show();
	}
