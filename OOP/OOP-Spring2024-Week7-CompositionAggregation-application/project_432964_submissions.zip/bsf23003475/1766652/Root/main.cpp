#include <iostream>
#include <string>
using namespace std;

class Engine {
public:
    Engine(const string& engineNumber) : engineNumber_(engineNumber) {}
    string getEngineNumber() const { return engineNumber_; }

private:
    string engineNumber_;
};

class Passenger {
public:
    Passenger(const string& passengerName) : passengerName_(passengerName) {}
    string getPassengerName() const { return passengerName_; }

private:
    string passengerName_;
};


class Car {
public:
    Car(const string& engineNumber, const string& passengerName)
        : engine_(engineNumber), passenger_(passengerName) {}

    void displayInfo() const {
        cout << "Engine Number: " << engine_.getEngineNumber() << endl;
    cout << "Passenger Name: " << passenger_.getPassengerName() << endl;
    }

private:
    Engine engine_;
    Passenger passenger_;
};

int main() {
        Car myCar("ABC123", "Alice");
    myCar.displayInfo();

    return 0;
}
