#include <iostream>
#include <string>
using namespace std;
class Engine {
private:
    string engine_number;

public:
    Engine(string number) : engine_number(number) {}
    string getEngineNumber() {
        return engine_number;
    }
};
class Passenger {
private:
    string passenger_name;

public:
    Passenger(string name) : passenger_name(name) {}
    string getPassengerName() {
        return passenger_name;
    }
};
class Car {
private:
    Engine car_engine; 
    Passenger car_passenger; 

public:
    Car(string engine_number, string passenger_name) : car_engine(engine_number), car_passenger(passenger_name) {}
    void displayInfo() {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    Car car("XYZ123", "John");
    car.displayInfo();

    return 0;
}
