/* Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>
using namespace std;

// Define the Engine class
class Engine {
private:
    string engine_number;

public:
    Engine(const string& num) : engine_number(num) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine engine;   // Object of Engine class (aggregation)
    Passenger passenger; // Object of Passenger class (aggregation)

public:
    Car(const string& engine_num, const string& passenger_name)
        : engine(engine_num), passenger(passenger_name) {}

    void displayInfo() {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an object of Car
    Car car("56", "Babar Azam👑");
    
    // Display engine number and passenger name
    car.displayInfo();

    return 0;
}