/* Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

using namespace std;

// Class definition for Engine
class Engine {
private:
    string engine_number;

public:
    // Constructor to initialize engine_number
    Engine(const string& num) : engine_number(num) {}

    // Getter method to retrieve engine number
    string getEngineNumber() const {
        return engine_number;
    }
};

// Class definition for Passenger
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to initialize passenger_name
    Passenger(const string& name) : passenger_name(name) {}

    // Getter method to retrieve passenger name
    string getPassengerName() const {
        return passenger_name;
    }
};

// Class definition for Car
class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
    // Constructor to initialize Car with Engine and Passenger objects
    Car(const string& engine_num, const string& passenger_name)
        : car_engine(engine_num), car_passenger(passenger_name) {}

    // Method to display engine number and passenger name
    void displayInfo() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    // Creating a Car object with specific engine number and passenger name
    Car myCar("ABC123", "John Doe");

    // Displaying car information
    myCar.displayInfo();

    return 0;
}