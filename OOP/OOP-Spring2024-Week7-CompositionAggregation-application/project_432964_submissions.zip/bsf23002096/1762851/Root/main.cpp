#include <iostream>


using namespace std;

// Define the Engine class
class Engine {
private:
    string engine_number;
public:
    Engine(string number) : engine_number(number) {}
    string getEngineNumber() {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passenger_name;
public:
    Passenger(string name) : passenger_name(name) {}
    string getPassengerName() {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine engine;
    Passenger passenger;
public:
    Car(Engine eng, Passenger pass) : engine(eng), passenger(pass) {}
    void displayInfo() {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an Engine object with engine number
    Engine carEngine("12345");

    // Create a Passenger object with passenger name
    Passenger carPassenger("John Doe");

    // Create a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display the information
    myCar.displayInfo();

    return 0;
}