/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
using namespace std;

class Engine {
private:
    string engine_num;

public:
    Engine(string num) : engine_num(num) {}

    
    string getEngineNum(){
        return engine_num;
    }
};


class Passenger {
private:
    string passenger_name;

public:
    
    Passenger(string name) : passenger_name(name) {}

    
    string getPassengerName() const {
        return passenger_name;
    }
};


class Car {
private:
    Engine carEngine;
    Passenger carPassenger; 

public:
    
    Car(string engineNum, string passengerName)
        : carEngine(engineNum), carPassenger(passengerName) {}

    
    void displayDetails() {
        cout << "Engine Number: " << carEngine.getEngineNum() << endl;
        cout << "Passenger Name: " << carPassenger.getPassengerName() << endl;
    }
};

int main() {
    
    Car myCar("52ABC12345", "Shaheer");
	myCar.displayDetails();

    return 0;
}
