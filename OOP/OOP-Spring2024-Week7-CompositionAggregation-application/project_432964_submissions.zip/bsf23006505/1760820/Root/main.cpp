#include <iostream>
#include <string>

using namespace std;
class Engine {
private:
    string engine_number;

public:
    Engine(string number) : engine_number(number) {}
    string getEngineNumber() const {
        return engine_number;
    }
};
class Passenger {
private:
    string passenger_name;

public:
    Passenger(string name) : passenger_name(name) {}
string getPassengerName() const {
        return passenger_name;
    }
};
class Car {
private:
    Engine car_engine;
    Passenger car_passenger; 

public:
        Car(string engine_number, string passenger_name) : car_engine(engine_number), car_passenger(passenger_name) {}

    void displayDetails() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    Car myCar("12345", "John");
    myCar.displayDetails();
    return 0;
}
