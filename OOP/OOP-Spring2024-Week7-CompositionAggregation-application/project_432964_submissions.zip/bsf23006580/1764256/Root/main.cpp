// Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
// The Engine has engine_number as a data member which is set in the constructor of class Engine.
// The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
// Create an object of class Car that displays the engine number and a passenger name on screen.
#include <iostream>
using namespace std;
class Engine
{
    string engine_number;

public:
    void setEngine(string e)
    {
        engine_number = e;
    }
    string getEngine()
    {
        return engine_number;
    }
};
class Passenger
{
    string passenger_name;

public:
    void setPn(string pn)
    {
        passenger_name = pn;
    }
    string getPn()
    {
        return passenger_name;
    }
};
class Car
{
private:
    Engine *car_engine;
    Passenger *car_passenger;

public:
    Car(Engine engine, Passenger passenger)
    {
        car_engine = &engine;
        car_passenger = &passenger;
    }
    void display()
    {
        cout << "Engine Number  : " << car_engine->getEngine() << endl;
        cout << "Passenger Name : " << car_passenger->getPn() << endl;
    }
};

int main()
{
    Engine car_engine;
        car_engine.setEngine("123");
    Passenger car_passenger;
    car_passenger.setPn("Maryam");
    Car c1(car_engine, car_passenger);
    c1.display();
    return 0;
}