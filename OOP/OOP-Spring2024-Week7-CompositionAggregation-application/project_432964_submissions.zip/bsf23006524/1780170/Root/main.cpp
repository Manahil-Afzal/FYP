#include <iostream>
#include <string>
using namespace std;
class Engine {
private:
    string engine_number;

public:
    Engine(string number) : engine_number(number) {}

    string getEngineNumber() const {
        return engine_number;
    }
};
class Passenger {
private:
    string passenger_name;

public:
    Passenger(string name) : passenger_name(name) {}
    string getPassengerName() const {
        return passenger_name;
    }
};


class Car {
private:
    Engine engine; 
    Passenger passenger; 
public:
    Car(string engine_number, string passenger_name) : engine(engine_number), passenger(passenger_name) {}

    void displayInfo() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    Car car("ABC123", "John Doe");
    car.displayInfo();

    return 0;
}
