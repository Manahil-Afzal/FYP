#include <iostream>
using namespace std;

string name;

class Engine{
    int engine_no;
    public:
        Engine(){
            engine_no = 219972;
        }
        void display(){
            cout<<"Engine no: "<<engine_no<<endl;

        }

};
class Passenger{
    string pass_name;
    public:
        void setName(string name){
            pass_name = name;
        }
        void display(){
            cout<<"Passenger name: "<<pass_name<<endl;
        }
};

class Car{
    public:
        Engine en;
        Passenger *p;
        Car(Passenger *p){
            this->p = p;
            en.display();
            p->setName(name);
            p->display();
        }
};

int main(){
    cout<<"Enter the name of passenger: ";
    cin>>name;
    Passenger pn;
    Car c(&pn);


    return 0;
}