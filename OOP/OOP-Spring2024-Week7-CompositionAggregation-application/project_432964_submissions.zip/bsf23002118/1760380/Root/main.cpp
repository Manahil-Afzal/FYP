// Main function of the C++ program.
#include <iostream>
using namespace std;
// Define the Engine class
class Engine {
private:
    string engine_number;
public:
    // Constructor to initialize the engine number
    Engine(string number1){
      engine_number=number1;
    }
    // Getter method to retrieve the engine number
    string getEngineNumber(){
        return engine_number;
    }
};
// Define the Passenger class
class Passenger {
private:
    string passenger_name;
public:
    Passenger(string name) {
       passenger_name=name;
    }
    string getPassengerName(){
        return passenger_name;
    }
};
class Car {
private:
    Engine* engine;
    Passenger* passenger;
public:
    Car(Engine engine1,Passenger passenger1){
      engine=&engine1;
      passenger=&passenger1;
    }
    void displayInfo() const {
        cout << "Engine Number: " << engine->getEngineNumber() <<endl;
        cout << "Passenger Name: " << passenger->getPassengerName() <<endl;
    }
};
int main() {
    Engine carEngine("007");
    Passenger carPassenger("Ali");
    Car myCar(carEngine, carPassenger);
    myCar.displayInfo();
    return 0;
}