#include <iostream>
#include <string>

using namespace std;


class Engine {
private:
    string engine_number;

public:
    
    Engine(string num) : engine_number(num) {}

    
    string getEngineNumber() {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    
    Passenger(string name) : passenger_name(name) {}

    
    string getPassengerName() {
        return passenger_name;
    }
};


class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
   
    Car(Engine engine, Passenger passenger) : car_engine(engine), car_passenger(passenger) {}

    
    void displayInfo() {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    
    Engine engine("123456");

    
    Passenger passenger("Ahmad izhar");

    
    Car car(engine, passenger);

    car.displayInfo();

    return 0;
}

