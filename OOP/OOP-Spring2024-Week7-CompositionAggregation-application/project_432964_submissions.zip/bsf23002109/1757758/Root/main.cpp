
#include <iostream>
#include <string>

// Define the Engine class
class Engine {
private:
    std::string engine_number;

public:
    // Constructor to initialize the engine number
    Engine(const std::string& number) : engine_number(number) {}

    // Getter method to retrieve the engine number
    std::string getEngineNumber() const {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    std::string passenger_name;

public:
    // Constructor to initialize the passenger name
    Passenger(const std::string& name) : passenger_name(name) {}

    // Getter method to retrieve the passenger name
    std::string getPassengerName() const {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    // Constructor to initialize engine and passenger
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    // Method to display engine number and passenger name
    void displayInfo() const {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }
};

int main() {
    // Create an Engine object
    Engine carEngine("12345");

    // Create a Passenger object
    Passenger carPassenger("John Doe");

    // Create a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display car information
    myCar.displayInfo();

    return 0;
}