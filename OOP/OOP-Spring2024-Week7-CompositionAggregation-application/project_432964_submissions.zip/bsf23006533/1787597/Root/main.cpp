#include <iostream> 
#include <cstring> 
using namespace std;

class Engine {
 private:
  int engine_number;

 public: 
  Engine(int number) : engine_number(number) {}

  int GetEngineNumber() {
   return engine_number; } };

class Passenger { 
 private: 
   char passenger_name[25];

 public: 
   Passenger(const char name[25]) { strcpy(passenger_name, name); }

   char* GetPassengerName() { return passenger_name; } };

 class Car {
  private: 
    Engine engine;
    Passenger passenger;

  public: 
    Car(int engine_number, const char passenger_name[25]) : engine(engine_number), passenger(passenger_name) {}

  void Display() { cout << "Engine number: " << engine.GetEngineNumber() << endl; cout << "Passenger name: " << passenger.GetPassengerName() << endl; } };

  int main() { Car car(123, "John Doe"); car.Display();

  return 0;
   }
