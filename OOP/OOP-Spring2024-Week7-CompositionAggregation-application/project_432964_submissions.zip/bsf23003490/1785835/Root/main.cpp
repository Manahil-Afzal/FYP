// Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
// The Engine has engine_number as a data member which is set in the constructor of class Engine.
// The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
// Create an object of class Car that displays the engine number and a passenger name on screen.

#include <iostream>
#include <string>

using namespace std;

// Define the Engine class
class Engine {
private:
    string engine_number;

public:
    // Constructor to set the engine number
    Engine(string num) : engine_number(num) {}

    // Function to get the engine number
    string getEngineNumber() const {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to set the passenger name
    Passenger(string name) : passenger_name(name) {}

    // Function to get the passenger name
    string getPassengerName() const {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    // Constructor to initialize engine and passenger
    Car(Engine eng, Passenger pass) : engine(eng), passenger(pass) {}

    // Function to display engine number and passenger name
    void displayInfo() {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an Engine object
    Engine carEngine("ABC123");

    // Create a Passenger object
    Passenger carPassenger("John Doe");

    // Create a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display the information
    myCar.displayInfo();

    return 0;
}
