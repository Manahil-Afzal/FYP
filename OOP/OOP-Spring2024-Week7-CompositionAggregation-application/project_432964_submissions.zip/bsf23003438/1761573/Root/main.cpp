//Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
//The Engine has engine_number as a data member which is set in the constructor of class Engine.
//The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
//Create an object of class Car that displays the engine number and a passenger name on screen.
#include<iostream>
#include<string>
using namespace std;
class Engine{
   private:
  int eng_num;
    
    public:
    
    Engine(int x){
        eng_num=x;
    }
    void display(){
        cout<<"Enter the engine number: "<<eng_num<<endl;
    }
   
    };
    class Passenger{
        private:
        string pass_name;
        public:
        Passenger(){}
        void setdata()
        {
            cout<<"Enter the name of passenger :"<<endl;
            cin>>pass_name;
            
        }
        void getdata(){
            cout<<"The name of Passenger is: "<<pass_name<<endl;
        }
        
         };
         class Car{
             Engine engine_number;
             Passenger *passenger;
             public:
             Car(int enginenumber,Passenger &pass):  engine_number(enginenumber),
                 passenger(&pass){
               
                 passenger->setdata();
             }
             void show(){
                 engine_number.display();
                 passenger->getdata();
                 
             }
             
         };
         int main()
         {
           Passenger pass;  
             Car c1(123,pass);
             c1.show();
             return 0;}