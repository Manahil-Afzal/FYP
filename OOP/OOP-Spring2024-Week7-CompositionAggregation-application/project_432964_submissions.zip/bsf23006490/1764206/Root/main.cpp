// Main function of the C++ program.
//****CODE****
#include <iostream>
using namespace std;
class Car{
	private:
		int eng_num;
		string p_name;
		public:
		void set_eng_num(int i){
				eng_num=i;
			}
		int get_eng_num(){
			return eng_num;
		}
		void set_pass_name(string name)
		{
			p_name=name;
		}
		 string get_pass_name(){
			return p_name;
		}
		};
class Engine{
	private:
		Car *engine;
		public:
			Engine(Car engine2){
				engine=&engine2;
				engine->set_eng_num(999);
			}
			void show(){
				cout<<"ENGINE NUMBER:"<<engine->get_eng_num()<<endl;
			}
};
class Passenger{
	private:
	 Car *p_name;
	 public:
	 	Passenger(Car Pnum1){
	 		p_name=&Pnum1;
	 		p_name->set_pass_name("Ahmad");
		 }
	 	void show1(){
	 		cout<<"PASSENGER NAME:"<<p_name->get_pass_name()<<endl;
		 }
};
int main(){
	Car engine1;
	Engine E(engine1);
	E.show();
	Car pass1;
	Passenger P(pass1);
	P.show1();
}

