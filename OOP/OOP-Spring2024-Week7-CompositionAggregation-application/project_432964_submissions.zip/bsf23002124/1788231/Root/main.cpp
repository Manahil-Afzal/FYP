#include <iostream>
#include <string>
using namespace std;

// Engine class
class Engine {
private:
    string engine_number;

public:
    // Constructor to set engine number
    Engine(string number) : engine_number(number) {}

    // Method to get engine number
    string getEngineNumber() const {
        return engine_number;
    }
};

// Passenger class
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to set passenger name
    Passenger(string name) : passenger_name(name) {}

    // Method to get passenger name
    string getPassengerName() const {
        return passenger_name;
    }
};

// Car class with aggregation relationship
class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
    // Constructor to initialize car's engine and passenger
    Car(Engine engine, Passenger passenger) : car_engine(engine), car_passenger(passenger) {}

    // Method to display engine number and passenger name
    void displayDetails() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create Engine object
    Engine car_engine("CG$57H865");

    // Create Passenger object
    Passenger car_passenger("Shoaib Akhtar");

    // Create Car object with Engine and Passenger objects
    Car my_car(car_engine, car_passenger);

    // Display car details
    my_car.displayDetails();

    return 0;
}
