// Main function of the C++ program.Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
/*The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/

#include <iostream>
using namespace std;
class engine
{
   string engine_num;
    public:
    engine()
    {

        cout<<"enter engine name:"<<endl;
        cin>>engine_num;
    }
    void display()
    {
        cout<<"Engine number is:"<<engine_num<<endl;
    }
};
class passenger 
{
    string pass_name;
    public:
    void getname()
    {
    		cout<<"Enter name:"<<endl;
        cin>>pass_name;
    }
    void displayname()
    {
    
        cout<<"The name is :"<<pass_name<<endl;
    }
};
class car
{
    engine eng;
    passenger *name[10];
    public:
    void show(){
    eng.display();
    for(int k=0;k<10;k++)
    {
        name[k]->displayname();
    }
    }
    void pass(passenger arr[],int size=10)
    {
        for(int i=0;i<10;i++)
        {
            name[i]=&arr[i];
        }
        for (int j=0;j<10;j++)
        {
            name[j]->getname();
        }
        
    }
    
};
int main()
{
    car c1;
    passenger p1[10];
    c1.pass(p1,10);
    c1.show();
    
    
}


