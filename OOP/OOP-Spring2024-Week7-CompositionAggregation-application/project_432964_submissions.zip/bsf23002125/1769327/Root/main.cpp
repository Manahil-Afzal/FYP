#include <iostream>
using namespace std;

class Engine{
private:
    int engineNumber;

public:
    void setEngineNumber(int eng){engineNumber = eng;}
    int getEngineNumber(){return engineNumber;}
    Engine(int eng){setEngineNumber(eng);}
};

class Passenger{
private:
    string passengerName;

public:
    void setPassengerName(string pn){passengerName = pn;}
    string getPassengerName(){return passengerName;}
    Passenger (string pn){setPassengerName(pn);}
};

class Car{
private:
    Engine engine;
    Passenger* passenger;

public:
    Car(Passenger* pass, Engine eng): passenger(pass), engine(eng){}
    void display(){   
        cout << "The engine number of car is: " << engine.getEngineNumber() << endl;
        cout << "The passenger name is: " << passenger->getPassengerName() << endl;
    }
};

int main (){
    Passenger passenger2("Abdul Rehman");
    Engine eng1(9211);
    Car car1(&passenger2, eng1);
    car1.display();

    return 0;
}