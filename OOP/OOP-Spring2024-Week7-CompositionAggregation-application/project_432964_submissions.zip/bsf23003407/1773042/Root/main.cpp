#include <iostream>
#include <string>

using namespace std;

// Define the Engine class
class Engine {
private:
    string engineNumber;

public:
    Engine(const string& number) : engineNumber(number) {}

    string getEngineNumber() const {
        return engineNumber;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passengerName;

public:
    Passenger(const string& name) : passengerName(name) {}

    string getPassengerName() const {
        return passengerName;
    }
};

// Define the Car class with aggregation relationships
class Car {
private:
    Engine carEngine;
    Passenger carPassenger;

public:
    Car(const string& engineNumber, const string& passengerName)
        : carEngine(engineNumber), carPassenger(passengerName) {}

    void displayInfo() const {
        cout << "Engine Number: " << carEngine.getEngineNumber() << endl;
        cout << "Passenger Name: " << carPassenger.getPassengerName() << endl;
    }
};

int main() {
    // Create a Car object
    Car myCar("ABC123", "John Doe");

    // Display car information
    myCar.displayInfo();

    return 0;
}
