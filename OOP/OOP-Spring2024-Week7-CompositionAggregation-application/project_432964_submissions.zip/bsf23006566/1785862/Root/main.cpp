//Write a C++ program that creates a class named Car. It has an object of user defined type 
//called Engine.
//The Engine has engine_number as a data member which is set in the constructor of class Engine.
//The class Car has an aggregation relationship with another user defined class called Passenger
// which has passenger_name as its data member.
//Create an object of class Car that displays the engine number and a passenger name on screen.

#include<iostream>
#include<string>
using namespace std;

class Engine{
	int engine_number;
	public:
	    Engine(int eng_no=0){
	        engine_number=eng_no;
	    }
	   // 2nd Method
// 		void set_Engine_No(int eng_no){
// 			engine_number=eng_no;
// 		}
		int get_Engine_No(){
		return engine_number;
		}
};
class Passenger{
	string passenger_name;
	public:
	    Passenger(string name=""){
	        passenger_name=name;
	    }
	   // 2nd Method
// 		void set_Passenger_Name(string name){
// 			passenger_name=name;
// 		}
		string get_Passenger_Name(){
		return passenger_name;
		}
};
class Car{
	Engine eng;
	Passenger p1;
	public:
		Car(int engr,string name):eng(engr),p1(name){
		  //  2nd Method
// 			eng.set_Engine_No(engr);
// 			p1.set_Passenger_Name(name);	
		}
		
		void display(){
			cout<<"Passenger Name: "<<p1.get_Passenger_Name()<<endl;
			cout<<"Engine Number: "<<eng.get_Engine_No();
		}
		
};

int main(){
	Car c1(34,"rizwan");
	c1.display();
	return 0;
}