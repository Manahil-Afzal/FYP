/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/


#include<iostream>
using namespace std;
class Engine{
	private :
		int eng_num;
	public :
	     Engine(const int& num){
	     	 eng_num=num;
		 }
		 int get_engine_num()const{
		 	return eng_num;
		 }
};
class Passenger{
	private :
		string passName;
	public :
		Passenger(const string& name){
			passName=name;
		}
	 
	   string get_passName()const{
	   	    return passName;
	   }	
};
class Car{
	private :
	   
		Engine engine;
		Passenger passenger;
	public :
	   
	   Car( const Engine& eng ,  const Passenger& pass):engine(eng),passenger(pass){
	   	
	   
	   }
		void display(){   
			cout<<"The engine no of car is :"<<engine.get_engine_num()<<endl;
		    cout<<"passenger Name :"<<passenger.get_passName()<<endl;
		} 
	
	

		
};
int main(){
	Engine eng1(46878);
	Passenger pass1("Abdullah");
     Car c1(eng1,pass1);
     
     c1.display();

	}


