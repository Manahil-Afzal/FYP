// Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.The Engine has engine_number as a data member which is set in the constructor of class Engine. The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member. Create an object of class Car that displays the engine number and a passenger name on screen.

#include <iostream>
#include <string>
using namespace std;

// Class definition for Engine
class Engine
{
private:
    string engineNumber;

public:
    Engine() {}

    Engine(string number)
    {
        engineNumber = number;
    }

    string getEngineNumber() const
    {
        return engineNumber;
    }
};

// Class definition for Passenger
class Passenger
{
private:
    string passengerName;

public:
    Passenger() {}
    Passenger(string name)
    {
        passengerName = name;
    }

    string getPassengerName()
    {
        return passengerName;
    }
};

// Class definition for Car
class Car
{
private:
    Engine carEngine;
    Passenger carPassenger;

public:
    Car(string engineNumber, string passengerName)
    {
        carEngine = Engine(engineNumber);
        carPassenger = Passenger(passengerName);
    }

    void displayDetails() 
    {
        cout << "Engine Number: " << carEngine.getEngineNumber() << endl;
        cout << "Passenger Name: " << carPassenger.getPassengerName() << endl;
    }
};

int main()
{
    Car myCar("123456", "Hamaad Afzal");

    cout << "Car Details:" << endl;
    myCar.displayDetails();

    return 0;
}