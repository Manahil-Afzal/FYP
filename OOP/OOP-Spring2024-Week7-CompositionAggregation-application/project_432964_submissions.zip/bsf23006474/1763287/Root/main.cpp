// Main function of the C++ program.

 #include <iostream>
using namespace std;


class Engine {
private:
    string engine_num;
    public:
    	Engine(string num)
    	{
    		engine_num=num;
		}
    string getData(){
    return engine_num;
	}
};

class Passenger {
private:
    string passenger_name;
    public:
    	Passenger(string name)
   {
        passenger_name=name;
     }
    string getData(){
    return passenger_name;
	}
};

class Car {
private:
    Engine *engine;
    Passenger *passenger;
    public:
    Car(Engine engine1, Passenger passenger1)
	{
	engine=&engine1;
	passenger=&passenger1;
}

    void displayDetails() {
        std::cout << "Engine Number: " << engine->getData()<<endl;
        std::cout << "Passenger Name: " << passenger->getData()<<endl;
    }
};

int main() {
	Engine engine("12345");
	Passenger passenger("Aiza");
    Car myCar(engine, passenger);

    myCar.displayDetails();

    return 0;
}