#include <iostream>
#include <string>
using namespace std;

// Engine class
class Engine {
private:
    string engine_number; // Data member for engine number

public:
    // Constructor to initialize engine_number
    Engine(string engineNum) {
        engine_number = engineNum;
    }

    // Method to display engine number
    void displayEngineNumber() const {
        cout << "Engine Number: " << engine_number << endl;
    }
};

// Passenger class
class Passenger {
private:
    string passenger_name; // Data member for passenger name

public:
    // Constructor to initialize passenger_name
    Passenger(string name) {
        passenger_name = name;
    }

    // Method to display passenger's name
    void displayPassengerName() const {
        cout << "Passenger Name: " << passenger_name << endl;
    }
};

// Car class
class Car {
private:
    Engine engine;       // Object of Engine class
    Passenger passenger; // Object of Passenger class

public:
    // Constructor to initialize Car, Engine, and Passenger
    Car(string engineNum, string name) : engine(engineNum), passenger(name) {}

    // Method to display Car details (engine number and passenger name)
    void displayCarDetails() const {
        engine.displayEngineNumber();
        passenger.displayPassengerName();
    }
};

int main() {
    // Create an object of Car, which initializes Engine and Passenger
    Car myCar("EN123456", "John Doe");

    // Display the car details
    cout << "Car Details:" << endl;
    myCar.displayCarDetails();

    return 0;
}
