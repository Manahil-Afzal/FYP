// Main function of the C++ program.
#include<iostream> 
using namespace std; 
class Engine{    
    private: 
    string eng_number;
    public:    
    Engine(){ 
        eng_number="BMX1122"; 
    } 
    string getEng_Number()
        {         return eng_number; 
    }  }; 
class Passenger{     private: 
    string Passenger_Name;     public: 
     void setName(string name){ 
         Passenger_Name=name; 
     }  
     string getName(){          return Passenger_Name; 
     } }; class Car{   private: 
  Engine engine;   Passenger* passenger;   public: 
    Car(Passenger psngr){ 
     passenger=&psngr;          passenger->setName("sara"); 
 }   void get(){      cout<<"Engine Number : " <<engine.getEng_Number()<<endl;       cout<<"Passenger Name : "<<passenger->getName()<<endl; 
  } 
}; int main(){     Passenger PSNG;     Car car(PSNG);     car.get();     return 0;} 