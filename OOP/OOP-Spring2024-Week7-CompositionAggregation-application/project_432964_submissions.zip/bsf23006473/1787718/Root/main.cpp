#include <iostream>
using namespace std;

// Define the Engine class
class Engine {
private:
    string engine_number;

public:
    // Constructor to set the engine number
    Engine(string num) : engine_number(num) {}

    // Function to get the engine number
    string getEngineNumber() const {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to set the passenger name
    Passenger(string name) : passenger_name(name) {}

    // Function to get the passenger name
    string getPassengerName() const {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine car_engine; // Object of Engine class
    Passenger car_passenger; // Object of Passenger class

public:
    // Constructor to initialize car_engine and car_passenger
    Car(string engine_number, string passenger_name) : car_engine(engine_number), car_passenger(passenger_name) {}

    // Function to display engine number and passenger name
    void display() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an object of Car
    Car myCar("123456", "John Doe");

    // Display engine number and passenger name
    myCar.display();

    return 0;
}
