/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen*/
#include <iostream>
#include <string>
using namespace std;

// Define the Passenger class
class Passenger {
public:
    Passenger(const std::string& name) : passenger_name(name) {}

    void display_passenger_name() const {
        std::cout << "Passenger Name: " << passenger_name << std::endl;
    }

private:
    std::string passenger_name;
};

// Define the Engine class
class Engine {
public:
    Engine(int engine_number) : engine_number(engine_number) {}

    void display_engine_number() const {
        std::cout << "Engine Number: " << engine_number << std::endl;
    }

private:
    int engine_number;
};

// Define the Car class
class Car {
public:
    Car(int engine_number, const std::string& passenger_name)
        : engine(engine_number), passenger(passenger_name) {}

    void display() const {
        engine.display_engine_number();
        passenger.display_passenger_name();
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    Car car(123, "John Doe");
    car.display();

    return 0;
}
