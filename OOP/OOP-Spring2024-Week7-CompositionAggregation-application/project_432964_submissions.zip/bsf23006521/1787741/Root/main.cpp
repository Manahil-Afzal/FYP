#include <iostream>
#include <string>

using namespace std;

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const { 
        return passenger_name;
    }
};

class Engine {
private:
    string engine_number;

public:
    Engine(const string& number) : engine_number(number) {}

    string getEngineNumber() const { 
        return engine_number;
    }
};

class Car {
private:
    Engine engine;        // Composition: Car has an Engine
    const Passenger& passenger;  // Aggregation: Car has a reference to Passenger

public:
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    void displayDetails() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine carEngine("12345");
    Passenger carPassenger("Abdullah");

    Car myCar(carEngine, carPassenger);

    myCar.displayDetails();

    return 0;
}
