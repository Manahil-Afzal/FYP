// Main function of the C++ program.

#include <iostream>
using namespace std;

// Define the Engine class
class Engine {
private:
    string engine_number;

public:
    // Constructor to initialize the engine number
    Engine(string number1){
      engine_number=number1;
    }

    // Getter method to retrieve the engine number
    string getEngineNumber(){
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to initialize the passenger name
    Passenger(string name) {
       passenger_name=name;
    }

    // Getter method to retrieve the passenger name
    string getPassengerName(){
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine* engine;
    Passenger* passenger;

public:
    // Constructor to initialize engine and passenger
    Car(Engine engine1,Passenger passenger1){
      engine=&engine1;
      passenger=&passenger1;
    }

    // Method to display engine number and passenger name
    void displayInfo() const {
        cout << "Engine Number: " << engine->getEngineNumber() <<endl;
        cout << "Passenger Name: " << passenger->getPassengerName() <<endl;
    }
};

int main() {
    // Create an Engine object
    Engine carEngine("12345");

    // Create a Passenger object
    Passenger carPassenger("asad");

    // Create a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display car information
    myCar.displayInfo();

    return 0;
}
