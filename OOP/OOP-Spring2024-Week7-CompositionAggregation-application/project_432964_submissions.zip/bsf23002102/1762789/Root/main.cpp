/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
using namespace std;
class Engine {
private:
    int engine_number;
public:
    Engine ( int num ) {
engine_number = num;
}
    void display_engine_number() {
        cout << "Engine number: " << engine_number << endl;
    }
};
class Passenger {
private:
    string passenger_name;
public:
        Passenger(const string& name){
passenger_name = name;
}
    void display_passenger_name() {
       cout << "Passenger's name: " << passenger_name << endl;
    }
};
class Car {
private:
    Engine car_engine;
    Passenger* car_passenger;
public:
        Car ( int engine_number, const string& passenger_name ) : car_engine ( engine_number ) {
       car_passenger = new Passenger ( passenger_name );
    }
    void display_car_data() {
       car_engine.display_engine_number();
        car_passenger->display_passenger_name();
    }
};
int main() {
    Car my_car(123, "Asad");
    my_car.display_car_data();
    return 0;
}