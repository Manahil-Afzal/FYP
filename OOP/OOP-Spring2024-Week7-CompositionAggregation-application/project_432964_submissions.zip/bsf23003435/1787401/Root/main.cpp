// Main function of the C++ program.

#include <iostream>
#include <string>
using namespace std;
// Class Engine
class Engine {
private:
 string engine_number;
public:
 // Constructor
 Engine(const string& num) : engine_number(num) {}
 // Getter method
 string getEngineNumber() const {
 return engine_number;
 }
};
// Class Passenger
class Passenger {
private:
 string passenger_name;
public:
 // Constructor
 Passenger(const string& name) : passenger_name(name) {}
 // Getter method
 string getPassengerName() const {
 return passenger_name;
 }
};
// Class Car
class Car {
private:
 Engine engine;
 Passenger passenger;
public:
 // Constructor
 Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}
 // Method to display engine number and passenger name
 void displayInfo() const {
 cout << "Engine Number: " << engine.getEngineNumber() << endl;
 cout << "Passenger Name: " << passenger.getPassengerName() << endl;
 }
};
int main() {
 // Creating objects of Engine and Passenger
 Engine carEngine("123456");
 Passenger carPassenger("John Doe");
 // Creating object of Car
 Car myCar(carEngine, carPassenger);
 // Displaying information
 myCar.displayInfo();
 return 0;
}
