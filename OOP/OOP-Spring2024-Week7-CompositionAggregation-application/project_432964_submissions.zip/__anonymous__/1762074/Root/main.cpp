/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>
using namespace std;

class Engine {
private:
    string engine_number;

public:
    Engine(const string& eng_num) : engine_number(eng_num) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    void displayInfo() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine carEngine("675");
    Passenger carPassenger("Ahmad");

    Car car(carEngine, carPassenger);
    car.displayInfo();

    return 0;
}


