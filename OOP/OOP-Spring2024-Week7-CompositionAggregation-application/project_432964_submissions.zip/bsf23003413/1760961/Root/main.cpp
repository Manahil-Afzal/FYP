/* Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen. */
#include<iostream>
using namespace std;
class engine
{
 int eng_num;
 public:
 engine(int en)
 {
  eng_num=en;
 }
 void display()
 {
  cout<<"Engine number: "<<eng_num;
 }
};
class passenger
{
 string name;
 public:
 void setdata()
 {
  cout<<"Enter the Passenger's name: ";
  cin>>name;
 }
 void getdata()
 {
  cout<<"Passenger's name: "<<name<<endl;	
 }
};
class car
{
engine eng=112;
passenger *pass;
public:
car(passenger &p1)
{
  pass=&p1;
  pass->setdata();
}
void show()
 {
 pass->getdata();
 eng.display();
 }	
};
int main()
{
 passenger p2;
 car c1(p2);
 c1.show();
}
