#include <iostream>
using namespace std;

class Engine {
public:
    string engine_number;
    Engine(string number){
        engine_number = number;
        }

};

class Passenger {
public:
    string passenger_name;
    Passenger(string name){
    passenger_name = name;
    } 
};

class Car {
private:
    Engine engine;       
    Passenger passenger;    
public:

    Car(Engine eng, Passenger pass) : engine(eng), passenger(pass) {}

    void displayDetails() {
        cout << "Engine Number: " << engine.engine_number << endl;
        cout << "Passenger Name: " << passenger.passenger_name << endl;
    }


};

int main() {
    Engine car_engine("9456");
    Passenger car_passenger("JD");

    Car my_car(car_engine, car_passenger);

    my_car.displayDetails();

    return 0;
}
