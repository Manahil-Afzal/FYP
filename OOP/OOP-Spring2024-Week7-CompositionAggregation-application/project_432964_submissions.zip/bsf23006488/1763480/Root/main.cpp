// Main function of the C++ program.
// Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
// The Engine has engine_number as a data member which is set in the constructor of class Engine.
// The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
// Create an object of class Car that displays the engine number and a passenger name on screen.

#include <iostream>
using namespace std;

class Engine {
private:
    string engine_number;

public:
    Engine(const string& num) : engine_number(num) {}

    string get_engine_number() const {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string get_passenger_name() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    void display_info() const {
        cout << "Engine Number: " << engine.get_engine_number() << endl;
        cout << "Passenger Name: " << passenger.get_passenger_name() << endl;
    }
};

int main() {
    Engine engine("12345");
    Passenger passenger("John Doe");
    Car car(engine, passenger);
    car.display_info();
    return 0;
}

