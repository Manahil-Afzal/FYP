// Main function of the C++ program.

#include <iostream>
#include <string>

using namespace std;

// Class Engine
class Engine {
private:
    string engine_number;

public:
    // Constructor to set engine number
    Engine(const string& num) : engine_number(num) {}

    // Getter function to retrieve engine number
    string getEngineNumber() const {
        return engine_number;
    }
};

// Class Passenger
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to set passenger name
    Passenger(const string& name) : passenger_name(name) {}

    // Getter function to retrieve passenger name
    string getPassengerName() const {
        return passenger_name;
    }
};

// Class Car
class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
    // Constructor initializing Car's engine and passenger
    Car(const Engine& engine, const Passenger& passenger)
        : car_engine(engine), car_passenger(passenger) {}

    // Function to display engine number and passenger name
    void displayInfo() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    // Creating an Engine object
    Engine carEngine("ABC123");

    // Creating a Passenger object
    Passenger carPassenger("Javed");

    // Creating a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Displaying car information
    myCar.displayInfo();

    return 0;
}
