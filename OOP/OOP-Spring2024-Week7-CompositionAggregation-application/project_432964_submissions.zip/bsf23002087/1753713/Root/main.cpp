#include<iostream>
using namespace std;
class Passenger{
private:
string passenger_name;
public:
Passenger(){}
Passenger(string name){
    passenger_name=name;
}
string getpass(){
    return passenger_name;
}


};
class Engine{
    private:
    int Engine_number;
    public:
    Engine(){}
    Engine(int num){
        Engine_number=num;
    }
    int geteng(){
        return Engine_number;
    }
};
class Car{
    private:
    Engine engine;
    Passenger *passenger;
    public:
    Car(){}
    Car(Passenger passenger1,Engine E1){
        passenger=&passenger1;
        engine=E1;


    }
    void display(){
        cout<<engine.geteng()<<endl;
        cout<<passenger->getpass()<<endl;
    }
};
int main(){
    cout<<"Please enter the Passengers Name: "<<endl;
    string name;
    getline(cin,name);
    Passenger p1(name);
    cout<<"Please enter the Engine Number: "<<endl;
    int num;
    cin>>num;
    Engine E1(num);
    Car c1(p1, E1);
    c1.display();
    return 0;
}