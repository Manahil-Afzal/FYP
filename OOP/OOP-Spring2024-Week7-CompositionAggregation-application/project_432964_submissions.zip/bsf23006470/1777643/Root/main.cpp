// Main function of the C++ program.

#include <iostream>
#include <string>

using namespace std;
class Engine {
private:
    string engine_number;

public:
    Engine(const string& number) : engine_number(number) {}
    string getEngineNumber() const {
        return engine_number;
    }
};
class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}
    string getPassengerName() const {
        return passenger_name;
    }
};
class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
    Car(const Engine& engine, const Passenger& passenger)
        : car_engine(engine), car_passenger(passenger) {}
    void displayInfo() {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine engine("ABC123");
    Passenger passenger("Aryan Hadi");
    Car car(engine, passenger);
    car.displayInfo();

    return 0;
}
