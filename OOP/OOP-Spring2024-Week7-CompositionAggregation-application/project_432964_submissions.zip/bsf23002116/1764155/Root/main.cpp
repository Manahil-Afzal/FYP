#include <iostream>
using namespace std;
class Engine {
private:
    int engine_num;

public:
    Engine(int egn) {
        engine_num = egn;
    }
    void get_engine_num() {
        cout << "engine num:" << engine_num << endl;
    }
};

class Passenger {
private:
    string name;
public:
    void set_name() {
        cout<<"passenger name:"<< endl;
        cin>>name;
    }
    void get_name() {
        cout << "passenger name:" << name << endl;
    }
};

class Car {
private:
    Engine En=125;
    Passenger* psgr;

public:
    Car(Passenger& p1){
        psgr = &p1;
        psgr->set_name();
    }

    void get_detail() {
        En.get_engine_num();
        psgr->get_name();
    }
};
int main() {
    Passenger passenger1;
    Car c1(passenger1);
    c1.get_detail();
    return 0;
}
