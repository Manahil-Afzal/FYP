#include<iostream>
using namespace std;
class Engine{
	private :
		int eng_num;
	public :
	     Engine(const int& num){
	     	 eng_num=num;
		 }
		 int get_engine_num()const{
		 	return eng_num;
		 }
};
class Passenger{
	private :
		string passName;
	public :
		Passenger(const string& name){
			passName=name;
		}
	 
	   string get_passName()const{
	   	    return passName;
	   }	
};
class Car{
	private :
	   Engine engine;
	   Passenger passenger;
	public :
	   
	   Car( const Engine& eng ,  const Passenger& pass):engine(eng),passenger(pass){}
	   void display(){   
			cout<<"The engine no of car is :"<<engine.get_engine_num()<<endl;
		    cout<<"passenger Name :"<<passenger.get_passName()<<endl;
		} 
};
int main(){
	Engine eng1(547383);
	Passenger pass1("Hammad");
    Car c1(eng1,pass1);
     
    c1.display();
}
