#include<iostream>
using namespace std;
class Engine{
private:
	string engine_number;
public:
    Engine(string num):
    engine_number(num){}
    string getEngineNumber(){
    return engine_number;
	}
};
class Passenger{
private:
	string passenger_name ;
public:
	Passenger(string name):
	passenger_name(name){}
	string getPassengerName(){
	return passenger_name;
	}
};
class Car{
private:
	Engine car_engine;
	Passenger car_passenger;
public:
	Car(string engine_number,string passenger_name):
	car_engine(engine_number),
	car_passenger(passenger_name){}
	void getOutput(){
	cout<<"The Engine number is "<<car_engine.getEngineNumber();
	cout<<"\nThe Passenger name is "<<car_passenger.getPassengerName();
	}
};
int main(){
	Car car1("FAW7221","Asma");
	car1.getOutput();
}
