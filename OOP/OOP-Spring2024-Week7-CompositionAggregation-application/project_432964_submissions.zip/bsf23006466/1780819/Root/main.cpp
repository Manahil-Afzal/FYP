// Main function of the C++ program.Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
//The Engine has engine_number as a data member which is set in the constructor of class Engine.
//The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
//Create an object of class Car that displays the engine number and a passenger name on screen.

#include <iostream>

using namespace std;

class Engine {
private:
    int engine_number;

public:
    Engine(int number) {
    	engine_number=number;
	}

    int getEngineNumber(){
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(string name){
     passenger_name=name;   	
	}
    string getPassengerName() {
        return passenger_name;
    }
};

class Car {
private:
    Engine car_engine; 
    Passenger car_passenger; 

public:

    Car(string passenger_name , int engine_number ):  car_passenger(passenger_name) , car_engine(engine_number) {}
    void displayInfo()  {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};
int main() {
    Car myCar("M.Muaaz",123);
    myCar.displayInfo();

    return 0;
}
