// Main function of the C++ program.

#include<iostream>
using namespace std;
class Engine{
	int engine_number;
	public:
		void set_engine_number(int engine_number1){
			engine_number=engine_number1;
		}
		int get_engine_number(){
			return engine_number;
		}
};
class Passanger{
	private:
	string passanger_name;
	public:
		void set_name(string name1){
			passanger_name=name1;
		}
	string get_name(){
		return passanger_name;
	}
};

class Car{
		public:
	Engine* engine;
	Passanger* passanger;
	      
		   Car(Engine &e,Passanger &n){
		   	engine=&e;
		   	passanger=&n;
		   	engine->set_engine_number(23);
		   	passanger->set_name("Asadullah Anasari");
		   }
	
	
	void show(){
	
	cout<<"Engine number is ="<<engine->get_engine_number()<<endl;
	cout<<"Name of passanger is="<<passanger->get_name()<<endl;
	}
};

int main(){
    Engine E2;
    Passanger N2;
    Car c1(E2,N2);          
	c1.show();
	return 0;
}