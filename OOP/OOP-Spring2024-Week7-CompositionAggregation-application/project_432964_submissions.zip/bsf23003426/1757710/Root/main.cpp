//Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
//The Engine has engine_number as a data member which is set in the constructor of class Engine.
//The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
//Create an object of class Car that displays the engine number and a passenger name on screen.
#include<iostream>
using namespace std;
class engine
{
    string engineno;
    public:
    
    engine()
    {
    	
    	cout<<"engine no";
    	cin>>engineno;
      
    }
    void display()
    {
     cout<<"engine num"<<engineno;   
    }
    
};
class passenger
{
    string passenger_name;
    public:
    void setdata(){
    	cout<<"name";
        getline(cin,passenger_name);
        
        
    }
    void getdata()
    {
        cout<<"passenger_name is"<<passenger_name;
    }
};
class car
{
	engine e1;
    
    passenger *p1[10];
    public:
    void showdata()
    {
         e1.display();
        for(int k=0;k<10;k++)
        {
            p1[k]->getdata();
        }}
    
void pass(passenger arr[],int size=10)
{
    for(int i=0;i<10;i++)
    {
        p1[i]=&arr[i];
    }
    for(int j=0;j<10;j++)
    {
        p1[j]->setdata();
    }
    }
};
int main()
{
    car c1;
    passenger p2[10];
    c1.pass(p2,10);
    c1.showdata();
    return 0;
}


