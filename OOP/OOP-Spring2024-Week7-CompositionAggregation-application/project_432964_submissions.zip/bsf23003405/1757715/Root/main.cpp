/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include<string>
using namespace std;
class engine{
  string engno;
  public:
  engine(){
      cout<<"Enter eng name"<<endl;
      cin>>engno;
  }
  void getdata(){
      cout<<"The eng no is"<<engno<<endl;
  }
};
class passenger{
  string passname;
  public:
  void setdata(){
      cout<<"Enter your name"<<endl;
      cin>>passname;
  }
  void getpdata(){
      cout<<"The passenger name is:"<<passname<<endl;
  }
};
class car{
    engine e;
    passenger *p[10];
    public:
    void setrdata(passenger p2[],int size){
        for(int i=0;i<size;i++){
            p[i]=&p2[i];
        }
        for(int j=0;j<size;j++){
            p[j]->setdata();
        }
}
void showdata(){
   e.getdata();
for(int j=0;j<10;j++){
    p[j]->getpdata();
}
}
};
int main()
{
    car c1;
    passenger p[10];
    c1.setrdata(p,10);
    c1.showdata();
}
