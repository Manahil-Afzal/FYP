#include <iostream>
#include <string>

using namespace std;

// Class representing the Engine
class Engine {
private:
    string engine_number;

public:
    // Constructor to set engine number
    Engine(const string& number) : engine_number(number) {}

    // Function to get engine number
    string getEngineNumber() const {
        return engine_number;
    }
};

// Class representing the Passenger
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to set passenger name
    Passenger(const string& name) : passenger_name(name) {}

    // Function to get passenger name
    string getPassengerName() const {
        return passenger_name;
    }
};

// Class representing the Car
class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    // Constructor to initialize engine and passenger
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    // Function to display engine number and passenger name
    void displayDetails() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an Engine object with engine number "ENG123"
    Engine carEngine("ENG123");

    // Create a Passenger object with name "John Doe"
    Passenger carPassenger("John Doe");

    // Create a Car object with the Engine and Passenger objects
    Car myCar(carEngine, carPassenger);

    // Display car details
    myCar.displayDetails();

    return 0;
}

