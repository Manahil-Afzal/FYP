#include <iostream>
using namespace std;

class Engine {
private:
    string engine_number;

public:
    Engine(const string& number) : engine_number(number) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    void displayDetails() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine car_engine("ABC12345"); // Example engine number
    Passenger car_passenger("John Doe"); // Example passenger name

    Car my_car(car_engine, car_passenger);

    cout << "Car Details:" << endl;
    my_car.displayDetails();

    return 0;
}
