// Main function of the C++ program.
#include<iostream>
using namespace std;

class Engine{
	private:
		int engine_number;
		public:
		void setEngineNumber(int i){
			engine_number=i;
		}
		int getEngineNumber(){
			return engine_number;
		}
};
    class Passenger{
    	private:
    		string nameOfPassenger;
    	public:
    		void setPassengerName(const string &n){
    			nameOfPassenger=n;
			}
			string getPassengerName(){
				return nameOfPassenger;
			}
	};
    class Car{
    	Engine *objEngine;
    	Passenger *objPassenger;
    	
    public:
    	Car(Engine &e, Passenger &n){
    		objEngine = &e;
    		objPassenger = &n;
    		objEngine->setEngineNumber(125786);
    		
    		objPassenger->setPassengerName("SHERAZ KHAN");
		}
		
		void show(){
			cout<<"The Engine Name Is:"<<objEngine->getEngineNumber()<<endl;
			cout<<"The Passenger Name Is:"<<objPassenger->getPassengerName()<<endl;
		}
	};
	
	int main(){
		Engine E2;
		Passenger N2;
			
			Car p1(E2,N2);
			p1.show();
			return 0;
	}
	
	
	
	
	
	
	
	
	
	
	
	