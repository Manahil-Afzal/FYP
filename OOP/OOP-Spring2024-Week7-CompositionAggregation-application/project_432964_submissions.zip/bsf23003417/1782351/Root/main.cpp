//Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
//The Engine has engine_number as a data member which is set in the constructor of class Engine.
//The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
//Create an object of class Car that displays the engine number and a passenger name on screen.
#include<iostream>
using namespace std;

class Engine{
	private:
			int no;
	public:
	Engine(int n){
		no=n;
	}
	int getno(){
	return no;
	}
};
class Passenger{
	private:
	string name;
	public:
		void set(){
			cout<<" enter name : \n";
			cin>>name;
		}
		string get(){
			cout<<"Passenger Name is : \n";
			return name;
		}
};
class Car{
	private:
	Engine engine;
	Passenger *passenger;
	public:
	Car(Passenger pp,int eng) : passenger(&pp), engine(eng) {}
	void showno(){
		cout<<"\nEngine number : \n"<<engine.getno()<<endl;
	}
	void showname(){
		passenger->set();
		cout<<passenger->get();
	}
	
};
int main(){
	Passenger p;
	Car c(p,33009);
	c.showname();
	c.showno();

	return 0;
}
