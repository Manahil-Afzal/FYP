

/*
Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has 
passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.
*/
#include<iostream>
using namespace std;
class Engine{
	private:
		string Egno;
	public:
	Engine(string name):Egno(name){
		
	}
	string get_Egno(){
		return Egno;
	}	
};
class Passenger{
	private:
		string pname;
	public:
	Passenger(string pn):pname(pn){
	}
	string get_pname(){
		return pname;
	}	
};
class Car{
	private:
	Engine engine;
	Passenger *pasen;
	public:
	Car(Engine e1,Passenger p1):engine(e1),pasen(&p1){
	}
	void display(){
		cout<<"Passenger Name: "<<pasen->get_pname()<<endl;
		cout<<"Engine Number: "<<engine.get_Egno()<<endl;
	}
};
int main(){
	Engine e1("suzuki_240");
	Passenger p1("M TOQEER ZIA");
	Car c1(e1,p1);
	c1.display();
}