#include <iostream>
using namespace std;

// Class Engine
class Engine {
private:
    string engine_number;
public:
    // Constructor
    Engine(string number) : engine_number(number) {}
    
    // Getter method
    string getEngineNumber() {
        return engine_number;
    }
};

// Class Passenger
class Passenger {
private:
    string passenger_name;
public:
    // Constructor
    Passenger(string name) : passenger_name(name) {}
    
    // Getter method
    string getPassengerName() {
        return passenger_name;
    }
};

// Class Car
class Car {
private:
    Engine engine;
    Passenger passenger;
public:
    // Constructor
    Car(Engine eng, Passenger pas) : engine(eng), passenger(pas) {}
    
    // Display method
    void displayInfo() {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create objects of Engine and Passenger
    Engine carEngine("1234");
    Passenger carPassenger("Ali");
    
    // Create object of Car
    Car myCar(carEngine, carPassenger);
    
    // Display information
    myCar.displayInfo();
    
    return 0;
}


