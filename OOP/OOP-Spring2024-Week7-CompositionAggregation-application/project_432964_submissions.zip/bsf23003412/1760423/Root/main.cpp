// Main function of the C++ program.

#include<iostream>
#include<string>
using namespace std;
class engine{
private:
	string engNo;
	public:
	
	
		void set(string number){
			engNo=number;
		}
			string get(){
				return engNo;
			}
		
};
class passenger{
	private:
		string pass_name;
		public:
			passenger(string name){
			pass_name=name;
			}
			
			string getpass()  {
				return pass_name;
			}
};
class car{
	private:
	engine e1;
	passenger* p1;
	public:


	car(string engine_no,string pass_no){
		e1.set(engine_no);
		p1 = new passenger(pass_no);
	}
		void show(){
		cout<<e1.get()<<endl;
		cout<<p1->getpass();
	}
};
int main(){
car c1("23","ali");



	
	c1.show();


}