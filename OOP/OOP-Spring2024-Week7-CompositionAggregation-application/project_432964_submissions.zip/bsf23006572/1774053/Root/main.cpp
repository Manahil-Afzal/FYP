// Main function of the C++ program.

#include<iostream>
#include<string.h>
using namespace std;
class Car
{
    protected:
    int engine_number=334;
    public:
    int return_engine_number()
    {
        return engine_number;
    }
   

};
class Passenger:public Car
{
   private:
   string passenger_name ="Ali Raza";
   public:
   void display_data()
   {
    cout<<"The engine number = "<<return_engine_number()<<endl;
    cout<<"The passenger name = "<<passenger_name<<endl;
   }

};
int main()
{
    Passenger ps1;
    ps1.display_data();
    return 0;
}