// Main function of the C++ program.
#include<iostream>
#include <string>
class Engine {
private:
    std::string engine_number;

public:
    Engine(const std::string& number) : engine_number(number) {}
    std::string getEngineNumber() const {
        return engine_number;
    }
};
class Passenger {
private:
    std::string passenger_name;

public:
    Passenger(const std::string& name) : passenger_name(name) {}


    std::string getPassengerName() const {
        return passenger_name;
    }
};


class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    
    void displayInfo() const {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }
};

int main() {
    
    Engine carEngine("12345");

    
    Passenger carPassenger("John Doe");

    
    Car myCar(carEngine, carPassenger);

    
    myCar.displayInfo();

    return 0;
}