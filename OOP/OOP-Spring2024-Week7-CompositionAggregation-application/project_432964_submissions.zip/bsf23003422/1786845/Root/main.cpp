/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include <iostream>
#include <string>

// Define the Engine class
class Engine {
public:
    Engine(int engineNumber) : engineNumber_(engineNumber) {}
    int getEngineNumber() const { return engineNumber_; }

private:
    int engineNumber_;
};

// Define the Passenger class
class Passenger {
public:
    Passenger(const std::string& passengerName) : passengerName_(passengerName) {}
    std::string getPassengerName() const { return passengerName_; }

private:
    std::string passengerName_;
};

// Define the Car class with aggregation relationship to Engine and Passenger
class Car {
public:
    Car(int engineNumber, const std::string& passengerName)
        : engine_(engineNumber), passenger_(passengerName) {}

    void displayInfo() const {
        std::cout << "Engine Number: " << engine_.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger_.getPassengerName() << std::endl;
    }

private:
    Engine engine_;
    Passenger passenger_;
};

int main() {
    // Create an object of class Car
    Car myCar(12345, "Alice");

    // Display engine number and passenger name
    myCar.displayInfo();

    return 0;
}


