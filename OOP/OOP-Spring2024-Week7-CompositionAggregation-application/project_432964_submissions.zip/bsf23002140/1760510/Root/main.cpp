// Main function of the C++ program.

#include <iostream>
#include <string>

using namespace std;

class Engine {
private:
    string engine_number;

public:
    Engine(const string &number) : engine_number(number) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string &name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    Car(const Engine &e, const Passenger &p) : engine(e), passenger(p) {}

    void displayInfo() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine carEngine("12345");
    Passenger carPassenger("Talha Khan");
    Car myCar(carEngine, carPassenger);

    myCar.displayInfo();

    return 0;
}
