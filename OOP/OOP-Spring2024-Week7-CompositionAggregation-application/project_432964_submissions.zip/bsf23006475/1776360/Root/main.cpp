// Main function of the C++ program.

#include <iostream>
using namespace std;
class Car{
	private:
		int eng_num;
		string p_name;
		public:
		void set_engine_num(int i){
				eng_num=i;
			}
		int get_engine_num(){
			return eng_num;
		}
		void set_p_name(string n)
		{
			p_name=n;
		}
		 string get_p_name(){
			return p_name;
		}
		};
class Engine{
	private:
		Car *engine;
		public:
			Engine(Car engine2){
				engine=&engine2;
				engine->set_engine_num(123456789);
			}
			void show(){
				cout<<"ENGINE NUMBER:"<<engine->get_engine_num()<<endl;
			}
};
class Passenger{
	private:
	 Car *p_name;
	 public:
	 	Passenger(Car Pnum1){
	 		p_name=&Pnum1;
	 		p_name->set_p_name("Bilal");
		 }
	 	void show1(){
	 		cout<<"PASSENGER NAME:"<<p_name->get_p_name()<<endl;
		 }
};
int main(){
	Car engine1;
	Engine Eng(engine1);
	Eng.show();
	Car pass1;
	Passenger Passenger(pass1);
	Passenger.show1();
}
