// Main function of the C++ program.

#include<iostream>
using namespace std;
class Engine{
	private:
		string engine_number;
	public:
		Engine (string number){
			engine_number = number;
		}
		string get_eng_num() {
//			get_eng_num = number;
			return engine_number;
		}
};
class Passenger{
	private:
		string passenger_name;
	public:
		Passenger (string name){
			passenger_name = name;
		}
		string get_passenger_name() {
//			get_passenger_name = name;
			return passenger_name;
		}
};
class Car {
	private:
		Engine engineNumber;
		Passenger passengerName;
	public:
		Car(Engine engine, Passenger passenger)
        : engineNumber(engine), passengerName(passenger) {}	
		void display_result(){
			cout<<engineNumber.get_eng_num()<<endl;
			cout<<passengerName.get_passenger_name();
		}
	
};
int main() {
	Engine engine_number ("Kamran12");
	Passenger passenger_name("Kamran34");
	Car car1(engine_number, passenger_name);
	car1.display_result();
	return 0;
}
