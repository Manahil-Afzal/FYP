// Main function of the C++ program.

#include<iostream>
using namespace std;
class Passenger{
    private:
       string passengerName;
    public:
       void setPassenger(){
           cout<<"Enter Passenger Name: ";
           getline(cin,passengerName);
       }
       string getPassenger(){
           return passengerName;
       }
};
class Engine{
    private:
        int engineNum;
    public:
        Engine(int eNum){
            engineNum=eNum;
        }
        int getEngineNum(){
            return engineNum;
        }
        void setEngineNum(){
            cout<<"Enter Engine Number :";
            cin>>engineNum;
            cin.ignore();
        }
};
class Car{
    private:
        Engine engine;
        Passenger *passenger;
    public: 
        Car(int engineNo): engine(engineNo){}
        void setData(Passenger pass){
            passenger=&pass;
            passenger->setPassenger();
        }
        void getData(){
            cout<<"Engine Number is : "<<engine.getEngineNum()<<endl;
            cout<<"Passenger Name is : "<<passenger->getPassenger()<<endl;
        }
};
int main(){
	Car C(12345);
    Passenger pass;
    C.setData(pass);
    C.getData();
}


