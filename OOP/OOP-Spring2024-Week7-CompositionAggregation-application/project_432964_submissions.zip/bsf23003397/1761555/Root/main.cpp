#include <iostream>
#include <string>

using namespace std;

class Engine {
private:
    string engine_number;
public:

    Engine(string number) : engine_number(number) {}

    
    string getEngineNumber() {
        return engine_number;
    }
};


class Passenger {
private:
    string passenger_name;
public:
    Passenger(string name) : passenger_name(name) {}


    string getPassengerName() {
        return passenger_name;
    }
};

class Car {
private:
    Engine car_engine;
    Passenger car_passenger;
public:
    
    Car(Engine engine, Passenger passenger) : car_engine(engine), car_passenger(passenger) {}

    void displayDetails() {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine car_engine("E1234");

    // Create a Passenger object with passenger name "John"
    Passenger car_passenger("John");

    // Create a Car object with the Engine and Passenger objects
    Car my_car(car_engine, car_passenger);

    // Display car details
    my_car.displayDetails();

    return 0;
}