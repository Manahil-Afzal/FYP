/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;
class Passenger{
    private:
       string passengerName;
    public:
       void setPassenger(){
           cout<<"Enter Passenger Name: ";
           getline(cin,passengerName);
       }
       string getPassenger(){
           return passengerName;
       }
};
class Engine{
    private:
        int engineNum;
    public:
        Engine(int eNum){
            engineNum=eNum;
        }
        int getEngineNum(){
            return engineNum;
        }
        void setEngineNum(){
            cout<<"Enter Engine Number :";
            cin>>engineNum;
            cin.ignore();
        }
};
class Car{
    private:
        Engine engine;
        Passenger *passenger;
    public: 
        Car(int engineNo): engine(engineNo){}
        void setData(Passenger pass){
            passenger=&pass;
            passenger->setPassenger();
        }
        void getData(){
            cout<<"Engine Number is : "<<engine.getEngineNum()<<endl;
            cout<<"Passenger Name is : "<<passenger->getPassenger()<<endl;
        }
};
int main(){
	Car C(12345);
    Passenger pass;
    C.setData(pass);
    // system("cls");
    C.getData();
}