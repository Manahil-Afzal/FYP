#include <iostream>
#include <string>
using namespace std;

// Class definition for Engine
class Engine {
private:
    string engine_number;

public:
    // Constructor to initialize engine_number
    Engine(string number) : engine_number(number) {}

    // Getter method to retrieve engine_number
    string getEngineNumber() {
        return engine_number;
    }
};

// Class definition for Passenger
class Passenger {
private:
    string passenger_name;

public:
    // Constructor to initialize passenger_name
    Passenger(string name) : passenger_name(name) {}

    // Getter method to retrieve passenger_name
    string getPassengerName() {
        return passenger_name;
    }
};

// Class definition for Car
class Car {
private:
    Engine car_engine; // Object of type Engine
    Passenger car_passenger; // Object of type Passenger

public:
    // Constructor to initialize Car with Engine and Passenger objects
    Car(Engine engine, Passenger passenger) : car_engine(engine), car_passenger(passenger) {}

    // Method to display engine number and passenger name
    void displayDetails() {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an Engine object
    Engine car_engine("12345");

// Create a Passenger object
    Passenger car_passenger("John Doe");

    // Create a Car object with the Engine and Passenger objects
    Car my_car(car_engine, car_passenger);

    // Display details of the car
    my_car.displayDetails();

    return 0;
}

