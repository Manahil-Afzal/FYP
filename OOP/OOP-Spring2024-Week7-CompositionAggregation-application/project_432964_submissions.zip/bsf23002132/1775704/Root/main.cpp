#include <iostream>


using namespace std;


class Engine {
private:
    string engine_number;
public:
    Engine(string number) : engine_number(number) {}
    string getEngineNumber() {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;
public:
    Passenger(string name) : passenger_name(name) {}
    string getPassengerName() {
        return passenger_name;
    }
};


class Car {
private:
    Engine engine;
    Passenger passenger;
public:
    Car(Engine eng, Passenger pass) : engine(eng), passenger(pass) {}
    void displayInfo() {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    
    Engine carEngine("12345");

    
    Passenger carPassenger("John Doe");

    
    Car myCar(carEngine, carPassenger);

    
    myCar.displayInfo();

    return 0;
}
