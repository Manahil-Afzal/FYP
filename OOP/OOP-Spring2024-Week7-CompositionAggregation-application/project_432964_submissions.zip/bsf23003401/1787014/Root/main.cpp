// Main function of the C++ program.

#include <iostream>
#include <string>

using namespace std;

class Engine {
private:
    string engine_number;

public:
    Engine(const string& number) : engine_number(number) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine car_engine;
    Passenger car_passenger;

public:
    Car(const Engine& engine, const Passenger& passenger) : car_engine(engine), car_passenger(passenger) {}

    void displayDetails() const {
        cout << "Engine Number: " << car_engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    // Create an Engine object
    Engine engine("ABC123");

    // Create a Passenger object
    Passenger passenger("John Doe");

    // Create a Car object with the Engine and Passenger objects
    Car car(engine, passenger);

    // Display car details
    car.displayDetails();

    return 0;
}