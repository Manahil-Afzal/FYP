#include <iostream>
#include <string>

using namespace std;

class Motor {
private:
    string motor_number;

public:
    Motor(string number) : motor_number(number) {}

    string getMotorNumber() const {
        return motor_number;
    }
};

class Traveler {
private:
    string traveler_name;

public:
    Traveler(string name) : traveler_name(name) {}

    string getTravelerName() const {
        return traveler_name;
    }
};

class Vehicle {
private:
    Motor vehicle_motor;
    Traveler vehicle_traveler;

public:
    Vehicle(Motor motor, Traveler traveler) : vehicle_motor(motor), vehicle_traveler(traveler) {}

    void displayInfo() const {
        cout << "Motor Number: " << vehicle_motor.getMotorNumber() << endl;
        cout << "Traveler Name: " << vehicle_traveler.getTravelerName() << endl;
    }
};

int main() {
    Motor motor("XYZ789");
    Traveler traveler("MUBASHAR");
    Vehicle vehicle(motor, traveler);
    vehicle.displayInfo();

    return 0;
}
