/*Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
The Engine has engine_number as a data member which is set in the constructor of class Engine.
The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
Create an object of class Car that displays the engine number and a passenger name on screen.*/
#include<iostream>
using namespace std;

class Passenger {
private:
    string passenger_name;

public:
    void set_passenger_name(string name) {
        passenger_name = name;
    }

    string get_passenger_name() {
        return passenger_name;
    }
};

class Engine {
private:
    string engine_number;

public:
    void set_engine_number(string number) {
        engine_number = number;
    }

    string get_engine_number() {
        return engine_number;
    }
};

class Car {
private:
    Engine engine;
    Passenger *passenger;

public:
    Car(Passenger passenger1) {
        passenger = &passenger1;
        passenger->set_passenger_name("Anas");
        engine.set_engine_number("a32b78g");
    }

    void showdata() {
        cout << "Engine number: " << engine.get_engine_number() << endl;
        cout << "Passenger name: " << passenger->get_passenger_name() << endl;
    }
};

int main() {
    Passenger passenger1;
    passenger1.set_passenger_name("Anas"); // Setting the name to John Doe

    Car obj2(passenger1); // Creating Car object with passenger1

    obj2.showdata(); // Displaying engine number and passenger name

    return 0;
}
