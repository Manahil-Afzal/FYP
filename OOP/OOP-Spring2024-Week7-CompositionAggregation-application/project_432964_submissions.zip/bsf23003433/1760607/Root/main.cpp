#include<iostream>
#include<string>
using namespace std;
class engine{
	string en_no;
	public:
		engine(string num)
		{
			en_no=num;
		}
		void data(){
			cout<<"engine num is:"<<en_no<<endl;
		}
};
class pasenger{
	string name;
	public:
		pasenger(){
		}
		void info(){
			cout<<"the name of pasenger is:";
			cin>>name;
		}
};
class car{
	engine Engine;
	pasenger *Pasenger;
	public:
		car():Engine("engine1234"){
			
		}
		void display(){
			Engine.data();
			Pasenger->info();
		}
};
int main(){
	car c1;
	c1.display();
	pasenger p2;
	p2.info();
}