#include <iostream>
using namespace std;

// Define the Engine class
class Engine {
private:
    string engine_number;

public:
    Engine(const string& number) : engine_number(number) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

// Define the Passenger class
class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

// Define the Car class
class Car {
private:
    Engine engine; // Aggregation with Engine class
    Passenger passenger; // Aggregation with Passenger class

public:
    
    Car(const string& engine_number, const string& passenger_name)
        : engine(engine_number), passenger(passenger_name) {}

    void displayInfo() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    
    Car car("34527dars", "Ali");

    car.displayInfo();

    return 0;
}
