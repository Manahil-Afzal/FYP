#include <iostream>
#include <string>

using namespace std;

class Engine {
private:
    string engine_number;

public:
    Engine(const string& num) : engine_number(num) {}

    string getEngineNumber() const {
        return engine_number;
    }
};

class Passenger {
private:
    string passenger_name;

public:
    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};

class Car {
private:
    Engine engine; 
    Passenger passenger;

public:
    Car(const Engine& eng, const Passenger& pass) : engine(eng), passenger(pass) {}

    void displayInfo() const {
        cout << "Engine Number: " << engine.getEngineNumber() << endl;
        cout << "Passenger Name: " << passenger.getPassengerName() << endl;
    }
};

int main() {
    Engine engine("754565");
    Passenger passenger("Adeel");
    Car car(engine, passenger);
    car.displayInfo();

    return 0;
}
