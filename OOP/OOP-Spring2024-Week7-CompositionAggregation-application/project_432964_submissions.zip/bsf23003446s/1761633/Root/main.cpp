//Write a C++ program that creates a class named Car. It has an object of user defined type called Engine.
//The Engine has engine_number as a data member which is set in the constructor of class Engine.
//The class Car has an aggregation relationship with another user defined class called Passenger which has passenger_name as its data member.
//Create an object of class Car that displays the engine number and a passenger name on screen.
#include <iostream>
#include <string>

// Define the Engine class
class Engine {
private:
    int engineNumber;

public:
    Engine(int engineNum) : engineNumber(engineNum) {}

    int getEngineNumber() const {
        return engineNumber;
    }
};

// Define the Passenger class
class Passenger {
private:
    std::string passengerName;

public:
    Passenger(const std::string& name) : passengerName(name) {}

    std::string getPassengerName() const {
        return passengerName;
    }
};

// Define the Car class with aggregation relationship to Engine and Passenger
class Car {
private:
    Engine engine;
    Passenger passenger;

public:
    Car(int engineNum, const std::string& passengerName)
        : engine(engineNum), passenger(passengerName) {}

    void displayInfo() const {
        std::cout << "Engine Number: " << engine.getEngineNumber() << std::endl;
        std::cout << "Passenger Name: " << passenger.getPassengerName() << std::endl;
    }
};

int main() {
    // Create an object of class Car
    Car myCar(12345, "Alice");

    // Display engine number and passenger name
    myCar.displayInfo();

    return 0;
}
