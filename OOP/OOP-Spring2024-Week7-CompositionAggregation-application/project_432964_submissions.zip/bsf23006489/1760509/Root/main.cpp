// Main function of the C++ program.

 #include<iostream>
 using namespace std;
 class Engine{
 	string eng_num;
 	public:
 	Engine(string num){
 		eng_num=num;
	 }
	 string getdata(){
	 	return eng_num;
	 }
 	
 	
 };

 
 class Pass{
 	string name;
 	public:
 		Pass(string name1){
 			name=name1;
		 }
		 string getdata(){
		 	return name;
		 }
 
 };
 
  class car{
 	Engine *engine;
 	Pass *pass;
 	public:
 	car(Engine eng , Pass pas){
 		engine=&eng;
 		pass=&pas;
 		
 		cout<<"engine no : "<<engine->getdata();
 		cout<<endl;
 		cout<<"passenger name : "<<pass->getdata();
 	
	 }
 };
 main(){
 	Engine engine("222");
 
 	Pass pass("arooba");
 
 	car c1(engine,pass);
 
 	
 }