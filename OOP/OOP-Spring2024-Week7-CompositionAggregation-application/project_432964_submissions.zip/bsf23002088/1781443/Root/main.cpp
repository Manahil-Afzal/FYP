// Main function of the C++ program.

#include <iostream>
using namespace std;
class Engine{
int en;
public:
Engine (){
}
Engine (int i){
en=i;
}
int showEN(){
return en;
}
};
class Passenger{
string pass_name;
public:
void setPassname(string pname){
pass_name=pname;
}
string showPassName(){
return pass_name;
}
};
class Car{
Passenger *p;
Engine e;
public:
Car(Passenger P, Engine E){
p=&P;
e=E;
}
void showCar(){
cout << "ZSB" << p->showPassName() << endl;
cout << e.showEN();
}
};
int main ()
{
Passenger pa;
Engine eng=459;
Car c(pa,eng);
c.showCar();
return 0;
}