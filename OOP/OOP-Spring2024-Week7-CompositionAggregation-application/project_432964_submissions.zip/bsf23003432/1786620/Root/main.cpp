// Main function of the C++ program.

#include <iostream>
#include <string>

using namespace std;

class Engine {
public:
    Engine(int number) : engine_number(number) {}
    int engine_number;
};

class Passenger {
public:
    Passenger(string name) : passenger_name(name) {}
    string passenger_name;
};

class Car {
public:
    Car(int engine_num, string passenger_name) : engine(engine_num), passenger(passenger_name) {}

    void displayInfo() {
        cout << "Engine Number: " << engine.engine_number << endl;
        cout << "Passenger Name: " << passenger.passenger_name << endl;
    }

private:
    Engine engine;
    Passenger passenger;
};

int main() {
    Car car(12345, "Liaqat");
    car.displayInfo();
    return 0;
}

