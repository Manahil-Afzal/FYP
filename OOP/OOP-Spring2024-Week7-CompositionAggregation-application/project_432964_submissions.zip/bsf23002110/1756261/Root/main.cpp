#include <iostream>
using namespace std;
class Engine{
    private:
        string engine_num;
    public:
         Engine(string num){
            engine_num=num;
        }
        string getEngineNum(){
            return engine_num;
        }
};
class Passenger
{
private:
    string passenger_name;
public:
    Passenger(string name){
        passenger_name=name;
    };
    string getPassengerName(){
        return passenger_name;
    };

};
class Car
{
private:
  Engine* engine;
  Passenger* passenger;  
public:
    Car(Engine engine1, Passenger passenger1){
        engine=&engine1;
        passenger=&passenger1;
    }
    void display(){
        cout<<"Engine Number: "<<engine->getEngineNum()<<endl;
        cout<<"Passenger Name: "<<passenger->getPassengerName();
    }
};
int main(){
    Engine eng("1234");
    Passenger pass("Ansar");
    Car myCar(eng,pass);
    myCar.display();
    return 0;
}