#include <iostream>
#include <string>
using namespace std;
class Engine {
private:
    string engine_number;

public:
    Engine(const string& number) : engine_number(number) {}

      string getEngineNumber() const {
        return engine_number;
    }
};


class Passenger {
private:
    string passenger_name;

public:

    Passenger(const string& name) : passenger_name(name) {}

    string getPassengerName() const {
        return passenger_name;
    }
};


class Car {
private:
    Engine car_engine; 
    Passenger car_passenger;

public:
   
    Car(const string& engine_number, const string& passenger_name)
        : car_engine(engine_number), car_passenger(passenger_name) {}

    void display() const {
        cout << "Engine no: " << car_engine.getEngineNumber() << endl;
      cout << "Passenger Name: " << car_passenger.getPassengerName() << endl;
    }
};

int main() {
    Car car("ABHDSH23243", "ALI");
    car.display();

    return 0;
}
