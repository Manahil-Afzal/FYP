
/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class student{
	string name;
	int id;
	int marks;
	float cgpa;
	
	public:
		int static num;
		void getdata(){
			cout<<"Enter name"<<endl;
			cin>>name;
			cout<<"Enter id"<<endl;
			cin>>id;
			cout<<"Enter marks"<<endl;
			cin>>marks;
			cout<<"Enter Cgpa"<<endl;
			cin>>cgpa;
			num++;
		}
		void display(student arr[],int size){
			int high=0;
			for(int i=0;i<size;i++){
				if(arr[i].marks>high){
					high=arr[i].marks;
				}
				
			}
				for(int i=0;i<size;i++){
				if(arr[i].marks==high){
					cout<<"The name of student is"<<arr[i].name<<endl;
					cout<<"The ID of student is"<<arr[i].id<<endl;
					cout<<"The marks of student is"<<arr[i].marks<<endl;
					cout<<"The CGPA of students is"<<arr[i].cgpa;
				}
				
			}
			
		}	
};
int student::num=1;
int main()
{
	student s1[3];
	student s2;
	for(int i=0;i<3;i++){
		cout<<"The seriel no std is"<<student::num<<endl;
		s1[i].getdata();
	}
    s2.display(s1,3);



 return 0;
}