/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string.h>
using namespace std;
class Student
{
    private:
    string stu_name;
    int stu_id;
    int stu_marks;
    float stu_cgpa;
    public:
    void getdata()
    {
        cout<<"Enter the name of the student = ";
        cin>>stu_name;
        cout<<"Enter the id of the student = ";
        cin>>stu_id;
        cout<<"Enter the marks of the student = ";
        cin>>stu_marks;
        cout<<"Enter the cgpa of the student = ";
        cin>>stu_cgpa;
    }
    void display_data()
    {
     cout<<"The name of the student = "<<stu_name<<endl;
     cout<<"The id of the student = "<<stu_id<<endl;
     cout<<"The marks of the student = "<<stu_marks<<endl;
     cout<<"The cgpa of the studnet = "<<stu_cgpa<<endl;
        
        
    }
};
int main()
{
    Student st[8];
    int i;
    for ( i = 0; i <=1; i++)
    {
        cout<<"Enter the data of the student = "<<i+1<<endl;
        st[i].getdata();
    }
    for ( i = 0; i <=8; i++)
    {
        cout<<"Student "<<i+1<<" Data "<<endl;
        st[i].display_data();
    }
    
    
    return 0;
}