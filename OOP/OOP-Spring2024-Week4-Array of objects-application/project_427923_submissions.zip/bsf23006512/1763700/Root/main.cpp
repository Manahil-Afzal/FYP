/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    static int count; 
    int serialNumber; 
    string name;
    int id;
    int marks;
    float cgpa;
public:
    Student() {
        count++;
        serialNumber = count;
    }

    void setData() {
        cout << "Enter details for Student " << serialNumber << ":" << endl;
        cout << "Name: ";
        getline(cin >> ws, name);
        cout << "ID: ";
        cin >> id;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;
    }

    void getData() {
        cout << "Details of Student " << serialNumber << ":" << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    for (int i = 0; i < numStudents; ++i) {
        students[i].setData();
    }
    int highestMarks = 0;
    int hMI = 0;
    for (int i = 0; i < numStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            hMI = i;
        }
    }
    cout << "Details of the student with the highest marks:" << endl;
    students[hMI].getData();

    return 0;
}