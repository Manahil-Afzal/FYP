/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student{
	public:
		char name[25];
		string id;
		int marks;
		float CGPA;
		static int serialno;
		public:
			void getdata(){
				cout<<"\n\tEnter name of student: ";
				cin>>name;
				cout<<"\n\tEnter id of student: ";
				cin>>id;
				cout<<"\n\tEnter marks of student out of 600: ";
				cin>>marks;
				cout<<"\n\tEnter CGPA of student: ";
                cin>>CGPA;
				serialno++;
			}
			void putdata()
			{
				cout<<"\n"<<name<<"\t"<<id<<"\t"<<marks<<"\t"<<CGPA<<endl;
				cout<<"\nSerial number: "<<serialno;
			}
		
};
int Student::serialno=0;

int main()
{
	Student std[8];
	for(int i=0;i<8;i++)
	{
	cout<<"Enter details for student "<<i+1<<endl;
	std[i].getdata();	
	}
	int highestmarks=0;
	for(int i=0;i<8;i++)
	{
		if(std[i].marks>std[highestmarks].marks){
			highestmarks=i;
		}
	}
	cout<<"\nStudent with highest marks: ";
	std[highestmarks].putdata();
	
}
