/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    static int count; // Static variable to keep track of the number of students
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

public:
    // Constructor
    Student(string n, int i, float m, float c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        count++; // Increment count each time a student object is created
        serialNumber = count; // Assign serial number based on the count
    }

    // Function to display student details
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    // Function to get marks
    float getMarks() {
        return marks;
    }
};

// Initializing static variable count
int Student::count = 0;

int main() {
    // Array of objects of 8 students
    Student students[8] = {
        Student("Fatima", 101, 85.5, 3.8),
        Student("Hina", 102, 78.2, 3.5),
        Student("Iram", 103, 90.0, 3.9),
        Student("Shazia", 104, 82.7, 3.7),
        Student("Faisal", 105, 88.9, 3.8),
        Student("Hammad", 106, 75.6, 3.3),
        Student("Abdullah", 107, 91.5, 4.0),
        Student("Mahad", 108, 79.8, 3.6)
    };

    // Finding the student with the highest marks
    int highestMarksIndex = 0;
    float highestMarks = students[0].getMarks();

    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Displaying details of the student with the highest marks
    cout << "Details of student with the highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}