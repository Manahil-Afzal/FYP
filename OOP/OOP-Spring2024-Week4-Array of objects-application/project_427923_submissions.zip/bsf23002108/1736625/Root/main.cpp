#include <iostream>
#include <string>

class Student {
private:
    std::string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber;

public:
    // Constructor
    Student(std::string _name, int _id, int _marks, float _cgpa, int _serialNumber)
        : name(_name), id(_id), marks(_marks), cgpa(_cgpa), serialNumber(_serialNumber) {}

    // Display student details
    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << std::endl;
    }

    // Getter for marks
    int getMarks() const {
        return marks;
    }
};

int main() {
    // Array of 8 Student objects
    Student students[8] = {
        {"Alice", 101, 85, 3.7, 1},
        {"Bob", 102, 75, 3.5, 2},
        {"Charlie", 103, 90, 3.9, 3},
        {"David", 104, 80, 3.8, 4},
        {"Emma", 105, 95, 4.0, 5},
        {"Frank", 106, 70, 3.3, 6},
        {"Grace", 107, 88, 3.6, 7},
        {"Henry", 108, 82, 3.7, 8}
    };

    int highestMarks = 0;
    int highestMarksIndex = 0;

    // Find student with highest marks
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Display details of student with highest marks
    std::cout << "Details of student with highest marks:" << std::endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/