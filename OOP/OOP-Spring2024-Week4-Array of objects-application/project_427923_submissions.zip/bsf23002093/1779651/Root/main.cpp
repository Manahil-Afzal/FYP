
#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

public:
    // Constructor to initialize the object with given details
    Student(string n, int i, float m, float c, int sn) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        serialNumber = sn;
    }

    // Function to display student details
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    // Function to get marks of the student
    float getMarks() {
        return marks;
    }
};

int main() {
    // Array of objects of 8 students
    Student students[8] = {
        Student("John", 101, 85.5, 3.7, 1),
        Student("Emma", 102, 92.0, 3.9, 2),
        Student("Michael", 103, 88.7, 3.5, 3),
        Student("Sophia", 104, 91.2, 3.8, 4),
        Student("William", 105, 87.3, 3.6, 5),
        Student("Olivia", 106, 89.8, 3.7, 6),
        Student("James", 107, 90.5, 3.9, 7),
        Student("Charlotte", 108, 86.9, 3.8, 8)
    };

    // Find the student with highest marks
    float highestMarks = students[0].getMarks();
    int highestMarksIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Display details of the student with highest marks
    cout << "Details of the student with highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
