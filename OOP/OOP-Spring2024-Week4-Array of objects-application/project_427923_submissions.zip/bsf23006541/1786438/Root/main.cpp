/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int count; // Static variable to keep track of the number of students created
    int serialNumber; // Serial number for each student
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student(string n, int i, int m, float c) {
        serialNumber = ++count;
        name = n;
        id = i;
        marks = m;
        cgpa = c;
    }

    void display() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() {
        return marks;
    }
};

int Student::count = 0; // Initializing static variable outside the class

int main() {
    Student students[8] = {
        {"John", 101, 85, 3.7},
        {"Alice", 102, 90, 3.9},
        {"Bob", 103, 75, 3.5},
        {"Emily", 104, 95, 4.0},
        {"Michael", 105, 80, 3.8},
        {"Sophia", 106, 88, 3.6},
        {"David", 107, 82, 3.4},
        {"Emma", 108, 92, 3.95}
    };

    int maxMarks = 0;
    int maxIndex = 0;

    // Finding the student with the highest marks
    for (int i = 0; i < 8; i++) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    cout << "Details of the student with the highest marks:" << endl;
    students[maxIndex].display();

    return 0;
}
