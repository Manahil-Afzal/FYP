#include <iostream>
#include <string>
using namespace std;

class student {
private:
    string name;
    string id;
    int marks;
    float cgpa;
    static int count;
    int serialnumber;

public:
    student() {
        count++;
        serialnumber = count;
    }

    static int getcount() {
        return count;
    }

    void getdetails() {
        cout << "Enter the name of student: ";
        cin >> name;
        cout << "Enter the ID of student: ";
        cin >> id;
        cout << "Enter the marks of student: ";
        cin >> marks;
        cout << "Enter the CGPA: ";
        cin >> cgpa;
    }

    void display() {
        cout << "Name of student: " << name << endl;
        cout << "ID of student: " << id << endl;
        cout << "Marks of student: " << marks << endl;
        cout << "CGPA of student: " << cgpa << endl;
    }

    static void calculate(student arr[], int size) {
        int highest_marks = 0;
        int index = 0;
        for (int i = 0; i < size; i++) {
            if (arr[i].marks > highest_marks) {
                highest_marks = arr[i].marks;
                index = i;
            }
        }
        cout << "Displaying details of student with highest marks:" << endl;
        arr[index].display();
    }
};

int student::count = 0;

int main() {
    const int num = 8;
    student students[num];
    for (int i = 0; i < num; i++) {
        cout << "Enter details of student " << i + 1 << ":" << endl;
        students[i].getdetails();
    }
    student::calculate(students, num);
    return 0;
}
