/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string>
using namespace std;
class student{
	string name;
	int id;
	int marks;
	float cgpa;
	static int count;
	public:
		void get(student a[],int b){
			for(int i=0; i<b; i++){
				cout<<"enter a name of student "<<i+1<<":"<<endl;
				cin>>a[i].name;
				cout<<"enter a id of student "<<i+1<<":"<<endl;
				cin>>a[i].id;
				cout<<"enter a marks of student "<<i+1<<":"<<endl;
				cin>>a[i].marks;
				cout<<"enter a cgpa of student "<<i+1<<":"<<endl;
				cin>>a[i].cgpa;
				count++;
			}
		}
		void cal(student a[],int b){
			int high=0;
			for(int i=0; i<b; i++){
				if(a[i].marks>a[high].marks){
					high=i;
			}
			}
					cout<<"the name of student "<<a[high].name<<endl;
					cout<<"the id of student "<<a[high].id<<endl;
					cout<<"the cgpa of student "<<a[high].cgpa<<endl;
					cout<<"the  marks of student "<<a[high].marks<<endl;
				}
			
			
			
		
		static int getcount(){
			return count;
		}
};
int student ::count=0;
int main(){
	student a[2];
	a[0].get(a,2);
	a[0].cal(a,2);
	cout<<"the number of students :"<<student::getcount();
}