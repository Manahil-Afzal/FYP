/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA.
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Student{
    private:
    	int serial_number;
        string name;
        int id;
        int marks;
        float cgpa;
        static int count;
    public:
    	Student(){
    		count = count + 1;
    		serial_number = count;
		}
        void input(){
        	cout<<" Enter the detail of student no. " << serial_number << endl << endl;
            cout << " Enter the name of student: ";
            cin >> name;
            cout << " Enter the id of student: ";
            cin >> id;
            cout << " Enter the marks of student: ";
            cin >> marks;
            cout << " Enter the cgpa of student: ";
            cin >> cgpa;
            cout<< "______________________________________________________________________"<< endl <<endl;
        }
        void show(){
			cout << "Student no " << serial_number << " detail is as follow." << endl;
            cout << "The name of student is: " << name << endl;
            cout << "The Id of student is: " << id << endl;
            cout << "The marks of student is: " << marks << endl;
            cout << "The cgpa of student is: " << cgpa << endl;
			
        }
        int getMarks(){
            return marks;
        }
};

int Student::count = 0;
int main(){
    Student s[8];
    for(int i = 0; i < 8; i++){
        s[i].input();
    }
int max_index = 0;
    for (int i = 1; i < 8; i++) {
        if (s[i].getMarks() > s[max_index].getMarks()) {
            max_index = i;
        }
    }

    cout << endl << "Student With Highest Marks" << endl;
    cout << "____________________________________________________________________" << endl;
    s[max_index].show();
}