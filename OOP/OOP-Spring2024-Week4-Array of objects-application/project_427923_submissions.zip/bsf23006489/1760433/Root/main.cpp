/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
 #include<iostream> 
 using namespace std ;
 class student{
 		string name;
          int id;
	      float cgpa;
 		 	int marks;
 		 	int serial;
 		 	static int count;
 	
 	public:
 		int getmarks(){
 			return marks;
		 }
		 student(){
		 	serial=++count;
		 }

 		void setdata(){
 			cout<<"enetr the name of student :"<<endl;
 			cin>>name;
 			cout<<"enetr the ID of student :"<<endl;
 			cin>>id;
 			cout<<"enetr the marks of student :"<<endl;
 			cin>>marks;
 			cout<<"enetr the cgpa of student :"<<endl;
 			cin>>cgpa;
 			
		 }
		 void getdata(){
		 	cout<<"the name is :"<<name<<endl;
		 		cout<<"the ID is :"<<id<<endl;
		 			cout<<"the marks is :"<<marks<<endl;
		 				cout<<"the cgpa is :"<<cgpa<<endl;
		 				cout<<"serial no :"<<serial<<endl;
		 }
		
 };

 int student::count=0;
 main(){
 	student s1[3];
 	for(int i=0;i<3;i++){
 		cout<<"enter the detail of  "<<i+1<<" "<<"student"<<endl;
 	
 		s1[i].setdata();
	 }
	 	for(int i=0;i<3;i++){
 		s1[i].getdata();
 		
 		
	 }
	 
    int maxMarks = s1[0].getmarks();
    int index = 0;
    for (int i = 1; i < 3; ++i) {
        if (s1[i].getmarks() > maxMarks) {
            maxMarks = s1[i].getmarks();
            index = i;
        }
    }


    cout << "Detail of student with highest marks:"<<endl;
    s1[index].getdata();

	 
 }