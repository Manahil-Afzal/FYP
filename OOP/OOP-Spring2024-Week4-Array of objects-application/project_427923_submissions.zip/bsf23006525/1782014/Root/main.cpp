/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
private:
    static int count;
    int serial_no;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student() {
        serial_no = ++count;
    }
    void input() {
        cout << "Enter name : ";
        cin >> name;
        cout << "Enter ID   : ";
        cin >> id;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter CGPA : ";
        cin >> cgpa;
    }
    void display() const {
        cout << "Serial Number: " << serial_no << endl;
        cout << "Name         : " << name << endl;
        cout << "ID           : " << id << endl;
        cout << "Marks        : " << marks << endl;
        cout << "CGPA         : " << cgpa << endl;
    }
    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    Student students[8];
    for (int i = 0; i < 8; ++i) {
        cout << "Enter details for student " << i + 1 << ":" << endl;
        students[i].input();
    }
    int maxMarks = students[0].getMarks();
    int maxIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }
    cout << "Details of the student with highest marks:" << endl;
    students[maxIndex].display();

    return 0;
}
