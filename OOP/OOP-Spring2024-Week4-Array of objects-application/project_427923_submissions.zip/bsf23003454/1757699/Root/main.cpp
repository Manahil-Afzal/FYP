/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
private:
    std::string name;
    int id;
    float marks;
    float cgpa;
    static int count;
    
public:
    Student(std::string n, int i, float m, float c) : name(n), id(i), marks(m), cgpa(c) {
        count++;
    }
    void displayDetails() {
        std::cout << "Serial Number: " << count << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << std::endl;
    }
    float getMarks() {
        return marks;
    }
    static int getCount() {
        return count;
    }
};

int Student::count = 0;

int main() {
    Student students[8] = {
        Student("John", 101, 85.5, 3.7),
        Student("Alice", 102, 90.0, 3.9),
        Student("Bob", 103, 92.5, 3.8),
        Student("Emma", 104, 88.0, 3.6),
        Student("Mike", 105, 91.0, 3.5),
        Student("Sarah", 106, 87.5, 3.9),
        Student("David", 107, 89.5, 3.4),
        Student("Lily", 108, 86.0, 3.8)
    };
    int highestMarksIndex = 0;
    float highestMarks = students[0].getMarks();
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }
    std::cout << "Student with highest marks:" << std::endl;
    students[highestMarksIndex].displayDetails();
    
    return 0;
}
