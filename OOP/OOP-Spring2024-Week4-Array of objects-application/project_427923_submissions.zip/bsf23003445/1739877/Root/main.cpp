#include<iostream>
#include<string>
using namespace std;
class stu{
	string name;
	int id;
	int marks;
	float cgpa;
	static int count;
	public:
		void get(stu a[],int b){
			for(int i=0; i<b; i++){
				cout<<"enter a name of student "<<i+1<<":"<<endl;
				cin>>a[i].name;
				cout<<"enter a id of student "<<i+1<<":"<<endl;
				cin>>a[i].id;
				cout<<"enter a marks of student "<<i+1<<":"<<endl;
				cin>>a[i].marks;
				cout<<"enter a cgpa of student "<<i+1<<":"<<endl;
				cin>>a[i].cgpa;
				count++;
			}
		}
		void cal(stu a[],int b){
			int high=0;
			for(int i=0; i<b; i++){
				if(a[i].marks>a[high].marks){
					high=i;
			}
			}
					cout<<"the name of student "<<a[high].name<<endl;
					cout<<"the id of student "<<a[high].id<<endl;
					cout<<"the cgpa of student "<<a[high].cgpa<<endl;
					cout<<"the  marks of student "<<a[high].marks<<endl;
				}
			
			
			
		
		static int getcount(){
			return count;
		}
};
int stu ::count=0;
int main(){
	stu a[2];
	a[0].get(a,2);
	a[0].cal(a,2);
	cout<<"the number of students :"<<stu::getcount();
}