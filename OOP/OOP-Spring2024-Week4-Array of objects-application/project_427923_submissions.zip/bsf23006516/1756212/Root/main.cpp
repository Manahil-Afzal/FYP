/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
/*Write a C++ program that creates a class
 to take and display details of student. 
 It takes input for student's name, id, marks, and CGPA.
  Create an array of objects of 8 students and display the details of 
  student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating 
the respective student object.*/
#include<iostream>
using namespace std;
class student{
	private:
		string name;
		string id;
		int marks;
		float gpa;
	public:
	student():name("Name/."),id("bsf"),marks(000),gpa(000){
		
	}
	void input(){
		
		cout<<"Enter Your Name: ";
		cin>>name;
	    cout<<"Enter Your Id: ";
		cin>>id;
		cout<<"Enter Your Marks: ";
		cin>>marks;
		cout<<"Enter Your CGPA: ";
		cin>>gpa;
	}
	void Display(){
		cout<<"Name: "<<name<<endl;
		cout<<"Id:  "<<id<<endl;
		cout<<"Marks: "<<marks<<endl;
		cout<<"Enter Your CGPA: "<<gpa<<endl;
	}
	static void check(student arr[],int size){
	    int maxindex=0;
		for(int i=0;i<size;i++){
			if(arr[i].marks>arr[maxindex].marks){
				maxindex=i;
			}
		}
		arr[maxindex].Display();
	}
};
int main(){
	int size;
	cout<<"Enter The size of array.objects: ";
	cin>>size;
	student arr[size];
	for(int i=0;i<size;i++){
		arr[i].input();
	}
	cout<<"This is Higest Score "<<endl;
	student::check(arr , size);
}