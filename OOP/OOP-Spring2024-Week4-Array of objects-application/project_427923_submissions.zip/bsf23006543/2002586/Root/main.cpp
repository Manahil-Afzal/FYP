#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int count;  // Static variable to keep track of student serial number

public:
    // Constructor to initialize the student's data
    Student() {
        count++;
        id = count;
    }

    // Method to input student details
    void inputDetails() {
        cout << "\nEnter details for Student " << id << ":\n";
        cout << "Name: ";
        cin.ignore();  // to clear the buffer before taking string input
        getline(cin, name);
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;
    }

    // Method to display student details
    void displayDetails() const {
        cout << "Student ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Method to return the marks
    float getMarks() const {
        return marks;
    }

    // Static method to get the total count of students
    static int getStudentCount() {
        return count;
    }
};

// Initialize static member
int Student::count = 0;

int main() {
    Student students[8];

    // Input details for each student
    for (int i = 0; i < 8; ++i) {
        students[i].inputDetails();
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }

    // Display the student with highest marks
    cout << "\nStudent with the highest marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;
}
