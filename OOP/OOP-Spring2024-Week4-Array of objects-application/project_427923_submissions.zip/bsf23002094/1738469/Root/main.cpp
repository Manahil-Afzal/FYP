/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student{
	private :
		string name;
		int id;
		int marks;
		float cgpa;
		int serial;
	public:
	    static int count;
		void get_details(){
			count++;
			serial=count;
			cout<<"Enter the name of student :"<<endl;
			cin>>name;
			cout<<"Enter student id :"<<endl;
			cin>>id;
			cout<<"Enter the marks of student :"<<endl;
			cin>>marks;
			cout<<"Enter the cgpa of student :"<<endl;
			cin>>cgpa;
		}
		void display(){
		   cout<<"The serial no of student is :"<<serial<<endl;
			cout<<"The name of student is :"<<name<<endl;
			cout<<"The student id is :"<<id<<endl;
			cout<<"The marks of student is :"<<marks<<endl;
			cout<<"The cgpa of student is : "<<cgpa<<endl;	
		}
		int getmarks (){
			return marks;
			
	}
	
};
    int Student::count = 0;
    int main(){
    	const int n=8;
    	Student S1[n];
    for(int i=0; i<n; i++)
		{
        S1[i].get_details();
    	
    }
   
 for(int i=0; i<n; i++){
 	
 	S1[i].display();
 }
     int max=0;
     for(int i=0; i<n; i++){
     	if(S1[i].getmarks()>S1[max].getmarks()){
     		max=i;
		 }
	 }
	 cout<<"Details of student with highest marks :"<<endl;
	 S1[max].display();
    	return 0;
    	
    	
	}