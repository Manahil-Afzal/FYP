/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int count; 
public:
    Student(string n, float m, float c) {
        name = n;
        marks = m;
        cgpa = c;
        id = ++count; 
    }

    void displayDetails() {
        cout << "Serial No: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }
};

int Student::count = 0; 

int main() {
    const int numStudents = 3; 
    Student students[numStudents] = { 
        Student("Alice", 90.5, 8.5),
        Student("Bob", 85.0, 8.0),
        Student("Charlie", 88.0, 8.2)
    };

    for (int i = 0; i < numStudents; ++i) {
        students[i].displayDetails();
    }

    return 0;
}
