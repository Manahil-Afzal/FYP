/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
    static int count; // Static variable to keep track of the number of students
    int serialNumber; // Serial number for each student
    string name;
    int id;
    int marks;
    float cgpa;

  public:
    // Constructor to initialize the student object
    Student(string n, int i, int m, float c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        serialNumber = ++count; // Assign serial number based on the order of creating the student object
    }

    // Method to display student details
    void display() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Method to get marks
    int getMarks() {
        return marks;
    }

    // Static method to get the count of students
    static int getCount() {
        return count;
    }
};

// Initializing static variable outside the class definition
int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents] = {
        Student("John", 101, 85, 3.5),
        Student("Alice", 102, 78, 3.2),
        Student("Bob", 103, 92, 3.8),
        Student("Emily", 104, 88, 3.6),
        Student("David", 105, 79, 3.3),
        Student("Emma", 106, 95, 3.9),
        Student("James", 107, 90, 3.7),
        Student("Sophia", 108, 83, 3.4)
    };

    // Find the student with the highest marks
    int highestMarks = 0;
    int highestMarksIndex = 0;
    for (int i = 0; i < numStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Display details of the student with the highest marks
    cout << "Details of the student with the highest marks:" << endl;
    students[highestMarksIndex].display();

    return 0;
}
