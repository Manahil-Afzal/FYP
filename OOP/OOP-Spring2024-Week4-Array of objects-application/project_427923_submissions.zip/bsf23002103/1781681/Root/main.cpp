/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Student{
    private:
    string Name;
    string Id;
    int totalMarks;
    float CGPA;
    public:
    int Marks;
    void getInfo(){
        cout<<"Enter students details: "<<endl;
        cout<<"Enter Student Name: ";
        getline(cin, Name);
        cout<<"Enter Student Id: ";
        cin>>Id;
        cout<<"Enter Students marks: ";
        cin>>Marks;
        cout<<"Enter total marks: ";
        cin>>totalMarks;
        cout<<"Enter Student CGPA: ";
        cin>>CGPA;
        cin.ignore();
    }
    void showInfo(){
        cout<<"Name: "<<Name<<endl;
        cout<<"Id: "<<Id<<endl;
        cout<<"Marks: "<<Marks<<"/"<<totalMarks<<endl;
        cout<<"CGPA: "<<CGPA<<endl;
    }
    
};
int main (){
    Student obj[8];
    cout<<"Enter The Following Details: "<<endl;
    for(int i=0; i<8; i++){
        cout<<"Student "<<i+1<<": "<<endl;
        obj[i].getInfo();
}
    int Temp;
    Temp=obj[0].Marks;
    int index=0;
    for(int i=0; i<8; i++){
        if(obj[i].Marks>Temp){
        	Temp=obj[i].Marks;
            index=i;
        }
       
       
}

 cout<<"Student with Highest Marks: "<<endl;
 obj[index].showInfo();
 
}