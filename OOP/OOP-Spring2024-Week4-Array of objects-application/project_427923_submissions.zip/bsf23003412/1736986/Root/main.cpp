/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string>
using namespace std;
class student{
	string name;
	string id;
	int marks;
	float cgpa;
		 int count;
	//int serialno;
	public:
		student(int serial){
		    count=serial;
			
		}
		void getdata(){
			//cout<<"serial no:"<<serialno<<endl;
			cout<<"enter the name:";
			cin>>name;
			cout<<"enter the id:";
			cin>>id;
			cout<<"enter the marks:";
			cin>>marks;
			cout<<"enter the cgpa:";
			cin>>cgpa;
		}
		void putdata(){
		
				cout<<"serial number"<<count<<endl;
				cout<<"name"<<name<<endl;
				cout<<"id:"<<id<<endl;
				cout<<"marks"<<marks<<endl;
				cout<<"cgpa"<<cgpa<<endl;
		
	}
		
		int  getmarks(){
			return marks;
		}
//
//	int student::count = 0;
 //int student::count = 0;
	};
		int main(){
student s[8]={1,2,3,4,5,6,7,8};
for(int i=0;i<8;i++){
	cout<<"the details of student is:"<<i+1<<endl;
s[i].getdata();}


for(int i=0;i<8;i++){
	if(s[i].getmarks()>=1000)
{
cout<<"the information of highest marks student:";
s[i].putdata();	}			
			}
		}