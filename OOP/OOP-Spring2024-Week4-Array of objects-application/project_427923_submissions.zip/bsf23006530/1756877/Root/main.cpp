/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;

class Student {
    string name;
    int id;
    float marks;
    float cgpa;
    static int count;
    int serialNumber; 

public:
    Student(const string name, int id, float marks, float cgpa) 
         : name(name), id(id), marks(marks), cgpa(cgpa) {
            count++; 
            serialNumber = count;
    }

    void display() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    float getMarks(){
        return marks;
    }

    static int getCount() {
        return count;
    }
};

int Student::count = 0; 

int main() {
    Student students[8] = {
        {"Ali", 101, 85.5, 3.8},
        {"Zain", 102, 78.3, 3.6},
        {"Shaheer", 103, 99.2, 4.0},
        {"Anas", 104, 88.7, 3.9},
        {"Rizwan", 105, 96.1, 4.0},
        {"Tayyab", 106, 81.4, 3.7},
        {"Talha", 107, 89.5, 3.9},
        {"Asad", 108, 95.0, 4.0}
    };

    float highestMarks = students[0].getMarks();
    int highestIndex = 0;

    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestIndex = i;
        }
    }

    cout << "Student have highest marks:" << endl;
    students[highestIndex].display();

    return 0;
}
