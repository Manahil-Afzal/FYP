/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;

class Student{
	private:
		string name;
		string id;
		int totalMarks;
		float cgpa;
	public:
		int marks;
		void Input(){
			cout<<"Enter name : ";
			getline(cin,name);
			cout<<"Enter student id : ";
			getline(cin,id);
			cout<<"Enter marks obtained : ";
			cin>>marks;
			cout<<"Enter total marks : ";
			cin>>totalMarks;
			cout<<"Enter CGPA : ";
			cin>>cgpa;
		}
		
		void Display(){
        cout<<"Student "<<name<<" with Id="<<id<<endl;
        cout<<"have got "<<marks<<"/"<<totalMarks<<" marks"<<endl;
        cout<<"with "<<cgpa<<" CGPA"<<endl<<endl;
    	}
};

int main(){
	Student st[8];
	cout<<"Enter following data "<<endl;
	for(int i=0;i<8;i++){
		cout<<"\nStudent "<<i+1<<endl;
		cout<<"---------"<<endl;
		st[i].Input();
		cin.ignore();
	}
	
	int Temp;
    Temp=st[0].marks;
    int index=0;
    for(int i=0; i<8; i++){
        if(st[i].marks>Temp){
        	Temp=st[i].marks;
            index=i;
        }
    }
    
    cout<<"\nList of All Students Details: "<<endl;
    for(int i=0; i<8; i++){
        cout<<i+1<<"."<<" Student details: "<<endl;
        st[i].Display();
    }
    
    cout<<"Highest marks are : "<<endl;
    st[index].Display();
	return 0;	
}