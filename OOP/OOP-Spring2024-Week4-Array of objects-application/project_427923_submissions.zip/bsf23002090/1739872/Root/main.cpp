/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/#include <iostream>
using namespace std;

class student
{
private:
    string name;
    int id;
    int marks;
    float cgpa;
    int serial;

public:
    static int count;

    void getdetail()
    {
        serial = count;
        count++;
        cout << "Enter student name: " << endl;
        cin >> name;
        cout << "Enter student id: " << endl;
        cin >> id;
        cout << "Enter student marks: " << endl;
        cin >> marks;
        cout << "Enter student cgpa: " << endl;
        cin >> cgpa;
    }

    void display()
    {
        cout << "Student name: " << name << endl;
        cout << "Student id: " << id << endl;
        cout << "Student marks: " << marks << endl;
        cout << "Student cgpa: " << cgpa << endl;
        cout << "Serial number: " << serial << endl;
        cout << endl;
    }

    int getmarks()
    {
        return marks;
    }
};

int student::count = 1;

int main()
{
     int n = 8;
    student s1[n];

    for (int i = 0; i < n; i++)
    {
        s1[i].getdetail();
       
    }
    for (int i = 0; i < n; i++)
    {
         s1[i].display();
    }
    

    int highestmarks = 0;
    for (int i = 1; i < n; i++)
    {
        if (s1[i].getmarks() > s1[highestmarks].getmarks())
        {
            highestmarks = i;
        }
    }

    cout << "Details of the student with the highest marks:" << endl;
    s1[highestmarks].display();

    return 0;
}