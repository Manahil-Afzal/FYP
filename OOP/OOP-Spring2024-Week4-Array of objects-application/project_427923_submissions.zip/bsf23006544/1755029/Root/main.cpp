/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber; // Serial number assigned based on order of creation

public:
    // Constructor to initialize the student details
    Student(string n, int i, int m, float c, int sn) : name(n), id(i), marks(m), cgpa(c), serialNumber(sn) {}

    // Function to display student details
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Function to get marks of the student
    int getMarks() {
        return marks;
    }
};

int main() {
    // Creating an array of objects of 8 students
    Student students[8] = {
        {"Alice", 101, 85, 3.5, 1},
        {"Bob", 102, 90, 3.8, 2},
        {"Charlie", 103, 95, 3.9, 3},
        {"David", 104, 80, 3.3, 4},
        {"Eve", 105, 88, 3.6, 5},
        {"Frank", 106, 92, 3.7, 6},
        {"Grace", 107, 87, 3.65, 7},
        {"Harry", 108, 91, 3.75, 8}
    };

    // Finding the student with the highest marks
    int highestMarks = 0;
    int highestMarksIndex = 0;

    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Displaying the details of the student with the highest marks
    cout << "Details of the student with the highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}