/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;
class Student {
private:
 static int count; // Static member to keep track of the number of students
 int serialNumber; // Serial number of the student
 string name;
 int id;
 int marks;
 float cgpa;
public:
 // Constructor to initialize data members
 Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
 count++; // Increment count when object is created
 serialNumber = count; // Assign serial number
 }
 // Method to display student details
 void display() {
 cout << "Serial Number: " << serialNumber << endl;
 cout << "Name: " << name << endl;
 cout << "ID: " << id << endl;
 cout << "Marks: " << marks << endl;
 cout << "CGPA: " << cgpa << endl;
 cout << "--------------------------------------" << endl;
 }
 // Static method to find student with highest marks
 static Student highestMarks(Student students[], int size) {
 Student maxStudent = students[0];
 for (int i = 1; i < size; i++) {
 if (students[i].marks > maxStudent.marks) {
 maxStudent = students[i];
 }
 }
 return maxStudent;
 }
};
int Student::count = 0; // Initializing static member outside the class
int main() {
 // Creating an array of 8 students
 Student students[8] = {
 Student("John", 101, 85, 3.5),
 Student("Alice", 102, 90, 3.8),
 Student("Bob", 103, 75, 3.2),
 Student("Emma", 104, 95, 4.0),
 Student("Mike", 105, 82, 3.6),
 Student("Sophia", 106, 88, 3.7),
 Student("Liam", 107, 78, 3.1),
 Student("Olivia", 108, 92, 3.9)
 };
 // Displaying details of all students
 cout << "Details of all students:" << endl;
 for (int i = 0; i < 8; i++) {
 students[i].display();
 }
 // Finding and displaying student with highest marks
 Student highest = Student::highestMarks(students, 8);
 cout << "Student with highest marks:" << endl;
 highest.display();
 return 0;
}
