/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
    static int serialCounter;
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

public:
    Student() {
        serialNumber = ++serialCounter;
    }

    void takeInput() {
        cout << "Enter details for student " << serialNumber << ":" << endl;
        cout << "Name: ";
        cin >> ws;
        getline(cin, name);
        cout << "ID: ";
        cin >> id;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() {
        cout << "\nDisplaying details of the student with the highest marks:" << endl;
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    float getMarks() const {
        return marks;
    }
};

int Student::serialCounter = 0;

int main() {
    Student students[8];

    for (int i = 0; i < 8; ++i) {
        students[i].takeInput();
    }

    int highestMarks = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > students[highestMarks].getMarks()) {
            highestMarks = i;
        }
    }

    students[highestMarks].displayDetails();

    return 0;
}
