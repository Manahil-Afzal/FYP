/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student{
	private:
		string name;
		int ID;
		int marks;
		float CGPA;
	//	static int count;
		public:
				static int count;
			Student(){
				count++;
				ID=count;
			}
			void inputData(){
				cout<<"Enter name : "<<endl;
				cin>>name;
			//	cout<<"Enter ID : "<<endl;
			//	cin>>ID;
				cout<<"Enter marks : "<<endl;
				cin>>marks;
				cout<<"Enter CGPA : "<<endl;
				cin>>CGPA;
			}
			void displayDetail(){
				cout<<"Name "<<name <<"\n ID"<<ID<<"\nmarks"<<marks<<"\nCGPA"<<CGPA;
			}
			int getMarks(){
				return marks;
			}
};
	int Student :: count=0;
int main(){
	const int numStd=8;
	Student std[numStd];
	int highestMarks=-1;
	int highestMarksIndex=-1;
	for(int i=0;i<numStd;i++){
		cout<<"Enter details of Student  " << i+1 <<":" <<endl;
		std[i].inputData();
		if(std[i].getMarks() > highestMarks){
			highestMarks=std[i].getMarks();
			highestMarksIndex=i;
		}
	}
		cout<<"Details of Student with highest marks "<<endl;
		std[highestMarksIndex].displayDetail();
	
	return 0;
}