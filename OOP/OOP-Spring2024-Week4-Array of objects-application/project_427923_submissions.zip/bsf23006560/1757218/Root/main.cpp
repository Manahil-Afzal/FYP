
#include <iostream>
#include <string>

class Student {
public:
    std::string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber;

    Student() {
        static int counter = 1;
        serialNumber = counter++;
    }

    void inputDetails() {
        std::cout << "Enter student's name: ";
        std::cin >> name;
        std::cout << "Enter student's ID: ";
        std::cin >> id;
        std::cout << "Enter student's marks: ";
        std::cin >> marks;
        std::cout << "Enter student's CGPA: ";
        std::cin >> cgpa;
    }

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }
};

int main() {
    Student students[8];

    for (int i = 0; i < 8; i++) {
        std::cout << "Enter details of student " << i+1 << ":" << std::endl;
        students[i].inputDetails();
    }

    int highestMarks = students[0].marks;
    int highestMarksIndex = 0;

    for (int i = 1; i < 8; i++) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            highestMarksIndex = i;
        }
    }

    std::cout << "Student with the highest marks:" << std::endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
