// Online C++ compiler to run C++ program online
#include <iostream>
using namespace std;

int srOftop;
class Students{
  string name;
  static int ser;
  float cgpa;
  int id;
  public:
  int serial;
    float marks;
    Students(){
        ser++;
        serial = ser;
    }
    void putData(){
        cout<<"student of SeRIal#"<<serial<<endl;
        cout<<"Name: "<<name;
        cin>>name;
        cout<<"ID: ";
        cin>>id;
        cout<<"CGPA: ";
        cin>>cgpa;
        cout<<"Marks: ";
        cin>>marks;
    }
    
    void getData(){
        cout<<"---------------------------------------"<<endl;
        cout<<"Student of SERIAL#"<<srOftop<<" Topped!!!!!!"<<endl; 
        cout<<"Name: "<<name<<endl;
        cout<<"Marks: "<<marks<<endl;
        cout<<"Cpga: "<<cgpa<<endl;
    }
};
int Students::ser = 0;
int main() {
    Students std[8];
    for(int i=0;i<8;i++){
        std[i].putData();
    }
    int max = std[0].marks;
    int n;
    for(int i=0;i<8;i++){
        if(max<std[i].marks){
            n=i;
            srOftop = std[i].serial;
        }
    }
    std[n].getData();
}