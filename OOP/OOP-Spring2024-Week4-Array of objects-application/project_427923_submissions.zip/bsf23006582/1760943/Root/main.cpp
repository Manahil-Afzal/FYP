/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class ss{
	string name;
	int id;
	
	float cgpa;
		static int count;
	public:
		int marks;
		void get(){
			cout<<"name";
		
			cin>>name;
			cout<<"id";
			cin>>id;
			cout<<"marks";
			cin>>marks;
			cout<<"cgpa";
			cin>>cgpa;
			count++;
			
		}
		void set(){
			cout<<"name"<<name<<" "<<"id"<<id<<" "<<"marks"<<marks<<" "<<"cgpa"<<cgpa;
		}
};
int ss::count=0;
int main(){
	ss s[2];
	
	for(int i=0;i<2;i++){
		s[i].get();
		
	}
	int highestmarks=0;
	for(int i=0;i<2;i++)
	{
		if(s[i].marks>s[highestmarks].marks){
			highestmarks=i;
		}
	}
	cout<<"\nStudent with highest marks: ";
	s[highestmarks].set();
	
}

