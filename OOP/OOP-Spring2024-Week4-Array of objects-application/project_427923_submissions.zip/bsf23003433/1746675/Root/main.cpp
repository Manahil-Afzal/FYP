/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    RationalNumber(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        // Increment count of objects
        count++;
    }

    // Copy constructor
    RationalNumber(const RationalNumber &other) : numerator(other.numerator), denominator(other.denominator) {
        // Increment count of objects
        count++;
    }

    // Destructor
    ~RationalNumber() {
        // Decrement count of objects
        count--;
    }

    // Method to take input of numerator and denominator
    void getInput() {
        do {
            cout << "Enter numerator: ";
            cin >> numerator;
            cout << "Enter denominator (non-zero): ";
            cin >> denominator;
        } while (denominator == 0); // Check denominator is not zero
    }

    // Operator overloading for multiplication
    RationalNumber operator*(const RationalNumber &other) {
        RationalNumber result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    // Operator overloading for division
    RationalNumber operator/(const RationalNumber &other) {
        RationalNumber result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    // Static method to get count of objects
    static int getCount() {
        return count;
    }

    // Method to display rational number
    void display() {
        cout << numerator << "/" << denominator;
    }
};

int RationalNumber::count = 0; // Initialize static member count

int main() {
    RationalNumber num1, num2;
    
    // Input for first rational number
    cout << "Enter details for first rational number:" << endl;
    num1.getInput();
    
    // Copying first number to second number
    num2 = num1;

    // Display count of objects
    cout << "\nTotal Rational Numbers created: " << RationalNumber::getCount() << endl;

    // Input for second rational number
    cout << "\nEnter details for second rational number:" << endl;
    num2.getInput();

    // Display multiplication and division
    cout << "\nMultiplication: ";
    num1.display();
    cout << " * ";
    num2.display();
    cout << " = ";
    (num1 * num2).display();
    cout << endl;

    cout << "Division: ";
    num1.display();
    cout << " / ";
    num2.display();
    cout << " = ";
    (num1 / num2).display();
    cout << endl;

    return 0;
}
