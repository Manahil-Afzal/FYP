/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;

class Student {
private:
    static int count;
    int id;
    string name;
    float marks;
    float cgpa;

public:
    Student() {
        count++;
        id = count;
        name = "";
        marks = 0.0;
        cgpa = 0.0;
    }

    void inputDetails() {
        cout << "Enter details for student " << id << ":\n";
        cout << "Name: ";
        cin >> name;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() {
        cout << "Student " << id << " details:\n";
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    float getMarks() {
    return marks;
    }

static int getCount() {
        return count;
    }
};

int Student::count = 0;

int main() {
    const int SIZE = 8;
    Student students[SIZE];
    float maxMarks = 0;
    int maxIndex = -1;

    for (int i = 0; i < SIZE; i++) {
        students[i].inputDetails();
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    if (maxIndex != -1) {
        cout << "\nDetails of the student with highest marks:\n";
        students[maxIndex].displayDetails();
    }

    return 0;
}

