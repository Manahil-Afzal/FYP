/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class student{
private:
	string name;
	int id;
	int marks;
	int CGPA;
public:

	void getname(){
		cin>>name;
	}
	void getid(){
		cin>>id;
	}
	void getmarks(){
		cin>>marks;
	}
	void getCGPA(){
		cin>>CGPA;
	}
	
	void displayinf(){
		cout<<"Name="<<" "<<name<<endl;
		cout<<" ID ="<<" "<<id<<endl;
		cout<<" Marks"<<" "<<marks<<endl;
		cout<<"CGPA"<<" "<<CGPA<<endl;		
		
	}
};
int main(){
	student stu[9];
	for(int a=0; a<=7; a++){
		cout<<"Student"<<a+1<<endl;
		cout<<"Enter name=";
		stu[a].getname();
		cout<<endl;
		cout<<"enter the id=";
		stu[a].getid();
		cout<<endl;
		cout<<"Enter the marks=";
		stu[a].getmarks();
		cout<<endl;
		cout<<"enter the CGPA=";
		stu[a].getCGPA();
		cout<<endl;
		cout<<"serial no."<<a+12<<endl;
		cout<<endl;
		
			
	}
	for(int a=0; a<=7; a++){
		
		cout<<"student"<<a+1;
		stu[a].displayinf();
	}	
	return 0;
	
	
	
	
	
	}
