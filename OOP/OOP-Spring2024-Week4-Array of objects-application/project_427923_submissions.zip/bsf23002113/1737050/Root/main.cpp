/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Students{
    private:
    string name;
    string id;
    int totalmarks;
    float Cgpa;
    public:
    int marks;
    void getdetails(){
        cout<<"Enter students details: "<<endl;
        cout<<"Enter Student Name: ";
        getline(cin, name);
        cout<<"Enter Student Id: ";
        cin>>id;
        cout<<"Enter Student marks: ";
        cin>>marks;
        cout<<"Enter total marks : ";
        cin>>totalmarks;
        cout<<"Enter Student CGPA: ";
        cin>>Cgpa;
        cin.ignore();
    }
    void showdetails(){
        cout<<"Name: "<<name<<endl;
        cout<<"Id: "<<id<<endl;
        cout<<"Marks: "<<marks<<"/"<<totalmarks<<endl;
        cout<<"CGPA: "<<Cgpa<<endl;
    }
    
};
int main (){
    Students Std[3];
    cout<<"Enter Students Following Details: "<<endl;
    for(int i=0; i<3; i++){
        cout<<"Student"<<i+1<<": "<<endl;
        Std[i].getdetails();
    }
    int Temp;
    Temp=Std[0].marks;
    int index=0;
    int _index=0;
    cout<<"\nStudent with Highest Marks"<<endl;
    for(int i=0; i<3; i++){
        if(Std[i].marks>Temp){
        	Temp=Std[i].marks;
            index=i;
        }
        if(Std[i].marks<Temp){
        	Temp=Std[i].marks;
        	_index=i;
		}
       
}
 Std[index].showdetails();
 cout<<"Student With Lowest Marks: "<<endl;
 Std[_index].showdetails();
    return 0; 
}