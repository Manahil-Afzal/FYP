/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;

class Student {
    static int count;
    int serialNumber;
    string name;
    int id;
    float marks;
    float cgpa;

public:
    Student(string name, int id, float marks, float cgpa) {
        this->name = name;
        this->id = id;
        this->marks = marks;
        this->cgpa = cgpa;
        this->serialNumber = ++count;
    }

    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 3;
    Student students[numStudents] = {
        Student("John Doe", 12345, 85.5, 3.8),
        Student("Jane Smith", 54321, 92.3, 4.0),
        Student("Alice Brown", 98765, 78.0, 3.5)
    };

    for (int i = 0; i < numStudents; ++i) {
        cout << "Student " << i + 1 << " details:" << endl;
        students[i].displayDetails();
        cout << endl;
    }

    return 0;
}