#include <iostream>
#include <string>

using namespace std;
class Student {
private:
    static int count;
    int serialNumber;
    string name;
    int id;
    float marks;
    float cgpa;

public:
    // Default constructor
    Student() {}

    Student(string n, int i, float m, float c) {
	name=n;
	id=i;
	marks=m;
	cgpa=c; 
        serialNumber = ++count;
    }

    void displayDetails() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    static int getCount() {
        return count;
    }
    static void resetCount() {
        count = 0;
    }

    Student findHighestMarks(Student students[], int size) {
        Student highestStudent;
        float highestMarks = -1; // assuming marks are non-negative
        for (int i = 0; i < size; ++i) {
            if (students[i].marks > highestMarks) {
                highestMarks = students[i].marks;
                highestStudent = students[i];
            }
        }
        return highestStudent;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];
    for (int i = 0; i < numStudents; ++i) {
        string name;
        int id;
        float marks, cgpa;

        cout << "Enter details for student " << i + 1 << ":" << endl;
        cout << "Name: ";
        getline(cin , name);
        cout << "ID: ";
        cin >> id;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;

        students[i] = Student(name, id, marks, cgpa);
        cout << endl;
    }

    cout << "Details of the student with the highest marks:\n";
    Student student;
    student = student.findHighestMarks(students, numStudents);
    student.displayDetails();

    return 0;
}

