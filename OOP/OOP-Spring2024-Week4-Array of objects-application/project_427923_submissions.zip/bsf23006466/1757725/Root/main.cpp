/*Write a C++ program that creates a class to take and display details of student. It takes input for student's
name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took 
highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class STUDENT{
    int id;
    int marks;
    string name;
    float cgpa;
    static int count;
    int serial;
    public:
    STUDENT(){
        count++;
        serial=count;
    }
   
   void put(){
       cout<<"ENTER DETAILAS OF STUDENT : "<<count<<endl;
       cout<<"ID : ";
       cin>>id;
       cout<<"MARKS : ";
       cin>>marks;
       cout<<"NAME : ";
       cin>>name;
       cout<<"CGPA : ";
       cin>>cgpa;
   }
   void get(){
       cout<<"DETAILAS OF STUDENT : "<<endl;
       cout<<"ID : "<<id<<endl;
       cout<<"serial number : "<<serial;
       cout<<"MARKS : "<<marks<<endl;
       cout<<"NAME : "<<name<<endl;
       cout<<"CGPA : "<<cgpa<<endl;
       
   }
   int Marks(){
       return marks;
   }
};
int STUDENT::count=0;
int main(){
    STUDENT student[8];
    for(int i=0;i<8;i++){
        student[i].put();
    }
    int high_marks=0;
    int index=0;
    for(int i=0; i<8 ; i++){
        if(student[i].Marks()>high_marks){
          high_marks=student[i].Marks();
          index=i;
        }
    }
    cout<<" /n Student of highest marks : "<<endl;
    student[index].get();
    
    return 0;
}







