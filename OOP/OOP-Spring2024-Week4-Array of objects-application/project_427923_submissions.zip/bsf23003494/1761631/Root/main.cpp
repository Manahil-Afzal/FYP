/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/#include <iostream>
#include <string>

class Student {
private:
    std::string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

public:
    Student() {
        static int count = 1;
        serialNumber = count++;
    }

    void inputDetails() {
        std::cout << "Enter student name: ";
        std::cin >> name;
        std::cout << "Enter student ID: ";
        std::cin >> id;
        std::cout << "Enter student marks: ";
        std::cin >> marks;
        std::cout << "Enter student CGPA: ";
        std::cin >> cgpa;
    }

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }

    float getMarks() {
        return marks;
    }
};

int main() {
    Student students[8];

    // Input details for each student
    for (int i = 0; i < 8; ++i) {
        std::cout << "\nEnter details for student " << i + 1 << ":\n";
        students[i].inputDetails();
    }

    // Find student with highest marks
    float maxMarks = students[0].getMarks();
    int maxIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    // Display details of student with highest marks
    std::cout << "\nDetails of student with highest marks:\n";
    students[maxIndex].displayDetails();
    return 0;
}