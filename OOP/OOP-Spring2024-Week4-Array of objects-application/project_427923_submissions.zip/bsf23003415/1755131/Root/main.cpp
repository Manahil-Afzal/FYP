/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int count; // static member to keep track of the number of students
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
        count++; // Increment count when a student is created
        serialNumber = count; // Assign serial number based on count
    }

    // Method to display student details
    void display() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Static member function to get the count of students
    static int getCount() {
        return count;
    }

    // Function to find the student with the highest marks among the array
    static Student findHighestMarks(Student students[], int size) {
        Student highest = students[0];
        for (int i = 1; i < size; ++i) {
            if (students[i].marks > highest.marks) {
                highest = students[i];
            }
        }
        return highest;
    }
};

// Initializing static member outside class definition
int Student::count = 0;

int main() {
    Student students[8] = {
        Student("Alice", 101, 85, 3.8),
        Student("Bob", 102, 90, 3.5),
        Student("Charlie", 103, 95, 3.9),
        Student("David", 104, 80, 3.7),
        Student("Eve", 105, 88, 3.6),
        Student("Frank", 106, 92, 3.4),
        Student("Grace", 107, 87, 3.9),
        Student("Henry", 108, 94, 3.8)
    };

    // Display details of all students
    for (int i = 0; i < 8; ++i) {
        cout << "Details of Student " << i + 1 << ":" << endl;
        students[i].display();
        cout << endl;
    }

    // Find and display the student with the highest marks
    Student highestMarksStudent = Student::findHighestMarks(students, 8);
    cout << "Student with the highest marks:" << endl;
    highestMarksStudent.display();

    return 0;
}
