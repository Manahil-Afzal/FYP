/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student{
public:
string Name;
int ID;
int Marks;
float CGPA;

void inputDetails(){
cout<<"Enter student Name:";
cin>>Name;
cout<<"Enter student ID:";
cin>>ID;
cout<<"Enter student marks:";
cin>>Marks;
cout<<"Enter student CGPA:";
cin>>CGPA;
}
void displayDetails(){
    cout<<"Name:"<< Name <<endl;
    cout<<"ID:"<< ID <<endl;
    cout<<"Marks:"<< Marks <<endl;
    cout<<"CGPA:"<< CGPA <<endl;
}
};
int main(){
    Student student[8];
    for(int i=0; i<8; i++){
        cout<<"Enter details for student:"<<i+1<<":"<<endl;
        student[i].inputDetails();
        cout<<endl;
    }
    int highestMarks =0;
    int highestMarksIndex =0;
    for(int i=0; i<8; i++){
        if(student[i].Marks>highestMarks){
            highestMarks=student[i].Marks;
            highestMarksIndex =i;
        }
    }
   cout<<"Student with the highest marks:"<<endl;
   cout<<"Serial Number:"<<highestMarksIndex + 1<<endl;
     student[highestMarksIndex].displayDetails();
     return 0;
}