/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
/*CODE*/
#include<iostream>
#include<string>
using namespace std;
class student{
	int id;
	string name;
	int marks;
	float CGPA;
	int serialnum;
	static int objectcount;
	public:
		student(){
			objectcount++;
			serialnum=objectcount;
		}
	void getdata();
   void displaydata();
	void displayhms(student st[],int size);
};
void student::getdata(){
	cout<<"Student #:"<<serialnum<<endl;
	cout<<"Student ID:";
	cin>>id;
	cout<<"Student name:";
	getline(cin>>ws,name);
	cout<<"Student marks:";
	cin>>marks;
	cout<<"Student CGPA:";
	cin>>CGPA;
	cout<<endl;
}
void student::displayhms(student st[],int size){
	int maxindex=0;
	int maxmarks=st[0].marks;
	for(int i=1;i<size;++i)
	{
		if(st[i].marks>maxmarks)
		{
			maxmarks=st[i].marks;
			maxindex=i;
		}
	}
	st[maxindex].displaydata();
}
void student::displaydata(){
    cout<<endl<<"Student #"<<serialnum<<endl;
	cout<<"Student ID:"<<id<<endl;
	cout<<"Student name:"<<name<<endl;
	cout<<"Student marks:"<<marks<<endl;
	cout<<"Student CGPA:"<<CGPA<<endl;
	
}
int student::objectcount=0;
int main(){
	student st[8];
		cout<<endl<<"Student Details:"<<endl;
	for(int i=0;i<8;++i){
	st[i].getdata();
	}
	cout<<"Details of Student with Highest Marks:"<<endl;
		for(int i=0;i<1;++i){
	st[i].displayhms(st,8);
	}		
}