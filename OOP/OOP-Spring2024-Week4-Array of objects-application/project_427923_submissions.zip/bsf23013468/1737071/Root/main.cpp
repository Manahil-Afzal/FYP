/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <iomanip>
using namespace std;

class Student {
private:
    static int serialNumberCounter;
    int serialNumber;
    string name;
    int id;
    float marks;
    float cgpa;

public:
    Student() {
        serialNumber = ++serialNumberCounter;
    }

    void inputDetails() {
        cout << "Enter student's name: ";
        cin.ignore(); // Ignore any newline character in the buffer
        getline(cin, name);

        cout << "Enter student's ID: ";
        cin >> id;

        cout << "Enter student's marks: ";
        cin >> marks;

        cout << "Enter student's CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() const {
        cout << "\nSerial Number: " << serialNumber;
        cout << "\nName: " << name;
        cout << "\nID: " << id;
        cout << "\nMarks: " << marks;
        cout << "\nCGPA: " << fixed << setprecision(2) << cgpa << endl;
    }

    float getMarks() const {
        return marks;
    }
};

int Student::serialNumberCounter = 0;

int main() {
    const int numOfStudents = 8;
    Student students[numOfStudents];

    // Input details for each student
    for (int i = 0; i < numOfStudents; ++i) {
        cout << "\nEnter details for Student " << i + 1 << ":" << endl;
        students[i].inputDetails();
    }

    // Find the student with the highest marks
    int highestMarksIndex = 0;
    for (int i = 1; i < numOfStudents; ++i) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }

    // Display details of the student with the highest marks
    cout << "\nDetails of the student with the highest marks:";
    students[highestMarksIndex].displayDetails();

    return 0;
}