/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
    static int serialNumber;
    string name;
    int id;
    float marks;
    float cgpa;

public:
    Student();
    void inputDetails();
    void displayDetails();
    float getMarks() const;

    static int getSerialNumber() {
        return serialNumber;
    }
};

int Student::serialNumber = 1;

Student::Student() {
    id = serialNumber++;
}

void Student::inputDetails() {
    cout << "Enter Student's Name: ";
    cin.ignore();
    getline(cin, name);

    cout << "Enter Student's Marks: ";
    cin >> marks;

    cout << "Enter Student's CGPA: ";
    cin >> cgpa;
}

void Student::displayDetails() {
    cout << "\nStudent Serial Number: " << id << endl;
    cout << "Student Name: " << name << endl;
    cout << "Student Marks: " << marks << endl;
    cout << "Student CGPA: " << cgpa << endl;
}

float Student::getMarks() const {
    return marks;
}

int main() {
    using namespace std;

    Student students[8];
    int highestMarksIndex = 0;

    for (int i = 0; i < 8; ++i) {
        cout << "Enter details for Student " << i + 1 << ":\n";
        students[i].inputDetails();
    }

    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }

   
    cout << "\nDetails of Student with Highest Marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;
}
