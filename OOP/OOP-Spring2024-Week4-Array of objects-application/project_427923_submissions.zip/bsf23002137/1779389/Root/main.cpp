
/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Student {
private:
    string name;
    int id;
    double marks;
    double cgpa;
public:
    Student(string n, int i, double m, double c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
    }
    void displayDetails() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
    double getMarks() {
        return marks;
    }
	 };
int main() {
    const int numOfStudents = 8;
    Student students[numOfStudents] = {
        {"Fatima",  1, 85.5, 3.6},
        {"Ali", 2, 90.0, 3.8},
        {"Bilal",  3, 78.5, 3.2},
        {"Emaan", 4, 95.0, 4.0},
        {"Minha", 5, 88.5, 3.7},
        {"Shakeel", 6, 91.5, 3.9},
        {"Ayesha", 7, 82.0, 3.4},
        {"Esha", 8, 87.0, 3.5}
    };
    double highestMarks = 0;
    int highestIndex = 0;
    for (int i = 0; i < numOfStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestIndex = i;
        }
}
    cout << "\nDetails of student with highest marks:" << endl;
    students[highestIndex].displayDetails();
    return 0;
}
