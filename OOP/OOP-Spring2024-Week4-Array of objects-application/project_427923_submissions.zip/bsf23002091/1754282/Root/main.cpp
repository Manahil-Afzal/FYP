/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;
class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int count; // Static member to keep track of the number of students
    int serialNumber; // Serial number of the student

public:
    Student(string n, int i, int m, float c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        count++;
        serialNumber = count;
    }

    void display() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks <<endl;
        cout << "CGPA: " << cgpa << endl;
        cout << std::endl;
    }

    static int getCount() {
        return count;
    }

    static void displayHighestMarks(Student students[], int size) {
        int maxMarks = students[0].marks;
        int maxIndex = 0;

        for (int i = 1; i < size; i++) {
            if (students[i].marks > maxMarks) {
                maxMarks = students[i].marks;
                maxIndex = i;
            }
        }

        cout << "Student with the highest marks:" << std::endl;
        students[maxIndex].display();
    }
};

int Student::count = 0;

int main() {
    Student students[8] = {
        Student("Ali", 1, 90, 3.8),
        Student("Babar", 2, 85, 3.6),
        Student("hamza", 3, 95, 3.9),
        Student("Dawod", 4, 88, 3.7),
        Student("Eman", 5, 92, 3.85),
        Student("Farhan", 6, 87, 3.65),
        Student("Greenay", 7, 94, 3.95),
        Student("Hemanshu", 8, 89, 3.75)
    };

    for (int i = 0; i < Student::getCount(); i++) {
        students[i].display();
    }

    Student::displayHighestMarks(students, 8);

    return 0;
}
