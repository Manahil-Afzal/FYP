#include <iostream>
using namespace std;
class Student{
    private:
    string Name;
    string Id;
    int totalMarks;
    float CGPA;
    public:
    int Marks;
    void getInfo(){
        cout<<"Enter students details: "<<endl;
        cout<<"Enter Student Name: ";
        getline(cin, Name);
        cout<<"Enter Student Id: ";
        cin>>Id;
        cout<<"Enter Students marks: ";
        cin>>Marks;
        cout<<"Enter total marks: ";
        cin>>totalMarks;
        cout<<"Enter Student CGPA: ";
        cin>>CGPA;
        cin.ignore();
    }
    void showInfo(){
        cout<<"Name: "<<Name<<endl;
        cout<<"Id: "<<Id<<endl;
        cout<<"Marks: "<<Marks<<"/"<<totalMarks<<endl;
        cout<<"CGPA: "<<CGPA<<endl;
    }
    
};
int main (){
    Student obj[8];
    cout<<"Enter The Following Details: "<<endl;
    for(int i=0; i<8; i++){
        cout<<"Student"<<i+1<<": "<<endl;
        obj[i].getInfo();
}
    int Temp;
    Temp=obj[0].Marks;
    int index=0;
    int _index=0;
    for(int i=0; i<8; i++){
        if(obj[i].Marks>Temp){
        	Temp=obj[i].Marks;
            index=i;
        }
        if(obj[i].Marks<Temp){
        	Temp=obj[i].Marks;
        	_index=i;
		}
       
}
 cout<<"\nStudent with Highest Marks: "<<endl;
 obj[index].showInfo();
 cout<<"\nStudent With Lowest Marks: "<<endl;
 obj[_index].showInfo();
    return 0; 
}