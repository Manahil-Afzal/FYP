/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int count; 
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    
    Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
        count++;
        serialNumber = count;
    }

    
    void display() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    
    int getMarks() {
        return marks;
    }

    
    int getSerialNumber() {
        return serialNumber;
    }

    
    static int getTotalStudents() {
        return count;
    }
};


int Student::count = 0;

int main() {
    Student students[8] = {
        Student("Ali", 101, 85, 3.5),
        Student("baber", 102, 90, 3.7),
        Student("daniyal", 103, 80, 3.3),
        Student("saim", 104, 95, 3.9),
        Student("haris", 105, 88, 3.6),
        Student("adeel", 106, 75, 3.0),
        Student("hamza", 107, 92, 3.8),
        Student("ahmad", 108, 78, 3.2)
    };

    int highestMarks = 0;
    int index = 0;

    
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            index = i;
        }
    }

    cout << "Details of student with highest marks:" << endl;
    students[index].display();

    return 0;
}
