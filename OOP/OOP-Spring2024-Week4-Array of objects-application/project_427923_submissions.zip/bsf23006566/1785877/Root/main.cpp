/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
#include <string>

class Student {
private:
    std::string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber;

public:
    // Constructor
    Student(std::string name, int id, int marks, float cgpa, int serialNumber) {
        this->name = name;
        this->id = id;
        this->marks = marks;
        this->cgpa = cgpa;
        this->serialNumber = serialNumber;
    }

    // Method to display student details
    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << std::endl;
    }

    // Getter method for marks
    int getMarks() const {
        return marks;
    }
};

int main() {
    // Creating an array of objects of 8 students
    Student students[8] = {
        Student("Junaid", 101, 85, 3.5, 1),
        Student("rizwan", 102, 90, 3.8, 2),
        Student("ahmad", 103, 78, 3.2, 3),
        Student("ali", 104, 92, 3.9, 4),
        Student("qasam", 105, 88, 3.7, 5),
        Student("rahan", 106, 95, 4.0, 6),
        Student("raza", 107, 82, 3.4, 7),
        Student("Emman", 108, 89, 3.6, 8)
    };

    // Finding the student with the highest marks
    int highestMarks = -1;
    int highestMarksIndex = -1;

    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;

        }
    }

    // Displaying details of the student with the highest marks
    std::cout << "Details of the student with the highest marks:" << std::endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}