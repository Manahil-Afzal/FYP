/*Write a C++ program that creates a class to take and display details of student.
It takes input for student's name, id, marks, and CGPA.Create an array of objects
of 8 students and display the details of student who took highest marks among
the 8 students. 
Also assign a serial number to each student based on the order of creating the
respective student object.*/

#include<iostream>
#include<string>
using namespace std;

class Student{
	string name;
	int id;
	int marks;
	float CGPA;
	public:
	static int serialNo;
		Student(){
			serialNo++;
		}
	void getdata(){
		cout<<"Enter Name of student:";
		cin>>name;
		cout<<"Enter your id:";
		cin>>id;
		cout<<"Enter your marks:";
		cin>>marks;
		cout<<"Enter your CGPA:";
		cin>>CGPA;
	}

void putdata(){
		cout<<"Name :"<<name<<endl;
		cout<<"Enter your id:"<<id<<endl;
		cout<<"Enter your marks:"<<marks<<endl;
		cout<<"Enter your CGPA:"<<CGPA<<endl;
	}
	int getMarks(){
		return marks;
	}

};
int Student::serialNo=0;
int main(){
	Student s[8];
	for(int i=0;i<8;i++){
		cout<<"Student: "<<i+1<<endl;
		s[i].getdata();
	}
	int highestmarks=s[0].getMarks();
	int highestindex=0;
	for(int i=0;i<8;i++){
		if(s[i].getMarks()>highestmarks){
			highestmarks=s[i].getMarks();
			highestindex=i;
		}
	}
	    cout << "Details of the student with highest marks:" << endl;
		s[highestindex].putdata();
		cout<<"Total Students: "<<Student::serialNo<<endl;
	return 0;
}