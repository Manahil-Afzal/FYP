/*Write a C++ program that creates a class to take and display details of student. It takes input for student's
name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took 
highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<iostream>
using namespace std;
class Student
       {
              int Id;
              string name;
              int marks;
              float cgpa;
              static int count;
              public:
              void getData(Student std[],int b){
                for(int i=0;i<b;i++){
                cout<<"serial # "<<Student ::getcount()<<")"<<endl;
                    cout<<"Enter Id of Student "<<i+1<<endl;
                    cin>>std[i].Id;
                    cout<<"Enter Name of Student "<<i+1<<endl;
                    cin>>std[i].name;
                    cout<<"Enter Marks of Student "<<i+1<<endl;
                    cin>>std[i].marks;
                    cout<<"Enter  CGPA of Student "<<i+1<<endl;
                    cin>>std[i].cgpa;
                    count++;

              }
              }
              void putData(Student std[],int b){
                int var=0;
                  for(int i=0;i<b;i++){
                    if(std[i].marks>std[var].marks){
                        var=i;
                        }
                    }
                   cout<<"Displaying the details of student whose marks are highest"<<endl;
                    cout<<"name is  "<<std[var].name<<endl;
                    cout<<"id is  "<<std[var].Id<<endl; 
					cout<<"marks are  "<<std[var].marks<<endl; 
					cout<<"CGPA is  "<<std[var].cgpa<<endl;
              
              }   
              static int getcount(){
                return count;

              }    
       };
int Student::count=1;
       int main()
       {
            Student std[8];  
            std[0].getData(std,8);
            std[0].putData(std,8);
             
        return 0;
       }
