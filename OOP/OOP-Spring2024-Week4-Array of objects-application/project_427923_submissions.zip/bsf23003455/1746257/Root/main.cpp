/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/#include<iostream>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int count;

public:
    void setdata() {
        cout << "Enter Your name: ";
        cin >> name;
        cout << "Enter Your marks: ";
        cin >> marks;
        cout << "Enter Your cgpa: ";
        cin >> cgpa;
        id = ++count;
    }

    void print() {
        cout << "Student ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student std[numStudents];

    for (int i = 0; i < numStudents; i++) {
        cout << "Student number: " << i + 1 << endl;
        std[i].setdata();
    }

    int maxMarksIndex = 0;
    for (int i = 1; i < numStudents; i++) {
        if (std[i].getMarks() > std[maxMarksIndex].getMarks()) {
            maxMarksIndex = i;
        }
    }

    cout << "Student with the highest marks:" << endl;
    std[maxMarksIndex].print();

    return 0;
}
