/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int count; // Static variable to keep track of the number of students
    int serialNumber;
    string name;
    int id;
    float marks;
    float cgpa;

public:
    Student() {
        serialNumber = ++count; // Increment count and assign as serial number
    }

    void getDetails() {
        cout << "Enter details for student " << serialNumber << ":\n";
        cout << "Name: ";
        cin >> name;
        cout << "ID: ";
        cin >> id;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() {
        cout << "Student " << serialNumber << " Details:\n";
        cout << "Name: " << name << "\n";
        cout << "ID: " << id << "\n";
        cout << "Marks: " << marks << "\n";
        cout << "CGPA: " << cgpa << "\n";
    }

    float getMarks() const {
        return marks;
    }
};

int Student::count = 0; // Initialize static member count

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; ++i) {
        students[i].getDetails();
    }

    // Find the student with the highest marks
    int maxIndex = 0;
    float maxMarks = students[0].getMarks();
    for (int i = 1; i < numStudents; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    // Display details of the student with the highest marks
    cout << "\nDetails of the student with the highest marks:\n";
    students[maxIndex].displayDetails();

    return 0;
}
