#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int count; // to keep track of the number of students

public:
    Student(string n, float m, float c) {
        name = n;
        marks = m;
        cgpa = c;
        id = ++count; // assigning a serial number based on the order of creation
    }

    void displayDetails() {
        cout << "Serial No: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }
};

int Student::count = 0; // initializing static member

int main() {
    const int numStudents = 3; // you can change this value according to your need
    Student students[numStudents] = { 
        Student("Alice", 90.5, 8.5),
        Student("Bob", 85.0, 8.0),
        Student("Charlie", 88.0, 8.2)
    };

    for (int i = 0; i < numStudents; ++i) {
        students[i].displayDetails();
    }

    return 0;
}/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/