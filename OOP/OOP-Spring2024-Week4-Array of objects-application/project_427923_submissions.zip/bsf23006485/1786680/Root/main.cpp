/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream> 
using namespace std;
 class student{     
 	public:  
	 	string name; 
		int id;  	
		float marks; 
       float cgpa; 
    void in(){ 
     	cout<<"enter name:";      	
		 cin>>name;      	
		 cout<<"enter id:";      	
		 cin>>id;      	
		 cout<<"enter marks:";      	
		 cin>>marks;      	
		 cout<<"enter cgpa:"; 
     	 cin>>cgpa; 
 	 	} 
 	void display(){ 
 	 	cout<<"\n Name is:"<<name<<"\nid is:"<<id<<"\n marks are:"<<marks<<"\n cgpa is:"<<cgpa; 
 	} 
}; 
int main()
{ 
 student std[8];  
 for(int i=0;i<8;i++){ 
cout<<"student "<<i+1<<endl;  	 
	std[i].in(); 
 	} 
 	cout<<"\n your enter student detail is:"; 
 	for(int i=0;i<8;i++){ 
 	 	cout<<"\n details of student number "<<i+1<<";"<<endl; 
 	 	 	 	std[i].display(); 
 	} 
 	 	int a; 
 	 	int b=std[0].marks;
		for(int i=1;i<8;i++)
		{  	 	 	
		if(b<std[i].marks){ 
 	 	 	b=std[i].marks; 
 	 	 	a=i; 	 
 	 	 	} 
 	 	} 
cout<<"\n\n\t\t____________"<<endl; 
 	 	cout<<"Student with the highest marks :"<<endl<<endl; 
 	 	 	std[a].display();  
 	 	 	 
} 

