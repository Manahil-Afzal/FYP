#include <iostream>
using namespace std;

class Student {
private:
    static int serialNumberCounter;
    int serialNumber;
    string name;
    int id;
    int marks;
    float CGPA;

public:
    Student() {
        serialNumber = ++serialNumberCounter;
        name = "";
        id = 0;
        marks = 0;
        CGPA = 0.0f;
    }
    

    void inputDetails() {
        cout << "\nEnter student name: ";
        cin >> name;
        cout << "Enter student ID: ";
        cin >> id;
        cout << "Enter student marks: ";
        cin >> marks;
        cout << "Enter student CGPA: ";
        cin >> CGPA;
    }


    void displayDetails() {
        cout << "\nSerial Number: " << serialNumber;
        cout << "\nName: " << name;
        cout << "\nID: " << id;
        cout << "\nMarks: " << marks;
        cout << "\nCGPA: " << CGPA << endl;
    }

    
    int getMarks() const {
        return marks;
    }
};

int Student::serialNumberCounter = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];
    int highestMarksIndex = 0;

    for (int i = 0; i < numStudents; ++i) {
        cout << "\nEnter details for Student " << i + 1 << ":";
        students[i].inputDetails();
    }

    for (int i = 1; i < numStudents; ++i) {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
        }
    }

    cout << "\nDetails of student with highest marks:";
    students[highestMarksIndex].displayDetails();

    return 0;
}
