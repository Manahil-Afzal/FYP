/* Write a C++ program that creates a class to take and display details of student. It takes input for student name, id, marks. 
Create an array of objects of 10 students and display the details of student who took highest marks among the 10 students.*/
#include<iostream>
#include<string>
using namespace std;

class student
{
    public:
    string name;
    int id;
    int marks;

    void getdata(){
        cout<<"Enter Name"<<endl;
        cin>>name;
        cout<<"Enter Roll.no"<<endl;
        cin>>id;
        cout<<"Enter Marks"<<endl;
        cin>>marks;
        
    }
    void putdata(){
        cout<<endl<<name<<endl<<id<<endl<<marks<<endl;
    }
};
int main()
{
    int i;
    
    student s[10];
    for(i=0;i<10;i++)
    {
        cout<<"Enter details of "<<"Student "<<i+1<<endl;
        s[i].getdata();
    }
    
    cout<<"Details of students";
    for(i=0;i<10;i++)
    s[i].putdata();
    
  for(i = 1;i <10; ++i)
    {
       if(s[0].marks < s[i].marks)
           s[0] = s[i];
    }
    cout << "Student with the highest Marks is " ;
    s[0].putdata();
    return 0;
}
