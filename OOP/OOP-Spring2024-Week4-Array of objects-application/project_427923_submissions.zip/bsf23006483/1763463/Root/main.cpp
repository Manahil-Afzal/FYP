/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

  #include <iostream>
  #include <string>

  using namespace std;

  class Student {
  private:
      static int count;
      string name;
      int id;
      float marks;
      float cgpa;
      int serialNumber;

  public:
      Student() {
          count++;
          serialNumber = count;
      }

      void setData() {
          cout << "Enter student name: ";
          getline(cin, name);
          cout << "Enter student ID: ";
          cin >> id;
          cout << "Enter marks: ";
          cin >> marks;
          cout << "Enter CGPA: ";
          cin >> cgpa;
          cin.ignore(); // Clear the input buffer
      }

      void displayDetails() {
          cout << "Serial Number: " << serialNumber << endl;
          cout << "Name: " << name << endl;
          cout << "ID: " << id << endl;
          cout << "Marks: " << marks << endl;
          cout << "CGPA: " << cgpa << endl;
      }

      static int getCount() {
          return count;
      }

      float getMarks() const {
          return marks;
      }
  };

  int Student::count = 0;

  int main() {
      Student students[8];

      for (int i = 0; i < 8; ++i) {
          cout << "Enter details for student " << i + 1 << endl;
          students[i].setData();
      }

      float highestMarks = students[0].getMarks();
      int indexHighestMarks = 0;

      for (int i = 1; i < 8; ++i) {
          if (students[i].getMarks() > highestMarks) {
              highestMarks = students[i].getMarks();
              indexHighestMarks = i;
          }
      }

      cout << "Details of student with the highest marks:" << endl;
      students[indexHighestMarks].displayDetails();

      return 0;
  }    