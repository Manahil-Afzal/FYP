#include <iostream>
using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int serialNumber; // to keep track of serial number
public:
    Student() {
        serialNumber++; // increment serial number for each object creation
    }
    void inputDetails() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter ID: ";
        cin >> id;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter CGPA: ";
        cin >> cgpa;
    }
    void displayDetails() {
        cout << "\nStudent with the highest marks in " << serialNumber << " students" << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
    float getMarks() {
        return marks;
    }
};

int Student::serialNumber = 0; // initializing static member

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; ++i) {
        cout << "Enter details of student "<< i+1 << ": " << endl;
        students[i].inputDetails();
    }

    // Find the student with the highest marks
    float maxMarks = students[0].getMarks();
    int maxIndex = 0;
    for (int i = 1; i <= numStudents; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    // Display details of the student with the highest marks
    students[maxIndex].displayDetails();

    return 0;
}