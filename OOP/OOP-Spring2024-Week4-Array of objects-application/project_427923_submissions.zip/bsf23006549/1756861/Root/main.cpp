/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students & display
the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student {
	private:
		string name;
		int id;
		float marks;
		float cgpa;
		int serialNum;
		static int objNo;
		static void highMarks(Student const *high) {
			cout<<"Student "<<high->serialNum<<" having ID "<<high->id<<" has achieved Highest Marks!!!"<<endl;
			cout<<high->name<<" have secured "<<high->marks<<" marks with "<<high->cgpa<<" CGPA :)"<<endl;
		}
	public:
		Student(string Name="NaN",int Id=-1,float Marks=-1,float Cgpa=-1.0) { //Deafault-Parametrized Constructor
			name=Name;
			id=Id;
			marks=Marks;
			cgpa=Cgpa;
			serialNum=objNo;
			objNo++;
		}
		void setData();// A Setter 
		void getData();// A Getter
		static void checkHigh(Student Stud[],int size);
};
void Student::setData() { //A setter
	cout<<"Enter Student Name: ";
	getline(cin,name);
	cout<<"Enter Student ID: ";
	cin>>id;
	cout<<"Enter "<<name<<"'s Marks: ";
	cin>>marks;
	cout<<"Enter "<<name<<"'s CGPA: ";
	cin>>cgpa;
	cin.ignore();
}
void Student::getData() { //To display details of all Students
	cout<<"Student"<<serialNum<<" Name is : "<<name<<endl;
	cout<<name<<"'s ID is : "<<id<<endl;
	cout<<name<<"'s Marks are : "<<marks<<endl;
	cout<<name<<"'s CGPA is : "<<cgpa<<endl;
}
void Student::checkHigh(Student Stud[],int size){
			int highMarks=-1;
			Student* ptr;
			for(int i=0;i<size; i++){
				if(Stud[i].marks>highMarks){
					highMarks=Stud[i].marks;
					ptr=&Stud[i];
				}
			}
			Student::highMarks(ptr);
		}
int Student::objNo=1;
int main() {
	int size=3;
	Student S[size];
	for(int i=0; i<size; i++) {
		S[i].setData();
	}
	Student::checkHigh(S,size);

}