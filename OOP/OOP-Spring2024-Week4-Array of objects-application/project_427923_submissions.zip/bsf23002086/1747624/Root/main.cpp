/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
#include <iomanip>
using namespace std;
class student{
	private:
		string name;
		int ID;
		int marks;
		float cgpa;
		int Sr;
		static int count;
	public:
		
	  void getdetails(){
	  	Sr=count;
	  	count++;
	  	cout << "Serial Number: " << Sr<<endl;
	  	cout<<" Enter the Student name: ";
	  	cin>>name;
	  	cout<<" Enter the Student ID: ";
	  	cin>>ID;
	  	cout<<" Enter the Student Marks: ";
	  	cin>>marks;
	  	cout<<" Enter the Student cgpa: ";
	  	cin>>cgpa;
	  	cout<<endl;
	  }	
	  
	 void display(){
	 	cout<<"   Details of students are: "<<endl;
	 	cout<<endl;
	 	cout<<" Student name is: "<<name<<endl;
	  	cout<<" Student ID is: "<<ID<<endl;
	  	cout<<" Student Marks is: "<<marks<<endl;
	  	cout<<" Student cgpa is: "<<cgpa<<endl;
	  	cout<<endl;
  } 
  int getmarks(){
  return marks;
}
	 
};

int student::count=1;

 int main(){
	int n=8;
	student s1[n];
	
	for(int i=0;i<8;i++){
		s1[i].getdetails();
		s1[i].display();
			
	}
	int highestmarks=0;
	for(int i=1;i<n;i++){
		if(s1[i].getmarks()>s1[highestmarks].getmarks()){
			highestmarks=i;
		}
	}
	cout<<" Details of the Student with highest marks: "<<endl;
	s1[highestmarks].display();
	
	return 0;
	
}