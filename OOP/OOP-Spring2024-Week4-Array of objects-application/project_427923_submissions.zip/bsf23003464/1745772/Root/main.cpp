/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string>
using namespace std;
class student{
	public:
    int marks;
    string id;
    string name;
    static int count;
   float cgpa;
   
    void getdetails(){
        cout<<"Enter the name of student:";
        cin>>name;
         cout<<"Enter the id of student:";
        cin>>id;
         cout<<"Enter the marks of student:";
        cin>>marks;
         cout<<"Enter the Cgpa of student:";
        cin>>cgpa;

    }
    
     student(){
        count++;
    }
};
int student::count = 0;
 int main(){
    float Cgpa=0;
	string Name,Id;
	int Marks;
    student obj[8];
    for(int i=0;i<=7;i++)
    {
        obj[i].getdetails();
        if(Cgpa<=obj[i].cgpa)
        {
        	Name=obj[i].name;
        	Id=obj[i].id;
            Cgpa=obj[i].cgpa;
            Marks=obj[i].marks;
            
        }
    }
 cout<<"The student who got the highest gpa is: "<<Name<<endl;
 cout<<"His Cgpa is: "<<Cgpa<<endl;
  cout<<"His Id  is: "<<Id<<endl;
   cout<<"His Marks are: "<<Marks<<endl;
   cout<<"Total number of Students are: "<<student::count;
}

