/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
#include<string>
using namespace std;
class Student
{ 
private:
	string Name;
	int Id;
	int marks;
	float cgpa;
	int serial;
public:
	static int count;
	Student(){
	}
	void setDetails(){
		cout<<"Enter name :";
		cin>>Name;
		cout<<"Enter Id :";
		cin>>Id;
		cout<<"Enter marks :";
		cin>>marks;
		cout<<"Enter cgpa :";
		cin>>cgpa;
		count++;
		serial = count;
		
	}
	int getMark()
	{
		return marks;
	}
	void getDetails()
	{
		cout<<"\t Name :"<<Name<<"\t Id :"<<Id<<"\t Marks :"<<marks<<"\t CGPA :"<<cgpa<<"\t Serial no :"<<serial;
	}
	static int getcount()
	{
		return count;
	}
};

int Student::count = 0;
int main()
{
   Student st[8];
	for(int i=0;i<8;i++)
	   st[i].setDetails();
int a=0;
    for(int i=0;i<8;i++)
    {
    	int b=0;
    	if(st[i].getMark() > b)
    	{ b = st[i].getMark();
    	  a = i;
		}
	}
   st[a].getDetails();
}