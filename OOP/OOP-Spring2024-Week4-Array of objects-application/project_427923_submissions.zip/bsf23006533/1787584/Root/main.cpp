#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

class Student {
private:
    int id;
    std::string name;
    int marks;
    float cgpa;
    static int count;

public:
    Student() : id(++count) {}
    void getDetails();
    void displayDetails();
    int getMarks() { return marks; }
};

int Student::count = 0;

void Student::getDetails() {
    cout << "Enter student name: ";
    cin.ignore();
    getline(std::cin, name);
    cout << "Enter marks: ";
    cin >> marks;
    cout << "Enter CGPA: ";
    cin >> cgpa;
}

void Student::displayDetails() {
    cout << "Student " << id << " details:\n";
    cout << "Name: " << name << "\n";
    cout << "Marks: " << marks << "\n";
    cout << "CGPA: " << cgpa << "\n";
}

int main() {
    Student students[8];
    int maxMarks = 0;
    int maxMarksIndex = -1;

    for (int i = 0; i < 2; i++) {
        students[i].getDetails();
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxMarksIndex = i;
        }
    }

    cout << "\nDetails of student who took highest marks:\n";
    students[maxMarksIndex].displayDetails();

    return 0;
}