/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int count; 
    int serialNumber;
    string name;
    int id;
    int marks;
    float CGPA;

public:
    Student() {
        serialNumber = ++count;
    }

    void getData() {
        cout << "Enter details for Student " << serialNumber << ":\n";
        cout << "Name: ";
        cin >> name;
        cout << "ID: ";
        cin >> id;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> CGPA;
    }

    int getMarks() const {
        return marks;
    }

    void displayData() const {
        cout << "Details of Student " << serialNumber << ":\n";
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << CGPA << endl;
    }

    static int getCount() {
        return count;
    }
};

int Student::count = 0; 

int main() {
    const int size = 8;
    Student students[size];

    for (int i = 0; i < size; ++i) {
        students[i].getData();
    }

    int highestMarks = 0;
    int index = 0;
    for (int i = 0; i < size; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            index = i;
        }
    }

    cout << "\nStudent with the highest marks:\n";
    students[index].displayData();

    return 0;
}
