/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
private:
    static int serialNumberCounter; 
    std::string name;
    int id;
    double marks;
    double cgpa;
    int serialNumber;

public:
   
    Student(const std::string& studentName, int studentId, double studentMarks, double studentCgpa)
        : name(studentName), id(studentId), marks(studentMarks), cgpa(studentCgpa) {
        serialNumber = ++serialNumberCounter;
    }

    
    void displayDetails() const {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << std::endl;
    }

    double getMarks() const {
        return marks;
    }
};


int Student::serialNumberCounter = 0;

int main() {
    
    Student students[8] = {
        {"Ali", 101, 85.5, 3.7},
        {"Bobar", 102, 92.0, 3.9},
        {"Fahid", 103, 78.5, 3.5},
        {"Dilawer", 104, 88.0, 3.8},
        {"alia", 105, 95.5, 4.0},
        {"Fahid baig", 106, 81.0, 3.6},
        {"Anas", 107, 89.5, 3.8},
        {"Hammad", 108, 93.5, 3.9}
    };

    
    double highestMarks = students[0].getMarks();
    int highestMarksIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }


    std::cout << "Student with highest marks:" << std::endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}