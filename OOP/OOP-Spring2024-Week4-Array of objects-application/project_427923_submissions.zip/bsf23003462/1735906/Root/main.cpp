/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/#include<iostream>
#include<string>
using namespace std;
class student
{ public:
    string name;
    string id;
    int marks;
    float cgpa;
   
    void get(){
        cout<<"Enter The Name:";
        cin>>name;
        cout<<"Enter ID:";
        cin>>id;
        cout<<"Enter Marks:";
        cin>>marks;
        cout<<"Enter CGPA:";
        cin>>cgpa;
    }
    void Display()
{
    cout<<"Name of Student is:"<<name<<endl;
    cout<<"ID of Student is:"<<id<<endl;
    cout<<"Marks of Student is:"<<marks<<endl;
    cout<<"CGPA of Student is:"<<cgpa<<endl;
    
}

    


};
int main()
{ int ser=0,highest=0,x;
    student stu[8];
    for(int i=0;i<=7;i++)
    {
        stu[i].get();
         stu[i].Display();
         if(stu[i].marks>highest)
         {
             x=stu[i].marks;
         }
         cout<<"Highest Marks of the student is :"<<x<<endl;
         cout<<"Serial Number is :"<<i+1<<endl;;
        
    }
    
}