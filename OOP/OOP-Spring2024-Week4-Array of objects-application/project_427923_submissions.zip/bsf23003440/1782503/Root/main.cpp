/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class student
{
	public:
		string name;
		int marks;
		string id;
		float cgpa;
			static int objectcount;
			student(){
				objectcount++;
			}			
			
		void getdata()
		{
			cout<<"enter name:"<<endl;
			cin>>name;
			cout<<"enter marks"<<endl;
			cin>>marks;
			cout<<"enter student id"<<endl;
			cin>>id;
			cout<<"enter your  cgpa:"<<endl;
			cin>>cgpa;
		
		}
		/*if(marks[i]>=1000){
		
		cout<<"deatils of higher marks:"<<endl;
	//	st[i].putdata();}
	}*/
		void putdata(){
		//	for( i=0;i<3;i++){
			
				if(marks>=1000){
		
		cout<<"deatils of higher marks:"<<endl;
		cout<<"name"<<name<<"marks"<<marks
<<"id"<<id<<"cgpa"<<cgpa<<endl;
}
		
}
		
	};
	int student::objectcount=0;
		int main()
		{
			//float marks;
			student st[3];
			for(int i=0;i<3;i++)
			{
				cout<<i+1<<"student :"<<endl;
				st[i].getdata();
				st[i].putdata();

}
return 0;
}