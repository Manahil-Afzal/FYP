/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;
//Program Working fine on DEV having issues on Codeboard IDE.
class student{
	private:
		string name; 
		int id; 
		int marks;
		float cgpa;
		int roll;
	public:
		static int count;
		void setter(){
			string n;
			int i,m;
			float c;
			cout<<"Please enter the name: "<<endl;
			cin.clear();
			cin.sync();
			getline(cin,n);
			cout<<"Please enter the Id: "<<endl;
			cin>>i;
			cout<<"Please enter the marks: "<<endl;
			cin>>m;
			cout<<"Please enter the CGPA: "<<endl;
			cin>>c;
			count++;
			name=n;
			id=i;
			marks=m;
		    cgpa=c;
		    roll=count;
		}
		int gettermarks(){
			return marks;
		}
		void display(){
			cout<<"Student Name: "<<name<<endl;
			cout<<"Student Id: "<<id<<endl;
			cout<<"Student Marks: "<<marks<<endl;
			cout<<"Student CGPA: "<<cgpa<<endl;
			cout<<"Student Serial Number: "<<roll<<endl;
		}
	
};
	student highest(student st[8]){
		student best;
			for(int i=0;i<8;++i){
				if(st[i+1].gettermarks()>st[i].gettermarks()){
					best=st[i+1];
				}
			}
		return best;}
int student::count=0;
int main(){
	student st[8];
	for(int i=0;i<8;++i){
		cout<<"Please enter the details of "<<i+1<<" Student: "<<endl;
		st[i].setter();
	}
	for(int i=0;i<8;++i){
		cout<<"The details of the "<<i+1<<" Student: "<<endl;
		st[i].display();
	}
	cout<<"The details of the student with the Highest marks are: "<<endl;
	highest(st).display();
	
	
	return 0;
}