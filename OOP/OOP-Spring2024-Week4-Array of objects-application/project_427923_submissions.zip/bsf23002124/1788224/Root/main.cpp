#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    static int count;
    string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber; 

public:
    Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
        serialNumber = ++count;
    }

    void display() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    int getMarks() const {
        return marks;
    }

    int getSerialNumber() const {
        return serialNumber;
    }
};

int Student::count = 0;

int main() {

    Student students[8] = {
        Student("Anas", 101, 85, 3.5),
        Student("Gulfam", 102, 90, 3.7),
        Student("Ahmad Tariq", 103, 95, 3.9),
        Student("Ahmad Izhar", 104, 88, 3.6),
        Student("Haris", 105, 92, 3.8),
        Student("Farhan", 106, 86, 3.5),
        Student("Muujahid", 107, 91, 3.7),
        Student("Junaid", 108, 94, 3.9)
    };

    
    int highestMarks = 0;
    int highestMarksIndex = 0;
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

   
    cout << "Details of the student with the highest marks:" << endl;
    students[highestMarksIndex].display();

    return 0;
}
