
#include<iostream>
using namespace std;
class student{
	private:
		string name;
		string id;
		double marks;
		double CGPA;
		public:
			void putdetails(){
				cout<<"Enter the name: ";
				cin>>name;
				cout<<"Enter the id: ";
				cin>>id;
				cout<<"Enter the marks: ";
				cin>>marks;
				cout<<"Enter the cgpa: ";
				cin>>CGPA;
			}
			void getdetails(){
				cout<<"Name: "<<name<<endl;
				cout<<"ID: "<<id<<endl;
				cout<<"Marks: "<<marks<<endl;
				cout<<"CGPA: "<<CGPA<<endl;	
						}
		
};
int main(){
	student std[3];
   for(int i=0;i<3;i++){
   	std[i].putdetails();
   }
   cout<<endl;
for(int i=0;i<3;i++){
   	std[i].getdetails();
   	cout<<"This student has serial number "<<i+1<<endl;
   }
   return 0;
}


