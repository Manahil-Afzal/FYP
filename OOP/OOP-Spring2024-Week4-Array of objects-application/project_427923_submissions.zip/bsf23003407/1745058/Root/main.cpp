/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int count; // to keep track of the number of students created
public:
    Student(string n, int i, float m, float c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        count++;
    }

    void displayDetails() {
        cout << "Serial Number: " << count << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    static int getCount() {
        return count;
    }

    static void displayHighestMarksStudent(Student students[], int size) {
        float maxMarks = students[0].marks;
        int maxIndex = 0;
        for (int i = 1; i < size; ++i) {
            if (students[i].marks > maxMarks) {
                maxMarks = students[i].marks;
                maxIndex = i;
            }
        }
        cout << "Details of the student with highest marks:" << endl;
        students[maxIndex].displayDetails();
    }
};

int Student::count = 0;

int main() {
    Student students[8] = {
        Student("John", 101, 85.5, 3.8),
        Student("Alice", 102, 90.0, 3.9),
        Student("Bob", 103, 75.0, 3.5),
        Student("Eve", 104, 95.0, 4.0),
        Student("Mike", 105, 80.0, 3.7),
        Student("Lucy", 106, 88.0, 3.9),
        Student("Sam", 107, 82.0, 3.6),
        Student("Emily", 108, 87.5, 3.8)
    };

    cout << "Details of all students:" << endl;
    for (int i = 0; i < Student::getCount(); ++i) {
        students[i].displayDetails();
        cout << endl;
    }

    Student::displayHighestMarksStudent(students, 8);

    return 0;
}