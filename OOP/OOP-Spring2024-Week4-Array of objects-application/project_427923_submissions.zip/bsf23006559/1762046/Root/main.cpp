/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;
class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int count; // To keep track of the number of students created
public:
    Student(string name1, int id1, int marks1, float cgpa1){
    	name=name1;
    	id=id1;
    	marks=marks1;
    	cgpa=cgpa1;
        count++; // Increment count when a new student object is created
    }

    void displayDetails() {
        cout << "Student #" << count << " Details:" <<endl;
        cout << "Name: " << name <<endl;
        cout << "ID: " << id <<endl;
        cout << "Marks: " << marks <<endl;
        cout << "CGPA: " << cgpa <<endl;
    }
    int getMarks(){
        return marks;
    }
};

int Student::count = 0;

int main() {
    
    Student students[8]={
        Student("ASAD", 101, 85, 3.7),
        Student("ZAIN", 102, 90, 3.9),
        Student("SHERRY", 103, 78, 3.5),
        Student("UBAID", 104, 95, 4.0),
        Student("DANi", 105, 88, 3.8),
        Student("EHTI", 106, 82, 3.6),
        Student("ABDULLAH", 107, 92, 3.9),
        Student("MUHAMMAD", 108, 79, 3.4)
};

    int maxMarks = 1;
    int maxIndex = 1;
    for (int i = 0; i < 8; i++) {
        students[i].displayDetails();
        cout <<endl;
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    cout << "Student with the highest marks:" <<endl;
    students[maxIndex].displayDetails();

    return 0;
}