/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber; // Serial number based on order of creation

public:
    static int count; // Static member to keep track of number of student objects created

    // Constructor to initialize student details
    Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
        count++;
        serialNumber = count;
    }

    // Method to display student details
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Static method to find the student with highest marks among all students
    static Student findStudentWithHighestMarks(Student students[], int size) {
        Student highest = students[0];
        for (int i = 1; i < size; ++i) {
            if (students[i].marks > highest.marks) {
                highest = students[i];
            }
        }
        return highest;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents] = {
        {"John", 101, 85, 3.8},
        {"Alice", 102, 78, 3.5},
        {"Bob", 103, 92, 3.9},
        {"Emily", 104, 88, 3.7},
        {"Michael", 105, 95, 4.0},
        {"Sophia", 106, 80, 3.6},
        {"David", 107, 75, 3.3},
        {"Emma", 108, 90, 3.8}
    };

    // Display details of all students
    for (int i = 0; i < numStudents; ++i) {
        cout << "Details of Student " << i + 1 << ":" << endl;
        students[i].displayDetails();
        cout << endl;
    }

    // Find student with highest marks
    Student highestMarksStudent = Student::findStudentWithHighestMarks(students, numStudents);
    cout << "Student with highest marks:" << endl;
    highestMarksStudent.displayDetails();

    return 0;
}
