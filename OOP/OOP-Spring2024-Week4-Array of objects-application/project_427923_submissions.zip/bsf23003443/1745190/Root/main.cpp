/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int count; // Static member to keep track of the number of students
    int serialNumber; // Serial number of the student

public:
    // Parameterized constructor
    Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
        serialNumber = ++count;
    }

    // Method to display student details
    void display() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Static method to get count of students
    static int getCount() {
        return count;
    }

    // Method to get marks of the student
    int getMarks() const {
        return marks;
    }
};

int Student::count = 0; // Initialize static member count

int main() {
    // Array to store 8 students
    Student students[8] = {
        {"Student1", 101, 85, 3.5},
        {"Student2", 102, 90, 3.7},
        {"Student3", 103, 75, 3.2},
        {"Student4", 104, 95, 3.9},
        {"Student5", 105, 80, 3.4},
        {"Student6", 106, 88, 3.6},
        {"Student7", 107, 92, 3.8},
        {"Student8", 108, 82, 3.3}
    };

    // Find student with highest marks
    int maxMarks = -1;
    int maxIndex = -1;
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    // Display details of student with highest marks
    cout << "Details of student with highest marks:" << endl;
    students[maxIndex].display();

    return 0;
}
