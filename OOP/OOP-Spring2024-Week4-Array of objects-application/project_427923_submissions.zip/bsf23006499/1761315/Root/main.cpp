/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;
class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int count; 
public:
    Student() {
    count++;
    id = count;
    }
    void setDetails() {
    cout << "Enter the name of student ";
    cin >> name;
    cout << "Enter the marks of student ";
    cin >> marks;
    cout << "Enter the CGPA of student ";
    cin >> cgpa;
    }
    void displayDetails() {
    cout << "Student ID: " << id <<endl;
    cout << "Name: " << name << endl;
    cout << "Marks: " << marks <<endl;
    cout << "CGPA: " << cgpa <<endl;
    }
    int getMarks() const {
    return marks;
    }
    static int getCount() {
    return count;
    }
};
int Student::count = 0;
int main() {
    const int numStudents = 8;
    Student students[numStudents];
    for (int i = 0; i < numStudents; ++i) 
	{
    cout << "Enter details for student " << i+1 << ":" <<endl;
    students[i].setDetails();
    }
    int maxMarks = students[0].getMarks();
    int maxIndex = 0;
    for (int i = 1; i <numStudents; ++i)
	{
    if (students[i].getMarks()>maxMarks) 
	{
    maxMarks=students[i].getMarks();
    maxIndex=i;
    }
  }
    cout << "\nDetails of student with highest marks:" <<endl;
    students[maxIndex].displayDetails();
}