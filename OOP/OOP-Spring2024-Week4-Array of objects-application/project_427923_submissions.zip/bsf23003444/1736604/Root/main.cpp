/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. 
Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student 
{
private:
    string student_name;
    int id;
    int marks;
    float cgpa;
    static int objectCount;

public:
    Student(string name = "", int student_id = 0, int student_marks = 0, float student_cgpa = 0.0) {
        student_name = name;
        id = student_id;
        marks = student_marks;
        cgpa = student_cgpa;
        objectCount++;
    }
    void getData()
    {
        cout << "Enter student name: ";
        cin >> student_name;
        cout << "Enter student id: ";
        cin >> id;
        cout << "Enter student marks: ";
        cin >> marks;
        cout << "Enter student CGPA: ";
        cin >> cgpa;
    }
    void displayData()
    {
        cout << "Student Name: " << student_name << endl;
        cout << "Student ID: " << id << endl;
        cout << "Student Marks: " << marks << endl;
        cout << "Student CGPA: " << cgpa << endl;
    }
    int getMarks() 
    {
        return marks;
    }
    static int getObjectCount()
    {
        return objectCount;
    }
};
int Student::objectCount = 1;
int main() {
    Student students[8];
    for (int i = 0; i <8; i++)
    { 
        cout << "Enter details for student " << i << ":" << endl;
        students[i].getData();
    }
    cout << "\nDetails of all students:" << endl;
    for (int i = 0; i < 8; i++)
    {
        cout << "\nStudent " << i + 1 << ":\n";
        students[i].displayData();
    }
    int maxMarksIndex = 0;
    int maxMarks = students[0].getMarks();
    for (int i = 1; i < 8; i++) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxMarksIndex = i;
        }
    }
    cout << "\nStudent with the highest marks:" << endl;
    students[maxMarksIndex].displayData();

    return 0;
}