#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber;

public:
    // Constructor to initialize Student details
    Student(string name, int id, int marks, float cgpa, int serialNumber)
        : name(name), id(id), marks(marks), cgpa(cgpa), serialNumber(serialNumber) {}

    // Method to display Student details
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
// Getter method for marks
    int getMarks() {
        return marks;
    }
};

int main() {
    // Create an array of objects of 8 students
    Student students[8] = {
        Student("John", 101, 85, 3.5, 1),
        Student("Emma", 102, 78, 3.2, 2),
        Student("Michael", 103, 92, 3.8, 3),
        Student("Sophia", 104, 88, 3.6, 4),
        Student("William", 105, 95, 3.9, 5),
        Student("Olivia", 106, 80, 3.3, 6),
        Student("James", 107, 91, 3.7, 7),
        Student("Amelia", 108, 89, 3.6, 8)
    };
    // Find student with the highest marks
    int highestMarksIndex = 0;
    int highestMarks = students[0].getMarks();
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Display details of student with the highest marks
    cout << "Details of student with the highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}

