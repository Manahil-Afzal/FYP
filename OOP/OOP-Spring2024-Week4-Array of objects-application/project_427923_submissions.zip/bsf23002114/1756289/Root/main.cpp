/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int count; // static member to keep track of the number of student objects
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student() {
        serialNumber = ++count; // Assigning serial number based on object creation order
    }

    void setData() {
        cout << "Enter Student Name: ";
        cin >> name;
        cout << "Enter Student ID: ";
        cin >> id;
        cout << "Enter Student Marks: ";
        cin >> marks;
        cout << "Enter Student CGPA: ";
        cin >> cgpa;
    }

    void displayData() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input student details
    for (int i = 0; i < numStudents; ++i) {
        cout << "\nEnter details of Student " << i + 1 << endl;
        students[i].setData();
    }

    // Find student with highest marks
    int highestMarks = students[0].getMarks();
    int indexHighestMarks = 0;
    for (int i = 1; i < numStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            indexHighestMarks = i;
        }
    }

    // Display details of student with highest marks
    cout << "\nDetails of Student with Highest Marks:" << endl;
    students[indexHighestMarks].displayData();

    return 0;
}
