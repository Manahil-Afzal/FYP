/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
#include <string>
using namespace std;
class Student {
private:
    static int count; 
    int serialNumber; 
    string name;
    int id;
    int marks;
    double cgpa;

public:
    Student(const string& name = "", int id = 0, int marks = 0, double cgpa = 0.0)
        : name(name), id(id), marks(marks), cgpa(cgpa) {
        count++; 
        serialNumber = count;
    }

    void inputDetails() {
       cout << "Enter student name: ";
        getline(std::cin >> std::ws, name); 

        cout << "Enter student ID: ";
        cin >> id;

        cout << "Enter student marks: ";
        cin >> marks;

        cout << "Enter student CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id <<endl;
       cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0; 

int main() {
    Student students[8]; 

    for (int i = 0; i < 8; ++i) {
        cout << "\nEnter details for student " << i + 1 << ":\n";
        students[i].inputDetails();
    }

    int maxMarks = students[0].getMarks();
    int maxIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    cout << "\nDetails of the student with highest marks:\n";
    students[maxIndex].displayDetails();

    return 0;
}
