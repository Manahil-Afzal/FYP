/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
#include <string>

class Student {
private:
    static int count; 
    int serialNumber; 
    std::string name;
    int id;
    int marks;
    double cgpa;

public:

    Student(const std::string& name = "", int id = 0, int marks = 0, double cgpa = 0.0)
        : name(name), id(id), marks(marks), cgpa(cgpa) {
        count++; 
        serialNumber = count; 
    }

    void inputDetails() {
        std::cout << "Enter student name: ";
        std::getline(std::cin >> std::ws, name); 

        std::cout << "Enter student ID: ";
        std::cin >> id;

        std::cout << "Enter student marks: ";
        std::cin >> marks;

        std::cout << "Enter student CGPA: ";
        std::cin >> cgpa;
    }

    void displayDetails() const {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
        std::cout << std::endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0; 

int main() {
    Student students[8]; 

    for (int i = 0; i < 8; ++i) {
        std::cout << "\nEnter details for student " << i + 1 << ":\n";
        students[i].inputDetails();
    }

    int maxMarks = students[0].getMarks();
    int maxIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > maxMarks) {
            maxMarks = students[i].getMarks();
            maxIndex = i;
        }
    }

    std::cout << "\nDetails of the student with highest marks:\n";
    students[maxIndex].displayDetails();

    return 0;
}
