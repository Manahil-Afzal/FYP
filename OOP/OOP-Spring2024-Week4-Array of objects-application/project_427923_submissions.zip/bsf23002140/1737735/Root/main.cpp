/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Employee
{
    int Id;
    char Name[25];  // Corrected the member variable name from 'name' to 'Name'
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin.ignore(); // To consume the newline character left in the buffer
        cin.getline(Name, 25);

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData()
    {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() // Corrected return type of main to int
{
    Employee E[5];

    for (int i = 0; i < 5; i++) // Corrected loop condition and added 'int' before 'i'
    {
        cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData();
    }

    cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) // Corrected loop condition and added 'int' before 'i'
        E[i].PutData();

    return 0; // Added return statement
}
