/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/#include <iostream>
using namespace std;

class Student {
public:
    string name;
    int ID;
    int marks;
    float CGPA;

    void inputDetails() {
        cout << "Enter student name: ";
        cin >> name;
        cout << "Enter student ID: ";
        cin >> ID;
        cout << "Enter student marks: ";
        cin >> marks;
        cout << "Enter student CGPA: ";
        cin >> CGPA;
    }

    void displayDetails() {
        cout << "Name: " << name << endl;
        cout << "ID: " << ID << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << CGPA << endl;
    }
};

int main() {
    Student students[8];

    for (int i = 0; i < 8; i++) {
        cout << "Enter details for student " << i + 1 << ":" << endl;
        students[i].inputDetails();
        cout << endl;
    }

    int highestMarks = 0;
    int highestMarksIndex = 0;

    for (int i = 0; i < 8; i++) {
        if (students[i].marks > highestMarks) {
            highestMarks = students[i].marks;
            highestMarksIndex = i;
        }
    }

    cout << "Student with the highest marks:" << endl;
    cout << "Serial Number: " << highestMarksIndex + 1 << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}