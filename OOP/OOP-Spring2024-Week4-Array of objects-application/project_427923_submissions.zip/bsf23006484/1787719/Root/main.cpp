/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;
class student{
    private:
    string student_name,student_id;
    int student_marks;
    float student_CGPA;
    public:
   
    void getdata()
    {
        cout<<"Enter Student Name:";
        cin>>student_name;
        cout<<"Enter Student ID:";
        cin>>student_id;
        cout<<"Enter Student Marks:";
        cin>>student_marks;
        cout<<"Enter Student CGPA:";
        cin>>student_CGPA;
    }
    int getmarks()
    {
        return student_marks;
    }
    void display()
    {   
        cout<<"Student Name:"<<student_name<<endl;
        cout<<"Student ID:"<<student_id<<endl;
        cout<<"Student Marks:"<<student_marks<<endl;
        cout<<"Student CGPA:"<<student_CGPA<<endl;
    }
};
int main()
{   student s;
    student array[8];
    for (int i = 0; i <8; i++)
    {   cout<<"Student No.:"<<i+1<<endl;
        array[i].getdata();
    }
    for (int i = 0; i <8; i++)
    {
        array[i].display();
    }
    int highestmarksno=0;
    float highestmarks=array[0].getmarks();
    for (int  i = 0; i < 8; i++)
    {
        if (array[i].getmarks()>highestmarks)
        {
            highestmarks=array[i].getmarks();
            highestmarksno=i;
        }   
    }
    cout<<"Higehst marks of students:"<<endl;
    array[highestmarksno].display();
    return 0; 
    
}
