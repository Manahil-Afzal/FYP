/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;
class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int count;

public:
    Student(string n, int i, int m, float c) {
	 name=n; id=i; marks=m; cgpa=c ;
        count++;
    }

    void display() {
        cout << "Serial Number: " << count << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    static int getCount() {
        return count;
    }

    int getMarks(){
      return marks;
    }
};

int Student::count;
int main() {
    Student stds[8] = {
        Student("Roha", 1001, 92, 3.9),
        Student("Arooba", 1002, 90, 3.9),
        Student("Tania", 1003, 88, 3.8),
        Student("Ali", 1004, 92, 4.0),
        Student("Fasiha", 1005, 82, 3.5),
        Student("Mahnoor", 1006, 87, 3.7),
        Student("Rohan", 1007, 95, 4.0),
        Student("Ahmed", 1008, 89, 3.9)
    };
    int maxMarks = 0;
    for (int i = 1; i < 8; ++i) {
        if (stds[i].getMarks() > stds[maxMarks].getMarks()) {
            maxMarks = i;
        }
    }
    cout << "Details of student with highest marks among the 8 students:" <<endl;
    stds[maxMarks].display();
    return 0;
}
