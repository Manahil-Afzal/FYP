/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int count; // To keep track of the number of students created
public:
    Student() {
        count++; // Increment count each time a student object is created
        id = count;
    }

    void inputDetails() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter CGPA: ";
        cin >> cgpa;
    }

    void displayDetails() {
        cout << "ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    float getMarks() {
        return marks;
    }

    static int getCount() {
        return count;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; i++) {
        cout << "Enter details for student " << i+1 << ":" << endl;
        students[i].inputDetails();
    }

    // Find student with highest marks
    int highestIndex = 0;
    float highestMarks = students[0].getMarks();
    for (int i = 1; i < numStudents; i++) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestIndex = i;
        }
    }

    // Display details of student with highest marks
    cout << "\nDetails of student with highest marks:" << endl;
    students[highestIndex].displayDetails();

    return 0;
}
