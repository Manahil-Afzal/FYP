/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include<iostream>
using namespace std;
class Student 
{
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int serialNumber; 
public:
    Student() 
    {
    serialNumber++; 
    }
    void inputDetails() 
   {
        cout << "Enter student name: ";
        cin >> name;
        cout << "Enter student ID: ";
        cin >> id;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter CGPA: ";
        cin >> cgpa;
    }
void displayDetails() const 
   {
        cout << "Serial Number: " << serialNumber <<endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }
float getMarks() const 
    {
        return marks;
    }
static int getSerialNumber() 
   {
        return serialNumber;
    }
};
int Student::serialNumber = 0;
int main() 
{
    const int numStudents = 8;
    Student students[numStudents];
    float maxMarks = -1;
    int maxMarksIndex = -1;
    for (int i = 0; i < numStudents; ++i) 
    {
       cout << "Enter details for student " << i + 1 << endl;
        students[i].inputDetails();
        if (students[i].getMarks() > maxMarks) 
        {
            maxMarks = students[i].getMarks();
            maxMarksIndex = i;
        }
    }
    if (maxMarksIndex != -1) 
    {
      cout << "Details of student with highest marks:" <<endl;
        students[maxMarksIndex].displayDetails();
    }
    else 
    {
       cout << "No students entered!" <<endl;
    }
 return 0;
}