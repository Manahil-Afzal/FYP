#include<iostream>
using namespace std;
class student{
	private:
		string name;
		int serial_no;
		int id;
	
		int cgpa;
		public:
		int marks;
			void set_serial(int s1){
				serial_no=s1;
				}
				void set_data()
				{
					cout<<"enter name : ";
					cin>>name;
					cout<<"enter roll number : ";
					cin>>id;
					cout<<"enter marks : ";
					cin>>marks;
					cout<<"enter cgpa : ";
					cin>>cgpa;
				}
				void get_data()
				{
				 cout<<"name is : "<<name<<endl;
				 cout<<"roll number is : "<<id<<endl;
				 cout<<"serial number is : "<<serial_no<<endl;
				 cout<<" marks is : "<<marks<<endl;
				 cout<<"cgpa is : "<<cgpa<<endl;
				}
			
};
int main(){
	student objs[7];
	cout<<"ener the detail of 1st student";
	int marks=0;
	int max_marks=0;
	for(int i=0;i<7;i++)
	{
		cout<<"enter the detail of next student "<<endl;
		objs[i].set_data();
		objs[i].set_serial(i+1);
	}
		for(int i=0;i<6;i++)
	{
		 marks=objs[i].marks;
		  
		 
		if(marks>max_marks)
		
		{
			max_marks=marks;
		}
	}
	cout<<"student with highest marks"<<endl;
	
	
	for(int i=0;i<7;i++)
	{
		if(objs[i].marks==max_marks)
		{
			objs[i].get_data();
		}
	}
	
	
}/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/