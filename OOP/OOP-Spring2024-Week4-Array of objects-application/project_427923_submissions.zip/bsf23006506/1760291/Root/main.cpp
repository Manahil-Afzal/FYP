/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;
class student{
	private:
		string name;
		int id;
		float cgpa;
		int serialno;
		public:
			static int objectcount;
			int marks;
           student(){
           	serialno=objectcount++;
		   }
       int   getserialno(){
          	return serialno;
		  }

			void input(){
				cout<<"enter the name of student"<<endl;
				cin>>name;
				cout<<"enter the student id"<<endl;
				cin>>id;
				cout<<"enter the student marks"<<endl;
				cin>>marks;
				cout<<"enter the student cgpa"<<endl;
				cin>>cgpa;				
							
			}
		void display(){
			cout<<"the name is "<<name<<endl;
			cout<<"the id is "<<id<<endl;
			cout<<"the marks are "<<marks<<endl;
			cout<<"the gpa is "<<cgpa<<endl;
			cout<<"the serial no is "<<serialno+1<<endl;
		}
					
	};
int student::objectcount=0;

int main(){
	student s1[3];
	for(int i=0;i<3;i++){
		cout<<"student"<<i+1<<endl;
		s1[i].input();
	}

  int maxmarks=s1[0].marks;
  int index=0;
  for(int i=0;i<3;i++){
  	if(s1[i].marks>maxmarks){
  		maxmarks=s1[i].marks;
  		index=i;
	  }
	   }
	   cout<<"details of topper : "<<endl;
	   s1[index].display();
	  return 0;
}