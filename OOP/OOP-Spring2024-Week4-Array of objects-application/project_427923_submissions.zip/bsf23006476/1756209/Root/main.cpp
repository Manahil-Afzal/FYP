/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;

class Student
{
    static int count;
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student(string studentName, int studentId, int studentMarks, float studentCGPA)
    {
        serialNumber = ++count;
        name = studentName;
        id = studentId;
        marks = studentMarks;
        cgpa = studentCGPA;
    }

    void displayDetails()
    {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    int getMarks()
    {
        return marks;
    }
};

int Student::count = 0;

int main()
{
    Student students[8] = {
        Student("Zain", 301, 85, 3.5),
        Student("Ahmed", 302, 90, 3.7),
        Student("Ali", 303, 75, 3.2),
        Student("Umar", 304, 95, 3.9),
        Student("Bilal", 305, 88, 3.6),
        Student("Asif", 306, 82, 3.4),
        Student("Ibrahim", 307, 91, 3.8),
        Student("Shafiq", 308, 87, 3.6)};

    int highestMarksIndex = 0;

    for (int i = 1; i < 8; ++i)
    {
        if (students[i].getMarks() > students[highestMarksIndex].getMarks())
        {
            highestMarksIndex = i;
        }
    }

    cout << "Details of the student with highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}