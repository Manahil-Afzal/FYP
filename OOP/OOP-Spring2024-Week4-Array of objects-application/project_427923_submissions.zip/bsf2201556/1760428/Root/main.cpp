/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    static int count; 

public:
    Student(string n, int i, float m, float c) {
        name = n;
        id = i;
        marks = m;
        cgpa = c;
        count++;
    }
    
    void display() {
        cout << "Serial Number: " << count << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }


    float getMarks() {
        return marks;
    }


    static int getCount() {
        return count;
    }
};


int Student::count = 0;

int main() {
    const int NUM_STUDENTS = 5;
    Student students[NUM_STUDENTS] = {
        Student("Ali", 101, 85.5, 3.7),
        Student("Ahmed", 102, 78.3, 3.5),
        Student("Abdullah", 103, 92.0, 3.9),
        Student("Haider", 104, 88.7, 3.8),
        Student("Mubeen", 105, 79.2, 3.6),

    };

    float highestMarks = 0;
    int highestIndex = 0;


    for (int i = 0; i < NUM_STUDENTS; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestIndex = i;
        }
    }

    cout << "Details of the student with the highest marks:" << endl;
    students[highestIndex].display();

    return 0;
}