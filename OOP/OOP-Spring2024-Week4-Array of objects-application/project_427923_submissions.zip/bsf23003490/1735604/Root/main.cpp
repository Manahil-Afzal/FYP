/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
private:
    static int count; // To keep track of the number of students
    std::string name;
    int id;
    int marks;
    float cgpa;
    int serialNumber;

public:
    Student(std::string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {
        count++; // Increment count for each new student
        serialNumber = count; // Assign serial number based on count
    }

    void displayDetails() {
        std::cout << "Student Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }

    static int getCount() {
        return count;
    }

    static void resetCount() {
        count = 0; // Reset count for reuse
    }

    static Student findHighestMarks(Student students[], int size) {
        Student highest = students[0];
        for (int i = 1; i < size; ++i) {
            if (students[i].marks > highest.marks) {
                highest = students[i];
            }
        }
        return highest;
    }
};

int Student::count = 0; // Initializing static member count

int main() {
    Student students[8] = {
        Student("John", 101, 85, 3.5),
        Student("Emma", 102, 90, 3.8),
        Student("Michael", 103, 95, 4.0),
        Student("Sophia", 104, 88, 3.6),
        Student("William", 105, 92, 3.9),
        Student("Olivia", 106, 86, 3.6),
        Student("James", 107, 89, 3.7),
        Student("Amelia", 108, 91, 3.8)
    };

    // Display details of all students
    for (int i = 0; i < 8; ++i) {
        students[i].displayDetails();
        std::cout << std::endl;
    }

    // Find and display student with the highest marks
    Student highestMarksStudent = Student::findHighestMarks(students, 8);
    std::cout << "Student with the highest marks: " << std::endl;
    highestMarksStudent.displayDetails();

    return 0;
}
