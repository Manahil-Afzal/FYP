/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber;

public:
    // Constructor
    Student(string n, int i, float m, float c, int s) : name(n), id(i), marks(m), cgpa(c), serialNumber(s) {}

    // Function to display student details
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    // Function to get marks of student
    float getMarks() {
        return marks;
    }
};

int main() {
    // Creating an array of objects for 8 students
    Student students[8] = {
        {"John", 101, 85.5, 3.8, 1},
        {"Alice", 102, 78.2, 3.6, 2},
        {"Bob", 103, 92.0, 3.9, 3},
        {"Emma", 104, 89.7, 3.7, 4},
        {"Sam", 105, 80.4, 3.5, 5},
        {"Linda", 106, 95.5, 4.0, 6},
        {"David", 107, 88.9, 3.7, 7},
        {"Sophia", 108, 91.3, 3.8, 8}
    };

    float highestMarks = 0;
    int highestMarksIndex = 0;

    // Finding student with highest marks
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Displaying details of student with highest marks
    cout << "Details of student with highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
