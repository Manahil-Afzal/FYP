/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of
objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include <iostream>
using namespace std;
class Student{
    private:
    	int serial;
        string name;
        int id;
        int marks;
        float cgpa;
        static int count;
    public:
    	Student(){
    		count = count + 1;
    		serial = count;
		}
        void input(){
            cout << "Enter name: ";
            cin >> name;
            cout << "Enter id: ";
            cin >> id;
            cout << "Enter marks: ";
            cin >> marks;
            cout << "Enter cgpa: ";
            cin >> cgpa;
        }
        void show(){
			cout << "Serial : " << serial << endl;
            cout << "Name : " << name << endl;
            cout << "Id : " << id << endl;
            cout << "Marks : " << marks << endl;
            cout << "Cgpa : " << cgpa << endl;
			
        }
        int getMarks(){
            return marks;
        }
};

int Student::count = 0;
int main(){
    Student s[8];
    for(int i = 0; i < 8; i++){
        s[i].input();
    }
    
    for(int i = 0; i < 8; i++){
        int max = s[0].getMarks();
        if(max < s[i].getMarks()){
            max = s[i].getMarks();
            cout << endl << "Student With Highest Marks" << endl;
			cout << "------------------------" << endl;
            s[i].show();
        }
    }
}