
#include<iostream>
using namespace std;
class student {
	string name;
	int id;
	float marks;
	float cgpa;
	int serialNumber;
	public:
		student(string n,int i,float m,float c,int s):name(n),id(i),marks(m),cgpa(c),serialNumber(s){}
	void displayDetails(){
	cout<<"Serial number:"<<serialNumber<<endl;
	cout<<"Name:"<<name<<endl;
	cout << "ID: " << id << endl;
    cout << "Marks: " << marks << endl;
    cout << "CGPA: " << cgpa << endl;	
	 }
	 float getMarks(){
	 	return marks;
	 }
};
int main()
{
student students[8]={
	{"Ali", 101, 85.5, 3.7, 1},
        {"Ahmad", 102, 92.0, 3.9, 2},
        {"Ahsan", 103, 88.3, 3.8, 3},
        {"Emman", 104, 90.7, 3.6, 4},
        {"Muzamil", 105, 87.2, 3.5, 5},
        {"sufiyan", 106, 91.8, 4.0, 6},
        {"Dawood", 107, 89.5, 3.8, 7},
        {"Tayyab", 108, 86.9, 3.7, 8}
	};	
int highestMarksIndex=0;
for(int i=1;i<8;++i){
if (students[i].getMarks() > students[highestMarksIndex].getMarks()) {
            highestMarksIndex = i;
}
}
cout << "Details of the student with the highest marks:\n";
    students[highestMarksIndex].displayDetails();

    return 0;
}
