/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
    static int count; 
    int serialNumber; 
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student() {
        serialNumber = ++count; 
    }

    void getData() {
        cout << "\nEnter details for student " << serialNumber << ":\n";
        cout << "Name: ";
        cin >> name;
        cout << "ID: ";
        cin >> id;
        cout << "Marks: ";
        cin >> marks;
        cout << "CGPA: ";
        cin >> cgpa;
    }

    void displayData() {
        cout << "\nDetails of student " << serialNumber << ":\n";
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    const int numOfStudents = 8;
    Student students[numOfStudents];
    for (int i = 0; i < numOfStudents; ++i) {
        students[i].getData();
    }
    int highestMarksIndex = 0;
    int highestMarks = students[0].getMarks();
    for (int i = 1; i < numOfStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }
    cout << "\nDetails of student with highest marks:\n";
    students[highestMarksIndex].displayData();

    return 0;
}
