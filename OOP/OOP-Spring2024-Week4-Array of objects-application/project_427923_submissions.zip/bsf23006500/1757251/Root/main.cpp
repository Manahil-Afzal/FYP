/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/

#include<iostream>
using namespace std;

class Student {
private:
    string name;
    int id;
    double marks;
    double cgpa;
public:
    static int count;
    Student() {
        count++;
        id = count;
    }
    void getdata() {
        cout << "Enter name: ";
        cin >> name;
        cout << "Enter marks: ";
        cin >> marks;
        cout << "Enter cgpa: ";
        cin >> cgpa;
    }
    void showdata() {
        cout << "Name is: " << name << endl;
        cout << "ID is: " << id << endl;
        cout << "Marks is: " << marks << endl;
        cout << "CGPA is: " << cgpa << endl;
    }
    double getmarks() {
        return marks;
    }
};

int Student::count = 0;

int main() {
    Student array[8];
    for(int i = 0; i < 8; i++) {
        cout << "Enter detail of Student " << i + 1 << endl;
        array[i].getdata();
    }

    int highestmarksindex = 0;
    double highestmarks = array[0].getmarks();

    for(int i = 1; i < 8; i++) {
        if(array[i].getmarks() > highestmarks) {
            highestmarks = array[i].getmarks();
            highestmarksindex = i;
        }
    }

    cout << "Student with the highest marks:" << endl;
    array[highestmarksindex].showdata();

    return 0;
}