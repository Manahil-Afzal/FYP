/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
    static int count;
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student() {
        serialNumber = ++count;
    }

    void getData() {
        cout << "Enter student's name: ";
        cin >> name;
        cout << "Enter student's ID: ";
        cin >> id;
        cout << "Enter student's marks: ";
        cin >> marks;
        cout << "Enter student's CGPA: ";
        cin >> cgpa;
    }

    void displayData() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    Student students[8];
    int highestMarks = -1;
    int highestIndex = -1;

    for (int i = 0; i < 8; ++i) {
        cout << "\nEnter details of student " << i + 1 << ":" << endl;
        students[i].getData();
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestIndex = i;
        }
    }

    cout << "\nDetails of the student with the highest marks:" << endl;
    students[highestIndex].displayData();

    return 0;
}
