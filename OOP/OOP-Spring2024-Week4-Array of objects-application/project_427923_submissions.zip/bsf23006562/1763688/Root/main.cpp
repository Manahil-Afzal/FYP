/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;
    static int serialNumber;

public:
    Student() {
        serialNumber++; // Increment serial number for each student object created
    }

    void getInput() {
        cout << "Enter student's name: ";
        cin >> name;
        cout << "Enter student's ID: ";
        cin >> id;
        cout << "Enter student's marks: ";
        cin >> marks;
        cout << "Enter student's CGPA: ";
        cin >> cgpa;
    }

    void display() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::serialNumber = 0; // Initializing static member

int main() {
    const int numOfStudents = 8;
    Student students[numOfStudents];

    // Input details for each student
    for (int i = 0; i < numOfStudents; ++i) {
        cout << "Enter details for student " << i + 1 << endl;
        students[i].getInput();
    }

    // Find student with highest marks
    int highestMarks = 0;
    int indexHighestMarks = 0;
    for (int i = 0; i < numOfStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            indexHighestMarks = i;
        }
    }

    // Display details of student with highest marks
    cout << "\nDetails of student with highest marks:" << endl;
    students[indexHighestMarks].display();

    return 0;
}