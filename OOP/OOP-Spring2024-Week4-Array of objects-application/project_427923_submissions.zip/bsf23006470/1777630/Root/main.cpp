/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    float marks;
    float cgpa;
    int serialNumber; 
public:
    Student(string n, int i, float m, float c, int serial) : name(n), id(i), marks(m), cgpa(c), serialNumber(serial) {}

    void displayDetails() {
        cout << "Student Serial Number: " << serialNumber << endl;
        cout << "Name: " << name <<endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }
    float getMarks() const {
        return marks;
    }
};

int main() {
    Student students[8] = {
        {"Saad", 101, 85.5, 3.7, 1},
        {"Irham", 102, 79.2, 3.5, 2},
        {"Mudasir", 103, 92.0, 4.0, 3},
        {"Rizwan", 104, 88.3, 3.8, 4},
        {"BIlal", 105, 75.9, 3.2, 5},
        {"Ali", 106, 91.5, 3.9, 6},
        {"Ahmed", 107, 84.6, 3.6, 7},
        {"Asad", 108, 95.2, 4.0, 8}
    };
    float highestMarks = 0;
    int highestMarksIndex = 0;
    for (int i = 0; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }
	cout << "Details of student with the highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
