#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student(string n, int i, int m, float c) : name(n), id(i), marks(m), cgpa(c) {}

    void display() {
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int main() {
    Student students[8] = {
        Student("Ali", 1001, 85, 3.5),
        Student("Fatima", 1002, 75, 3.2),
        Student("Ahmed", 1003, 90, 3.8),
        Student("Aisha", 1004, 88, 3.6),
        Student("Hassan", 1005, 92, 4.0),
        Student("Zara", 1006, 82, 3.4),
        Student("Omar", 1007, 78, 3.0),
        Student("Sana", 1008, 94, 4.0)
    };

    int maxMarksIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > students[maxMarksIndex].getMarks()) {
            maxMarksIndex = i;
        }
    }

    cout << "Details of student with highest marks:" << endl;
    students[maxMarksIndex].display();

    return 0;
}
