/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    int marks;
    double cgpa;
    int serialNumber;

public:
    Student(string name, int id, int marks, double cgpa, int serialNumber)
        : name(name), id(id), marks(marks), cgpa(cgpa), serialNumber(serialNumber) {}

   
    void displayDetails() {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
    }

 
    int getMarks() const {
        return marks;
    }
};

int main() {
    const int numOfStudents = 8;

    Student students[numOfStudents] = {
        {"John", 101, 85, 3.5, 1},
        {"Alice", 102, 92, 3.8, 2},
        {"Bob", 103, 78, 3.2, 3},
        {"Emily", 104, 95, 3.9, 4},
        {"Michael", 105, 88, 3.6, 5},
        {"Sophia", 106, 90, 3.7, 6},
        {"David", 107, 85, 3.5, 7},
        {"Emma", 108, 89, 3.7, 8},
    };

    int highestMarks = students[0].getMarks();
    int highestMarksIndex = 0;
    for (int i = 1; i < numOfStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    cout << "Details of student with highest marks:" << endl;
    students[highestMarksIndex].displayDetails();

    return 0;
}
