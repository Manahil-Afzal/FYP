#include<iostream>
using namespace std;
class student{
	public:
		string name;
		int id;
		int marks;
		float CGPA;
		public:
		void inputdetails()
		{
			cout<<"enter student name="<<endl;
			cin>>name;
			cout<<"enter student id="<<endl;
			cin>>id;
			cout<<"enter student marks ="<<endl;
			cin>>marks;
			cout<<"enter student CGPA ="<<endl;
			cin>>CGPA;
			}
			void displaydetails()
			{
				cout<<"name="<<name<<endl;
				cout<<"id="<<id<<endl;	
				cout<<"marks="<<marks<<endl;
				cout<<"CGPA="<<CGPA<<endl;
				}	
};
int main(){
	student students[8];
	for(int i=0;i<8;++i)
	{
		cout<<"enter details for student="<<i+1<<endl;
		students[i].inputdetails();
		cout<<endl;
	}
	int highestmarks=0;
	int highestmarksindex=0;
	for(int i=0;i<8;++i)
	{
		if(students[i].marks>highestmarks)
		{
		
			highestmarks=students[i].marks;
			highestmarksindex=i; 
}
}
cout<<"student with highest marks="<<endl;
cout<<"serialno="<<highestmarksindex+1<<endl;
students[highestmarksindex].displaydetails();
return 0;
}