/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object*/
#include<iostream>
using namespace std;
class Student{
 private:
   static int count;
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;
    public:
	Student(string name, int id, int marks, float cgpa) : name(name), id(id), marks(marks), cgpa(cgpa){
        serialNumber = ++count;
        
    }
    void display()  {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id <<endl;
        cout << "Marks: " << marks <<endl;
        cout << "CGPA: " << cgpa <<endl;
    }

    int getMarks()  {
        return marks;
   }
      static  int getCount() {
        return count;
    }


};
int Student::count=0;

int main() {
    Student students[8] = {
        Student("ALi", 101, 85, 3.8),
        Student("Ahmad", 102, 90, 3.9),
        Student("Hassan", 103, 95, 4.0),
        Student("Husnain", 104, 88, 3.7),
        Student("Nawaz", 105, 92, 3.85),
        Student("Zaddi", 106, 87, 3.6),
        Student("Salman", 107, 94, 3.95),
        Student("Tayyab", 108, 91, 3.65)
    };

    int highestMarks = students[0].getMarks();
    int highestIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestIndex = i;
        }
    }
  cout << "Details of the student with the highest marks:\n";
    students[highestIndex].display();
    return 0;
}

