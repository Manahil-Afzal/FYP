/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
using namespace std;

class Student {
private:
    static int count;
    int serialNumber;
    string name;
    int id;
    int marks;
    double cgpa;

public:
    Student() {
        serialNumber = ++count;
    }

    void setDetails() {
        cout << "Enter student's name: ";
        cin >> name;
        cout << "Enter student's ID: ";
        cin >> id;
        cout << "Enter student's marks: ";
        cin >> marks;
        cout << "Enter student's CGPA: ";
        cin >> cgpa;
    }

    int getMarks() const {
        return marks;
    }

    void display() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << endl;
    }

    static int getCount() {
        return count;
    }
};

int Student::count = 0;

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; ++i) {
        cout << "Enter details for student " << i + 1 << ":" << endl;
        students[i].setDetails();
    }

    // Find the student with the highest marks
    int highestMarks = 0;
    int highestMarksIndex = 0;
    for (int i = 0; i < numStudents; ++i) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // Display details of the student with the highest marks
    cout << "Details of student with the highest marks:" << endl;
    students[highestMarksIndex].display();

    return 0;
}
