/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>

class Student {
private:
    static int count;
    int serialNumber;
    std::string name;
    int id;
    int marks;
    float cgpa;
public:
    Student(const std::string& name, int id, int marks, float cgpa) {
        this->name = name;
        this->id = id;
        this->marks = marks;
        this->cgpa = cgpa;
        this->serialNumber = ++count;
    }

    void displayDetails() {
        std::cout << "Serial Number: " << serialNumber << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "ID: " << id << std::endl;
        std::cout << "Marks: " << marks << std::endl;
        std::cout << "CGPA: " << cgpa << std::endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0;

int main() {
    Student students[8] = {
        Student("John", 101, 85, 3.5),
        Student("Alice", 102, 78, 3.2),
        Student("Bob", 103, 90, 3.9),
        Student("Emma", 104, 92, 3.8),
        Student("Mike", 105, 88, 3.6),
        Student("Sophia", 106, 95, 4.0),
        Student("David", 107, 82, 3.4),
        Student("Olivia", 108, 87, 3.7)
    };

    int maxMarksIndex = 0;
    for (int i = 1; i < 8; ++i) {
        if (students[i].getMarks() > students[maxMarksIndex].getMarks()) {
            maxMarksIndex = i;
        }
    }

    std::cout << "Details of student with highest marks:" << std::endl;
    students[maxMarksIndex].displayDetails();

    return 0;
}
