/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    static int serialNumberCounter;
    int serialNumber;
    string name;
    int id;
    int marks;
    double cgpa;

public:
    Student(string n, int i, int m, double c) : name(n), id(i), marks(m), cgpa(c) {
        serialNumber = ++serialNumberCounter;
    }

    void displayDetails() const {
        cout << "Serial Number: " << serialNumber << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "Marks: " << marks << endl;
        cout << "CGPA: " << cgpa << endl;
        cout << "------------------------" << endl;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::serialNumberCounter = 0;

int main() {
    Student students[8] = {
        Student("Ali", 101, 85, 3.7),
        Student("Fatima", 102, 92, 3.9),
        Student("Ahmed", 103, 78, 3.5),
        Student("Aisha", 104, 95, 4.0),
        Student("Imran", 105, 88, 3.8),
        Student("Sara", 106, 90, 3.9),
        Student("Kamran", 107, 79, 3.4),
        Student("Zainab", 108, 87, 3.7)
    };

    int highestMarks = -1;
    int index = -1;

    for (int i = 0; i < 8; ++i) {
        students[i].displayDetails();
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            index = i;
        }
    }

    cout << "Details of the student with the highest marks:" << endl;
    students[index].displayDetails();

    return 0;
}
