/*Write a C++ program that creates a class to take and display details of student. It takes input for student's name, id, marks, and CGPA. Create an array of objects of 8 students and display the details of student who took highest marks among the 8 students. 
Also assign a serial number to each student based on the order of creating the respective student object.*/
#include <iostream>
#include <string>
using namespace std;

class Student {
    static int count; 
    int serialNumber;
    string name;
    int id;
    int marks;
    float cgpa;

public:
    Student() {
        serialNumber = ++count; 
    }

    void getData() {
        cout << "\nEnter student's name: ";
        cin >> name;
        cout << "Enter student's ID: ";
        cin >> id;
        cout << "Enter student's marks: ";
        cin >> marks;
        cout << "Enter student's CGPA: ";
        cin >> cgpa;
    }

    void displayData() {
        cout << "\nSerial Number: " << serialNumber;
        cout << "\nName: " << name;
        cout << "\nID: " << id;
        cout << "\nMarks: " << marks;
        cout << "\nCGPA: " << cgpa;
    }

    int getMarks() const {
        return marks;
    }
};

int Student::count = 0; // Initializing static member variable

int main() {
    const int numStudents = 8;
    Student students[numStudents];

    // Input details for each student
    for (int i = 0; i < numStudents; i++) {
        cout << "\nEnter details of student " << i + 1 << ":\n";
        students[i].getData();
    }

    // student with the highest marks
    int highestMarks = students[0].getMarks();
    int highestMarksIndex = 0;
    for (int i = 1; i < numStudents; i++) {
        if (students[i].getMarks() > highestMarks) {
            highestMarks = students[i].getMarks();
            highestMarksIndex = i;
        }
    }

    // details of the student with the highest marks
    cout << "\nDetails of the student with the highest marks:\n";
    students[highestMarksIndex].displayData();

    return 0;
}