#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Postfix increment operator overload
    Time operator++(int) {
        Time temp(hr, min); // Create a copy of the current object
        hr++;
        min++;
        cout << "\nHours and Minutes " << hr << "'" << min;
        return temp; // Return the original value
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Postfix increment
    return 0;
}