//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }
    // Overloading the unary increment operator ++
    Time operator++(int) {
        Time temp(hr, min); // Create a temporary Time object to hold the original values
        ++hr;
        ++min;
        cout << "\n Hours and Minutes " << hr << "'" << min;
        return temp; // Return the original Time object
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Using the overloaded ++ operator
    return 0;
}
