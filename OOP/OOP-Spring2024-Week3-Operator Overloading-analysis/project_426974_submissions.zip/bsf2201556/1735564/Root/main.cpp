//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) : hr(h), min(m) {}

    
    Time operator++(int) {
        Time temp(hr, min);
        min++;
        if (min >= 60) {
            min %= 60;
            hr++;
            if (hr >= 24) {
                hr %= 24;
            }
        }
        return temp;
    }

    void display() const {
        cout << "Time: " << hr << ":" << min << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++;
    t1.display();
    return 0;
}
