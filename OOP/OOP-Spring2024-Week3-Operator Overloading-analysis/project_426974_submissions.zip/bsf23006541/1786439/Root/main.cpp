//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void operator++(int) { // Overloading post-increment operator
        hr++;
        min++;
        cout << "\nHours and Minutes: " << hr << "'" << min;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Using post-increment operator
    return 0;
}

