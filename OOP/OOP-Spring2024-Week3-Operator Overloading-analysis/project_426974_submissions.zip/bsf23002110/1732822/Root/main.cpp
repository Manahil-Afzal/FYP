#include <iostream>
using namespace std;

class Time {
private:
int hr, min;
public:
	Time(int h, int m)
	{
	hr = h;
	min = m;
	}
   int operator++(int h) 
	{
		hr++;
		min++;
cout << "\n Hours and Minutes " << hr << "'" << min; } };
int main()
{
	Time t1(4, 45);
	t1++;  
	return 0;
}
