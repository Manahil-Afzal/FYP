//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void display() const {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }

    // Overloading the postfix increment operator
    Time operator++(int) {
        Time temp = *this;
        hr++;
        min++;
        return temp;
    }
};

int main() {
    Time t1(4, 45);
    t1++;  // using postfix increment
    t1.display();  // displaying the result
    return 0;
}
