//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void display() const {
        cout << "Hours: " << hr << ", Minutes: " << min << endl;
    }

    Time operator++(int) {
        Time temp(*this);  // Create a temporary Time object as a copy
        hr++;
        min++;
        return temp;
    }
};

int main() {
    Time t1(4, 45);

    cout << "Before increment:" << endl;
    t1.display();

    t1++;  // Increment using post-increment operator

    cout << "After increment:" << endl;
    t1.display();

    return 0;
}
