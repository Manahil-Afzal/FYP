#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overloading the post-increment operator
    void operator++(int) {
        hr++;
        min++;

        cout << "\nHours and Minutes: " << hr << "h " << min << "m";
    }
};

int main() {
    Time t1(4, 45);
    t1++;

    return 0;
}