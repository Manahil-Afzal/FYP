//This program is meant to post-increment a time's object and display the results

#include<iostream>
using namespace std;
class Time{
    private:
	int hr,min;
	public:
		Time(int h,int m){
			hr=h;
			min=m;
		}
		Time operator ++(int h){
			hr++;
			min++;
			cout<<" \n hours and minutes="<<hr<<" : "<<min<<endl;	} };
int main(){
	Time t1(4, 45);
	t1++;
	return 0;
}