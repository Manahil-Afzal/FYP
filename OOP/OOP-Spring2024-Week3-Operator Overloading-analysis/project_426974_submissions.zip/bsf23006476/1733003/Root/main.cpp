#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }
    
    Time operator++(int) {
        Time temp(hr, min); 
        hr++;  
        min++; 
        return temp; 
    }
    
    void display() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++; 
    t1.display(); 
    return 0;
}
