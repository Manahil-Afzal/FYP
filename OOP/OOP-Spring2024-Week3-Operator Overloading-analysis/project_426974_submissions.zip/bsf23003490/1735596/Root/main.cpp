//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
public:
    Time(int h, int m) : hr(h), min(m) {}

    Time operator++() {
        ++hr;
        ++min;
        if (min >= 60) {
            min -= 60;
            ++hr;
        }
        cout << "\nHours and Minutes: " << hr << ":" << min;
        return *this;
    }

private:
    int hr;
    int min;
};

int main() {
    Time t1(4, 45);
    ++t1;
    return 0;
}