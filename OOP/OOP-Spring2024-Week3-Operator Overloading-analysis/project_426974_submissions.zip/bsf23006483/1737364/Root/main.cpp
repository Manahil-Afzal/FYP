#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    Time operator++(int) {
        Time temp = *this; // Save the current state of the object.
        ++hr;              // Increment hours.
        ++min;             // Increment minutes.
        return temp;       // Return the saved state.0
    }

    void display() {
    //Updated the display function to print hours and minutes correctly.
        cout << "Hours and Minutes: " << hr << "'" << min << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++;          // Using the post-increment operator to increment time
    t1.display();  // Display the time
    return 0;
}
