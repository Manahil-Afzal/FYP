//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;
  public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }
    
    // Overloading the postfix increment operator ++
    Time operator++(int) {
        Time temp = *this; // Create a temporary Time object with the current values
        hr++; // Increment hours
        min++; // Increment minutes
        return temp; // Return the original value before increment
    }

    // Overloading the insertion operator <<
    friend ostream& operator<<(ostream& os, const Time& t) {
        os << "Time: " << t.hr << " hours " << t.min << " minutes";
        return os;
    }
};

int main() {
    Time t1(4, 45);
    cout << "Original Time: " << t1 << endl;
    t1++; // Postfix increment
    cout << "After Postfix Increment: " << t1 << endl;
    return 0;
}

