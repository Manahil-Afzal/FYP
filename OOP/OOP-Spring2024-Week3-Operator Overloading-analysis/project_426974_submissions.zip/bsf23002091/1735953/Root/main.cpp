//This program is meant to post-increment a time's object and display the results
// #include <iostream>
// using namespace std;

// class Time {
// int hr, min;
// public:
// 	Time(int h, int m)
// 	{
// 	hr = h;
// 	min = m;
// 	}
//   int operator++(int) 
// 	{
// 		++hr;
// 		++min;
// cout << "\n Hours and Minutes " << he << "'" << min; } };
// int main()
// {
// 	Time t1(4, 45);
// 	t1++;  
// 	return 0;
// }

#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overloading the post-increment operator
    Time operator++(int) {
        Time temp = *this;  // Make a copy of the current object
        hr++;
        min++;
        return temp;  // Return the original value
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++;
    t1.display();  // Display the updated time
    return 0;
}
