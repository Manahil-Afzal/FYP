#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    // Constructor
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Post-increment operator overloading
    Time operator++(int) {
        Time temp = *this;  // save current state

        ++min;
        if (min >= 60) {
            min = 0;
            ++hr;
        }

        return temp;  // return original (before increment)
    }

    // Display function
    void display() {
        cout << "Time: " << hr << " hours and " << min << " minutes" << endl;
    }
};

int main() {
    Time t1(4, 59);

    cout << "Before post-increment: ";
    t1.display();

    Time t2 = t1++;  // post-increment

    cout << "Returned object (before increment): ";
    t2.display();

    cout << "After post-increment: ";
    t1.display();

    return 0;
}
