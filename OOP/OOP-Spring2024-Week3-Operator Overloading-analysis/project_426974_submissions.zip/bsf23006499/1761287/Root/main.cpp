//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;
class Time {
    int hr, min;
public:
    Time(int h, int m) {
    hr = h;
    min = m;
    }
    Time operator++(int t) {
    Time temp = *this; 
    hr++;
    min++; 
    cout << "\nHours and Minutes= " << hr << ":" << min; 
    return temp; 
    }
};
int main() {
    Time t1(6, 45);
    t1++; 
}