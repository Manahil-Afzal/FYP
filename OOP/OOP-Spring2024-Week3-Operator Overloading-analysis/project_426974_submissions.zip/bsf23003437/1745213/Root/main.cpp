#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    Time operator++() {
        ++min;
        if (min == 60) {
            min = 0;
            ++hr;
            if (hr == 24) {
                hr = 0;
            }
        }
        return *this;
    }

    void display() {
        cout << "Time: " << hr << " hours " << min << " minutes" << endl;
    }
};

int main() {
    Time t1(4, 45);
    ++t1;
    t1.display();
    return 0;
}
