//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr;
    int min;

public:
    Time(int h = 0, int m = 0) : hr(h), min(m) {
        if (min >= 60) {
            cerr << "Error: Minutes must be less than 60." << endl;
            
        }
    }

    Time(const Time& t) : hr(t.hr), min(t.min) {}

    Time& operator=(const Time& t) {
        if (this != &t) {
            hr = t.hr;
            min = t.min;
        }
        return *this;
    }

    Time operator++(int) {
        Time temp(*this);
        ++hr;
        ++min;
        if (min >= 60) {
            hr++;
            min -= 60;
        }
        return temp;
    }

    void display() {
        cout << hr << ":" << (min < 10 ? "0" : "") << min << " ";
    }
};

int main() {
    Time t1(4, 45);
    t1++;
    cout << "t1 = ";
    t1.display();

    return 0;
}