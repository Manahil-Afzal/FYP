#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overloading post-increment operator
    Time operator++(int) {
        Time temp(hr, min); // Create a temporary Time object with current values
        min++; // Increment minutes
        if (min >= 60) {
            min -= 60;
            hr++;
        }
        if (hr >= 24) {
            hr -= 24;
        }
        return temp; // Return the temporary object with the original values
    }

    // Display time
    void display() {
        cout << "Time: " << hr << ":" << min << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Using the post-increment operator
    t1.display(); // Display the time after incrementing
    return 0;
}