//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) : hr(h), min(m) {}

    // Overload post-increment operator
    Time operator++(int) {
        Time temp(*this); // Create a copy of the current object
        ++hr;             // Increment hours
        ++min;            // Increment minutes
        return temp;      // Return the original value before increment
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "'" << min << endl;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Post-increment

    t1.display();

    return 0;
}
