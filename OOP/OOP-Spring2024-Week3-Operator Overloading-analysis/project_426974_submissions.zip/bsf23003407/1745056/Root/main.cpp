//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) : hr(h), min(m) {}

    Time& operator++() {
        ++hr;
        ++min;
        cout << "\nHours and Minutes " << hr << "'" << min;
        return *this;
    }
};

int main() {
    Time t1(4, 45);
    ++t1; // Increment t1
    return 0;
}