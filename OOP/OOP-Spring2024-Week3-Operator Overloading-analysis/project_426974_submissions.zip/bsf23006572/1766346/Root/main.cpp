// //This program is meant to post-increment a time's object and display the results
// #include <iostream>
// using namespace std;

// class Time {
// int hr, min;
// public:
// 	Time(int h, int m)
// 	{
// 	hr = h;
// 	min = m;
// 	}
//   int operator+() 
// 	{
// 		++hr;
// 		++min;
// cout << "\n Hours and Minutes " << he << "'" << min; } };
// int main()
// {
// 	Time t1(4, 45);
// 	t1++;  
// 	return 0;
// }
// These are the following problems:
// First the  plus increment must be ++ instead of + 
// Second the data type of the opertor must be void as it is not returning any value 
// Third as it is postfix increment so you have to give int as an argument to the increment operator 

// The solved program :
// This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time
{
    int hr, min;

public:
    Time(int h, int m)
    {
        hr = h;
        min = m;
    }
    void operator++(int)
    {
        hr++;
        min++;
        cout << "\n Hours and Minutes " << hr << "'" << min;
    }
};
int main()
{
    Time t1(4, 45);
    t1++;
    return 0;
}