#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m){
        hr = h;
        min = m;
    }
    
    Time operator++(int) {                  // Operator overloading for post-increment
        Time temp(hr, min);                 // Create a copy of the original object
        ++hr;
        ++min;
        return temp;                        // Return the original value
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "'" << min << endl;
    }
};

int main() {
    Time t1(6, 35);
    t1++;                                   // Post-increment
    t1.display();

    return 0;
}