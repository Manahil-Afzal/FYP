#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m)
    {
        hr = h;
        min = m;
    }

    void display()
    {
        cout << "Time: " << hr << " hours " << min << " minutes" << endl;
    }

    Time operator++(int)
    {
        Time temp(*this);
        hr++;
        min++;

        return temp;
    }
};

int main()
{
    Time t1(4, 45);

    cout << "Original Time:" << endl;
    t1.display();

    t1++;

    cout << "Updated Time:" << endl;
    t1.display();

    return 0;
}
