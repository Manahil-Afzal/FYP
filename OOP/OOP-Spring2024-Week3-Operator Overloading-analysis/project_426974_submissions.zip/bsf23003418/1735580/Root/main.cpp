//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
	public:
int hr, min;

	Time(int h, int m)
	{
	hr = h;
	min = m;
	}
   int operator++() 
	{
		hr++;
		min++;}
		void display(void)
		{
		
cout << "\n Hours and Minutes " << hr << "'" << min; } };
int main()
{
	Time t1(4, 45);
	t1.hr++;  
	t1.min++;
	t1.display();
	return 0;
}
