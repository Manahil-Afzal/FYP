//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overloading unary plus operator to increment time by one hour and one minute
    Time operator+() {
        Time temp(hr, min); // Create a temporary object to hold the incremented time
        temp.hr++; // Increment hour
        temp.min++; // Increment minute
        cout << "\nTime after increment: " << temp.hr << " hours and " << temp.min << " minutes." << endl; // Display the updated time
        return temp; // Return the updated time
    }
};

int main() {
    Time t1(4, 45);
    Time t2 = +t1; // Using unary plus operator to increment time by one hour and one minute
    return 0;
}
