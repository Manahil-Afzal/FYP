#include <iostream>
#include <string>

using namespace std;

// Base class Course
class Course {
protected:
    string courseId;

public:
    // Method to input course ID
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }

    // Method to display course ID
    void display() {
        cout << "Course ID: " << courseId << endl;
    }
};

// IT class inherited from Course
class IT : virtual public Course { // Use virtual inheritance to avoid diamond problem
public:
    // Method to display IT course ID
    void displayIT() {
        cout << "IT ";
        Course::display(); // Call display method from base class Course
    }
};

// CS class inherited from Course
class CS : virtual public Course { // Use virtual inheritance to avoid diamond problem
public:
    // Method to display CS course ID
    void displayCS() {
        cout << "CS ";
        Course::display(); // Call display method from base class Course
    }
};

// SOS_Course class inherited from both IT and CS
class SOS_Course : public IT, public CS {
public:
    // Method to display SOS course ID
    void displaySOS() {
        cout << "SOS ";
        Course::display(); // Call display method from base class Course
    }
};

int main() {
    // Declare an object of SOS_Course
    SOS_Course sosCourse;

    // Input course ID
    sosCourse.input();

    // Display course ID using displaySOS() method
    sosCourse.displaySOS();

    return 0;
}


