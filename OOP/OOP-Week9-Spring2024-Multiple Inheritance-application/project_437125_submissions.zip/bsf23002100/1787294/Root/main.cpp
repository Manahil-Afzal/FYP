/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Course{
	protected :
		string iT_course_id;
		string CS_course_id;
	public :
		void set_course_id(){
			cout<<"\tEnter Your IT Course ID :"<<endl;
			cin>>iT_course_id;
			cout<<"\tEnter Your CS Course ID :"<<endl;
			cin>>CS_course_id;
		}
};
class iT : virtual public Course{
	public :
		void displayIT(){
			cout<<"\tIT Course ID: "<<iT_course_id<<endl;
		}
};
class CS : virtual public Course {
	public :
		void displayCS(){
			cout<<"\tCS Course ID : "<<CS_course_id<<endl;
		}
};
class SOS_Course : public iT , public CS{
	public :
		void Display(){
			cout<<"\tThe Course ID of iT and CS is given below :"<<endl;
		}
			void displayIT(){
			cout<<"\tiT Course ID : "<<iT::iT_course_id<<endl;
		}
			void displayCS(){
			cout<<"\tCS Course ID : "<<CS::CS_course_id<<endl;
		}
		
};
int main(){
	SOS_Course sos;
	sos.set_course_id();
	sos.Display();
	sos.displayIT();
	sos.displayCS();
	return 0;
}