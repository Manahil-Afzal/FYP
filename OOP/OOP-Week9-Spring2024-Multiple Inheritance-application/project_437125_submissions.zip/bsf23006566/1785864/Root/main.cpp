/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/


#include<iostream>
using namespace std;

class Course{
	protected:
	int courseId;
	public:
		void input(){
			cout<<"Enter course Id: ";
			cin>>courseId;
		}
	
};
class IT:virtual public Course{
	public:
		void display(){
			cout<<"Coure Id is: "<<courseId;
		}
};
class CS:virtual public Course{
	public:
		void display(){
			cout<<"Coure Id is: "<<courseId;
		}	
};
class SOS_Course:public IT,public CS{
	public:

		void display(){
			IT::display();
		}
};
int main(){
	SOS_Course s;
	s.input();
	s.display();
	return 0;
}