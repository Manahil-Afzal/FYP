/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;
class course{
	int course_id;
	public:
		void setdata(int id){
			course_id=id;
		}
		int getdata(){
			return course_id;
		}
		void input(){
			cout<<"enter the course id"<<endl;
			cin>>course_id;
		}
};
class IT: virtual public course{
	public:
		void display(){
			cout<<"course id :"<<getdata();
		}
};
class CS: virtual public course{
	public:
				void display(){
			cout<<"course id :"<<getdata();
		}
};
class SOS:public IT,public CS{
	public:
			void display(){
			cout<<" SOS course id :"<<getdata();
		}
	
};
main(){
	SOS s1;
	s1.input();
	s1.display();
}