#include <iostream>
#include <string>

using namespace std;

// Base class Course
class Course {
protected:
    string course_id;

public:
    // Method to take input of course ID from user
    void input() {
        cout << "Enter Course ID: ";
        cin >> course_id;
    }
};

// Derived class IT inheriting from Course
class IT : public Course {
public:
    // Method to display the course ID
    void display() {
        cout << "Course ID: " << course_id << endl;
    }
};

// Derived class CS inheriting from Course
class CS : public Course {
public:
    // Method to display the course ID
    void display() {
        cout << "Course ID: " << course_id << endl;
    }
};

// Derived class SOS_Course inheriting from IT and CS
class SOS_Course : public IT, public CS {
public:
    // Method to display the course ID
    void display() {
        IT::input(); // Call input method of IT
        cout << " Course ID: ";
        IT::display(); // Display course ID from IT
    }
};

int main() {
    // Create an object of SOS_Course
    SOS_Course sos_course;

    // Display the course ID set by the user
    sos_course.display();

    return 0;
}
