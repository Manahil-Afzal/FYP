#include <iostream>
using namespace std;

class Course {
protected:
	int courseId;

public:
	void input() {
		cout << "Enter Course ID: ";
		cin >> courseId;
	}
};

class IT : public Course {
public:
	void display() {
		cout << "IT Course ID: " << courseId << endl;
	}
};

class CS : public Course {
public:
	void display() {
		cout << "CS Course ID: " << courseId << endl;
	}
};

class SOS_Course : public IT, public CS {
public:
	void display() {
		cout << "SOS Course ID: " << IT::courseId << endl; // Use IT::courseId to specify
	}
};

int main() {
	SOS_Course sosCourse;

	sosCourse.IT::input(); // Use IT::input() to specify
	sosCourse.display();

	return 0;
}



