/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
#include <string.h>
using namespace std;
class Course
{
protected:
    int course_id;

public:
    void get_data()
    {
        cout << "Enter the course id = " << endl;
        cin >> course_id;
    }
};
class IT : public Course

{
public:
    void display_data()
    {
        cout << "The course id is = " << course_id << endl;
    }
};
class CS : public Course
{
    void display_data()
    {
        cout << "The course id is = " << course_id << endl;
    }
};
class SOS_course : public IT, public CS
{
public:
    void display_data()
    {
    }
};
int main()
{
    SOS_course obj1;
    obj1.display_data();
    return 0;
}