#include <iostream>
using namespace std;
class course
{
protected:
    string course_id;
    public:
    void input()
    {
        cout << "Enter course ID:" << endl;
        cin >> course_id;
    }
};
class IT:virtual public course
{
    public:
    void display()
    {
        cout<<"IT course :"<<course_id<<endl;

    }
};
class CS :virtual public course
{   public:
    void display()
    {
        cout<<"CS course:"<<course_id<<endl;
    }
};
class SOS_course:public IT,public CS
{   public:
    void display()
    {
        IT::display();
        CS::display();
    }
};
int main()
{SOS_course sos;
    sos.input();
    sos.display();
    return 0;

}