/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
#include <string>
using namespace std;

class Course {
protected:
    string course_id;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> course_id;
    }
};

class IT : virtual public Course {  // Use virtual inheritance
public:
    void display() {
        cout << "IT Course ID: " << course_id << endl;
    }
};

class CS : virtual public Course {  // Use virtual inheritance
public:
    void display() {
        cout << "CS Course ID: " << course_id << endl;
    }
};

class SOS_course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID (IT): " << course_id << endl;
        cout << "SOS Course ID (CS): " << course_id << endl;
    }
};

int main() {
    SOS_course course;
    course.input();
    course.display();

    return 0;
}
