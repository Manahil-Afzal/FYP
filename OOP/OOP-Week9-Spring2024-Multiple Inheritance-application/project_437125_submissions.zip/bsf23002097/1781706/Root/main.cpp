/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;
class Employee{
  protected:
    string Name;
    string Id;
    int work_hours;
    int hour_salary;
public:
    void setValues(){
        Name="Rabbiya";
        Id="rabbiya654";
        work_hours=4;
        hour_salary=1000;
    }
};
class Adhoc_Employee: public Employee{
  public: 
  double Salary(){
      return work_hours * hour_salary;
  }
            void displayInfo(){
                cout<<"Employee Name: "<<Name<<endl;
                cout<<"Employee ID: "<<Id<<endl;
                cout<<"Working hours: "<<work_hours<<endl;
                cout<<"Total Salary: "<<Salary()<<endl;
            }
};
int main(){
    Adhoc_Employee employee;
    employee.setValues();
    employee.displayInfo();
    return 0;
}