/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};
class CS : public virtual Course {
public:
    void display() {
        cout << "CS Course ID: "<<courseId<<endl;
    }
};
class IT : public virtual Course {
public:
    void display() {
        cout << "IT Course ID: "<<courseId<<endl;
    }
};
class SOS_Course :public CS, public IT {
public:
    void display() {
    	Course::input();
        CS::display();
        IT::display();
    }
};
int main() {
	SOS_Course s1;
	s1.display();
return 0;


}