#include <iostream>
#include <string>
using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class IT inheriting from Course
class IT : virtual public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class CS inheriting from Course
class CS : virtual public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class SOS_Course inheriting from both IT and CS
class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID: " << courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input(); // Take input for course ID
    sosCourse.display(); // Display the course ID
    return 0;
}
