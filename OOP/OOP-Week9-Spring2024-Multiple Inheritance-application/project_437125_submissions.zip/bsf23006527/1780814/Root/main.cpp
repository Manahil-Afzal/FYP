#include<iostream>
using namespace std;

class Course{
    protected: 
        int CourseID;
    public: 
        void input(){
            cout << "Enter the Course ID : " ;
            cin >> CourseID;
        };
};

class IT : virtual public Course {
    public: 
        void display () {
            cout << "The Course Id is : " << CourseID << endl;
        }; 
};

class CS : virtual public Course {
    public: 
        void display () {
            cout << "The Course Id is : " << CourseID << endl;
        };        
};

class SOS_Course :  public IT ,  public CS{
    public: 
        void display () {
            cout << "The Course Id is : " << CourseID << endl;
        };       
};

int main() {
    SOS_Course course;

    course.input();
    course.display();
    return 0;
}