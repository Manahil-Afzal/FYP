/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user.
 Each child class in the hierarchy implementsa display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include<iostream>
using namespace std;
class course{
	protected:
	int c_id;
	public:
		course(int id){
			c_id=id;
		}
		void input(){
			cout<<"enter the course id "<<endl;
			cin>>c_id;
		}
		
};
class IT: virtual public course{
	public:
		IT(int id):course(id){
		}
		void display(){
			cout<<"the course id is "<<c_id<<endl;
		}
};
class CS: virtual public course{
	public:
		CS(int id):course(id){
		}
	
		void display(){
			cout<<"the course id is "<<c_id<<endl;
		}
};
class sos_course:public IT,public CS{

			public:
				sos_course(int id):course(id),IT(id),CS(id){
		}
		
		void display(){
			cout<<"the course id is "<<c_id<<endl;
			
			}
	
		
};
int main(){
	sos_course s(0);
    s.input();
    s.display();
}
