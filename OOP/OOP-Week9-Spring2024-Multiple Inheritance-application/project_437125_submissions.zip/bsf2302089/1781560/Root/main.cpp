/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

// Base class: Course
class Course {
protected:
    int courseId;

public:
    void input() {
        cout << "Enter course ID: ";
        cin >> courseId;
    }
};

// Derived class: IT (inherits from Course)
class IT : public virtual Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class: CS (inherits from Course)
class CS : public virtual Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class: SOS_Course (inherits from IT and CS)
class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID: " << courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;

    cout << "Enter course details:" << endl;
    sosCourse.input();

    cout << "Course details:" << endl;
    sosCourse.IT::display();
    sosCourse.CS::display();
    sosCourse.display();

    return 0;
}