/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include <iostream>

using namespace std;

class Course {
protected:
  int course_ID;

public:
  void input() {
    cout << "Enter course ID: ";
    cin >> course_ID;
  }
};

class ITCourse :virtual public Course {
public:
  void display() {
    cout << "IT Course ID: " << course_ID << endl;
  }
};

class CSCourse :virtual public Course {
public:
  void display() {
    cout << "CS Course ID: " << course_ID << endl;
  }
};

class SOSCourse : public ITCourse, public CSCourse {
public:
  void displaySOS() { 
    cout << "SOS Course  ID: " << course_ID << endl;
  }
};

int main() {
  SOSCourse sosCourse;

  sosCourse.input();
  sosCourse.displaySOS(); 

  return 0;
}