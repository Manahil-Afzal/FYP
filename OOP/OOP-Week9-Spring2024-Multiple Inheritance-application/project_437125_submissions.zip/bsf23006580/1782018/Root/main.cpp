/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include <iostream>
using namespace std;
class Course
{
protected:
    int course_id;

public:
    void input()
    {
        cout << "Enter ID : ";
        cin >> course_id;
    }
};
class IT : virtual public Course
{
public:
    void display()
    {
        cout << "IT Course ID : " << course_id << endl
             << endl;
    }
};
class CS : virtual public Course
{
public:
    void display()
    {
        cout << "CS Course ID : " << course_id << endl
             << endl;
    }
};
class SOS_Course : public CS, public IT
{
public:
    void display()
    {
        cout << "SOS Course ID : " << course_id << endl
             << endl;
    }
};
int main()
{
    SOS_Course c;
    c.input();
    c.display();
    IT it;
    it.input();
    it.display();
    CS cs;
    cs.input();
    cs.display();
    return 0;
}