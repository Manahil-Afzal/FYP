#include <iostream>
using namespace std;

class Course
{
protected:
    string courseId;

public:
    void input()
    {
        cout << "Enter course ID: ";
        cin >> courseId;
    }
};

class IT : public Course
{
public:
    void display()
    {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : public Course
{
public:
    void display()
    {
        cout << "CS Course ID: " << courseId << endl;
    }
};

class SOS_Course : public IT, public CS
{
public:
    void display()
    {
        cout << "SOS Course ID (from IT): " << IT::courseId << endl;
        cout << "SOS Course ID (from CS): " << CS::courseId << endl;
    }
};

int main()
{
    SOS_Course sosCourse;

    sosCourse.IT::input();
    sosCourse.CS::input();

    cout << "Course IDs for SOS Course:" << endl;
    sosCourse.display();

    return 0;
}
