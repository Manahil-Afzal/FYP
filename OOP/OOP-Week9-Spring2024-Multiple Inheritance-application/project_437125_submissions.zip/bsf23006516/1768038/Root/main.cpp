/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course{
	protected:
	string name;	
	string c_id;
	public:
	void input(){
		cout<<"Enter Course name: ";
		cin>>name;
		cout<<"Enter Couse Id: ";
		cin>>c_id;
	}
	void display(){
		cout<<"Course ID: "<<c_id<<endl;
		cout<<"Course Name: "<<name<<endl;
	}		
};
class IT:virtual public course{
	
};
class CS:virtual public course{
};
class SOS_course:public IT,public CS{
	
};
int main(){
SOS_course c1;
c1.input();
c1.display();	
}