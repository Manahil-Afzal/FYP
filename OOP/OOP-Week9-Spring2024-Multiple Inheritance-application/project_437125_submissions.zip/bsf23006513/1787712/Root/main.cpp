#include<iostream>
#include<string>
using namespace std;
class Course
{
protected:
	string course_Id;
public:
	void Course_Input()
	{
		cout<<"Enter course Id : ";
		cin>>course_Id;
	}

};
class IT :virtual public Course
{
public:
	void display()
	{
		cout<<" Course Id : "<<course_Id;
	}
};
class CS :virtual public Course
{
public:
		void display()
	{
		cout<<" Course Id : "<<course_Id;
	}
};
class SOS_Course :virtual public IT,virtual public CS
{
public:
		void display()
	{
		cout<<" Course Id : "<<course_Id;
	}
};

int main()
{
	SOS_Course c1;
	c1.Course_Input();
	c1.display();
}
