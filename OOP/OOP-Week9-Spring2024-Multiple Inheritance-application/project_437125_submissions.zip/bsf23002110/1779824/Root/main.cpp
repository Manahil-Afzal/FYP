#include <iostream>

using namespace std;

class Course {
protected:
  int courseID;

public:
  void input() {
    cout << "Enter course ID: ";
    cin >> courseID;
  }
};

class ITCourse :virtual public Course {
public:
  void display() {
    cout << "IT Course ID: " << courseID << endl;
  }
};

class CSCourse :virtual public Course {
public:
  void display() {
    cout << "CS Course ID: " << courseID << endl;
  }
};

class SOSCourse : public ITCourse, public CSCourse {
public:
  void displaySOS() { 
    cout << "SOS Course (inherited from CS): ID: " << courseID << endl;
  }
};

int main() {
  SOSCourse sosCourse;

  sosCourse.input();
  sosCourse.displaySOS(); 

  return 0;
}
