#include <iostream>
using namespace std;

class Course{
protected:
    string course_id;
public:
    void input(){
        cout<<"Enter the course Id: ";
        cin>>course_id;
    }
};

class IT: virtual public Course{
public:
    void display(){
        cout<<"Your course id: "<<course_id<<endl;
    }    
};
class CS: virtual public Course{
public:
    void display(){
        cout<<"Your course id: "<<course_id<<endl;
    }
};

class Sos_course: public IT, public CS{
public:
    void display(){
        cout<<"Your course id: "<<course_id<<endl;
    }
};



int main(){
    Sos_course obj;
    obj.input();
    obj.display();


    return 0;
}