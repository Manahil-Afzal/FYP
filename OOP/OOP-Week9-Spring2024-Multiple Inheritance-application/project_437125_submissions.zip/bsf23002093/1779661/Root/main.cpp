/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

// Base class Course
class Course {
protected:
    int courseId;

public:
    // Method to take input of courseId
    void input() {
        cout << "Enter course ID: ";
        cin >> courseId;
    }
};

// Derived class IT inheriting virtually from Course
class IT : virtual public Course {
public:
    // Method to display courseId for IT course
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class CS inheriting virtually from Course
class CS : virtual public Course {
public:
    // Method to display courseId for CS course
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class SOS_course inheriting from IT and CS
class SOS_course : public IT, public CS {
public:
    // Method to display courseId for SOS_course
    void display() {
        cout << "SOS_course ID: " << courseId << endl;
    }
};

int main() {
    // Declare an object of SOS_course
    SOS_course sosCourse;

    // Input courseId
    sosCourse.input();

    // Display courseId set by user
    sosCourse.display();

    return 0;
}
