/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Intermediate derived classes
class IT : virtual public Course { // Adding 'virtual' keyword to solve diamond problem
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : virtual public Course { // Adding 'virtual' keyword to solve diamond problem
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class inheriting from IT and CS
class SOS_Course : public IT, public CS {
public:
    void display() {
        IT::display(); // Call IT's display function explicitly
        CS::display(); // Call CS's display function explicitly
    }

    // Resolve ambiguity by specifying which input() to call
    void input() {
        Course::input();
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input(); // Take input for course ID
    sosCourse.display(); // Display the course ID
    return 0;
}
