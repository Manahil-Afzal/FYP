#include <iostream>
#include <string>
using namespace std;

// Base class Course
class Course {
protected:
    string courseId;

public:
    // Method to take input for courseId
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Subclass IT inheriting from Course
class IT : public Course {
public:
    // Method to display courseId
    void display() {
        cout << "Course ID (IT): " << courseId << endl;
    }
};

// Subclass CS inheriting from Course
class CS : public Course {
public:
    // Method to display courseId
    void display() {
        cout << "Course ID (CS): " << courseId << endl;
    }
};

// Subclass SOS_Course inheriting from both IT and CS
class SOS_Course : public IT, public CS {
public:
    // Method to display courseId from IT
    void displayITCourseId() {
        cout << "Course ID (SOS Course from IT): " << IT::courseId << endl;
    }

    // Method to display courseId from CS
    void displayCSCourseId() {
        cout << "Course ID (SOS Course from CS): " << CS::courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;
    
    // Input course ID for SOS_Course
    sosCourse.CS::input(); // Specify input from CS class

    // Display course ID for SOS_Course from IT and CS
    sosCourse.displayITCourseId();
    sosCourse.displayCSCourseId();

    return 0;
}
