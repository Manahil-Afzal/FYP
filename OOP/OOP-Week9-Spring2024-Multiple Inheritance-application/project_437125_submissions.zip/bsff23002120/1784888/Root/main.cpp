/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include <iostream>
using namespace std;

// Base class
class Course {
protected:
    int courseId;
public:
    void input() {
        cout << "Enter course ID: ";
        cin >> courseId;
    }
};

// Derived class from Course
class IT : public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Another derived class from Course
class CS : public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class from IT and CS
class SOS_Course : public IT, public CS {
public:
    // Display method that shows both IT and CS course IDs
    void display() {
        IT::display(); // Calling display from IT
        CS::display(); // Calling display from CS
    }
};

int main() {
    SOS_Course obj;
    obj.IT::input(); // Taking input for IT course ID
    // Note: If IT and CS have different IDs, you need separate input methods for each.
    obj.display(); // Displaying course IDs
    return 0;
}
