/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
#include <string>
using namespace std;

class course{

	protected:
	int id;
 	public:
 	void setid(int ID)
    {
 	     id=ID;
    }
    void getid() 
    {
 	     cout<<" enter id"<<endl;
 	     cin>>id;
    }
};

class cs : virtual public course
{

 	public:
 	void display()
    {
 	     cout<<"id is: "<<id;
    }

};
class it: virtual public course
{
 	public:
 	void display()
    {
 	     cout<<"id is: "<<id;
    }
};
class sos_course : public cs,public it
{
 	public:
 		void display()
    {
 	     cout<<"course id is: "<<id;
    }

};

int main()
{
	sos_course b1;
	b1.getid();
	b1.display();
 
 	 return 0;
}