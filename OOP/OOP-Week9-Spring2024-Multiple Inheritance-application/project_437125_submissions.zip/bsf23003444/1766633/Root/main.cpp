/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/

#include <iostream>
#include <string>

using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Subclass IT inheriting from Course
class IT : virtual public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Subclass CS inheriting from Course
class CS : virtual public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Subclass SOS_Course inheriting from both IT and CS
class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID: " << courseId << endl;
    }
};

int main() {
    // Declare an object of SOS_Course
    SOS_Course sosCourse;

    // Take input for Course ID
    sosCourse.input();

    // Display the Course ID set by the user
    sosCourse.display();

    return 0;
}
