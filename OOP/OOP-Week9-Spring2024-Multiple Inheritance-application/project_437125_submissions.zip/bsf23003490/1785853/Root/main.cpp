/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
#include <string>

using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter course ID: ";
        cin >> courseId;
    }

    // Display method to be used by derived classes
    void display(const string& prefix) {
        cout << prefix << " Course ID: " << courseId << endl;
    }
};

// Derived class 1
class IT : virtual public Course {
public:
    // Display method for IT
    void display() {
        Course::display("IT");
    }
};

// Derived class 2
class CS : virtual public Course {
public:
    // Display method for CS
    void display() {
        Course::display("CS");
    }
};

// Derived class from IT and CS
class SOS_Course : public IT, public CS {
public:
    // Display method for SOS_Course
    void display() {
        Course::display("SOS");
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input(); // Take input of course ID from the user
    sosCourse.display(); // Display the course ID set by the user for SOS_Course
    return 0;
}
