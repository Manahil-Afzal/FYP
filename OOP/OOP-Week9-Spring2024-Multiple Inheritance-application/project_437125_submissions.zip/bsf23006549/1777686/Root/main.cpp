/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes:
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS.
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id.
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class Course {
	protected:
		int courseID;
	public:
		void setCourseID() {
			cout<<"Enter Course ID :";
			cin>>courseID;
		}
};
class IT :virtual  public Course {
	public:
		void getCourseID() {
			cout<<"Course ID is :";
			cout<<courseID;
		}
};
class CS :  virtual public Course {
	public:
		void getCourseID() {
			cout<<"Course ID is :";
			cout<<courseID;
		}
};
class SOS : public IT, public CS {
	public:
		void getCourseID() {
			cout<<"Course ID is :";
			cout<<courseID;
		}
};	
int main() {
	SOS S;
	S.setCourseID();
	S.getCourseID();

}