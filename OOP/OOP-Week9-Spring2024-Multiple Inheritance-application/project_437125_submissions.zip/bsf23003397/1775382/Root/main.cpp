/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
#include <string>
using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class IT inheriting from Course
class IT : virtual public Course {
public:
    void display() {
        cout << "Course ID (IT): " << Course::courseId << endl;
    }
};

// Derived class CS inheriting from Course
class CS : virtual public Course {
public:
    void display() {
        cout << "Course ID (CS): " << Course::courseId << endl;
    }
};

// Derived class SOS_Course inheriting from both IT and CS
class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "Course ID (SOS_Course): " << Course::courseId << endl;
    }
};

int main() {
    SOS_Course course;
    course.input(); // Input course ID
    course.display(); // Display course ID

    return 0;
}
