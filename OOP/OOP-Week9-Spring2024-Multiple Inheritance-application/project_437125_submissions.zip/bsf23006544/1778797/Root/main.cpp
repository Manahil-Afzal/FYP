/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>

// Base class
class Course {
protected:
    int courseId; // Course ID attribute
public:
    // Method to input the course ID
    void input() {
        std::cout << "Enter Course ID: ";
        std::cin >> courseId;
    }
};

// Derived class IT
class IT : public Course {
public:
    // Display method to show course ID
    void display() {
        std::cout << "IT Course ID: " << courseId << std::endl;
    }
};

// Derived class CS
class CS : public Course {
public:
    // Display method to show course ID
    void display() {
        std::cout << "CS Course ID: " << courseId << std::endl;
    }
};

// Derived class SOS_Course, inheriting from both IT and CS
class SOS_Course : public IT, public CS {
public:
    // Display method to show course ID from both IT and CS
    void display() {
        std::cout << "SOS_Course derived from IT and CS." << std::endl;
        std::cout << "Course ID from IT: " << IT::courseId << std::endl;
        std::cout << "Course ID from CS: " << CS::courseId << std::endl;
    }
};

int main() {
    SOS_Course sosCourse;
    
    // Input course ID (only once)
    sosCourse.IT::input(); // Using IT's method to input
    
    // Display course ID from SOS_Course
    sosCourse.display();
    
    return 0;
}