#include <iostream>
#include <string>

using namespace std;

// Base class Course
class Course {
protected:
    string courseId;

public:
    // Input method to take course ID from user
    void getdata() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class IT inheriting from Course
class IT : public Course {
public:
    // Display method to display IT course ID
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class CS inheriting from Course
class CS : public Course {
public:
    // Display method to display CS course ID
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class SOS_Course inheriting from IT and CS
class SOS_Course : public IT, public CS {
public:
    // Display method to display SOS course ID
    void display() {
        // Since SOS_Course inherits from both IT and CS, it needs to specify which course ID to display
        cout << "SOS Course ID:" << endl;
        cout << "IT Course ID: " << IT::courseId << endl;
        cout << "CS Course ID: " << CS::courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;

    // Input course ID for SOS_Course object
    sosCourse.IT::getdata();
    sosCourse.CS::getdata();
    

    // Display the course ID of SOS_Course
    sosCourse.display();

    return 0;
}
