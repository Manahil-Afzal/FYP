#include<iostream>
using namespace std;

class Course{
    protected: 
        int CourseID;
    public: 
        void input(){
            cout << "Enter the Course ID : " ;
            cin >> CourseID;
        };
};

class IT : virtual public Course {
    public: 
        void display () {
            cout << "The Course Id is : " << CourseID << endl;
        }; 
};

class CS : virtual public Course {
    public: 
        void display () {
            cout << "The Course Id is : " << CourseID << endl;
        };        
};

class SOS_Course :  public IT ,  public CS{
    public: 
        void display () {
            cout << "The Course Id is : " << CourseID << endl;
        };       
};

int main() {
    SOS_Course course;

    course.input();
    course.display();
    return 0;
}


/* Write a C++ program that implements multiple inheritance through class hierarchy having four classes:
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS.
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id.
Declare an object of SOS_Course and display the course Id set by user. */