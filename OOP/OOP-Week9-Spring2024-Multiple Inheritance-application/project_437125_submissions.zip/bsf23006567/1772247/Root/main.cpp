/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course{
	protected:
		int course_id;
		public:
			void input()
			{
				cout<<"enter course id";
				cin>>course_id;
			}
		
};
class cs:public course{
	public:
	void display()
	{
		cout<<"the course id is"<<course_id<<endl;
		
		
	}
	
};

class it:public course{
	public:
	void display()
	{
		cout<<"the course id is"<<course_id<<endl;
		
		
	}
	
};
class SOS:public cs,public it{
	
	
};
int main()
{
	SOS obj;
    obj.cs::input(); 
	obj.cs::display();
	
}