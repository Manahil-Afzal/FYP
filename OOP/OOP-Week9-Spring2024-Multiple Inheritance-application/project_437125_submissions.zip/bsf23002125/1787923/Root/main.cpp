/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;

class Course{
	protected:
		string itCourseId;
		string csCourseId;
	public:
		void setCourseId(){
			cout << "Enter Your IT Course ID: ";
			cin >> itCourseId;
			cout << "Enter Your CS Course ID: ";
			cin >> csCourseId;
		}
};

class IT : virtual public Course{
	public:
		void displayIT(){
			cout << "IT Course ID: " << itCourseId << endl;
		}
};

class CS : virtual public Course{
	public:
		void displayCS(){
			cout << "CS Course ID: " << csCourseId << endl;
		}
};

class SOS_Course : public IT , public CS{
	public :
		void display(){
			cout << "The Course IDs of IT and CS are given below: " << endl;
		}
		void displayIT(){
		    cout << "IT Course ID: " << IT :: itCourseId << endl;
		}
		void displayCS(){
			cout << "CS Course ID: "<< CS :: csCourseId << endl;
		}		
};

int main(){
	SOS_Course sos;
	sos.setCourseId();
	sos.display();
	sos.displayIT();
	sos.displayCS();
	return 0;
}