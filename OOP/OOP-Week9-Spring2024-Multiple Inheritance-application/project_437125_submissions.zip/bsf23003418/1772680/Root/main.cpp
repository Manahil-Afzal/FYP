/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
using namespace std;
class course
{
  public:
  string course_id;
  void setdata()
  {
      cout<<"enter course id"<<endl;
      cin>>course_id;
  }
};
class IT:public course
{
    public:
    void display()
    {
        cout<<"your it id is"<<course_id<<endl;
    }
    
};
class CS:public course
{
    public:
    void display()
    {
        cout<<"your cs id id"<<course_id<<endl;
    }
};
class SOS:public IT,public CS
{
    
};
int main()
{
    SOS s1;
    s1.IT::setdata();
    s1.IT::display();
    s1.CS::setdata();
    s1.CS::display();

}
