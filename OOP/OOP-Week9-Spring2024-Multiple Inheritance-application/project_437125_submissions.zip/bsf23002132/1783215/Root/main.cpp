#include <iostream>
using namespace std;

class Course {
protected:
    string courseId;
public:
    void input() {
        cout << "Enter the course ID: ";
        cin >> courseId;
    }
};

class IT : virtual public Course {
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : virtual public Course {
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

class SOS_Course : public IT, public CS {
public:
    void displaySOS() {
cout << "SOS Course ID: " << courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input();
    sosCourse.displaySOS();

    return 0;
}
