/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include<iostream>
#include<string>
using namespace std;
class Course
{
protected:
	string course_Id;
public:
	void Course_Input()
	{
		cout<<"Enter course Id : ";
		cin>>course_Id;
	}

};
class IT :virtual public Course
{
public:
	void display()
	{
		cout<<" Course Id : "<<course_Id;
	}
};
class CS :virtual public Course
{
public:
		void display()
	{
		cout<<" Course Id : "<<course_Id;
	}
};
class SOS_Course :virtual public IT,virtual public CS
{
public:
		void display()
	{
		cout<<" Course Id : "<<course_Id;
	}
};

int main()
{
	SOS_Course c1;
	c1.Course_Input();
	c1.display();
}