#include <iostream>
#include <string>

using namespace std;

// Base class
class Course {
protected:
    string courseId;

public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Intermediate classes
class IT : virtual public Course { // Virtual inheritance
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

class CS : virtual public Course { // Virtual inheritance
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class
class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID: " << courseId << endl;
    }
};

int main() {
    SOS_Course sosCourse;
    sosCourse.input(); // Input course ID
    sosCourse.display(); // Display course ID
    return 0;
}