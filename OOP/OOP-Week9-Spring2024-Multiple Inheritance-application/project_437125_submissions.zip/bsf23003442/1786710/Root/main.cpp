/*Write a C++ program that implements multiple inheritance through class hierarchy having four classes: 
Course, IT, CS, SOS_course where IT, CS are inherited from Course and SOS_Course is inherited from IT and CS. 
Course class has an attribute course Id and an input() method that takes input of course Id from user. Each child class in the hierarchy implements
a display() method that displays the course Id. 
Declare an object of SOS_Course and display the course Id set by user.*/
#include <iostream>
using namespace std;

// Base class
class Course {
protected:
    int courseId;
public:
    void input() {
        cout << "Enter Course ID: ";
        cin >> courseId;
    }
};

// Derived class IT
class IT : virtual public Course { // Add 'virtual' to ensure only one instance of courseId
public:
    void display() {
        cout << "IT Course ID: " << courseId << endl;
    }
};

// Derived class CS
class CS : virtual public Course { // Add 'virtual' to ensure only one instance of courseId
public:
    void display() {
        cout << "CS Course ID: " << courseId << endl;
    }
};

// Derived class SOS_Course inherited from IT and CS
class SOS_Course : public IT, public CS {
public:
    void display() {
        cout << "SOS Course ID: " << courseId << endl; // Ambiguity resolved by using courseId from Course
    }
};

int main() {
    SOS_Course sos_course;
    sos_course.input(); // Take input for Course ID
    sos_course.display(); // Display the Course ID set by the user
    return 0;
}
