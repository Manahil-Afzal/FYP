/*This program is intended to have an abstract class called Base which has a pure virtual function named show.
The function is overriden in Derived class and polymorphically called in main(). Identify and correct errors.*/
#include <iostream>  
using namespace std;  
class base  
{  
public:  
 	void print ()  
 	{ cout<< "print base class" <<endl; }  
};  
class derived:public base  
{  
public:  
virtual void print ()  
 	{ cout<< "print derived class" <<endl; }  
virtual void show ()  
 	{ cout<< "show derived class" <<endl; }  
};  
int main()  
{  	base *bptr;  
 	derived d;   	
 	bptr = &d;  
 	d.print();  
 	d.show();   	return 0;  
}  

