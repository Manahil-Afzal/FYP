/*This program is intended to have an abstract class called Base which has a pure virtual function named show.
The function is overriden in Derived class and polymorphically called in main(). Identify and correct errors.*/
#include<iostream>
using namespace std; 
class Base 
{ 
      public: 
	virtual void show()=0;
}; 
class Derived: public Base 
{ 
      public: 
	void show() { cout<< "In Derived \n"; } 
}; 
int main() 
{ 
	Derived *d = new Derived(); 
           Base *b = d;
	d->show(); 
           delete b;
	return 0; 
};