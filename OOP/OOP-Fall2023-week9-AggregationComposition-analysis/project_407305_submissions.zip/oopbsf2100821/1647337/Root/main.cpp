//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
int hr, min;
public:
	Time(int h, int m)
	{
	hr = h;
	min = m;
	}
   int operator++()// increment operator overloading not plus operator 
	{
		++hr;
		++min;
cout << "\n Hours and Minutes " << hr << "'" << min;// we declare hr not he
}
};
int main()
{
	Time t1(4, 45);
	++t1;// pre increment operator overloaded not pos increment  
	return 0;
}
