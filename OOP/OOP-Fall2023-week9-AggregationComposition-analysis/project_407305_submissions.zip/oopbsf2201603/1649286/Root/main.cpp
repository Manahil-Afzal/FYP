//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private: // Make 'hr' and 'min' private members
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void operator++() { // Corrected the operator overloading function, and changed the return type to 'void'
        ++hr;
        ++min;
        cout << "\n Hours and Minutes " << hr << "'" << min; // Corrected the variable name 'he' to 'hr'
    }
};

int main() {
    Time t1(4, 45);
    ++t1; // Corrected the way you increment the time
    return 0;
}

