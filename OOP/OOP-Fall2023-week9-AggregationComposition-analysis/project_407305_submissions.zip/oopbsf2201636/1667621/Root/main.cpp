//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void displayTime() const {
        cout << "\n Hours and Minutes " << hr << "'" << min;
    }

    // Post-increment operator overloading
    void operator++(int) {
        hr++;
        min++;
    }
};

int main() {
    Time t1(4, 45);
    t1++; // Post-increment

    // Display the results
    t1.displayTime();

    return 0;
}
