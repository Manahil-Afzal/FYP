#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void operator++() {
        ++hr;
        ++min;
    }

    void displayTime() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }
};

int main() {
    Time t1(4, 45);
    ++t1;  // You need to use the prefix increment operator here
    t1.displayTime();
    return 0;
}
