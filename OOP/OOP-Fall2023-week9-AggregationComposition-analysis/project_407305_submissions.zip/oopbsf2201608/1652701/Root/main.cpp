//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overload the ++ operator as a member function
    Time operator++() {
        ++hr;
        ++min;
        return *this;
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }
};

int main() {
    Time t1(4, 45);
    ++t1;  // Increment the time
    t1.display();  // Display the updated time
    return 0;
}
