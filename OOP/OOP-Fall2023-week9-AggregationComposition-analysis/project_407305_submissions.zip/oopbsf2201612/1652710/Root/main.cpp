#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void display() {
        cout << "Hours and Minutes: " << hr << "h " << min << "m" << endl;
    }

    Time operator++(int) {
        Time temp = *this; // Create a temporary object with the current values
        hr++;
        min++;

        return temp;
    }
};

int main() {
    Time t1(4, 45);
    t1.display(); // Display the initial time

    t1++; // Post-increment t1
    t1.display(); // Display the updated time

    return 0;
}
