#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    void displayTime() {
        cout << "Time: " << hr << " hours " << min << " minutes" << endl;
    }

    // Overload the post-increment operator (++)
    Time operator++(int) {
        Time temp(hr, min);
        hr++;
        min++;
        return temp;
    }
};

int main() {
    Time t1(4, 45);
    t1.displayTime();  // Display the original time

    t1++;  // Post-increment the time

    t1.displayTime();  // Display the time after post-increment

    return 0;
}
