//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
private:
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    Time operator++(int) {
        Time temp(hr, min); // Create a temporary Time object with the current values
        hr++;
        min++;

        cout << "\n Hours and Minutes " << hr << "'" << min;

        return temp; // Return the temporary object with the original values
    }
};

int main() {
    Time t1(4, 45);
    t1++;

    return 0;
}
