#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Overloading post-increment operator
    Time operator++(int) {
        Time temp = *this;  // Create a temporary object with the current values
        hr++;
        min++;
        cout << "\n Hours and Minutes " << hr << "'" << min;
        return temp;        // Return the temporary object (pre-incremented state)
    }
};

int main() {
    Time t1(4, 45);
    t1++;  // Using the overloaded post-increment operator

    return 0;
}
