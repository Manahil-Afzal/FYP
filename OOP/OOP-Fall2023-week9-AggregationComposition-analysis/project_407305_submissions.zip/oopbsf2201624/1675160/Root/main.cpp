//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
    int hr, min;

public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    // Use the prefix increment operator (++t1) instead of the unary plus operator (+t1).
    // Also, the function should return a Time object.
    Time operator++() {
        ++hr;
        ++min;
        // Use cout instead of he.
        cout << "\n Hours and Minutes " << hr << "'" << min;
        return *this; // Return the updated Time object.
    }
};

int main() {
    Time t1(4, 45);
    ++t1; // Use the prefix increment operator (++t1) instead of t1++.
    return 0;
}
