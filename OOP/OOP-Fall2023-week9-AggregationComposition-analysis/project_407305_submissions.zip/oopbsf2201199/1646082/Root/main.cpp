//This program is meant to post-increment a time's object and display the results

#include <iostream>
using namespace std;

class Time {
    int hr, min;
public:
    Time(int h, int m) {
        hr = h;
        min = m;
    }

    Time operator++() {
        ++hr;
        ++min;
        return *this;
    }

    void display() {
        cout << "\n Hours and Minutes " << hr << "'" << min;
    }
};

int main() {
    Time t1(3, 19);
    ++t1;
    t1.display();
    return 0;
}
