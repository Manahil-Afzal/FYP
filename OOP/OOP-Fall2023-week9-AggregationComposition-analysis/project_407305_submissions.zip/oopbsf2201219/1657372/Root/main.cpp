//This program is meant to post-increment a time's object and display the results
#include <iostream>
using namespace std;

class Time {
int hr, min;
public:
	Time(int h, int m)
	{
	hr = h;
	min = m;
	}
   int operator+() 
	{
		++hr;
		++min;
cout << "\nHours and Minutes:" << hr << "'" << min; } }; // "hr" instead of he
int main()
{
	Time t1(4, 45);
	t1.operator+(); // operator+ using instead of t1++
	return 0;
}
