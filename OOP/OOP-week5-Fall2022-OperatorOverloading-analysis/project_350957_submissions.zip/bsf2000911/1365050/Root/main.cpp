//This program is meant to post-increment a time's object and display the results
    	#include <iostream>
    	using namespace std;
		class Employee
       {
              int Id;
              char name[25];
              int Age;
              long Salary;

              public:
              void GetData()           
              {
                    cout<<"\n\tEnter Employee Id : ";
                    cin>>Id;

                    cout<<"\n\tEnter Employee Name : ";
                    cin>>name;
                    cout<<"\n\tEnter Employee Age : ";
                    cin>>Age;

                    cout<<"\n\tEnter Employee Salary : ";
                    cin>>Salary;
              }

              void PutData()           
              {
                    cout<<"\n"<<Id<<"\t"<<name<<"\t"<<Age<<"\t"<<Salary;
              }

       };


       int main()
       {

              Employee E[5];           
			int i;
              for(i=0;i<=5;i++)
              {
                    cout<<"\nEnter details of "<<i+1<<" Employee";
                    void GetData();
              }

              		cout<<"\nDetails of Employees";
              		for(i=0;i<=5;i++)
              		void PutData();

       }
