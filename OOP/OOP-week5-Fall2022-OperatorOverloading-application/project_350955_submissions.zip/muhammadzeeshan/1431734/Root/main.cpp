/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/


#include<stdio.h>
#include<iostream>
using namespace std;
class rational
{
         int numer;
         int denom;
         public:
         void getdata()
         {
                 cout<<"\n enter the numerator part of the rational no. :: ";
                 cin>>numer;
                 cout<<"\n enter the denominator part of the rational no. :: ";
                 cin>>denom;
         }
         void operator *(rational);
         void operator /(rational);
};
void rational ::operator *(rational c1)
 {
         rational temp;
         temp.numer=numer*c1.numer;
         temp.denom=denom*c1.denom;
         cout<<"\n rational no. after multiplication :: ";
         cout <<"\n numerator = "<<temp.numer<<"\n denominator = "<< temp.denom;
}
void rational :: operator /(rational c1)
{
         rational temp;
         temp.numer= numer*c1.denom;
         temp.denom=c1.numer*denom;
         cout<<"\n rational no. after dividation :: ";
         cout <<"\n numerator = "<<temp.numer<<"\n denominator = "<<temp.denom;
}
int main()
{

         rational c1, c2;
         int n;
         do
         {
                 cout<<"\n\n 1.Input data for rational no. ";
                 cout<<"\n 2. Multiplication of rational no.";
                 cout<<"\n 3. Division of rational no. ";
                 cout<<"\n\n Enter your choice :: ";
                 cin>>n;
                 switch(n)
                 {
                         case 1:
                         cout<<endl<<"\n enter the data for first rational no.:: ";
                         c1.getdata();
                         cout<<endl<<"\n enter the data for second rational no. :: ";
                         c2.getdata ();
                         break;

                        
                         case 2:
                         c1*c2;
                         break;

                         case 3:
                         c1/c2;
                         break;

                 }
         } while (n!=4);
         return 0;
}