/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
#include <string>
using namespace std;
class rational {
	public:
    float numerator,denominator;
    static int objectCounter;

    rational(float n=0, float d=0)
    {    
        numerator = n;
        denominator = d;
       objectCounter++;
    }
    
    
    rational(rational const &s1)
    {    
        numerator = s1.numerator ;
        denominator = s1.denominator;
        
    }
    void takeInput()
    {
        cout << "Enter Numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;

    }
    rational operator/(rational const& b)
    {
        rational multiply;
        multiply.numerator = numerator / b.numerator;
       multiply.denominator = denominator / b.denominator;
    

        return multiply;
    }
    rational operator*(rational const & b)
    {
        rational divide;
       divide.numerator = numerator * b.numerator;
        divide.denominator =denominator * b.denominator;
        return divide;
    }
    void Multiplication()
    {
        cout << "Multiplication  : " << numerator << "/" << denominator << endl;

    }
    void Division()
    {
        cout << "Division  : " << numerator <<"/" <<denominator<< endl;
        cout << "Total number of Objects in Programm : "<<objectCounter;

}
 
 

};
int rational::objectCounter = 0;

 

int main()
{
	int numerator, denominator;
    rational s1(numerator,denominator);
        s1.takeInput();
        rational s2 = s1;  
        s2.takeInput();   
       cout<<"_____________________"<<endl;
 	 if( s1.denominator==0||s2.denominator==0){
 	 	cout<<"\n\n";
	cout<<"\3\3 Denominator Cannot Be '0'\3\3";
}
else{
		
		rational s3 = s1 * s2;
        s3.Multiplication();
       s3= s1 / s2;
        s3.Division();
		
		
		
	}

 	
 
 
    return 0;
}