/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;
class Rationalnumbers
{
    private:
    int numinator;
    double denuminator;
    public:
    //static data function :
    static int objectCount;
    //parametrized connstructor:
    Rationalnumbers(int n=0,double d=0)
    {
        numinator=n;
        denuminator=d;
        //increasing data members:
        objectCount++;
    }
    //copy constructor:
    Rationalnumbers(const Rationalnumbers&n1)
    {
        numinator=n1.numinator;
        denuminator=n1.denuminator;
    }
    //operator overloading*:
    Rationalnumbers operator *(Rationalnumbers const &obj)
    {
        Rationalnumbers temp;
        temp.numinator=numinator*obj.numinator;
        temp.denuminator=denuminator*denuminator;
        return temp;
    }
     //operator overloading/:
    Rationalnumbers operator /(Rationalnumbers const &obj)
    {
        Rationalnumbers temp;
        temp.numinator=numinator/obj.numinator;
        temp.denuminator=denuminator/denuminator;
        return temp;
    }
   
    void display()
    {
        cout<<numinator/denuminator<<" "<<endl;
      cout<<  numinator*denuminator<<" "<<endl;
    }
};
int Rationalnumbers::objectCount = 0;

int main() {
  Rationalnumbers n1(3,5);
  Rationalnumbers n2=n1;
  Rationalnumbers n3=n1*n2;
  Rationalnumbers n4=n1/n2;
  
n3.display();


n4.display();

// Print total number of objects.
   cout << "Total objects: " << Rationalnumbers::objectCount << endl;
    return 0;
}

