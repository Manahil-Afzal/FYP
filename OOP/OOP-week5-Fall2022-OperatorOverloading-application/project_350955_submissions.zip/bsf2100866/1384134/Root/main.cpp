/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
# include<iostream>
using namespace std;
class rational
{
    private:
    int denominator,numerator;
    public:
    int s1,s2;
    //static data member
    static int objectCount;
    //parametrized constructor
    rational(int n=0, int d=0){
        numerator=n;
        denominator=d;
        objectCount++;
    }
   // copy constructor
    rational(rational const&A1){
        numerator=A1.numerator;
        denominator=A1.denominator;
    }
    //operator overloading
    rational operator /(rational const&R1){
        rational res;
        res.s1=(numerator/R1.numerator)/(denominator/R1.denominator);
       
        return res;
    }
    rational operator * (rational const &R2){
        rational temp;
        temp.s2=(numerator/R2.numerator)*(denominator/R2.denominator);
        
        return temp;
    }
    void print(){
        int a,b;
        cout<<"enter numerator value"<<endl;
        cin>>a;
        cout<<"enter denominator value"<<endl;
        cin>>b;
    }
    void display(){
        cout<<s1<<endl;}
        void output(){
        cout<<s2<<endl;
    }
};
int rational::objectCount=0;
int main(){
    int a,b;
    rational A1(a,b);
    A1.print();
    rational A2=A1;
    rational A3=A1/A2;
    A3.display();
    rational A4=A1*A2;
    
    A4.output();
    cout<<"total objects created are"<<rational::objectCount<<endl;
    return 0;
}
