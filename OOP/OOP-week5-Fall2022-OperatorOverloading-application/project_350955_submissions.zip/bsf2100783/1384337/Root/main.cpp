/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
#include <string>
using namespace std;

class rational {
private:
    float numerator,denominator;
    static int count;
public:
    rational(float n, float d)
    {    
        numerator = n;
        denominator = d;
        count++;
    }
    void takeInput()
    {
        cout << "Enter Numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;

    }
    rational operator/(rational& b)
    {
        rational multiply(0,0);
        multiply.numerator = this->numerator / b.numerator;
        multiply.denominator = this->denominator / b.denominator;
        return multiply;
    }
    rational operator*(rational& b)
    {
        rational multiply(0, 0);
        multiply.numerator = this->numerator * b.numerator;
        multiply.denominator = this->denominator * b.denominator;
        return multiply;
    }
    void Multiplication()
    {
        cout << "Multiplication  : " << numerator << "/" << denominator << endl;

    }
    void Division()
    {
        cout << "Division  : " << numerator <<"/" <<denominator<< endl;
        cout << "count : "<<count;

    }
    int Check() {
        if (denominator == 0) {
            cout << " value of denominator can't be zero";
            return 0;
        }
        return 1;
    }

};
int rational::count = 0;

int main()
{
    rational s1(0, 0);
        s1.takeInput();
        rational s2 = s1;
        s2.takeInput();
        if (s1.Check() ==1 && s2.Check()==1) {
            
        rational s3 = s1 * s2;
        s3.Multiplication();
        s3 = s1 / s2;
        s3.Division();
    }
 
    return 0;
}

