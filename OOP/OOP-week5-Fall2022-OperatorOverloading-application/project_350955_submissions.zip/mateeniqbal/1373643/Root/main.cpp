/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class RationalNumber{
	public:
		int denominator;
		int numenator;
		static int count;
		
		RationalNumber(){
			count++;
		}
		
		RationalNumber(int numenator,int denominator){
			this->numenator=numenator;
			this->denominator=denominator;
			if(denominator==0){
				cout<<"Denominator Cannot be Zero(0) \n";
				this->takeDenominator();
			}
			count++;
		}
		RationalNumber(RationalNumber &n){
			denominator=n.denominator;
			numenator=n.numenator;
			count++;
		}
		void takeDenominator(){
			cout<<"Enter Denominator";
			cin>>denominator;
		}
		void takeInput(){
			cout<<"Enter Numenator \n";
			cin>>numenator;
			this->takeDenominator();
			if(denominator==0){
				cout<<"Denominator Cannot be Zero(0) \n";
				this->takeDenominator();
			}
		}
		RationalNumber operator*(const RationalNumber &n){
			RationalNumber temp;
			temp.numenator=this->numenator*n.numenator;
			temp.denominator=this->denominator*n.denominator;
			return temp;
		}
		RationalNumber operator/(const RationalNumber &n){
			RationalNumber temp;
			temp.numenator=this->numenator*n.denominator;
			temp.denominator=this->denominator*n.numenator;
			return temp;
		
		}
		
};

int RationalNumber::count;
int main(){
	RationalNumber n1(5,8);
	RationalNumber n2(7,5);
	
	RationalNumber n3;
	n3=n1*n2;
	 RationalNumber n4;
	 n4=n1/n2;
	 
	 cout<<n3.numenator<<"/"<<n3.denominator<<"\n";
	 cout<<n4.numenator<<"/"<<n4.denominator<<"\n";
	 cout<<"Total="<<RationalNumber::count;
	 return 0;
}
