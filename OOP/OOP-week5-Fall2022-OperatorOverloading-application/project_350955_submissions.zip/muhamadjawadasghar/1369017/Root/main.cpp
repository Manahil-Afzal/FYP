/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream> 
using namespace std; 

class Rational 
{ 
    int numerator, denominator; 
    static int count; 
    public: 
        Rational() 
        { 
            count++; 
        } 
        Rational(int n, int d) 
        { 
            numerator = n; 
            denominator = d; 
            count++; 
        } 
        Rational(Rational &r) 
        { 
            numerator = r.numerator; 
            denominator = r.denominator; 
            count++; 
        } 
        void getdata(); 
        void display(); 
        friend Rational operator *(Rational, Rational); 
        friend Rational operator /(Rational, Rational); 
        static void showcount(); 
}; 
int Rational :: count = 0; 

void Rational :: getdata() 
{ 
    cout << "Enter numerator: "; 
    cin >> numerator; 
    do
    { 
        cout << "Enter denominator: "; 
        cin >> denominator; 
        if(denominator == 0) 
            cout << "Denominator can't be zero. Retry\n"; 
    }while(denominator == 0); 
} 

void Rational :: display() 
{ 
    cout << numerator << "/" << denominator; 
} 

void Rational :: showcount() 
{ 
    cout << "Total number of rational numbers: " << Rational :: count; 
} 

Rational operator *(Rational r1, Rational r2) 
{ 
    Rational result; 
    result.denominator = r1.denominator * r2.denominator; 
    result.numerator = (r1.numerator * r2.denominator) + (r2.numerator * r1.denominator); 
    return result; 
} 

Rational operator /(Rational r1, Rational r2) 
{ 

    Rational result; 
    
    result.denominator = r1.denominator * r2.numerator; 
    result.numerator = r1.numerator * r2.denominator; 
    return result;
	 
} 

int main() 
{ 
    Rational r1, r2, result; 
    r1.getdata(); 
    r2.getdata(); 
    cout << "Before multiplying and dividing: " << endl; 
    cout << "Rational number 1: "; 
    r1.display(); 
    cout << "\nRational number 2: "; 
    r2.display(); 
    cout << "Result of multiplication: "; 
    result = r1 * r2; 
    result.display(); 
    cout << "\nResult of division: "; 
    result = r1 / r2; 
    result.display(); 
    Rational :: showcount(); 
    return 0; 
}