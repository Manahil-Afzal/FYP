/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;

class bank_account {
private:
    string title;
    string type;
    float balance;
    float profit_percentage;
    string account_type;

public:
    void showdetails() {
        cout << "Enter the title of your bank: ";
        cin >> title;
        cout << "Enter the type of account: ";
        cin >> type;
        cout << "Enter the balance of account: ";
        cin >> balance;
        cout << "Enter the profit percentage of account: ";
        cin >> profit_percentage;
        cout << "Enter your account type (saving/psl): ";
        cin >> account_type;

        if (account_type == "saving") {
            balance += 0.05 * balance;
        }
        else if (account_type == "psl") {
            balance += 0.08 * balance;
        }

        cout << "Account details are as follows:" << endl;
        cout << "Title: " << title << endl;
        cout << "Type: " << type << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percentage: " << profit_percentage << "%" << endl;
    }
};

int main() {
    bank_account b;
    bank_account b2;

    cout << "Enter details for the first account:" << endl;
    b.showdetails();

    cout << "\nEnter details for the second account:" << endl;
    b2.showdetails();

}