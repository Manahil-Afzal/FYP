/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }

    
    void getInput() {
        cout << "Enter Account Title: ";
        cin.ignore(); 
        getline(cin, accountTitle);
        cout << "Enter Account Type (savings or PLS): ";
        cin >> accountType;
        cout << "Enter Initial Balance: ";
        cin >> balance;
    }


    void calculateBalance() {
        if (accountType == "savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        } else {
            cout << "Invalid account type!" << endl;
            return;
        }

        double profit = (profitPercent / 100) * balance;
        balance += profit;
    }

    
    void displayDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: $" << balance << endl;
    }
};

int main() {
    BankAccount account1, account2;

    
    cout << "Enter details for Account 1:" << endl;
    account1.getInput();
    account1.calculateBalance();

    
    cout << "\nEnter details for Account 2:" << endl;
    account2.getInput();
    account2.calculateBalance();

    cout << "\nAccount Details:" << endl;
    cout << "================" << endl;
    cout << "Account 1:" << endl;
    account1.displayDetails();

    cout << "\nAccount 2:" << endl;
    account2.displayDetails();

    return 0;
}
