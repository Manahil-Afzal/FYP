/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>

class Utility_Bill {
private:
    std::string customerName;
    int billNumber;
    int unitsConsumed;
    std::string customerAddress;

public:
    // Constructor to initialize the class members
    Utility_Bill(std::string name, int number, int units, std::string address)
        : customerName(name), billNumber(number), unitsConsumed(units), customerAddress(address) {
    }

    // Calculate and display the bill amount based on units consumed and per unit price
    void displayBill() {
        double perUnitPrice;

        if (unitsConsumed < 300) {
            perUnitPrice = 8.0;
        } else if (unitsConsumed < 1000) {
            perUnitPrice = 5.0;
        } else {
            perUnitPrice = 14.0;
        }

        double billAmount = unitsConsumed * perUnitPrice;

        std::cout << "Customer Name: " << customerName << std::endl;
        std::cout << "Bill Number: " << billNumber << std::endl;
        std::cout << "Units Consumed: " << unitsConsumed << std::endl;
        std::cout << "Customer Address: " << customerAddress << std::endl;
        std::cout << "Bill Amount: Rs. " << billAmount << std::endl;
    }
};

int main() {
    std::string name, address;
    int billNumber, unitsConsumed;

    std::cout << "Enter Customer Name: ";
    std::getline(std::cin, name);

    std::cout << "Enter Bill Number: ";
    std::cin >> billNumber;

    std::cout << "Enter Units Consumed: ";
    std::cin >> unitsConsumed;

    std::cin.ignore(); // Clear newline character from input buffer

    std::cout << "Enter Customer Address: ";
    std::getline(std::cin, address);

    // Create an instance of the Utility_Bill class
    Utility_Bill bill(name, billNumber, unitsConsumed, address);

    // Display the bill details and calculated amount
    bill.displayBill();

    return 0;
}