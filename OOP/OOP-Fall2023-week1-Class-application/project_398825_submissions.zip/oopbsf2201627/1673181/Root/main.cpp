/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include<iostream>
#include<string>
using namespace std;

class bankAccount{
    private:
        string accountTitle;
        string accountType;
        float balance;
        float profit_percent;
        float currentBalance;
    public:
        void set_info(){
            cout<<"Enter the Account Title: ";
            cin>>accountTitle;
            cout<<endl<<"Enter Account type: ";
            cin>>accountType;
            cout<<endl<<"Enter balance: ";
            cin>>balance;
            cout<<endl;
            
            if(accountType == "savings"){
                    profit_percent = 5;
            } else if(accountType == "PLS"){
                profit_percent = 8;
            } else{
                cout<<"Invalid Account Type is entered."<<endl;
            }
            
        currentBalance = balance + (balance * profit_percent/100);
        }
        
    void display_info(){
        cout<<"Account Title: "<<accountTitle<<endl<<"Account Type: "<<accountType<<endl<<"Balance: "<<balance<<endl<<"Profit Percent: "<<profit_percent<<endl<<"Current Balance: "<<currentBalance<<endl; 
    }
};

int main(){
    bankAccount b1;
    bankAccount b2;
    
    b1.set_info();
    b2.set_info();
    
    b1.display_info();
    b2.display_info();
    return 0;
}



