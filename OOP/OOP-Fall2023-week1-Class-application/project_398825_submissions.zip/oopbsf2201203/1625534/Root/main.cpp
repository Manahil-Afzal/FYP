/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include<iostream>
using namespace std;
int save, save1, pls, pls1;

class account{
	public:
		string accountTitle;
		int profit_percent, accountType, balance;
//	public:
  void input(){
  	cout<<"Enter datails of Account "<<endl;
  	cout<<"Enter Account Title"<<endl;
  	cin>>accountTitle;
  	cout<<"Account Type: Enter 1 for Saving & 2 for PLS"<<endl;
  	cin>> accountType;
  	cout<<"Enter Balance" <<endl;
  	cin>>balance;
  	cout<<"Enter Profit Percentage"<<endl;
  	cin>>profit_percent;
  
		}
		void currentBalance(){
			switch(accountType){
				case 1:
					{
					save = balance*5/100;
					save1=balance+save;

					}
					break;
				case 2:
					{
					pls = balance*8/100;
					pls1=pls+balance;
	
					}
					default:
						cout<<"wrong type";
				
			}
		}
		void display(){
			switch(accountType){
			
		case 1:
								cout<<"New Balance is : "<<save1;
								break;
		case 2:
								cout<<"New Balance is : "<<pls1;
								default:
									cout<<"End it";
}
}
};
int main()
{
	account acc1;
		acc1.input();
		acc1.currentBalance();
		acc1.display();
	}
   
