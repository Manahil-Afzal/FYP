/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include<iostream>
using namespace std;

class bankAccount
{
	private:
		string accountTitle;
		string accountType;
		int balance;
		float profitPercent;
	public:
		bankAccount() {
		accountTitle="";
		accountType="";
		balance=0.0;
		profitPercent=0.0;
}

void inputaccountDetails(){
	cout<<"Enter Account Title:"<<endl;
	cin>>accountTitle;
	cout<<"Enter Account Type (savings or PLS):"<<endl;
	cin>>accountType;
	cout<<"Enter Balance:"<<endl;
	cin>>balance;
	
if (accountType=="savings") {
	profitPercent=5.0;
	} else if (accountType=="PLS") {
		profitPercent=8.0;
	} else {
		cout<<"Invalid account type."<<endl;
	}
}
	void calculateBalance(){
	
	double profitAmount=(balance * profitPercent)/100;
	balance+=profitAmount;
}
    void showaccountDetails()
	{
    	cout<<"Account Details:"<<endl;
    	cout<<"Account Title:"<<accountTitle<<endl;
    	cout<<"Account Type:"<<accountType<<endl;
    	cout<<"Balance:"<<balance<<endl;
	}
};

int main()
{
	bankAccount account1, account2;
	cout<<"Enter details for account 1:"<<endl;
	account1.inputaccountDetails();
	account1.calculateBalance();
	
	cout<<"Enter details for account 2:"<<endl;
	account2.inputaccountDetails();
	account2.calculateBalance();
	
	cout<<"Account Information"<<endl;
	account1.showaccountDetails();
	account2.showaccountDetails();
	return 0;
}