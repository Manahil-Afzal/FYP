/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bank_account{
	private:
	string account_title;
	int account_type;
	long balance;
	float profit_percet;
	public:
		void userinput();
		void add_profit();
		void showdetails();
};
int main()
{
	bank_account obj[2];
	for(int i=0;i<2;i++)
	{
		obj[i].userinput();
		obj[i].add_profit();
		obj[i].showdetails();
	}
}
void bank_account::userinput()
{
	cout<<"ENTER TITLE OF ACCOUNT:"<<endl;
	cin>>account_title;
	cout<<"ENTER TYPE OF ACCOUNT:"<<endl;
	cout<<"1.saving"<<endl;
	cout<<"2.PSL:"<<endl;
	cin>>account_type;
	cout<<"ENTER BALANCE:"<<endl;
	cin>>balance;
}
void bank_account::add_profit()
{
   if(account_type==1)
   {
   	cout<<"******SAVING ACCOUNT******"<<endl;
   	profit_percet=balance+(balance/100*5);
   }else if(account_type==2)
   {
   	cout<<"************PSL ACCOUNT***********"<<endl;
   	profit_percet=balance+(balance/100*8);
   }else 
   cout<<"invalid condition"<<endl;
}
void bank_account::showdetails()
{
	cout<<"ACCOUNT TITLE:"<<account_title<<endl;
	cout<<"ACCOUNT TYPE:"<<account_type<<endl;
	cout<<"USER BALANCE:"<<balance<<endl;
	cout<<"CURRENT BALANCE:"<<profit_percet<<endl;
	cout<<endl;
}