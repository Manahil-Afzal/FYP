/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
class bankaccount {
    private:
    string accounttitle;
    string accounttype;
    double balance;
    double profit_percent ;
    
    public:
     
    void getdetail();
    void putdetail();
    int calculationdetail();
};
void bankaccount :: getdetail(){
    
    cout<<"Enter Your account title is : ";
    cin>>accounttitle;
    
    cout<< "Enter your account type : ";
    cin>>accounttype;
    
    cout<<" Enter your balance : ";
    cin>>balance; 

}
    int bankaccount :: calculationdetail()
  { if (accounttype == "Savings") {
            profit_percent = 5.0;
            return profit_percent =balance/5*100;
        } else if (accounttype == "PLS") {
            profit_percent = 8.0;   
            return profit_percent = balance/8*100;
            
        } else {
            cout << "Invalid account type. Setting profit percent to 0%" << endl;
            profit_percent = 0.0;
        }
    
      
    }
void bankaccount :: putdetail(){
    cout<<"Your bank account tilte is : "<<accounttitle<<endl;
    cout<<" your bank account type is : "<<accounttype<<endl;
    cout<<"your balance is : "<<balance<<endl;
    cout<<"balance after profit : "<<profit_percent<<endl;
}
  main()
  {
      bankaccount a1,a2;
      a1.getdetail();
      a1.putdetail();
      a1.calculationdetail();
  
      a2.getdetail();
      a2.putdetail();
      a2.calculationdetail();
  }
