/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>

class BankAccount {
private:
    std::string accountTitle;
    std::string accountType;
    double balance;
    double profitPercent;

public:
    // Method to input account details from the user
    void inputAccountDetails() {
        std::cout << "Enter Account Title: ";
        std::cin >> accountTitle;
        std::cout << "Enter Account Type (savings/pls): ";
        std::cin >> accountType;
        std::cout << "Enter Initial Balance: ";
        std::cin >> balance;
        std::cout << "Enter Profit Percentage: ";
        std::cin >> profitPercent;
    }

    // Method to calculate current balance based on account type
    void calculateCurrentBalance() {
        if (accountType == "savings") {
            balance += (balance * (profitPercent / 100));
        } else if (accountType == "pls") {
            balance += (balance * (profitPercent / 100));
        }
    }

    // Method to display account details
    void displayAccountDetails() {
        std::cout << "Account Title: " << accountTitle << std::endl;
        std::cout << "Account Type: " << accountType << std::endl;
        std::cout << "Current Balance: $" << balance << std::endl;
    }
};

int main() {
    // Creating two objects of BankAccount class
    BankAccount account1, account2;

    // Input details for both accounts
    std::cout << "Enter details for Account 1:\n";
    account1.inputAccountDetails();
    account1.calculateCurrentBalance(); // Calculate balance based on account type

    std::cout << "\nEnter details for Account 2:\n";
    account2.inputAccountDetails();
    account2.calculateCurrentBalance(); // Calculate balance based on account type

    // Display account details
    std::cout << "\nAccount 1 Details:\n";
    account1.displayAccountDetails();

    std::cout << "\nAccount 2 Details:\n";
    account2.displayAccountDetails();

    return 0;
}
