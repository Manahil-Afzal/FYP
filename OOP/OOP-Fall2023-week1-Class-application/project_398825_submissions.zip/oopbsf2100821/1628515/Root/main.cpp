/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
class bankaccount{
    private:
    string account_title;
    string account_type;
    int balance;
    float profit_per;
    public:
       void  getdetails();
        void putdetails();
    };
   void  bankaccount::getdetails(){
       
   	    cout<<"enter ";
        cin>>account_title>>account_type>>balance;
        if(account_type=="saving"){
		
        	profit_per=balance/100*5;
        	balance=balance+profit_per;
		}else if(account_type=="pls"){
		
			profit_per=balance/100*8;
			balance=balance+profit_per;
			
		}else{
			cout<<"invalid type";
		}
        
    };
    void bankaccount::putdetails(){
       cout<<"Account Title="<<account_title<<"Account type= "<<account_type<<account_type<<"Balance="<<balance;
    };


int main()
{
bankaccount myobj;
myobj.getdetails();
myobj.putdetails();
}