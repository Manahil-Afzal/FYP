/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bank_account
{
	private:
		string account_tittle;
		int account_type;
		int balance;
		float profit_percent;
		public:
void getDetails()
{
	cout<<"Enter the account tittle:"<<endl;
	cin>>account_tittle;
	cout<<"Select the account type:"<<endl;
	cout<<"1.saving account:"<<endl;
	cout<<"2.PSL:"<<endl;
	cin>>account_type;
	cout<<"Enter the amount:"<<endl;
	cin>>balance;
}
void add_profit()
{
	if(account_type==1)
	{
	cout<<" saving account"<<endl;
	profit_percent=balance+(balance/100*5);
	}
	else if(account_type==2)
	{
		cout<<"PSL account"<<endl;
		profit_percent=balance+(balance/100*8);
	}else
	cout<<"invalid condition"<<endl;
	
}
void showDetails()
{
	cout<<"Account Titte"<<account_tittle<<endl;
	cout<<"Account Type"<<account_type<<endl;
	cout<<" The balance is"<<balance<<endl;
	cout<<"current balance is"<<profit_percent<<endl;
		
}
};
int main()
{
bank_account obj1;
bank_account obj2;
obj1.getDetails();
obj1.add_profit();
obj1.showDetails();
obj2.getDetails();
obj2.add_profit();
obj2.showDetails();
return 0;
}



