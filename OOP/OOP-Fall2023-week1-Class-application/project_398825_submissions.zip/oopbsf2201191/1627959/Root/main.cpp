/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bank_account
{
  public:
     string account_title;
     string account_type;
     int balance;
     float profit_percent;
     
     void input();
     void calculate();
     void display();
     
};

void bank_account::input(){
  
      cout<<"enter the account title:"<<endl;
      cin>>account_title;
      cout<<"enter the account type"<<endl;
      cin>>account_type;
      cout<<"enter the current balance"<<endl;
      cin>>balance;
      if(account_type=="savings"){
          profit_percent = 5;
      }else if(account_type=="PSL"){
          profit_percent = 8;
      }
}


    void bank_account::calculate(){
        
        float profit=(balance*profit_percent)/100;
        balance += profit;
        
}
    void bank_account::display(){
        cout<<"account title:"<<account_title<<endl;
        cout<<"accout type:"<<account_type<<endl;
        cout<<"balance:"<<balance<<endl;
        
    }
    
int main()
{
    bank_account obj1,obj2;
    obj1.input();
    obj1.calculate();
    obj1.display();
    cout<<"abdullah";

    obj2.input();
    obj2.calculate();
    obj2.display();
    cout<<"ali";
return 0;    
    
}