/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class Bankaccount{
    string accountTitle;
    string accountType;
    float balence;
    float profit;
    public:
    void input();
    void calculation();
    void display();
};
int main (){
    Bankaccount user1;
     user1.input();
     user1.calculation();
     user1.display();
}
void Bankaccount:: input(){
    cout<<"enter the account tittle "<<endl;
    cin>>accountTitle;
    cout<<"enter the account type (saving or PLS )"<<endl;
    cin>>accountType;
    cout<<"enter your balence "<<endl;
    cin>>balence;
}
void Bankaccount:: calculation(){
    if(accountType=="saving"){
        profit=balence*5/100;
    }
    else{
        profit=balence*8/100;
    }
}
void Bankaccount::display(){
    cout<<"Your account tittle is "<<accountTitle<<endl;
    cout<<"your account type is "<<accountType<<endl;
    cout<<"Your balence is "<<balence<<endl;
    cout<<"According to your profit type "<<profit+1<<endl;
}