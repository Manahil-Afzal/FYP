/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both.*/
#include<iostream>
using namespace std;

class bankAccount{
         string accountTitle;
         string accountType;
         float balance;
         float profit;
    public:
        void input();
        void calculation();
        void display();
};

int main(){
    bankAccount user1;
    
    user1.input();
user1.input();
    user1.calculation();
    user1.display();
}

void bankAccount:: input(){
    cout<<"Enter the account title "<<endl;
    cin>>accountTitle;
    cout<<"Enter the account type (saving or PLS) "<<endl;
    cin>>accountType;
    cout<<"Enter your balance "<<endl;
    cin>>balance;
}

void bankAccount:: calculation(){
    if(accountType=="saving"){
        profit = balance*5/100;
    }else{
        profit = balance*8/100;
    }
}

void bankAccount :: display(){
    cout<<"Your account title is "<< accountTitle<<endl;
    cout<<"Your account type is "<<accountType<<endl;
    cout<<"Your balance is "<<balance<<endl;
    cout<<"Your profit according to your account type is "<<profit<<endl;
}