/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class BankAccount{
    string title;
    string accountType;
    float balance;
    float profit;
    public:
    void input();
    void display();
    void calcul();
};
int main (){
  BankAccount user2;
  user2.input();
  user2.calcul();
  user2.display();
}
void BankAccount::input(){
    cout<<"enter your account tittle "<<endl;
    cin>>title;
    cout<<"enter account type(saving or pls) "<<endl;
    cin>>accountType;
    cout<<"enter your balance "<<endl;
    cin>>balance;
}
void BankAccount ::calcul(){
    if(accountType =="saving"){
        profit=balance*5/100;
    }
    else{
        profit=balance*8/100;
    }
}
void BankAccount ::display(){
    cout<<"accunt type is "<<accountType <<endl;
    cout<<"your account tottle is "<<title<<endl;
    cout<<"your balence is "<<balance<<endl;
    cout<<"your profit accounding to yor account type "<<profit<<endl;
}
