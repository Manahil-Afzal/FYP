/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
class bank_acc{
    private:
    string accountTitle, accountType;
    int balance, profitPercent;
    public:
    void getinfo();
    void showinfo();
    
};
    void bank_acc::getinfo(){
        cout<<"Enter the following data:\n"<<"Account Title:";
        cin>>accountTitle;
        cout<<"\n Account Type(Saving or PLS/(profit and loss sharing)?):\n";
        cin>>accountType;
        cout<<"\n Balance: \n";
        cin>>balance;
        if (accountType=="saving"){
            profitPercent=(balance/100)*5;
            balance+=profitPercent;
        }
        else if (accountType=="PLS"||accountType=="pls"||accountType=="profit and loss sharing"){
            profitPercent=(balance/100)*8;
            balance+=profitPercent;
        }
        else{
            cout<<"Account type not supported!";
        }
    };
    
    void bank_acc::showinfo(){
        cout<<"Results:\n"<<"Account Title: "<<accountTitle<<"\nAccount Type: "<<accountType<<"\n Current Balance* "<<balance;
    };
    
    
    int main(){
     bank_acc user1;
     user1.getinfo();
     user1.showinfo();
     
        
        
    }