
#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Constructor to initialize data members
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }

    // Method to input account details from the user
    void inputAccountDetails() {
        cout << "Enter Account Title: ";
        cin.ignore(); // Ignore any previous newline character
        getline(cin, accountTitle);

        cout << "Enter Account Type (savings or PLS): ";
        cin >> accountType;

        cout << "Enter Initial Balance: ";
        cin >> balance;
    }

    // Method to calculate current balance with profit
    void calculateCurrentBalance() {
        if (accountType == "savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        } else {
            cout << "Invalid account type." << endl;
            return;
        }

        double profitAmount = (profitPercent / 100) * balance;
        balance += profitAmount;
    }

    // Method to display account details
    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;}