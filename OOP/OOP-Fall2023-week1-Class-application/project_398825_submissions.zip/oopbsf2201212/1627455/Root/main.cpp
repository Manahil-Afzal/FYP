/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>

using namespace std;

class BankAccount {
public:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

    void inputData() {
        cout << "Enter Account Title: ";
        cin >> accountTitle;

        cout << "Enter Account Type (Savings or PLS): ";
        cin >> accountType;

        cout << "Enter Balance: ";
        cin >> balance;

        cout << "Enter Profit Percent: ";
        cin >> profitPercent;
    }

    void calculateBalance() {
        if (accountType == "Savings") {
            balance += 0.05 * balance;
        } else if (accountType == "PLS") {
            balance += 0.08 * balance;
        }
    }

    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" << endl;
    account1.inputData();
    account1.calculateBalance();

    cout << "\nEnter details for Account 2:" << endl;
    account2.inputData();
    account2.calculateBalance();

    cout << "\nAccount 1 Details:" << endl;
    account1.displayAccountDetails();

    cout << "\nAccount 2 Details:" << endl;
    account2.displayAccountDetails();

    return 0;
}