/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
#include <string>

class BankAccount {
private:
    std::string accountTitle;
    std::string accountType;
    double balance;
    double profitPercent;

public:
    // Constructor to initialize the class members
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }

    // Method to take input for data members
    void inputData() {
        std::cout << "Enter Account Title: ";
        std::cin.ignore();
        std::getline(std::cin, accountTitle);

        std::cout << "Enter Account Type (savings or PLS): ";
        std::cin >> accountType;

        std::cout << "Enter Initial Balance: ";
        std::cin >> balance;

        // Set profit percentage based on account type
        if (accountType == "savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        } else {
            std::cerr << "Invalid account type. Using default profit percentage of 0%." << std::endl;
        }
    }

    // Method to calculate current balance with profit
    void calculateBalance() {
        double profitAmount = (balance * profitPercent) / 100.0;
        balance += profitAmount;
    }

    // Method to display account details
    void displayAccountDetails() {
        std::cout << "Account Title: " << accountTitle << std::endl;
        std::cout << "Account Type: " << accountType << std::endl;
        std::cout << "Current Balance: $" << balance << std::endl;
        std::cout << "Profit Percentage: " << profitPercent << "%" << std::endl;
    }
};

int main() {
    BankAccount account1, account2;

    std::cout << "Enter details for Account 1:" << std::endl;
    account1.inputData();
    account1.calculateBalance();

    std::cout << "\nEnter details for Account 2:" << std::endl;
    account2.inputData();
    account2.calculateBalance();

    std::cout << "\nAccount Details for Account 1:" << std::endl;
    account1.displayAccountDetails();

    std::cout << "\nAccount Details for Account 2:" << std::endl;
    account2.displayAccountDetails();

    return 0;
}