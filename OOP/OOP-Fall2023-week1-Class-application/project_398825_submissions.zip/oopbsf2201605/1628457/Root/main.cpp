/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Constructor to initialize data members
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }

    // Method to take input for data members
    void inputData() {
        cout << "Enter Account Title: ";
        cin.ignore();
        getline(cin, accountTitle);

        cout << "Enter Account Type (Savings/PLS): ";
        cin >> accountType;

        cout << "Enter Initial Balance: ";
        cin >> balance;

        cout << "Enter Profit Percent: ";
        cin >> profitPercent;
    }

    // Method to calculate current balance
    void calculateBalance() {
        if (accountType == "Savings") {
            double profit = (balance * profitPercent) / 100.0;
            balance += profit;
        } else if (accountType == "PLS") {
            double profit = (balance * profitPercent) / 100.0;
            balance += profit;
        }
    }

    // Method to display account details
    void displayAccountDetails() {
        cout << "\nAccount Details:\n";
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << " PKR" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter Details for Account 1:\n";
    account1.inputData();
    account1.calculateBalance();

    cout << "\nEnter Details for Account 2:\n";
    account2.inputData();
    account2.calculateBalance();

    cout << "\nDisplaying Account Details:\n";
    account1.displayAccountDetails();
    account2.displayAccountDetails();

    return 0;
}