/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts*/
#include <iostream>
using namespace std;
class BankAccount {
    string accountTitle;
    string accountType;
    int balance;
    float profitPercent;
    public:
     // Method to take input for data members from the user
    void inputData() {
    cout << "Enter account title: ";
    cin >> accountTitle;
    cout << "Enter account type (savings/PLS): ";
        cin >> accountType;
        cout << "Enter balance: ";
        cin >> balance;
        // Set profit percent based on account type
        if (accountType == "savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        } 
    }

    // Method to calculate current balance including profit
    void calculateBalance() {
        float profit = (balance * profitPercent) / 100.0;
        balance += profit;
    }

    // Method to display account details
    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: $" << balance << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" <<endl;
    account1.inputData();
    account1.calculateBalance();

    cout << "Enter details for Account 2:" << endl;
    account2.inputData();
    account2.calculateBalance();

    cout << "Account 1:" << endl;
    account1.displayAccountDetails();
    cout << "Account 2:" <<endl;
    account2.displayAccountDetails();

    return 0;
}