/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/#include<iostream>
using namespace std;

class BankAccount{
    public:
            string accountTitle;
            string accountType;
            double balance;
            double profitPercent;
            
    void inputAccountDetails() {
        cout<<"enter account title: ";
        cin>>accountTitle;
        cout<<"enter account type: ";
        cin>>accountType;
        cout<<"enter balance: ";
        cin>>balance;
        cout<<"enter profit percentage: ";
        cin>>profitPercent;
    }
    
    void currentBalance(){
        if(accountType=="saving account"){
             balance += (balance * (profitPercent / 100.0));
        }
        else if(accountType=="PLS"){
            balance += (balance * (profitPercent / 100.0));
        }
		}
    
    void displayAccountDetails(){
    	cout<<"accountTitle: "<<accountTitle<<endl;
    	cout<<"accountType: "<<accountType<<endl;
    	cout<<"balance: "<<balance<<endl;
    	cout<<"profitPercentage: "<<profitPercent<<"%"<<endl;
    	
	}
    
        
        
    
};
int main(){

    BankAccount account1, account2;
    cout << "Enter details for Account 1:" << endl;
    account1.inputAccountDetails();
    account1.currentBalance();

    cout << "Enter details for Account 2:" << endl;
    account2.inputAccountDetails();
    account2.currentBalance();

   cout << "\naccount1 Details:" << endl;
    account1.displayAccountDetails();

    cout << "\naccount2 Details:" << endl;
    account2.displayAccountDetails();
    
    
}
  
