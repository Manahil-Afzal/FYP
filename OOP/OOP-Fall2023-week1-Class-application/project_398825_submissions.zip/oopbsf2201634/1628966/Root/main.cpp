/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include<string>


using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
   
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }

    // Method to take input for data members from the user
    void inputAccountDetails() {
        cout << "Enter Account Title: ";
        cin.ignore();
        getline(cin, accountTitle);

        cout << "Enter Account Type (Savings or PLS): ";
        cin >> accountType;

        cout << "Enter Balance: ";
        cin >> balance;

        
        if (accountType == "Savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        }
    }

    //calculate current balance including profit
    void calculateCurrentBalance() {
        double profitAmount = (balance * profitPercent) / 100.0;
        balance += profitAmount;
    }

    // Method to display account details
    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    // Create two objects of the BankAccount class
    BankAccount account1, account2;

    // Input details for both accounts
    cout << "Enter details for Account 1:" << endl;
    account1.inputAccountDetails();
    cout << "Enter details for Account 2:" << endl;
    account2.inputAccountDetails();

    // Calculate current balance for both accounts
    account1.calculateCurrentBalance();
    account2.calculateCurrentBalance();

    // Display account details for both accounts
    cout << "\nAccount 1 Details:" << endl;
    account1.displayAccountDetails();
    cout << "\nAccount 2 Details:" << endl;
    account2.displayAccountDetails();

    return 0;
}