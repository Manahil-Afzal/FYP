/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
#include<string>
using namespace std;

class Bank{
    private:
    string accountTitle;
    string accountType;
    float balance;
    float profit_percent;
    float profit;
    float existing_amount;

    public:
    Bank(){
        accountTitle="";
        accountType="";
        balance=0.0;
        profit_percent=0.0;
        profit=0.0;
        existing_amount=0.0;
    }
    void getDetails(){
    cout<<"Enter the account Title:"<<endl;
    cin>>accountTitle;
    cout<<"Enter the balance"<<endl;
    cin>>balance;
    cout<<"Enter the type of your account ( Enter Sharings or PLS):"<<endl;
    cin>>accountType;
    if(accountType=="Sharings"){
        profit_percent=5;
    }else if(accountType=="PLS"){
        profit_percent=8;
    }else{
        cout<<"Invalid input";
        }}
    
    void calculate(){
    profit=(balance*profit_percent)/100;
    balance+=profit;
        
    }
    

void displayDetails(){
    cout<<"The account title:"<<accountTitle<<endl;
    cout<<"Account type:"<<accountType<<endl;;
    cout<<"Existing Balance"<<balance<<endl;
        }
        
   
    
};


int main(){
    Bank b1,b2;
    cout<<"Enter Details for Account 1:"<<endl;
    b1.getDetails();
    b1.calculate();
    cout<<"Enter Details for Account 2:"<<endl;
    b2.getDetails();
    b2.calculate();
    
    cout<<"Displaying Details:"<<endl;
    b1.displayDetails();
    b2.displayDetails();
    
    
return 0;
    
    
}        
        