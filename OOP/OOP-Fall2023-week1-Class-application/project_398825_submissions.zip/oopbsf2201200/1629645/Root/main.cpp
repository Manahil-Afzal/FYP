/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankaccount{
	private:
		string account_title;
		string saving,pls;
		string accounttype;
		long balance;
		int profit;
		public:
	void		input1();
		void	output1();
void loop1();
			void	input2();
			void output2();
void loop2();
			
};
int main(){

bankaccount bk1;
bankaccount bk2;
bk1.input1();
bk1.output1();
bk1.loop1();
bk1.loop2();
bk2.input2();
bk2.output2();
}
void bankaccount::input1(){
	cout<<"Account title :"<<endl;
	cin>>account_title;
		cout<<"Account type :"<<endl;
	cin>>accounttype;
		cout<<"balance :"<<endl;
	cin>>balance;
	//	cout<<"Account title :"<<endl;
	//cin>>account_title;
	
}

void bankaccount::loop1(){
	if(accounttype == "saving"){
		profit=balance*5/100;
//		cout<<"current balance = "<<balance*profit; 
	}
	else if(accounttype=="pls"){
		profit=balance*8/100;
		//cout<<"current balance = "<<balance*profit; 
	}
}
void bankaccount::output1(){
	cout<<"The details of the user 01 are given below. \n";
	cout<<"Account title is :"<<account_title<<endl;
		cout<<"Account type is :"<<accounttype<<endl;
			cout<<"Balance :"<<balance<<endl;
cout<<"Current balance: "<<balance+profit<<endl;
}
void bankaccount::input2(){
    cout<<"please enter the details of second user:\n ";
	cout<<"Account title :"<<endl;
	cin>>account_title;
		cout<<"Account type :"<<endl;
	cin>>accounttype;
		cout<<"balance :"<<endl;
	cin>>balance;
	//	cout<<"Account title :"<<endl;
	//cin>>account_title;
	
	
}
void bankaccount::loop2(){
	if(accounttype=="saving"){
		profit=balance*5/100;
//		cout<<"current balance = "<<profit; 
	}
	else if(accounttype=="pls"){
		profit=balance*8/100;
//		cout<<"current balance = "<<balance*profit; 
	}
}
void bankaccount::output2(){
	cout<<"The details of the user 02 are given below. \n";
	cout<<"Account title is :"<<account_title<<endl;
		cout<<"Account type is :"<<account_title<<endl;
			cout<<"Balance :"<<balance<<endl;
cout<<"Current balance: "<<balance+profit<<endl;
}