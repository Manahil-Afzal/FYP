#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
   
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }


    void inputAccountDetails() {
        cout << "Enter Account Title: ";
        cin.ignore();
        getline(cin, accountTitle);
        cout << "Enter Account Type (Savings/PLS): ";
        cin >> accountType;
        cout << "Enter Initial Balance: ";
        cin >> balance;
        cout << "Enter Profit Percent: ";
        cin >> profitPercent;
    }

  
    void calculateCurrentBalance() {
        if (accountType == "Savings") {
            balance += (balance * (profitPercent / 100.0));
        } else if (accountType == "PLS") {
            balance += (balance * (profitPercent / 100.0));
        }
    }

   
    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1: " << endl;
    account1.inputAccountDetails();
    account1.calculateCurrentBalance();

    cout << "\nEnter details for Account 2: " << endl;
    account2.inputAccountDetails();
    account2.calculateCurrentBalance();

    cout << "\nAccount Details for Account 1: " << endl;
    account1.displayAccountDetails();

    cout << "\nAccount Details for Account 2: " << endl;
    account2.displayAccountDetails();

    return 0;
}