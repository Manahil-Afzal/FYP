/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class BankAccount{
    private:
    string account_title;
    string account_type;
    int balance;
    int current_balance;
    float profit_percent;
    public:
    void getdata();
    void putdata();
};
void BankAccount::getdata(){
    cout<<"Enter account title";
    cin>>account_title;
    cout<<"Enter account type";
    cin>>account_type;
    cout<<"Enter balance";
    cin>>balance;
}
void BankAccount::putdata(){
    cout<<"Account Title :"<<account_title<<endl<<"Account Type :"<<account_type<<endl<<"Balance :"<<balance<<endl;
    if(account_type=="saving"){
    profit_percent=0.05*balance;
    current_balance=profit_percent+balance;
    cout<<"Current balance :"<<current_balance<<endl;
    }
    else if(account_type=="pls")
    {
    profit_percent=0.08*balance;
    current_balance=profit_percent+balance;
    cout<<"Current balance :"<<current_balance<<endl;
    }
    else{
    cout<<"Invalid account type"<<endl;
    }
}
int main()
{
    BankAccount account1, account2;
    account1.getdata();
    account1.putdata();
    account2.getdata();
    account2.putdata();
    return 0;
}
    

