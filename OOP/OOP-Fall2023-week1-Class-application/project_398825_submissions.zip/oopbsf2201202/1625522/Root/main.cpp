#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    BankAccount() : balance(0), profitPercent(0) {}

    void inputData() {
        cout << "Enter Account Title: ";
        cin.ignore();
        getline(cin, accountTitle);
        cout << "Enter Account Type (savings/pls): ";
        cin >> accountType;
        cout << "Enter Initial Balance: ";
        cin >> balance;
        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * profitPercent / 100);
        } else if (accountType == "pls") {
            balance += (balance * profitPercent / 100);
        }
    }

    void displayAccountDetails() {
        cout << "\nAccount Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" << endl;
    account1.inputData();
    account1.calculateBalance();

    cout << "\nEnter details for Account 2:" << endl;
    account2.inputData();
    account2.calculateBalance();

    cout << "\nAccount Details for Account 1:" << endl;
    account1.displayAccountDetails();

    cout << "\nAccount Details for Account 2:" << endl;
    account2.displayAccountDetails();

    return 0;
}
