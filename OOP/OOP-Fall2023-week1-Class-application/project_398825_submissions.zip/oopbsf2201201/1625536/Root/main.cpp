/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;


class bankaccount{
    private:
    string accounttitle;
    string accounttype;
    double balance;
    double profitpercent;
    
    
    public:
    void getdetails(){
        cout<<"enter accounte title";
        cin>>accounttitle;
        cout<<"enter account type";
        cin>>accounttype;
        cout<<"enter balance";
        cin>>balance;
    }
    
    
    void calculatebalance(){
        if(accounttype=="savings"){
            profitpercent=5;
        }else if(accounttype=="profit loss sharing"){
            profitpercent=8;
        }
        double profit=(profitpercent/100)*balance;
        balance+=profit;
    }
    
    void displaydetails(){
        cout<<"account details";
        cout<<"accounttitle"<<accounttitle;
        cout<<"accounttype"<<accounttype;
        cout<<"balance"<<balance;
    }
};
int main(){
    bankaccount account1,account2;
    cout<<"enter details for acciunt1";
    account1.displaydetails();
    account1.calculatebalance();
    
    
    cout<<"enter details for account 2";
    account2.displaydetails();
    account2.calculatebalance();
    
    account1.displaydetails();
    account2.displaydetails();
    return 0;
}
    
