/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bnkacc{
	
	string acctitle;
	string acctype;
	float blnc;
	float prft;
	float crntblnc;
	
	public:
		void input();
		void calculation();
		void display();
};
 
  int main()
  {
  	bnkacc bnkacc1;
  	bnkacc1.input();
  	bnkacc1.calculation();
  	bnkacc1.display();
  	return 0;
  }
  	void bnkacc :: input(){
  	
  		cout<<"bnkacc1 title :";
  cin>>acctitle;
  	cout<<"bnkacc1 type (saving or PLS):";
  	cin>>acctype;
  	cout<<"bnkacc1 balance :";
  	cin>>blnc;
  }
  void bnkacc :: calculation(){
  
  	if(acctype=="saving")
	  {
  		prft=blnc*5/100;
  		cout<<"profit :"<<prft<<endl;
  		crntblnc=blnc+prft;
  		cout<<"current balance : "<<crntblnc<<endl;
}
if(acctype=="PLS")
{
	prft=blnc*8/100;
	cout<<"profit :"<<prft<<endl;
	crntblnc=blnc+prft;
	cout<<"current balnce : "<<crntblnc<<endl;
}
}

	  void bnkacc :: display(){
	  	cout<<"account title :"<<acctitle<<endl<<"account type :"<<acctype<<endl<<"balance :"<<blnc<<endl<<" profit is :"<<prft<<endl;
	  	
	  	cout<<"current balance after profit is : "<<crntblnc;
	  }

  
  
  
  
  
