/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>

class BankAccount {
private:
    std::string accountTitle;
    std::string accountType;
    double balance;
    double profitPercent;

public:
    
    BankAccount() {
        accountTitle = "";
        accountType = "";
        balance = 0.0;
        profitPercent = 0.0;
    }

    
    void inputAccountDetails() {
        std::cout << "Enter Account Title: ";
        std::cin >> accountTitle;
        std::cout << "Enter Account Type (Savings or PLS): ";
        std::cin >> accountType;
        std::cout << "Enter Balance: ";
        std::cin >> balance;
        
        if (accountType == "Savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        }
    }

    
    void calculateBalanceWithProfit() {
        double profitAmount = (profitPercent / 100) * balance;
        balance += profitAmount;
    }

    
    void displayAccountDetails() {
        std::cout << "Account Title: " << accountTitle << std::endl;
        std::cout << "Account Type: " << accountType << std::endl;
        std::cout << "Current Balance: " << balance << std::endl;
    }
};

int main() {
    
    BankAccount account1, account2;

    
    std::cout << "Enter details for Account 1:" << std::endl;
    account1.inputAccountDetails();
    account1.calculateBalanceWithProfit();

    std::cout << "Enter details for Account 2:" << std::endl;
    account2.inputAccountDetails();
    account2.calculateBalanceWithProfit();

    
    std::cout << "\nAccount Details for Account 1:" << std::endl;
    account1.displayAccountDetails();

    std::cout << "\nAccount Details for Account 2:" << std::endl;
    account2.displayAccountDetails();

    return 0;
}