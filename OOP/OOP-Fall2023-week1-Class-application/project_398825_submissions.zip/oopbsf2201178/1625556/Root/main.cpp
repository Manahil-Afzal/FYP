/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
class Account {
  private:
  string account_title;
  string account_type;
  int balance;
  float profit_percent;
  public:
  void Getdetail();
  void Putdetail();
  int current_balance_profit();
};
void Account::Getdetail(){
    cout<<"Enter the account title";
    cin>>account_title;
    cout<<"Enter the Account type";
    cin>>account_type;
    cout<<"Enter the currrent balancein your account";
    cin>>balance;
}
void Account::Putdetail(){
    
    cout<<"Your bank title is :"<<account_title<<endl;
    cout<<"Your bank account type is :"<<account_type<<endl;
    cout<<"Your current balance is :"<<balance<<endl;
    cout<<"The Current balance after adding profit to it :"<<profit_percent<<endl;
}
int Account ::current_balance_profit(){
    if(account_type=="saving"||"SAVING"){
    return   profit_percent=balance/5*100;
    }else if(account_type=="pls"||"PLS"){
    return    profit_percent=balance/8*100;
    }else
    cout<<"invalid type of account"<<endl;
}
main(){
    Account a1,a2;
    a1.Getdetail();
    a1.current_balance_profit();
    
    a2.Getdetail();
    a2.current_balance_profit();
    a1.Putdetail();
    cout<<"---------------------------------------------------"<<endl;
    a2.Putdetail();
}