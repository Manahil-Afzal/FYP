/* identify and correct errors. Also comment the identified error*/
 #include <iostream>
using namespace std;

class Person
{
    protected:
   string subject;
   
     public:
    
    void set_subject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class Maths_Teacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
};


int main()
{
     Maths_Teacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name";
     cin>>subjectname;
     teacher.set_subject(subjectname);
     teacher.display();

     return 0;
}
