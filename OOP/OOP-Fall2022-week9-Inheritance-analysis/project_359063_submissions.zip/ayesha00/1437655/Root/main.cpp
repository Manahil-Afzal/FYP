/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;
class person {
	public:
		string name;
		string subject;
		void setname(string name1){
			name= name1;
		}
		void setsubject(string subjectname){
			subject =subjectname;
		}
};
class MathTeacher : public person{
	public:
		void display(){
			cout<<"subject"<<subject<<endl;
		}
};
int main(){
	MathTeacher teacher;
	string subjectname;
	cout<<"enter subject name: "<<endl;
	cin>>subjectname;
	teacher.setname(subjectname);
	teacher.display();
	return 0;
}
