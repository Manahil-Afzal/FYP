/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    string subjectname;
    public:
    void setname(){
        cout<<"Enter name of subject: ";
        cin>>subjectname;
    }
        void display()
        {
             cout << "Subject" <<subjectname;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject name: ";
     cin>>subjectname;
     teacher.setname();
     teacher.display();

     return 0;
}
