/* identify and correct errors. Also comment the identified error*/
#include <iostream>
#include <string>// We use string data type therefore we have to include it
using namespace std;
class Person {
  
private:
   
   string subject;// we use string in private therefore we will use it by method(getter)
public:
	 
    void setname(string subjectname)
    {   subject = subjectname;}
	string getName()
	{
		return subject;
	}
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject "<<getName()<< endl;}};
int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject name;    ";
     cin>>subjectname;
     teacher.setname(subjectname);
     teacher.display();
     return 0;
}