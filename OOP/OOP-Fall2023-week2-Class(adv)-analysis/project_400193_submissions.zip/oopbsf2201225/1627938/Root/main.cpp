
/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
	private: //acess specifier
string title;
float price ;
public: // acess specifier
void getdata ();
void putdata ();
} ;
void book :: getdata ()//use class book and resolution operator
{
cout<<"Title:"; //use double quotes
cin>>title;
cout<<"Price:"; //use double quotes
cin>>price;
 
}
void book :: putdata () //use class book and resolution operator
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";//semi colon error
}
int main ()
{
book book1, book2, book3; // class name as book
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
