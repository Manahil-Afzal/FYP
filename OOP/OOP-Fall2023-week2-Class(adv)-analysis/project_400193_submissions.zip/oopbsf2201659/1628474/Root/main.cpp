/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string> // Add this line to use the string data type

using namespace std;

class Book // Class names should start with an uppercase letter
{
private:
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData()
{
    cout << "Title: ";
    cin.ignore(); // To clear the newline character from the previous input
    getline(cin, title); // Use getline to read the entire title, including spaces
    cout << "Price: ";
    cin >> price;
}

void Book::putData()
{
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main()
{
    Book book1, book2, book3;
    cout << "Enter data of book 1:\n";
    book1.getData();
    cout << "Enter data of book 2:\n";
    book2.getData();
    cout << "Enter data of book 3:\n";
    book3.getData();
    cout << "Displaying Book 1 data:\n";
    book1.putData();
    cout << "Displaying Book 2 data:\n";
    book2.putData();
    cout << "Displaying Book 3 data:\n";
    book3.putData();

    return 0;
}
