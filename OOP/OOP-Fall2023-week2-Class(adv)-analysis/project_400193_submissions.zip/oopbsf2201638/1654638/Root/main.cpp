/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include<iostream>
using namespace std;

class car{
	string title;
	float price;
	public:
//		car(string t, float p)
//		{
//			title = t;
//			price = p;
//			
//		}
        void setdata(){
        	cout<<"Enter the title"<<title<<endl;
        	cin>>title;
                cout<<"Enter the price"<<price<<endl;
        	cin>>price;	
		}
		void display(){
			cout<<"The Title of  "<<title<<endl;
			cout<<"The Price of  "<<price<<endl;
		}
};
main()
{
	car   a1,a2,a3;
	a1.setdata();
	a1.display();
		a2.setdata();
	a2.display();
		a3.setdata();
	a3.display();
	
}