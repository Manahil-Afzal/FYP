/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;

class Book // Use uppercase for class names
{
public: // Make the member functions public
    string title;
    float price;
    void getData(); // Correct the function names
    void putData();
};

void Book::getData() // Use :: to define member functions outside the class
{
    cout << "Title: "; // Use double quotes (") instead of special characters (”)
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData()
{
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main()
{
    Book book1, book2, book3;
    cout << "Enter data for book1:\n";
    book1.getData();
    cout << "Enter data for book2:\n";
    book2.getData();
    cout << "Enter data for book3:\n";
    book3.getData();
    
    cout << "Displaying book data:\n";
    book1.putData();
    book2.putData();
    book3.putData();
    
    return 0;
}