/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
	private: // Access specifier
string title;
float price ;
public: // Access specifier
void getdata ();
 // removed extra void getdata()
void putdata ();
} ;
void book ::getdata () // resolution operator
{
cout<<"Title:"; // semi colon error
cin>>title;
cout<<"Price:"; // semi colon error
cin>>price;
 
}
void book :: putdata () // resolution operator
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n"; // semi colon error
} // curly bracket
int main ()
{
book book1, book2, book3; // class is book instead books
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
