#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getdata() {
        cout << "Title: ";
        cin.ignore(); // Ignore any previous newline characters in the input buffer
        getline(cin, title); // Read the title with spaces
        cout << "Price: ";
        cin >> price;
    }

    void putdata() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
