/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/


#include <iostream>

using namespace std;

class Book // Changed "book" to "Book" for class name (capitalized)
{
public: // Made member functions public
    string title; // Changed to public for access
    float price;  // Changed to public for access

    void getdata(); // Removed duplicate function declaration
    void putdata(); // Removed duplicate function declaration
};

// Corrected function definitions for getdata and putdata
void Book::getdata()
{
    cout << "Title: "; // Fixed quotation marks
    cin >> title;
    cout << "Price: "; // Fixed quotation marks
    cin >> price;
}

void Book::putdata()
{
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main()
{
    Book book1, book2, book3;
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
