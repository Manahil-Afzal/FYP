/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
    private:// access specifier
    string title;
    float price;
public:
void getdata();
void putdata();
} ;
void book :: getdata ()
{
cout<<"Title:"<<endl;
cin>>title;
cout<<"Price:"<<endl;
cin>>price;
 
}
void book :: putdata ()
{
cout<<"Title:"<<title<<"\n";
cout<<"Price:"<<price<<"\n";
}
int main ()
{
book book1, book2, book3;
book1.getdata();
book1.putdata();
book2.getdata();
book2.putdata();
book3.getdata();
book3.putdata();
return 0;
}
