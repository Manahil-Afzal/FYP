/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;
class Book {
private:
    string title;
    float price;
public:
    // Member function declarations
    void getData();
    void putData();
};

// Member function definitions
void Book::getData() {
    cout << "Title: ";
    cin.ignore(); 
    getline(cin, title);
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n\n";
}

int main() {
    Book book1, book2, book3;

    // Input data for books
    cout << "Enter data for Book 1:\n";
    book1.getData();

    cout << "Enter data for Book 2:\n";
    book2.getData();

    cout << "Enter data for Book 3:\n";
    book3.getData();

    // Display data for books
    cout << "Displaying data for Book 1:\n";
    book1.putData();

    cout << "Displaying data for Book 2:\n";
    book2.putData();

    cout << "Displaying data for Book 3:\n";
    book3.putData();

    return 0;
}