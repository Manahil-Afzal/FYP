/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book // Class names should start with an uppercase letter
{
public: // Member functions and variables need to be declared public
    string title;
    float price;

    void getData(); // Corrected the function names
    void putData();
};

void Book::getData() // Corrected the scope resolution operator
{
    cout << "Title: "; // Corrected the quotation marks
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData() // Corrected the scope resolution operator
{
    cout << "Title: " << title << "\n"; // Corrected the quotation marks
    cout << "Price: " << price << "\n"; // Corrected the quotation marks
}

int main()
{
    Book book1, book2, book3;
    cout << "Enter details for book 1:\n";
    book1.getData();
    cout << "Enter details for book 2:\n";
    book2.getData();
    cout << "Enter details for book 3:\n";
    book3.getData();

    cout << "Displaying book details:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}