/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include<string>
using namespace std;

class book{
    private:
string title;
float price ;

public:
void getdata ();
void putdata ();
} ;
void book :: getdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";  //wrong quotation marks
cin>>price;
 
}
void book :: putdata ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";  //wrong quotation marks
}
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
