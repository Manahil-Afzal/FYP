/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class Book      //uppercase letter
{
    private:     //private specifier
string title;
float price ;
public:          //public specifier
void getData ();
//void getdata ();  double function
void putData ();
} ;
void Book :: getData ()   //double colon
{
cout<<"Title:";     //teminator
cin>>title;
cout<<"Price:";
cin>>price;
 
}
void Book :: putData ()   //double colon
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
int main ()
{
Book book1, book2, book3;
book1.getData();
book2.getData();
book3.getData();
book1.putData() ;
book2.putData() ;
book3.putData() ;

return 0;
}
