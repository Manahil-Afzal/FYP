#include <iostream>
using namespace std;

class Book { // Changed class name to start with a capital letter
private: // Added access specifiers to make data members private
    string title;
    float price;

public: // Added access specifier to make member functions public
    void getdata(); // Removed duplicate declaration
    void putdata(); // Removed duplicate declaration
};

// Corrected the syntax for member function definitions
void Book::getdata() {
    cout << "Enter Title: ";
    cin >> title;
    cout << "Enter Price: ";
    cin >> price;
}

void Book::putdata() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;
    cout << "Enter details for book 1:\n";
    book1.getdata();
    cout << "Enter details for book 2:\n";
    book2.getdata();
    cout << "Enter details for book 3:\n";
    book3.getdata();
    cout << "Book 1 details:\n";
    book1.putdata();
    cout << "Book 2 details:\n";
    book2.putdata();
    cout << "Book 3 details:\n";
    book3.putdata();

    return 0;
}