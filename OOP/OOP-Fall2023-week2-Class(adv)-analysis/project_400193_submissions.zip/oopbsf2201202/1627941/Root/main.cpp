#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData() {
        cout << "Title: ";
        cin.ignore(); // Ignore any newline characters in the input buffer
        getline(cin, title);
        cout << "Price: ";
        cin >> price;
    }

    void putData() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "Book 1 Details:\n";
    book1.putData();

    cout << "Book 2 Details:\n";
    book2.putData();

    cout << "Book 3 Details:\n";
    book3.putData();

    return 0;
}