/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData() {
        cout << "Enter title: ";
        cin.ignore(); // Ignore any previous newline character
        getline(cin, title);
        cout << "Enter price: ";
        cin >> price;
    }

    void putData() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "Book details:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
