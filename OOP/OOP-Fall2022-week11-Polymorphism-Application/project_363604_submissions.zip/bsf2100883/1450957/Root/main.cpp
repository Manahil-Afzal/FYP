/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
 #include<iostream>
using namespace std;

class shape{
    protected:
    int base;
    int height;
    int length;
    int width;
    int squareOfRadius;
    public:
    virtual void area(){
        
        
        
    }
};

class triangle : public shape{
    private:
    
    float areaOfTriangle;
    public:
    void area(){
    	cout<<"Enter the base: ";
        cin>>base;
        cout<<"Enter the height: ";
        cin>>height;
        areaOfTriangle = (base*height)/2;
        cout<<"Area of triangle is: "<<areaOfTriangle<<endl;
    }
    
};

class rectangle : public shape{
    private:
    
    float areaOfRectangle;
    
   public:
    void area(){
    	cout<<"Enter the length: ";
        cin>>length;
        cout<<"Enter the width: ";
        cin>>width;
        areaOfRectangle = length * width;
        cout<<"Area of rectangle is: "<<areaOfRectangle<<endl;
    }
    
};

class circle : public shape{
    private:
    
    float areaOfCircle;
   public:
    void area(){
    	cout<<"Enter the square of radius: ";
        cin>>squareOfRadius;
        areaOfCircle = 3.1415 * squareOfRadius;
        cout<<"Area of circle is: "<<areaOfCircle<<endl;
    }
    
};

void inter_func(shape *sh1){
    sh1->area();
}

int main(){
    shape *obj1 = new shape;
    triangle *obj2 = new triangle;
    rectangle *obj3 = new rectangle;
    circle *obj4 = new circle;
    
    inter_func(obj1);
    inter_func(obj2);
    inter_func(obj3);
    inter_func(obj4);
    
 
    
    return 0;
}