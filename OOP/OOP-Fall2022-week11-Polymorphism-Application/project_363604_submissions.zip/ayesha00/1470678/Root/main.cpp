/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class shape{
	public:
		double a,b;
		void getData(){
			cin>>a>>b;
		}
		virtual void display_area()=0;
};
class Triangle:public shape{
	public:
		void display_area(){
			cout<<"area of triangle:"<<0.5*a*b<<endl;
			
		}
};
class Rectangle: public shape{
	public:
	void display_area(){
		cout<<"area of rectangle: "<<a*b<<endl;
	}
};
class Circle: public shape{
	public:
		void display_area(){
			cout<<"area of circle: "<< 3.14*a*a<<endl;
		}
};
int main(){
	Triangle t;
	shape*st=&t;
	cout<<"enter length and width ";
	st->getData();
	st->display_area();
	
	Rectangle r;
	shape*sr=&r;
	cout<<"enter base and height: "<<endl;
	sr->getData();
	sr->display_area();
	
	Circle c;
	shape*sc=&c;
	cout<<"Enter radius: ";
	sc->getData();
	sc->display_area();
	return 0;
}
