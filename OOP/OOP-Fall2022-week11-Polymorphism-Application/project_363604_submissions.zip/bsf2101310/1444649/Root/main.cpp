#include<iostream>
using namespace std;
class shape{
    protected:
    float  base;
    float height;
    float square_of_radius;
    float length ;
    float width;
    public:
    void settriangle(float a,float b){
        base =a;
        height =b;
    }
    void setcircle(double c ){
        square_of_radius =c;}
        
        void setrectangle(float d ,float e){
        length =d;
        height =e;
        }
        virtual float area(){
            return 0;
        }
};
class circle:public shape{
    float area(){
        cout<<"area of circle"<<endl;
        return 3.1415 * (square_of_radius);
    }
};
class rectangle:public shape{
    float area(){
        cout<<"area of rectangle"<<endl;
        return length * width;
    }
    };
class triangle:public shape{
    float area(){
        cout<<"area of triangle"<<endl;
        return (base* height)/2;
    }
};
int main(){
shape *sPtr;

triangle tri;
sPtr=&tri;
sPtr->settriangle(2,6);
cout<<sPtr->area()<<endl;

circle cir;
sPtr =&cir;
sPtr->setcircle(2.1);
cout<<sPtr->area()<<endl;

rectangle rect;
sPtr =&rect;
sPtr->setrectangle(9,7) ;
cout<<sPtr->area()<<endl;
  
  return 0;
  }/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/