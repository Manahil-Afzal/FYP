/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
using namespace std;
float const PI = 3.1415;
class Shape{
	protected:
		float length;
		float width;
	public:
	void area(float length, float width) {
		
	}	
};

class Triangle: public Shape{
	public:
	void area(float length, float width) {
		cout<<" Area of Triangle is :"<<(length*width) / 2;
	}	
};

class Rectangle: public Shape{
	public:
	void area(float length, float width) {
		cout<<"\n Area of Rectangle is :"<<length*width;
	}	
};

class Circle: public Shape{
	public:
	void area(float length, float width) {
		cout<<"\n Area of Circle is :"<<PI * length * length;
	}	
};

int main() {
	Triangle *t;
	t->area(3,6);
	Rectangle *r;
	r->area(2,7);
	Circle *c;
	c->area(7,8);
	
	return 0;
}