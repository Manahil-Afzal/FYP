/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
using namespace std;

class Shape{
	public:
		virtual void area(){
			cout<<"Polymorphism is working!"<<endl;
		}
};

class Triangle : public Shape{
	private:
		float base, height, areaOfTriangle;
	public:
		void area(){
			cout<<"\nEnter the base of triangle: ";
			cin>>base;
			cout<<"Enter the height of triangle: ";
			cin>>height;
			areaOfTriangle = (base*height)/2;
			cout<<"The area of triangle is: "<<areaOfTriangle;
		}
};

class Rectangle : public Shape{
	private:
		float length, width, areaOfRectangle;
	public:
		void area(){
			cout<<"\n\nEnter the length of rectangle: ";
			cin>>width;
			cout<<"Enter the width of rectangle: ";
			cin>>length;
			areaOfRectangle = length*width;
			cout<<"The area of rectangle is: "<<areaOfRectangle;
		}
};

class Circle : public Shape{
	private:
		float radius, areaOfCircle;
	public:
		void area(){
			cout<<"\n\nEnter the radius of circle: ";
			cin>>radius;
			areaOfCircle = radius*radius*3.1415;
			cout<<"The area of circle is: "<<areaOfCircle;
		}
};

void inter_func(Shape *sh1){
	sh1->area();
}

int main(){
	Shape *obj1 = new Shape;
	Shape *obj2 = new Triangle;
	Shape *obj3 = new Rectangle;
	Shape *obj4 = new Circle;
	
	inter_func(obj1);
	inter_func(obj2);
	inter_func(obj3);
	inter_func(obj4);
	
	delete obj1;
	delete obj2;
	delete obj3;
	delete obj4;
}