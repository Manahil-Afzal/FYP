/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/


/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/


#include <iostream>
using namespace std;


class Shape
{
protected:
	float width, height, radius;
public:
void set_data (float a, float b)
	{
		width = a;
		height = b;

	}
	void set_data (float c)
	{

		radius = c;
	}
};


class Rectangle: public Shape
{
public:
	float area ()
	{
		return (width * height);
	}
};


class Triangle: public Shape
{
public:
	float area ()
	{
		return (width * height / 2);
	}
};

class Circle: public Shape
{
public:
	float area ()
	{
		return (3.1415 * radius*radius);
	}
};


int main (){


	Rectangle rectangle;
	Triangle triangle;
	Circle circle;
	rectangle.set_data (5,3);
	triangle.set_data (2,5);
	circle.set_data(8);
	
	cout <<"The area of the rectangle is:   " <<rectangle.area() << endl;
	cout << "The area of the triangle is:   "<<triangle.area() << endl;
	cout <<"The area of the rectangle is:   " <<circle.area() << endl;
	return 0;
}
