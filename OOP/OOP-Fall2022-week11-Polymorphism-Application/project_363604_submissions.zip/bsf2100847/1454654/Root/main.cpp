/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class shape{
public:
virtual float area(){
cout << "Area" << endl;
};
};
class triangle: public shape{
protected:
float b,h;
public:
float area(){
cout << "Enter base and height : ";
cin >> b >> h;
float tri=(0.5)*(b*h);
cout << "Area of traingle : " << tri << endl;
return tri;
};
};
class rectangle: public shape{
protected:
float l,w;
public:
float area(){
cout << "Enter length and width : ";
cin >> l >> w;
float rect=l*w;
cout << "Area of rectangle : " << rect << endl;
return rect;
};
};
class circle: public shape{
protected:
float r;
public:
float area(){
cout << "Enter radius : ";
cin >> r;
float cir=3.1415 * r * r;
cout << "Area of circle: " << cir;
return cir;
};
};
float interfunc(shape *s){
s->area();
}
int main ()
{
triangle *t=new triangle;
rectangle *R=new rectangle;
circle *c=new circle;
interfunc(t);
interfunc(R);
interfunc(c);
delete t;
delete R;
delete c;
return 0;
}