/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include <iostream>
using namespace std;

const double PI = 3.1415;

class Shape
{
public:
    virtual void area() = 0;
};

class Triangle: public Shape
{
private:
    double base, height;

public:
    Triangle(double base, double height)
    {
        this->base = base;
        this->height = height;
    }

    void area()
    {
        cout << "Area of Triangle: " << (base * height) / 2 << endl;
    }
};

class Rectangle: public Shape
{
private:
    double length, width;

public:
    Rectangle(double length, double width)
    {
        this->length = length;
        this->width = width;
    }

    void area()
    {
        cout << "Area of Rectangle: " << length * width << endl;
    }
};

class Circle: public Shape
{
private:
    double radius;

public:
    Circle(double radius)
    {
        this->radius = radius;
    }

    void area()
    {
        cout << "Area of Circle: " << PI * radius * radius << endl;
    }
};

int main()
{
    Shape *shape;
    Triangle t(10, 5);
    Rectangle r(5, 6);
    Circle c(7);

    shape = &t;
    shape->area();

    shape = &r;
    shape->area();

    shape = &c;
    shape->area();

    return 0;
}
