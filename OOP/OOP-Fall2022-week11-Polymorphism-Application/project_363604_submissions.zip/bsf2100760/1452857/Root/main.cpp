/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class Shape{
    protected:
    int base;
    int height;
    int radius;
    int length;
    int width;
    
    public:
    void area(){
        cout<<"Area of the Shape"<<endl;
    }
    
};
class Triangle:public Shape{
    public:
    void input(){
        cout<<"Enter the base "<<endl;
        cin>>base;
        cout<<"Enter the height "<<endl;
        cin>>height;
    }
    void area(){
        cout<<"Area of triangle is : "<<(base*height)/2<<"cm^2"<<endl;
    }
    
};
class Rectangle:public Shape{
     public:
     void input(){
        cout<<"Enter the length "<<endl;
        cin>>length;
        cout<<"Enter the width "<<endl;
        cin>>width;
        
    }
    void area(){
        cout<<"Area of Rectangle is : "<<length*width<<"cm^2"<<endl;
    }
    
};
class Circle:public Shape{
     public:
     void input(){
        cout<<"Enter the radius "<<endl;
        cin>>radius;
    }
    void area(){
        cout<<"Area of Circle is : "<<3.1415*(radius*radius)<<"cm^2"<<endl;
    }
    
};

int main(){
   
    Shape *shape=new Shape;
    Triangle *triangle=new Triangle;
    Rectangle *rectangle=new Rectangle;
    Circle *circle=new Circle;
    shape->area();
    triangle->input();
    rectangle->input();
    circle->input();
    triangle->area();
    rectangle->area();
    circle->area();
    
    
    delete shape;
    delete triangle;
    delete rectangle;
    delete circle;
    

    return 0;
}