/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
using namespace std;
class shape{
    public:
   
    float a=0;
     virtual void area()
    {
       
    }
    
    
};
class triangle:public shape{
    public:
    float l;
    float h;
    virtual void area()
    {
       cout<<"enter height and length of the triangle"<<endl;
       cin>>h;
       cin>>l;
       a=(h*l)/2;
       cout<<"area = "<<a<<endl;
    }
    
};
class circle:public shape{
    public:
    float r;

    virtual void area()
    {
       cout<<"enter radius of the circle"<<endl;
       cin>>r;
       a=r*r;
       a=a*3.1415;
      cout<<"area = "<<a<<endl;
    }
};
class rectangle:public shape{
    public:
    float length;
    float width;
    virtual void area()
    {
       cout<<"enter height and width of the rectangle"<<endl;
       cin>>length;
       cin>>width;
       a=length*width;
       cout<<"area = "<<a<<endl;
    }
};
int main()
{
    triangle t;
    circle c;
    rectangle r;
    t.area();
    c.area();
     r.area();
}



