/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class shape
{
    public:
    double a,b;
    void getdata()
    {
        cin>>a;
        cin>>b;
    }
    virtual void displayarea()=0;
};
class Triangle:public shape
{
    public:
    void displayarea()
    {
        cout<<"Area of triangle:"<<(a*b)/2<<endl;
    }
};
class Rectangle:public shape
{
    public:void displayarea()
    {
        cout<<"Area of rectangle:"<<a*b<<endl;
    }
};
class Circle:public shape
{
    public:
    void displayarea()
    {
        cout<<"Area of circle :"<<(3.14*a*a)<<endl;
    }
};
int main ()
{
    Triangle t;
    shape*st=&t;
    cout<<"Enter Length and Width:";
    st->getdata();
    st->displayarea();
    Rectangle r;
    shape*sr=&r;
    cout<<"Enter Base And Height:";
    sr->getdata();
    sr->displayarea();
    Circle c;
    shape*sc=&c;
    cout<<"Enter Radius:";
    sc->getdata();
    sc->displayarea();
    return 0;
}