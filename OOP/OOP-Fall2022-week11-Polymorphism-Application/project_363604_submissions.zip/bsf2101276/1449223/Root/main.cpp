/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;

class shape{
	public:
		int base;
		int height;
		int width;
		int length;
		int SquareOfRadius;
		virtual void area(){
		}
};
class triangle: public shape{
		public:
		int height;
		int base;
		float AreaOfTriangle;
		void get(){
			cout<<"Enter the Height:";
			cin>>height;
			cout<<"Enter the base:";
			cin>>base;
			AreaOfTriangle=base*height/2;
			cout<<"Area of Triangle:"<<AreaOfTriangle<<endl;
			
        }
};
class Rectangle: public shape{
	public:
		int length;
		int width;
		int AreaOfRectangle;
		void get(){
			cout<<"Enter the length:";
			cin>>length;
			cout<<"Enter the width:";
			cin>>width;
			AreaOfRectangle=length*width;
			cout<<"Area of Rectangel:"<<AreaOfRectangle<<endl;
		}
};
class Circle: public shape{
	public:
	    int SquareOfRadius;
	    float AreaOfCircle;
		void get(){
	    	cout<<"Enter the Sqaure of Radius:";
	    	cin>>SquareOfRadius;
	    	AreaOfCircle=3.14*SquareOfRadius;
	    	
		}
};

void inter_func(shape *sh1){
    sh1->area();
}

int main(){
    shape *obj1 = new shape;
    triangle *obj2 = new triangle;
    Rectangle *obj3 = new Rectangle;
    Circle *obj4 = new Circle;
    
    inter_func(obj1);
    inter_func(obj2);
    inter_func(obj3);
    inter_func(obj4);
    
    delete obj1;
    delete obj2;
    delete obj3;
    delete obj4;
    
    return 0;
}