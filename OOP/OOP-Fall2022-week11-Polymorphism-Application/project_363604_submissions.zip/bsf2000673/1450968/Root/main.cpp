/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
using namespace std;
class Shape
{
    public: 
    double a,b;
        void get_data ()
        {
        }
        
    virtual void display_area () = 0;
};

class Triangle:public Shape
{
    public: 
    void get_data(){
        cout<<"Enter the values for area of the Triangle"<<endl;
        cout<<"Enter the length: "<<endl;
            cin>>a;
        
            cout<<"Enter the width: "<<endl;
            cin>>b;
    }
    void display_area ()
    {
cout<<"Area of Rectangle: "<<a*b<<endl;
    }
};

class Rectangle:public Shape
{
    public: 
     void get_data(){
         cout<<"Enter the values for area of the Rectangle"<<endl;
        cout<<"Enter the Base: "<<endl;
            cin>>a;
        
            cout<<"Enter the Height: "<<endl;
            cin>>b;
    }
    
    void display_area ()
    {
cout<<"Area of rectangle: "<<a*b<<endl;
    }
};

class Circle:public Shape
{
	public: 
	 void get_data(){
	     
	    cout<<"Enter the values for area of the Circle"<<endl;
        cout<<"Enter the Radius: "<<endl;
            cin>>a;
        
    }
	void display_area ()
	{
		cout<<"Area of Circle:"<<3.14*a*a<<endl;
	}
};
int main()
{   
    Triangle t;
    t.get_data();
    t.display_area();
    
    
    Circle c;
     c.get_data();
    c.display_area();
    
    Rectangle r;
     r.get_data();
    r.display_area();
    return 0;
}