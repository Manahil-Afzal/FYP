#include <iostream>
#include <cmath>

class Shape {
 public:
  virtual double area() = 0;  
};

class Triangle : public Shape {
 private:
  double base, height;

 public:
  Triangle(double base, double height) : base(base), height(height) {}

  double area() override {
    return (base * height) / 2;
  }
};

class Rectangle : public Shape {
 private:
  double length, width;

 public:
  Rectangle(double length, double width) : length(length), width(width) {}

  double area() override {
    return length * width;
  }
};

class Circle : public Shape {
 private:
  double radius;

 public:
  Circle(double radius) : radius(radius) {}

  double area() override {
    return 3.1415 * std::pow(radius, 2);
  }
};

int main() {
  Shape* shapes[3];  
  shapes[0] = new Triangle(10, 5);
  shapes[1] = new Rectangle(10, 5);
  shapes[2] = new Circle(5);

  for (int i = 0; i < 3; i++) {
    std::cout << "Area of shape " << i + 1 << ": " << shapes[i]->area() << std::endl;
  }

  
  delete shapes[0];
  delete shapes[1];
  delete shapes[2];

  return 0;
}