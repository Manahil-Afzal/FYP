/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;

class Shape{
    public:
    virtual void area(){
        
    }
};
class Triangle: public Shape{
    float base;
    float height;
    public:
    void area(){
        float area_triangle;
        cout<<"Enter base of triangle"<<endl;
        cin>>base;
        cout<<"enter height of triangle"<<endl;
        cin>>height;
        area_triangle=(base* height) /2;
        cout<<"Area of triangle is "<<area_triangle<<endl;
    }
};
class Rectangle: public Shape{
    float length;
    float width;
    public:
    void area(){
        float area_rectangle;
            cout<<"Enter length of rectangle"<<endl;
            cin>>length;
            cout<<"Enter width of rectangle"<<endl;
            cin>>width;
            area_rectangle=length * width;
            cout<<"Area of Rectangle is "<<area_rectangle<<endl;
        
    }
    
};
class Circle: public Shape{
    float radius;
    public:
    void area(){
        float area_circle;
        cout<<"Enter radius of circle"<<endl;
        cin>>radius;
        area_circle=3.14*(radius*radius);
        cout<<"Area of Circle is "<<area_circle<<endl;
    }
};
int main(){
    Triangle T1;
    Rectangle R1;
    Circle C1;
    T1.area();
    R1.area();
    C1.area();
    return 0;
}
