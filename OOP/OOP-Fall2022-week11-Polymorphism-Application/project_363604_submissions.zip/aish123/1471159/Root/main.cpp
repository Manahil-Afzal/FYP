/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
#include<cmath>

using namespace std;

class Shape
{
public:
    virtual void area() = 0;
};

class Triangle: public Shape
{
private:
    float base, height;

public:
    Triangle(float base, float height)
    {
        this->base = base;
        this->height = height;
    }

    void area()
    {
        cout << "Area of triangle: " << (base*height)/2 << endl;
    }
};

class Rectangle: public Shape
{
private:
    float length, width;

public:
    Rectangle(float length, float width)
    {
        this->length = length;
        this->width = width;
    }

    void area()
    {
        cout << "Area of rectangle: " << length*width << endl;
    }
};

class Circle: public Shape
{
private:
    float radius;

public:
    Circle(float radius)
    {
        this->radius = radius;
    }

    void area()
    {
        cout << "Area of circle: " << 3.1415*pow(radius, 2) << endl;
    }
};

int main()
{
    Triangle t(10, 15);
    Rectangle r(10, 5);
    Circle c(5);

    Shape *sp;

    sp = &t;
    sp->area();

    sp = &r;
    sp->area();

    sp = &c;
    sp->area();

    return 0;
}
