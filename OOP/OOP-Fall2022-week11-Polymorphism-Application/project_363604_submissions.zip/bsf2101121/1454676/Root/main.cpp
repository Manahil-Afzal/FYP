/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class shape{
    protected :
    double w,h,r,b;
    public:
    void put_data(double a,double b,double c,double d)
    {
        w=a;
        h=b;
        r=c;
        b=d;
    }
    virtual double areaa()
    {
        return 0;
    }
};
class rectangular : public shape
{
public:
double areaa()
{
    return(w*h);
    
}
};
class circle :public shape
{
    public:
    double areaa(){
        return(3.1415*r*8);
    }
};
class triangle : public shape {
    public:
    double areaa(){
    return(b*h);
    }
};
int main (){
    shape *iptr;
    rectangular rect;
    iptr=&rect;
    iptr->put_data(6,7,8,9);
    cout<<"area of rectangul="<<iptr->areaa()<<endl;
    circle cir;
    iptr=&cir;
    iptr->put_data(6,7,8,9);
    cout<<"area of circle="<<iptr->areaa()<<endl;
    triangle tir;
    iptr=&tir;
    iptr->put_data(6,8,9,5);
    cout<<"area of triangle="<<iptr->areaa()<<endl;
    return 0;
}
    
