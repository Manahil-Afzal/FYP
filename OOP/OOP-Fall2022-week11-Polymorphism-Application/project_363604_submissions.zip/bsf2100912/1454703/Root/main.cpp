/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class Shape {
	public:
		void area(){
		}
};
class Triangle : public Shape {
	public:
		void area(){
			int base,height;
			cout<<"Enter base of triangle:";
	    	cin>>base;
	    	cout<<"Enter height of triangle:";
	    	cin>>height;
			cout<<"Area of triangle: "<<base*height/2<<endl;
		}
};
class Circle : public Shape{
	public:
		void area(){
			int radius;
			cout<<"Enter radius of circle:";
	    	cin>>radius;
	    	cout<<"Area of circle:"<<3.1425 * radius * radius<<endl;		
		}
};
class Rectangle : public Shape {
	public:
		void area(){
			int length,width;
			cout<<"Enter length of rectangle:";
			cin>>length;
			cout<<"Enter width of rectangle:";
			cin>>width;
			cout<<"Area of rectangle:"<<length * width<<endl; 
		}
};
int main(){
	Triangle *a1;
	Circle*a2;
	Rectangle*a3;
	a1->area();
	a2->area();
	a3->area();
}