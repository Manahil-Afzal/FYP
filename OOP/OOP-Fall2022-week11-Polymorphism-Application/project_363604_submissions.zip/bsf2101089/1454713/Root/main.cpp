/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class shape{
	public:
	int b,h, l,w,r;
	void area(){
	}
};
class triangle:public shape{
	public:
  	void area(){
		cout<<"Enter the value of Height"<<endl;
		cin>>h;
			cout<<"Enter the value of Base"<<endl;
			cin>>b;
			cout<<"\nThe area of Triangle is "<<h*b<<endl;
	}
};
class rectangle: public shape{
	public:
  	void area(){
		cout<<"Enter the value of Lenght"<<endl;
		cin>>l;
			cout<<"Enter the value of Width"<<endl;
			cin>>w;
			cout<<"\nThe area of Rectangle is "<<l*w<<endl;
	}
	
};
class circle:public shape{
	public:
  	void area(){
		cout<<"Enter the value of radius"<<endl;
		cin>>r;

			cout<<"\nThe area of Circle is "<<3.1415*r<<endl;
	}
};
int main(){
triangle tri;
tri.area();
circle cr;
cr.area();
rectangle ret;
ret.area();
}