/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
 #include<iostream>
 using namespace std;
 class Shape{
 	public:
  void area(){
  	cout<<"\nParent class Area method()!";
  }
 };
 class Triangle:public Shape{
 	public:
  void area(){
  	int base,height;
cout<<"\nEnter triangle information!\n";
  	cout<<"\nEnter base:";
  	cin>>base;
  	cout<<"Enter height:";
  	cin>>height;
  	cout<<"| Area of Triangle is:"<<base*height<<"|";
	} 	
 };
 class Rectangle:public Shape{
  	public:
  void area(){
  	int length,width;
cout<<"\nEnter Rectangle information!\n";
  	cout<<"\nENter length:";
  	cin>>length;
  	cout<<"Enter width:";
  	cin>>width;
  	cout<<"| Area of rectangle is:"<<length*width<<"|";
  }	
 };
 class Circle:public Shape{
  	public:
  void area(){
  	int radius;
cout<<"\nEnter Circle information!\n";
  	cout<<"\nEnter radius:";
  	cin>>radius;
cout<<"| Area of circle is:"<<radius*radius*3.14<<" |\n";
	  }	
 };
 int main (){
 	Triangle t1;
 	t1.area();
 	Rectangle r1;
 	r1.area();
 	Circle c1;
 	c1.area();
 }