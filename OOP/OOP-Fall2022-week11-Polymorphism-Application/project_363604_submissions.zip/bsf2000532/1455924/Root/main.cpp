/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
using namespace std;
class shape{
	protected:
		float area;
	public:
		shape(): area(0){}
		virtual void get(){}
		virtual void calculate(){}
		virtual void display(){}
};
class Triangle: public shape{
	private:
		int base;
		int heigth;
	public:
		Triangle(int b,int h):base(b),heigth(h){}
		void get(){
			cout<<"Please enter the base = ";
			cin>>base;
			cout<<"Please enter the height = ";
			cin>>heigth;
		}
		void calculate(){
			area= base*heigth/2;
		}
		void display(){
			cout<<"Your area of triangle is= "<<area<<endl<<endl;
		}
		
};
class Rectangle: public shape{
	private:
		int length;
		int width;
	public:
		Rectangle(int l,int w):length(l),width(w){
		}
		void get(){
			cout<<"Please enter the length = ";
			cin>>length;
			cout<<"Please enter the width = ";
			cin>>width;
		}
		void calculate(){
			area= length*width;
		}
		void display(){
			cout<<"Your Area of rectangle is= "<<area<<endl<<endl;
		}
};
class Circle:public shape{
	private:
		int radius;
		float pi;
	public:
		Circle(int r,float p):radius(r),pi(p){}
		void get(){
			cout<<"Please enter the radius = ";
			cin>>radius;
		}
		void calculate(){
			area=pi* (radius*radius);
		}
		void display(){
			cout<<"Your Area of Circle= "<<area<<endl<<endl;
		}
};

int main(){
	shape *p;
	Triangle T1(0,0); 
    Rectangle R1(0,0); 
    Circle C1(0,3.14);
    p=&T1;
    p->get();
    p->calculate();
    p->display();
    p=&R1; 
    p->get();
    p->calculate(); 
    p->display();
    p=&C1; 
    p->get();
    p->calculate(); 
    p->display();
	return 0;
}