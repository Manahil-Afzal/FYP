/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
 
class Shape
{
  protected:
    double width, height ,radius,base;
  public:
    void set_data (double a, double b,double c,double d)
    {
        width = a;
        height = b;
        radius = c ;
        base = d ;
    }
    virtual double area()
    {return 0;}
};
 
class Rectangle: public Shape
{
  public:
    double area ()
    {
        return (width * height);
    }
};
class circle: public Shape
{
  public:
    double area ()
    {
        return (3.1415 * radius*radius);
    }
};
class triangle: public Shape
{
  public:
    double area ()
    {
        return (base * height);
    }
};
 
int main ()
{
    Shape *sPtr;
    Rectangle Rect;
   
    sPtr = &Rect;
    
 
    sPtr -> set_data (5,3,2,2);
    cout <<"area of rectangle= "<< sPtr -> area() << endl;
     circle cir ;
     sPtr = &cir;
    
 
    sPtr -> set_data (5,3,2,2);
    cout <<"area of circle= "<< sPtr -> area() << endl;
     triangle tir ;
     sPtr = &tir;
    
 
    sPtr -> set_data (5,3,2,2);
    cout <<"area of triangle= "<< sPtr -> area() << endl;
    
    
    
 
    return 0;
}