/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class shape{
    public:
    virtual void area()
    {
        cout<<"area"<<endl;
    }
    
};
class triangle:public shape{
    public:
    
    void area()
    {
        int base;
        int height;
        int triangleArea;
        cout<<"enter base"<<endl;
        cin>>base;
        cout<<"enter height"<<endl;
        cin>>height;
        triangleArea= (base* height) /2;
    cout<<"triangle Area= "<<triangleArea <<endl;
    
}};
class circle:public shape{
    public:
    
    void area()
    {
        int squareOfRadius;
        int circleArea;
        cout<<"enter square of radius"<<endl;
        cin>>squareOfRadius;
        
        circleArea=3.1415 * (squareOfRadius);
     cout<<"circle area= "<<circleArea<<endl;
    }
};
class rectangle:public shape{
    public:
    void area()
    {
        int length;
        int width;
       int rectangleArea;
       cout<<"enter length"<<endl;
       cin>>length;
       cout<<"enter width"<<endl;
       cin>>width;
        rectangleArea= length * width;
        cout<<"rectangle area= "<<rectangleArea<<endl;
    }
};
void intermediate_func(shape *S1)
{
    S1->area();
}
int main()
{shape *S2=new shape;
    triangle *T1=new triangle;
    circle *C2=new circle;
    rectangle *R1=new rectangle;
    intermediate_func(S2);
    intermediate_func(T1);
    intermediate_func(C2);
    intermediate_func(R1);
    delete S2;
    delete C2;
    delete R1;
    return 0;
    
}
