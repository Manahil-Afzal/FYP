/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>

using namespace std;

class Shape {
public:
virtual void area() = 0;
};

class Triangle : public Shape {
double base, height;

public:
Triangle(double b, double h) : base(b), height(h) {}

void area() {
cout << "Area of triangle: " << (base * height) / 2 << endl;
}
};

class Rectangle : public Shape {
double length, width;

public:
Rectangle(double l, double w) : length(l), width(w) {}

void area() {
cout << "Area of rectangle: " << length * width << endl;
}
};

class Circle : public Shape {
double radius;

public:
Circle(double r) : radius(r) {}

void area() {
cout << "Area of circle: " << 3.1415 * radius * radius << endl;
}
};

int main() {
Shape *shapes[3];
shapes[0] = new Triangle(10, 5);
shapes[1] = new Rectangle(10, 5);
shapes[2] = new Circle(5);

for (int i = 0; i < 3; i++) {
shapes[i]->area();
}

return 0;
}