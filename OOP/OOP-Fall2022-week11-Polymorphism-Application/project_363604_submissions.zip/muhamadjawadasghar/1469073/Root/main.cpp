/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;

//Parent Class - Shape
class Shape {
   public:
      //Area Method
      virtual void area() { 
         cout << "Parent class area :" <<endl;
      }
};

//Child Class - Triangle
class Triangle: public Shape {
   public:
      double base, height;
      Triangle(double b, double h):base(b), height(h) { }
      void area () { 
         cout << "Area of Triangle : "<< (base*height)/2 << endl; 
      }
};

//Child Class - Rectangle
class Rectangle: public Shape {
   public:
      double length, width;
      Rectangle(double l, double w):length(l), width(w) { }
      void area () { 
         cout << "Area of Rectangle : "<< length*width <<endl; 
      }
};

//Child Class - Circle
class Circle: public Shape {
   public:
      double radius;
      Circle(double r):radius(r) { }
      void area () { 
         cout << "Area of Circle : "<< 3.1415*radius*radius <<endl; 
      }
};

//Main Function
int main() {
   Shape *shape;
   
   //Triangle
   shape = new Triangle(2,2);
   shape->area();
   
   //Rectangle
   shape = new Rectangle(2,4);
   shape->area();
   
   //Circle
   shape = new Circle(2);
   shape->area();
   
   return 0;
}