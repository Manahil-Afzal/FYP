/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include<iostream>
using namespace std;
class Shape
{
    public: double a,b;
        void get_data ()
        {
cin>>a>>b;
        }
        virtual void display_area () = 0;
};

class Triangle:public Shape
{
    public: void display_area ()
    {
cout<<"Area of triangle: "<<0.5*a*b<<endl;
    }
};

class Rectangle:public Shape
{
    public: void display_area ()
    {
cout<<"Area of rectangle: "<<a*b<<endl;
    }
};

class Circle:public Shape
{
	public: void display_area ()
	{
		cout<<"Area of Circle:"<<3.14*a*a<<endl;
	}
};
int main()
{   
    Triangle t;
    Shape *st = &t;
cout<<"Enter Length and Width : ";
st->get_data();
st->display_area();

    Rectangle r;
    Shape *sr = &r;
cout<<"Enter Base and Height : ";
sr->get_data();
sr->display_area();   

    Circle c;
    Shape *sc =&c;
cout<<"Enter radius: ";
sc->get_data();
sc->display_area();
}
