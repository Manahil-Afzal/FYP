/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
#include <iostream>
using namespace std;
class shape
{
   public:
   int width;
   int height;
   
   virtual float area()
   {
       cout<<"enter the value of width"<<endl;
        cin>>width;
        cout<<"enter the value of height"<<endl;
        cin>>height;
      return width*height;
   }
};
class traingle:public shape
{
    public:
    int base;
    int height; 
 // virtual
  float area()
    {
        cout<<"enter the value of base"<<endl;
        cin>>base;
        cout<<"enter the value of height"<<endl;
        cin>>height;
        return base*height*0.5;
    }
};
class circle:public shape
{
    public:
    int radius;
    float phie;
  // virtual
  float area()
    {
        cout<<"enter the value of lenth"<<endl;
        cin>>radius;
        cout<<"enter the value of width"<<endl;
        cin>>phie;
        return (phie) * (radius*radius);
    }
};
class rectangle:public shape
{
    public:
    int length;
    int width;
   //virtual
   float area()
    {
        cout<<"enter the value of lenth"<<endl;
        cin>>length;
        cout<<"enter the value of width"<<endl;
        cin>>width;
        
        return length * width;
    }
};
void intermediate_func(shape*s1)
{
    s1->area();
}
int main() {
   shape*obj1;
   traingle*t1;
   circle*c1;
   rectangle*r1;
   //showing result:
   intermediate_func(obj1);
   intermediate_func(t1);
   intermediate_func(c1);
   intermediate_func(r1);
    return 0;
}