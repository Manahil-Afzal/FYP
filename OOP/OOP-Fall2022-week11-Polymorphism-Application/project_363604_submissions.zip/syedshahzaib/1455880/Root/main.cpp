/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/
/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include<iostream>
using namespace std;
class Shape{
	public:
		double a,b;
		void getdata(){
			cin>>a>>b;
		}
		virtual void display_area()=0;
};
class Triangle:public Shape{
	void display_area(){
		cout<<"Area of Triangle :"<<a*b/2<<endl;
	}
};
class Rectangle :public Shape{
	void display_area(){
		cout<<"Area of rectangle :"<<a*b<<endl;
	}
};
class Circle :public Shape{
	void display_area(){
		cout<<"Area of Circle :"<<a*a*3.14<<endl;
	}
};
int main(){
	Triangle o;
	Shape*shptri=&o;
	cout<<"Enter  Lenght and Width:";
	shptri->getdata();
	shptri->display_area();
	Rectangle r;
	Shape*shprec=&r;
	cout<<"Enter Base and Height:";
	shprec->getdata();
	shprec->display_area();
	Circle  c;
	Shape*shpc=&c;
	cout<<"Enter Radius:";
	shpc->getdata();
	shpc->display_area();
}
