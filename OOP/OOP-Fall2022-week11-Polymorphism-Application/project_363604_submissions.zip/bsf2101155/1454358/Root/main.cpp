/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius); area of rectangle = length * width)*/

#include <iostream>
using namespace std;
class shape{
 protected:
 float base;
 float height;
 float length;
 float width;
 float squareOfRadius; 
 public:
 void set_triangle_data(float a, float b)
 {
     base = a;
     height = b;
 }
 void set_rectangle_data(float x, float y)
 {
     length= x;
     width= y;
 }
 void set_circle_data(float c)
 {
     squareOfRadius= c;
 }
 virtual float area(){
     return 0;
 }
};
class triangle:public shape{
    float area(){
        cout<<"area of triangle is:"<<endl;
        return  (base* height) /2 ;
    }
};
class rectangle:public shape{
    float area(){
    cout<<"area of rectangle is:"<<endl;
    return (length* width);
    }
};
class circle:public shape{
  float area(){
      cout<<"area of circle is:"<<endl;
      return 3.1415 * (squareOfRadius); 
  }  
};
int main(){
shape * sPtr;
triangle t1;
sPtr = &t1;
sPtr -> set_triangle_data(2,6);
cout << sPtr->area()<<endl;

rectangle r1;
sPtr = &r1;
sPtr -> set_rectangle_data(3,5);
cout << sPtr->area()<<endl;

circle c1;
sPtr = &c1;
sPtr -> set_circle_data(7.5);
cout <<sPtr -> area()<<endl;
return 0;
}