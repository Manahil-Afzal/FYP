/*Write a C++ program that defines four classes named: Shape, Triangle, Rectangle and Circle 
where Shape is parent class of rest of the three classes. 
Class Shape has a method named area which is overridden in child classes. 
This method calculates and displays the area of its respective type. 
The program displays areas of all the shapes through polymorphism.
(area of triangle= (base* height) /2: area of circle = 3.1415 * (square of radius);
area of rectangle = length * width)*/
#include <iostream>
using namespace std;

// base class
class Shape{
protected:
float base;
float height;
float sqaureOfRadius;
float length;
float width;

public:
void setTriangle_Data(float a , float b){
    base = a;
    height = b;
}

void setCircle_Data(float c){
   sqaureOfRadius = c;
}

void setRec_Data(float y , float z){
    length = y;
    width = z;
}

  virtual float Area()
    {
        return 0;
        
    }

};

// class of triangele
class triangele : public Shape{
    float Area(){
         cout << "Area OF triangele is:" << endl;
        return( base*height)/2;
    }
} ;

 // class of circle 
class circle : public Shape{
    float Area(){
        cout << "Area OF circle is:" << endl;
        return 3.1415 * (sqaureOfRadius);
    }
} ;

// class of rectangle
class rectangle : public Shape{
    float Area(){
         cout << "Area OF rectangle is:" << endl;
        return length* width;
    }
} ;

int main(){
    Shape *sPtr;
    
    triangele Tri; 
    sPtr = &Tri;   
    sPtr->setTriangle_Data (5.4,3.6); 
    cout << sPtr -> Area() << endl;  

    circle Cir;
    sPtr = &Cir;   
    sPtr->setCircle_Data (1.6);
    cout << sPtr -> Area() << endl;  
    
    rectangle Rect;
    sPtr = &Rect;   
    sPtr->setRec_Data (55.0,33.0);
    cout << sPtr -> Area() << endl; 
    
    return 0;

}
