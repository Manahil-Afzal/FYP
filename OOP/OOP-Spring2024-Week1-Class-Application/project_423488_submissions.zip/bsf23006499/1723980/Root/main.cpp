/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
using namespace std;
class BA {
public:
    string Title;
    string Type;
    double balance, profit,total_balance;
    int profit_p;
    void display_input();
    void display_Balance();
     void display_output();
};
    void BA::display_input() {
        cout<<"Enter the Account Title: ";
        cin>>Title;
        cout<<"Enter the Account Type: ";
       cin>>Type;
        cout<<"Enter Account Balance: ";
        cin>>balance;
        cout<<"Enter Profit Percent: ";
        cin>>profit_p;
    }
    void BA::display_Balance() {
        if (Type == "savings") 
		{
           profit=balance*5/100;
        }
		 else if (Type == "PLS")
		 {
            profit=balance*8/100;
        }
        total_balance=profit+balance;
    }
    void BA::display_output() {
        cout<<"Account Title: "<<Title<<endl;
        cout<<"Account Type: "<<Type<<endl;
        cout<<"Balance: Rs."<<balance<<"/-"<<endl;
        cout<<"Profit Percent: "<<profit_p<<"%"<<endl;
        cout<<"The total balance=Rs."<<total_balance<<"/-"<<endl;
    }


int main() {
    BA account1, account2;
    cout<<"Enter the details of Account 1:"<<endl;
    account1.display_input();
    account1.display_Balance();
    cout<<"\n Enter the details of Account 2:"<<endl;
    cin.ignore();
    account2.display_input();
    account2.display_Balance();
    cout<<"\n the detail of Account 1:"<<endl;
    account1.display_output();
    cout<<"\n the detail of Account 2:"<<endl;
    account2.display_output();
}