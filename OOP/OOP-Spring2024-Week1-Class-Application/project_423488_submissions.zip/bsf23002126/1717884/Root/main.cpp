#include<iostream>
using namespace std;
class bankaccount{
    private:
    string accounttitle;
    string accounttype;
    int balance;
    public:
    void getinfo()
    {
        cout<<"enter account title"<<endl;
        cin>>accounttitle;
        cout<<"enter account type"<<endl;
        cin>>accounttype;
        cout<<"enter balance"<<endl;
        cin>>balance;
    }
    void calbalance()
    {
        if(accounttype=="savings"){
            balance=(balance)+(0.05*balance);
        }
        else
        balance=(balance)+(0.08*balance);
        }
        void printinfo(){
            cout<<"account title is"<<accounttitle<<endl;
             cout<<"account type is"<<accounttype<<endl;
              cout<<"account balance is"<<balance;
              cout<<"current balance is"<<balance;
    }
};
int main(){
    bankaccount a;
    bankaccount b;
    a.getinfo();
    a.calbalance();
    a.printinfo();
    b.getinfo();
    b.calbalance();
    b.printinfo();
    return 0;
}