/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>
using namespace std;
class BankAccount {
    private:
        string account_title; 
        string account_type; 
        double balance; 
        double profit_percent; 
    public:
        BankAccount() {
            cout << "Enter account title: ";
            getline(cin, account_title); 
            cout << "Enter account type (savings or PLS): ";
            cin >> account_type;
            cout << "Enter balance: ";
            cin >> balance; 
            if (account_type == "savings") {
                profit_percent = 0.05; 
            }
            else if (account_type == "PLS") {
                profit_percent = 0.08; 
            }
            else {
                profit_percent = 0.0; 
            }
        }
        void calculate_balance() {
            balance = balance + balance * profit_percent;
        }
        void display() {
            cout << "Account title: " << account_title << endl; 
            cout << "Account type: " << account_type << endl; 
            cout << "Balance: " << balance << endl; 
        }
};


int main() {
    BankAccount account1;
    BankAccount account2;
    account1.calculate_balance();
    account2.calculate_balance();
    cout << "Account 1 details:" << endl;
    account1.display();
    cout << "Account 2 details:" << endl;
    account2.display();

    return 0; 
}
