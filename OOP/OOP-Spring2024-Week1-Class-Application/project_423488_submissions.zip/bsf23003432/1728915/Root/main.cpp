/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/


#include<iostream>
#include<string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    void inputDetails() {
        cout << "Enter Account Title: ";
        cin.ignore();
        getline(cin, accountTitle);

        cout << "Enter Account Type (savings/PLS): ";
        cin >> accountType;

        cout << "Enter Balance: ";
        cin >> balance;

        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }

    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * 0.05);
        } else if (accountType == "PLS") {
            balance += (balance * 0.08);
        }
    }

    void displayDetails() {
        cout << "\nAccount Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << "%" << endl;
    }
};

int main() {
    using namespace std;

    BankAccount account1, account2;

    cout << "Enter details for Account 1:\n";
    account1.inputDetails();

    cout << "\nEnter details for Account 2:\n";
    account2.inputDetails();

    account1.calculateBalance();
    account2.calculateBalance();

    cout << "\nAccount 1 Details:\n";
    account1.displayDetails();

    cout << "\nAccount 2 Details:\n";
    account2.displayDetails();

    return 0;
}
