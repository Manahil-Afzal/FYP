/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include<iostream>
#include<string>
using namespace std;

class bank_account {
	// int this section the enter variable will be private the cannot be access directly
	 private:
	 	string account_title;
	 	string account_type;
	 	int balance;
	 	int profit;
	 	int ne;
	 	
	public:
	    
		void getdetails(){
			
			cout<<"Please Enter The Account Details"<<endl;
			cout<<"ENTER THE ACCOUNT TITAL : ";
			cin>>account_title;
			cout<<"ENTER THE ACCOUNT TYPE (saving / PSL) : ";
			cin>>account_type;
			cout<<"ENTER THE ACCOUNT BALANCE : ";
			cin>>balance;
			cout<<"ENTER THE ACCOUNT PROFIT PERCENTAGE : ";
			cin>>profit;
		} 
		
	void balancecalculate(){
			 
			if(account_type =="saving"){
			
				balance += balance*(5/100);
				
			}
			else if(account_title=="PSL")
			{	 
		     
				balance += balance*(8/100);
			}
			
			
			
		}
		
		void updatedetails(){
			
		    cout<<"You Account Updated Details :"<<endl;
			cout<<"ACCOUNT TITAL : ";
			cout<<account_title<<endl;
			cout<<"ACCOUNT TYPE : ";
			cout<<account_type<<endl;
			cout<<"NEW CURRENT BALANCE : ";
			cout<<balance<<endl;
			cout<<"PROFIT PERCENTAGE : ";
			cout<<profit<<endl;
			
		}	
}; 

int main(){
	
	bank_account obj1,obj2;
	// to get account details from user
	
	obj1.getdetails();
	obj2.getdetails();

	obj2.balancecalculate();
	obj2.balancecalculate();

		obj1.updatedetails();
		obj2.updatedetails();
	
	
	return 0;
	
	
}
