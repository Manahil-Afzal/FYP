/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankacc{
	private:
	string title;
	string type;
	float balance;
	float profitpercent;
	public:
		void input()
		{
			cout<<"enter account title: ";
			cin>>title;
			cout<<"enter account type: ";
			cin>>type;
			cout<<"enter account balance: ";
			cin>>balance;
			cout<<"enter profit percentage: ";
			cin>>profitpercent;
		}
		void calculatebalance()
		{
			if(type=="savings"){
				profitpercent=0.05* balance;
			}else if(type=="PLS"){
				profitpercent=0.08*balance;
			}
		}
		void display()
		{
			cout<<"account title: "<<title<<endl;
			cout<<"account type: "<<type<<endl;
			cout<<"current balance : " <<balance<<endl;
		}
	};
	int main()
	{
		bankacc acc1,acc2;
		//input data for the 1st account
		cout<<"enter details for the first account:"<<endl;
		acc1.input();
		acc1.calculatebalance();
		//input data for the second account
		cout<<"enter details for the second account: "<<endl;
		acc2.input();
		acc2.calculatebalance();
		//display account detail for both account
		cout<<"details for the first account: ";
		acc1.display();
		cout<<"details for the second account: ";
		acc2.display();
	}
	
