#include <iostream>
using namespace std;
class bank_acc{
public:
    string acc_title;
    string acc_type;
    int balance;
    void input();
    void calculate();
    void display(); 
};
void bank_acc::input()
{
    cout<<"Enter account name :";
    cin>>acc_title;
    cout<<"Enter account type :";
    cin>>acc_type;
    cout<<"Enter account balance :";
    cin>>balance;
}
void bank_acc::calculate()
{
    if(acc_type=="PLS")
    {
        balance += balance*0.08;
    }
    else if(acc_type=="savings"){
         balance += balance*0.05;
    }
    else
    cout<<"Enter valid type";
    
}
void bank_acc::display()
{
    cout<<"Accout Name: "<<acc_title<<endl;
    cout<<"Total Balance with profit: "<<balance;
}
int main()
{
    bank_acc acc1;
    bank_acc acc2;
    
    acc1.input();
    acc1.calculate();
    
    acc2.input();
    acc2.calculate();
    
    acc1.display();
    cout<<endl;
    acc2.display();
    return 0;
}