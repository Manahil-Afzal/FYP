/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/#include<iostream>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double balanceWithProfit;

public:
    void getDetails() {
        cout << "Enter account title: ";
        cin >> accountTitle;
        cout << "Enter account type (savings or PLS): ";
        cin >> accountType;
        cout << "Enter balance: ";
        cin >> balance;
    }

    void calculateBalance() {
        if (accountType == "savings") {
            balanceWithProfit = balance + (0.05 * balance);
        } else if (accountType == "PLS") {
            balanceWithProfit = balance + (0.08 * balance);
        } else {
            cout << "Invalid account type." << endl;
        }
    }

    void printInfo() {
        cout << "Your account title is: " << accountTitle << endl;
        cout << "Account type is: " << accountType << endl;
        cout << "Account balance is: " << balance << endl;
        cout << "Current balance with profit is: " << balanceWithProfit << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for account 1:" << endl;
    account1.getDetails();
    account1.calculateBalance();

    cout << "\nEnter details for account 2:" << endl;
    account2.getDetails();
    account2.calculateBalance();

    cout << "\nAccount 1 Details:" << endl;
    account1.printInfo();

    cout << "\nAccount 2 Details:" << endl;
    account2.printInfo();

    return 0;
}
