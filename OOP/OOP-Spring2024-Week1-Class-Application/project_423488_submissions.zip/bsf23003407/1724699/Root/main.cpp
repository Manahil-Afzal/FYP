/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>
using namespace std;
class BankAccount {
private:
    string accountTitle;
   string accountType;
    double balance;
    double profitPercent;

public:
    // Method to take input for data members from the user
    void inputDetails() {
        cout << "Enter Account Title: ";
        getline(cin, accountTitle);

        cout << "Enter Account Type (Savings/PLS): ";
        cin >> accountType;

        cout << "Enter Initial Balance: ";
        cin >> balance;

        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }

    // Method to calculate current balance based on account type
    void calculateBalance() {
        if (accountType == "Savings") {
            balance += (balance * profitPercent / 100); // 5% profit for savings
        } else if (accountType == "PLS") {
            balance += (balance * profitPercent / 100); // 8% profit for PLS
        }
    }

    // Method to display account details on the screen
    void displayDetails() {
        cout << "\nAccount Title: " << accountTitle << "\n";
        cout << "Account Type: " << accountType << "\n";
        cout << "Current Balance: " << balance << "\n";
        cout << "Profit Percentage: " << profitPercent << "%\n";
    }
};

int main() {
    // Creating two objects of the BankAccount class
    BankAccount account1, account2;

    // Taking input for the data members from the user
    cout << "Enter details for Account 1:\n";
    account1.inputDetails();

    cout << "\nEnter details for Account 2:\n";
    account2.inputDetails();

    // Calculating current balance based on profit percentage
    account1.calculateBalance();
    account2.calculateBalance();

    // Displaying account details
    cout << "\nAccount Details for Account 1:\n";
    account1.displayDetails();

    cout << "\nAccount Details for Account 2:\n";
    account2.displayDetails();

    return 0;
}