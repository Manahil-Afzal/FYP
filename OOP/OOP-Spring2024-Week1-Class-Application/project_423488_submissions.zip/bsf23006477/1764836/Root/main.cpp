/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;

class Bank
{
private:
    string title;
    string type;
    int balance;
    float percent;

public:
    void getDetail()
    {
        cout << "Enter Bank Title : ";
        cin >> title;
        cout << "Enter Bank Type saving/PLS : ";
        cin >> type;
        cout << "Enter Bank Balance : ";
        cin >> balance;
        cout<<"Enter Percentage : ";
        cin>>percent;
        cout<<endl;
    }

    void CalculateProfit()
    {
        if (type == "saving")
        {
            balance += (0.05 * balance);
        }
        else if (type == "PLS")
        {
            balance += (0.08 * balance);
        }
    }

    void displayDetail()
    {
        cout << "\nBank Detail" << endl;
        cout << "Title : " << title << endl;
        cout << "Type : " << type << endl;
        cout << "Balance : " << balance << endl;
        cout << "Percent : " << percent << endl;
    }
};

int main()
{
    Bank account1, account2;
    account1.getDetail();
    account2.getDetail();

    account1.CalculateProfit();
    account2.CalculateProfit();

    account1.displayDetail();
    account2.displayDetail();

    return 0;
}