#include <iostream>
using namespace std;

class BankAcc {
private:
    string accTitle;
    string accType;
    double balance1;
    double balance;
    double profitPercent;

public:

    void inputDetails() {
        cout << "Enter Acc Title: ";
        cin >> accTitle;
        cout << "Enter Acc Type (saving/pls): ";
        cin >> accType;
        cout << "Enter Balance1: ";
        cin >> balance1;
        cout << "Enter Profit Percent: ";
        cin >> profitPercent;
    }

    
   void calculateBalance1() {
    if (accType == "saving") {
        
        balance1 += balance * 0.05;
    } else {
       
        balance1 += balance * 0.08;
    }
}

    
    void displayDetails() {
        cout << "Acc Title: " << accTitle << endl;
        cout << "Acc Type: " << accType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
   
    BankAcc acc1, acc2;

    cout << "Enter details for Acc 1: " << endl;
    acc1.inputDetails();
    acc1.calculateBalance1();

    cout << "Enter details for Acc 2: " << endl;
    acc2.inputDetails();
    acc2.calculateBalance1();

    
    cout << "\nDetails of Acc 1: " << endl;
    acc1.displayDetails();

    cout << "\nDetails of Acc 2: " << endl;
    acc2.displayDetails();

    return 0;
}