#include <iostream>
using namespace std;

class BankAccount {
    private:
        string accountTitle;
        string accountType;
        double balance;
        double profitPercent;
    public:
        void input(); 
        void calculate(); 
        void display(); 
};

int main() {
    BankAccount account1, account2;
    
    // Account1
    cout << "Enter details of your first account:\n";
    account1.input();
    account1.calculate();
    cout << "The details of your first account are:\n";
    account1.display();
    
    // Account2
    cout << "Enter details of your second account:\n";
    account2.input();
    account2.calculate();
    cout << "The details of your second account are:\n";
    account2.display(); 

    return 0;
}

void BankAccount::input(){
    cout << "Enter account title: ";
    cin >> accountTitle;
    cout << "Enter account type(savings or PLS): ";
    cin >> accountType;
    cout << "Enter balance: ";
    cin >> balance;
            
    if (accountType == "savings") {
          profitPercent = 0.05;
     }
     else if (accountType == "PLS") {
          profitPercent = 0.08;
      }
      else {
           cout << "Invalid account type.\n";
            profitPercent = 0;
      }
};

void BankAccount::calculate() {
            balance = balance + (balance * profitPercent);
        };

void BankAccount::display(){
            cout << "Account title: " << accountTitle << "\n";
            cout << "Account type: " << accountType << "\n";
            cout << "Your Balance: " << balance << "\n";
            cout << "Profit percent: " << profitPercent * 100 << "%\n";
        };/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/