/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankaccount
{
    public:
    string accounttitle;
    string accounttype;
    int accountbalance;
    float profit;
    int currentbalance;
    void getdata(void)
    {
        cout<<"enter account title";
        cin>>accounttitle;
        cout<<"enter accountype";
        cin>>accounttype;
        cout<<"enter your balance";
        cin>>accountbalance;
        
        
    }
    void setdata(void)
    {
    	cout<<"your account title is"<<accounttitle<<endl;
    	cout<<"your account type is"<<accounttype<<endl;
    	cout<<"your balance is"<<accountbalance<<endl;
    	 cout<<"your profit is"<<profit<<endl;
    cout<<"your current baalance is"<<currentbalance<<endl;
	}
    void currentbal(void);
};
void bankaccount::currentbal(void)
{
    if(accounttype=="savings")
    {
        cout<<"your profit percentage is 5%"<<endl;
        profit=(5*accountbalance)/100;
        currentbalance=accountbalance+profit;
    }
    else if(accounttype=="pls")
    {
        cout<<"profit is 8%";
        profit=(8*accountbalance)/100;
        currentbalance=accountbalance+profit;
    }
   
}
int main()
{
    bankaccount p1,p2;
    p1.getdata();
    p1.currentbal();
    p1.setdata();
    p2.getdata();
    p2.currentbal();
    p2.setdata();}