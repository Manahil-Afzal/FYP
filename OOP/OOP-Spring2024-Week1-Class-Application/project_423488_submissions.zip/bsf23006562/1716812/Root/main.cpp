/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
#include<string>
using namespace std;
class bankaccount{
    private:
        string accounttitle;
        string accounttype;
        double balance;
        double profit_percent;
    public:
        int inputdetail()
        {
            cout<<"enter the account title : \n";
            cin>>accounttitle;
            cout<<"enter the type of account :\n";
            cin>>accounttype;
            cout<<"enter the balance of account :\n";
            cin>>balance;
        }
        int calculation()
        {
            if(accounttype=="saving")
            {
                profit_percent=0.05;
                balance+=(balance*profit_percent/100.0);
            }
            else
            {
                profit_percent=0.08;
                balance+=(balance*profit_percent/100.0);
            }
        }
        int outputdetail()
        {
            cout<<"the detail of account :\n";
            cout<<"\nthe title of account :\n";
            cout<<accounttitle;
            cout<<"\nthe type of an account :\n";
            cout<<accounttype;
            cout<<"\nthe balance of account : \n";
            cout<<balance;
            cout<"\nthe profit percent of an acount :\n";
            cout<<profit_percent;
        }
};
int main()
{
    bankaccount account1,account2;
    cout<<"enter the detail of account 1 :\n";
    account1.inputdetail();
    cout<<"enter the detail of account 2 :\n";
    account2.inputdetail();
    account1.calculation();
    account2.calculation();
    cout<<"display the output of account 1 on screen :\n";
    account1.outputdetail();
    cout<<"display the output of account 2 on screen : \n";
    account2.outputdetail();
    return 0;
}