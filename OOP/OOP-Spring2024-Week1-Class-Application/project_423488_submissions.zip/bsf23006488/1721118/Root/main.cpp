#include <iostream>
using namespace std;

class Bank
{
private:
    string title;
    string type;
    int balance;
    float percent;

public:
    void getDetail()
    {
        cout << "Enter Bank Title : ";
        cin >> title;
        cout << "Enter Bank Type saving/PLS : ";
        cin >> type;
        cout << "Enter Bank Balance : ";
        cin >> balance;
        cout<<"Enter Percentage : ";
        cin>>percent;
        cout<<endl;
    }

    void CalculateProfit()
    {
        if (type == "saving")
        {
            balance += (0.05 * balance);
        }
        else if (type == "PLS")
        {
            balance += (0.08 * balance);
        }
    }

    void displayDetail()
    {
        cout << "\nBank Detail" << endl;
        cout << "Title : " << title << endl;
        cout << "Type : " << type << endl;
        cout << "Balance : " << balance << endl;
        cout << "Percent : " << percent << endl;
    }
};

int main()
{
    Bank account1, account2;
    account1.getDetail();
    account2.getDetail();

    account1.CalculateProfit();
    account2.CalculateProfit();

    account1.displayDetail();
    account2.displayDetail();

    return 0;
}