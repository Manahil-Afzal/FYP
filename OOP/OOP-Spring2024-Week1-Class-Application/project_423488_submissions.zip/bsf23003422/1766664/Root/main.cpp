#include <iostream>
using namespace std;
class BankAccount {
	private:
	   string accountTitle;
	   string accountType;
	   double balance;
	   double profitPercent;
	public:
		void setDetails(){
			cout<<"Enter Account Title: "<<endl;
			cin>>accountTitle;
			cout<<"Enter Account Type(savings or PLS): "<<endl;
			cin>>accountType;
			cout<<"Enter Account Balance: "<<endl;
			cin>>balance;
		}
		void calculateBalance(){
			if(accountType == "savings"){
				profitPercent = 5.0;
			}
			else if(accountType == "PLS"){
				profitPercent = 8.0;
			}
			else{
				profitPercent = 0.0;
			}
			balance += balance * (profitPercent/100);
			cout<<"Account Title: "<<accountTitle<<endl;
			cout<<"Account Type: "<<accountType<<endl;
			cout<<"Balance: "<<balance<<endl;
		}
};

int main(){
	BankAccount account1, account2;
	cout<<"Enter details for Account 1: "<<endl;
	account1.setDetails();
	account1.calculateBalance();
	
	cout<<"Enter details for account 2: "<<endl;
	account2.setDetails();
	account2.calculateBalance();
	return 0;
	
}


