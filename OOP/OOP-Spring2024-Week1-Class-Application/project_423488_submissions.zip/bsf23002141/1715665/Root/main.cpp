/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
using namespace std;
class bankAccount {
private:
    string account_title;
    string account_type;
    double balance;
    double profit_percent;
public:
    void input_data() {
        cout << "Enter account title: ";
        cin >> account_title;
        cout << "Enter account type (savings or pls): ";
        cin >> account_type;
        cout << "Enter Balance: ";
        cin >> balance;
        cout << "Enter Profit Percentage: ";
        cin >> profit_percent;
        while (account_type != "savings" && account_type != "pls") {
            cout << "Invalid account type. Enter either pls or savings: ";
            cin >> account_type;
        }
    }
    void calculate_balance() {
        if (account_type == "savings") {
            balance = balance + (balance * 5 / 100);
        } else if (account_type == "pls") {
            balance = balance + (balance * 8 / 100);
        }
    }
    void display_details() {
        cout << "\nAccount title: " << account_title << endl;
        cout << "Account Type: " << account_type << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percentage: " << profit_percent<<"%"<< endl;
    }
};
int main() {
    bankAccount account1, account2;
    cout << "Enter details for first account:" << endl;
    account1.input_data();
    account1.calculate_balance();
    cout << "Enter details for second account:" << endl;
    account2.input_data();
    account2.calculate_balance();
    cout << "\nAccount 1 details are as follows:" << endl;
    account1.display_details();
    cout << "\nAccount 2 details are as follows:" << endl;
    account2.display_details();
}

