#include <iostream>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    
    void inputDetails() {
        cout << "Enter Account Title: ";
        getline(cin >> ws, accountTitle);

        cout << "Enter Account Type (savings/PLS): ";
        getline(cin >> ws, accountType);

        cout << "Enter Initial Balance: ";
        cin >> balance;

        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }

    
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * 5 / 100);
        } else if (accountType == "PLS") {
            balance += (balance * 8 / 100);
        }
    }

   
    void displayDetails() {
        cout << "\nAccount Title: " << accountTitle <<endl;
        cout << "Account Type: " << accountType <<endl;
        cout << "Current Balance: " << balance <<endl;
        cout << "Profit Percentage: " << profitPercent << "%" <<endl;
    }
};

int main() {
    
    BankAccount account;

 
    cout << "Enter details for Account :\n";
    account.inputDetails();
    account.calculateBalance();


    cout << "\nAccount Details for Account :\n";
    account.displayDetails();

       return 0;
}