/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class BankAcount
{
	public:
	string Title;
	string AccType;
	float Balance;
	float profit;
	
	void input()
	{
		cout<<"Enter Account Title :";
		cin>>Title;
		cout<<"Enter Account Type (saving & pls): ";
		cin>>AccType;
		cout<<"Enter the Balance : ";
		cin>>Balance;
		cout<<"Enter the profit(Saving & Pls ): ";
		cin>>profit;
	}
	
	
	void Calculate()
	{
		if(AccType=="saving")
		{
			Balance=Balance+Balance*(profit/100);
		}
		else if(AccType=="pls")
		{
		Balance =Balance+Balance*(profit/100);
		}
	}
	
	
	void display()
	{
		cout<<endl;
		cout<<"Accoun Title is :"<<Title<<endl;
		cout<<"Account Type is :"<<AccType<<endl;
		cout<<"Current Blance is :"<<Balance<<endl;
		cout<<"Profit is : "<<profit<<"%"<<endl;
	}
		
};
int main()
{
	BankAcount BankObj1, BankObj2;
	cout<<"\nEnter the detail Acount 1 "<<endl;
	BankObj1.input();
	BankObj1.Calculate();
	
	
	cout<<"\nEnter the Detail acount 2"<<endl;
	BankObj2.input();
	BankObj2.Calculate();
	
	
	cout<<endl<<"\nDisplay Account 1 deatial";
	BankObj1.display();
	cout<<endl<<"\nDisplay Account 2 deatial";
	BankObj2.display();
	
	
	
}