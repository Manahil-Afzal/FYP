/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bank{
	private:
		string accounttitle;
		string accounttype;
		float balance;
		float profitpercentage;
		public:
			void inputacc(){
				cout<<"Enter account title:"<<endl;
				cin>>accounttitle;
				cout<<"Enter account type:"<<endl;
				cin>>accounttype;
				cout<<"Enter initial balance:"<<endl;
				cin>>balance;
				cout<<"Enter profit percentage:"<<endl;
				cin>>profitpercentage; 
			}
			void accountcalculate(){
				if(accounttype=="saving"){
					balance+=(0.05*balance);
				}
				else{
					balance+=(0.08*balance);
				}
			}
			void display(){
				cout<<"Account title:"<<accounttitle<<endl;
				cout<<"Account type:"<<accounttype<<endl;
				cout<<"Initial balance:"<<balance<<endl;
				cout<<"Profit percentage balance:"<<profitpercentage<<endl;
			}
};
int main(){
	bank account1,account2;
	 cout<<"Enter detail for account 1:"<<endl;
	 account1.inputacc();
	 account1.accountcalculate();
	 cout<<"Enter detail for account 2:"<<endl;
	 account2.inputacc();
	 account2.accountcalculate();
	 cout<<" Detail of account 1:"<<endl;
	 account1.display();
	 account1.display();
	 cout<<" Detail of account 2:"<<endl;
	 account2.display();
	 account2.display();
	 return 0;
	
}