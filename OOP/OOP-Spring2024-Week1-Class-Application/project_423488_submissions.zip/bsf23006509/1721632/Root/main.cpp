/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankacc{
	private:
		string acctitle;
		string acctype;
		float balance;
		float profit;
		
	public:
	    void getdata();
	    void showdetails();			
};

void bankacc::getdata()
{
	    cout<<"Enter the Account Title =";
	    cin>>acctitle;
	
		cout<<"Enter the Account Type =";
		cin>>acctype;
		
		cout<<"Enter the Account Balance =";
		cin>>balance;
		
		if(acctype=="saving")
		{
			profit = balance+ (0.05*balance);
		}
		else if(acctype=="PLS")
		{
			profit=  balance+ (0.08*balance);
		}
		
		
		
}
void bankacc::showdetails()
{
	cout<<acctitle<<endl;
	cout<<acctype<<endl;
	cout<<balance<<endl;
	cout<<profit;
}
	
int main()
{
	bankacc obj1;
	obj1.getdata();
	obj1.showdetails();
	
}