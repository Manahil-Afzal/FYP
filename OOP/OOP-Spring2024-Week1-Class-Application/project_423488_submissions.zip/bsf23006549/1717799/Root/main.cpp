/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class Bank_Acc{
	private:
    string accountTitle;
    string accountType;
    float balance;
    float profit_age;
    float current_bal();
    public:
        void setter();
        void getter();
        Bank_Acc();
};
void Bank_Acc::setter(){   //Function to input Data Members
    cout<<"Enter Account Title : "<<endl;
    cin>>accountTitle;
    cout<<"Enter Account Type (Savings/PLS): "<<endl;
    cin>>accountType;
    cout<<"Enter Balance : ";
    cin>>balance;
}
float Bank_Acc::current_bal(){ //Function to calculate current Balance
    if(accountType=="Savings" or accountType=="savings") // Condition to check whether accountType is Savings or PLS
    profit_age=0.05;
    else if(accountType=="PLS" or accountType=="pls")
    profit_age=0.08;
    return balance+=balance*profit_age;
}
void Bank_Acc::getter(){ // A function to display all details
    cout<<"1- Your Account Title is : "<<accountTitle<<endl;
    cout<<"2- Your Account Type is : "<<accountType<<endl;
    cout<<"3- Your Balance is : Rs."<<current_bal()<<endl;
    cout<<"4- Your Profit Percentage is : "<<profit_age*100<<"%"<<endl;
}
Bank_Acc::Bank_Acc(){  // A constructor to avoid unexpected results
    accountTitle="Un-defined";
    accountType="Un-defined";
    balance=0.0;
    profit_age=0.0;
}
int main(){
    Bank_Acc Taimoor,Ali; // Creation of two objects 
    cout<<"\t\t\t\t\tEnter Details for 1st Person  \n"<<endl;
    Taimoor.setter();
    cout<<"\n\t\t\t\t\tEnter Details for 2nd Person  "<<endl;
    Ali.setter();
    cout<<"\t\t\t\t\tDetails of 1st Person are  "<<endl;
    Taimoor.getter();
    cout<<"\t\t\t\t\tDetails of 2nd Person are  "<<endl;
    Ali.getter();
}