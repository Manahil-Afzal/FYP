/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class account{
	public:
	string title;
		string type;
		int balance;
		int profit;
		void input(){
			cout<<"Enter the title:"<<endl;
			cin>>title;
			cout<<"Enter the account type:"<<endl;
			cin>>type;
			cout<<"Enter the balance:"<<endl;
			cin>>balance;
						
		}
		void processing(){
			if(type=="saving"){
			
			
			profit=(balance*0.05);
		
		}
			
			else
			 {	
			type=="pls";
			profit=(balance*0.08);
			 
			}
	}
			void display(){
				cout<<"Title="<<balance<<endl;
				cout<<"account type="<<type<<endl;
				cout<<"balance="<<balance<<endl;
				cout<<"profit_percentage="<<profit<<endl;
			}
};
int main(){
account account1,account2;
account1.input();
account1.processing();
account1.display();
account2.input();
account2.processing();
account2.display();
return 0;
}