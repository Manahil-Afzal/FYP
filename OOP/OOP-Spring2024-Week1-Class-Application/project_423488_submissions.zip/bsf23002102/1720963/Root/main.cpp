/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/


#include <iostream>
using namespace std;
class Bank {
	private:
		string Account_Title;
		int Balance;
		string Type;
		float Profit_percent;
	public:
		void getDetails(){
			cout << "Enter Account Title: ";
			cin >> Account_Title;
			cout << "Enter the balance: ";
			cin >> Balance;
			cout << "Choose type (saving or pl): ";
			cin >> Type;
		}
		float Profit_Cal(){
			if(Type == "saving"){
				Profit_percent = (5 * Balance / 100) + Balance;
				return Profit_percent;
			} else if(Type == "pl"){
				Profit_percent = (8 * Balance / 100) + Balance;
				return Profit_percent;
			}
		}
		void Display(){
			cout << "After profit increment amount is: " << Profit_percent;
		}
};
main(){
    cout << "----Bank Account Details----" << endl;
	Bank Account1;
	Account1.getDetails();
	Account1.Profit_Cal();
	Account1.Display();
	cout << endl<< endl;
	
	cout << "------------------------" << endl;
	cout << endl;
	cout << "----Another Bank Account Details----" << endl;
	Bank Account2;
	Account2.getDetails();
	Account2.Profit_Cal();
	Account2.Display();
}