/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class Account{
	private:
		string A_title;
		string A_type;
		float Amount;
		string profit_weighg;
	public:
		
	    void take_details(){
	    	
	    	cout<<"Enter your account title(ie. your name) : ";
	        cin>>A_title;
	        cout<<"Enter your account type(ie. pls or savings) : ";
	        cin>>A_type;
	        cout<<"Enter your current balance : ";
	        cin>>Amount;
	        if(A_type=="pls" ){
	           profit_weighg="8%";
	        }
	        else if(A_type=="savings" ){
	           profit_weighg="5%";
	       }
	       
	        Amount = present_balance( Amount , A_type);
		}
		
		
	    float present_balance(float Amount2 ,string A_type2)
		{
			float t_balance;
	        if(A_type2=="savings" ){
		        t_balance =  (5.0*Amount2)/100.0 + Amount2;
	        }
	        else if (A_type2=="pls" )
		        t_balance =  (8.0*Amount2)/100.0 + Amount2;
	            return t_balance;
		}
		
	    void show_details(){

		cout<<"your account's title : "<<A_title<<endl;
	    cout<<"Your Account's type is : "<<A_type<<endl;
	    cout<<"Your Profit weight is : "<<profit_weighg<<endl;
	    cout<<"Your Account's Amount  is : "<<Amount<<endl;
		}
};
int main()
{
	Account User1;
	Account User2;
	cout<<"ENTER DETAILS FOR 1 "<<endl;
	User1.take_details();
	
	cout<<"ENTER DETAILS FOR  2 "<<endl;
	User2.take_details();
	
	cout<<"final result for 1"<<endl;
	User1.show_details();
		
	
	cout<<"final result for 2"<<endl;
	User2.show_details();	
	return 0;
}