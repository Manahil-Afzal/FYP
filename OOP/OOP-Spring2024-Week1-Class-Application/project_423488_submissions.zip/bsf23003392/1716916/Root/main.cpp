/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
#include<string>
#include <cstdlib>
using namespace std;
class MYaccount{
	string account_title;
	int current_balance;
	char account_type;
	int existing_balance;	
	public:
	int getdata();
	int putdata();	
	};		
	int MYaccount::getdata()
	{
		cout<<"Enter account_title:"<<endl;
		getline(cin,account_title);
		cout<<"Enter Existing_balance:"<<endl;
		cin>>existing_balance;
		cout<<"Enter account_type (S for savings while P for PLS (profit and loss sharing)"<<endl;
		cin>>account_type;
		
			if(account_type=='S'||account_type=='s')
			{
				current_balance=existing_balance+0.05*existing_balance;
			}
				else if(account_type=='P'||account_type=='p')
				{
					current_balance=existing_balance+0.08*existing_balance;
				}
				else
				{ 
					cout<<"Invalid input Please enter the S for savings while P for PLS (profit and loss sharing!Thank you.";
					exit(1);
				}
				return 0;
	} 	
	int MYaccount::putdata()
		{
			cout<<"Account_title:"<<account_title<<endl;
			cout<<"Account_type:"<<account_type<<endl;
			cout<<"Existing_balance:"<<existing_balance<<endl;
			cout<<"Current_balance:"<<current_balance<<endl;
		}
		int main(){			
			MYaccount Account_details;
			Account_details.getdata();
			Account_details.putdata();
			return 0;			
		}