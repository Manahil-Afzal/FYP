/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class Bank_acount{
	
	string title;
	string type;
	int balance;
	string name;
	float profit_percent;
	public:
	void input(int i);
	void display(int i);
};
void Bank_acount::input(int i){
	cout<<endl;
	cout<<" bank account details of user "<<i<<endl;
	cout<<"enter your name:"<<endl;
    cin>>name;
	cout<<"enter bank title"<<endl;
	cin>>title;
	cout<<"enter your account type only small words and capital words:"<<endl;
	cin>>type;
	cout<<"enter balance"<<endl;
	cin>>balance;
}
void Bank_acount::display(int i){
	cout<<endl;
	cout<<"the bank acount of information of user "<<i<<endl;
	cout<<"your name is "<<name<<endl;
	cout<<"your account type is "<<type<<endl;
	if(type =="savings" || type=="SAVINGS"  ||  type=="SAVING"  ||  type=="saving" ){
        balance +=(balance/100)*5;
        cout<<"Your profit percentage is 5% "<<endl;
        cout<<"Your current balance is  "<<balance;
	}else if(type=="PLS"  ||  type=="pls"){
		balance +=(balance/100)*8;
		cout<<"Your profit percentage is 8% "<<endl;
        cout<<"Your current balance is  "<<balance;   
	}else{
		cout<<"inappropriate bank account type"<<endl;
	}
}
int main(){
	int n=1;
	Bank_acount user1;
    Bank_acount user2;
    user1.input(n);
	user1.display(n);
	n++;
	user2.input(n);
	user2.display(n);
	return 0;
	
}
