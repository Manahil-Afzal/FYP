#include<iostream>
#include<string>
using namespace std;

class bankAccount
{
private:
	string accTitle;
	string accType;
	float balance;
	float profitPercent;
public:
     void Account();
	 void display();
};


void bankAccount::Account()
{cout<<"Account title: ";
 cin>>accTitle;
 cout<<"Account Type: ";
 cin>>accType;
 cout<<"Balance: ";
 cin>>balance;
 if(accType == "savings")
 {
 profitPercent = 0.05* balance;
 balance = profitPercent + balance;}
 else
 {
 profitPercent = 0.08 * balance;
 balance = profitPercent + balance;
}
}

void bankAccount::display()
{cout<<"Account Title = "<<accTitle<<endl;
cout<<"Account Type = "<<accType<<endl;
cout<<"Current Balance = "<<balance<<endl;
cout<<"Profit = "<<profitPercent<<endl;
}


int main()
{bankAccount acc1;
cout<<"Enter details of Account 1 :"<<endl;
acc1.Account();
bankAccount acc2;
cout<<"Enter details of Account 2 :"<<endl;
acc2.Account();
cout<<endl<<"Details of Account 1 :"<<endl;
acc1.display();
cout<<endl<<"Details of Account 2 :"<<endl;
acc2.display();
return 0;
}/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/