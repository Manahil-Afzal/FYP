/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Method to take input for data members from user
    void inputDetails() {
        cout << "Enter Account Title: ";
        getline(cin, accountTitle);
        cout << "Enter Account Type (savings or PLS): ";
        getline(cin, accountType);
        cout << "Enter Balance: ";
        cin >> balance;
        cin.ignore(); // Ignore newline character in input buffer
    }

    // Method to calculate current balance with profit
    void calculateBalance() {
        if (accountType == "savings") {
            profitPercent = 5;
        } else if (accountType == "PLS") {
            profitPercent = 8;
        } else {
            cout << "Invalid account type!" << endl;
            return;
        }
        double profit = (profitPercent / 100) * balance;
        balance += profit;
    }

    // Method to display account details
    void displayDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: $" << balance << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" << endl;
    account1.inputDetails();
    account1.calculateBalance();

    cout << "\nEnter details for Account 2:" << endl;
    account2.inputDetails();
    account2.calculateBalance();

    cout << "\nDetails of Account 1:" << endl;
    account1.displayDetails();

    cout << "\nDetails of Account 2:" << endl;
    account2.displayDetails();

    return 0;
}
