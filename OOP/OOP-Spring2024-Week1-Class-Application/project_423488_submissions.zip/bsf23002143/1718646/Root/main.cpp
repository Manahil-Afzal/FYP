#include <iostream>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Constructor
    BankAccount(string title, string type, double initialBalance, double percent) {
        accountTitle = title;
        accountType = type;
        balance = initialBalance;
        profitPercent = percent;
    }

    // Function to display account details
    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    // Creating a BankAccount object
    BankAccount myAccount("Habiba", "Savings", 8000, 5);

    // Displaying the account details
    myAccount.displayAccountDetails();

    return 0;
}

