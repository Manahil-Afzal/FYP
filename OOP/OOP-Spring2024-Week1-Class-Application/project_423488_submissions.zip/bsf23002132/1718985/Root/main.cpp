#include<iostream>
using namespace std;
class bankaccount{

private:
	string accounttitle;
	string accounttype;
	int balance;
	double profitpercent;
	public:
		void getinfo(){
			cout<< "Enter the account title"<<endl;
			cin>>accounttitle;
			cout<<"Enter the account type"<<endl;
			cin>>accounttype;
			cout<<"Enter the balance"<<endl;
			cin>>balance;
		}
		void calbalance(){
			if(accounttype=="savings"){
				balance=(balance)+(0.05*balance);
			}
			else
			balance=(balance)+(0.08*balance);
		}
		void printinfo(){
			cout<<"Account title is"<<accounttitle<<endl;
			cout<<"Account type is"<<accounttype<<endl;
			cout<<"Account balance is"<<balance<<endl;
			cout<<"Current balance is"<<balance<<endl;
		}
	};
	int main(){
		bankaccount a;
		bankaccount b;
		a.getinfo();
		a.calbalance();
		a.printinfo();
		b.getinfo();
		b.calbalance();
		b.printinfo();
		return 0;
	}