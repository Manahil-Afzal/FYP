/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;

class BankAccount {
public:
    string accountTitle;
    string accountType;
    long balance;
    double profitPercentage;
    double current_balance;

    void getData() {
        cout << "Enter account title: ";
        cin >> accountTitle;

        cout << "Enter your current balance: ";
        cin >> balance;

        cout << "Press 1 for savings account or press 2 for PLS account: ";
        int accountTypeChoice;
        cin >> accountTypeChoice;

        if (accountTypeChoice == 1) 
        {
            accountType = "savings";
            profitPercentage = 5.0;
            current_balance = balance + (balance * profitPercentage / 100.0);
        }
        else if (accountTypeChoice == 2) 
        {
            accountType = "PLS";
            profitPercentage = 8.0;
            current_balance = balance + (balance * profitPercentage / 100.0);
        }
        else 
        {
            cout << "Invalid choice. Defaulting to savings account." ;
            accountType = "savings";
            profitPercentage = 5.0;
            current_balance = balance + (balance * profitPercentage / 100.0);
        }
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:\n";
    account1.getData();

    cout << "\nEnter details for Account 2:\n";
    account2.getData();


    cout << "\nDetails for Account 1:\n";
    cout << "Account Title: " << account1.accountTitle << endl;
    cout << "Account Type: " << account1.accountType << endl;
    cout << "Original Balance: $" << account1.balance << endl;
    cout << "Current Balance: $" << account1.current_balance << endl;
    cout << "Profit Percentage: " << account1.profitPercentage << "%" << endl;

    cout << "\nDetails for Account 2:\n";
    cout << "Account Title: " << account2.accountTitle << endl;
    cout << "Account Type: " << account2.accountType << endl;
    cout << "Original Balance: $" << account2.balance << endl;
    cout << "Current Balance: $" << account2.current_balance << endl;
    cout << "Profit Percentage: " << account2.profitPercentage << "%" << endl;

    return 0;
}
