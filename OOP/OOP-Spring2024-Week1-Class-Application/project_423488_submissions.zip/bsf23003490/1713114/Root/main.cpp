/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankaccount{
	public:
	string accounttitle;
	string accounttype;
	double balance;
	float profitpercent;
	void input(void);
	void profit(void);
};
void bankaccount::input()

{
	cout<<"enter your account title"<<endl;
	cin>>accounttitle;
	cout<<"Enter Your Account Type"<<endl;
	cin>>accounttype;
	cout<<"enter your balance"<<endl;
	cin>>balance;

}
void bankaccount::profit(void){
	if(accounttype=="savings")
	
	{
		balance+=(balance*5)/100;
		cout<<balance<<endl;
	}
	else  
	{
	if(accounttype=="PLS")
	{
		 balance+=(balance*8)/100;
		 cout<<balance<<endl; 
	}
	else 
	{
		cout<<"inappropriate intput............................................."<<endl;
	}
	}
}
int main()
{
bankaccount zain;
zain.input();	
zain.profit();
	
}