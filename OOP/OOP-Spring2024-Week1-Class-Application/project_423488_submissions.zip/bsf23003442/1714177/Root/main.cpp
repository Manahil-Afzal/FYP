#include<iostream>
#include<string>
using namespace std;
class bank{
	public:
		int balance;
		int profit;
		string account_type;
		string account_title;
		void get(){
			cout<<"Enter the account title:";
			cin>>account_title;
			cout<<"Enter the account type:";
			cin>>account_type;
			cout<<"Enter the existing balance:";
			cin>>balance;
		}
		void allow(){
			if(account_type=="savings"||account_type=="Savings"){
				profit=balance*0.05;
				balance=balance+profit;}
				else if(account_type=="pls"||account_type=="PLS"){
					profit=balance*0.08;
					balance=profit+balance;
				}
				else{
					cout<<"Wrong Choice!";
				}
		}
		void display(){
			cout<<"Your account title is "<<account_title<<endl;
			cout<<"Your aaccount type is "<<account_type<<endl;
			cout<<"Your current balance is "<<balance<<endl;
		}
};
int main(){
	bank hbl,meezan;
	hbl.get();
	hbl.allow();
	hbl.display();
	meezan.get();
	meezan.allow();
	meezan.display();
}/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/