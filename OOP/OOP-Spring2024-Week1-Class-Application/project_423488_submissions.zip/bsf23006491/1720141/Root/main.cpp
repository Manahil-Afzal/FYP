/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankaccount
{
    private:
    string account_title,account_type;
    float balance,profit_percent;
    public:
    void gettingdetails()
    {
        cout<<"Enter Account Title:";
        cin>>account_title;
        cout<<"Enter Account Type (savings/pls):";
        cin>>account_type;
        cout<<"Enter Current Balance:";
        cin>>balance;
        cout<<"Enter Profit Percent:";
        cin>>profit_percent;
    }
    void processing()
    {
        if (account_type=="savings")
        {
            balance+=0.05*balance;
        }
        else if (account_type=="pls")
        {
            balance+=0.08*balance;
        }
    }
    void displaying_details()
    {
        cout<<"Account Title:"<<account_title<<endl;
        cout<<"Account Type:"<<account_type<<endl;
        cout<<"Balance:"<<balance<<endl;
        cout<<"Profit Percent:"<<profit_percent<<endl;
    }
};
int main()
{
    bankaccount obj1,obj2;
    cout<<"Details of First Account:"<<endl;
    obj1.gettingdetails();
    cout<<"Details of Second Account:"<<endl;
    obj2.gettingdetails();
    obj1.processing();
    cout<<"First Account details:"<<endl;
    obj1.displaying_details();
    obj2.processing();
    cout<<"Second Account details:"<<endl;
    obj2.displaying_details();
    return 0;
}