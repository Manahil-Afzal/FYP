/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankacc{
	private :
		string acc_title,acc_type;
		double balance,profit;
	public :
		void getdata(){
			cout<<"\nenter account title\n";
			cin>>acc_title;
			cout<<"enter account type either \"saving\" or \"pls\"\n";
			cin>>acc_type;
			cout<<"enter balance\n";
			cin>>balance;
			cout<<endl;
		}
		void cal(){
			if(acc_type=="saving"){
				profit=5;
				balance+=profit*balance/100; 
				}
		    else if(acc_type=="pls"){
				profit=8;
				balance+=profit*balance/100;
				}
		}
		void output(){
			cout<<"account title is : "<<acc_title<<endl;
			cout<<"account type is : "<<acc_type<<endl;
			cout<<"profit percentage is :"<<profit<<endl;
			cout<<"new balance is :"<<balance<<endl<<endl;
		}
};

int main(){
	bankacc acc1,acc2;
	acc1.getdata();
	acc2.getdata();
	acc1.cal();
	acc2.cal();
	acc1.output();
	acc2.output();
 return 0;
}