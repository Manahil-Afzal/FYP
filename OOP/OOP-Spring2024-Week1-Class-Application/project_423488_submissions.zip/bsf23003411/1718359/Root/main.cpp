/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankacc{
	public:
    string title;
    string type;
    float balance;
    float profitpercent;
    void getdetails(){
    	cout<<"Enter title: ";
    	cin>>title;
    	cout<<"Enter type: ";
    	cin>>type;
		cout<<"Enter balance: ";
    	cin>>balance;
		cout<<"Enter profit: ";
    	cin>>profitpercent;
	}
    void baldetails(){
        if(type=="savings"){
		
		balance += (0.05 * balance);} 
        else if(type=="pls"){
		
		balance += (0.08 * balance) ;}
   }
   void displaydetails(){
   	cout<<"Title is: "<<title<<endl;
   	cout<<"Type is: "<<type<<endl;
   	cout<<"Balance is: "<<balance<<endl;
   	cout<<"Profit is: "<<profitpercent<<"%"<<endl;
   }}; 

int main(){
	bankacc obj1;
	bankacc obj2;
	cout << "Enter details for Account 1: "<<endl;
obj1.getdetails();
cout << "Enter details for Account 2: "<<endl; 
obj2.getdetails();
obj1.baldetails();
obj2.baldetails();
cout << "Account Details for Account 1: "<<endl;
obj1.displaydetails();
cout << "Account Details for Account 2: "<<endl;
obj2.displaydetails();
  
    
    return 0;
}