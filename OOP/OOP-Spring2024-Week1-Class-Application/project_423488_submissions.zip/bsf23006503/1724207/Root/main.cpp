/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class Bank_account{
      private:
	  string title;
	  string account_type;
	  int balance;
	  float pro_per;
	  public:
	  void input_user(){

	cout<<"Enter a Account title:";
	cin>>title;
	cout<<"Enter a Account type saving/pls:";
	cin>>account_type;
	cout<<"Ente a balance: ";
	cin>>balance;
	cout<<"Enter a percentage:";
	cin>>pro_per;
}

    void calculatebalance() {
         if(account_type == "saving")
        {
            balance += (0.05 * balance);
        }
        else if(account_type == "pls")
        {
            balance += (0.08 * balance);
        }

}
    void displayDetails() {
    	cout<<"=========Bank Details=============\n";
        cout << "Account Title: " <<title <<endl;
        cout << "Account Type: " << account_type <<endl;
        cout << "Balance: " << balance <<endl;
        cout<<"percentage:"<<pro_per<<endl;
    }
};
int main() {
    
     Bank_account account1 , account2;
    account1.input_user();
    account2.input_user();

    account1.calculatebalance();
    account2.calculatebalance();

    account1.displayDetails();
    account2.displayDetails();
    return 0;
}
