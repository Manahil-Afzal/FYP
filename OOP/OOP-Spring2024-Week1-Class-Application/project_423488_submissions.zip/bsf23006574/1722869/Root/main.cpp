/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankAcc{
public:
    string acctitle;
    string acctype;
    double balance;
    double profit_percent;
    
    void takeinput();
    void Calbalance();
    void displayDetails();
};
void bankAcc::takeinput(){
    cout<<"enter acccount title=";
    cin>>acctitle;
    cout<<"enter account type=";
    cin>>acctype;
    cout<<"enter baloance=";
    cin>>balance;
    cout<<"enter profit percent=";
    cin>>profit_percent;
} 
  void bankAcc::Calbalance(){
      if(acctype=="savings"){
          profit_percent=5.0;
      }
      else if(acctype=="PLS"){
          profit_percent=8.0;
      }
      double profit=balance*(profit_percent/100.0);
      balance+=profit;
  }
  void bankAcc::displayDetails()
  {
      cout<<"account title is"<<acctitle<<endl;
      cout<<"account typeis"<<acctype<<endl;
      cout<<"account balance is"<<balance;
      cout<<"profit_percent is"<<profit_percent;
  }
  int main(){
      bankAcc Acc1,Acc2;
      cout<<"enter details for Acc1:"<<endl;
      Acc1.takeinput();
      Acc1.Calbalance();
      Acc1.displayDetails();
      
            cout<<"enter details for Acc2"<<endl;
      Acc2.takeinput();
      Acc2.Calbalance();
      Acc2.displayDetails();
      
      
      return 0;
  }