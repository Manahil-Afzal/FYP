/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class myAccount{
	private:
		
	string accountTitle;
	string accountType;
	float balance;
	float profitPercent;
	
	public:
		void input();
		void output();

};
int main()
{
	myAccount person1,person2;
	cout<<"enter information for 1st person"<<endl;
	person1.input();
		cout<<"enter information for 2nd person"<<endl;
		person2.input();
		cout<<"for 1st person";
		person1.output();
		cout<<"for 2nd person";
		person2.output();
		
}
	
	void myAccount::output(){
		cout<<"accountTitle="<<accountTitle<<endl;
		cout<<"accountType="<<accountType<<endl;
		cout<<"curnt balance="<<balance<<endl;
		cout<<"profitPercent="<<profitPercent<<endl;
	}
		void  myAccount::input()
	{
	  cout<<"enter account title=";
	  cin>>accountTitle;
	  cout<<"enter account type=";
	  cin>>accountType;
	  cout<<"enter balance=";
	  cin>>balance;
	  
	if(accountType=="savings")
	{    profitPercent=5;
		balance=balance+(5.0/100*balance);
	}
	else
	{
		 profitPercent=8;
		balance=balance+(8.0/100*balance);
	}
	
		}	
