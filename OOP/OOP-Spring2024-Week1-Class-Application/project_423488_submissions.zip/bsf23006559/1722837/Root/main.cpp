/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
class BankAccount {
private:
    string accountTitle;
    string accountType;
     int  balance;
    int profitPercent;

public:
     void getinput();
     void display();
};

  
    void BankAccount::getinput() {
        cout << "Enter Account Title: ";
        cin >> accountTitle;
        cout << "Enter Account Type (Savings or PLS): ";
        cin >> accountType;
        cout << "Enter Balance: ";
        cin >> balance;
            if(accountType == "Savings"){
        	profitPercent=0.05* balance;
             balance=profitPercent +balance;  
        } else if (accountType == "PLS") {
            profitPercent=0.08*balance;
            balance=profitPercent +balance;
        }
    }
              void BankAccount::display() {
        cout << "\nAccount Details:\n";
        cout << "Account Title: " << accountTitle <<endl;
        cout << "Account Type: " << accountType <<endl;
        cout << "Current Balance: $" << balance <<endl;
        cout <<" Profit"<<profitPercent<<endl;
    }
 
int main() {
    BankAccount account1, account2;
    cout<<"Enter details for account 1"<<endl;
    account1.getinput();   
	cout<<"Details of accunt 1"<<endl;
    account1.display();
     cout<<"Enter details for account 2"<<endl;
     account2.getinput();
      cout<<"Details of accunt 2";
         account2.display();
    return 0;
}
