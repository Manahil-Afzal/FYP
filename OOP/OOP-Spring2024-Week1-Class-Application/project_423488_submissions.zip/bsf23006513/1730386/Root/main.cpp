/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bank{
	public:
		string Acctitle;
		int Acctype;
		int Balance;
		float profit=0;
//		INPUT FUNCTION
		void input()
		{
				cout<<"Enter Account Title : ";
	cin>>Acctitle;
	cout<<"Enter Account Type For Saving (1) And For Pls (2) For other (3) : ";
	cin>>Acctype;
	cout<<"Enter Account Balance : ";
	cin>>Balance;
		}
		
		
//		CALCULATION FUNCTION	
		
		void cal()
{
	if(Acctype == 1)
		{
			profit=Balance*0.05;
		}
	else if(Acctype == 2)
	{
		profit=Balance*0.08;
	}
	else
	{
		profit=0;
		
	}	
	
}
//    DISPLAY FUNCTION
void dis()
{
	cout<<"Your Account Title :"<<Acctitle<<"\n";
	cout<<"Your Account Type  :"<<Acctype<<"\n";
	cout<<"Your Balance Brfore Profit :"<<Balance<<"\n";
	cout<<"your Balance After Profit :"<<Balance+profit<<"\n";
}
		 
		
};

int main()
{
	bank Obj1;
	Obj1.input();
	Obj1.cal();	
	cout<<"\n\n";
	cout<<"Displaying Data OF Object 1";
	cout<<"\n\n";
	Obj1.dis();	
	cout<<"\n\n";
	Obj1.input();
	Obj1.cal();
	cout<<"\n\n";
	cout<<"Displaying Data OF Object 2";
	cout<<"\n\n";
	Obj1.dis();		
	
}