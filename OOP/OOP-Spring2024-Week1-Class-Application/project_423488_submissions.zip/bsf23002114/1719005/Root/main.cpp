/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/



#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;

public:
   
    void inputDetails() {
        cout << "Enter Account Title: ";
        cin>> accountTitle;

        cout << "Enter Account Type (savings/PLS): ";
        cin >> accountType;

        cout << "Enter Initial Balance: ";
        cin >> balance;
    }

    
    void calculateBalance() {
        if (accountType == "savings") {
            balance += balance * 0.05; 
        } else if (accountType == "PLS") {
            balance += balance * 0.08;
        }
    }

    void displayDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: " << balance << endl;
    }
};

int main() {
    BankAccount account;

    
    cout << "Enter details for the account:" << endl;
    account.inputDetails();
    account.calculateBalance();

 
    cout << "\nDetails for the account:" << endl;
    account.displayDetails();

    return 0;
}

