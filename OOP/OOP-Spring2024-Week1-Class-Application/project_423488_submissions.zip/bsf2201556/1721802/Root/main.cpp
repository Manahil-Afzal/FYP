/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/


#include <iostream>
#include <string>

class BankAccount {
private:
    std::string accountTitle;
    std::string accountType;
    double balance;
    double profitPercent;

public:
    
    void inputDetails() {
        std::cout << "Enter Account Title: ";
        std::getline(std::cin, accountTitle);

        std::cout << "Enter Account Type (savings or PLS): ";
        std::cin >> accountType;

        std::cout << "Enter Initial Balance: ";
        std::cin >> balance;

        std::cout << "Enter Profit Percentage: ";
        std::cin >> profitPercent;
    }

    
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (0.05 * balance);  
        } else if (accountType == "PLS") {
            balance += (0.08 * balance);  
        }
    }

    
    void displayDetails() {
        std::cout << "\nAccount Title: " << accountTitle << std::endl;
        std::cout << "Account Type: " << accountType << std::endl;
        std::cout << "Current Balance: $" << balance << std::endl;
        std::cout << "Profit Percentage: " << profitPercent << "%" << std::endl;
    }
};

int main() {
    
    BankAccount account1, account2;

    
    std::cout << "Enter details for Account 1:\n";
    account1.inputDetails();
    account1.calculateBalance();

    
    std::cout << "\nEnter details for Account 2:\n";
    account2.inputDetails();
    account2.calculateBalance();


    std::cout << "\nAccount Details for Account 1:\n";
    account1.displayDetails();

    std::cout << "\nAccount Details for Account 2:\n";
    account2.displayDetails();

    return 0;
}