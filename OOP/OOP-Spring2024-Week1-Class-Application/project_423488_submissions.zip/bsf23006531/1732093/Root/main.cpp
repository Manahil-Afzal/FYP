#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    void inputData() {
        cout << "Enter Account Title: ";
        getline(cin, accountTitle);
        cout << "Enter Account Type (savings/PLS): ";
        cin >> accountType;
        cout << "Enter Balance: ";
        cin >> balance;
        cout << "Enter Profit Percent: ";
        cin >> profitPercent;
    }

    void calculateBalance() {
        if (accountType == "savings") {
            balance += balance * (profitPercent / 100.0 * 0.05); 
        } else if (accountType == "PLS") {
            balance += balance * (profitPercent / 100.0 * 0.08);
        }
    }

    void display() {
        cout << "\nAccount Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:\n";
    account1.inputData();
    account1.calculateBalance();

    cout << "\nEnter details for Account 2:\n";
    cin.ignore();
    account2.inputData();
    account2.calculateBalance();

    cout << "\nAccount Details:\n";
    cout << "-----------------\n";
    cout << "Account 1:\n";
    account1.display();
    cout << "\nAccount 2:\n";
    account2.display();

    return 0;
}
