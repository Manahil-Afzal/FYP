#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
       void inputDetails() {
        cout << "Enter Account Title: ";
        getline(cin, accountTitle);

        cout << "Enter Account Type (Savings/PLS): ";
        getline(cin, accountType);

        cout << "Enter Balance: ";
        cin >> balance;     
        cin.ignore();

        if (accountType == "Savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS") {
            profitPercent = 8.0;
        } else {
            cout << "Invalid account type entered." << endl;
        
        }

      
        balance += (balance * profitPercent / 100);
    }

   
    void displayDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1: " << endl;
    account1.inputDetails();

    cout << "Enter details for Account 2: " << endl;
    account2.inputDetails();

    cout << "\nDetails of Account 1: " << endl;
    account1.displayDetails();

    cout << "\nDetails of Account 2: " << endl;
    account2.displayDetails();

    return 0;
}
