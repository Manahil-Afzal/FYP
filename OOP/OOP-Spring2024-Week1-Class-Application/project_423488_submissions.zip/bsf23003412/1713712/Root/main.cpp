#include <iostream>
using namespace std;

class bank{
	public:
	string acctitle;
	string acctype;
	float balance;
	float profitperc;
	void myfunc(){
	
	cout<<"enter the account title"<<endl;
	cin>>acctitle;
	cout<<"enter the account type(saving/pal)"<<endl;
	cin>>acctype;
	cout<<"enter the balance you have"<<endl;
	cin>>balance;
	cout<<"enter your profit percentage"<<endl;
	cin>>profitperc;
}
	void profit(){
	
	if(acctype=="saving"){
		balance+=balance*profitperc/100;
	
	
	}
	else if(acctype=="pal"){
		balance+=balance*profitperc/100;
	
	
	
}}
void details(){
    //for new balance
	cout<<"bankaccount details"<<endl;
	cout<<"your title is"<<acctitle<<endl;
	cout<<"your account type"<<acctype<<endl;
	cout<<"your balance is"<<balance<<endl;
	cout<<"your profit percentage is"<<profitperc<<"%"<<endl;
}
};
int main(){
	bank obj1,obj2;
	cout<<"bank account status for obj1"<<endl;
	obj1.myfunc();
	obj1.profit();
	obj1.details();
	cout<<"bank account status for obj2"<<endl;
	obj2.myfunc();
	obj2.profit();
	obj2.details();
	return 0;
}