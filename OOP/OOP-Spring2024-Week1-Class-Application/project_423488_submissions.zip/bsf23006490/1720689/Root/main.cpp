/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
                                                //*****CODE*****
#include<iostream>
using namespace std;
class BankACC{
	public:
		string ACC_Tittle;
		string ACC_Type;
		int ACC_Balance;
		float Profit_Balance;
		float Total_Balance;
		void ACC_Details();
		void Calculate_Profit( );
		void Display_Details();
};
void BankACC::ACC_Details(){
cout<<"Enter Account Tittle:";
cin>>ACC_Tittle;
cout<<"Enter Account Type (Saving/PLS):";
cin>>ACC_Type;
cout<<"Enter Account Balance:";
cin>>ACC_Balance;
}
void BankACC::Calculate_Profit(){
	if(ACC_Type=="Saving" )
	{
		Profit_Balance+= (0.05 * ACC_Balance);
		Total_Balance=Profit_Balance+ACC_Balance;
	}
	else if(ACC_Type=="PLS" ){
		Profit_Balance+= (0.08 * ACC_Balance);
		Total_Balance=Profit_Balance+ACC_Balance;
	}
}
void BankACC::Display_Details(){
cout<<"Account Tittle:"<<ACC_Tittle<<endl;
cout<<"Account Type:"<<ACC_Type<<endl;
cout<<"Account Balance:"<<ACC_Balance<<endl;
cout<<"Profit Balance:"<<Profit_Balance<<endl;
cout<<"Total Balance:"<<Total_Balance<<endl;
}
int main()
{
	BankACC Account_1,Account_2;
	cout<<"Enter Details for Account 01"<<endl;
	Account_1.ACC_Details();
	cout<<endl<<"Enter Details for Account 02"<<endl;
	Account_2.ACC_Details();
	Account_1.Calculate_Profit();
	Account_2.Calculate_Profit();
	cout<<endl<<"Details of Account 01"<<endl;
	Account_1.Display_Details();
	cout<<endl<<"Details of Account 02"<<endl;
	Account_2.Display_Details();
	
}                                   