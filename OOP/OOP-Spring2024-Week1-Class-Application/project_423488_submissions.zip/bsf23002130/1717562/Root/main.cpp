
/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankAccount{
	private:
		string acc_title;
		int acc_type;
		float Balance;
		float Profit_Percent;
		public:
			void getDetails();
			void showDetails();
			
};

int main(){
	bankAccount hold1 ;
	hold1.getDetails();
	hold1.showDetails();
	bankAccount hold2;
	hold2.getDetails();
	hold2.showDetails();
	return 0;
	
}

void bankAccount::getDetails() {
	cout<<"Enter your details"<<endl;
	cout<<"Enter your Name"<<endl;
	cin>>acc_title;
	cout<<"Select your Account type:"<<endl<<"1.Saving"<<endl<<"2.Current"<<endl;
	cin>>acc_type;
	cout<<"Enter your Account Balance:";
	cin>>Balance;
	
}

void bankAccount::showDetails(){
	cout<<"Welcome "<<acc_title<<endl;
	if(acc_type==1){
		cout<<"Thanks for selecting saving Account!"<<endl;
		
	}
	else if(acc_type==2){
		cout<<"Thanks for selecting Current Account!"<<endl;
	}
	else{
		cout<<"Please enter a valid selection!"<<endl;
	}
	cout<<"Your Previous Balance:"<<Balance<<endl;
	if(acc_type==1){
		Profit_Percent=Balance+(Balance*0.05);
		cout<<"Your new Balance with Profit:"<<Profit_Percent<<endl;
		
	}
	else if (acc_type==2) {
		Profit_Percent=Balance+(Balance*0.08);
		cout<<"Your new Balance after adding Profit:"<<Profit_Percent<<endl;
		
	}
	
}
