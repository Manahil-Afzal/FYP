/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
#include<stdlib.h>
using namespace std;
class bank_account{
    string acc_title;
    string acc_type;
    int bal;
    int profit;
    int exist_bal;
    public:
    void setdata();
    void current_bal();
    void getdata();
    };
void bank_account::setdata(){
    cout<<"Enter the account title"<<endl;
    cin>>acc_title;
    cout<<"enter savings for saving acc and PLS for profit sharing acc"<<endl;
    cout<<"enter the account type"<<endl;
    cin>>acc_type;
    cout<<"Enter Current Balance"<<endl;
    cin>>bal;
}
void bank_account::current_bal(){
    if(acc_type=="savings"){
        cout<<"The profit per is 5%"<<endl;
        profit=(5*bal)/100;
        exist_bal=profit+bal;
    }
    else if(acc_type=="PLS"){
        cout<<"The profit per is 8%"<<endl;
        profit=(8*bal)/100;
        exist_bal=profit+bal;
    }
    else{
    	cout<<"Please enter correct input"<<endl;
    	exit(0);
	}
}
void bank_account::getdata(){
    cout<<"Your account title is"<<acc_title<<endl;
    cout<<"Your account type is"<<acc_type<<endl;
    cout<<"Your existing bal is"<<bal<<endl;
    cout<<"Your current balance after adding profit is"<<exist_bal<<endl;
    
}
int main(){
   bank_account zuha_account;
   zuha_account.setdata();
   zuha_account.current_bal();
   zuha_account.getdata();
   return 0;
}