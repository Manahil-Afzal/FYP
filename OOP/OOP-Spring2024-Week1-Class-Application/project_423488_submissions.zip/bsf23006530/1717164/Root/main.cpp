/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
using namespace std;

class BankAccount {
public:
    string AccTitle;
    string AccType;
    double balance;
    double profitPercent;

void Myinput() {
        cout<<"Enter Account Title: ";
        cin>>AccTitle;

        cout<<"Enter Account Type (savings or PLS): ";
        cin>>AccType;

        cout<<"Enter Initial Balance: ";
        cin>>balance;

        cout<<"Enter Profit Percentage: ";
    	cin>>profitPercent;
    }

void MyBalance() {
        if (AccType == "savings") {
            balance += balance * (profitPercent / 100.0);
        } else if (AccType == "PLS") {
            balance += balance * (profitPercent / 100.0);
        }
    }

void MyDetails() {
    cout<<"\nAccount Title: "<< AccTitle << "\n";
    cout<<"Account Type: "<< AccType << "\n";
    cout<<"Current Balance: "<< balance << "\n";
    cout<<"Profit Percentage: "<< profitPercent << "%\n";
    }
};

int main() {
    
    BankAccount Acc1, Acc2;

    
    cout<<"Enter input for Account 1:\n";
    Acc1.Myinput();

    cout<<"\nEnter input for Account 2:\n";
    Acc2.Myinput();

    
    Acc1.MyBalance();
    Acc2.MyBalance();

    
    cout<<"\nAccount Details for Account 1:\n";
    Acc1.MyDetails();

    cout<<"\nAccount Details for Account 2:\n";
    Acc2.MyDetails();

    return 0;
}
