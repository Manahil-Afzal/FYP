/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankaccount{
    int  accountid;
	string accounttype;
	int balance;
	float profit_percent;
	public:
		bankaccount(){
			cout<<"YOU HAVE TWO CHOICES: "<<endl;
			cout<<"1. saving "<<endl;
			cout<<"2. PLS "<<endl;}
	    ~bankaccount(){
		
 cout<<"Thanks For Contacting Us "<<endl;}
		void input(void);
		void profit(void);
	
};
void bankaccount::input(void)
{
	cout<<"Enter Your account id "<<endl;
	cin>>accountid;
	cout<<"Enter Your account type "<<endl;
	cin>>accounttype;
	cout<<"Enter Your balance "<<endl;
	cin>>balance;
}
void bankaccount::profit(void)
{
	if (accounttype=="saving")
	{
	int result=	balance+=(balance*5)/100;
	cout<<"The Profit Is "<<result<<endl;
	}
	else
	{
		if(accounttype=="PLS")
		{
			int result=balance+=(balance*8)/100;
			cout<< "The Profit Is "<<result<<endl;}
			else{
			
			cout<<"inappropriate input "<<endl;
	}
	}
}
 
int main()
{
	bankaccount hbl;
	hbl.input();
	hbl.profit();
}
