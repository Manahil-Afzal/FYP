/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string account_title;
    string account_type;
    double balance;
    double profit_percent;

public:
    BankAccount() {
        // Default constructor
    }

    void input_details() {
        cout << "Enter Account Title: ";
        cin.ignore();
        getline(cin, account_title);
        cout << "Enter Account Type (Savings/PLS): ";
        cin >> account_type;
        cout << "Enter Balance: ";
        cin >> balance;
        cout << "Enter Profit Percentage: ";
        cin >> profit_percent;
    }

    void calculate_balance() {
        if (account_type == "Savings") {
            balance += (balance * (profit_percent / 100.0));
        } else if (account_type == "PLS") {
            balance += (balance * (profit_percent / 100.0));
        }
    }

    void display_details() {
        cout << "Account Title: " << account_title << endl;
        cout << "Account Type: " << account_type << endl;
        cout << "Balance: " << balance << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" << endl;
    account1.input_details();
    account1.calculate_balance();

    cout << "\nEnter details for Account 2:" << endl;
    account2.input_details();
    account2.calculate_balance();

    cout << "\nDetails of Account 1:" << endl;
    account1.display_details();

    cout << "\nDetails of Account 2:" << endl;
    account2.display_details();

    return 0;
}
