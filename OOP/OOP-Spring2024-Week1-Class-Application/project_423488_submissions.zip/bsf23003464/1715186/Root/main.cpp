/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
//class, constructor
#include <iostream>
#include<string>
using namespace std;
class Bank_account{
    public:
    string name;
    int type;
    double balance;
    int profit_percent;
    void profit(){
        if(type==1)
        {
            profit_percent=balance+balance*0.05;
            cout<<"Your Account is Saving Account"<<endl;
        }
        else if(type==2)
       {  profit_percent=balance+balance*0.08;
       cout<<"Your Account is Profit & Loss Account"<<endl;
            }
            double updated_balance = profit_percent+balance;
            cout<<"Your Name ="<<name<<endl;
            cout<<"Your Balance ="<<balance<<endl;
            cout<<"Your Profit ="<<profit_percent<<endl;}

    
    
};
int main(){
    Bank_account obj1,obj2;
    cout<<"Enter The Name of the User=";
    cin>>obj1.name;
    cout<<"Enter The Account Type(Type 1 for Saving Account and 2 for profit & loss account)=";
    cin>>obj1.type;
    cout<<"Enter The Balance =";
    cin>>obj1.balance;
    obj1.profit();
    
}