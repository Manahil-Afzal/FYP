#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Method to take input for data members from the user
    void inputDetails() {
        cout << "Enter Account Title: ";
        getline(cin >> ws, accountTitle);

        cout << "Enter Account Type (savings/PLS): ";
        getline(cin >> ws, accountType);

        cout << "Enter Initial Balance: ";
        cin >> balance;

        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }

    // Method to calculate current balance based on account type
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * 5 / 100);
        } else if (accountType == "PLS") {
            balance += (balance * 8 / 100);
        }
    }

    // Method to display account details on screen
    void displayDetails() {
        cout << "\nAccount Title: " << accountTitle <<endl;
        cout << "Account Type: " << accountType <<endl;
        cout << "Current Balance: " << balance <<endl;
        cout << "Profit Percentage: " << profitPercent << "%" <<endl;
    }
};

int main() {
    // Create object of the BankAccount class
    BankAccount account;

    // Take input for the first account
    cout << "Enter details for Account :\n";
    account.inputDetails();
    account.calculateBalance();

      // Display details for account
    cout << "\nAccount Details for Account :\n";
    account.displayDetails();

       return 0;
}
