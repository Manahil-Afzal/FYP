/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit
is 5% of the existing balance and if the amount type is PLS (profit and loss sharing),
then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bank_acc
{
	string acc_title ;
	int acc_type ;
	long current_bal;
	int profit_per;
	public:
	void input()
	{	cout<<"Input section :"<<endl<<endl;
		cout<<"Enter account title :";
		getline (cin,acc_title);
		do
		{
		cout<<"Press 0 for \"Savings account\" or 1 for \"Profit and Loss Sharing account\" :";
		cin>>acc_type;
		if (acc_type!=0&&acc_type!=1)
		cout<<"Invalid Choice , Try again ...."<<endl;
		}while (acc_type!=0&&acc_type!=1);
		cout<<"Enter current balance :";
		cin>>current_bal;	
	}
	long calculation()
	{  int d=0;
		if (acc_type==0)
		{
				d=current_bal*0.05;
			current_bal=current_bal+d;}
		else 
		{
				d=current_bal*0.08;
			current_bal=current_bal+d;}
			return current_bal;	
	}	
	void output()
	{	cout<<endl<<endl<<"Output section :"<<endl<<endl;
		cout<<"Account title :"<<acc_title<<endl;
		cout<<"Account type :";
		if (acc_type==0)
		cout<<"Saving"<<endl ;
		else 
		cout<<"Profit and Loss Sharing "<<endl;
		cout<<"Balance without adding profits :"<<current_bal<<endl;
		cout<<"Balance after adding profits:"<<calculation();
	}
};
int main()
{
	bank_acc acc1;
	acc1.input();
	acc1.output();
	return 0;
}
