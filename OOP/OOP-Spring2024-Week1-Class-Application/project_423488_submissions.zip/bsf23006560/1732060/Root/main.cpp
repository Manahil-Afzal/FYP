
#include <iostream>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    void getInput() {
        cout << "Enter Account Title: ";
        cin >> accountTitle;
        cout << "Enter Account Type (Savings/PLS): ";
        cin >> accountType;
        cout << "Enter Balance: ";
        cin >> balance;
        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }

    void calculateBalance() {
        if (accountType == "Savings") {
            balance += balance * (profitPercent /100);
        }
        else if (accountType == "PLS") {
            balance += balance * (profitPercent / 100);
        }
    }

    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1: " << endl;
    account1.getInput();
    account1.calculateBalance();

    cout << "Enter details for Account 2: " << endl;
    account2.getInput();
    account2.calculateBalance();

    cout << "Account 1 Details: " << endl;
    account1.displayAccountDetails();

    cout << "Account 2 Details: " << endl;
    account2.displayAccountDetails();

    return 0;
}