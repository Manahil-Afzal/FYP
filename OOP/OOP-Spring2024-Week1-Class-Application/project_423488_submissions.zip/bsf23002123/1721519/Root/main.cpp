/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;
   
public:
    // Method to take input for data members from the user
    void getInput() {
        cout << "Enter Account Title: ";
        cin>> accountTitle;

        cout << "Enter Account Type (savings/PLS): ";
        cin >> accountType;

        cout << "Enter Initial Balance: ";
        cin >> balance;

        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
       
    }

    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * profitPercent) / 100.0; 
        }  else if (accountType == "PLS") {
            balance += (balance * profitPercent) / 100.0; 
        } 
        
    }
  

    void displayAccountDetails() {
        cout << "Account Title: " << accountTitle <<endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << "%" <<endl;
       
    }
};

int main() {
    
    BankAccount account1, account2 , account3;

    cout << "***** Enter details for Account 1 *****:\n";
    account1.getInput();

    cout << "\n***** Enter details for Account 2 *****\n";
    account2.getInput();
     cout << "\n***** Enter details for Account 3 *****\n";
    account3.getInput();
     
    
    

    account1.calculateBalance();
    account2.calculateBalance();
    account3.calculateBalance();


   
    cout << "\n----------- Account Details for Account 1 -----------:\n";
    account1.displayAccountDetails();

    cout << "\n---------- Account Details for Account 2 ---------------:\n";
    account2.displayAccountDetails();
        cout << "\n---------- Account Details for Account 3 ---------------:\n";
    account3.displayAccountDetails();

    return 0;
}