#include<iostream>
using namespace std;
class bankaccount{
	private:
		string accounttitle;
		string accounttype;
        double balance;
		double profitpercent;
		double currentbalance;
	public:
		void getinfo(){
			cout<<"enter the accounttitle"<<endl;
			cin>>accounttitle;
			cout<<"enter the accountype"<<endl;
			cin>>accounttype;
			cout<<"enter the balance"<<endl;
			cin>>balance;
		}
		void calbalance(){
			if(accounttype=="saving")
			{
			currentbalance=(balance)+(0.05*balance);}
			else{
			currentbalance=(balance)+(0.08*balance);}	
		}
		void printinfo(){
			cout<<"account title is "<<accounttitle<<endl;
			cout<<"account type is "<<accounttype<<endl;
			cout<<"account balance is "<<balance<<endl;
			cout<<"current balance is "<<currentbalance<<endl;
		}
};
int main()
{
	bankaccount a1;
	bankaccount a2;
	a1.getinfo();
	a1.calbalance();
	a1.printinfo();
	a2.getinfo();
	a2.calbalance();
	a2.printinfo();
	return 0;
}/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/