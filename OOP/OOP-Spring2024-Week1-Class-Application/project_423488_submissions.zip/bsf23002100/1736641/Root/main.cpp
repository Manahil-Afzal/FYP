#include <iostream>
#include <string>

using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Constructor
    BankAccount() {
        balance = 0.0;
    }

    // Method to take input for data members
    void inputData() {
        cout << "Enter account title: ";
        getline(cin, accountTitle);
        cout << "Enter account type (savings/PLS): ";
        cin >> accountType;
        cout << "Enter balance: ";
        cin >> balance;
        cout << "Enter profit percent: ";
        cin >> profitPercent;
    }

    // Method to calculate current balance
    void calculateBalance() {
        if (accountType == "savings") {
            balance += balance * (profitPercent / 100);
        } else if (accountType == "PLS") {
            balance += balance * (profitPercent / 100);
        }
    }

    // Method to display account details
    void display() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for account 1:" << endl;
    account1.inputData();
    account1.calculateBalance();

    cout << "\nEnter details for account 2:" << endl;
    account2.inputData();
    account2.calculateBalance();

    cout << "\nDetails of account 1:" << endl;
    account1.display();

    cout << "\nDetails of account 2:" << endl;
    account2.display();

    return 0;
}
/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/