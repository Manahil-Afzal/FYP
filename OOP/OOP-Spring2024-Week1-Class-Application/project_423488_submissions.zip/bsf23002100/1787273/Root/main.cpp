#include <iostream>
using namespace std;

class BankAccount {
    private:
        string account_title;
        string account_type;
        double balance;
        double profit_percent;
    public:
        void input(); 
        void calculate(); 
        void display(); 
};

int main() {
    BankAccount account1, account2;
    
    // Account1
    cout << "Enter details of your first account:\n";
    account1.input();
    account1.calculate();
    cout << "The details of your first account are:\n";
    account1.display();
    
    // Account2
    cout << "Enter details of your second account:\n";
    account2.input();
    account2.calculate();
    cout << "The details of your second account are:\n";
    account2.display(); 

    return 0;
}

void BankAccount::input(){
    cout << "Enter account title: ";
            cin >> account_title;
            cout << "Enter account type(savings or PLS): ";
            cin >> account_type;
            cout << "Enter balance: ";
            cin >> balance;
            
            if (account_type == "savings") {
                profit_percent = 0.05;
            }
            else if (account_type == "PLS") {
                profit_percent = 0.08;
            }
            else {
                cout << "Invalid account type.\n";
                profit_percent = 0;
            }
};

void BankAccount::calculate() {
            balance = balance + (balance * profit_percent);
        };

void BankAccount::display(){
            cout << "Account title: " << account_title << "\n";
            cout << "Account type: " << account_type << "\n";
            cout << "Your Balance: " << balance << "\n";
            cout << "Profit percent: " << profit_percent * 100 << "%\n";
        };