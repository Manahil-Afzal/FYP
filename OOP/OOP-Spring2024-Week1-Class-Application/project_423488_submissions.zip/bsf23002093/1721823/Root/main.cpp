#include <iostream>
#include <string>

class BankAccount {
private:
    std::string account_title;
    std::string account_type;
    double balance;
    double profit_percent;

public:
    BankAccount() {}

    void input_account_details() {
        std::cout << "Enter Account Title: ";
        std::getline(std::cin, account_title);

        std::cout << "Enter Account Type (Savings/PLS): ";
        std::getline(std::cin, account_type);

        std::cout << "Enter Balance: ";
        std::cin >> balance;

        std::cout << "Enter Profit Percentage: ";
        std::cin >> profit_percent;
    }

    void calculate_balance() {
        if (account_type == "Savings") {
            balance += balance * (profit_percent / 100.0 * 0.05);
        } else if (account_type == "PLS") {
            balance += balance * (profit_percent / 100.0 * 0.08);
        }
    }

    void display_account_details() {
        std::cout << "\nAccount Title: " << account_title << std::endl;
        std::cout << "Account Type: " << account_type << std::endl;
        std::cout << "Balance: " << balance << std::endl;
        std::cout << "Profit Percentage: " << profit_percent << "%" << std::endl;
    }
};

int main() {
    BankAccount account1, account2;

    std::cout << "Enter details for Account 1:" << std::endl;
    account1.input_account_details();
    account1.calculate_balance();

    std::cout << "\nEnter details for Account 2:" << std::endl;
    account2.input_account_details();
    account2.calculate_balance();

    std::cout << "\nAccount Details for Account 1:" << std::endl;
    account1.display_account_details();

    std::cout << "\nAccount Details for Account 2:" << std::endl;
    account2.display_account_details();

    return 0;
}
/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/