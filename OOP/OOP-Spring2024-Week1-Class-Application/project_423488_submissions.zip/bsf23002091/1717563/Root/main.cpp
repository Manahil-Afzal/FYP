/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include <iostream>
#include <string>
using namespace std;

class BankAccount {
  private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

  public:
    // Method to take input for data members
    void inputDetails() {
      cout << "Enter Account Title: ";
      getline(cin, accountTitle);

      cout << "Enter Account Type (savings or PLS): ";
      cin >> accountType;

      cout << "Enter Initial Balance: ";
      cin >> balance;

      cout << "Enter Profit Percentage: ";
      cin >> profitPercent;
    }

    // Method to calculate current balance based on account type
    void calculateBalance() {
      if (accountType == "savings") {
        balance += (0.05 * balance);  // 5% profit for savings account
      } else if (accountType == "PLS") {
        balance += (0.08 * balance);  // 8% profit for PLS account
      }
    }

    // Method to display account details
    void displayDetails() {
      cout << "\nAccount Details:\n";
      cout << "Account Title: " << accountTitle << endl;
      cout << "Account Type: " << accountType << endl;
      cout << "Current Balance: " << balance << endl;
      cout << "Profit Percentage: " << profitPercent << "%" << endl;
    }
};

int main() {
  BankAccount account1, account2;

  // Input details for the first account
  cout << "Enter details for the first account:\n";
  account1.inputDetails();
  account1.calculateBalance();

  // Input details for the second account
  cout << "\nEnter details for the second account:\n";
  account2.inputDetails();
  account2.calculateBalance();

  // Display details for both accounts
  account1.displayDetails();
  account2.displayDetails();

  return 0;
}
