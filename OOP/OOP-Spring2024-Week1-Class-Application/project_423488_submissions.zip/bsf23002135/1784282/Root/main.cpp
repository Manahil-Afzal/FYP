#include <iostream>
#include <cstdlib>
using namespace std;

class bankAcc{
    string accTitle, accType;
    int balance;
    float profit_percent;
    int currentBal;

    public:
        void putData();
        void calcData();
        void getData();
};

void bankAcc::putData(){
    cout<<"Account Title: ";
    cin>>accTitle;
    cout<<"Account Type(saving=pls): ";
    cin>>accType;
    cout<<"Account Balance: ";
    cin>>balance;
}
void bankAcc::calcData(){
    if(accType == "saving"){
        profit_percent = 5.0/100 * balance;
        currentBal= balance + profit_percent;
    }
    else if(accType == "pls"){
        profit_percent = 8.0/100 * balance;
        currentBal= balance + profit_percent;
    }
    else
        cout<<"please enter valid type (saving/pls)!!!";
        exit(EXIT_FAILURE);
}

void bankAcc::getData(){
    cout<<"------------"<<endl
        <<"YOUR DETAILS:"<<endl
        <<"------------"<<endl
        <<"Account Title: "<<accTitle<<endl
        <<"Account Type : "<<accType<<endl
        <<"Balance You Entered: "<<balance<<endl
        <<"Percent Profit: "<<profit_percent<<"%"<<endl
        <<"Current Balance: "<<currentBal<<endl;
}

int main(){
    bankAcc account1, account2;
    cout<<"ENTER THE DETAILS FOR ACCOUNT 1: "<<endl;
    account1.putData();
    account1.calcData();
    account1.getData();
    cout<<"@@@@@@@@............@@@@@@@@"<<endl;
    cout<<"ENTER THE DETAILS FOR ACCOUNT 2: "<<endl;
    account2.putData();
    account2.calcData();
    account2.getData();
}