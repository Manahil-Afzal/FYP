/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
class BankAccount
{
    private:
    string title;
    string AcType;
    int balance;
 ;
    public:
    void getter()
    {
        cout<<"Enter your bank title "<<endl;
        cin>>title;
        cout<<"Enter your account type "<<endl;
        cin>>AcType;
        cout<<"Enter your total balance "<<endl;
        cin>>balance;
    
    }
    void checker()
    {
        if(AcType=="saving"||AcType=="Saving")
        {
            balance+=balance*0.05;
        }
        else if(AcType=="profit"||AcType=="loss")
        {
            balance+=balance*0.08;
        }
        else 
        {
            cout<<"Your account is  not saving and profit type account so your balance is still same "<<endl;
        }
        cout<<" Your account name is :"<<title<<endl;
         cout<<" Your account type is :"<<AcType<<endl;
          cout<<" Your total balance  :"<<balance<<endl;
        
    }
    
};
int main()
{
    BankAccount person1;
    person1. getter();
    person1.checker();
}
