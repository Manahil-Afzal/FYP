/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankacc{
	public:
	string acctitle;
	string acctype;
	int balance;
	float perc;
	void inputdetails();
	void calculatebalance();
	void displaydetails();
};
void bankacc::inputdetails(){
	cout<<"enter account title";
	cin>>acctitle;
	cout<<"enter account type(savings or PLS)";
	cin>>acctype;
	cout<<"enter balance";
	cin>>balance;
	cout<<"enter profit percentage";
	cin>>perc;
	}
	void bankacc::calculatebalance(){
		if(acctype=="savings")
		balance+=balance*(perc/100);
		else if(acctype=="PLS")
		balance+=balance*(perc/100);
	}
	void bankacc::displaydetails(){
		cout<<"account title"<<acctitle;
		cout<<"account type"<<acctype;
		cout<<"total balance"<<balance;
		cout<<"profit percentage"<<perc;
	}
	int main(){
		bankacc acc1,acc2;
		cout<<"details of account 1";
		acc1.inputdetails();
		cout<<"details of account 2";
		acc2.inputdetails();
		acc1.calculatebalance();
		acc2.calculatebalance();
		cout<<"display details of account 1";
		acc1.displaydetails();
		cout<<"display details of account 2";
			acc2.displaydetails();
	}