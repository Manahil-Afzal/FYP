/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;

class BankAccount 
{
private:
    string accountTitle;
    string accountType;
    float balance;
    float profitPercent;

public:
    void inputDetails();
    void calculateBalance();
    void displayDetails();
};

int main() 
{
    BankAccount account1, account2;
    cout << "Enter details for Account 1:\n";
    account1.inputDetails();
    account1.calculateBalance(); 

    cout << "\nEnter details for Account 2:\n";
    account2.inputDetails();
    account2.calculateBalance(); 
    
    cout << "\nAccount Details for Account 1:\n";
    account1.displayDetails();

    cout << "\nAccount Details for Account 2:\n";
    account2.displayDetails();

}
void BankAccount::inputDetails()
{
	cout << "Enter Account Title: ";
        cin >> accountTitle;
        cout << "Enter Account Type (PLS/Savings): ";
        cin >> accountType;
        cout << "Enter Balance: ";
        cin >> balance;
        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
}
void BankAccount::calculateBalance()
	 {
        if (accountType == "savings")
		{
            balance += balance * (profitPercent / 100);
        } else if (accountType == "PLS")
	    {
            balance += balance * (profitPercent / 100);
        }
    }
void BankAccount::displayDetails()
    {
        cout << "Account Title: " << accountTitle <<endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << "%" << endl;
    }

