#include <iostream>
using namespace std;
float _balance;
class bankAccount{
	private:
		string accountTitle;
		int accountType;
		float balance;
		float profit_Percent;
	public:
		void getDetails();
		void showDetails();
};
int main(){
	bankAccount acc1;
	acc1.getDetails();
	acc1.showDetails();
	bankAccount acc2;
	acc2.getDetails();
	acc2.showDetails();
	return 0;
}
void bankAccount::getDetails(){
	cout<<"Enter Bank details"<<endl;
	cout<<"Enter Account Holder Name:"<<endl;
	cin>>accountTitle;
	cout<<"Select Account type: "<<endl<<"1. Saving "<<endl<<"2. Current"<<endl;
	cin>>accountType;
	if(accountType!=1 && accountType!=2){
		cout<<"oops! Select a valid Account."<<endl;
		}
		else{
	cout<<"Enter Account Balance: ";
	cin>>balance;}

}
void bankAccount::showDetails(){
	cout<<"Welcome "<<accountTitle<<"! Thanks for choosing us "<<endl;
	switch (accountType){
		case 1:
			cout<<"Saving Account: "<<endl;
			break;
		case 2:
			cout<<"Current Account: "<<endl;
			break;
	}
	cout<<"Your Existing Balance was: "<<balance<<endl;
	switch(accountType){
		case 1:
			_balance= balance*0.05;
			profit_Percent=balance + _balance;
			cout<<"Your new Balance after adding Profit: "<<profit_Percent<<endl;
			break;
		case 2:
			_balance= balance*0.08;
			profit_Percent=balance+_balance;
			cout<<"Your new Balance after adding Profit: "<<profit_Percent<<endl;
			break;
	}
}