/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;
float percentage;
class account{
      private:
             string firstName;
             string lastName;
             double contactNo;
             string Email;
             int accountType;
             int amountDeposit;
             float newBalance;
      public:
             void putInfo();
             void showInfo();       
};
int main(){
    account person;
    person.putInfo();
    person.showInfo();
    
    return 0;
}
void account::putInfo(){
     cout<<"Enter Your Details"<<endl;
     cout<<"Enter your first name : "<<endl;
     cin>>firstName;
     cout<<"Enter your last name : "<<endl;
     cin>>lastName;
      cout<<"Enter your Contact number: "<<endl;
     cin>>contactNo;
      cout<<"Enter your Email : "<<endl;
     cin>>Email;
     cout<<"Enter the amount you want to deposit: "<<endl;
     cin>>amountDeposit;
     cout<<"Enter your account type "<<endl;
     cout<<"1. SAVING ACCOUNT"<<endl;
     cout<<"2. PROFIT AND LOSS SHARING"<<endl;
     cout<<"ENTER NUMBER: ";
     cin>>accountType;
    switch(accountType){
                            case 1:
                                 cout<<"You selected a saving account"<<endl;
                                 break;
                            case 2:
                                 cout<<"You select a PLS account"<<endl;
                                 break;
                            default:
                                 cout<<"please enter given numbers only"<<endl;
                        }
    
     }
void account::showInfo(){
     cout<<"Welcome! "<<firstName<<" "<<lastName<<endl;
     cout<<"Email address: "<<Email<<endl;
     cout<<"Contact Number: "<< contactNo<<endl;
     cout<<"Your amount deposited : "<<amountDeposit<<endl;
     switch(accountType){
     	case 1:
     	newBalance=amountDeposit*0.05;
     	percentage=newBalance+ amountDeposit;
     	cout<<"New Balance With Profit: "<<percentage<<endl;
     	break;
     	case 2:
     		newBalance=amountDeposit*0.08;
     		percentage=newBalance + amountDeposit;
     		cout<<"New Balance With Profit: "<<percentage<<endl;
     	break;
	 }
	 
 }