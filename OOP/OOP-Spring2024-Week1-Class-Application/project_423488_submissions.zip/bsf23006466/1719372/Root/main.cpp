/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class bankAccount{
	public:
		string Account_title;
		string Account_type;
		float Balance;
		int profit;
		
	    void get_details();
	    float current_balance(float,string);
	    void display_details();	
};
int main()
{
	bankAccount Account1;
	bankAccount Account2;
	
	cout<<"ENTER DETAILS FOR ACCOUNT 1 "<<endl;
	cout<<endl;
	Account1.get_details();
	cout<<endl;
	
	cout<<"ENTER DETAILS FOR ACCOUNT 2 "<<endl;
	cout<<endl;
	Account2.get_details();
	cout<<endl;
	
	cout<<"HERE IS THE FINAL DETAILS OF ACCOUNT 1"<<endl;
	Account1.display_details();	
	cout<<endl;
	
	cout<<"HERE IS THE FINAL DETAILS OF ACCOUNT 2"<<endl;
	Account2.display_details();	
	cout<<endl;
	
	return 0;
}
void bankAccount:: get_details()
{
	cout<<"Enter your account title : ";
	cin>>Account_title;
	cout<<"Enter your account type : ";
	cin>>Account_type;
	cout<<"Enter your current balance : ";
	cin>>Balance;
	if(Account_type=="pls" || Account_type=="PLS")
	profit=8;
	else if(Account_type=="savings" || Account_type=="SAVINGS")
	profit=5;
	Balance = current_balance( Balance , Account_type);
}
float bankAccount:: current_balance(float balance2 ,string Account_type2)
{
	float total_balance;
	if(Account_type2=="savings" || Account_type2=="Savings" ){
		total_balance =  (5.0*balance2)/100.0 + balance2;
	}
	else if (Account_type2=="PLS" || Account_type2=="pls" )
		total_balance =  (8.0*balance2)/100.0 + balance2;
	return total_balance;
}
void bankAccount:: display_details(){
	cout<<"Your Account title is : "<<Account_title<<endl;
	cout<<"Your Account type is : "<<Account_type<<endl;
	cout<<"Your Profit is : "<<profit<<"%"<<endl;
	cout<<"Your Account balance is : "<<Balance<<endl;	
}
