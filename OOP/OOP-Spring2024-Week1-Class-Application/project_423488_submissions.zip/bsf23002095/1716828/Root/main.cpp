/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
	//Declaring class
	class BankAccount{
		//Access specifier
		private:
			string account_title;
			string account_type;
			int balance;
			float profit_percent;		
		public:
			//Making function
                void account_info(){
				cout<<" Enter the account title : ";
				cin>>account_title;
				cout<<" Enter the account type (saving or pls): ";
				cin>>account_type;
				cout<<" Enter the balance : ";
				cin>>balance;
				if(account_type == "saving"){
					profit_percent=balance+(balance*5/100);
					cout<<" You got 5% profit on your balance and your new balance is: "<<profit_percent;					
				}
				else if(account_type == "pls"){
				profit_percent=balance+(balance*8/100);
				cout<<" You got 8% profit on your balance and your new balance is: "<<profit_percent;			
				}
				cout<<endl;
				cout<<endl;
				cout<<"< ------------------------------------------------------- >";
				cout<<endl;
			}
	};
	int main(){
		//Creating object
	BankAccount account1;
	BankAccount account2;
		//Function caliing
	  account1.account_info();
	  cout<<endl;
	  account2.account_info();
}