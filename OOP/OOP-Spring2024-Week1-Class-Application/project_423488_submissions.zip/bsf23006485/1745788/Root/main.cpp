/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    BankAccount() {
        balance = 0.0;
    }

    void inputDetails() {
        cout << "Enter account title: ";
        cin >> accountTitle;
        cout << "Enter account type (Savings or PLS): ";
        cin >> accountType;
        cout << "Enter initial balance: ";
        cin >> balance;
        cout << "Enter profit percentage: ";
        cin >> profitPercent;
    }

    void calculateBalance() {
        if (accountType == "Savings") {
            balance += balance * (profitPercent / 100);
        } else if (accountType == "PLS") {
            balance += balance * (profitPercent / 100);
        } else {
            cout << "Invalid account type!" << endl;
        }
    }

    void displayDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Balance: " << balance << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" << endl;
    account1.inputDetails();
    account1.calculateBalance();

    cout << "\nEnter details for Account 2:" << endl;
    account2.inputDetails();
    account2.calculateBalance();

    cout << "\nDetails for Account 1:" << endl;
    account1.displayDetails();

    cout << "\nDetails for Account 2:" << endl;
    account2.displayDetails();

    return 0;
}