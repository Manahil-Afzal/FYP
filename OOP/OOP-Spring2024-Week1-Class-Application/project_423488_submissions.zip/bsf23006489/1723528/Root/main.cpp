/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class account{
	public:
		string title;
		string type;
		int balance;
		float profitpercent;
		void getinput();
		void currentbalance();
		void display();
	
};
void account::getinput(){
	cout<<"enter the account title:";
	cin>>title;
	cout<<"enter the account type(savings OR PLS):";
	cin>>type;
	cout<<"enter the account balance:";
	cin>>balance;
	
	{

   if (type == "savings") 
        {
            profitpercent = 5.0;
        } else if (type == "PLS") 
		{
            profitpercent = 8.0;
        } 
        
}
	
	
	
}
void account::currentbalance() 
{
	 double profit = balance * (profitpercent / 100.0);
        balance += profit;
}

void account::display(){
	cout<<"account title is "<<title<<endl;
		cout<<"account type is "<<type<<endl;
			cout<<"account balance is "<<balance<<endl;
				cout<<"account profit is "<<profitpercent<<endl;
}
main(){
	account A1,A2;
	cout<<".........take input of 1st account........."<<endl;
	A1.getinput();
	A1.currentbalance();
	cout<<".....1st account display......"<<endl;
	A1.display();
	
	
	cout<<".........take input of 2nd accout..........."<<endl;
	A2.getinput();
	A2.currentbalance();
	cout<<"..........2nd account display........."<<endl;
	A2.display();
}