/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/#include<iostream>
using namespace std;
class BankAccount{
	private:
		string title;
		string type;
		float balance;
		float profit;
    public:
     	void getDetail();
	    void putDetail();
	
	
	};
	int main(){
		BankAccount std1;
		BankAccount std2;
		cout<<"Bank Account 1:"<<endl;
		std1.getDetail();
		std1.putDetail();
		cout<<endl;
		cout<<"Bank Account 2:"<<endl;
		std2.getDetail();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
		std2.putDetail();
		return 0;
		
	}
	void BankAccount::getDetail(){
		cout<<"Enter Account Title:"<<endl;
		cin>>title;
		cout<<"Enter Account Type(savings or PLS):"<<endl;
		cin>>type;
		cout<<"Enter initial Balance:"<<endl;
		cin>>balance;
		cout<<"Entre profit:"<<endl;
		cin>>profit;
		if( type=="savings"){
			balance+=balance*(profit/100);
	}
		if( type=="PLS"){
			balance+=balance*(profit/100);
		}
		
	}
	void BankAccount::putDetail(){
		cout<<"ACCOUNT DETAIL:"<<endl;
		cout<<"Account Title is:"<<title<<endl;
		cout<<"Account Type is:"<<type<<endl;
		cout<<"Account current balance is "<<balance<<" with "<<profit<<"% profit"<<endl;
	
	}