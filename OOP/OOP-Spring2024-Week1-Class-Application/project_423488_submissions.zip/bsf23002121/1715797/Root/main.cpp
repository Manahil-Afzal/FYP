/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;

class bank{
	
	private:
	string title;
	string type;
	float balance;
	float profit;
	
	public:
	void Input(){
		cout<<"     Account title : ";
		cin>>title;
		cout<<"     Account type (Savings, PLS) : ";
		cin>>type;
		cout<<"     Current balance : ";
		cin>>balance;
		cout<<"     Profit : ";
		cin>>profit;
	}
	
	void Profit(){
		if (type == "Savings") {
            balance += (balance * profit / 100);
        } else if (type == "PLS") {
            balance += (balance * profit / 100);
        }
	}
	
	void Display(){
		cout<<"\nAccount Details : "<<endl;
		cout<<"     Title : "<<title<<endl;
		cout<<"     Type : "<<type<<endl;
		cout<<"     Your updated balance is  "<<balance<<" with "<<profit<<"% profit"<<endl;
	}
};


int main(){
	
	bank account1;
	cout<<"Account 1 details : "<<endl;
	account1.Input();
	account1.Profit();
	
	bank account2;
	cout<<"Account 2 details : "<<endl;
	account2.Input();
	account2.Profit();
	
	account1.Display();
	account2.Display();
	
	return 0;
}