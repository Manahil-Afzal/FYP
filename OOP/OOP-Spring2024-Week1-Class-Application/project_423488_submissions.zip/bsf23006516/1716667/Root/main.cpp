/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
/*Write a C++ program that has a class for Bank account. The class should have data members
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class Bank_Account{
	public:
		string Account_title;
		string type;
		float balance;
		float persent;	
	Bank_Account(string name,string kind,float bal):Account_title(name),type(kind),balance(bal)
	{
		
	}
	void input(){
		cout<<"Enter your name: ";
		cin>>Account_title;
		cout<<"Enter your Account type: ";
		cin>>type;
		cout<<"Enter your balance: ";
		cin>>balance;
    }
    float calculate_salary(){
    	if(type=="saving"){
    		float newbal=balance*0.5;
    		balance+=newbal;
    		return balance;
		}
		else if(type=="psl"){
			float newbal=balance*0.8;
    		balance+=newbal;
    		return balance;
		}
		else
		{
			return balance;
		}
	}
	void showdetails(){
	cout<<"Your Account Title is: "<< Account_title<<endl;
	cout<<"Your Account Type is: "<<type<<endl;
	cout<<"Your balance is: "<<balance<<endl;
}
};
int main(){
	Bank_Account obj1("Toqeer","saving",50000);
	obj1.input();
	obj1.showdetails();
}