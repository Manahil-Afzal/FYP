#include<iostream>
using namespace std;
class bank_account{
	public:

	string account_title;
		string account_type;
		int balance;
		void  input();
		void calculate();
		void  output(); 
		};
		void bank_account::input()
		{
		cout<<"Enter account name:";
		cin>>account_title;
		cout<<"Enter account type:";
		cin>>account_type;
		cout<<"Enter account balance:";
		cin>>balance;
				}
				void bank_account::calculate()
				{
				if(account_type=="PLS")
				{
				balance+=balance*0.08;	
					}
					else if(account_type=="savings"){
					balance+=balance*0.05;	
					}
					else
					cout<<"Enter  valid type";	
				}
				void bank_account::output()
				{
				cout<<"Account Name:"<<account_title<<endl;
				cout<<"Total Balance with profit:"<<balance;
				}
		int main()
		{
		bank_account account1;
		bank_account account2;
		
		account1.input();
		account1.calculate();
		
		account2.input();
		account2.calculate();
		account1.output();
		cout<<endl;
		account2.output();
		return 0;
	}
		
		