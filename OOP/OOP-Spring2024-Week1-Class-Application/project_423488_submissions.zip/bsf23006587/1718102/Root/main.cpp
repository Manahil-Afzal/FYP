/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include<iostream>
using namespace std;
class BankAcc{
    private:
        string AccTitle;
        string AccType;
        float InitialBalance;
        float AccBalance;
    public:
        void inputInfo(){
            cout<<"Please Enter Following Details"<<endl;
            cout<<"Account Title : ";
            cin>>AccTitle;
            cout<<"Account Type(Savings/PLS) : ";
            cin>>AccType;
            cout<<"Initial Account Balance : ";
            cin>>InitialBalance;
        }
        float totalBalance(){
            if(AccType=="PLS"){
                AccBalance = InitialBalance*1.08 ;
            } 
            else if(AccType=="Savings"){
            AccBalance = InitialBalance*1.05 ;
        }
            return AccBalance;
        }

        void outputInfo(){
            cout<<"Your details are as Follow"<<endl;
            cout<<"Account Title : "<<AccTitle<<endl;
            cout<<"Account Type : "<<AccType<<endl;
            cout<<"Current Account Balance : " <<totalBalance()<<endl;
        }

};

int main(){
    BankAcc details;
    details.inputInfo();
    details.outputInfo();
}