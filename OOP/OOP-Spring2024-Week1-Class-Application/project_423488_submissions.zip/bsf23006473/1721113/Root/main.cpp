/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>
using namespace std;


class Bank  {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Method to take input for data members
    void inputDetails() {
        cout << "Enter Account Title: ";
        cin >> accountTitle;

        cout << "Enter Account Type (savings/PLS): ";
        cin >> accountType;

        cout << "Enter Balance: ";
        cin >> balance;

     //   cout << "Enter Profit Percentage: ";
       // cin >> profitPercent;//
    }

    // Method to calculate current balance based on account type
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (0.05 * balance); // 5% profit for savings account
        } else if (accountType == "PLS") {
            balance += (0.08 * balance); // 8% profit for PLS account
        }
    }

    // Method to display account details
    void displayDetails() {
        cout << "\nAccount Details:\n";
        cout << "Title: " << accountTitle << "\n";
        cout << "Type: " << accountType << "\n";
        cout << "Balance: Rs" << balance << "\n";
        cout << "Profit Percentage: " << profitPercent << "%\n";
    }
};

int main() {
    // Create two objects of the BankAccount class
    Bank account1, account2;

    // Input details for both accounts
    cout << "Enter details for Account 1:\n";
    account1.inputDetails();

    cout << "Enter details for Account 2:\n";
    account2.inputDetails();

    // Calculate current balance for both accounts
    account1.calculateBalance();
    account2.calculateBalance();

    // Display details for both accounts
    account1.displayDetails();
    account2.displayDetails();

    return 0;
}