/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;

class bankacc{
	public:
	string acc_title;
	string type;
	int balance;
	float profit_percent;
	
	
		void takeInput();
		void balance_calculate();
		void displayDetails();
	};
	
		void bankacc::takeInput()
		{
			cout<<"Enter account title:"<<endl;;
			cin>>acc_title;
			cout<<"Enter account type:"<<endl;;
			cin>>type;
			cout<<"Enter balance:"<<endl;;
			cin>>balance;
		
		}
		void bankacc::balance_calculate()
		{
	if(type== "savings") 
	{
		profit_percent=5.0;
		
	}
	else if(type=="pls")
	{
	profit_percent=8.0;
	}
	  double  current_balance=balance*(profit_percent/100.0);
	balance+=current_balance;
     }
		void bankacc::displayDetails()
		{
			cout<<"accoount title is:"<<acc_title<<endl;
			cout<<"account type is:"<<type<<endl;
			cout<<"account balance is:"<<balance<<endl;
			cout<<"account profit is:"<<profit_percent<<endl;
		}
int main(){
	bankacc acc1,acc2;
	cout<<"Enter details for acc 1:"<<endl;
	acc1.takeInput();
	acc1.balance_calculate();
	acc1.displayDetails();

	
	cout<<"Enter detaails for acc 2:"<<endl;
	acc2.takeInput();
	acc2.balance_calculate();
	acc2.displayDetails();
	
	return 0;
}

