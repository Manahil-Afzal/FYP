#include <iostream>
using namespace std;
class BankAccount {
private:
   string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
    // Method to take input for data members
    void inputData() {
        cout << "Enter Account Title: ";
        cin >> accountTitle;

        cout << "Enter Account Type (savings or PLS): ";
        cin >> accountType;
        cout << "Enter Initial Balance: ";
        cin >> balance;

        cout << "Enter Profit Percentage: ";
        cin >> profitPercent;
    }

    // Method to calculate current balance with profit
    void calculateBalance() {
        if (accountType == "savings") {
            balance += balance * (profitPercent / 100.0); // 5% profit for savings account
        } else if (accountType == "PLS") {
            balance += balance * (profitPercent / 100.0); // 8% profit for PLS account
        }
    }

    // Method to display account details
    void displayAccountDetails() {
       cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
       cout << "Current Balance: " << balance << endl;
        cout << "Profit Percentage: " << profitPercent << endl;
    }
};

int main() {
    // Create two objects of the BankAccount class
    BankAccount account1, account2;

    // Take input for the first account
    cout << "Enter details for Account 1:" << endl;
    account1.inputData();

    // Calculate balance for the first account
    account1.calculateBalance();

    // Take input for the second account
   cout << "Enter details for Account 2:" <<endl;
    account2.inputData();

    // Calculate balance for the second account
    account2.calculateBalance();

    // Display details for both accounts
   cout << "Account Details for Account 1:" << endl;
    account1.displayAccountDetails();

   cout << "Account Details for Account 2:" << endl;
    account2.displayAccountDetails();

    return 0;
}