/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
#include<string>
using namespace std;
class bankacc{
   
    public:
        string acctype,acctittle;
        int balance,profit;
        void getdata()
        {
            cout<<"enter account type";
            cin>>acctype;
            cout<<"enter account tittle";
            cin>>acctittle;
            cout<<"enter balance";
            cin>>balance;
            cout<<"enter profit";
            cin>>profit;
            
        }
         void calculation() {
        if (acctype == "savings") {
            balance += (balance * profit / 100);
        } else if (acctype == "PLS") {
            balance += (balance * profit / 100);
        }
    }
    void display(){
        
        cout<<acctype<<endl<<acctittle<<endl<<profit<<endl<<balance;
    }
};
int main(){
    bankacc person1,person2;
    
    person1.getdata();
    person1.calculation();
    person1.display();
    
    person2.getdata();
    person2.calculation();
    person2.display();
}