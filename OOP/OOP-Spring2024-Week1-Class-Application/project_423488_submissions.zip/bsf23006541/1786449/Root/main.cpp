
#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string account_title;
    string account_type;
    float balance;
    float profit_percent;

public:
    void input() {
        cout << "Enter Account Title: ";
        getline(cin, account_title);
        cout << "Enter Account Type (savings or PLS): ";
        cin >> account_type;
        cout << "Enter Initial Balance: ";
        cin >> balance;
        cout << "Enter Profit Percentage: ";
        cin >> profit_percent;
    }

    void calculate_balance() {
        if (account_type == "savings") {
            balance += balance * (profit_percent / 100 * 0.05); // 5% profit for savings account
        } else if (account_type == "PLS") {
            balance += balance * (profit_percent / 100 * 0.08); // 8% profit for PLS account
        } else {
            cout << "Invalid account type!" << endl;
        }
    }

    void display() {
        cout << "Account Title: " << account_title << endl;
        cout << "Account Type: " << account_type << endl;
        cout << "Balance: Rs. " << balance << endl;
        cout << "Profit Percentage: " << profit_percent << "%" << endl;
    }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1:" << endl;
    account1.input();
    account1.calculate_balance();

    cout << "\nEnter details for Account 2:" << endl;
    account2.input();
    account2.calculate_balance();

    cout << "\nDetails of Account 1:" << endl;
    account1.display();

    cout << "\nDetails of Account 2:" << endl;
    account2.display();

    return 0;
}
