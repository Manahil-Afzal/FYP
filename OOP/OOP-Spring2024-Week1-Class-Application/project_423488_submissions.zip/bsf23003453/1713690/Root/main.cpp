/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
using namespace std;

class Bank {
    string title;
    string type;
    double balance;
    int profit;

public:
    void getter() {
        cout << "Enter account title: ";
        cin >> title;
        cout << "Enter account type: ";
        cin >> type;
        cout << "Enter balance: ";
        cin >> balance;
        cout << "Enter profit percent: ";
        cin >> profit;
    }

    void calculateBalance() {
        if (type == "savings") {
            balance += balance * 0.05;
        } else if (type == "PLS") {
            balance += balance * 0.08;
        }
    }

    void display() {
        cout << "Account title: " << title << endl;
        cout << "Account type: " << type << endl;
        cout << "Balance: " << balance << endl;
        cout << "Calculated Profit: " << balance - (balance / (1 + (profit / 100.0))) << endl;
        cout << "Profit percent: " << profit << endl;
    }
};

int main() {
    Bank account1, account2;

    cout << "Enter details for Account :" << endl;
    account1.getter();

    account2.getter();

    cout << "\nCalculating current balance for both accounts :" << endl;
    account1.calculateBalance();
    account2.calculateBalance();

    cout << "\nDetails of Account :" << endl;
    account1.display();

    account2.display();

    return 0;
}
