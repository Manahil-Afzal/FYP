#include <iostream>
#include <string>
using namespace std;
//class
class BankAccount {
private:
    string accountTitle;
    string accountType;
    double balance;
    double profitPercent;

public:
   //take input from user
    void inputDetails() {
        cout << "Enter Account Title: ";
        cin>>accountTitle;

        cout << "Enter Account Type (savings/PLS): ";
        cin >> accountType;

        cout << "Enter current Balance: ";
        cin >> balance;


    }

  //calculate profit balance
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * 5 / 100);
        } else if (accountType == "PLS") {
            balance += (balance * 8 / 100);
        }
    }


    void displayDetails() {
       
        cout << "Title: " << accountTitle<<endl;
        cout << "Type: " << accountType<<endl;
        cout << "Profit Balance:" << balance<<endl;
        
        
    }
};

int main() {
    BankAccount account1;
    cout << "Enter details for Account 1:"<<endl;
    account1.inputDetails();
    account1.calculateBalance();
    account1.displayDetails();
    BankAccount account2;
    cout << "Enter details for Account 2:"<<endl;
    account2.inputDetails();
    account2.calculateBalance();
    account2.displayDetails();

    return 0;
}
