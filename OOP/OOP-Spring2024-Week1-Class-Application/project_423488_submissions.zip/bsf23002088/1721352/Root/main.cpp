/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/

#include<iostream>
#include<string>
using namespace std;
class Bankaccount{
 private:
  string accounttitle;
  string accounttype;
  float balance;
  float profitpercent;
    public:
 void getdata(){
  cout<<" enter the account title:"<<endl;
  cin>>accounttitle;
  cout<<" enter the account type(saving or PLS):"<<endl;
  cin>>accounttype;
  cout<<" enter the initial balance:"<<endl;
  cin>>balance;}
 void calbalance(){
  if(accounttype=="savings"){
   balance+=( 5*balance)/100;}
  else{
   balance+=( 8*balance)/100;
  } 
  
 } 
  
 void printdata(){
  cout<<"Account title is:"<<accounttitle<<endl;
     cout<<"Account type is:"<<accounttype<<endl;
     cout<<"Account balance is:"<<balance<<endl;
     
 }
	
	
};
int main(){
 
Bankaccount Account1;
Bankaccount Account2;
Account1.getdata(); 
Account1.calbalance(); 
Account1.printdata();
Account2.getdata(); 
Account2.calbalance(); 
Account2.printdata(); 
return 0;
}
