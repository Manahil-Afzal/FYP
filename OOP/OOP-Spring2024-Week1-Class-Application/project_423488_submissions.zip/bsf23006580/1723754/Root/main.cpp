/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
using namespace std;
class account{
	public:
	string title, type;
	double balance, cbalance, profit;
	int p_prcnt;
	void inp();
	void totalbalance();
	void details();
};
void account::inp(){
	cout<<"Enter the account title               : ";
	cin>>title;
	cout<<"Enter the account type (savings, pls) : ";
	cin>>type;
	cout<<"Enter the account balance             : ";
	cin>>balance;
	cout<<"Enter the profit percentage (5, 8)    : ";
	cin>>p_prcnt;
}
void account::totalbalance(){
	if(type=="savings")
	profit=(balance*5/100);
	if(type=="pls")
	profit=(balance*8/100);
	cbalance=balance+profit;
}
void account::details(){
	cout<<endl<<"Account Title              : "<<title<<endl;
	cout<<"Account Type               : "<<type<<endl;
	cout<<"Account Balance            : "<<balance<<endl;
	cout<<"Profit Percentage          : "<<p_prcnt<<endl;
	cout<<"Current Balance            : "<<cbalance<<endl<<endl;
}
int main()
{
	account bal1, bal2;
	cout<<"Enter the details for the first account "<<endl;
	bal1.inp();
	cout<<endl<<"Enter the details for the second account"<<endl;
	bal2.inp();
	bal1.totalbalance();
	bal2.totalbalance();
	cout<<endl<<"Details of 1st Account ";
	bal1.details();
	cout<<"Details of 2nd Account ";
	bal2.details();
	return 0 ;
}

