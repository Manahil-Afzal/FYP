#include<iostream>
using namespace std;

class BankAccount{
private:
string accountTitle;
int accountType;
float balance;
string profit_percent;
public:
void input(){
    cout<<"Enter the details of the account."<<endl;
    cout<<"Please enter the name of the account owner: "<<endl;
    cin.sync();
    getline(cin,accountTitle);
    cout<<"Please select the account type: "<<endl<<"(1)Savings account."<<endl<<"(2)PLS (profit and loss sharing) account."<<endl;
    cin>>accountType;
    if(accountType>2||accountType<1){
        cout<<"Please enter a valid selection."<<endl;
        cin>>accountType;
    }
    cout<<"Please enter the account Balance: "<<endl;
    cin>>balance;
    cout<<"Thank you for your kind cooperation."<<endl;
    if(accountType==1){
        profit_percent="5%";
    }
    if(accountType==2){
        profit_percent="8%";    }
}
float currentBalance(int accountType,float balance){
    if(accountType==1){
        float cbalance=balance+(balance*0.05);
        return cbalance;
    }
    if(accountType==2){
        float cbalance=balance+(balance*0.08);
        return cbalance;
    }}
void displayDetail(){
    cout<<"The details of your account are: "<<endl;
    cout<<"Account Title: "<<accountTitle<<endl;
    cout<<"Account type: ";
    if(accountType==1){
        cout<<"Savings account."<<endl;
    }
    if(accountType==2){
        cout<<"PLS (profit and loss sharing) account."<<endl;
    }
    cout<<"Balance: "<<balance<<endl;
    cout<<"Profit percentage: "<<profit_percent<<endl;
    
    cout<<"Your current balance after the profit is: "<<currentBalance(accountType,balance)<<endl;
    
}


};


int main(){
    BankAccount acc1;
    acc1.input();
    acc1.displayDetail();
    cout<<endl;
    BankAccount acc2;
    acc2.input();
    acc2.displayDetail();
    return 0;
}