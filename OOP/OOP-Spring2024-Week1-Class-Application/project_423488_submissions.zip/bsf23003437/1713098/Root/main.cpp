/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include<iostream>
#include<string>

using namespace std;

class BankAccount {
    private:
        string account_title;
        string account_type;
        double balance;
        double profit_percent;
    
    public:
        void takeInput() {
            cout << "Enter account title: ";
            cin >> account_title;
            cout << "Enter account type: ";
            cin >> account_type;
            cout << "Enter balance: ";
            cin >> balance;
            cout << "Enter profit percent: ";
            cin >> profit_percent;
        }

        void calculateBalance() {
            if(account_type == "savings") {
                balance += (balance * (profit_percent / 100));
            }
            else if(account_type == "PLS") {
                balance += (balance * (profit_percent / 100));
            }
        }

        void displayAccountDetails() {
            cout << "\nAccount Details: \n";
            cout << "Account Title: " << account_title << endl;
            cout << "Account Type: " << account_type << endl;
            cout << "Current Balance: " << balance << endl;
            cout << "Profit Percent: " << profit_percent << endl;
        }
};

int main() {
    BankAccount account1, account2;

    cout << "Enter details for Account 1: \n";
    account1.takeInput();

    cout << "Enter details for Account 2: \n";
    account2.takeInput();

    account1.calculateBalance();
    account2.calculateBalance();

    cout << "\nDetails of Account 1: \n";
    account1.displayAccountDetails();

    cout << "\nDetails of Account 2: \n";
    account2.displayAccountDetails();

    return 0;
}