/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>
using namespace std;

class BankAccount {
private:
    string accountTitle;
    string accountType;
    float balance;
    float profitPercent;

public:
    // Constructor to initialize account details
    BankAccount(string title, string type, float initialBalance, float profit)
        : accountTitle(title), accountType(type), balance(initialBalance), profitPercent(profit) {}

    // Method to deposit an amount
    void deposit(float amount) {
        balance += amount;
    }

    // Method to calculate current balance with profit
    void calculateBalance() {
        if (accountType == "savings") {
            balance += (balance * profitPercent / 100);
        } else if (accountType == "PLS") {
            balance += (balance * profitPercent / 100);
        }
    }

    // Method to display account details
    void displayDetails() {
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Current Balance: $" << balance << endl;
    }
};

int main() {
    // Create two BankAccount objects
    BankAccount account1("John Doe", "savings", 1000, 5);
    BankAccount account2("Jane Smith", "PLS", 2000, 8);

    // Deposit some amount
    account1.deposit(500);
    account2.deposit(800);

    // Calculate balances
    account1.calculateBalance();
    account2.calculateBalance();

    // Display account details
    cout << "Account 1 Details:" << endl;
    account1.displayDetails();
    cout << endl;

    cout << "Account 2 Details:" << endl;
    account2.displayDetails();

    return 0;
}