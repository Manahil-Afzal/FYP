/*Write a C++ program that has a class for Bank account. The class should have data members 
to keep the bank account details for account title, account type, balance, and profit_percent.
Write a method for the class to:
1- Take input for the data members from user.
2- Calculate current balance by adding profit on the basis of type of account. If the account type is savings, then the profit is 
5% of the existing balance and if the amount type is PLS (profit and loss sharing), then 8% profit is applicable to the balance.
3- To display the account details on screen.
In main create two objects of the bank account class and display the data member values of both accounts.*/
#include <iostream>
#include <string>
using namespace std;

// BankAccount class definition
class BankAccount {
private:
    string accountTitle;
    string accountType; // "savings" or "PLS"
    double balance;
    double profitPercent;

public:
    // Method to input data
    void inputAccountDetails() {
        cout << "Enter Account Title: ";
        getline(cin, accountTitle);

        cout << "Enter Account Type (savings or PLS): ";
        getline(cin, accountType);

        cout << "Enter Initial Balance: ";
        cin >> balance;

        // Clear input buffer for next getline
        cin.ignore();

        // Set profit percent based on account type
        if (accountType == "savings" || accountType == "Savings") {
            profitPercent = 5.0;
        } else if (accountType == "PLS" || accountType == "pls") {
            profitPercent = 8.0;
        } else {
            profitPercent = 0.0;
            cout << "Invalid account type! No profit will be added.\n";
        }
    }

    // Method to calculate balance with profit
    void calculateProfit() {
        double profit = (balance * profitPercent) / 100.0;
        balance += profit;
    }

    // Method to display account details
    void displayAccountDetails() const {
        cout << "\n----- Account Details -----\n";
        cout << "Account Title: " << accountTitle << endl;
        cout << "Account Type: " << accountType << endl;
        cout << "Profit Percent: " << profitPercent << "%" << endl;
        cout << "Current Balance (after profit): " << balance << endl;
    }
};

// Main function
int main() {
    BankAccount acc1, acc2;

    cout << "Enter details for Account 1:\n";
    acc1.inputAccountDetails();
    acc1.calculateProfit();

    cout << "\nEnter details for Account 2:\n";
    acc2.inputAccountDetails();
    acc2.calculateProfit();

    // Display both accounts
    acc1.displayAccountDetails();
    acc2.displayAccountDetails();

    return 0;
}
