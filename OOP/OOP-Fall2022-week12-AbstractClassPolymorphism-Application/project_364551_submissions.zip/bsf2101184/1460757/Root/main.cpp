/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class vehicle
{
	public:
		string manufacturer;
		int mileage;
	virtual	void first_maintainence()=0;
	void display()
	{
	}
};
class four_wheeler:public vehicle
{
	public:
		void first_maintainence()
		{
			int mileage =6000;
if (mileage > 5000) {
  cout << "maintainence is due for four wheeler";
} else {
  cout << "not due.";
}
		}
		void display()
	{
		cout<<"enter the manufacturer"<<endl;
		cin>>manufacturer;
		cout<<"enter the mileage "<<endl;
		cin>>mileage;
	}
	
};
class two_wheeler:public vehicle
{
	public:
		void first_maintainence()
		{
		    
		    if (mileage > 2000) {
  cout << "maintainence is due for two wheeler.";
} else {
  cout << "not due.";
}
			cout<<"two weeler"<<endl;
		}
			void display()
		{
			cout<<manufacturer<<" "<<mileage <<" "<<endl;
}
};
int main()
{
	//vehicle*v1=new v1;
	 four_wheeler* car=new four_wheeler;
	 two_wheeler  *bike=new two_wheeler;
	// v1->display();
	 car->first_maintainence();
	 car->display();
	 bike->first_maintainence();
	 bike->display();
	// delete v1;
	 delete car;
	 delete bike;
	return 0;
}

	
