/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class vehicle{
	public:
		string manufac;
		int mileage;
		virtual void first_maintenance()=0;
		void display()
		{
			cout<<"Mainufacturer of vehicle is"<<manufac<<"and the mileage is "<<mileage<<"km.\n" <<endl;
			
		}
};
class four_wheeler:public vehicle{
	public:
		void first_maintenance(){
			if(mileage>=5000){
				cout<<"Vehicle need maintenance...\n"<<endl;
				
			}
			else{
				cout<<"Vehicle not need maintenance...\n"<<endl;
				
			}
		};
	
};
class two_wheeler:public vehicle{
	public:
		void first_maintenance(){
			if(mileage>=200)
			{
				cout<<"Vehicle need maintenance...\n"<<endl;
			}
			else{
				cout<<"Vehicle not need maintenance...\n"<<endl;
				
			}
		}
};
int main(){
	four_wheeler car;
	two_wheeler bike;
	cout<<"Enter the mileage of the four wheeler vehicle:"<<endl;
	cin>>car.mileage;
	cout<<"Enter the manufacturer of the four wheeler vehicle:"<<endl;
	cin>>car.manufac;
	cout<<"Enter the mileage of the two wheeler vehicle: "<<endl;
	cin>>bike.mileage;
	cout<<"Enter the manufacturer of the two wheeler vehicle:"<<endl;
	cin>>bike.manufac;
	car.display();
	car.first_maintenance();
	bike.display();
	bike.first_maintenance();
	return 0;
	
}