/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

	

#include<iostream>
using namespace std;

class Vehicle{
	public:
		int mileage;
		string manufacturer;
		virtual void first_maintenance(int mileage) = 0;
		virtual void display(int mileage,string manufacturer) {
			
		}
};

class Four_Wheeler: public Vehicle{
	public:
		void first_maintenance(int mileage) {
			if(mileage >= 5000)
			cout<<"Reaches Maintenance !"<<endl;
			else 
			cout<<"It's OK!"<<endl;
		}
		void display(int mileage,string manufacturer) {
			cout<<"Distance Travelled :"<<mileage<<endl;
			cout<<"Manufacturer of Vehicle is :"<<manufacturer<<endl;
		}
};

class Two_Wheeler: public Vehicle{
	public:
	void first_maintenance(int mileage) {
			if(mileage >= 2000) 
			cout<<"Reaches Maintenance !"<<endl;
			else 
			cout<<"It's OK!"<<endl;		}
	 void display(int mileage,string manufacturer) {
			cout<<"Distance Travelled :"<<mileage<<endl;
			cout<<"Manufacturer of Vehicle is :"<<manufacturer<<endl;
		}
};

int main() {
	Four_Wheeler car;
	car.display(2000,"BMW");
	car.first_maintenance(4000);
	Two_Wheeler bike;
	bike.display(1000,"Honda");
	bike.first_maintenance(2000);
	
	return 0;
}