/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

#include <iostream>
using namespace std;
using namespace std;
class Vehicle{               //parent class
	public:
	int mileage;
	string manufacturer;
	
		virtual void first_maintenance()=0;
		void getin(){
			cout<<"Enter the mileage and manufacturer"<<endl;
			cin>>mileage>>manufacturer;
		}
		
	void display(){
			cout<<"Mileage:"<<mileage<<endl;
			cout<<"Manufacturer : ";
			cout<<manufacturer;
			cout<<endl;
			first_maintenance();
		}
			
};
class Four_Wheeler:public Vehicle {
	void first_maintenance(){
		if(mileage>=5000){
			cout<<"The maintenance is due."<<endl;
		}
		else{
		    cout<<"Dont required maintenance"<<endl;
		}
	}
		void display(){
			cout<<"Mileage:"<<mileage<<endl;
			cout<<"Manufacturer : ";
			cout<<manufacturer;
			cout<<endl;
			first_maintenance();
		}	
	
	
};
class Two_Wheeler:public Vehicle{
	void first_maintenance(){
		if(mileage>=2000){
			cout<<"The maintenance is due."<<endl;
		}
		else{
		    cout<<"Dont required any maintenance"<<endl;
		}
	}
		void display(){
			cout<<"Mileage:"<<mileage<<endl;
			cout<<"Manufacturer : ";
			cout<<manufacturer;
			cout<<endl;
			first_maintenance();
		}	
};


int main(){
    Vehicle* obj;
    Four_Wheeler Car;
    Two_Wheeler Bike;
    cout<<"For Car"<<endl;
    Car.getin();
    obj=&Car;
    obj->display();
    cout<<endl;
    cout<<"For Bike"<<endl;
    Bike.getin();
    obj=&Bike;
    obj->display();
	

return 0;
}