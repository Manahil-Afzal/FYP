#include<iostream>
using namespace std;

class Vehicle{
	protected:
		float mileage;
		string manufacturer;
	public:
		virtual void first_maintenance() = 0;
		virtual void display(){}
};

class Four_Wheeler : public Vehicle{
	public:
		void display(){
			cout<<"\nEnter the mileage of Four_Wheeler in Km: ";
			cin>>mileage;
			cout<<"Enter the manufacturer of Four_Wheeler: ";
			cin>>manufacturer;
			cout<<"\nThe mileage of Four_Wheeler is: "<<mileage<<"Km"<<endl;
			cout<<"The manufacturer of Four_Wheeler is: "<<manufacturer<<endl;
			if(mileage>=5000){
				cout<<"\nMaintenance is needed for Four_Wheeler."<<endl;
			}
			else{
				cout<<"\nMaintenance is not needed for Four_Wheeler."<<endl;
			}
		}
		void first_maintenance(){
			cout<<"\nFour_Wheeler's pure virtual function overridden successfully."<<endl;
		}
};

class Two_Wheeler : public Vehicle{
	public:
		void display(){
			cout<<"\nEnter the mileage of Two_Wheeler in Km: ";
			cin>>mileage;
			cout<<"Enter the manufacturer of Two_Wheeler: ";
			cin>>manufacturer;
			cout<<"\nThe mileage of Two_Wheeler is: "<<mileage<<"Km"<<endl;
			cout<<"The manufacturer of Two_Wheeler is: "<<manufacturer<<endl;
			if(mileage>=2000){
				cout<<"\nMaintenance is needed for Two_Wheeler."<<endl;
			}
			else{
				cout<<"\nMaintenance is not needed for Two_Wheeler."<<endl;
			}
		}
		void first_maintenance(){
			cout<<"\nTwo_Wheeler's pure virtual function overridden successfully."<<endl;
		}
};

int main(){
	Vehicle *vh;
	Four_Wheeler car;
	Two_Wheeler bike;
	vh = new Four_Wheeler();
	vh->display();
	vh->first_maintenance();
	vh = new Two_Wheeler();
	vh->display();
	bike.first_maintenance();
	delete vh;
	return 0;
}