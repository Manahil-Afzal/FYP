/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

#include <iostream>
#include <string>
using namespace std;
class vehicle{
public:
float mileage;
string manufacturer;
virtual void first_maintenance()=0;
virtual void display(){
cout << mileage << manufacturer;
}
};
class four_wheeler : public vehicle{
public:
void first_maintenance(){
cout << "enter mileage and manufacturer of car : ";
cin >> mileage >> manufacturer;
if (mileage >= 5000)
cout << "Maintenance is due!" << endl;
else
cout << "Your car is in a good condition!" << endl;
}
void display(){
cout << "Mileage of car : " << mileage << endl;
cout << "Manufacturer of car : " << manufacturer << endl;
}
};
class two_wheeler : public vehicle{
public:
void first_maintenance(){
cout << "enter mileage and manufacturer of bike : ";
cin >> mileage >> manufacturer;
if (mileage >= 2000)
cout << "Maintenance is due!" << endl;
else
cout << "Your bike is in a good condition!" << endl;
}
void display(){
cout << "Mileage of bike : " << mileage << endl;
cout << "Manufacturer of bike : " << manufacturer << endl;
}
};
void intermediate (vehicle *v)
{
v->first_maintenance();
v->display();
}
int main ()
{
four_wheeler *car=new four_wheeler();
two_wheeler *bike=new two_wheeler();
intermediate(car);
intermediate(bike);
delete car;
delete bike;
return 0;
}

	
