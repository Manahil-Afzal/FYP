/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
	
#include<iostream> 
using namespace std; 

class Vehicle
{
protected:
    int mileage;
    string manufacturer;

public:
    Vehicle(int mileage, string manufacturer)
    {
        this->mileage = mileage;
        this->manufacturer = manufacturer;
    }

    virtual void first_maintenance() = 0;

    void display()
    {
        cout << "Mileage: " << mileage << endl;
        cout << "Manufacturer: " << manufacturer << endl;
    }
}; 

class Four_Wheeler: public Vehicle
{
public:
    Four_Wheeler(int mileage, string manufacturer): Vehicle(mileage, manufacturer) {}

    void first_maintenance()
    {
        if (mileage >= 5000)
        {
            cout << "Maintenance is due for this four wheeler." << endl;
        }
        else
        {
            cout << "Maintenance is not due for this four wheeler." << endl;
        }
    }
}; 

class Two_Wheeler: public Vehicle
{
public:
    Two_Wheeler(int mileage, string manufacturer): Vehicle(mileage, manufacturer) {}

    void first_maintenance()
    {
        if (mileage >= 2000)
        {
            cout << "Maintenance is due for this two wheeler." << endl;
        }
        else
        {
            cout << "Maintenance is not due for this two wheeler." << endl;
        }
    }
}; 

int main() 
{ 
    Four_Wheeler car(6000, "Toyota");
    Two_Wheeler bike(3000, "Honda");

    cout << "Car details: " << endl;
    car.display();
    car.first_maintenance();

    cout << endl;

    cout << "Bike details: " << endl;
    bike.display();
    bike.first_maintenance();

    return 0; 
}
	
