/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/


#include<iostream>
using namespace std;

class Vehicle
{
	protected:
		int mileage;
		string manufacturer;
	public:
		Vehicle(int m,string man)
		{
			mileage=m;
			manufacturer=man;
		}
		void display()
		{
			cout<<"Mileage: "<<mileage<<endl;
			cout<<"Manufacturer: "<<manufacturer<<endl;
		}
		virtual void first_maintenance()=0;
};

class Four_Wheeler:public Vehicle
{
	public:
		Four_Wheeler(int m,string man):Vehicle(m,man)
		{
			
		}
		void first_maintenance()
		{
			if(mileage>5000)
				cout<<"Maintenance of Four Wheeler is due"<<endl;
			else
				cout<<"Maintenance of Four Wheeler is not due"<<endl;
		}
};

class Two_Wheeler:public Vehicle
{
	public:
		Two_Wheeler(int m,string man):Vehicle(m,man)
		{
			
		}
		void first_maintenance()
		{
			if(mileage>2000)
				cout<<"Maintenance of Two Wheeler is due"<<endl;
			else
				cout<<"Maintenance of Two Wheeler is not due"<<endl;
		}
};

int main()
{
	Four_Wheeler car(7000,"BMW");
	Two_Wheeler bike(1500,"Honda");
	
	cout<<"Car:"<<endl;
	car.display();
	car.first_maintenance();
	cout<<endl;
	
	cout<<"Bike:"<<endl;
	bike.display();
	bike.first_maintenance();
	
	return 0;
}