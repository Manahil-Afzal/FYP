/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class Vehicle
{
    public:
    string manufacturer;
    int mileage;
    virtual void first_maintenance()=0;
    void display()
    {
        cout<<"Manufacturer of vehicle is "<<manufacturer<<" and the mileage is "<<mileage<<" Km.\n"<<endl;
    }
};
class Four_Wheeler:public Vehicle
{
    public:
    void first_maintenance()
    {
        if(mileage>=5000)
    {
        cout<<"Vehicle need maintenance\n"<<endl;
    }
        else{
            cout<<"Vehicle not need maintenance\n"<<endl;
        }
        };
    };
class Two_Wheeler:public Vehicle
{
    public:
    void first_maintenance(){
        if(mileage>=2000)
        {
            cout<<"Vehicle need maintenance\n"<<endl;
        }
        else {
            cout<<"Vehicle not need maintenance\n"<<endl;
        }
    }
};
int main()
{
    Four_Wheeler car;
    Two_Wheeler bike;
    cout<<"Mileage of four wheeler:"<<endl;
    cin>>car.mileage;
    cout<<"Enter manufacture of four wheeler:"<<endl;
    cin>>car.manufacturer;
    cout<<"Mileage of two wheeler:"<<endl;
    cin>>bike.mileage;
    cout<<"Enter manufacture of two wheeler:"<<endl;
    cin>>bike.manufacturer;
    car.display();
    car.first_maintenance();
    bike.display();
    bike.first_maintenance();
    return 0;
}
