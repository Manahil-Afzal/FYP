/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include <iostream>
using namespace std;
class Vehicle{
	protected:
		int mileage;
		string manufacturer;
		string abc;
	public:
		virtual void first_maintenance()=0; 
		void display(){
			cout<<"\n Manufacturer : "<<manufacturer<<endl;
			cout<<" Mileage : "<<mileage<<" km"<<endl;
			cout<<" "<<abc<<endl;
		}
}; 
class Four_Wheeler: public Vehicle{
	public:
		void first_maintenance(){
			cout<<"Enter manufacturer for four wheeler:";
			cin>>manufacturer;
			cout<<"Enter mileage for four wheeler vehicle:";
			cin>>mileage;
			if(mileage>=5000)
			abc="Maintenance is due.";		
			else
			abc="Maintenance is not due.";
}
};
class Two_Wheeler : public Vehicle {
	public:
		void first_maintenance(){
			cout<<"\nEnter manufacturer for two wheeler:";
			cin>>manufacturer;
			cout<<"Enter mileage for two wheeler vehicle:";
			cin>>mileage;
			if(mileage>=2000)
			abc="Maintenance is due.";		
			else
			abc="Maintenance is not due.";
	}
};

int main(){
	Four_Wheeler car;
	car.first_maintenance();
	Two_Wheeler bike;
	bike.first_maintenance();
   car.display();
   bike.display();
}



	
