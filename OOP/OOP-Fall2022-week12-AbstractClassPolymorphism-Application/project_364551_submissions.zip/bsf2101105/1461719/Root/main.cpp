/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class Vehicle{
    protected:
    int mileage;
    string manufacturer;
    public:
    virtual void first_maintenance() = 0;
    void display(){
        cout<<"Mileage "<<mileage<<endl;
        cout<<"Manufacturer "<<manufacturer<<endl;
    }
};
class Four_Wheeler : public Vehicle{
    public:
    virtual void first_maintenance(){
        cout<<"Enter name of Manufacturer"<<endl;
        cin>>manufacturer;
        cout<<"Enter the Mileage of your 4 wheeler"<<endl;
        cin>>mileage;
        if(mileage>5000)
        {
            cout<<"Maintenance is required"<<endl;
        }
        else
        {
            cout<<"Maintenance is not required"<<endl;
        }
    }
};
class Two_Wheeler : public Vehicle{
    public:
    void first_maintenance(){
        cout<<"Enter name of Manufacturer"<<endl;
        cin>>manufacturer;
        cout<<"Enter the Mileage of your 2 wheeler"<<endl;
        cin>>mileage;
        if(mileage>2000)
        {
            cout<<"Maintenance is required"<<endl;
        }
        else
        {
            cout<<"Maintenance is not required"<<endl;
        }
    }
};
int main(){
    Four_Wheeler *car;
    Two_Wheeler *bike;
    car->first_maintenance();
    bike->first_maintenance();
    car->display();
    bike->display();
    return 0;
    
}
	

	

	
