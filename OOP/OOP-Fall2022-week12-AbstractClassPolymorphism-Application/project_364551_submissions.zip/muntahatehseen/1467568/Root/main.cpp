/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

#include<iostream>
#include<string.h>
using namespace std;
class Vehicle{
    public:
    float mileage;
    string manufacturer;
    void virtual first_maintenance()=0;
    virtual void set_details(float m,string mf){
        mileage=m;
        manufacturer=mf;
    }
    virtual void display_details(){
        cout<<"Mileage : "<<mileage<<endl;
        cout<<"Manufacturer : "<<manufacturer;
    }
    
};
class Four_Wheeler:public Vehicle{
    public:
    virtual void first_maintenance()
    {
        if(mileage<=5000)
        cout<<"Maintenance is due"<<endl;
        else
        cout<<"No maintenance due"<<endl;
    }
     virtual void set_details(float m,string mf) {
        mileage=m;
        manufacturer=mf;
    }
    virtual void display_details() {
        cout<<"Mileage : "<<mileage<<endl;
        cout<<"Manufacturer : "<<manufacturer;
    }
    
};
class Two_Wheeler:public Vehicle{
    public:
      void first_maintenance()
    {
        if(mileage<=2000){
        cout<<"Maintenance is due"<<endl;
        }
        else
        cout<<"No maintenance due"<<endl;
    }
     virtual void set_details(float m,string mf) {
        mileage=m;
        manufacturer=mf;
    }
    virtual void display_details(){
        cout<<"Mileage : "<<mileage<<endl;
        cout<<"Manufacturer : "<<manufacturer;
    }
    
};
int main()
{
    Four_Wheeler car;
    Two_Wheeler bike;
    car.set_details(56000,"city");
    car.display_details();
    car.first_maintenance();
}
