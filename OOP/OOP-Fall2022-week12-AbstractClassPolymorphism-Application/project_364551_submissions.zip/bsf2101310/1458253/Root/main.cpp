/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class Vehicle{
    protected:
    float mileageOfFourWheeler;
    string manufacturerOfFourWheeler;
    float mileageOfTwoWheeler;
    string manufacturerOfTwoWheeler;
    public:
    virtual void first_maintenance()=0;
    void display()
    {
        cout<<"the mileage of four Wheeler is: "<<mileageOfFourWheeler<<endl;
        cout<<"the manufacturer of four wheeler is: "<<manufacturerOfFourWheeler<<endl;
        cout<<"the mileage of two Wheeler is: "<<mileageOfTwoWheeler<<endl;
        cout<<"the manufacturer of two wheeler is: "<<manufacturerOfTwoWheeler<<endl;
    }
};
class four_wheeler:public Vehicle{
    public:
    void first_maintenance()
    {
        float mileageOfFourWheeler;
        string manufacturerOfFourWheeler;
        cout<<"enter the mileage of four wheeler"<<endl;
        cin>>mileageOfFourWheeler;
        
        cout<<"enter manufacturer of four wheeler"<<endl;
        cin>>manufacturerOfFourWheeler;
        if(mileageOfFourWheeler>=5000)
        {
            cout<<"the maintenance for four_wheeler is due "<<endl;
        }
        else
        {
            cout<<" four wheeler does not need maintenance"<<endl;
        }
    }
};
class two_wheeler:public Vehicle{
    public:
    float mileageOfTwoWheeler;
    string manufacturerOfTwoWheeler;
    void first_maintenance()
    {
        cout<<"enter mileage of two wheeler"<<endl;
        cin>>mileageOfTwoWheeler;
        
        cout<<"enter manufacturer of two wheeler"<<endl;
        cin>>manufacturerOfTwoWheeler;
        if(mileageOfTwoWheeler>=2000)
        {
            cout<<"the maintenance of two_wheeler is due"<<endl;
        }
        else
        {
            cout<<" two wheeler does not need maintenance"<<endl;
        }
    }
};
 

void intermediate_func(Vehicle *v )
 {
    v->first_maintenance();
 }

int main()
{
    
    four_wheeler *car=new four_wheeler;
    two_wheeler *bike=new two_wheeler;
    intermediate_func(car);
    intermediate_func(bike);
 delete car;
    delete bike;
    return 0;
    
}/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

	
