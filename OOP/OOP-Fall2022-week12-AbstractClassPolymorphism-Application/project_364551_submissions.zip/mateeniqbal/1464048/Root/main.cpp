/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include <iostream>
using namespace std;
class Vehicle {
 public:
  Vehicle(int mileage, string manufacturer)
      : mileage_(mileage), manufacturer_(manufacturer) {}
  virtual void first_maintenance() = 0;
  void display() {
    cout << "Mileage: " << mileage_ <<endl;
    cout << "Manufacturer: " << manufacturer_ <<endl;
  }
 protected:
  int mileage_;
  string manufacturer_;
};

class Four_Wheeler : public Vehicle {
 public:
  Four_Wheeler(int mileage,string manufacturer) : Vehicle(mileage, manufacturer) {}
  void first_maintenance() override {
    if (mileage_ >= 5000) {
      cout << "Maintenance is due for the four wheeler." <<endl;
    } else {
      cout << "Four wheeler does not need maintenance yet." <<endl;
    }
  }
};

class Two_Wheeler : public Vehicle {
 public:
  Two_Wheeler(int mileage,string manufacturer) : Vehicle(mileage, manufacturer) {}
  void first_maintenance() override {
    if (mileage_ >= 2000) {
      cout << "Maintenance is due for the two wheeler." <<endl;
    } else {
      cout << "Two wheeler does not need maintenance yet." <<endl;
    }
  }
};

int main() {
  Four_Wheeler car(6000, "Toyota");
  Two_Wheeler bike(1600, "Honda");

  cout << "Four Wheeler:" <<endl;
  car.display();
  car.first_maintenance();
  cout <<endl;

  cout << "Two Wheeler:" <<endl;
  bike.display();
  bike.first_maintenance();

  return 0;
}

