#include <iostream>
using namespace std;
class Vehicle {
 public:
  Vehicle(int mileage, string manufacturer)
      : mileage_(mileage), manufacturer_(manufacturer) {}
  virtual void first_maintenance() = 0;
  void display() {
    cout << "Mileage: " << mileage_ <<endl;
    cout << "Manufacturer: " << manufacturer_ <<endl;
  }
 protected:
  int mileage_;
  string manufacturer_;
};

class Four_Wheeler : public Vehicle {
 public:
  Four_Wheeler(int mileage,string manufacturer) : Vehicle(mileage, manufacturer) {}
  void first_maintenance() override {
    if (mileage_ >= 5000) {
      cout << "Maintenance is due for the four wheeler." <<endl;
    } else {
      cout << "Four wheeler does not need maintenance yet." <<endl;
    }
  }
};

class Two_Wheeler : public Vehicle {
 public:
  Two_Wheeler(int mileage,string manufacturer) : Vehicle(mileage, manufacturer) {}
  void first_maintenance() override {
    if (mileage_ >= 2000) {
      cout << "Maintenance is due for the two wheeler." <<endl;
    } else {
      cout << "Two wheeler does not need maintenance yet." <<endl;
    }
  }
};

int main() {
  Four_Wheeler car(6000, "Toyota");
  Two_Wheeler bike(1600, "Honda");

  cout << "Four Wheeler:" <<endl;
  car.display();
  car.first_maintenance();
  cout <<endl;

  cout << "Two Wheeler:" <<endl;
  bike.display();
  bike.first_maintenance();

  return 0;
}