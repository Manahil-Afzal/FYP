/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class Vahicle{
protected:
int mileage;
string manufacturer;
public:
virtual void first_maintenance()=0;
void display(){
	cout<<"\nmilaege is:"<<mileage<"km";
	cout<<"\nmanufacturer is:"<<manufacturer;
    
}
};
class Four_wheeler:public Vahicle{
public:
void first_maintenance(){
	cout<<"\nEnter mileage of four wheeler:";
	cin>>mileage;
	cout<<"Enter manufacturer name of four wheeler:";
	cin>>manufacturer;
	if(mileage>5000){
		cout<<"\ncar required maintanance!";
	}
	else {
		cout<<"\ncar dosn't required maintanance!";
	}
	}	
};
class Two_wheeler:public Vahicle{
public:
void first_maintenance(){
	cout<<"\n\nEnter mileage of two wheeler:";
	cin>>mileage;
	cout<<"Enter manufacturer name of two wheeler:";
	cin>>manufacturer;
	if(mileage>2000){
		cout<<"\nbike required maintanance!";
	}
	else {
		cout<<"\nbike dosn't required maintanance!";
	
	}
	}		
};
int main (){
	Vahicle *v1;
	Four_wheeler car;
	v1=&car;
	v1->first_maintenance();
	v1->display();
	Two_wheeler bike;
	v1=&bike;
	v1->first_maintenance();
	v1->display();    
}
