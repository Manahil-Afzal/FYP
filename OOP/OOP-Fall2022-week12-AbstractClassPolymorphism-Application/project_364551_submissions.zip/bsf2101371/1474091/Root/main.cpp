/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

	
#include <iostream>
#include <string>

using namespace std;

class Vehicle {
protected:
int mileage;
string manufacturer;

public:
Vehicle(int m, string manu) : mileage(m), manufacturer(manu) {}

virtual void first_maintenance() = 0;

void display() {
cout << "Mileage: " << mileage << endl;
cout << "Manufacturer: " << manufacturer << endl;
}
};

class Four_Wheeler : public Vehicle {
public:
Four_Wheeler(int m, string manu) : Vehicle(m, manu) {}

void first_maintenance() {
if (mileage >= 5000) {
cout << "Four wheeler maintenance is due." << endl;
} else {
cout << "Four wheeler maintenance is not due." << endl;
}
}
};

class Two_Wheeler : public Vehicle {
public:
Two_Wheeler(int m, string manu) : Vehicle(m, manu) {}

void first_maintenance() {
if (mileage >= 2000) {
cout << "Two wheeler maintenance is due." << endl;
} else {
cout << "Two wheeler maintenance is not due." << endl;
}
}
};

int main() {
Vehicle *car = new Four_Wheeler(6000, "Toyota");
Vehicle *bike = new Two_Wheeler(3000, "Honda");

car->display();
car->first_maintenance();

cout << endl;

bike->display();
bike->first_maintenance();

return 0;
}

