/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include <iostream>
#include <string>

using namespace std;

class Vehicle
{
protected:
  int mileage;
  string manufacturer;
public:
    Vehicle (int m, string man):mileage (m), manufacturer (man)
  {
  }
  virtual void first_maintenance () = 0;
  void display ()
  {
    cout << "Mileage: " << mileage << endl;
    cout << "Manufacturer: " << manufacturer << endl;
  }
};

class Four_Wheeler:public Vehicle
{
public:
  Four_Wheeler (int m, string man):Vehicle (m, man)
  {
  }
  void first_maintenance ()
  {
    if (mileage >= 5000)
      {
	cout << "Maintenance is due for the four wheeler." << endl;
      }
    else
      {
	cout << "Maintenance is not due for the four wheeler." << endl;
      }
  }
};

class Two_Wheeler:public Vehicle
{
public:
  Two_Wheeler (int m, string man):Vehicle (m, man)
  {
  }
  void first_maintenance ()
  {
    if (mileage >= 2000)
      {
	cout << "Maintenance is due for the two wheeler." << endl;
      }
    else
      {
	cout << "Maintenance is not due for the two wheeler." << endl;
      }
  }
};

int
main ()
{
  Four_Wheeler car (6000, "Toyota");
  Two_Wheeler bike (2500, "Honda");
  Vehicle *ptr1 = &car;
  Vehicle *ptr2 = &bike;

  cout << "Four wheeler:" << endl;
  ptr1->display ();
  ptr1->first_maintenance ();
  cout << endl;

  cout << "Two wheeler:" << endl;
  ptr2->display ();
  ptr2->first_maintenance ();

  return 0;
}


	
