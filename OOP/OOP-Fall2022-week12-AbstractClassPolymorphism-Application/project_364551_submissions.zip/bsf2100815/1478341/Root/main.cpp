/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/

#include<iostream>
using namespace std;
class vehicle{

    protected:
    int mileage;
    string manufacturer;
    public:
    virtual void first_maintenance()=0; //pure virtual function
    void input()
    {
        cout<<"\nEnter mileage: ";
        cin>>mileage;
        cout<<"Enter manufacturer: ";
        cin>>manufacturer;
    }
    void display()
    {
        cout<<"Mileage of vehicle is: "<<mileage<<endl;
        cout<<"Manufacturer of vehicle is: "<<manufacturer<<endl;
        first_maintenance();
    }
    
};
class four_wheeler: public vehicle{
    public:
    void first_maintenance()
    {
        if(mileage>=5000)
        {
            cout<<"Maintenance is needed: "<<endl;
        }
        else
        {
            cout<<"Vehicle is in good condition: "<<endl;
        }
    }
    void display()
    {
        cout<<"Mileage of vehicle is: "<<mileage<<endl;
        cout<<"Manufacturer of vehicle is: "<<manufacturer<<endl;
        first_maintenance();
    }
    
};
class two_wheeler: public vehicle{
    public:
    void first_maintenance()
    {
        if(mileage>=2000)
        {
            cout<<"Maintenance is needed: "<<endl;
        }
        else
        {
            cout<<"Vehicle is in good condition: "<<endl;
        }
    }
    void display()
    {
        cout<<"Mileage of vehicle is: "<<mileage<<endl;
        cout<<"Manufacturer of vehicle is: "<<manufacturer<<endl;
        first_maintenance();
    }
    
};
int main()
{
    vehicle *obj1;
    four_wheeler car;
    two_wheeler bike;
    car.input();
    obj1=&car;
    cout<<"\n\tFour_Wheeler vehicle: "<<endl;
    obj1->display();
    bike.input();
    obj1=&bike;
    cout<<"\n\tTwo_Wheeler vehicle: "<<endl;
    obj1->display();
    
    
    return 0;
}
