/*Write a C++ program having three classes named: Vehicle, Four_Wheeler, Two_Wheeler where Vehicle is parent class of the latter two classes.
The Vehicle class has two data members named mileage and manufacturer. It also has a pure virtual function named 
first_maintenance() that displays appropriate message (in it's overriden versions in derived classes)
if the maintenance of vehicle is due or not according (maintenance is due if the mileage of vehicle reaches 5000 km or above for four wheeler
and 2000 km or above for two wheeler). Vehicle class also has a display function that displays the mileage and manufacturer of the vehicle.
Create one Four_Wheeler object, named car, and one Two_Wheeler object, named bike. Display the mileage and manufacturer of both vehicles 
(car and bike) polymorphically. Also display appropriate messages in case the vehicles need maintenance or not.*/
#include<iostream>
using namespace std;
class Vehicle
{ public:
	int milage;
	string manufecturer;
	virtual void first_maintenance()=0;
	void Display()
	{
		
		cout<<"Manufecturer of vehicle is: "<<manufecturer;
		cout<<"Milage of vehicle is: "<<milage;
	}
};
class Four_Wheeler:public Vehicle
{public:
	void first_maintenance(){
	  if (milage>=1000)
	    {
	cout<<"Vehicle needs maintenance "<<endl;
	cin>>milage;
	    }
	    else 
	    {
	cout<<"Vehicle needs no maintenance "<<endl;
	    }
}
 };
 class Two_wheeler:public Vehicle
 {public:
		void first_maintenance(){
	
	  if (milage>=3000)
	    {
	cout<<"Vehicle needs maintenance"<<endl;
	cin>>manufecturer;


	    }
	    else 
	    {
	cout<<"Vehicle needs no maintenance"<<endl;}

		}
 };
 int main()
{  Four_Wheeler car;
Two_wheeler bike;
	
cout<<"Enter the manufacturer of the Four wheeler vehicle: ";
cin>>car.manufecturer;
cout<<"Enter the milleage of the Four wheeler vehicle: ";
cin>>car.milage;

cout<<"Enter the manufacturer of the Two wheeler vehicle: ";
cin>>bike.manufecturer;
cout<<"Enter the milleage of the Two wheeler vehicle: ";
cin>>bike.milage;
	
car.Display();
car.first_maintenance();
bike.Display();
bike.first_maintenance(); 
return 0;
}
	
