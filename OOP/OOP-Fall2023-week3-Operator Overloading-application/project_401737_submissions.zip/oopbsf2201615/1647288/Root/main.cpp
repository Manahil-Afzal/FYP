/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;
class Rational {
private:
  int numerator;
  int denominator;
  static int objectCount;

public:
  Rational(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
    if (denominator == 0) {

      denominator = 1;
    }
    objectCount++;
  }

  Rational(const Rational &other)
      : numerator(other.numerator), denominator(other.denominator) {
    objectCount++;
  }

  void input() {
    do {
      cout << "Enter the numerator: ";
      cin >> numerator;
      cout << "Enter the denominator (not zero): ";
      cin >> denominator;
      if (denominator == 0) {
      }
    } while (denominator == 0);
  }

  static int getObjectCount() { return objectCount; }

  void display() const { std::cout << numerator << "/" << denominator; }

  Rational operator*(const Rational &other) const {
    return Rational(numerator * other.numerator,
                    denominator * other.denominator);
  }

  Rational operator/(const Rational &other) const {
    if (other.numerator == 0) {
      cerr << "Error: Division by zero." << std::endl;
      return Rational(); // Return a default-constructed Rational
    }
    return Rational(numerator * other.denominator,
                    denominator * other.numerator);
  }
};

int Rational::objectCount = 0;

int main() {
  Rational r1, r2, result;

  cout << "Enter the first rational number:\n";
  r1.input();

  cout << "Enter the second rational number:\n";
  r2.input();

  result = r1 * r2;
  cout << "Multiplication result: ";
  result.display();
  cout << endl;

  result = r1 / r2;
  cout << "Division result: ";
  result.display();
  cout << endl;

  cout << "Total objects created: " << Rational::getObjectCount() << endl;

  return 0;
}