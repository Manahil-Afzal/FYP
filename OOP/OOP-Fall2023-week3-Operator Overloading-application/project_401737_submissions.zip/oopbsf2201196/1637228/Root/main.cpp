/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep track of object count

public:
    RationalNumber(int num = 0, int den = 1) {
        // Parameterized constructor
        if (den == 0) {
            cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
            den = 1;
        }
        numerator = num;
        denominator = den;
        count++; // Increment object count
    }

    RationalNumber(const RationalNumber &other) {
        // Copy constructor
        numerator = other.numerator;
        denominator = other.denominator;
        count++; // Increment object count
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    RationalNumber operator*(const RationalNumber &other) {
        // Overloaded multiplication operator
        RationalNumber result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber &other) {
        // Overloaded division operator
        RationalNumber result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        if (result.denominator == 0) {
            cout << "Division by zero detected. Result set to 0/1." << endl;
            result.numerator = 0;
            result.denominator = 1;
        }
        return result;
    }

    void display() {
        cout << numerator << "/" << denominator << endl;
    }

    static int getObjectCount() {
        return count;
    }
};

int RationalNumber::count = 0; // Initialize static member

int main() {
    RationalNumber r1, r2;
    r1.input();
    r2 = r1; // Copy constructor called here
    cout << "Rational Numbers (Count: " << RationalNumber::getObjectCount() << "):" << endl;
    cout << "Rational Number 1: ";
    r1.display();
    cout << "Rational Number 2: ";
    r2.display();

    RationalNumber multiplication = r1 * r2;
    RationalNumber division = r1 / r2;

    cout << "Multiplication: ";
    multiplication.display();
    cout << "Division: ";
    division.display();

    return 0;
}
