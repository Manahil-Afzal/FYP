/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int objectCount;  // Static member to keep track of the number of objects

public:
    // Parameterized constructor
    RationalNumber(int num, int denom) : numerator(num), denominator(denom) {
        // Check if the denominator is zero and handle the error
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero. Setting to 1." << std::endl;
            denominator = 1;
        }

        // Increment the count of objects
        objectCount++;
    }

    // Copy constructor
    RationalNumber(const RationalNumber& other) : numerator(other.numerator), denominator(other.denominator) {
        // Increment the count of objects
        objectCount++;
    }

    // Static method to get the count of objects
    static int getObjectCount() {
        return objectCount;
    }

    // Method to take input from the user
    void userInput() {
        std::cout << "Enter Numerator: ";
        std::cin >> numerator;

        do {
            std::cout << "Enter Denominator (non-zero): ";
            std::cin >> denominator;

            if (denominator == 0) {
                std::cerr << "Error: Denominator cannot be zero. Please enter a non-zero value." << std::endl;
            }

        } while (denominator == 0);
    }

    // Method to display the rational number
    void display() const {
        std::cout << numerator << "/" << denominator;
    }

    // Operator overloading for multiplication
    RationalNumber operator*(const RationalNumber& other) const {
        return RationalNumber(numerator * other.numerator, denominator * other.denominator);
    }

    // Operator overloading for division
    RationalNumber operator/(const RationalNumber& other) const {
        // Check for division by zero
        if (other.numerator == 0) {
            std::cerr << "Error: Division by zero. Returning default value." << std::endl;
            return RationalNumber(0, 1);
        }

        return RationalNumber(numerator * other.denominator, denominator * other.numerator);
    }

    // Destructor
    ~RationalNumber() {
        // Decrement the count of objects when an object is destroyed
        objectCount--;
    }
};

// Initialize the static member
int RationalNumber::objectCount = 0;

int main() {
    // Example usage of the RationalNumber class
    RationalNumber num1(3, 4);
    RationalNumber num2 = num1; // Copy constructor is called

    std::cout << "Number of RationalNumber objects: " << RationalNumber::getObjectCount() << std::endl;

    RationalNumber resultMul = num1 * num2;
    RationalNumber resultDiv = num1 / num2;

    // Display results
    std::cout << "Multiplication: ";
    resultMul.display();
    std::cout << std::endl;

    std::cout << "Division: ";
    resultDiv.display();
    std::cout << std::endl;

    return 0;
}
