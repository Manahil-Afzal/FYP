/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero
*/

#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count; 
public:
    
    Rational(int num, int den) : numerator(num), denominator(den) {
        count++;
    }

   
    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++; 
    }

    
    void input() {
        std::cout << "Enter the numerator: ";
        std::cin >> numerator;
        
        do {
            std::cout << "Enter the denominator (must be nonzero): ";
            std::cin >> denominator;
        } while (denominator == 0);
    }

   
    Rational operator*(const Rational& other) {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return Rational(num, den);
    }

    
    Rational operator/(const Rational& other) {
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return Rational(num, den);
    }

   
    static int getCount() {
        return count;
    }

    
    void display() {
        std::cout << numerator << "/" << denominator;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(3, 4); 
    Rational r2 = r1; 
    
    r1.display();
    std::cout << " * ";
    r2.display();
    std::cout << " = ";
    (r1 * r2).display();
    std::cout << std::endl;

    r1.display();
    std::cout << " / ";
    r2.display();
    std::cout << " = ";
    (r1 / r2).display();
    std::cout << std::endl;

    std::cout << "Total objects created: " << Rational::getCount() << std::endl;

    return 0;
}