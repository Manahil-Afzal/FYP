/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;

public:
    RationalNumber(int num = 0, int den = 1) {
        if (den == 0) {
            cout << "Denominator cannot be zero. Setting it to 1." << endl;
            den = 1;
        }
        numerator = num;
        denominator = den;
        count++;
    }

    RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (not zero): ";
        cin >> denominator;

        while (denominator == 0) {
            cout << "Denominator cannot be zero. Please enter again: ";
            cin >> denominator;
        }
    }

    static int getCount() {
        return count;
    }

    RationalNumber operator*(const RationalNumber& other) {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return RationalNumber(num, den);
    }

    RationalNumber operator/(const RationalNumber& other) {
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return RationalNumber(num, den);
    }

    void display() {
        cout << numerator << "/" << denominator;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1, num2;

    cout << "Enter values for the first rational number:" << endl;
    num1.input();

    cout << "Enter values for the second rational number:" << endl;
    num2.input();

    cout << "First Rational Number: ";
    num1.display();
    cout << endl;

    cout << "Second Rational Number: ";
    num2.display();
    cout << endl;

    RationalNumber result_mult = num1 * num2;
    cout << "Multiplication Result: ";
    result_mult.display();
    cout << endl;

    RationalNumber result_div = num1 / num2;
    cout << "Division Result: ";
    result_div.display();
    cout << endl;

    cout << "Total RationalNumber objects created: " << RationalNumber::getCount() << endl;

    return 0;
}
