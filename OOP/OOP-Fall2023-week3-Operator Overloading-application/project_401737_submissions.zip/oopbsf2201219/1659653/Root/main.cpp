/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include<iostream>
using namespace std;

class rationalNum
{
	private:
		int numerator, denominator;
		static int count;
	public:
		rationalNum(int nume, int denomi) {
			numerator=nume;
		if (denomi!=0) {
			denominator=denomi;
		} else { 
			cout<<"Denominator can not be zero.Set denominator is equal to 1."<<endl;
			denominator=1;
	}
		count++;
}

rationalNum(const rationalNum& Other) {
	numerator=Other.numerator;
	denominator=Other.denominator;
	count++;
}

void inputDetails(){
	cout<<"Enter numerator:";
	cin>>numerator;
	cout<<"Enter denominator:";
	cin>>denominator;
	
	if (denominator==0) {
		cout<<"Denominator cannot be zero. Set denominator equal to 1.";
		denominator=1;
	}
}

static int getCount(){
	return count;
}

 rationalNum operator*(const rationalNum& Other) {
        rationalNum result(numerator*Other.numerator, denominator*Other.denominator);
        return result;
    }

    rationalNum operator/(const rationalNum& Other) {
        rationalNum result(numerator*Other.denominator, denominator*Other.numerator);
        return result;
    }

    void display() {
        cout<<numerator<<"/"<<denominator<<endl;
    }
};

int rationalNum::count=0;

int main() 
{
    rationalNum num1(1,2);
    rationalNum num2(5,6);
    num2.inputDetails();

    rationalNum result1=num1*num2;
    cout<<"Result of multiplication:";
    result1.display();

    rationalNum result2=num1/num2;
    cout<<"Result of division:";
    result2.display();

    cout<<"Total Rational Number objects created:"<<rationalNum::getCount()<<endl;

    return 0;
}