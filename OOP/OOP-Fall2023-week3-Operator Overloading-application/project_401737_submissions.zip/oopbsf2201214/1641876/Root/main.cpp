/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class Rational{
    private:
    int nom;
    int dem;
    static int count;  
    public:
    	 Rational() {
        nom = 0;
        dem = 1;
        count++;
    }  
	Rational input()
   {
       cout<<"Enter numerator:";
       cin>>nom;
       cout<<"Enter denominator:";
       cin>>dem;  
       if(dem==0)
       {
           cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
           dem =1;
       }
   } 
    Rational(int _nom,int _dom)
    {
        nom=_nom;
        dem=_dom;
    }
    
   Rational(Rational & r)
   {
       nom=r.nom;
       dem=r.dem;
   }
   
   Rational operator*(const Rational& t) {
        Rational res;
        res.nom = nom * t.nom;
        res.dem = dem * t.dem;
        return res;
    }
 Rational operator/(const Rational&  t)
   {
        Rational res;
        res.nom=nom*t.dem;
        res.dem=dem*t.nom;
        return res;
   }
   void display()
   {
       cout<<"\n Value is: "<<nom<<"/" <<dem;
       cout<<"\n Count: = "<<count<<"\n";
   }
};
int Rational::count = 0;
 int main(){
   Rational R1, R3,R4,R5;
   R1.input();
   R5.input();
 
   cout<<"R1: ";
   R1.display();
   
   Rational R2(R1);
   cout<<"R2 copy constructor: ";
   R2.display();
   
   cout<<"R5:  ";
   R5.display();
   
   R3 = R5*R2;
   R4 = R5/R2;
   
     cout<<"R5*R2:  ";
    R3.display();
      cout<<"R5/R2:  ";
    R4.display();
   
 }