/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
#include <algorithm>
class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;
    int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    void reduce() {
        int common = gcd(std::abs(numerator), denominator);
        numerator /= common;
        denominator /= common;
    }
public:
    RationalNumber(int num = 0, int den = 1) : numerator(num), denominator(den) {
        if (denominator == 0) {
            std::cerr << "Error: Denominator cannot be zero." << std::endl;
            exit(1);
        }
        reduce();
        count++;
    }
    RationalNumber(const RationalNumber& other) : numerator(other.numerator), denominator(other.denominator) {
        count++;
    }
    static int getCount() {
        return count;
    }
    RationalNumber operator*(const RationalNumber& other) const {
        return RationalNumber(numerator * other.numerator, denominator * other.denominator);
    }
    RationalNumber operator/(const RationalNumber& other) const {
        if (other.numerator == 0) {
            std::cerr << "Error: Division by zero is not allowed." << std::endl;
            exit(1);
        }
        return RationalNumber(numerator * other.denominator, denominator * other.numerator);
    }
    void display() const {
        std::cout << numerator << "/" << denominator;
    }
};
int RationalNumber::count = 0;
int main() {
    RationalNumber num1(1, 2);
    RationalNumber num2(num1); // Copy constructor
    RationalNumber num3;
    num3 = RationalNumber(3, 4);
    std::cout << "Count of RationalNumber objects: " << RationalNumber::getCount() << std::endl;
    RationalNumber result1 = num1 * num3;
    RationalNumber result2 = num1 / num3;
    std::cout << "Result of multiplication: ";
    result1.display();
    std::cout << std::endl;
    std::cout << "Result of division: ";
    result2.display();
    std::cout << std::endl;
    return 0;
}