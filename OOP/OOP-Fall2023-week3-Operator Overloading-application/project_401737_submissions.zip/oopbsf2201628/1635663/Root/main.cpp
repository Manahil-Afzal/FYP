/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
*/

#include<iostream>

using namespace std;

class Rational {
private:
    int numerator;
    int denominator;

public:
    Rational(int num = 0, int denom = 1) {
        numerator = num;
        denominator = denom;
    }

    // Copy constructor
    Rational(const Rational &other) {
        numerator = other.numerator;
        denominator = other.denominator;
    }

    // Function to input numerator and denominator
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
    }

    // Overloading * operator for multiplication
    Rational operator*(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    // Overloading / operator for division
    Rational operator/(const Rational &other) {
        Rational result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }

    // Display the rational number
    void display() {
        cout << numerator << "/" << denominator << endl;
    }
};

int main() {
    Rational r1, r2, product, quotient;

    cout << "Enter the first rational number:" << endl;
    r1.input();

    cout << "Enter the second rational number:" << endl;
    r2.input();

    product = r1 * r2;
    quotient = r1 / r2;

    cout << "Product of the two rational numbers: ";
    product.display();

    cout << "Quotient of the two rational numbers: ";
    quotient.display();

    return 0;
}
