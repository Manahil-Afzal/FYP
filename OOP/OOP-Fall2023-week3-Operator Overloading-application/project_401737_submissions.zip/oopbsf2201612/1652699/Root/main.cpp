/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int objectCount;

public:
    Rational(int num = 0, int den = 1) {
        if (den == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            den = 1;
        }
        numerator = num;
        denominator = den;
        objectCount++;
    }

    Rational(const Rational& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        objectCount++;
    }

    static int getObjectCount() {
        return objectCount;
    }

    void getInput() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator (non-zero): ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    void display() {
        cout << numerator << "/" << denominator;
    }

    Rational operator*(const Rational& other) {
        return Rational(numerator * other.numerator, denominator * other.denominator);
    }

    Rational operator/(const Rational& other) {
        if (other.numerator == 0) {
            cout << "Error: Division by zero. Returning 0/1." << endl;
            return Rational(0, 1);
        }
        return Rational(numerator * other.denominator, denominator * other.numerator);
    }
};

int Rational::objectCount = 0;

int main() {
    Rational r1, r2;
    r1.getInput();

    // Create a copy of r1 using the copy constructor
    Rational r3(r1);

    cout << "Enter values for the second rational number (r2):" << endl;
    r2.getInput();

    cout << "Rational Number r1: ";
    r1.display();
    cout << endl;

    cout << "Rational Number r2: ";
    r2.display();
    cout << endl;

    cout << "Rational Number r3 (copy of r1): ";
    r3.display();
    cout << endl;

    cout << "Object Count: " << Rational::getObjectCount() << endl;

    Rational product = r1 * r2;
    cout << "Multiplication: ";
    r1.display();
    cout << " * ";
    r2.display();
    cout << " = ";
    product.display();
    cout << endl;

    Rational division = r1 / r2;
    cout << "Division: ";
    r1.display();
    cout << " / ";
    r2.display();
    cout << " = ";
    division.display();
    cout << endl;

    return 0;
}
