/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator, denominator;
    static int count; // static member to keep the count of the objects of rational numbers
public:
    RationalNumber() {
        numerator = 0;
        denominator = 1;
        count++;
    }

    RationalNumber(int numerator, int denominator) {
        if (denominator == 0) {
            cout << "Invalid denominator" << endl;

        }

        this->numerator = numerator;
        this->denominator = denominator;
        count++;
    }

    RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    static int getCount() {
        return count;
    }

    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;

        cout << "Enter denominator: ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Invalid denominator" << endl;

        }
    }

    RationalNumber operator*(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = this->numerator * other.numerator;
        result.denominator = this->denominator * other.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = this->numerator * other.denominator;
        result.denominator = this->denominator * other.numerator;
        return result;
    }

    void display() {
        cout << numerator << "/" << denominator << endl;
    }
};

int RationalNumber::count = 0; // static member initialization

int main() {
    RationalNumber r1;
    RationalNumber r2;

    cout << "Enter the first rational number: ";
    r1.input();

    cout << "Enter the second rational number: ";
    r2.input();

    cout << "The first rational number is: ";
    r1.display();

    cout << "The second rational number is: ";
    r2.display();

    RationalNumber result1 = r1 * r2;
    RationalNumber result2 = r1 / r2;

    cout << "The product of the two rational numbers is: ";
    result1.display();

    cout << "The quotient of the two rational numbers is: ";
    result2.display();

    cout << "The total number of rational number objects created is: " << RationalNumber::getCount() << endl;

    return 0;
}
