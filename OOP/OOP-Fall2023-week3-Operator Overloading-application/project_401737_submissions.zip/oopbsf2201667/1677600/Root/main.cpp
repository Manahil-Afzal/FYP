/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/


#include <iostream>
using namespace std;

class Math {
private:
    int num;
    int denom;

public:
    static int objcount;

    Math() : num(0), denom(1) {
        objcount++;
    }

    Math(int x, int y) : num(x), denom(y) {
        objcount++;
    }

    Math(const Math &obj) : num(obj.num), denom(obj.denom) {
        objcount++;
    }

    void showdata() {
        cout << num << "/" << denom << endl;
    }

    void getdata() {
        cout << "Enter numerator: ";
        cin >> num;
        cout << "Enter denominator (non-zero): ";
        cin >> denom;
        while (denom == 0) {
            cout << "Denominator cannot be zero. Enter again: ";
            cin >> denom;
        }
    }

    Math operator/(const Math &obj) const {
        Math result;
        result.num = num * obj.denom;
        result.denom = denom * obj.num;
        return result;
    }

    Math operator*(const Math &obj) const {
        Math result;
        result.num = num * obj.num;
        result.denom = denom * obj.denom;
        return result;
    }

    ~Math() {
        objcount--;
    }
};

int Math::objcount = 0;

int main() {
    Math obj1(2, 5);
    Math obj2(5, 8);
    Math divide = obj1 / obj2;
    Math multiply = obj1 * obj2;

    cout << "Result of division: ";
    divide.showdata();

    cout << "Result of multiplication: ";
    multiply.showdata();

    cout << "Object count: " << Math::objcount << endl;

    return 0;
}
