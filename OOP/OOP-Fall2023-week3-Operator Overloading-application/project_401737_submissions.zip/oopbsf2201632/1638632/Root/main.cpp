/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;

class Rational {
private:
    int num, den;
public:
    Rational(int n = 0, int d = 1) {
        num = n;
        den = d;
    }

    Rational(const Rational& r1) {
        num = r1.num;
        den = r1.den;
    }

    Rational operator*(Rational &obj) {
        Rational res;
        res.num = num * obj.num;
        res.den = den * obj.den;
        return res;
    }

    Rational operator/(Rational &obj) {
        Rational res;
        res.num = num / obj.num;
        res.den = den / obj.den;
        return res;
    }

    void get_input() {
        cout << "Enter the numerator: ";
        cin >> num;
        cout << "Enter the denominator (must not be zero): ";
        cin >> den;
        if(den==0){
            den=1;  }
    }

    void print() {
        cout << num << "/" << den << '\n';
    }
};

int main() {
    Rational r1;
    r1.get_input();
    Rational r2 = r1;
    Rational r3 = r1 * r2;
    r3.print();
    Rational r4 =  r1 / r2;
    r4.print();

    return 0;
}