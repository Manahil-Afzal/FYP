/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
 #include<iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;

public:
    RationalNumber() {
        numerator = 0;
        denominator = 1;
        count++;
    }

    RationalNumber(int num, int den) {
        if (den == 0) {
            cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
            num = 0;
            den = 1;
        }
        numerator = num;
        denominator = den;
        count++;
    }

    RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    static int getCount() {
        return count;
    }

    void getValues() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    void display() {
        cout << numerator << "/" << denominator;
    }

    RationalNumber operator*(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = numerator * other.numerator;
        result.denominator = denominator * other.denominator;
        return result;
    }

    RationalNumber operator/(const RationalNumber& other) {
        RationalNumber result;
        result.numerator = numerator * other.denominator;
        result.denominator = denominator * other.numerator;
        return result;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1, num2, result_mul, result_div;

    cout << "Enter values for the first rational number:" << endl;
    num1.getValues();

    cout << "Enter values for the second rational number:" << endl;
    num2.getValues();

    result_mul = num1 * num2;
    result_div = num1 / num2;

    cout << "Multiplication result: ";
    result_mul.display();
    cout << endl;

    cout << "Division result: ";
    result_div.display();
    cout << endl;

    cout << "Total objects created: " << RationalNumber::getCount() << endl;

    return 0;
}
