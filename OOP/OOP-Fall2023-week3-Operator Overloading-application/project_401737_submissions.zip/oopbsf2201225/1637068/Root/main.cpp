/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero*/
#include<iostream>
using namespace std;
class rational{
	private:
		int numerator;
		int denominator;
		public:
			rational()
			:
				numerator(0),
				denominator(1)
			{
				
			}
			
			rational(int n,int d)
			:
				numerator(n),
				denominator(d)
				{
					
				}
   
    rational operator*(const rational& r )
    {
    	rational res;
    	res.numerator=numerator*r.numerator;
    	res.denominator=denominator*r.denominator;
    	return res;
	}
	rational operator/(const rational& r)
	{
		rational res;
		res.numerator=numerator * r.denominator;
		res.denominator=denominator * r.numerator;
		return res;
	}
	 void userinput()
    {
    	cout<<"enter numerator:"<<endl;
    	cin>>numerator;
    	cout<<"ENTER denominator:"<<endl;
    	cin>>denominator;
    	while(true)
    	{
    	if(denominator!=0)
    	{
    		break;
	    }else
	    
	    {
	    	cout<<"denominator is not zero so try again:"<<endl;
		}
		
		}
	}
	void print()
	{
		cout<<numerator<<"/"<<denominator<<endl;
	}

};
int main()
{
	rational obj1,obj2;
	
	cout<<"ENTER value for first RATIONAL NUMBER:"<<endl;
	obj1.userinput();
	
	cout<<"ENTER SECOUND RATIONAL NUMBER:"<<endl;
	obj2.userinput();

	rational multi=obj1*obj2;
	rational divi=obj1/obj2;
	
	cout<<"multiplication of ratinal number:"<<endl;
	
	multi.print();
	
	cout<<"division of rational number"<<endl;
	divi.print();
	return 0;
}