/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;
class Rational{
  private:
  int num,denum;
  public:
   static int  count;
  void getdetail(){
      cout <<"Enter the numerator";
      cin >>num;
      cout<<"Enter the denumerator";
      cin>>denum;
     // count++;
  }
  Rational(){num=0,denum=0; }
  Rational(int n,int d){num=n,denum=d;count++; }
  Rational(Rational&a){
      num=a.num;
      denum=a.denum;
  }

  void putdata(){
      cout<<"numerator"<<num<<" "<<"denumerator"<<denum<<endl;
  }
  void  operator*(Rational R){
      Rational temp;
      temp.num=num*R.num;
      temp.denum=denum*R.denum;
         cout<<"\n rational no. after multiplication :: ";
         cout <<"\n numerator = "<<temp.num<<"\n denominator = "<< temp.denum;
         count++;
  }
    void operator /(Rational c){
        Rational temp;
        temp.num=num*c.denum;
        temp.denum=denum*c.num;
         cout<<"\n rational no. after dividation :: ";
         cout <<"\n numerator = "<<temp.num<<"\n denominator = "<<temp.denum;
         count++;
    }
};
int Rational::count=0;
main(){
    Rational R1,R2(9,6);
    Rational R3=R2;
    R1.getdetail();
    R3*R2;
    R1/R3;
    cout<<"\n total object created"<<Rational::count<<endl;
    
}