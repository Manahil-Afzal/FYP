/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational{
	private:
    	float numerator,denominator;
    	static int objectCount;
	public:
    	Rational(float n, float d){    
        	numerator=n;
        	denominator=d;
        	objectCount++;
    	}
    	
    void getData(){
        cout<<"Enter Numerator : ";
        cin>>numerator;
        cout<<"Enter denominator : ";
        cin>>denominator;
        cout<<endl;
	}
	
    Rational operator*(Rational &b){
        Rational multiply(0,0);
        multiply.numerator=numerator*b.numerator;
        multiply.denominator=denominator*b.denominator;
        return multiply;
    }
	
	Rational operator/(Rational &b){
        Rational divide(0,0);
        divide.numerator=numerator/b.numerator;
        divide.denominator=denominator/b.denominator;
        return divide;
    }
    
	void Multiplication(){
        cout<<"Multiplication : "<<numerator<<"/"<<denominator<<endl;
	}
	
    void Division(){
        cout<<"Division : "<<numerator<<"/"<<denominator<<endl;
        cout<<"Total no. of created objects : "<<objectCount<<endl;
	}
	
    int check() {
        if (denominator==0){
            cout<<"Value of denominator can't be zero!";
            return 0;
        }
        return 1;
    }
};

int Rational::objectCount=0;

int main(){
    Rational R1(0,0);
        R1.getData();
        Rational R2=R1;
        R2.getData();
        if(R1.check()==1 && R2.check()==1){
            Rational R3=R1*R2;
        	R3.Multiplication();
        	R3=R1/R2;
        	R3.Division();
    	}
 	return 0;
}