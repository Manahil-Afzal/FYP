/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include<iostream>
using namespace std;
class rational{
  int denominator;
  int numerator;
  public:
    rational(){}
    rational(int a, int b){
        numerator = a;
        denominator = b;
    }
    
    rational(const rational &ref){
        numerator = ref.numerator;
        denominator = ref.denominator;
    }
    
    rational operator *(rational &other){
        rational temp(numerator * other.numerator, denominator * other.denominator);
        return temp;
    }
    
    rational operator /(rational &other){
        rational temp(numerator * other.denominator, denominator * other.numerator);
        return temp;
    }    
    
    void input();
    void display();
};

int main(){
    rational a(2,3);
    rational b;
  b.input();
    rational c=a*b;
    a.display();
    b.display();
    c.display();
    
}

void rational :: input(){
    cout<<"Enter numerator: "<<endl;
    cin>>numerator;
    cout<<"Enter denominator: "<<endl;
    cin>>denominator;
    if(denominator==0){
        cout<<"Denominator can't be 0. Setting it to 1"<<endl;
        denominator = 1;
    }
}

void rational :: display(){
    cout<<numerator<<"/"<<denominator<<endl;
}