/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
class Rational {
private:
    int numerator;
    int denominator;
    static int count; 
public:
    Rational(int num, int denom) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            std::cerr << "Denominator cannot be zero. Setting to 1.\n";
            denominator = 1;
        }
        count++; 
    }
    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++; 
}
    void input() {
        std::cout << "Enter numerator: ";
        std::cin >> numerator;

        std::cout << "Enter denominator: ";
        std::cin >> denominator;

        if (denominator == 0) {
            std::cerr << "Denominator cannot be zero. Setting to 1.\n";
            denominator = 1;
        }
    }
    void display() const {
        std::cout << numerator << "/" << denominator << "\n";
    }
    Rational operator*(const Rational& other) const {
        int num = numerator * other.numerator;
        int denom = denominator * other.denominator;

        return Rational(num, denom);
    }
    Rational operator/(const Rational& other) const {
        int num = numerator * other.denominator;
        int denom = denominator * other.numerator;

        return Rational(num, denom);
    }
    static int getCount() {
        return count;
    }
    ~Rational() {
        count--; 
    }
};
int Rational::count = 0;

int main() {
    Rational r1(3, 4);
    std::cout << "Rational number 1: ";
    r1.display();

    Rational r2(r1); // Copy constructor
    std::cout << "Rational number 2 (copied from r1): ";
    r2.display();

    Rational r3(1, 2);
    std::cout << "Rational number 3: ";
    r3.display();

    Rational result_mul = r1 * r3;
    std::cout << "Multiplication result: ";
    result_mul.display();

    Rational result_div = r1 / r3;
    std::cout << "Division result: ";
    result_div.display();

    std::cout << "Total count of Rational objects: " << Rational::getCount() << "\n";

    return 0;
}
