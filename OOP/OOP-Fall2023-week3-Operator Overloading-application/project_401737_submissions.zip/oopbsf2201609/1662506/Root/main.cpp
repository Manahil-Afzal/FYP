#include <iostream>
using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;

public:
    // Parameterized constructor with default values
    RationalNumber(int num = 0, int denom = 1) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    // Function to take input from the user
    void input() {
        cout << "Enter the numerator: ";
        cin >> numerator;
        cout << "Enter the denominator (not zero): ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting it to 1." << endl;
            denominator = 1;
        }
    }

    // ... rest of the class remains the same
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1, num2;
    num1.input();
    num2.input();

    // ... rest of the main function remains the same
}
