/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>
using namespace std;

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num, int den) {
        if (den != 0) {
            numerator = num;
            denominator = den;
            count++;
        } else {
            cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
            numerator = num;
            denominator = 1;
        }
    }

    // Copy constructor
    Rational(const Rational& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    // Input method
    void input() {
        cout << "Enter numerator: ";
        cin >> numerator;
        cout << "Enter denominator: ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Multiplication operator overloading
    Rational operator*(const Rational& other) {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return Rational(num, den);
    }

    // Division operator overloading
    Rational operator/(const Rational& other) {
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return Rational(num, den);
    }

    // Display method
    void display() {
        cout << numerator << "/" << denominator;
    }

    // Static member function to get the count of objects
    static int getCount() {
        return count;
    }
};

int Rational::count = 0;

int main() {
    Rational r1(1, 2); // Using parameterized constructor
    Rational r2 = r1; // Using copy constructor
    Rational r3(3, 4);

    cout << "Total objects created: " << Rational::getCount() << endl;

    cout << "Rational Numbers:" << endl;
    r1.display();
    cout << " * ";
    r3.display();
    cout << " = ";
    (r1 * r3).display();
    cout << endl;

    r1.display();
    cout << " / ";
    r3.display();
    cout << " = ";
    (r1 / r3).display();
    cout << endl;

    return 0;
}
