/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int count; // Static member to keep count of objects

public:
    // Parameterized constructor
    Rational(int num, int den) : numerator(num), denominator(den) {
        count++; // Increment object count
    }

    // Copy constructor
    Rational(const Rational& other) : numerator(other.numerator), denominator(other.denominator) {
        count++; // Increment object count
    }

    // Function to take user input for numerator and denominator
    void input() {
        std::cout << "Enter the numerator: ";
        std::cin >> numerator;
        
        do {
            std::cout << "Enter the denominator (must be nonzero): ";
            std::cin >> denominator;
        } while (denominator == 0); // Validate that denominator is nonzero
    }

    // Function to multiply two rational numbers
    Rational operator*(const Rational& other) {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return Rational(num, den);
    }

    // Function to divide two rational numbers
    Rational operator/(const Rational& other) {
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return Rational(num, den);
    }

    // Static member function to get the count of objects
    static int getCount() {
        return count;
    }

    // Function to display the rational number
    void display() {
        std::cout << numerator << "/" << denominator;
    }
};

int Rational::count = 0; // Initialize static member count

int main() {
    Rational r1(3, 4); // Create an object using the parameterized constructor
    Rational r2 = r1; // Create another object using the copy constructor
    
    r1.display();
    std::cout << " * ";
    r2.display();
    std::cout << " = ";
    (r1 * r2).display();
    std::cout << std::endl;

    r1.display();
    std::cout << " / ";
    r2.display();
    std::cout << " = ";
    (r1 / r2).display();
    std::cout << std::endl;

    std::cout << "Total objects created: " << Rational::getCount() << std::endl;

    return 0;
}