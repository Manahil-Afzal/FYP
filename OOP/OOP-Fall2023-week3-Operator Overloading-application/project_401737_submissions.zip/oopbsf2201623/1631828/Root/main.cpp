/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/
#include <iostream>

class Rational {
private:
    int numerator;
    int denominator;
    static int objectCount;

public:
    Rational(int num = 0, int denom = 1) {
        if (denom != 0) {
            numerator = num;
            denominator = denom;
            objectCount++;
        } else {
            std::cout << "Error: Denominator cannot be zero." << std::endl;
            numerator = 0;
            denominator = 1;
        }
    }

    // Copy constructor
    Rational(const Rational& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        objectCount++;
    }

    // Input method
    void input() {
        std::cout << "Enter the numerator: ";
        std::cin >> numerator;
        std::cout << "Enter the denominator: ";
        std::cin >> denominator;

        if (denominator == 0) {
            std::cout << "Error: Denominator cannot be zero. Setting denominator to 1." << std::endl;
            denominator = 1;
        }
    }

    // Static member to count objects
    static int getObjectCount() {
        return objectCount;
    }

    // Operator overloading for multiplication
    Rational operator*(const Rational& other) {
        int num = numerator * other.numerator;
        int denom = denominator * other.denominator;
        return Rational(num, denom);
    }

    // Operator overloading for division
    Rational operator/(const Rational& other) {
        if (other.numerator != 0) {
            int num = numerator * other.denominator;
            int denom = denominator * other.numerator;
            return Rational(num, denom);
        } else {
            std::cout << "Error: Division by zero." << std::endl;
            return Rational();
        }
    }

    // Display method
    void display() {
        std::cout << numerator << "/" << denominator << std::endl;
    }
};

int Rational::objectCount = 0;

int main() {
    Rational r1, r2;

    // Input values for r1 and r2
    std::cout << "Enter values for the first rational number (r1):" << std::endl;
    r1.input();

    std::cout << "Enter values for the second rational number (r2):" << std::endl;
    r2.input();

    std::cout << "Number of objects created: " << Rational::getObjectCount() << std::endl;

    // Perform multiplication and division
    Rational result_mult = r1 * r2;
    Rational result_div = r1 / r2;

    std::cout << "Multiplication result (r1 * r2): ";
    result_mult.display();

    std::cout << "Division result (r1 / r2): ";
    result_div.display();

    return 0;
}