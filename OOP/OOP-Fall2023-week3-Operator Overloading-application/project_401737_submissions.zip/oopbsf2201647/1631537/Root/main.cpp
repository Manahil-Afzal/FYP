/*Write a program that implements a class to multiply and divide two rational numbers using operator overloading. 
The class should have two data members for denominator and numerator values. It should also have a parameterized constructor to initialize the 
values of one object and a copy constructor to initialize second object through previously created object. The class should have a method to take 
inputs of denominator and numerator from user. It should also contain a static member to keep the count of the objects of rational numbers. 
Display the output after performing multiplication and division. Implement check to ensure that the value of denominator should not be entered as zero.*/

#include <iostream>

using namespace std;

class RationalNumber {
private:
    int numerator;
    int denominator;
    static int count;

public:
    // Parameterized constructor with default values
    RationalNumber(int num = 0, int den = 1) {
        numerator = num;
        if (den != 0) {
            denominator = den;
        } else {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
        count++;
    }

    // Copy constructor
    RationalNumber(const RationalNumber& other) {
        numerator = other.numerator;
        denominator = other.denominator;
        count++;
    }

    // Method to take inputs from the user
    void getInput() {
        cout << "Enter numerator: ";
        cin >> numerator;

        cout << "Enter denominator (non-zero): ";
        cin >> denominator;

        if (denominator == 0) {
            cout << "Error: Denominator cannot be zero. Setting denominator to 1." << endl;
            denominator = 1;
        }
    }

    // Function to display the rational number
    void display() const {
        cout << numerator << "/" << denominator;
    }

    // Operator overloading for multiplication
    RationalNumber operator*(const RationalNumber& other) const {
        int num = numerator * other.numerator;
        int den = denominator * other.denominator;
        return RationalNumber(num, den);
    }

    // Operator overloading for division
    RationalNumber operator/(const RationalNumber& other) const {
        int num = numerator * other.denominator;
        int den = denominator * other.numerator;
        return RationalNumber(num, den);
    }

    // Static member function to get the count of objects
    static int getCount() {
        return count;
    }
};

int RationalNumber::count = 0;

int main() {
    RationalNumber num1(2, 3);
    RationalNumber num2;

    cout << "Enter the second rational number:" << endl;
    num2.getInput();

    RationalNumber product = num1 * num2;
    RationalNumber quotient = num1 / num2;

    cout << "Multiplication result: ";
    product.display();
    cout << "\n";

    cout << "Division result: ";
    quotient.display();
    cout << "\n";

    cout << "Total rational numbers created: " << RationalNumber::getCount() << "\n";

    return 0;
}