/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/
#include <iostream>
using namespace std;

class book
{ 
private:
     string title;
     float price ;
     
public:
void getdata()
{
   cout<<"Enter a Title:";
   cin>>title;
   cout<<"Enter a Price:";
   cin>>price;
}
void putdata ()
   {
   cout<<"Title:"<<title<< "\n";
   cout<<"Price:"<<price<< "\n";
   }
};
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata();
book2.putdata();
book3.putdata();
return 0;
}

