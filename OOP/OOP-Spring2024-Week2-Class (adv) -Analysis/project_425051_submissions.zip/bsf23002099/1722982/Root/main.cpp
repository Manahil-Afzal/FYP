#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
   cin >> title;

    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "Details of the books:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
