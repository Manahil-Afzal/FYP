#include <iostream>
using namespace std;
class book
{
private:
string title;
float price ;
public:
void getdata();
void putdata();
};

int main()
{
book book1;
book1.getdata();
book1.putdata();
book book2;
book2.getdata();
book2.putdata();
book book3;
book3.getdata();
book3.putdata();
return 0;
}
void book :: getdata()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
}
void book :: putdata()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}