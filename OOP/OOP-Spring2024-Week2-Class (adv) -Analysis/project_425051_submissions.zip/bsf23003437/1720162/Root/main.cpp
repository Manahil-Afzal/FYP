#include <iostream>

using namespace std;

class Book {
public:
    void getdata() {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putdata() {
        cout << "Title: " << title << endl;
        cout << "Price: " << price << endl;
    }

private:
    string title;
    float price;
};

int main() {
    Book book1, book2, book3;

    book1.getdata();
    book2.getdata();
    book3.getdata();

    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
