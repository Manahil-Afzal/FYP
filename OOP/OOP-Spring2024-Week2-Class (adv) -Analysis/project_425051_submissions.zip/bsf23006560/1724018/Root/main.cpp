#include <iostream>
using namespace std;

class Book
{
public:
    string title;
    float price;
    
    void getData()
    {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putData()
    {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main()
{
    Book book1, book2, book3;
    
    cout << "Enter data for Book 1:\n";
    book1.getData();

    cout << "Enter data for Book 2:\n";
    book2.getData();

    cout << "Enter data for Book 3:\n";
    book3.getData();

    cout << "\nDisplaying data for all books:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
