/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book
{
private:
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData()
{
    cout << "Title: ";
    getline(cin, title); 
    cout << "Price: ";
    cin >> price;
    cin.ignore(); 
}

void Book::putData()
{
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n\n";
}

int main()
{
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "Displaying information for all books:\n";
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
