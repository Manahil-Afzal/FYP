/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore(); // to clear the newline character from the input buffer
    getline(cin, title); // using getline to read the entire title including spaces
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "\nEnter details for Book 2:\n";
    book2.getData();

    cout << "\nEnter details for Book 3:\n";
    book3.getData();

    cout << "\nDetails of Book 1:\n";
    book1.putData();

    cout << "\nDetails of Book 2:\n";
    book2.putData();

    cout << "\nDetails of Book 3:\n";
    book3.putData();

    return 0;
}
