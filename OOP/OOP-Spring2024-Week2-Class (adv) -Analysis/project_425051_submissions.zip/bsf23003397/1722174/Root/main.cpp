/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class book {
private:
    string title;
    float price;

public:
    void getdata();
    void putdata();
};

void book::getdata() {
    cout << "Title: ";
    cin.ignore(); // Ignore newline character left in the input buffer
    getline(cin, title); // Use getline to allow spaces in the title
    cout << "Price: ";
    cin >> price;
}

void book::putdata() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n\n";
}

int main() {
    book book1, book2, book3;

    cout << "Enter details for book 1:\n";
    book1.getdata();

    cout << "Enter details for book 2:\n";
    book2.getdata();

    cout << "Enter details for book 3:\n";
    book3.getdata();

    cout << "Details of books:\n";
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}