/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string> // Include the string header for using string type
using namespace std;

class Book {
    string title;
    float price;

  public:
    void getData(); // Declaration of getData method
    void putData(); // Declaration of putData method
};

void Book::getData() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    // Getting data for each book
    cout << "Enter data for Book 1:\n";
    book1.getData();

    cout << "Enter data for Book 2:\n";
    book2.getData();

    cout << "Enter data for Book 3:\n";
    book3.getData();

    // Displaying data for each book
    cout << "\nData for Book 1:\n";
    book1.putData();

    cout << "\nData for Book 2:\n";
    book2.putData();

    cout << "\nData for Book 3:\n";
    book3.putData();

    return 0;
}
