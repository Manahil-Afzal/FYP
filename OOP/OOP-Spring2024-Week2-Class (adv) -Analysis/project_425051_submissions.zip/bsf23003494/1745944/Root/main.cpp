/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    // Member function to get data from the user
    void getData() {
        cout << "Enter Title: ";
        cin >> title;
        cout << "Enter Price: ";
        cin >> price;
    }

    // Member function to display book data
    void putData() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "Enter details for Book 2:\n";
    book2.getData();

    cout << "Enter details for Book 3:\n";
    book3.getData();

    cout << "\nBook Details:\n";
    cout << "----------------\n";
    cout << "Book 1:\n";
    book1.putData();
    cout << "\nBook 2:\n";
    book2.putData();
    cout << "\nBook 3:\n";
    book3.putData();

    return 0;
}
