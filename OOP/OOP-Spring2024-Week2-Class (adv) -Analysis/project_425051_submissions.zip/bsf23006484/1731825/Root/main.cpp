/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/


#include <iostream>
using namespace std;
class book
{
string title;
float price ;

public:
void getdata ();

void putdata ();
} ;

void book :: getdata()
{

cout<<"\n"<<"Title :";
cin>>title;

cout<<"Price :";
cin>>price;
 }
 
void book :: putdata()
{
cout<<"Title :"<<title<< "\n";

cout<<"Price :"<<price<<"\n";}
int main ()
{

book book1, book2, book3;
cout<<"Enter data for 1st book";
book1.getdata();
cout<<"Enter data for 2nd book";
book2.getdata();
cout<<"Enter data for 3rd book";
book3.getdata();
cout<<"Output segmant :"<<"\n";
cout<<"Book one :"<<"\n";
book1.putdata() ;
cout<<"Book two :"<<"\n";
book2.putdata() ;
cout<<"Book three :"<<"\n";
book3.putdata() ;
return 0;
}
