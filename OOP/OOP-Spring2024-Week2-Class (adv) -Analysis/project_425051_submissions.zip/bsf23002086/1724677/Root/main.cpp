#include <iostream>
#include <string> 

using namespace std;

class Book // Corrected class name
{
private: // Made members private to encapsulate data
    string title;
    float price;

public: 
    void getdata();
    void putdata();
};

// Corrected member function definitions using ::
void Book::getdata()
{
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putdata()
{
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main()
{
    Book book1, book2, book3;
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
