/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    // Member function to get data
    void getData() {
        cout << "Title: ";
        cin.ignore();  // Ignore any previous newline character
        getline(cin, title);

        cout << "Price: ";
        cin >> price;
    }

    // Member function to display data
    void putData() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "\nEnter details for Book 2:\n";
    book2.getData();

    cout << "\nEnter details for Book 3:\n";
    book3.getData();

    cout << "\nDetails for Book 1:\n";
    book1.putData();

    cout << "\nDetails for Book 2:\n";
    book2.putData();

    cout << "\nDetails for Book 3:\n";
    book3.putData();

    return 0;
}
