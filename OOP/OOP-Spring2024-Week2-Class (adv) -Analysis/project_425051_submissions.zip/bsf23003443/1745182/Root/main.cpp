// /* This program implements a class of Book and displays the data of three books entered by user.
// identify and correct errors*/

// #include <iostream>

// using namespace std;

// class book
// {
// string title;
// float price ;
// void getdata ();
// void getdata ();
// void putdata ();
// } ;
// void books : getdata ()
// {
// cout<<"Title:”;
// cin>>title;
// cout<<"Price:”;
// cin>>price;
 
// }
// void books : putdata ()
// {
// cout<<"Title:"<<title<< "\n";
// cout<<"Price:"<<price<< "\n”;
// int main ()
// {
// books book1, book2, book3;
// book1.getdata();
// book2.getdata();
// book3.getdata();
// book1.putdata() ;
// book2.putdata() ;
// book3.putdata() ;

// return 0;
// }
#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData() {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putData() {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter data for Book 1:" << endl;
    book1.getData();

    cout << "\nEnter data for Book 2:" << endl;
    book2.getData();

    cout << "\nEnter data for Book 3:" << endl;
    book3.getData();

    cout << "\nBook 1 details:" << endl;
    book1.putData();

    cout << "\nBook 2 details:" << endl;
    book2.putData();

    cout << "\nBook 3 details:" << endl;
    book3.putData();

    return 0;
}
