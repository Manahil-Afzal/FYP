#include<iostream>
#include<string>
using namespace std;

class information {
    private: 
        string title;
        float price;
    public: 
       void getData () {
           cout << "Enter the Book Title : " ;
           cin >> title;
           cout << "Enter the Price of Book : ";
           cin >> price;
       }
       
       void putData () {
           cout << "The Title of Book \n" << title << "\nThe Price of Book is\n" << price <<endl;
       }
};

int main () {
    information book1, book2, book3;
    
    book1.getData ();
    book1.putData ();
    book2.getData ();
    book2.putData ();
    book3.getData ();
    book3.putData ();
    return 0;
}