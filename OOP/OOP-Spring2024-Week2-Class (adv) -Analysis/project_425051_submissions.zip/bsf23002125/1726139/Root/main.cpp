#include <iostream>
using namespace std;

class book
{
    private:                            // add private
        string title;                   // add indentation
        float price ;                   // add indentation
    public:                             // add public
        void getdata ();                // remove extra getdata()
        void putdata ();                // add indentation
};

int main ()
{
    book book1, book2, book3;           // correct the class name
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}

void book::getdata()                   // add colon and corrected the class name
{
    cout << "Title: ";                 // Correct the quotation ".
    cin >> title;

    cout << "Price: ";                  // correct the quotation ".
    cin >> price;
};                                      // add semi-colon
void book::putdata(){
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
};