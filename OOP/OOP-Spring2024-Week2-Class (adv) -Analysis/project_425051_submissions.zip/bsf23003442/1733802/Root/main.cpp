/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
string title;
float price ;
public:        //both the methods were kept private 
void getdata ();
void putdata ();
} ;
void book :: getdata ()  //colon was used instead of scope resolution operator 
{
cout<<"Title:";
cin>>title;
cout<<"Price:"; //missing closing " character
cin>>price;
 
}
void book :: putdata ()//colon was used instead of scope resolution operator 
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";}
int main ()
{
book book1, book2, book3; //class name was used incorrectly
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
