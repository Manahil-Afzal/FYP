/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include<iostream>
using namespace std;
class book{
	char title[50];
	float price;
	public:
		void get();
		void display();
		
};
void book::get(){
		cout<<"Enter the name of book "<<endl;
	      cin>>title;
		cout<<"Enter price of book "<<endl;
		cin>>price;
	}
	void book::display(){
		cout<<"Book Name  :: "<<title<<endl;
		cout<<"Book Price :: "<<price<<endl;
	}
int main(){
	book b1,b2,b3;
	b1.get();
	
	b2.get();
	
	b3.get();
	b1.display();
	b2.display();
	b3.display();
	return 0;
}