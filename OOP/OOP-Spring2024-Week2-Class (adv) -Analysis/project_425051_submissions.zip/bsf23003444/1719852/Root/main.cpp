/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class books // Corrected class name from 'book' to 'books'
{
    string title;
    float price;

public: // Added public access specifier
    void getdata();
    void putdata();
};

void books::getdata() // Corrected function definition syntax
{
    cout << "Title:";
    cin >> title;
    cout << "Price:";
    cin >> price;
}

void books::putdata() // Corrected function definition syntax
{
    cout << "Title:" << title << "\n";
    cout << "Price:" << price << "\n";
}

int main()
{
    books book1, book2, book3;
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}

