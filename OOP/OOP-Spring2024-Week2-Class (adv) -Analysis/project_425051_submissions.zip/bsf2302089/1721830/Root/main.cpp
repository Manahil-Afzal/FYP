#include <iostream>
using namespace std;

class Book {
    string title;
    float price;

public:
    void getData();
    void putData();
};

void Book::getData() {
    cout << "Title: ";
    cin.ignore(); 
    getline(cin, title); 
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getData();

    cout << "\nEnter details for Book 2:\n";
    book2.getData();

    cout << "\nEnter details for Book 3:\n";
    book3.getData();

    cout << "\nDetails of Book 1:\n";
    book1.putData();

    cout << "\nDetails of Book 2:\n";
    book2.putData();

    cout << "\nDetails of Book 3:\n";
    book3.putData();

    return 0;
}
