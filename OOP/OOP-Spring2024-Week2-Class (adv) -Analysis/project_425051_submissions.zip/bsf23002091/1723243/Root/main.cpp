// /* This program implements a class of Book and displays the data of three books entered by user.
// identify and correct errors*/

// #include <iostream>

// using namespace std;

// class book
// {
// string title;
// float price ;
// void getdata ();
// void getdata ();
// void putdata ();
// } ;
// void books : getdata ()
// {
// cout<<"Title:”;
// cin>>title;
// cout<<"Price:”;
// cin>>price;
 
// }
// void books : putdata ()
// {
// cout<<"Title:"<<title<< "\n";
// cout<<"Price:"<<price<< "\n”;
// int main ()
// {
// books book1, book2, book3;
// book1.getdata();
// book2.getdata();
// book3.getdata();
// book1.putdata() ;
// book2.putdata() ;
// book3.putdata() ;

// return 0;
// }
#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getData();  // Corrected function declaration
    void putData();  // Corrected function declaration
};

void Book::getData() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void Book::putData() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    Book book1, book2, book3;

    book1.getData();
    book2.getData();
    book3.getData();

    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}

