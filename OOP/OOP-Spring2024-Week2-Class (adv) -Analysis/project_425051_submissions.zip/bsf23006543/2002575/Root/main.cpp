#include <iostream>
using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getdata() {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putdata() const {
        cout << "Title: " << title << "\n";
        cout << "Price: " << price << "\n";
    }
};

int main() {
    Book book1, book2, book3;

    cout << "Enter details for Book 1:\n";
    book1.getdata();

    cout << "Enter details for Book 2:\n";
    book2.getdata();

    cout << "Enter details for Book 3:\n";
    book3.getdata();

    cout << "\nDisplaying Book Information:\n";
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
