/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class book {
private:
    string title;
    float price;

public:
    void getdata();
    void putdata();
};

void book::getdata() {
    cout << "Title: ";
    cin >> title;
    cout << "Price: ";
    cin >> price;
}

void book::putdata() {
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main() {
    book book1, book2, book3;
    cout << "Enter details for book1:\n";
    book1.getdata();
    cout << "Enter details for book2:\n";
    book2.getdata();
    cout << "Enter details for book3:\n";
    book3.getdata();

    cout << "\nDetails of book1:\n";
    book1.putdata();
    cout << "\nDetails of book2:\n";
    book2.putdata();
    cout << "\nDetails of book3:\n";
    book3.putdata();

    return 0;
}

