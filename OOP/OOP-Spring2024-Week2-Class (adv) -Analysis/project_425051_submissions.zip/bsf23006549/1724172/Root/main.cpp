/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class book { 
		string title;
		float price ;
	public: // Added "public" access modifier to access the operations outside the class.
		void getdata ();// Removed the identical operation.
		void putdata ();
} ;
void book::getdata () { //Corrected the scope resolution operator & removed s from books.
	cout<<"Title:"; // Corrected the double quotes
	cin>>title;
	cout<<"Price:"; // Corrected the double quotes
	cin>>price;

}
void book::putdata () { //Corrected the scope resolution operator & removed s from books.
	cout<<"Title:"<<title<< "\n";
	cout<<"Price:"<<price<< "\n"; //corrected double quotes
} //Added terminating braces
	int main () {
		book book1, book2, book3; //Removed s from books as class is delared as book.
		book1.getdata();
		book2.getdata();
		book3.getdata();
		book1.putdata() ;
		book2.putdata() ;
		book3.putdata() ;

		return 0;
	}
