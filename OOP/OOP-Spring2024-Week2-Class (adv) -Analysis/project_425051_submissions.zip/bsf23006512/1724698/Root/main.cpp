/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors

#include <iostream>

using namespace std;

class book
{
string title;
float price ;
void getdata ();
void getdata ();
void putdata ();
} ;
void books : getdata ()
{
cout<<"Title:”;
cin>>title;
cout<<"Price:”;
cin>>price;
 
}
void books : putdata ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n”;
int main ()
{
books book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}*/

#include<iostream>
using namespace std;
class book
{
	private:
		string title;
		float price;
	public:
	    void input();
		void display();	
};
void book::input()
{
	cout<<"\nTitle: ";
	cin>>title;
	cout<<"Price: ";
	cin>>price;
}
void book::display()
{
	cout<<"\nTitle: "<<title;
	cout<<"\nprice: "<<price;
}
int main()
{
	book book1,book2,book3;
	cout<<"Enter data for books:- \n";
	book1.input();
	book2.input();
	book3.input();
	cout<<"Entered Data Is:- \n";
	book1.display();
	book2.display();
	book3.display();
	
}