/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string>

using namespace std;

class Book {
private:
    string title;
    float price;

public:
    void getdata() {
        cout << "Title: ";
        cin >> title;
        cout << "Price: ";
        cin >> price;
    }

    void putdata() {
        cout << "Title: " << title << endl;
        cout << "Price: " << price << endl;
    }
};

int main() {
    Book book1, book2, book3;
    cout << "Enter details for Book 1:" << endl;
    book1.getdata();
    cout << "Enter details for Book 2:" << endl;
    book2.getdata();
    cout << "Enter details for Book 3:" << endl;
    book3.getdata();

    cout << "\nBook Details:" << endl;
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}

