/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;

class book{
    public:
    string title;
    float price ;
    void putdata();
    void getdata();
};
void book::putdata (){
    cout<<"Title:";
    cin>>title;
    cout<<"Price:";
    cin>>price;
 
}
void book::getdata (){
    cout<<"Title:"<<title<< "\n";
    cout<<"Price:"<<price<< "\n";
}

int main (){
    book book1, book2, book3;
    book1.putdata();
    book2.putdata();
    book3.putdata();
    book1.getdata();
    book2.getdata();
    book3.getdata();

return 0;
}
