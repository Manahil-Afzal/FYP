/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
string title;
float price ;
	public: // functions were private
void getdata ();
//void getdata (); getdata is overloaded
void putdata ();
} ;
void book :: getdata () //: instead of :: , wrong class name 
{
cout<<"Title: "; //”instead of "
cin>>title;
cout<<"Price:"; //”instead of "
cin>>price;
 
}
void book :: putdata ()	//: instead of :: , wrong class name
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";	//”instead of "
} //} was missing
int main ()
{
book book1, book2, book3;	//wrong class name
book1.getdata();
book2.getdata();
book3.getdata();
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
