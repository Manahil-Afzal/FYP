/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

using namespace std;

class book
{
string title;
float price ;
public:
void getdata ();
void putdata ();
} ;
void book :: getdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
 
}
void book :: putdata ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n"; 
}
int main ()
{
book book1, book2, book3;
cout<<"enter data for book1:\n";
book1.getdata();
cout<<"enter data for book2:\n";
book2.getdata();
cout<<"enter data for book3:\n";
book3.getdata();
cout<<"\ndisplaying book data:\n";
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;

return 0;
}
