#include <iostream>
using namespace std;
class book
{
	private:
string title;
float price ;
public:
void getdata ();
void putdata ();
} ;
void book::getdata ()
{

cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
void book::putdata ()
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
 
}
int main ()
{
book book1, book2, book3;
book1.putdata() ;
book2.putdata() ;
book3.putdata() ;
book1.getdata();
book2.getdata();
book3.getdata();

return 0;
}
