/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string> // Include the <string> header file
using namespace std;

class Book //corrected class name
{
private: // Added private access specifier
    string title;
    float price;

public: // Added public access specifier
    void getData(); // Corrected function declaration
    void putData(); // Corrected function declaration
};

void Book::getData() // Correct function definition
{
    cout << "Title: ";
    cin.ignore(); // added .ignore function to ignore newline character
    getline(cin, title); // Use getline to input entire line including spaces
    cout << "Price: ";
    cin >> price;
}

void Book::putData() // Correct function definition
{
    cout << "Title: " << title << "\n";
    cout << "Price: " << price << "\n";
}

int main()
{
    Book book1, book2, book3;
    book1.getData();
    book2.getData();
    book3.getData();
    book1.putData();
    book2.putData();
    book3.putData();

    return 0;
}
