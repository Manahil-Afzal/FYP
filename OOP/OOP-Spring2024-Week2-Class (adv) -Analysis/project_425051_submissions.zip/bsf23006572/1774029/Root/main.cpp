// /* This program implements a class of Book and displays the data of three books entered by user.
// identify and correct errors*/

// #include <iostream>

// using namespace std;

// class book
// {
// string title;
// float price ;
// void getdata ();
// void getdata ();
// void putdata ();
// } ;
// void books : getdata ()
// {
// cout<<"Title:”;
// cin>>title;
// cout<<"Price:”;
// cin>>price;
 
// }
// void books : putdata ()
// {
// cout<<"Title:"<<title<< "\n";
// cout<<"Price:"<<price<< "\n”;
// int main ()
// {
// books book1, book2, book3;
// book1.getdata();
// book2.getdata();
// book3.getdata();
// book1.putdata() ;
// book2.putdata() ;
// book3.putdata() ;

// return 0;
// }

// These are the following problems in the code:
// First the format spacifiers are missing 
// Second the scope operator is not correct 
// Third the closing prentheses are missing 
// Forth the class name outside the funtion is not same 
// Fifth the string header file is missing 
// Sixth the getdata must be declared only once
/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
#include <string>

using namespace std;

class book
{
private:
    string title;
    float price;

public:
    void getdata();
    // void getdata();
    void putdata();
};
void book ::getdata()
{
    cout << "Title:";
    cin >>title;
    cout << "Price:";
    cin >>price;
}
void book ::putdata()
{
    cout << "Title:" << title << "\n";
    cout << "Price:" << price << "\n";
}
int main()
{
    book book1, book2, book3;
    book1.getdata();
    book2.getdata();
    book3.getdata();
    book1.putdata();
    book2.putdata();
    book3.putdata();

    return 0;
}
