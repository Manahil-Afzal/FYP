/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>

// using namespace std;

// class book
// {
// string title;
// float price ;
// void getdata ();
// void getdata ();
// void putdata ();
// } ;
// void books : getdata ()
// {
// cout<<"Title:”;
// cin>>title;
// cout<<"Price:”;
// cin>>price;
 
// }
// void books : putdata ()
// {
// cout<<"Title:"<<title<< "\n";
// cout<<"Price:"<<price<< "\n”;
// int main ()
// {
// books book1, book2, book3;
// book1.getdata();
// book2.getdata();
// book3.getdata();
// book1.putdata() ;
// book2.putdata() ;
// book3.putdata() ;

// return 0;
// }
// These are the following problems in the program :
// First the format specifiers are missing data member must be private and member functions must be public
// Second There is no need to declare the getdata twice 
// Third access formate specifier is incorrect in both conditons of functions outside the classes 
// Forth The closing prentheses are missing in some cases 
// Fifth is not a big but we can correct it that the name of the putdata must be displaydata
// Sixth the class name in function outsie is not correct 
// Seventh the class name is wrong in the main funciotn 
// Solved Program 
#include <iostream>

using namespace std;

class book
{
    private:
string title;
float price ;
public:
void getdata ();
void displaydata();
} ;
void book :: getdata ()
{
cout<<"Title:"<<endl;
cin>>title;
cout<<"Price:"<<endl;
cin>>price;
 
}
void book :: displaydata ()
{
cout<<"Title:"<<title<< "\n"<<endl;
cout<<"Price:"<<price<< "\n"<<endl;
}
int main ()
{
book book1, book2, book3;
book1.getdata();
book2.getdata();
book3.getdata();
book1.displaydata();
book2.displaydata();
book3.displaydata();
return 0;
}