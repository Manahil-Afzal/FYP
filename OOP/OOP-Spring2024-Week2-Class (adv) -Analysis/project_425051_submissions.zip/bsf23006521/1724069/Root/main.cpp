/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include <iostream>
using namespace std;
class book
{
string title;
float price ;
//access specifier should be public so that methods can be accessed in main.
public:
void getdata ();
// void getdata (); getdata is decleared two time which will generate an error so, we should remove it.
void putdata ();
} ;
// void books : getdata ()  this line have a syntax error, which can be corrected in such a way
void book :: getdata()
{
//cout<<"Title:”; double quotes are not closed properly , they should be closed as 
cout<<"Title :";
cin>>title;
//cout<<"Price:”; similar mistake as above
cout<<"Price :";
cin>>price;
 }
//void books : putdata ()   this line will generate syntax error .to correct it we should write 
void book :: putdata()
{
cout<<"Title :"<<title<< "\n";
//cout<<"Price:"<<price<< "\n”;  double quotes are not closed properly , they should be closed as 
cout<<"Price :"<<price<<"\n";}
int main ()
{
//books book1, book2, book3;  books should be replaced by book as the name of class is book.
book book1, book2, book3;
/* although there is not any type of error but to make it easy for users to understand it,
we should separate all the segments to describe its working properly*/
cout<<"Enter data for 1st book";
book1.getdata();
cout<<"Enter data for 2nd book";
book2.getdata();
cout<<"Enter data for 3rd book";
book3.getdata();
cout<<"Output segmant :"<<"\n";
cout<<"Book one :"<<"\n";
book1.putdata() ;
cout<<"Book two :"<<"\n";
book2.putdata() ;
cout<<"Book three :"<<"\n";
book3.putdata() ;
return 0;
}