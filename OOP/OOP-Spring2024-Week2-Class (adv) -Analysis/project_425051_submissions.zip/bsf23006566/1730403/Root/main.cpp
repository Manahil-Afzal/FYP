/* This program implements a class of Book and displays the data of three books entered by user.
identify and correct errors*/

#include<iostream>
using namespace std;
class book{
	string title;
	int price;
	public:
		void in(){
			cout<<"Enter the name of book"<<endl;
			cin>>title;
	      cout<<"Enter the price of book"<<endl;
	      cin>>price;
	      
		}
		void display(){
			cout<<"Name "<<title<<endl;
			cout<<"Price "<<price<<endl;
		}
};
int main(){
	book b1,b2,b3;
	b1.in();
	b2.in();
	b3.in();
	b1.display();
	b2.display();
	b3.display();
	return 0;
}