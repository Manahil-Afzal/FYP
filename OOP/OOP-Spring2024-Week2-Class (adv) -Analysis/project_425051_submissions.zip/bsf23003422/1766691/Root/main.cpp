#include <iostream>
using namespace std;

class Book //Class name should start with capital letters
{
	public:
      string title;
      float price ;

void getData()   //Function names should be LowerCase
{
cout<<"Title:";
cin>>title;
cout<<"Price:";
cin>>price;
 
}
void putData ()
{
cout<<"Title:"<<title<< "\n";
cout<<"Price:"<<price<< "\n";
}
};
int main ()
{
Book book1, book2, book3; //Create Book objects
book1.getData();
book2.getData();
book3.getData();

book1.putData() ;
book2.putData() ;
book3.putData() ;

return 0;
}