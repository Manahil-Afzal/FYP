// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)
#include <iostream>
using namespace std;
class Employee
{
private:
    int Id;
    char Name[25];
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin >> Name;

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData()
    {
        cout << Id << "\t" << Name << "\t" << Age << "\t" << Salary << endl;
    }
};

int main() 
{
    Employee E[5];

    for (int i = 0; i < 5; i++) 
    {
        cout << "\nEnter details of Employee " << i + 1 << endl;
        E[i].GetData(); 
    }

    cout << "\nDetails of Employees" << endl;
    for (int i = 0; i < 5; i++)
    {
        E[i].PutData(); 
    }

    return 0;
}
