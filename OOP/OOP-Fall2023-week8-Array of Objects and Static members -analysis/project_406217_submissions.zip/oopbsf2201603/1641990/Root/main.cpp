// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

     #include <iostream>  // You need to include the iostream header.

class Employee {
    int Id;
    char name[25];
    int Age;
    long Salary;

public:
    void GetData() {
        std::cout << "\nEnter Employee Id: ";
        std::cin >> Id;

        std::cout << "\nEnter Employee Name: ";
        std::cin >> name;

        std::cout << "\nEnter Employee Age: ";
        std::cin >> Age;

        std::cout << "\nEnter Employee Salary: ";
        std::cin >> Salary;
    }

    void PutData() {
        std::cout << "\n" << Id << "\t" << name << "\t" << Age << "\t" << Salary;
    }
};

int main() {  // The main function should return int.
    Employee E[5];

    for (int i = 0; i < 5; i++) {  // Declare 'i' and fix the loop condition.
        std::cout << "\nEnter details of Employee " << i + 1;
        E[i].GetData();  // Use the dot operator to call member functions.
    }

    std::cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) {  // Declare 'i' and fix the loop condition.
        E[i].PutData();  // Use the dot operator to call member functions.
    }

    return 0;
}

