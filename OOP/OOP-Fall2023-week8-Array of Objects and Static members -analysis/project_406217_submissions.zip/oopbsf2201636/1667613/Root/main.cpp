#include <iostream>

class Employee
{
    int Id;
    char name[25];
    int Age;
    long Salary;

public:
    void GetData()
    {
        std::cout << "\n\tEnter Employee Id : ";
        std::cin >> Id;

        std::cout << "\n\tEnter Employee Name : ";
        std::cin >> name;

        std::cout << "\n\tEnter Employee Age : ";
        std::cin >> Age;

        std::cout << "\n\tEnter Employee Salary : ";
        std::cin >> Salary;
    }

    void PutData()
    {
        std::cout << "\n" << Id << "\t" << name << "\t" << Age << "\t" << Salary;
    }
};

int main()
{
    Employee E[5];

    for (int i = 0; i < 5; i++)
    {
        std::cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData();
    }

    std::cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++)
        E[i].PutData();

    return 0;
}
