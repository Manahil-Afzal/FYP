#include <iostream>
using namespace std;

class Employee {
private:
    int Id;
    char Name[25];
    int Age;
    long Salary;

public:
    void GetData() {
        cout << "\n\tEnter Employee Id: ";
        cin >> Id;

        cout << "\n\tEnter Employee Name: ";
        cin.ignore(); // Clear the newline character from the previous input
        cin.getline(Name, 25);

        cout << "\n\tEnter Employee Age: ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary: ";
        cin >> Salary;
    }

    void PutData() {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() {
    Employee E[5];
    int i; // Declare 'i' to use as a loop variable

    for (i = 0; i < 5; i++) { // Changed loop conditions: loop from 0 to 4
        cout << "\nEnter details of Employee " << i + 1;
        E[i].GetData(); // Use the array index to call the GetData method
    }

    cout << "\nDetails of Employees:";
    for (i = 0; i < 5; i++) { // Changed loop conditions: loop from 0 to 4
        E[i].PutData(); // Use the array index to call the PutData method
    }

    return 0;
}
