// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

     #include <iostream>
using namespace std;

class Employee {
private: // You should specify the access level for your class members
    int Id;
    char Name[25]; // Fixed the variable name 'Name'
    int Age;
    long Salary;

public:
    void GetData() {
        cout << "\n\tEnter Employee Id : ";
        cin >> Id;

        cout << "\n\tEnter Employee Name : ";
        cin >> Name;

        cout << "\n\tEnter Employee Age : ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary : ";
        cin >> Salary;
    }

    void PutData() {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() { // Use int instead of void for the main function
    Employee E[5];

    for (int i = 0; i < 5; i++) { // Fixed the loop condition
        cout << "\nEnter details of Employee " << i + 1;
        E[i].GetData(); // Corrected the function call
    }

    cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) { // Fixed the loop condition
        E[i].PutData(); // Corrected the function call
    }

    return 0; // Added a return statement for the main function
}
