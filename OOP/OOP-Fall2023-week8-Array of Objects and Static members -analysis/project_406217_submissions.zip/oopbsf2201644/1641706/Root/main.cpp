// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

      #include <iostream>
using namespace std; // You need to include this to use cout and cin

class Employee
{
    int Id;
    char Name[25]; // You had a capital N, it should be a lowercase n
    int Age;
    long Salary;

public:
    void GetData()
    {
        cout << "\n\tEnter Employee Id: ";
        cin >> Id;

        cout << "\n\tEnter Employee Name: ";
        cin >> Name;

        cout << "\n\tEnter Employee Age: ";
        cin >> Age;

        cout << "\n\tEnter Employee Salary: ";
        cin >> Salary;
    }

    void PutData()
    {
        cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() // Use int main() instead of void main()
{
    Employee E[5];

    for (int i = 0; i < 5; i++) // Fix the loop condition
    {
        cout << "\nEnter details of Employee " << i + 1;
        E[i].GetData(); // Use dot operator to call member functions
    }

    cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) // Fix the loop condition
    {
        E[i].PutData(); // Use dot operator to call member functions
    }

    return 0;
}
