// This program creates a user defined type Employee. It takes and displays data of 5 employees. (correct errors)

#include <iostream>
using namespace std;

class Employee {
    int Id;
    char Name[25];
    int Age;
    long Salary;

public:
    void GetData() {
        std::cout << "\n\tEnter Employee Id : ";
        std::cin >> Id;

        std::cout << "\n\tEnter Employee Name : ";
        std::cin >> Name;

        std::cout << "\n\tEnter Employee Age : ";
        std::cin >> Age;

        std::cout << "\n\tEnter Employee Salary : ";
        std::cin >> Salary;
    }

    void PutData() {
        std::cout << "\n" << Id << "\t" << Name << "\t" << Age << "\t" << Salary;
    }
};

int main() { // Use 'int main()' instead of 'void main()'

    Employee E[5];

    for (int i = 0; i < 5; i++) {
        std::cout << "\nEnter details of " << i + 1 << " Employee";
        E[i].GetData();
    }
    
    std::cout << "\nDetails of Employees";
    for (int i = 0; i < 5; i++) {
        E[i].PutData();
    }
    return 0;
}