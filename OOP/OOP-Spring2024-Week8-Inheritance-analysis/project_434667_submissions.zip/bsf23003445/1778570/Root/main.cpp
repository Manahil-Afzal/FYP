#include <iostream>
#include <string> // Added for string usage
using namespace std;

class Person {
private:
    string subject;

public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
    
    string getsubject() { // Accessor function to retrieve subject
        return subject;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << getsubject() << endl; // Accessing subject using accessor
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Corrected quotes
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function name
    teacher.display();

    return 0;
}