#include <iostream>
using namespace std;

class Person
{
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }

    string getSubject() const
    {
        return subject;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << getSubject() << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;

    cout << "Enter subject’s name: ";
    cin >> subjectname;

    teacher.setsubject(subjectname);
    teacher.display();

    return 0;
}
