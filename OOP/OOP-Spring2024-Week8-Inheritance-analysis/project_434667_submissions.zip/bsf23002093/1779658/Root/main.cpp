#include <iostream>
using namespace std;

class Person {
protected: // "subject" should be protected or public for access in derived classes
    string subject;
    
public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl; // Added "Subject: " for clarity
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Replaced ” with "
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function name from setname to setsubject
    teacher.display();

    return 0;
}
