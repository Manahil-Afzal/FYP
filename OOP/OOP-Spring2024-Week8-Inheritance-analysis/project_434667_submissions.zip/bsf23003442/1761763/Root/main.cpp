/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    protected: //access specifier was not decalred
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject:" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name";
     cin>>subjectname;
     teacher.setsubject(subjectname); //setter name was not used correctly
     teacher.display();

     return 0;
}
