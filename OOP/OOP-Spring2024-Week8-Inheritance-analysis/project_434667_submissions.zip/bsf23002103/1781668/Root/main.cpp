/* identify and correct errors. Also comment the identified error*/
#include<iostream>
using namespace std;

class Person {
protected:
    string subject;

public:
    void setSubject(string subjectName) {
        subject = subjectName;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectName;
    
    cout << "Enter subject's name: ";
    cin >> subjectName;
    
    teacher.setSubject(subjectName);
    teacher.display();

    return 0;
}
