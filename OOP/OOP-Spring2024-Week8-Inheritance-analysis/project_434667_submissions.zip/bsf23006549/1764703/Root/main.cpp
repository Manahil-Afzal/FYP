/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
	protected: //Changed the accessibility of subject to protected so it can be inherited to MathsTeacher
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject " << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject's name "; // Corrected the double quotes
     cin>>subjectname;
     teacher.setsubject(subjectname); //Changed the setname() to setsubject()
     teacher.display();

     return 0;
}
