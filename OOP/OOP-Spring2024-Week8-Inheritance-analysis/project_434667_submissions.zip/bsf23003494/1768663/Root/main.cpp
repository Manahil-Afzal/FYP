/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{

public:
	string subject; // Added access specifier 'private'

    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Added space after "Subject"
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Corrected quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function name
    teacher.display();

    return 0;
}
