#include <iostream>
using namespace std;

class Person
{
protected: // changed from private to protected to allow access in derived class
    string subject;
public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // added colon after "Subject"
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // fixed quote and added colon
    cin >> subjectname;
    teacher.setsubject(subjectname); // corrected method name
    teacher.display();

    return 0;
}