/* identify and correct errors. Also comment the identified error*/


#include <iostream>
using namespace std;

class Person
{
    protected: // private access was set for these data members so derived class wasn't able to access them so changed to protected
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "\n Subject  :" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject name  :"; // ’’ were used instead of " "
     cin>>subjectname;
     teacher.setsubject(subjectname); //setsubject was defined rather than set name
     teacher.display();

     return 0;
}
