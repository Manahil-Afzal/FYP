 #include <iostream>
using namespace std;

class Person {
private:
    string subject;

public:
    string getSubject() {
        return subject;
    }

    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
         cout << "Subject: " << getSubject() << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;

    cout << "Enter subject's name: ";
    cin >> subjectname;
    teacher.setsubject(subjectname);
    teacher.display();

    return 0;
}
