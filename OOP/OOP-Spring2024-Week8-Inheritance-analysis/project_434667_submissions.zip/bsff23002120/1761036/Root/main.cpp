/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected: // Change access level to protected
    string subject; // Changed from private to protected
    
public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Added "Subject: "
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Replaced ” with "
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function name
    teacher.display();

    return 0;
}
