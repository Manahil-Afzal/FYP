#include <iostream>
using namespace std;

class Person {
protected:
    string subject; // Error: Access specifier should be "private" since it's not explicitly mentioned.
    
public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl; // Error: "subject" is a private member of class Person, so it's inaccessible here.
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Error: Incorrect quotes used.
    cin >> subjectname;
    teacher.setsubject(subjectname); // Error: The function name is setsubject, not setname.
    teacher.display();

    return 0;
}
