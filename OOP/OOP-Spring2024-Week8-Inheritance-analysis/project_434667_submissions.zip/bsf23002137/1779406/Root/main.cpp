/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected: // used protected to allow derived classes to access it
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject= " << subject << endl; // "Subject=" for clarity
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // ” ” Replaced  with ""
    cin >> subjectname;
    teacher.setsubject(subjectname); // function name from setname to setsubject
    teacher.display();

    return 0;
}

