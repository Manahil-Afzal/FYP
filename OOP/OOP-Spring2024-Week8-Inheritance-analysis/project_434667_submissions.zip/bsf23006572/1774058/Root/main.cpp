// /* identify and correct errors. Also comment the identified error*/
// #include <iostream>
// using namespace std;

// class Person
// {
//   string subject;
   
//      public:
    
//     void setsubject(string subjectname1)
//     {
//     subject= subjectname1;
//     }
        
// };

// class MathsTeacher : public Person
// {
//     public:
//         void display()
//         {
//              cout << "Subject" << subject << endl;
             
             
//         }
// };


// int main()
// {
//      MathsTeacher teacher;
//      string subjectname;
// 	 cout<<”Enter subject’s name”;
//      cin>>subjectname;
//      teacher.setname(subjectname);
//      teacher.display();

//      return 0;
// }
// These are the following errors in the above program:
// First include string.h header file
// Second call setsubject instead of setname 
// Third make the data member of the person public or protected to get accessed in the inheritanced class
#include <iostream>
#include <string.h>
using namespace std;

class Person
{
protected:
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject = " << subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name = ";
    cin >> subjectname;
    teacher.setsubject(subjectname);
    teacher.display();

    return 0;
}
