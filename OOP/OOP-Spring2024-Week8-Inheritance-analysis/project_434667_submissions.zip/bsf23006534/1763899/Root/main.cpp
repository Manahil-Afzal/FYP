/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected:
    string subject;
    string nameOfTecher;
public:
    void setsubject(string subjectname1, string name)
    {
        nameOfTecher = name;
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Name Of Teacher : " << nameOfTecher << endl;
        cout << "\nSubject  :\t" << subject << endl;
    }
};

int main()
{
    MathsTeacher sub;
    sub.setsubject("Mathematics", "Amna Yaseen");
    sub.display();

    return 0;
}
