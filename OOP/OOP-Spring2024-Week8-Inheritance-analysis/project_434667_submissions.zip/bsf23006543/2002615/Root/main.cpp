#include <iostream>
using namespace std;

class Person
{
protected:
    string subject;  // Changed from private to protected to allow derived classes to access it.
   
public:
    // Setter function to set the subject name
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
    
    // Getter function to access subject (optional if needed)
    string getSubject() {
        return subject;
    }
};

class MathsTeacher : public Person
{
public:
    // Function to display the subject
    void display()
    {
        cout << "Subject: " << subject << endl;  // Now correctly prints the subject
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;

    // Fixed quotation marks for string
    cout << "Enter subject’s name: ";
    cin >> subjectname;

    // Fixed method name to set the subject correctly
    teacher.setsubject(subjectname);

    // Display the subject
    teacher.display();

    return 0;
}
