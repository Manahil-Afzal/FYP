#include <iostream>
using namespace std;

class Person {
    string subject;

public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }

    // Added getter for subject to allow access in derived class
    string getsubject() const {
        return subject;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        // ❌ ERROR: 'subject' is private in base class. Cannot access it directly here.
        // ✅ FIX: Use public getter to access 'subject' from base class
        cout << "Subject: " << getsubject() << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;

    // ❌ ERROR: Wrong quote characters used (smart quotes)
    // ✅ FIX: Use standard double quotes
    cout << "Enter subject’s name: ";

    cin >> subjectname;

    // ❌ ERROR: Method 'setname' does not exist
    // ✅ FIX: Use 'setsubject'
    teacher.setsubject(subjectname);
    teacher.display();

    return 0;
}
