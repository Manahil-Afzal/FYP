/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected: // set the access specifier to protected so it could be accessed from the child class
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject " << subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name"; // Changed quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname);//changed the methods name from setname to setsubject because there is no method named setname.
    teacher.display();

    return 0;
}
