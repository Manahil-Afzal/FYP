/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    //to inherit subject in derived class we have to make it protected
    protected:
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject: " << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
     //inverted commas should be used
	 cout<<"Enter subject’s name:";
     cin>>subjectname;
     //method is setsubject not setname 
     teacher.setsubject(subjectname);
     teacher.display();

     return 0;
}
