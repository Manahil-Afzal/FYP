/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    //Peotected access specifier is used in order to access it in child classes
    protected:
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject : " << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     //Use the teacher object to set value of subject
     teacher.setsubject("Mathematics");
     //No need to get input of subject name as it is not allowed syntax
	 //cout<<”Enter subject’s name”;
     //cin>>subjectname;
     //There is no function using setname
     //teacher.setname(subjectname);
     teacher.display();

     return 0;
}
