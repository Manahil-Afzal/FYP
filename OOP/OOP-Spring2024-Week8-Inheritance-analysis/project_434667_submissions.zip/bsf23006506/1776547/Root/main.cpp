/* identify and correct errors. Also comment the identified error*/
// The setsubject function in the Person class is setting the subject variable, but the display function in the MathsTeacher classis trying to access it as subject.
// we need to make subject variable protected or use a getter function to access it.
// You are using setname instead of setsubject in the main function to set the subject name for the teacher.
// In main,the quotation marks inside cout statement are  incorrect.
// #include <iostream>
// using namespace std;

// class Person
// {
//   string subject;
   
//      public:
    
//     void setsubject(string subjectname1)
//     {
//     subject= subjectname1;
//     }
        
// };

// class MathsTeacher : public Person
// {
//     public:
//         void display()
//         {
//              cout << "Subject" << subject << endl;
             
             
//         }
// };


// int main()
// {
//      MathsTeacher teacher;
//      string subjectname;
// 	 cout<<”Enter subject’s name”;
//      cin>>subjectname;
//      teacher.setname(subjectname);
//      teacher.display();

//      return 0;
// }
// here's the correct code
#include <iostream>
using namespace std;

class Person
{
	protected:
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject<< endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject name";
     cin>>subjectname;
     teacher.setsubject(subjectname);
     teacher.display();

     return 0;
}