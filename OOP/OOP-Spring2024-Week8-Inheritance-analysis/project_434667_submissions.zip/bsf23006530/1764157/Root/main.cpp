/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected: // Error 1: Make 'subject' protected to access it in derived classes
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Error 2: Corrected output statement
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Error 3: Corrected quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Error 4: Corrected function name
    teacher.display();

    return 0;
}

