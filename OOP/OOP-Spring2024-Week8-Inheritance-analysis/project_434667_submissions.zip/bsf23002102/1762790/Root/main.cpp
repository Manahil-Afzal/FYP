/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;
class Person
{
    //subject is private make it protected
    protected:
        string subject;
    public:
    void setsubject(string subjectname)
    {
    subject = subjectname;
    }
};
class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject: " << subject << endl;
        }
};
int main()
{
     MathsTeacher teacher;
     string subjectname;
     // wrong symbol used for cout
cout<<"Enter subject’s name ";
     cin>>subjectname;
     cout << endl;
     cout << "--------------------------------" << endl;
     //wrong function name is used
     teacher.setsubject(subjectname);
     teacher.display();
     return 0;
}