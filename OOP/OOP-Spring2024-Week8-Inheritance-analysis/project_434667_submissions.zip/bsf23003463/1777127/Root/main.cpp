/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person {
protected: // Made subject protected instead of private
    string subject;
public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl; // Corrected the output format
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Corrected the quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected the function name
    teacher.display();

    return 0;
}