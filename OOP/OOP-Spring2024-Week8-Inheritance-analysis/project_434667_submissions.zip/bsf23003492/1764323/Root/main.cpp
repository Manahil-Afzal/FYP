/* identify and correct errors. Also comment the identified error*/
#include <iostream>
#include <string>                                                 // Added to support string data type
using namespace std;
class Person 
{
protected:                                                       // Changed to protected to allow derived classes to access it
    string subject;                                              // Changed private to protected
public:
    void setsubject(string subjectname1)
    {
    subject = subjectname1;
    }
};
class MathsTeacher : public Person 
{
public:
    void display() 
    {
    cout << "Subject: " << subject << endl;
    }
};
int main() 
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Fixed invalid quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Fixed function name typo
    teacher.display();
    return 0;
}