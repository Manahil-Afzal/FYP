#include <iostream>
using namespace std;

class Person
{
	public:
    string subject; // Member variable to represent the subject
   
public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        // Corrected the output statement to display the subject
        cout << "Subject: " << subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Corrected string literals
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function name
    teacher.display();

    return 0;
}
