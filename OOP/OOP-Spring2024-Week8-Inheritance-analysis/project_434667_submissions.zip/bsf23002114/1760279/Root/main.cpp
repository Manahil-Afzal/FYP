/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected:
    string subject; // Changed visibility to protected to allow access in derived class

public:
    void setSubject(string subjectName)
    {
        subject = subjectName;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectName;
    
    cout << "Enter subject's name: ";
    cin >> subjectName;
    
    teacher.setSubject(subjectName); // Corrected function name
    teacher.display();

    return 0;
}
