/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected:
    string Subject;

public:
    void setsubject(string subjectname1)
    {
        Subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << Subject << endl;
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: ";
    cin >> subjectname;
    teacher.setsubject(subjectname);
    teacher.display();

    return 0;
}