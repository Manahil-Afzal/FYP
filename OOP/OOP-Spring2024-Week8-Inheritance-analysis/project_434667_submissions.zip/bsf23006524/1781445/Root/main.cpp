/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person {
    protected: // Change 'private' to 'protected' to allow access in derived classes
        string subject;

    public:
        void setsubject(string subjectname1) {
            subject = subjectname1;
        }
};

class MathsTeacher : public Person {
    public:
        void display() {
            cout << "Subject: " << subject << endl; // Added a space after "Subject"
        }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Replaced ” with "
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected the function name to setsubject
    teacher.display();

    return 0;
}
