/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    protected: // using proetected access specifier
   string subject; 
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject: " << subject << endl; //used exclamation to incarease readability
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name"; //corrected using inverted commas 
     cin>>subjectname;
     teacher.setsubject(subjectname);
     teacher.display();

     return 0;
}
