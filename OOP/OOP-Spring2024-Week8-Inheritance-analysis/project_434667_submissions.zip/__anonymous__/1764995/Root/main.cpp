/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    // data member was declared as by default private
	public:
   string subject;
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject : " << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject's name : ";
     cin>>subjectname;
     //wrong member function name was used
     teacher.setsubject(subjectname);
     teacher.display();

     return 0;
}