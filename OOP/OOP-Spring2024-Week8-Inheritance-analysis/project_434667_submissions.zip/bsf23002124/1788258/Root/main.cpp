#include <iostream>
using namespace std;

class Person {
protected: // Changed from private to protected for inheritance access
    string subject;

public:
    // Constructor to initialize subject
    Person(string subjectname1) : subject(subjectname1) {}

    // Method to set subject
    void setSubject(string subjectname1) {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    // Constructor to call base class constructor
    MathsTeacher(string subjectname1) : Person(subjectname1) {}

    // Method to display subject
    void display() {
        cout << "Subject: " << subject << endl;
    }
};

int main() {
    string subjectname;
    cout << "Enter subject's name: "; // Fixed invalid quotation marks
    cin >> subjectname;

    // Create MathsTeacher object with subject name
    MathsTeacher teacher(subjectname);
    
    // Call display method to show subject
    teacher.display();

    return 0;
}
