/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{   
     public:
    string subject;
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject: " << subject << endl;  // subject from ptivate to public
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject name";              //Comma
     cin>>subjectname;
     teacher.setsubject(subjectname);     //setname to setsubject which is a method in person class
     teacher.display();

     return 0;
}
