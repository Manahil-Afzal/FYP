#include <iostream>
#include <string> // Added the necessary header file

using namespace std;

class Person {
   public: 
   string subject;
    void setsubject(string subjectname1) { // Corrected member function name
        subject = subjectname1;
    }
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl; // Added a label for clarity
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Replaced incorrect quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function call
    teacher.display();

    return 0;
}