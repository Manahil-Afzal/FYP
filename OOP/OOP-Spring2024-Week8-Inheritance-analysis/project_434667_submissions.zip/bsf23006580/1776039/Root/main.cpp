/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person {
    // The data member "subject" must be protected or public so that the deriverd classes can access it.
protected: // Making "subject" protected to allow access by derived classes.
    string subject;
    
public:
    void setsubject(string subjectname1) {
        subject = subjectname1;
    }       
};

class MathsTeacher : public Person {
public:
    void display() {
        cout << "Subject: " << subject << endl;
    }
};

int main() {
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Replaced ” with " .
    cin >> subjectname;
    teacher.setsubject(subjectname); // Fixed the function name to setsubject from setname.
    teacher.display();

    return 0;
}

