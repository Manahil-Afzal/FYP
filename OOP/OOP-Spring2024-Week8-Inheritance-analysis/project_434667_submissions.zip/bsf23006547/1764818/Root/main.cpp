/* identify and correct errors. Also comment the identified error*/
#include <iostream>
#include<string>
using namespace std;
class Person
{
//private:
protected:
   string subject;
public:
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
    string subj()
    {
   	 return subject;
	}
};
class MathsTeacher : public Person
{
    public:
    	void setname(string a)
    	{
    		Person::setsubject(a);
		}
        void display()
        {
             cout << "Subject : " << subject << endl;   
        }
};
int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter Subject's Name : ";
     cin>>subjectname;
     //teacher.setname(subjectname);
     teacher.setsubject(subjectname);
     teacher.display();
     return 0;
}
