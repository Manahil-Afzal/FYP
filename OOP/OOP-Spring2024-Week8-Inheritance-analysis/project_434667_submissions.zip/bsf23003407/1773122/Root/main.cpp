#include <iostream>
#include <string> // Include the <string> header for using string type
using namespace std;

class Person
{
protected: // Changed to protected for inheritance
    string subject; // Changed variable name from "subjectname1" to "subject"

public:
    void setSubject(string subjectName) // Changed function name to follow naming conventions
    {
        subject = subjectName; // Updated variable name
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Added ":" after "Subject" for better readability
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectName; // Changed variable name from "subjectname" to "subjectName"

    cout << "Enter subject's name: "; // Added ":" after "name" for better readability
    cin >> subjectName;
    teacher.setSubject(subjectName); // Changed function name to match the corrected naming
    teacher.display();

    return 0;
}