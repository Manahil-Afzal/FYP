/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
	protected://make it protected
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject :" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject name :";//dont use''
     cin>>subjectname;
     teacher.setsubject(subjectname);//function name setsubject
     teacher.display();

     return 0;
}
