/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person{
   private:                                                  // Add private keyword
    string subject;                                          // Corrected the indentation
   
   public:
    void setSubject(string subjectname1){subject= subjectname1;}       // Correct the name
    string getSubject(){return subject;}                                // Add getter method
};

class MathsTeacher : public Person{
    public:
        void display(){
            cout << "Subject: " << getSubject() << endl;            // Add getSubject method
        }
};

int main(){
    MathsTeacher teacher;                                  // Corrected the indentation
    string subjectName;                                    // Corrected the name method 
	cout<<"Enter subject name: ";                          // Corrected the quotation marks
    cin >> subjectName;                                    // Corrected the name
    teacher.setSubject(subjectName);                        // Corrected the set method name
    teacher.display();

    return 0;
}
