/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected: // Corrected: Change access specifier to protected to make it accessible to derived classes.
    string subject;

public:
    void setSubject(string subjectname1) // Corrected: Changed function name to setSubject for consistency and clarity.
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Corrected: Added a colon after "Subject" for proper formatting.
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Corrected: Replaced incorrect quotation marks with standard double quotes.
    cin >> subjectname;
    teacher.setSubject(subjectname); // Corrected: Changed function name to setSubject for consistency.
    teacher.display();

    return 0;
}
