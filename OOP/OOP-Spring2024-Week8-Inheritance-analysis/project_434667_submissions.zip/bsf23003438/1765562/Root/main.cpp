#include <iostream>
using namespace std;

class Person
{
	protected: //change access specifier
   string subject;
   
     public:
    
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter Subject Name :"; //change curly quotes
     cin>>subjectname;
     teacher.setsubject(subjectname); //correct setname to setsubject
     teacher.display();

     return 0;
}
