/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    public:
   string subject;
   
     public:
    
    void setSubject(string subjectName) // Error: Function name should be setSubject
    {
    subject = subjectName;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject: " <<subject << endl; // Error: Missing space after "Subject:"
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectName; // Error: Variable name should be subjectName
     cout << "Enter subject's name: "; // Error: Incorrect quotation marks used
     cin >> subjectName;
     teacher.setSubject(subjectName); // Error: Function name should be setSubject
     teacher.display();

     return 0;
}



