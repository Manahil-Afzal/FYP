/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
    public:
   string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Error: Missing space between "Subject" and subject variable
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Error: Incorrect quotes used for the string literal
    cin >> subjectname;
    teacher.setsubject(subjectname); // Error: Function name is 'setsubject', not 'setname'
    teacher.display();

    return 0;
}
