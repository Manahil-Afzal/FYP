/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
protected: // Access specifier should be protected to allow derived classes to access it.
    string subject;

public:
    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Now it's accessible due to the protected specifier.
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject’s name: "; // Corrected quotation marks
    cin >> subjectname;
    teacher.setsubject(subjectname); // Corrected function name to setsubject
    teacher.display();

    return 0;
}
