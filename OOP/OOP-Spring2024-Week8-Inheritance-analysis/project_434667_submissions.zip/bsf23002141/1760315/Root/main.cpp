/* identify and correct errors. Also comment the identified error*/

#include <iostream>
using namespace std;
class Person
{
	protected:
   string subject;
     public:
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
    string getsubject(){
    	return subject;
	}
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject :" << subject << endl;           
        }
};
int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subjects name :";
     getline(cin,subjectname);
     teacher.setsubject(subjectname);
     teacher.display();
     return 0;
}

