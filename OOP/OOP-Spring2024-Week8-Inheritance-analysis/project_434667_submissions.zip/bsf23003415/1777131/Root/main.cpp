/* identify and correct errors. Also comment the identified error*/
#include <iostream>
#include <string>
using namespace std;

class Person
{
public: // Missing access specifier
    string subject;

    void setsubject(string subjectname1)
    {
        subject = subjectname1;
    }
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Added a colon after Subject
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Fixed typo in the prompt
    cin >> subjectname;
    teacher.setsubject(subjectname); // Fixed typo in the method name
    teacher.display();

    return 0;
}
