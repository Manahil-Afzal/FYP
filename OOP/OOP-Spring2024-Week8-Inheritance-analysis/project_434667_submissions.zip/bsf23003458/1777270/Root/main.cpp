#include <iostream>
using namespace std;

class Person
{
protected: // Fix: Change access specifier to protected to access 'subject' in derived classes
    string subject;
   
public:
    void setSubject(string subjectname1) // Fix: Method name corrected to setSubject
    {
        subject = subjectname1;
    }
        
};

class MathsTeacher : public Person
{
public:
    void display()
    {
        cout << "Subject: " << subject << endl; // Fix: Access 'subject' from base class
    }
};

int main()
{
    MathsTeacher teacher;
    string subjectname;
    cout << "Enter subject's name: "; // Fix: Corrected syntax for output statement
    cin >> subjectname;
    teacher.setSubject(subjectname); // Fix: Corrected method name
    teacher.display();

    return 0;
}
