/* identify and correct errors. Also comment the identified error*/
#include <iostream>
using namespace std;

class Person
{
	public:
   string subject;
   
     
    void setsubject(string subjectname1)
    {
    subject= subjectname1;
    }
        
};

class MathsTeacher : public Person
{
    public:
        void display()
        {
             cout << "Subject" << subject << endl;
             
             
        }
};


int main()
{
     MathsTeacher teacher;
     string subjectname;
	 cout<<"Enter subject’s name";
     cin>>subjectname;
     Person p1;
	 p1.setsubject(subjectname);
     teacher.display();

     return 0;
}
